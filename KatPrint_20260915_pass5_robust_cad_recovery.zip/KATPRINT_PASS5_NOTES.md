# KatPrint Pass 5 — Robust CAD Recovery

- Added a second repair strategy: `simplify`, used as a recovery path when a targeted precision repair fails or does not improve the candidate.
- Recovery mode tells Gemini to preserve critical dimensions, openings, mating surfaces, holes, slots, clearances, locked parameters, and multi-part ABI while simplifying only non-critical geometry.
- Recovery explicitly reduces fragile CSG patterns: excessive boolean depth, transform nesting, coplanar cuts, tiny slivers, zero-thickness walls, and near-tangent operations.
- The generation loop no longer spends its second repair attempt repeating a strategy that just failed. It switches to simplified parametric recovery.
- Candidate history and deterministic comparison remain authoritative, so a recovery attempt cannot overwrite a better earlier model merely because it is newer.
