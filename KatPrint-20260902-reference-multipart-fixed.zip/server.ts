import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import * as jscadModeling from '@jscad/modeling';
import {
  JSCAD_FEATURE_BUILDER_LIB,
  FEATURE_BUILDER_REGISTRY,
  RESERVED_BUILDER_NAMES,
  validateReservedBuilderUsage,
  getFeatureFunctionName,
  getFeatureBuilderPromptDocs,
} from './src/features/featureGenerators';
import type {
  ExtractedRequirements,
  DesignSpecification,
  DesignCheck,
  GenerationMode,
  ProjectReferenceImage,
} from './src/types';
import type {
  SemanticFeatureModel,
  SemanticFeature,
  FeatureParameter,
  FeatureCodeBinding,
  FeatureBindingValidation,
  SemanticRevisionOperation,
} from './src/features/featureTypes';
import type { RevisionContextPayload } from './src/services/geminiService';

// Load .env.local first if it exists, without overriding existing environment variables
const envLocalPath = path.resolve(process.cwd(), '.env.local');
if (fs.existsSync(envLocalPath)) {
  dotenv.config({ path: envLocalPath });
}
dotenv.config();

const app = express();
const server = http.createServer(app);
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '25mb' }));


const ALLOWED_REFERENCE_IMAGE_MIME = new Set(['image/jpeg', 'image/png', 'image/webp']);

function parseReferenceImageDataUrl(image: Pick<ProjectReferenceImage, 'dataUrl' | 'mimeType'>): { mimeType: string; base64: string } | null {
  if (!image?.dataUrl || typeof image.dataUrl !== 'string') return null;
  const match = image.dataUrl.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=\r\n]+)$/i);
  if (!match) return null;
  const mimeType = match[1].toLowerCase();
  if (!ALLOWED_REFERENCE_IMAGE_MIME.has(mimeType)) return null;
  return { mimeType, base64: match[2].replace(/\s+/g, '') };
}

function appendReferenceImagesToContents(contents: any[], referenceImages: ProjectReferenceImage[] = []): any[] {
  referenceImages.slice(0, 6).forEach((image, index) => {
    const parsed = parseReferenceImageDataUrl(image);
    if (!parsed) return;
    contents.push({
      text: `REFERENCE IMAGE ${index + 1}\nRole: ${image.role || 'unknown'}\nNotes: ${image.notes || 'None'}\nFilename: ${image.fileName || image.filename || 'Reference photo'}`,
    });
    contents.push({ inlineData: { mimeType: parsed.mimeType, data: parsed.base64 } });
  });
  return contents;
}

// Lazy/Safe Gemini Client
function getGeminiClient(): GoogleGenAI | null {
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    console.warn('GEMINI_API_KEY is not set.');
    return null;
  }
  return new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      timeout: 90000,
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// ---------------------------------------------------------------------------
// Unified Gemini Request Budget & Resilience
// ---------------------------------------------------------------------------
const PRIMARY_MODEL = 'gemini-3.7-flash';
const FALLBACK_MODELS = ['gemini-2.5-flash'];

interface AIRequestRecord {
  id?: string;
  purpose: string;
  model: string;
  attemptNumber?: number;
  durationMs: number;
  timestamp: number;
  status: 'success' | 'failure';
  statusCode?: number;
  errorCategory?: string;
}

function getLastSuccessfulModel(records: AIRequestRecord[]): string | undefined {
  const successful = (records || []).filter((r) => r.status === 'success');
  return successful.length > 0 ? successful[successful.length - 1].model : undefined;
}

interface GeminiCallParams {
  purpose:
    | 'design_reasoning'
    | 'cad_generation'
    | 'cad_execution_repair'
    | 'visual_fidelity_review'
    | 'precision_correction'
    | 'final_visual_review'
    | string;
  contents: any;
  config?: any;
  enableThinking?: boolean;
  timeoutMs?: number;
}

interface GeminiCallResult {
  text: string;
  model: string;
  durationMs: number;
  attempts: number;
  requestRecords: AIRequestRecord[];
}

async function callGeminiWithResilience(
  ai: GoogleGenAI,
  params: GeminiCallParams
): Promise<GeminiCallResult> {
  const modelsToTry = [PRIMARY_MODEL, ...FALLBACK_MODELS];
  let lastError: any = null;
  const timeoutMs = params.timeoutMs || 90000;
  const startTime = Date.now();
  let totalAttempts = 0;
  const requestRecords: AIRequestRecord[] = [];

  for (let mIdx = 0; mIdx < modelsToTry.length; mIdx++) {
    const model = modelsToTry[mIdx];
    const attemptNumber = totalAttempts + 1;
    totalAttempts++;
    const attemptStartTime = Date.now();
    let timeoutId: NodeJS.Timeout | null = null;

    try {
      const configToUse = { ...(params.config || {}) };
      if (params.enableThinking && model.includes('3.7')) {
        configToUse.thinkingConfig = {
          thinkingLevel: ThinkingLevel.HIGH,
        };
      }

      const callPromise = ai.models.generateContent({
        model,
        contents: params.contents,
        config: configToUse,
      });

      const timeoutPromise = new Promise<never>((_, reject) => {
        timeoutId = setTimeout(() => {
          const tErr: any = new Error(`AI generation request timed out after ${timeoutMs}ms`);
          tErr.isTimeout = true;
          tErr.statusCode = 504;
          tErr.errorCategory = 'REQUEST_TIMEOUT';
          reject(tErr);
        }, timeoutMs);
      });

      const response = await Promise.race([callPromise, timeoutPromise]);

      if (!response || !response.text || !response.text.trim()) {
        const emptyErr: any = new Error(`Gemini model ${model} returned an empty response`);
        emptyErr.errorCategory = 'EMPTY_MODEL_RESPONSE';
        emptyErr.status = 200;
        throw emptyErr;
      }

      const attemptDuration = Date.now() - attemptStartTime;
      requestRecords.push({
        purpose: params.purpose,
        model,
        attemptNumber,
        durationMs: attemptDuration,
        timestamp: attemptStartTime,
        status: 'success',
      });

      return {
        text: response.text,
        model,
        durationMs: Date.now() - startTime,
        attempts: totalAttempts,
        requestRecords,
      };
    } catch (err: any) {
      lastError = err;
      const attemptDuration = Date.now() - attemptStartTime;
      const msg = String(err?.message || err || '');

      let rawStatus: number | undefined = undefined;
      if (typeof err?.status === 'number') rawStatus = err.status;
      else if (typeof err?.statusCode === 'number') rawStatus = err.statusCode;
      else if (typeof err?.code === 'number') rawStatus = err.code;
      else if (typeof err?.error?.code === 'number') rawStatus = err.error.code;
      else if (typeof err?.response?.status === 'number') rawStatus = err.response.status;
      else if (err?.isTimeout) rawStatus = 504;

      const isQuotaExceeded =
        rawStatus === 429 ||
        msg.includes('429') ||
        msg.includes('RESOURCE_EXHAUSTED') ||
        msg.includes('quota') ||
        msg.includes('Quota exceeded') ||
        msg.includes('rate_limit') ||
        msg.includes('rate limit');

      const isAuth =
        rawStatus === 401 ||
        rawStatus === 403 ||
        msg.includes('401') ||
        msg.includes('403') ||
        msg.includes('UNAUTHENTICATED') ||
        msg.includes('PERMISSION_DENIED') ||
        msg.includes('API key not valid');

      const isTimeoutOrDeadline =
        err?.isTimeout ||
        err?.errorCategory === 'REQUEST_TIMEOUT' ||
        rawStatus === 408 ||
        rawStatus === 504 ||
        msg.includes('504') ||
        msg.includes('DEADLINE_EXCEEDED') ||
        msg.includes('Deadline expired') ||
        msg.includes('timed out') ||
        msg.includes('timeout') ||
        msg.includes('ETIMEDOUT') ||
        err?.error?.status === 'DEADLINE_EXCEEDED';

      const isUnavailable =
        rawStatus === 503 ||
        msg.includes('503') ||
        msg.includes('UNAVAILABLE') ||
        msg.includes('high demand') ||
        msg.includes('overloaded');

      const isNotFound =
        rawStatus === 404 ||
        msg.includes('404') ||
        msg.includes('NOT_FOUND') ||
        msg.includes('is not supported') ||
        msg.includes('no longer available');

      const isBadRequest =
        rawStatus === 400 ||
        msg.includes('400') ||
        msg.includes('INVALID_ARGUMENT') ||
        msg.includes('bad request');

      let errorCategory = err?.errorCategory || (err?.isTimeout ? 'REQUEST_TIMEOUT' : undefined);
      if (!errorCategory) {
        if (isQuotaExceeded) errorCategory = 'RATE_LIMIT';
        else if (isAuth) errorCategory = 'AUTH_ERROR';
        else if (isTimeoutOrDeadline) errorCategory = 'REQUEST_TIMEOUT';
        else if (isUnavailable) errorCategory = 'GEMINI_UNAVAILABLE';
        else if (isNotFound) errorCategory = 'MODEL_UNAVAILABLE';
        else if (isBadRequest) errorCategory = 'INVALID_REQUEST';
        else errorCategory = 'UNKNOWN_ERROR';
      }

      const effectiveStatusCode = rawStatus || (isTimeoutOrDeadline ? 504 : isQuotaExceeded ? 429 : isAuth ? 401 : isUnavailable ? 503 : isNotFound ? 404 : isBadRequest ? 400 : 500);

      requestRecords.push({
        purpose: params.purpose,
        model,
        attemptNumber,
        durationMs: attemptDuration,
        timestamp: attemptStartTime,
        status: 'failure',
        statusCode: effectiveStatusCode,
        errorCategory,
      });

      err.errorCategory = errorCategory;
      err.statusCode = effectiveStatusCode;
      err.requestRecords = requestRecords;
      err.modelsUsed = Array.from(new Set(requestRecords.map((r) => r.model)));
      err.totalModelCalls = totalAttempts;

      // Stop immediately on unrecoverable quota / auth / bad-request errors
      if (isQuotaExceeded || isAuth || isBadRequest) {
        throw err;
      }

      // Fallback eligible (504/Timeout, 503 Unavailable, 404 Not Found, Empty Response):
      // Try fallback model if available
      if ((isTimeoutOrDeadline || isUnavailable || isNotFound || errorCategory === 'EMPTY_MODEL_RESPONSE') && mIdx + 1 < modelsToTry.length) {
        console.warn(`[AI Resilience] Model ${model} failed with ${errorCategory} (${effectiveStatusCode}). Falling back to ${modelsToTry[mIdx + 1]}...`);
        continue;
      }

      // End of models or unhandled error: throw
      throw err;
    } finally {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    }
  }

  if (lastError) {
    lastError.requestRecords = requestRecords;
    lastError.modelsUsed = Array.from(new Set(requestRecords.map((r) => r.model)));
    lastError.totalModelCalls = totalAttempts;
    throw lastError;
  }

  const genericErr: any = new Error('CAD generation request could not be completed.');
  genericErr.requestRecords = requestRecords;
  genericErr.modelsUsed = Array.from(new Set(requestRecords.map((r) => r.model)));
  genericErr.totalModelCalls = totalAttempts;
  throw genericErr;
}

// ---------------------------------------------------------------------------
// Security & Sandbox Validation
// ---------------------------------------------------------------------------
function stripComments(code: string): string {
  return code
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .replace(/\/\/[^\n\r]*/g, ' ');
}

function stripStringAndTemplateLiterals(code: string): string {
  return code
    .replace(/`(?:\\[\s\S]|[^`\\])*`/g, "''")
    .replace(/"(?:\\[\s\S]|[^"\\])*"/g, "''")
    .replace(/'(?:\\[\s\S]|[^'\\])*'/g, "''");
}

function validateCodeSecurity(code: string): { isSafe: boolean; violation?: string } {
  // Step 1: Strip comments first
  const noComments = stripComments(code);

  // Step 2: Check forbidden import / require syntax on code without comments
  const modulePatterns = [
    { regex: /\bimport\s+.*?from\s+['"](?!@jscad\/|jscad)[^'"]+['"]/i, reason: 'External module imports are forbidden.' },
    { regex: /\bimport\s*\(/i, reason: 'Dynamic module import() is forbidden.' },
    { regex: /\brequire\s*\(\s*['"](?!@jscad\/|jscad)[^'"]+['"]\s*\)/i, reason: 'Dangerous CommonJS require() is forbidden.' },
  ];

  for (const { regex, reason } of modulePatterns) {
    if (regex.test(noComments)) {
      return { isSafe: false, violation: `Security violation: ${reason}` };
    }
  }

  // Step 3: Strip string and template literals to inspect only executable code tokens
  const executableOnly = stripStringAndTemplateLiterals(noComments);

  const executableForbiddenPatterns = [
    { regex: /\b(?:fetch|XMLHttpRequest|WebSocket|EventSource)\s*\(/i, reason: 'Network communication APIs are forbidden.' },
    { regex: /\beval\s*\(/i, reason: 'Dynamic code execution (eval) is forbidden.' },
    { regex: /\bnew\s+Function\b/i, reason: 'Dynamic Function constructor is forbidden.' },
    { regex: /\b(?:setTimeout|setInterval|setImmediate)\s*\(/i, reason: 'Timer manipulation is forbidden.' },
    { regex: /\bprocess\.(?:env|exit|kill|cwd|chdir|mainModule|binding|dlopen|argv|pid)\b/i, reason: 'Node.js process access is forbidden.' },
    { regex: /\bchild_process\b/i, reason: 'Process spawning is forbidden.' },
    { regex: /\b(?:window|document|localStorage|sessionStorage|indexedDB)\b/i, reason: 'DOM and browser storage access is forbidden.' },
    { regex: /\b(?:window|document)\s*\.\s*(?:location|cookie)\b/i, reason: 'DOM and browser storage access is forbidden.' },
    { regex: /\b(?:global|globalThis)\b/i, reason: 'Global scope access is forbidden.' },
    { regex: /\b(?:__proto__|prototype\.constructor)\b/i, reason: 'Prototype pollution is forbidden.' },
    { regex: /\bimportScripts\s*\(/i, reason: 'Dynamic script loading is forbidden.' },
    { regex: /\bWebAssembly\b/i, reason: 'WebAssembly execution is forbidden.' },
    { regex: /\b__dirname\b|\b__filename\b/i, reason: 'System path introspection is forbidden.' },
  ];

  for (const { regex, reason } of executableForbiddenPatterns) {
    if (regex.test(executableOnly)) {
      return { isSafe: false, violation: `Security violation: ${reason}` };
    }
  }

  return { isSafe: true };
}

// ---------------------------------------------------------------------------
// Server-Side JSCAD Execution Sandbox & Geometric Measurement
// ---------------------------------------------------------------------------
interface GeometryMeasurements {
  dimensions: { x: number; y: number; z: number };
  boundingBox: [[number, number, number], [number, number, number]];
  polygonCount: number;
  triangleCount: number;
  vertexCount: number;
  actualVolumeMm3: number;
  volumeMm3: number;
  surfaceAreaMm2: number;
  nonManifoldEdgeCount: number;
  isManifold: boolean;
  isNonEmpty: boolean;
}

function measureJscadSolids(result: any): GeometryMeasurements | null {
  const solids = Array.isArray(result) ? result : [result];
  let minX = Infinity, minY = Infinity, minZ = Infinity;
  let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
  let polyCount = 0;
  let triangleCount = 0;
  let vertexCount = 0;
  let totalSignedVolume = 0;
  let totalSurfaceArea = 0;
  let hasValidPoly = false;
  let isFiniteCoords = true;

  const edgeMap = new Map<string, number>();

  for (const solid of solids) {
    if (!solid) continue;
    const polygons = solid.polygons || (solid.toPolygons ? solid.toPolygons() : []);
    if (Array.isArray(polygons)) {
      polyCount += polygons.length;
      for (const poly of polygons) {
        const vertices = poly.vertices || poly;
        if (Array.isArray(vertices) && vertices.length >= 3) {
          hasValidPoly = true;
          vertexCount += vertices.length;

          // Fan triangulation of polygon: [v[0], v[i], v[i+1]]
          const v0 = vertices[0];
          const x0 = Number(v0?.[0]);
          const y0 = Number(v0?.[1]);
          const z0 = Number(v0?.[2]);

          if (!Number.isFinite(x0) || !Number.isFinite(y0) || !Number.isFinite(z0)) {
            isFiniteCoords = false;
            continue;
          }

          if (x0 < minX) minX = x0;
          if (x0 > maxX) maxX = x0;
          if (y0 < minY) minY = y0;
          if (y0 > maxY) maxY = y0;
          if (z0 < minZ) minZ = z0;
          if (z0 > maxZ) maxZ = z0;

          for (let i = 1; i < vertices.length - 1; i++) {
            const v1 = vertices[i];
            const v2 = vertices[i + 1];

            const x1 = Number(v1?.[0]);
            const y1 = Number(v1?.[1]);
            const z1 = Number(v1?.[2]);
            const x2 = Number(v2?.[0]);
            const y2 = Number(v2?.[1]);
            const z2 = Number(v2?.[2]);

            if (
              !Number.isFinite(x1) || !Number.isFinite(y1) || !Number.isFinite(z1) ||
              !Number.isFinite(x2) || !Number.isFinite(y2) || !Number.isFinite(z2)
            ) {
              isFiniteCoords = false;
              continue;
            }

            if (x1 < minX) minX = x1;
            if (x1 > maxX) maxX = x1;
            if (y1 < minY) minY = y1;
            if (y1 > maxY) maxY = y1;
            if (z1 < minZ) minZ = z1;
            if (z1 > maxZ) maxZ = z1;

            if (x2 < minX) minX = x2;
            if (x2 > maxX) maxX = x2;
            if (y2 < minY) minY = y2;
            if (y2 > maxY) maxY = y2;
            if (z2 < minZ) minZ = z2;
            if (z2 > maxZ) maxZ = z2;

            triangleCount++;

            // Signed tetrahedron volume calculation: (v0 . (v1 x v2)) / 6
            const signedTetraVolume =
              (x0 * (y1 * z2 - z1 * y2) +
                y0 * (z1 * x2 - x1 * z2) +
                z0 * (x1 * y2 - y1 * x2)) /
              6.0;
            totalSignedVolume += signedTetraVolume;

            // Surface Area from cross product
            const ax = x1 - x0;
            const ay = y1 - y0;
            const az = z1 - z0;
            const bx = x2 - x0;
            const by = y2 - y0;
            const bz = z2 - z0;

            const cx = ay * bz - az * by;
            const cy = az * bx - ax * bz;
            const cz = ax * by - ay * bx;
            const triArea = 0.5 * Math.hypot(cx, cy, cz);
            totalSurfaceArea += triArea;

            // Undirected edge tracking for manifold verification
            const p0 = `${x0.toFixed(4)},${y0.toFixed(4)},${z0.toFixed(4)}`;
            const p1 = `${x1.toFixed(4)},${y1.toFixed(4)},${z1.toFixed(4)}`;
            const p2 = `${x2.toFixed(4)},${y2.toFixed(4)},${z2.toFixed(4)}`;

            const e1 = p0 < p1 ? `${p0}_${p1}` : `${p1}_${p0}`;
            const e2 = p1 < p2 ? `${p1}_${p2}` : `${p2}_${p1}`;
            const e3 = p2 < p0 ? `${p2}_${p0}` : `${p0}_${p2}`;

            edgeMap.set(e1, (edgeMap.get(e1) || 0) + 1);
            edgeMap.set(e2, (edgeMap.get(e2) || 0) + 1);
            edgeMap.set(e3, (edgeMap.get(e3) || 0) + 1);
          }
        }
      }
    }
  }

  if (!hasValidPoly || polyCount === 0 || !isFiniteCoords || minX === Infinity) {
    return null;
  }

  const dimX = Number(Math.max(0, maxX - minX).toFixed(2));
  const dimY = Number(Math.max(0, maxY - minY).toFixed(2));
  const dimZ = Number(Math.max(0, maxZ - minZ).toFixed(2));

  const actualVolumeMm3 = Number(Math.abs(totalSignedVolume).toFixed(2));
  const surfaceAreaMm2 = Number(totalSurfaceArea.toFixed(2));

  // In a closed triangular manifold mesh without boundary, every edge is shared by exactly 2 triangles
  let nonManifoldEdgeCount = 0;
  for (const count of edgeMap.values()) {
    if (count !== 2) {
      nonManifoldEdgeCount++;
    }
  }

  const isManifold = nonManifoldEdgeCount === 0 && triangleCount >= 4 && actualVolumeMm3 > 0.001;
  const isNonEmpty = triangleCount > 0 && actualVolumeMm3 > 0.001 && (dimX > 0.1 || dimY > 0.1 || dimZ > 0.1);

  return {
    dimensions: { x: dimX, y: dimY, z: dimZ },
    boundingBox: [
      [Number(minX.toFixed(2)), Number(minY.toFixed(2)), Number(minZ.toFixed(2))],
      [Number(maxX.toFixed(2)), Number(maxY.toFixed(2)), Number(maxZ.toFixed(2))],
    ],
    polygonCount: polyCount,
    triangleCount,
    vertexCount,
    actualVolumeMm3,
    volumeMm3: actualVolumeMm3,
    surfaceAreaMm2,
    nonManifoldEdgeCount,
    isManifold,
    isNonEmpty,
  };
}


function measureIndividualJscadSolids(result: any): GeometryMeasurements[] {
  const solids = Array.isArray(result) ? result : [result];
  return solids.map((solid) => measureJscadSolids(solid)).filter((m): m is GeometryMeasurements => Boolean(m));
}

function buildEnhancedJscadServerRuntime(modelingLib: any) {
  const rawJscad = (modelingLib as any)?.default?.primitives
    ? (modelingLib as any).default
    : (modelingLib as any)?.primitives
    ? (modelingLib as any)
    : ((modelingLib as any)?.default || (modelingLib as any) || {});

  const rawPrimitives = rawJscad.primitives || (modelingLib as any)?.primitives || {};
  const rawBooleans = rawJscad.booleans || (modelingLib as any)?.booleans || {};
  const rawTransforms = rawJscad.transforms || (modelingLib as any)?.transforms || {};
  const rawExtrusions = rawJscad.extrusions || (modelingLib as any)?.extrusions || {};
  const rawHulls = rawJscad.hulls || (modelingLib as any)?.hulls || {};
  const rawExpansions = rawJscad.expansions || (modelingLib as any)?.expansions || {};
  const rawGeometries = rawJscad.geometries || (modelingLib as any)?.geometries || {};
  const rawMeasurements = rawJscad.measurements || (modelingLib as any)?.measurements || {};
  const rawColors = rawJscad.colors || (modelingLib as any)?.colors || {};
  const rawMaths = rawJscad.maths || (modelingLib as any)?.maths || {};
  const rawUtils = rawJscad.utils || (modelingLib as any)?.utils || {};

  const normalizeVec3 = (arg0: any, arg1?: any, arg2?: any): [number, number, number] => {
    if (Array.isArray(arg0)) {
      return [Number(arg0[0]) || 0, Number(arg0[1]) || 0, Number(arg0[2]) || 0];
    }
    if (typeof arg0 === 'number') {
      return [arg0, Number(arg1) || 0, Number(arg2) || 0];
    }
    return [0, 0, 0];
  };

  const enhanceGeometry = (geom: any): any => {
    if (!geom || typeof geom !== 'object') return geom;
    if (Array.isArray(geom)) {
      for (let i = 0; i < geom.length; i++) {
        geom[i] = enhanceGeometry(geom[i]);
      }
      return geom;
    }
    if ((geom as any).__enhanced) return geom;

    try {
      Object.defineProperties(geom, {
        __enhanced: { value: true, writable: true, configurable: true },
        translate: {
          value: function (...args: any[]) {
            const offset = args.length === 1 && Array.isArray(args[0]) ? args[0] : normalizeVec3(args[0], args[1], args[2]);
            const res = rawTransforms.translate ? rawTransforms.translate(offset, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        rotate: {
          value: function (...args: any[]) {
            const angles = args.length === 1 && Array.isArray(args[0]) ? args[0] : normalizeVec3(args[0], args[1], args[2]);
            const res = rawTransforms.rotate ? rawTransforms.rotate(angles, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        rotateX: {
          value: function (rad: number) {
            const res = rawTransforms.rotateX ? rawTransforms.rotateX(rad, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        rotateY: {
          value: function (rad: number) {
            const res = rawTransforms.rotateY ? rawTransforms.rotateY(rad, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        rotateZ: {
          value: function (rad: number) {
            const res = rawTransforms.rotateZ ? rawTransforms.rotateZ(rad, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        scale: {
          value: function (...args: any[]) {
            let factors: any = args[0];
            if (typeof factors === 'number' && args.length === 1) {
              factors = [factors, factors, factors];
            } else if (typeof factors === 'number' && args.length >= 3) {
              factors = [factors, args[1], args[2]];
            }
            const res = rawTransforms.scale ? rawTransforms.scale(factors, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        center: {
          value: function (options: any = {}) {
            const res = rawTransforms.center ? rawTransforms.center(options, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        align: {
          value: function (options: any = {}) {
            const res = rawTransforms.align ? rawTransforms.align(options, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        mirror: {
          value: function (options: any = {}) {
            const res = rawTransforms.mirror ? rawTransforms.mirror(options, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        subtract: {
          value: function (...cuts: any[]) {
            return enhanceGeometry(safeSubtract(this, ...cuts));
          },
          writable: true,
          configurable: true,
        },
        union: {
          value: function (...others: any[]) {
            return enhanceGeometry(safeUnion(this, ...others));
          },
          writable: true,
          configurable: true,
        },
        intersect: {
          value: function (...others: any[]) {
            return enhanceGeometry(safeIntersect(this, ...others));
          },
          writable: true,
          configurable: true,
        },
        colorize: {
          value: function (color: any) {
            const res = rawColors.colorize ? rawColors.colorize(color, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
      });
    } catch {
      // Ignore if properties cannot be defined
    }
    return geom;
  };

  const safeCube = (options: any = {}) => {
    let opts = options;
    if (typeof opts === 'number') opts = { size: [opts, opts, opts] };
    else if (Array.isArray(opts)) opts = { size: opts };
    if (opts && Array.isArray(opts.size)) {
      if (typeof rawPrimitives.cuboid === 'function') return enhanceGeometry(rawPrimitives.cuboid(opts));
      if (typeof rawPrimitives.cube === 'function') return enhanceGeometry(rawPrimitives.cube(opts));
    }
    if (typeof rawPrimitives.cube === 'function') return enhanceGeometry(rawPrimitives.cube(opts));
    if (typeof rawPrimitives.cuboid === 'function') return enhanceGeometry(rawPrimitives.cuboid(opts));
    return null;
  };

  const safeRoundedCuboid = (options: any = {}) => {
    let opts = { ...options };
    if (opts.radius && !opts.roundRadius) opts.roundRadius = opts.radius;
    if (opts.round && !opts.roundRadius) opts.roundRadius = opts.round;
    if (!opts.roundRadius) opts.roundRadius = 1;
    if (typeof rawPrimitives.roundedCuboid === 'function') {
      try {
        return enhanceGeometry(rawPrimitives.roundedCuboid(opts));
      } catch {
        return safeCube(opts);
      }
    }
    return safeCube(opts);
  };

  const safeSubtract = (target: any, ...cuts: any[]) => {
    if (!target) return target;
    const flatCuts: any[] = [];
    for (const c of cuts) {
      if (Array.isArray(c)) flatCuts.push(...c);
      else if (c) flatCuts.push(c);
    }
    if (flatCuts.length === 0) return enhanceGeometry(target);
    if (typeof rawBooleans.subtract === 'function') {
      return enhanceGeometry(rawBooleans.subtract(target, ...flatCuts));
    }
    return enhanceGeometry(target);
  };

  const safeUnion = (...objects: any[]) => {
    const flat: any[] = [];
    for (const obj of objects) {
      if (Array.isArray(obj)) flat.push(...obj);
      else if (obj) flat.push(obj);
    }
    if (flat.length === 0) return safeCube({ size: 1 });
    if (flat.length === 1) return enhanceGeometry(flat[0]);
    if (typeof rawBooleans.union === 'function') {
      return enhanceGeometry(rawBooleans.union(...flat));
    }
    return enhanceGeometry(flat[0]);
  };

  const safeIntersect = (...objects: any[]) => {
    const flat: any[] = [];
    for (const obj of objects) {
      if (Array.isArray(obj)) flat.push(...obj);
      else if (obj) flat.push(obj);
    }
    if (typeof rawBooleans.intersect === 'function') {
      return enhanceGeometry(rawBooleans.intersect(...flat));
    }
    return enhanceGeometry(flat[0] || null);
  };

  const safeTranslate = (arg1: any, ...geoms: any[]) => {
    if (Array.isArray(arg1) || typeof arg1 === 'number') {
      const offset = normalizeVec3(arg1);
      const res = rawTransforms.translate ? rawTransforms.translate(offset, ...geoms) : geoms[0];
      return enhanceGeometry(res);
    }
    if (geoms.length > 0 && (Array.isArray(geoms[0]) || typeof geoms[0] === 'number')) {
      const offset = normalizeVec3(geoms[0]);
      const res = rawTransforms.translate ? rawTransforms.translate(offset, arg1) : arg1;
      return enhanceGeometry(res);
    }
    return enhanceGeometry(arg1);
  };

  const safeRotate = (arg1: any, ...geoms: any[]) => {
    if (Array.isArray(arg1) || typeof arg1 === 'number') {
      const angles = normalizeVec3(arg1);
      const res = rawTransforms.rotate ? rawTransforms.rotate(angles, ...geoms) : geoms[0];
      return enhanceGeometry(res);
    }
    if (geoms.length > 0 && (Array.isArray(geoms[0]) || typeof geoms[0] === 'number')) {
      const angles = normalizeVec3(geoms[0]);
      const res = rawTransforms.rotate ? rawTransforms.rotate(angles, arg1) : arg1;
      return enhanceGeometry(res);
    }
    return enhanceGeometry(arg1);
  };

  const safeRotateX = (rad: number, ...geoms: any[]) => {
    const res = rawTransforms.rotateX ? rawTransforms.rotateX(rad, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };
  const safeRotateY = (rad: number, ...geoms: any[]) => {
    const res = rawTransforms.rotateY ? rawTransforms.rotateY(rad, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };
  const safeCylinder = (...args: any[]) => {
    try {
      let opt: any = {};
      if (args.length === 1 && typeof args[0] === 'object' && args[0] !== null) {
        const o = args[0];
        const r = o.radius ?? o.r ?? (Array.isArray(o.startRadius) ? o.startRadius[0] : o.startRadius) ?? 5;
        const endR = o.endRadius ?? o.radius2 ?? o.r2 ?? o.topRadius;
        const h = o.height ?? o.h ?? o.length ?? 10;
        const segs = o.segments ?? o.fn ?? 32;

        if (endR !== undefined) {
          const r2 = Array.isArray(endR) ? endR[0] : endR;
          const res = rawPrimitives.cylinderElliptic
            ? rawPrimitives.cylinderElliptic({
                startRadius: [Math.max(0.001, Number(r) || 5), Math.max(0.001, Number(r) || 5)],
                endRadius: [Math.max(0.0001, Number(r2) || 0.0001), Math.max(0.0001, Number(r2) || 0.0001)],
                height: Math.max(0.001, Number(h) || 10),
                segments: segs,
                center: o.center ?? [0, 0, 0],
              })
            : rawPrimitives.cylinder({
                radius: Math.max(0.001, Number(r) || 5),
                height: Math.max(0.001, Number(h) || 10),
                segments: segs,
                center: o.center ?? [0, 0, 0],
              });
          return enhanceGeometry(res);
        }

        opt = {
          radius: Math.max(0.001, Number(r) || 5),
          height: Math.max(0.001, Number(h) || 10),
          segments: segs,
          center: o.center ?? [0, 0, 0],
        };
      } else if (args.length >= 2) {
        const r = typeof args[0] === 'number' ? args[0] : 5;
        const h = typeof args[1] === 'number' ? args[1] : 10;
        const segs = typeof args[2] === 'number' ? args[2] : 32;
        opt = { radius: Math.max(0.001, r), height: Math.max(0.001, h), segments: segs };
      } else {
        opt = args[0] || {};
      }

      const res = rawPrimitives.cylinder(opt);
      return enhanceGeometry(res);
    } catch {
      return enhanceGeometry(rawPrimitives.cylinder({ radius: 5, height: 10, segments: 16 }));
    }
  };

  const safeCone = (...args: any[]) => {
    try {
      let r1 = 10;
      let r2 = 0.001;
      let h = 20;
      let segs = 32;
      let center = [0, 0, 0];

      if (args.length === 1 && typeof args[0] === 'object' && args[0] !== null) {
        const opt = args[0];
        h = opt.height ?? opt.h ?? opt.length ?? 20;
        r1 =
          opt.bottomRadius ??
          opt.radius1 ??
          opt.r1 ??
          opt.radius ??
          opt.r ??
          (Array.isArray(opt.startRadius) ? opt.startRadius[0] : opt.startRadius) ??
          10;
        r2 =
          opt.topRadius ??
          opt.radius2 ??
          opt.r2 ??
          (Array.isArray(opt.endRadius) ? opt.endRadius[0] : opt.endRadius) ??
          0.001;
        segs = opt.segments ?? opt.fn ?? 32;
        if (opt.center) center = opt.center;
      } else if (args.length === 1 && typeof args[0] === 'number') {
        r1 = args[0];
        r2 = 0.001;
        h = 20;
      } else if (args.length >= 2) {
        if (args.length === 2) {
          r1 = typeof args[0] === 'number' ? args[0] : 10;
          r2 = 0.001;
          h = typeof args[1] === 'number' ? args[1] : 20;
        } else {
          r1 = typeof args[0] === 'number' ? args[0] : 10;
          r2 = typeof args[1] === 'number' ? Math.max(0.0001, args[1]) : 0.001;
          h = typeof args[2] === 'number' ? args[2] : 20;
          if (typeof args[3] === 'number') segs = args[3];
        }
      }

      const startR = Math.max(0.001, Number(r1) || 10);
      const endR = Math.max(0.0001, Number(r2) || 0.0001);
      const height = Math.max(0.001, Number(h) || 20);

      const res = rawPrimitives.cylinderElliptic
        ? rawPrimitives.cylinderElliptic({
            startRadius: [startR, startR],
            endRadius: [endR, endR],
            height: height,
            segments: segs,
            center: center,
          })
        : rawPrimitives.cylinder({
            radius: startR,
            height: height,
            segments: segs,
            center: center,
          });
      return enhanceGeometry(res);
    } catch {
      return enhanceGeometry(rawPrimitives.cylinder({ radius: 10, height: 20, segments: 16 }));
    }
  };

  const safeTube = (...args: any[]) => {
    try {
      let outerR = 10;
      let innerR = 8;
      let h = 20;
      let segs = 32;
      if (args.length === 1 && typeof args[0] === 'object' && args[0] !== null) {
        const o = args[0];
        outerR = o.outerRadius ?? o.radius ?? o.r ?? 10;
        innerR = o.innerRadius ?? (o.wallThickness ? outerR - o.wallThickness : outerR - 2);
        h = o.height ?? o.h ?? 20;
        segs = o.segments ?? o.fn ?? 32;
      } else if (args.length >= 2) {
        outerR = Number(args[0]) || 10;
        innerR = Number(args[1]) || 8;
        h = Number(args[2]) || 20;
        if (args[3]) segs = Number(args[3]);
      }
      const outer = safeCylinder({ radius: outerR, height: h, segments: segs });
      const inner = safeCylinder({ radius: Math.min(innerR, outerR - 0.1), height: h + 4, segments: segs });
      return safeSubtract(outer, inner);
    } catch {
      return enhanceGeometry(rawPrimitives.cylinder({ radius: 10, height: 20 }));
    }
  };

  const safeRotateZ = (rad: number, ...geoms: any[]) => {
    const res = rawTransforms.rotateZ ? rawTransforms.rotateZ(rad, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };

  const safeScale = (factors: any, ...geoms: any[]) => {
    let f = factors;
    if (typeof f === 'number') f = [f, f, f];
    const res = rawTransforms.scale ? rawTransforms.scale(f, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };

  const wrapPrimitive = (fn: any) => {
    if (typeof fn !== 'function') return () => null;
    return (...args: any[]) => {
      try {
        const res = fn(...args);
        return enhanceGeometry(res);
      } catch {
        return null;
      }
    };
  };

  const primitives = {
    ...rawPrimitives,
    cube: safeCube,
    cuboid: wrapPrimitive(rawPrimitives.cuboid) || safeCube,
    cylinder: safeCylinder,
    cone: safeCone,
    tube: safeTube,
    pipe: safeTube,
    cylinderElliptic: wrapPrimitive(rawPrimitives.cylinderElliptic),
    roundedCylinder: wrapPrimitive(rawPrimitives.roundedCylinder),
    sphere: wrapPrimitive(rawPrimitives.sphere),
    geodesicSphere: wrapPrimitive(rawPrimitives.geodesicSphere),
    ellipsoid: wrapPrimitive(rawPrimitives.ellipsoid),
    polyhedron: wrapPrimitive(rawPrimitives.polyhedron),
    roundedCuboid: safeRoundedCuboid,
    torus: wrapPrimitive(rawPrimitives.torus),
    polygon: wrapPrimitive(rawPrimitives.polygon),
    rectangle: wrapPrimitive(rawPrimitives.rectangle),
    roundedRectangle: wrapPrimitive(rawPrimitives.roundedRectangle),
    circle: wrapPrimitive(rawPrimitives.circle),
    ellipse: wrapPrimitive(rawPrimitives.ellipse),
    star: wrapPrimitive(rawPrimitives.star),
  };

  const transforms = {
    ...rawTransforms,
    translate: safeTranslate,
    rotate: safeRotate,
    rotateX: safeRotateX,
    rotateY: safeRotateY,
    rotateZ: safeRotateZ,
    scale: safeScale,
    center: (options: any, ...geoms: any[]) => enhanceGeometry(rawTransforms.center ? rawTransforms.center(options, ...geoms) : geoms[0]),
    align: (options: any, ...geoms: any[]) => enhanceGeometry(rawTransforms.align ? rawTransforms.align(options, ...geoms) : geoms[0]),
    mirror: (options: any, ...geoms: any[]) => enhanceGeometry(rawTransforms.mirror ? rawTransforms.mirror(options, ...geoms) : geoms[0]),
    transform: (matrix: any, ...geoms: any[]) => enhanceGeometry(rawTransforms.transform ? rawTransforms.transform(matrix, ...geoms) : geoms[0]),
  };

  const booleans = {
    ...rawBooleans,
    union: safeUnion,
    subtract: safeSubtract,
    intersect: safeIntersect,
  };

  const extrusions = {
    ...rawExtrusions,
    extrudeLinear: (options: any, ...geoms: any[]) => enhanceGeometry(rawExtrusions.extrudeLinear ? rawExtrusions.extrudeLinear(options, ...geoms) : geoms[0]),
    extrudeRotate: (options: any, ...geoms: any[]) => enhanceGeometry(rawExtrusions.extrudeRotate ? rawExtrusions.extrudeRotate(options, ...geoms) : geoms[0]),
    extrudeRectangular: (options: any, ...geoms: any[]) => enhanceGeometry(rawExtrusions.extrudeRectangular ? rawExtrusions.extrudeRectangular(options, ...geoms) : geoms[0]),
    slice: (options: any, ...geoms: any[]) => enhanceGeometry(rawExtrusions.slice ? rawExtrusions.slice(options, ...geoms) : geoms[0]),
  };

  const hulls = {
    ...rawHulls,
    hull: (...geoms: any[]) => enhanceGeometry(rawHulls.hull ? rawHulls.hull(...geoms) : geoms[0]),
    hullChain: (...geoms: any[]) => enhanceGeometry(rawHulls.hullChain ? rawHulls.hullChain(...geoms) : geoms[0]),
  };

  const expansions = {
    ...rawExpansions,
    expand: (options: any, ...geoms: any[]) => enhanceGeometry(rawExpansions.expand ? rawExpansions.expand(options, ...geoms) : geoms[0]),
    offset: (options: any, ...geoms: any[]) => enhanceGeometry(rawExpansions.offset ? rawExpansions.offset(options, ...geoms) : geoms[0]),
  };

  const colors = {
    ...rawColors,
    colorize: (color: any, ...geoms: any[]) => enhanceGeometry(rawColors.colorize ? rawColors.colorize(color, ...geoms) : geoms[0]),
  };

  const jscad = {
    ...rawJscad,
    primitives,
    booleans,
    transforms,
    extrusions,
    hulls,
    expansions,
    geometries: rawGeometries,
    measurements: rawMeasurements,
    colors,
    maths: rawMaths,
    utils: rawUtils,
  };

  const safeRequire = (moduleName: string) => {
    if (!moduleName || typeof moduleName !== 'string') return jscad;
    const clean = moduleName.trim().toLowerCase();
    if (
      clean === '@jscad/modeling' ||
      clean === 'jscad' ||
      clean === '@jscad/csg' ||
      clean === 'openjscad' ||
      clean.includes('jscad')
    ) {
      return jscad;
    }
    throw new Error(`Module '${moduleName}' is not allowed in CAD sandbox`);
  };

  return {
    jscad,
    primitives,
    booleans,
    transforms,
    extrusions,
    hulls,
    expansions,
    geometries: rawGeometries,
    measurements: rawMeasurements,
    colors,
    maths: rawMaths,
    utils: rawUtils,
    safeCube,
    safeRoundedCuboid,
    safeCylinder,
    safeCone,
    safeTube,
    safeSubtract,
    safeUnion,
    safeIntersect,
    safeTranslate,
    safeRotate,
    safeRotateX,
    safeRotateY,
    safeRotateZ,
    safeScale,
    safeRequire,
    enhanceGeometry,
  };
}

const serverCadRuntime = buildEnhancedJscadServerRuntime(jscadModeling);

function executeJscadServerSide(codeString: string): {
  success: boolean;
  error?: string;
  measurements?: GeometryMeasurements;
  polygonCount?: number;
  partMeasurements?: GeometryMeasurements[];
} {
  try {
    // 1. Strict Security Validation
    const security = validateCodeSecurity(codeString);
    if (!security.isSafe) {
      return { success: false, error: security.violation };
    }

    // 2. Syntax extract and normalize
    const cleanCode = extractAndValidateJscad(codeString);
    if (!cleanCode) {
      return { success: false, error: 'Code does not contain a valid main() function declaration' };
    }

    // Isolated sandbox scope: mask dangerous globals as undefined
    const scopeKeys = [
      'process',
      'global',
      'globalThis',
      'fetch',
      'XMLHttpRequest',
      'WebSocket',
      'localStorage',
      'sessionStorage',
      'window',
      'document',
      'require',
      'jscad',
      'jscadModeling',
      'jscad_modeling',
      'modeling',
      'JSCAD',
      'CSG',
      'primitives',
      'booleans',
      'transforms',
      'extrusions',
      'hulls',
      'expansions',
      'geometries',
      'measurements',
      'colors',
      'maths',
      'utils',
      'cube',
      'cuboid',
      'cylinder',
      'cone',
      'tube',
      'pipe',
      'cylinderElliptic',
      'roundedCylinder',
      'sphere',
      'geodesicSphere',
      'ellipsoid',
      'polyhedron',
      'roundedCuboid',
      'torus',
      'polygon',
      'rectangle',
      'roundedRectangle',
      'circle',
      'ellipse',
      'star',
      'union',
      'subtract',
      'intersect',
      'translate',
      'rotate',
      'rotateX',
      'rotateY',
      'rotateZ',
      'scale',
      'center',
      'align',
      'mirror',
      'transform',
      'extrudeLinear',
      'extrudeRotate',
      'extrudeRectangular',
      'slice',
      'hull',
      'hullChain',
      'expand',
      'offset',
      'colorize',
    ];

    const scopeValues = [
      undefined, // process
      undefined, // global
      undefined, // globalThis
      undefined, // fetch
      undefined, // XMLHttpRequest
      undefined, // WebSocket
      undefined, // localStorage
      undefined, // sessionStorage
      undefined, // window
      undefined, // document
      serverCadRuntime.safeRequire,
      serverCadRuntime.jscad,
      serverCadRuntime.jscad,
      serverCadRuntime.jscad,
      serverCadRuntime.jscad,
      serverCadRuntime.jscad,
      serverCadRuntime.jscad,
      serverCadRuntime.primitives,
      serverCadRuntime.booleans,
      serverCadRuntime.transforms,
      serverCadRuntime.extrusions,
      serverCadRuntime.hulls,
      serverCadRuntime.expansions,
      serverCadRuntime.geometries,
      serverCadRuntime.measurements,
      serverCadRuntime.colors,
      serverCadRuntime.maths,
      serverCadRuntime.utils,
      serverCadRuntime.safeCube,
      serverCadRuntime.primitives.cuboid || serverCadRuntime.safeCube,
      serverCadRuntime.safeCylinder,
      serverCadRuntime.safeCone,
      serverCadRuntime.safeTube,
      serverCadRuntime.safeTube,
      serverCadRuntime.primitives.cylinderElliptic,
      serverCadRuntime.primitives.roundedCylinder,
      serverCadRuntime.primitives.sphere,
      serverCadRuntime.primitives.geodesicSphere,
      serverCadRuntime.primitives.ellipsoid,
      serverCadRuntime.primitives.polyhedron,
      serverCadRuntime.safeRoundedCuboid,
      serverCadRuntime.primitives.torus,
      serverCadRuntime.primitives.polygon,
      serverCadRuntime.primitives.rectangle,
      serverCadRuntime.primitives.roundedRectangle,
      serverCadRuntime.primitives.circle,
      serverCadRuntime.primitives.ellipse,
      serverCadRuntime.primitives.star,
      serverCadRuntime.safeUnion,
      serverCadRuntime.safeSubtract,
      serverCadRuntime.safeIntersect,
      serverCadRuntime.safeTranslate,
      serverCadRuntime.safeRotate,
      serverCadRuntime.safeRotateX,
      serverCadRuntime.safeRotateY,
      serverCadRuntime.safeRotateZ,
      serverCadRuntime.safeScale,
      serverCadRuntime.transforms.center,
      serverCadRuntime.transforms.align,
      serverCadRuntime.transforms.mirror,
      serverCadRuntime.transforms.transform,
      serverCadRuntime.extrusions.extrudeLinear,
      serverCadRuntime.extrusions.extrudeRotate,
      serverCadRuntime.extrusions.extrudeRectangular,
      serverCadRuntime.extrusions.slice,
      serverCadRuntime.hulls.hull,
      serverCadRuntime.hulls.hullChain,
      serverCadRuntime.expansions.expand,
      serverCadRuntime.expansions.offset,
      serverCadRuntime.colors.colorize,
    ];

    const wrappedScript = `
      const exports = {};
      const module = { exports };
      ${JSCAD_FEATURE_BUILDER_LIB}
      ${cleanCode}
      if (typeof main === 'function') {
        return main();
      } else if (typeof exports !== 'undefined' && typeof exports.main === 'function') {
        return exports.main();
      } else if (typeof module !== 'undefined' && module.exports && typeof module.exports.main === 'function') {
        return module.exports.main();
      }
      throw new Error('main() function not declared or exported');
    `;

    const fn = new Function(...scopeKeys, wrappedScript);
    const result = fn(...scopeValues);
    if (!result) {
      return { success: false, error: 'main() returned undefined or null' };
    }

    const measured = measureJscadSolids(result);
    if (!measured || !measured.isNonEmpty) {
      return {
        success: false,
        error: 'main() returned geometry with zero valid polygons (empty or degenerate solid)',
      };
    }

    const partMeasurements = measureIndividualJscadSolids(result);
    if (Array.isArray(result) && result.length > 1) {
      if (partMeasurements.length !== result.length) {
        return { success: false, error: 'One or more returned parts could not be measured.' };
      }
      for (let i = 0; i < partMeasurements.length; i++) {
        const part = partMeasurements[i];
        if (!part.isNonEmpty || part.actualVolumeMm3 <= 0 || part.triangleCount <= 0 || !part.isManifold || part.nonManifoldEdgeCount > 0) {
          return {
            success: false,
            error: `Part ${i + 1} is not independently printable (${!part.isNonEmpty ? 'empty/degenerate' : !part.isManifold ? 'non-manifold' : 'invalid geometry'}).`,
            partMeasurements,
          };
        }
      }
    }

    return {
      success: true,
      measurements: measured,
      partMeasurements,
      polygonCount: measured.polygonCount,
    };
  } catch (e: any) {
    return { success: false, error: e?.message || String(e) };
  }
}

// ---------------------------------------------------------------------------
// JSCAD String Sanitizer and Function Extractor (no silent removal of forbidden code)
// ---------------------------------------------------------------------------
function extractAndValidateJscad(rawText: string): string | null {
  if (!rawText || typeof rawText !== 'string') return null;

  let code = rawText.trim();
  const fenceMatch = code.match(/```(?:javascript|js|typescript|ts)?\s*([\s\S]*?)```/i);
  if (fenceMatch && fenceMatch[1]) {
    code = fenceMatch[1].trim();
  } else {
    code = code
      .replace(/^```[a-z]*\s*/gim, '')
      .replace(/\s*```$/gim, '')
      .replace(/```javascript/gi, '')
      .replace(/```js/gi, '')
      .replace(/```/g, '')
      .trim();
  }

  code = code
    .replace(/import\s*\{\s*([^}]+)\s*\}\s*from\s*['"](?:@jscad\/modeling|jscad)['"];?/gi, 'const { $1 } = jscad;')
    .replace(/import\s+([a-zA-Z0-9_$]+)\s+from\s*['"](?:@jscad\/modeling|jscad)['"];?/gi, 'const $1 = jscad;')
    .replace(/const\s*\{\s*([^}]+)\s*\}\s*=\s*require\(['"](?:@jscad\/modeling|jscad)['"]\);?/gi, 'const { $1 } = jscad;')
    .replace(/const\s+([a-zA-Z0-9_$]+)\s*=\s*require\(['"](?:@jscad\/modeling|jscad)['"]\);?/gi, 'const $1 = jscad;')
    .replace(/\bexport\s+default\s+function\s+/g, 'function ')
    .replace(/\bexport\s+function\s+/g, 'function ')
    .replace(/\bexport\s+(?:const|let|var)\s+/g, 'const ');

  const hasMain =
    /\bfunction\s+main\s*\(/.test(code) ||
    /\b(?:const|let|var)\s+main\s*=\s*(?:function|\([^)]*\)\s*=>|\w+\s*=>)/.test(code) ||
    /\bmain\s*=\s*(?:function|\([^)]*\)\s*=>|\w+\s*=>)/.test(code) ||
    /\bfunction\s+main\b/.test(code) ||
    /\bexports\.main\s*=/.test(code) ||
    /\bmodule\.exports\s*=\s*\{\s*main/.test(code);

  if (hasMain) {
    return code.trim();
  }

  if (/\b(?:union|subtract|intersect|cube|cuboid|cylinder|sphere|roundedCuboid)\s*\(/.test(code)) {
    if (/^\s*return\s+/m.test(code)) {
      return `function main() {\n${code}\n}`;
    }
  }

  return null;
}

// ---------------------------------------------------------------------------
// Step 1: Requirements Extraction Pass
// ---------------------------------------------------------------------------
const SERVER_KNOWN_REFERENCE_OBJECTS = [
  {
    name: 'Dr. Squatch Soap Bar',
    aliases: [
      'dr squatch',
      'squatch bar',
      'dr. squatch',
      'squatch soap',
      'dr.squatch',
      'dr squatch soap',
      'dr squatch bar',
      'dr. squatch bar',
      'dr. squatch soap',
      'squatch',
    ],
    dimensions: { width: 76.2, depth: 76.2, height: 25.4 },
    confidence: 'verified' as const,
    clearanceMm: 2.0,
    sourceNote: 'Standard 3" × 3" × 1" cold-process soap bar',
  },
  {
    name: 'Standard Bar Soap (Dove / Dial)',
    aliases: ['soap bar', 'bar soap', 'bath soap', 'dove bar', 'standard soap', 'hand soap bar'],
    dimensions: { width: 88.0, depth: 56.0, height: 26.0 },
    confidence: 'verified' as const,
    clearanceMm: 3.0,
    sourceNote: 'Standard rectangular rounded bar soap',
  },
  {
    name: 'Apple iPhone 17 / 16 / 15 Pro Max',
    aliases: [
      'iphone 17 pro max',
      'iphone 17',
      'iphone 16 pro max',
      'iphone 16',
      'iphone 15 pro max',
      'iphone max',
      'pro max',
      'iphone 17 pro',
      'iphone 16 pro',
    ],
    dimensions: { width: 77.6, depth: 8.25, height: 163.0 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: '6.7-inch to 6.9-inch flagship smartphone body',
  },
  {
    name: 'Apple iPhone Standard (15 / 14 / 13)',
    aliases: ['iphone 15', 'iphone 14', 'iphone 13', 'iphone', 'standard iphone', 'iphone 12', 'smartphone', 'phone'],
    dimensions: { width: 71.6, depth: 7.8, height: 147.6 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: '6.1-inch standard smartphone body',
  },
  {
    name: 'Apple AirPods / AirPods Pro Case',
    aliases: ['airpods', 'airpods pro', 'airpod case', 'earbuds case', 'airpods case'],
    dimensions: { width: 60.6, depth: 21.7, height: 45.2 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Apple wireless earbuds charging case',
  },
  {
    name: 'Xbox Wireless Controller',
    aliases: [
      'xbox controller',
      'xbox series x controller',
      'xbox one controller',
      'xbox wireless controller',
      'xbox gamepad',
      'xbox',
      'game controller',
      'controllers',
    ],
    dimensions: { width: 155.0, depth: 108.0, height: 63.0 },
    confidence: 'verified' as const,
    clearanceMm: 3.0,
    sourceNote: 'Xbox Series X/S standard gamepad',
  },
  {
    name: 'PlayStation 5 DualSense Controller',
    aliases: ['ps5 controller', 'dualsense', 'playstation 5 controller', 'ps5 gamepad', 'dualsense controller', 'ps5'],
    dimensions: { width: 160.0, depth: 106.0, height: 66.0 },
    confidence: 'verified' as const,
    clearanceMm: 3.0,
    sourceNote: 'Sony PlayStation 5 DualSense controller',
  },
  {
    name: 'Stanley Quencher 40 oz Tumbler',
    aliases: [
      'stanley tumbler',
      'stanley cup',
      'stanley 40 oz',
      'stanley 40oz',
      '40 oz stanley',
      '40oz stanley',
      'stanley quencher',
      'stanley',
      'tumbler',
    ],
    dimensions: { width: 100.0, depth: 100.0, height: 260.0, diameter: 78.0 },
    confidence: 'verified' as const,
    clearanceMm: 2.5,
    sourceNote: '40 oz insulated tumbler with 78mm base diameter',
  },
  {
    name: 'Milwaukee M18 RedLithium Battery',
    aliases: [
      'milwaukee m18',
      'm18 battery',
      'milwaukee battery',
      'milwaukee m18 battery',
      'm18 redlithium',
      'm18',
    ],
    dimensions: { width: 78.0, depth: 120.0, height: 68.0 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Milwaukee M18 tool slide battery pack',
  },
  {
    name: 'DeWalt 20V MAX Battery',
    aliases: ['dewalt battery', 'dewalt 20v', 'dewalt 20v max', 'dewalt'],
    dimensions: { width: 75.0, depth: 115.0, height: 65.0 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'DeWalt 20V slide tool battery pack',
  },
  {
    name: 'Makita 18V LXT Battery',
    aliases: ['makita battery', 'makita 18v', 'makita lxt', 'makita'],
    dimensions: { width: 72.0, depth: 114.0, height: 62.0 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Makita 18V LXT slide battery pack',
  },
  {
    name: 'Yeti Rambler Tumbler / Bottle',
    aliases: [
      'yeti bottle',
      'yeti tumbler',
      'yeti rambler',
      'yeti cup',
      'yeti 26 oz',
      'yeti 36 oz',
      'yeti',
    ],
    dimensions: { width: 86.0, depth: 86.0, height: 240.0, diameter: 86.0 },
    confidence: 'verified' as const,
    clearanceMm: 2.0,
    sourceNote: 'Yeti insulated drinkware (86mm base diameter)',
  },
  {
    name: 'Standard 12 oz Aluminum Soda Can',
    aliases: ['soda can', '12 oz can', 'beer can', 'aluminum can', 'can holder'],
    dimensions: { width: 66.0, depth: 66.0, height: 122.0, diameter: 66.0 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Standard 12 fl oz beverage can (Ø66.0 mm)',
  },
  {
    name: 'Slim 12 oz Beverage Can',
    aliases: ['slim can', 'skinny can', 'white claw can', 'red bull can', 'slim 12 oz'],
    dimensions: { width: 58.0, depth: 58.0, height: 155.0, diameter: 58.0 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Slim 12 fl oz beverage can (Ø58.0 mm)',
  },
  {
    name: 'Standard Coffee Mug',
    aliases: ['coffee mug', 'mug', 'tea cup', 'coffee cup'],
    dimensions: { width: 84.0, depth: 120.0, height: 95.0, diameter: 84.0 },
    confidence: 'verified' as const,
    clearanceMm: 2.5,
    sourceNote: 'Standard ceramic mug with 35mm handle clearance',
  },
  {
    name: 'Standard Pencils & Pens',
    aliases: ['pencil', 'pencils', 'pen', 'pens', 'marker', 'markers'],
    dimensions: { width: 8.5, depth: 8.5, height: 175.0, diameter: 8.5 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Standard hex or round writing instruments (Ø8.5 - 10.0 mm)',
  },
  {
    name: 'Credit Card / ID Badge',
    aliases: ['credit card', 'credit cards', 'business card', 'id card', 'wallet card'],
    dimensions: { width: 85.6, depth: 53.98, height: 0.8 },
    confidence: 'verified' as const,
    clearanceMm: 1.2,
    sourceNote: 'ISO/IEC 7810 ID-1 standard card format',
  },
  {
    name: 'USB-C Cable & Connector',
    aliases: ['usb-c', 'usb c', 'usbc', 'charging cable', 'type c', 'usb cable'],
    dimensions: { width: 12.5, depth: 6.5, height: 25.0, diameter: 4.5 },
    confidence: 'verified' as const,
    clearanceMm: 1.0,
    sourceNote: 'Standard USB-C molded connector head and 4.5mm cable relief',
  },
  {
    name: 'Standard Toothbrush',
    aliases: ['toothbrush', 'tooth brush', 'electric toothbrush', 'oral-b'],
    dimensions: { width: 16.0, depth: 16.0, height: 190.0, diameter: 16.0 },
    confidence: 'verified' as const,
    clearanceMm: 2.0,
    sourceNote: 'Standard manual/electric toothbrush handle',
  },
  {
    name: 'Nintendo Switch Game Cartridge',
    aliases: ['switch cartridge', 'switch game', 'nintendo switch game', 'switch card'],
    dimensions: { width: 31.0, depth: 3.0, height: 21.0 },
    confidence: 'verified' as const,
    clearanceMm: 0.8,
    sourceNote: 'Official Nintendo Switch media cartridge',
  },
  {
    name: 'GoPro Hero Action Camera',
    aliases: ['gopro camera', 'gopro hero', 'gopro mount', 'gopro 11', 'gopro 12', 'gopro 10', 'gopro'],
    dimensions: { width: 71.8, depth: 33.6, height: 50.8 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Standard GoPro Hero action camera body',
  },
  {
    name: '2-Inch Schedule 40 PVC Pipe',
    aliases: ['2 inch pvc', '2" pvc', '2in pvc', '2-inch pipe', '2" pipe', '2 inch pipe'],
    dimensions: { width: 60.3, depth: 60.3, height: 100.0, diameter: 60.3 },
    confidence: 'verified' as const,
    clearanceMm: 1.0,
    sourceNote: 'Standard 2" Sch 40 PVC (Outer Diameter: 60.3 mm)',
  },
  {
    name: '18650 Li-ion Battery Cell',
    aliases: ['18650', '18650 battery', '18650 cell', 'vape battery'],
    dimensions: { width: 18.4, depth: 18.4, height: 65.0, diameter: 18.4 },
    confidence: 'verified' as const,
    clearanceMm: 0.6,
    sourceNote: 'Standard 18.4mm × 65.0mm cylindrical rechargeable cell',
  },
  {
    name: 'AA Battery',
    aliases: ['aa battery', 'double a battery', 'aa batteries', 'aa cell'],
    dimensions: { width: 14.5, depth: 14.5, height: 50.5, diameter: 14.5 },
    confidence: 'verified' as const,
    clearanceMm: 0.5,
    sourceNote: 'Standard 14.5mm × 50.5mm cylindrical cell',
  },
  {
    name: 'AAA Battery',
    aliases: ['aaa battery', 'triple a battery', 'aaa batteries', 'aaa cell'],
    dimensions: { width: 10.5, depth: 10.5, height: 44.5, diameter: 10.5 },
    confidence: 'verified' as const,
    clearanceMm: 0.5,
    sourceNote: 'Standard 10.5mm × 44.5mm cylindrical cell',
  },
];

function matchKnownReference(prompt: string) {
  const p = prompt.toLowerCase();
  for (const obj of SERVER_KNOWN_REFERENCE_OBJECTS) {
    if (obj.aliases.some((alias) => p.includes(alias))) {
      return {
        name: obj.name,
        dimensions: { ...obj.dimensions },
        confidence: obj.confidence,
        clearanceMm: obj.clearanceMm,
        sourceNote: obj.sourceNote,
      };
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// Intent-Based Prompt Classifier & Sanitizer
// ---------------------------------------------------------------------------
export function classifyPromptIntent(
  prompt: string,
  parsedObj?: any
): {
  classification: 'parametric' | 'organic' | 'hybrid';
  confidence: number;
  primaryObject: string;
  referenceObject: string | null;
  functionalRequirements: string[];
  decorativeRequirements: string[];
  sculpturalRequirements: string[];
  reason: string;
} {
  const p = prompt.toLowerCase();

  // 1. Identify primary manufactured functional object
  const functionalKeywords = [
    'soap dish',
    'soapdish',
    'dish',
    'tray',
    'holder',
    'stand',
    'mount',
    'bracket',
    'organizer',
    'enclosure',
    'box',
    'adapter',
    'spacer',
    'clamp',
    'shelf',
    'hook',
    'cup holder',
    'cupholder',
    'phone stand',
    'battery holder',
    'controller holder',
    'tool holder',
    'wall mount',
    'container',
    'drawer organizer',
    'cable guide',
    'pipe fitting',
    'fitting',
    'cover',
    'lid',
    'rack',
    'gear knob',
    'shift knob',
    'knob',
    'gear',
    'case',
    'bin',
    'jig',
    'fixture',
    'caddy',
    'dock',
    'coaster',
    'riser',
    'funnel',
    'clip',
    'handle',
    'spool',
    'wheel',
    'hinge',
    'latch',
    'catch',
    'washer',
    'bushing',
    'flange',
    'plug',
    'cap',
    'plate',
  ];

  let primaryObject = parsedObj?.primaryObject || '';
  if (!primaryObject) {
    for (const kw of functionalKeywords) {
      if (p.includes(kw)) {
        primaryObject = kw;
        break;
      }
    }
    if (!primaryObject) {
      if (/(?:figurine|statue|sculpture|bust|miniature)/i.test(p)) {
        primaryObject = 'sculpture / figurine';
      } else {
        primaryObject = prompt.slice(0, 30);
      }
    }
  }

  // 2. Identify reference object
  const knownRef = matchKnownReference(prompt);
  let referenceName = knownRef ? knownRef.name : null;
  if (!referenceName) {
    const forMatch = prompt.match(/(?:for|fitted for|fits?|holds?|holding|made for)\s+(?:a\s+|an\s+|the\s+)?([A-Za-z0-9\s\.\-]+?)(?:with|having|that|and|$|\.)/i);
    if (forMatch && forMatch[1]) {
      referenceName = forMatch[1].trim();
    }
  }

  // 3. Functional requirements extraction
  const functionalRequirements: string[] = [];
  if (/soap/i.test(p)) functionalRequirements.push('Hold soap bar securely');
  if (/drain|drainage|slot|hole/i.test(p)) functionalRequirements.push('Drainage slots/holes');
  if (/rib|airflow|raised/i.test(p)) functionalRequirements.push('Raised airflow drying ribs');
  if (/wall|mount|screw/i.test(p)) functionalRequirements.push('Wall mounting support');
  if (/cable|wire|pass/i.test(p)) functionalRequirements.push('Cable pass-through');
  if (/m\d|thread|insert|clamp/i.test(p)) functionalRequirements.push('Precision mechanical interface/thread');
  if (functionalRequirements.length === 0) functionalRequirements.push('Functional mechanical utility');

  // 4. Decorative requirements extraction
  const decorativeRequirements: string[] = [];
  if (/recess|emboss|text|name|word|font|dr\.?\s*squatch/i.test(p)) {
    decorativeRequirements.push('Recessed or embossed text/logo feature');
  }
  if (/footprint|silhouette|icon|pattern|hex|hexagon|ribs|curved|round/i.test(p)) {
    decorativeRequirements.push('Geometric or decorative surface styling');
  }
  if (decorativeRequirements.length === 0) decorativeRequirements.push('none');

  // 5. Sculptural requirements test
  // True sculptural request requires the body itself to be a realistic anatomical/organic sculpt
  const hasRealisticSculptBody =
    /(?:realistic|detailed|anatomical)\s+(?:dragon|sasquatch|skull|bust|statue|figurine|dog|animal|monster|hand|head|creature|face|body)/i.test(
      p
    ) ||
    /shaped\s+like\s+(?:a\s+)?(?:realistic|detailed)\s+(?:dragon|sasquatch|skull|hand|animal|monster)/i.test(
      p
    ) ||
    /(?:statue\s+of|sculpture\s+of|bust\s+of|figurine\s+of)\s+(?:a\s+)?(?:sasquatch|dragon|dog|animal|skull|monster|character|head|person)/i.test(
      p
    ) ||
    /make\s+a\s+(?:realistic\s+)?(?:dragon\s+figurine|sasquatch\s+figurine|dog\s+figurine|skull|statue\s+of|monster\s+miniature)/i.test(
      p
    );

  const isPureStatueOrFigurine =
    /(?:realistic\s+)?(?:dragon\s+figurine|sasquatch\s+figurine|dog\s+figurine|human\s+head\s+sculpture|anatomical\s+skull|monster\s+miniature|realistic\s+skull\b|statue\s+of\s+a\s+sasquatch)/i.test(
      p
    ) && !/(?:gear\s+knob|knob|dish|holder|mount|bracket|clamp|box|stand)/i.test(p);

  const hasPrecisionMechanicalInterface =
    /(?:m[3-8]|m12|thread|insert|mounting\s+hole|clamp\s+for|pipe\s+clamp|screw\s+hole|bolt\s+circle|flange)/i.test(
      p
    ) ||
    /(?:holding|holds)\s+(?:the\s+)?(?:soap|controller|battery|bottle|cup)/i.test(p);

  // Intent classification decision:
  // Condition 1: Pure sculpture / figurine -> ORGANIC
  if (isPureStatueOrFigurine) {
    return {
      classification: 'organic',
      confidence: 0.96,
      primaryObject: primaryObject || 'sculpture figurine',
      referenceObject: referenceName,
      functionalRequirements: ['Display / Aesthetic model'],
      decorativeRequirements,
      sculpturalRequirements: ['Freeform organic anatomical geometry'],
      reason: 'Primary requested object is a freeform sculpture/figurine with no precision mechanical assembly.',
    };
  }

  // Condition 2: Explicitly requires substantial realistic sculpture AND precision mechanical mounting -> HYBRID
  if (
    hasRealisticSculptBody &&
    hasPrecisionMechanicalInterface &&
    (p.includes('hand') ||
      p.includes('shaped like') ||
      p.includes('dragon-shaped') ||
      p.includes('skull-shaped') ||
      p.includes('eagle sculpture that mounts'))
  ) {
    return {
      classification: 'hybrid',
      confidence: 0.92,
      primaryObject: primaryObject || 'hybrid object',
      referenceObject: referenceName,
      functionalRequirements,
      decorativeRequirements,
      sculpturalRequirements: ['Substantial freeform anatomical sculpture feature'],
      reason: 'Model combines substantial freeform sculpture geometry with precision mechanical mounting/fit requirements.',
    };
  }

  // Condition 3: Default is PARAMETRIC for functional manufactured objects
  return {
    classification: 'parametric',
    confidence: 0.98,
    primaryObject: primaryObject || 'functional part',
    referenceObject: referenceName,
    functionalRequirements,
    decorativeRequirements,
    sculpturalRequirements: ['none'],
    reason: 'Functional manufactured part designed for fit and utility. No freeform sculpture required.',
  };
}

async function extractRequirements(prompt: string, ai: GoogleGenAI, referenceImages: ProjectReferenceImage[] = []): Promise<any> {
  const startTime = Date.now();
  const knownRef = matchKnownReference(prompt);
  const baselineClassification = classifyPromptIntent(prompt);

  const systemInstruction = `You are a world-class industrial product designer, mechanical specification engineer, and CAD analyst.
Analyze the user's 3D print request and extract a strict, structured JSON specification with a complete DESIGN PLAN.

# CRITICAL CLASSIFICATION & INTENT ARCHITECTURE:
Before deciding the classification engine, YOU MUST EXTRACT:
1. "primaryObject": The actual physical item being manufactured (e.g. "soap dish", "tray", "holder", "stand", "mount", "bracket", "organizer", "enclosure", "box", "adapter", "spacer", "clamp", "shelf", "hook", "cup holder", "phone stand", "battery holder", "controller holder", "tool holder", "wall mount", "container", "drawer organizer", "cable guide", "pipe fitting", "cover", "lid", "rack", "knob", "statue", "figurine").
2. "referenceObject": Name and dimensions of any reference product being fitted or held (e.g. "Dr. Squatch soap bar", "Xbox controller", "Milwaukee M18 battery", "Stanley 40 oz tumbler", "iPhone 17 Pro Max", "Yeti bottle", "GoPro", "AA battery", "soda can", "toothbrush").
3. "inferredCategory": One of ["PARAMETRIC_FUNCTIONAL", "PARAMETRIC_DECORATIVE", "HYBRID_FUNCTIONAL", "ORGANIC_DECORATIVE", "ENCLOSURE", "HOLDER_OR_MOUNT", "CONTAINER_OR_TRAY", "THREAD_OR_MECHANICAL_PART"].
4. "mountingStyle": One of ["freestanding", "desktop / tabletop", "wall mount", "under-desk mount", "snap-fit / clip", "drop-in insert", "DIN rail"].
5. "designPlan": A comprehensive design strategy including:
   - "function": Specific physical and practical purpose (e.g. "Elevate soap, drain water, prevent softening").
   - "targetUseCase": Where and how it is used.
   - "keyFeatures": 3-6 explicit and inferred geometric features (e.g. ["Drying ribs", "Drainage slots", "Perimeter drip tray", "Angled backrest", "USB cable slot"]).
   - "assumptions": Inferred engineering assumptions (e.g. ["Assumed 3.2mm wall thickness", "Clearance +2.0mm around reference item", "45° chamfered transitions for no-support printing"]).
   - "generationStrategy": Detailed step-by-step CSG modeling approach.

# CLASSIFICATION RULES:
1. PARAMETRIC (DEFAULT FOR FUNCTIONAL OBJECTS):
   - A PRODUCT NAME, BRAND NAME, REFERENCE OBJECT, OR OBJECT BEING FITTED DOES NOT MAKE A DESIGN ORGANIC OR HYBRID.
   - Example: "Make me a soap dish made for a Dr. Squatch bar of soap." -> PARAMETRIC. Dr. Squatch is the reference object being fitted. The requested model is a soap dish.
   - Example: "Wall mount for an Xbox controller." -> PARAMETRIC.
   - Example: "Holder for a Milwaukee M18 battery." -> PARAMETRIC.
   - Example: "Cup holder for a Stanley 40 oz tumbler." -> PARAMETRIC.
   - Example: "Stand for an iPhone 17 Pro Max." -> PARAMETRIC.
   - Example: "Make a soap dish with DR. SQUATCH recessed into the front." -> PARAMETRIC.
   - Example: "Make a soap dish with a simple sasquatch-footprint cutout." -> PARAMETRIC.
   - Whenever the primary requested object is a functional manufactured part, it MUST be PARAMETRIC.

2. ORGANIC (SCULPTURES ONLY):
   - Classify as ORGANIC ONLY when the primary requested object itself requires true freeform/sculptural geometry with NO precision mechanical interfaces (e.g. "Make a realistic dragon figurine", "Make a statue of a sasquatch").

3. HYBRID (EXTREMELY RARE):
   - Classify as HYBRID ONLY when the design explicitly combines substantial anatomical sculpt with precision mechanical mounting.

CORE INDUSTRIAL DESIGN PRINCIPLES:
1. DESIGN FOR FIT & CLEARANCE:
   - If user names a physical object being fitted, identify it under "referenceObject" with appropriate clearance (+1.5 mm to +3.0 mm).
2. UNIT CONVERSION MANDATE:
   - All measurements strictly in millimeters (1 inch = 25.4 mm).
3. SUGGESTED IMPROVEMENTS:
   - Provide 2-4 concrete, clickable improvement suggestions tailored to this specific object.

REFERENCE IMAGE EVIDENCE RULES:
- When reference images are provided, inspect the actual pixels as visual design evidence.
- Evidence priority: explicit user text dimensions > explicit measured notes on reference images > visible image geometry > engineering inference/defaults.
- Images may establish shape, relative proportions, visible feature count/placement, component count, symmetry, interfaces, and likely multi-piece structure.
- Do NOT invent exact verified millimeter dimensions from an unscaled photograph. Mark unseen or unmeasured dimensions as inferred/unknown.

Output ONLY valid JSON with this schema:
{
  "objectName": "Short descriptive title (e.g. Dr. Squatch Raised Soap Dish)",
  "primaryObject": "soap dish",
  "classification": "parametric" | "organic" | "hybrid",
  "classificationConfidence": number,
  "classificationReason": "Functional manufactured soap dish designed to fit reference product.",
  "inferredCategory": "CONTAINER_OR_TRAY" | "HOLDER_OR_MOUNT" | "PARAMETRIC_FUNCTIONAL" | "ENCLOSURE" | "THREAD_OR_MECHANICAL_PART",
  "mountingStyle": "desktop / tabletop" | "wall mount" | "under-desk mount" | "freestanding",
  "isOrganicOnly": boolean,
  "functionalRequirements": ["hold Dr. Squatch soap bar", "drainage slots", "raised airflow drying ribs", "stable base"],
  "decorativeRequirements": ["none"],
  "sculpturalRequirements": ["none"],
  "units": "mm" | "cm" | "inches" | "feet" | "mixed",
  "overallDimensions": {
    "width": number | null,
    "depth": number | null,
    "height": number | null,
    "diameter": number | null,
    "length": number | null,
    "rawInput": "Original raw dimensional text"
  },
  "wallThicknessMm": number | null,
  "referenceObject": {
    "name": "Name of object being fitted",
    "dimensions": { "width": number, "depth": number, "height": number, "diameter": number | null },
    "confidence": "verified" | "estimated",
    "clearanceMm": number,
    "sourceNote": "Source or reasoning for dimensions"
  } | null,
  "designPlan": {
    "primaryObject": "Soap Dish",
    "function": "Elevate soap bar, allow water drainage, and facilitate airflow drying",
    "targetUseCase": "Bathroom vanity / shower counter",
    "inferredCategory": "CONTAINER_OR_TRAY",
    "inferredDimensions": { "width": 88, "depth": 88, "height": 22 },
    "criticalDimensions": ["Inner cavity clearance +2.0mm around Dr. Squatch Soap Bar"],
    "mountingStyle": "desktop / tabletop",
    "structuralRequirements": ["3.2mm wall thickness", "Flat base at Z=0"],
    "ergonomicRequirements": ["Rounded outer corners with 6mm radius"],
    "aestheticRequirements": ["Clean geometric lines"],
    "printConstraints": ["Orient flat on build plate at Z=0"],
    "confidenceScore": 0.96,
    "assumptions": ["Assumed 3.2 mm wall thickness for rigidity", "Added 5 drainage slots (4 mm wide)", "Raised drying ribs by 3.5 mm"],
    "missingCriticalInfo": [],
    "generationStrategy": "Parametric Tray with Drainage Grate & Ribs",
    "keyFeatures": ["Raised drainage ribs", "Water drain slots", "Perimeter drip catch tray", "Filleted ergonomic rim"]
  },
  "explicitRequirements": ["User explicitly asked for ..."],
  "designDecisions": ["Assumed 3.2 mm wall thickness for rigidity", "Added 5 drainage slots (4 mm wide)", "Raised drying platform by 4 mm for airflow"],
  "suggestedImprovements": ["Add counterbore mounting holes", "Add drip tray catch basin", "Round top rim"],
  "features": ["Feature 1", "Feature 2"],
  "quantities": {},
  "spatialArrangements": [],
  "fastenersOrHardware": [],
  "tolerancesOrClearances": [],
  "printConsiderations": ["Print flat on base at Z=0"],
  "warnings": []
}`;

  try {
    const designContents: any[] = [{
      text: `Extract technical product design requirements and complete design plan for: "${prompt}".
${knownRef ? `[HINT: Matched known verified reference item: ${JSON.stringify(knownRef)}]` : ''}`,
    }];
    appendReferenceImagesToContents(designContents, referenceImages);

    const geminiRes = await callGeminiWithResilience(ai, {
      purpose: 'design_reasoning',
      contents: designContents,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(geminiRes.text);

    // Apply deterministic classifier sanity validation
    const verifiedIntent = classifyPromptIntent(prompt, parsed);

    // Guard against false positive organic/hybrid classifications for functional objects
    if (verifiedIntent.classification === 'parametric' && parsed.classification !== 'parametric') {
      parsed.classification = 'parametric';
      parsed.isOrganicOnly = false;
      parsed.classificationReason = verifiedIntent.reason;
      parsed.classificationConfidence = verifiedIntent.confidence;
    } else {
      parsed.classification = parsed.classification || verifiedIntent.classification;
      parsed.classificationConfidence = parsed.classificationConfidence || verifiedIntent.confidence;
      parsed.classificationReason = parsed.classificationReason || verifiedIntent.reason;
    }

    parsed.primaryObject = parsed.primaryObject || verifiedIntent.primaryObject;
    parsed.functionalRequirements = parsed.functionalRequirements || verifiedIntent.functionalRequirements;
    parsed.decorativeRequirements = parsed.decorativeRequirements || verifiedIntent.decorativeRequirements;
    parsed.sculpturalRequirements = parsed.sculpturalRequirements || verifiedIntent.sculpturalRequirements;

    if (!parsed.referenceObject && knownRef) {
      parsed.referenceObject = knownRef;
    }
    if (parsed.referenceObject && knownRef && knownRef.name.toLowerCase() === parsed.referenceObject.name?.toLowerCase()) {
      parsed.referenceObject.confidence = 'verified';
    }

    // Ensure designPlan is populated
    if (!parsed.designPlan) {
      parsed.designPlan = {
        primaryObject: parsed.primaryObject || 'functional part',
        function: 'Functional manufactured 3D print model',
        targetUseCase: 'General everyday utility',
        inferredCategory: parsed.inferredCategory || 'PARAMETRIC_FUNCTIONAL',
        referenceObject: parsed.referenceObject || null,
        inferredDimensions: {
          width: parsed.overallDimensions?.width || 80,
          depth: parsed.overallDimensions?.depth || 80,
          height: parsed.overallDimensions?.height || 25,
        },
        criticalDimensions: parsed.referenceObject ? [`Fit clearance around ${parsed.referenceObject.name}`] : ['Wall thickness 3.0mm'],
        mountingStyle: parsed.mountingStyle || 'freestanding',
        structuralRequirements: ['Flat base at Z=0 for bed adhesion', 'Wall thickness 3.0mm'],
        ergonomicRequirements: ['Rounded outer corners'],
        aestheticRequirements: ['Clean CAD styling'],
        printConstraints: ['No unsupported overhangs steeper than 45°'],
        confidenceScore: 0.95,
        assumptions: parsed.designDecisions || ['Assumed standard 3.0mm wall thickness'],
        missingCriticalInfo: [],
        generationStrategy: 'Parametric CSG Construction',
        keyFeatures: parsed.features || ['Parametric functional geometry'],
      };
    }

    const modelsUsed = Array.from(new Set(geminiRes.requestRecords.map((r: any) => r.model)));
    const aiMetadata = {
      modelUsed: geminiRes.model,
      modelsUsed,
      totalModelCalls: geminiRes.attempts,
      durationMs: geminiRes.durationMs,
      requestRecords: geminiRes.requestRecords,
    };

    return { requirements: parsed, aiMetadata };
  } catch (err: any) {
    console.warn('Requirements extraction parse error, using conservative fallback extractor:', err);
    const isInches = /inch|in\b|"/i.test(prompt);
    const unitScale = isInches ? 25.4 : 1;

    const widthMatch = prompt.match(/(?:width|wide|w|length|long|l)[:\s]*(\d+(?:\.\d+)?)\s*(?:mm|cm|in|inch|")?/i);
    const heightMatch = prompt.match(/(?:height|tall|h|thickness|thick)[:\s]*(\d+(?:\.\d+)?)\s*(?:mm|cm|in|inch|")?/i);
    const depthMatch = prompt.match(/(?:depth|deep|d)[:\s]*(\d+(?:\.\d+)?)\s*(?:mm|cm|in|inch|")?/i);
    const dim3Match = prompt.match(/(\d+(?:\.\d+)?)\s*(?:mm|cm|in|inch|")?\s*[x×*]\s*(\d+(?:\.\d+)?)\s*(?:mm|cm|in|inch|")?\s*(?:[x×*]\s*(\d+(?:\.\d+)?))?/i);

    let w: number | null = null;
    let d: number | null = null;
    let h: number | null = null;

    if (dim3Match) {
      w = Number((parseFloat(dim3Match[1]) * unitScale).toFixed(2));
      d = Number((parseFloat(dim3Match[2]) * unitScale).toFixed(2));
      if (dim3Match[3]) {
        h = Number((parseFloat(dim3Match[3]) * unitScale).toFixed(2));
      }
    } else {
      if (widthMatch) w = Number((parseFloat(widthMatch[1]) * unitScale).toFixed(2));
      if (depthMatch) d = Number((parseFloat(depthMatch[1]) * unitScale).toFixed(2));
      if (heightMatch) h = Number((parseFloat(heightMatch[1]) * unitScale).toFixed(2));
    }

    const intent = baselineClassification;

    const fallbackReqs = {
      objectName: intent.primaryObject ? `${intent.primaryObject.toUpperCase()}` : prompt.slice(0, 35),
      primaryObject: intent.primaryObject,
      classification: intent.classification,
      classificationConfidence: intent.confidence,
      classificationReason: intent.reason,
      inferredCategory: 'PARAMETRIC_FUNCTIONAL',
      mountingStyle: 'freestanding',
      functionalRequirements: intent.functionalRequirements,
      decorativeRequirements: intent.decorativeRequirements,
      sculpturalRequirements: intent.sculpturalRequirements,
      isOrganicOnly: intent.classification === 'organic',
      units: isInches ? 'inches' : 'mm',
      overallDimensions: {
        width: w,
        depth: d,
        height: h,
        rawInput: prompt,
      },
      wallThicknessMm: 3.0,
      referenceObject: knownRef || (intent.referenceObject ? {
        name: intent.referenceObject,
        dimensions: { width: 80, depth: 80, height: 25 },
        confidence: 'estimated',
        clearanceMm: 2.0,
        sourceNote: 'Derived from user reference',
      } : null),
      designPlan: {
        primaryObject: intent.primaryObject || 'functional part',
        function: 'Functional manufactured 3D print model',
        targetUseCase: 'General everyday utility',
        inferredCategory: 'PARAMETRIC_FUNCTIONAL',
        referenceObject: knownRef || null,
        inferredDimensions: { width: w || 80, depth: d || 80, height: h || 25 },
        criticalDimensions: knownRef ? [`Fit clearance around ${knownRef.name}`] : ['Wall thickness 3.0mm'],
        mountingStyle: 'freestanding',
        structuralRequirements: ['Flat base at Z=0 for bed adhesion', 'Wall thickness 3.0mm'],
        ergonomicRequirements: ['Rounded outer corners'],
        aestheticRequirements: ['Clean CAD styling'],
        printConstraints: ['No unsupported overhangs steeper than 45°'],
        confidenceScore: 0.92,
        assumptions: ['Selected durable 3.0 mm wall thickness', 'Standard 2.0 mm fit clearance around reference boundaries'],
        missingCriticalInfo: [],
        generationStrategy: 'Parametric CSG Construction',
        keyFeatures: ['Parametric mechanical model based on: ' + prompt],
      },
      explicitRequirements: [prompt],
      designDecisions: [
        'Selected durable 3.0 mm wall thickness',
        'Standard 2.0 mm fit clearance around reference boundaries',
        'Optimized base geometry for flat build-plate adhesion at Z=0',
      ],
      suggestedImprovements: [
        'Round outer corners by 5mm',
        'Add drainage slots',
        'Add screw mounting holes',
      ],
      unspecifiedProperties: [
        ...(w === null ? ['Width not specified'] : []),
        ...(d === null ? ['Depth not specified'] : []),
        ...(h === null ? ['Height not specified'] : []),
      ],
      features: ['Parametric mechanical model based on: ' + prompt],
      quantities: {},
      spatialArrangements: [],
      fastenersOrHardware: [],
      tolerancesOrClearances: [],
      printConsiderations: ['Ensure base is flat at Z=0 for bed adhesion'],
      warnings: [],
    };

    return {
      requirements: fallbackReqs,
      fallbackUsed: 'deterministic',
      aiMetadata: {
        modelUsed: getLastSuccessfulModel(err?.requestRecords || []) || undefined,
        modelsUsed: err?.modelsUsed || [],
        totalModelCalls: err?.totalModelCalls || (err?.requestRecords?.length ?? 0),
        durationMs: Date.now() - startTime,
        requestRecords: err?.requestRecords || [],
      },
    };
  }
}

// ---------------------------------------------------------------------------
// Step 2 & 3: CAD Generation & Self-Repair Pass (Throws on Failure)
// ---------------------------------------------------------------------------
export interface GenerateAndRepairJscadOptions {
  prompt: string;
  requirements: ExtractedRequirements | DesignSpecification | Record<string, unknown>;
  ai: GoogleGenAI;
  isRevision?: boolean;
  previousCode?: string;
  revisionContext?: RevisionContextPayload;
  mode?: GenerationMode | string;
  featureModel?: SemanticFeatureModel;
  designSpecification?: DesignSpecification;
  designChecklist?: DesignCheck[];
  referenceImages?: ProjectReferenceImage[];
}

async function generateAndRepairJscad(options: GenerateAndRepairJscadOptions): Promise<{
  code: string;
  measurements: GeometryMeasurements;
  repairAttempts: number;
  requestRecords: AIRequestRecord[];
  modelsUsed: string[];
  totalModelCalls: number;
}> {
  const {
    prompt,
    requirements,
    ai,
    isRevision = false,
    previousCode = '',
    revisionContext,
    mode,
    featureModel,
    designSpecification,
    designChecklist,
    referenceImages,
  } = options;

  let refImagesContext = '';
  if (referenceImages && Array.isArray(referenceImages) && referenceImages.length > 0) {
    refImagesContext = `\nPROJECT REFERENCE PHOTOS & USER SPECIFICATIONS:\n` +
      referenceImages.map((img: any, idx: number) => {
        const title = img.name || img.label || `Photo ${idx + 1}`;
        const notes = img.notes ? ` (Notes: ${img.notes})` : '';
        return `- Reference Image [${title}]${notes}`;
      }).join('\n') + '\n';
  }

  const semanticFeatures =
    featureModel?.features ||
    revisionContext?.targetFeatureModel?.features ||
    revisionContext?.featureModel?.features;
  const builderDocs = getFeatureBuilderPromptDocs(semanticFeatures);

  const systemInstruction = `You are a world-class industrial product designer and mechanical CAD engineer writing @jscad/modeling (version 2.x) JavaScript for functional 3D printing.

AUTHORITATIVE PRODUCT DESIGN RULES:
1. DESIGN INTENT TRANSLATION:
   - Understand the functional purpose of the object:
     * Soap dishes: Outer tray, internal cavity with +2.0-3.0mm clearance around soap, elevated support ribs/slats (height 3-4mm), drainage slots/through-holes (3-5mm wide), filleted ergonomic corners.
     * Phone & Tablet stands: 65°-75° angled back support, 14mm thick front lip stop, central bottom USB cable pass-through slot (14mm wide), stable weighted foot.
     * Wall mounts & Brackets: Flange with counterbore/countersunk screw holes (M4/M5: 4.5mm hole, 8mm countersink), structural triangular gussets (4mm thick), support cradle lips.
     * Game controller holders & dual docks: Ergonomic dual cradle rests, trigger relief cutouts, weighted base or wall mount tab.
     * Battery holders (M18, DeWalt, Makita): Retention rails (1.5mm sliding tolerance), latch retention stop tab, mounting screw holes.
     * Cable organizers & Clips: Snapping C-channel (4.5mm bore, 0.8mm snap retention lip), lead-in funnel chamfer, flat mounting base.
     * Parts / Socket / Bit trays: Divided compartments, radiused bottom corners (easy small-part scoop), stackable outer lip rim.
     * Planters & Pots: Hollow inner soil pot, bottom drainage hole (6-8mm), integrated drip catch reservoir rim, flat base at Z=0.
     * Boxes & Enclosures: Stepped lid rebate / lip (0.35mm tolerance offset), snap catches or corner screw standoffs, cable ports.
     * Shift knobs & Threaded parts: Ergonomic palm contour, internal threaded socket / bore (10.5mm for M12 tap/insert), flat bottom seating shoulder.

2. TOP-LEVEL NAMED CONSTANTS:
   - Declare EVERY primary dimension and design parameter as a top-level numeric "const" in millimeters with a descriptive comment.
   - Example:
     const targetWidth = 84.0; // Overall width in mm
     const targetDepth = 84.0; // Overall depth in mm
     const dishHeight = 22.0; // Total height in mm
     const wallThickness = 3.2; // Wall thickness in mm
     const ribHeight = 4.0; // Raised drying rib height
     const drainageSlotWidth = 4.0; // Drainage slot width
   - These constants MUST be simple numeric literals (e.g. 84.0), NOT expressions, so they can be edited directly by users in the UI!

3. FEATURE WRAPPER FUNCTIONS & WORLD-SPACE SELECTION ABI:
   - For every planned feature (such as mounting holes, slots, ribs, bosses, cutouts), write a dedicated wrapper function:
     function kpFeature_<sanitizedFeatureId>() { ... }
   - SEMANTIC FEATURE SELECTION ABI (MANDATORY):
     Every kpFeature_<featureId>() wrapper MUST return its geometry already positioned and oriented in FINAL MODEL WORLD COORDINATES directly.
     Inside main(), you may boolean-combine feature wrappers (union, subtract, intersect) but you MUST NOT apply outer transformations around kpFeature_*() calls (e.g., do NOT do translate([x,y,z], kpFeature_foo()), rotate([...], kpFeature_bar()), scale(), center(), or align()).
     All spatial translation, rotation, and alignment belongs strictly INSIDE the feature wrapper function itself.
   - Example GOOD:
     function kpFeature_mounting_hole_left() {
       return createCountersinkHole(mountingHoleDiameter, mountingHoleHeadDiameter, plateThickness, 90, mountingHoleLeftX, mountingHoleLeftY, 0);
     }
     main():
       const hole = kpFeature_mounting_hole_left();
       return subtract(base, hole);
   - Call all feature wrapper functions from inside main() to assemble the solid geometry.
   - DO NOT re-declare or redefine reserved global builder functions (e.g. createThroughHole, createCountersinkHole, createCounterboreHole, createElongatedSlot, createCableOpening, createMountingBoss, createPCBStandoff, createReinforcingRib, createCornerGusset, createLinearHolePattern, createCircularHolePattern, createDrainageSlotPattern). They are already injected in the runtime environment!

4. CSG MODELING BEST PRACTICES:
   - Use subtract() to cut cavities, drainage slots, holes, and channels.
   - Use union() to combine outer shells, ribs, gussets, and alignment features.
   - Use roundedCuboid({ size: [x, y, z], roundRadius: r, segments: 24 }) or cuboid({ size: [x, y, z] }) for smooth, ergonomic products.
   - Use cylinder({ radius: r, height: h, segments: 36 }) for holes and circular geometry.

5. PRINTABILITY & BED ADHESION:
   - Position single-piece models with a flat bottom surface sitting directly at Z=0.
   - Minimum wall thickness: 1.6 mm (preferably 2.4 - 3.5 mm for durability).
   - Chamfer or round bottom edges slightly to prevent elephant foot without causing extreme overhangs.

6. MULTI-PART & MULTI-PIECE DESIGN RULES (MANDATORY):
   - When the requested design contains 2 or more independently printable physical pieces, use the MULTI-PIECE CAD ABI.
   - Create one stable part wrapper for each UNIQUE part type: function kpPart_<partId>() { ... }.
   - Create function getParts() returning objects with exactly: id, name, quantity, geometry.
   - Example:
       function kpPart_base() { return baseGeometry; }
       function kpPart_lid() { return lidGeometry; }
       function getParts() {
         return [
           { id: 'base', name: 'Base', quantity: 1, geometry: kpPart_base() },
           { id: 'lid', name: 'Lid', quantity: 1, geometry: kpPart_lid() }
         ];
       }
       function main() { return getParts().map((part) => part.geometry); }
   - Quantity is metadata for duplicate physical copies. For "one bracket and four spacers", define one spacer geometry with quantity: 4; do NOT return four coincident spacer solids from main().
   - Never boolean-union separate printable pieces unless the user explicitly asks for print-in-place.
   - Every unique part must independently be closed, manifold, watertight, and printable.
   - Mating clearances must use named editable constants (for example const lidClearance = 0.30) chosen for the intended fit; do not hide a universal magic clearance.
   - Stable part IDs and kpPart_<id>() names survive revisions unless the user explicitly changes assembly structure.
   - The STL exporter will place physical copies apart as disconnected shells for the user's slicer.

7. SECURITY & API STYLE:
   - Functional JSCAD V2 format: use translate([x, y, z], geom), rotate([rx, ry, rz], geom), subtract(base, ...cuts), union(...parts).
   - All geometric primitives and transforms are directly available in global scope.
   - Do NOT use import or require statements.
   - Do NOT access DOM, window, process, network, or file system.

8. FUNCTION SIGNATURE:
   - Single-piece: function main() { ... return solid; }
   - Multi-piece: kpPart_<id>() wrappers + getParts() + function main() { return getParts().map((part) => part.geometry); }.

${builderDocs}`;

  const requestRecords: AIRequestRecord[] = [];
  const modelsUsedSet = new Set<string>();
  let totalModelCalls = 0;

  const attachTelemetryAndRethrow = (err: any) => {
    err.requestRecords = requestRecords;
    err.modelsUsed = Array.from(modelsUsedSet);
    err.totalModelCalls = totalModelCalls;
    throw err;
  };

  // ---------------------------------------------------------------------------
  // Stage 1: Primary CAD Generation
  // ---------------------------------------------------------------------------
  let stage1Prompt = '';
  if (isRevision && previousCode) {
    let contextDetails = '';
    if (revisionContext) {
      if (revisionContext.requestedChanges && Array.isArray(revisionContext.requestedChanges) && revisionContext.requestedChanges.length > 0) {
        contextDetails += `\nEXPLICIT CHANGES TO APPLY:\n${revisionContext.requestedChanges.map((c: any) => `- ${c.feature}: ${c.change}${c.toValue ? ` (Target: ${c.toValue})` : ''}`).join('\n')}\n`;
      }
      if (revisionContext.preservedFeatures && Array.isArray(revisionContext.preservedFeatures) && revisionContext.preservedFeatures.length > 0) {
        contextDetails += `\nPRESERVED UNTOUCHED FEATURES (DO NOT REMOVE OR BREAK):\n${revisionContext.preservedFeatures.map((f: string) => `- ${f}`).join('\n')}\n`;
      }
      if (revisionContext.projectMemory?.importantDecisions && Array.isArray(revisionContext.projectMemory.importantDecisions) && revisionContext.projectMemory.importantDecisions.length > 0) {
        contextDetails += `\nPROJECT MEMORY & DESIGN CONSTRAINTS:\n${revisionContext.projectMemory.importantDecisions.map((d: string) => `- ${d}`).join('\n')}\n`;
      }
      if (revisionContext.recentConversation && Array.isArray(revisionContext.recentConversation) && revisionContext.recentConversation.length > 0) {
        contextDetails += `\nRECENT CONVERSATION CONTEXT:\n${revisionContext.recentConversation.slice(-5).map((m: any) => `${m.role}: ${m.content}`).join('\n')}\n`;
      }

      // Current Semantic Feature Model
      if (revisionContext.featureModel) {
        contextDetails += `
CURRENT SEMANTIC FEATURE MODEL (PRE-REVISION):
${JSON.stringify(revisionContext.featureModel, null, 2)}
`;
      }

      // Target Semantic Feature Model
      const targetModel = revisionContext.targetFeatureModel || featureModel || revisionContext.featureModel;
      if (targetModel) {
        contextDetails += `
TARGET SEMANTIC FEATURE MODEL AFTER REQUESTED CHANGE (AUTHORITATIVE FOR NEW VERSION):
${JSON.stringify(targetModel, null, 2)}

THIS TARGET SEMANTIC FEATURE MODEL IS AUTHORITATIVE FOR THIS REVISION.
The generated revised CAD must implement this target model.
`;
      }

      // Semantic Revision Operation
      if (revisionContext.semanticOperation) {
        contextDetails += `
SEMANTIC REVISION OPERATION:
${JSON.stringify(revisionContext.semanticOperation, null, 2)}

Instruction: Only the features/parameters named by this operation should change unless a dependent derived constraint requires another update.
`;
      }

      // Current Semantic Binding Validation
      if (revisionContext.bindingValidation) {
        contextDetails += `
CURRENT SEMANTIC BINDING VALIDATION:
${JSON.stringify(revisionContext.bindingValidation, null, 2)}
`;
      }

      // Locked Semantic Parameters with IDs, constants, and values
      const modelParams: FeatureParameter[] = (targetModel || revisionContext.featureModel)?.parameters || [];
      const lockedIds = revisionContext.lockedParameterIds || modelParams.filter((p) => p.locked).map((p) => p.id);
      if (lockedIds.length > 0) {
        const lockedDetails = lockedIds.map((id) => {
          const p = modelParams.find((param) => param.id === id);
          return `- Parameter ID: ${id} | Semantic Name: ${p?.name || p?.semanticName || id} | Constant: const ${p?.jscadConstantName || p?.name || id} | Value: ${p?.value !== undefined ? p.value : 'N/A'} ${p?.unit || 'mm'}`;
        });
        contextDetails += `
LOCKED SEMANTIC PARAMETERS:
${lockedDetails.join('\n')}

Instruction: DO NOT CHANGE THESE VALUES unless the SemanticRevisionOperation explicitly represents an intentional lock override.
`;
      }

      // Code Binding ABI & Preservation
      if (revisionContext.featureModel?.codeBindings && Object.keys(revisionContext.featureModel.codeBindings).length > 0) {
        contextDetails += `
CODE BINDING ABI TO PRESERVE:
${JSON.stringify(revisionContext.featureModel.codeBindings, null, 2)}

Instruction: Do not rename bound constants. Do not rename preserved feature wrappers.
`;
      }
    }

    stage1Prompt = `REVISION TASK:
Original Code:
\`\`\`js
${previousCode}
\`\`\`

User Revision Request: "${prompt}"
${contextDetails}
Updated Technical Requirements:
${JSON.stringify(requirements, null, 2)}

INSTRUCTIONS:
1. MODIFY ONLY the features and parameters requested by the revision.
2. For every SemanticFeature preserved from the current model, reuse its existing code bindings (wrapper function name kpFeature_<featureId> and parameter constant names). Only added or modified features should receive new or updated bindings.
3. PRESERVE WORLD-SPACE WRAPPER ABI: Every kpFeature_<featureId>() must return geometry positioned in final model coordinates. DO NOT introduce outer transforms (translate, rotate, scale, center, align) around semantic wrappers in main().
4. DO NOT recreate or regenerate the whole model from scratch when the change can be expressed by modifying existing semantic parameters or features.
5. DO NOT violate projectMemory constraints or modify locked parameters.
6. Maintain top-level editable numeric constants.
7. If the existing CAD contains getParts() or kpPart_ wrappers, PRESERVE THE MULTI-PIECE ABI: keep unchanged part IDs, kpPart_<id>() names, quantities, getParts() metadata, and separate solids unless the user explicitly changes assembly structure. Never repair/revise by fusing printable pieces.
8. Return ONLY executable JavaScript.`;
  } else {
    let semanticContext = '';
    if (featureModel && Array.isArray(featureModel.features) && featureModel.features.length > 0) {
      semanticContext += `
AUTHORITATIVE SEMANTIC FEATURE MODEL:
${JSON.stringify(featureModel, null, 2)}

SEMANTIC IMPLEMENTATION RULES:
1. Implement every critical and important feature from the semantic model.
2. Preserve exact feature IDs: for each feature, create a dedicated wrapper function named \`kpFeature_<featureId>()\`.
3. WORLD-SPACE SELECTION ABI: Every \`kpFeature_<featureId>()\` must return its geometry already positioned in FINAL WORLD COORDINATES. Do NOT wrap \`kpFeature_*()\` calls in outer \`translate\`, \`rotate\`, \`scale\`, \`center\`, or \`align\` inside \`main()\`.
4. Preserve exact parameter constant names: declare top-level consts with the exact \`jscadConstantName\` (or parameter name) and required numeric values.
5. Preserve locked values: do not change or substitute locked parameters.
6. Use registered deterministic builders (such as createThroughHole, createCountersinkHole, createCounterboreHole, createElongatedSlot, createCableOpening, createMountingBoss, createPCBStandoff, createReinforcingRib, createCornerGusset, createLinearHolePattern, createCircularHolePattern, createDrainageSlotPattern).
7. Do not silently replace semantic dimensions or omit planned features.
`;
    }

    if (designSpecification) {
      semanticContext += `
FORMAL DESIGN SPECIFICATION:
${JSON.stringify(designSpecification, null, 2)}
`;
    }

    if (designChecklist && Array.isArray(designChecklist) && designChecklist.length > 0) {
      semanticContext += `
VERIFICATION CHECKLIST EXPECTATIONS:
${designChecklist.map((c: any) => `- [${c.severity || 'CRITICAL'}] ${c.title || c.requirement || 'Check'}: ${c.description || ''}`).join('\n')}
`;
    }

    stage1Prompt = `USER REQUEST: "${prompt}"
${refImagesContext}
EXTRACTED HARD SPECIFICATIONS:
${JSON.stringify(requirements, null, 2)}
${semanticContext}
Generate the complete, verified, executable @jscad/modeling script containing every single requested feature, top-level named consts, and dedicated kpFeature_<featureId>() wrapper functions.`;
  }

  let stage1Result: GeminiCallResult;
  try {
    const generationContents: any[] = [{ text: stage1Prompt }];
    appendReferenceImagesToContents(generationContents, referenceImages || []);
    stage1Result = await callGeminiWithResilience(ai, {
      purpose: 'cad_generation',
      contents: generationContents,
      config: {
        systemInstruction,
      },
      enableThinking: true,
    });
  } catch (apiErr: any) {
    if (apiErr?.requestRecords && Array.isArray(apiErr.requestRecords)) {
      apiErr.requestRecords.forEach((r: AIRequestRecord) => {
        modelsUsedSet.add(r.model);
        requestRecords.push(r);
      });
      totalModelCalls += (apiErr.totalModelCalls || apiErr.requestRecords.length);
    }
    attachTelemetryAndRethrow(apiErr);
  }

  totalModelCalls += stage1Result.attempts;
  stage1Result.requestRecords.forEach((r) => {
    modelsUsedSet.add(r.model);
    requestRecords.push(r);
  });

  const extractedCode1 = extractAndValidateJscad(stage1Result.text);
  let lastExecutionError = '';
  let failingCode = stage1Result.text;

  if (extractedCode1) {
    failingCode = extractedCode1;
    const reservedErr = validateReservedBuilderUsage(extractedCode1);
    if (reservedErr) {
      lastExecutionError = reservedErr.message;
    } else {
      const execResult1 = executeJscadServerSide(extractedCode1);
      if (execResult1.success && execResult1.measurements && execResult1.measurements.isNonEmpty) {
        return {
          code: extractedCode1,
          measurements: execResult1.measurements,
          repairAttempts: 0,
          requestRecords,
          modelsUsed: Array.from(modelsUsedSet),
          totalModelCalls,
        };
      }
      lastExecutionError = execResult1.error || 'Execution returned empty or invalid geometry';
    }
  } else {
    lastExecutionError = 'Generated code did not contain a valid main() function declaration';
  }

  // ---------------------------------------------------------------------------
  // Stage 2: Single CAD Execution Repair (ONLY if Stage 1 code failed execution)
  // ---------------------------------------------------------------------------
  console.warn(`[JSCAD Repair] Stage 1 execution failed (${lastExecutionError}). Launching cad_execution_repair pass...`);

  let executionRepairSemanticContext = '';

  if (isRevision && revisionContext) {
    if (revisionContext.featureModel) {
      executionRepairSemanticContext += `
CURRENT SEMANTIC FEATURE MODEL (PRE-REVISION):
${JSON.stringify(revisionContext.featureModel, null, 2)}
`;
    }
    const targetModel = revisionContext.targetFeatureModel || featureModel || revisionContext.featureModel;
    if (targetModel) {
      executionRepairSemanticContext += `
TARGET SEMANTIC FEATURE MODEL AFTER REQUESTED CHANGE (AUTHORITATIVE FOR NEW VERSION):
${JSON.stringify(targetModel, null, 2)}
`;
    }
    if (revisionContext.semanticOperation) {
      executionRepairSemanticContext += `
SEMANTIC REVISION OPERATION:
${JSON.stringify(revisionContext.semanticOperation, null, 2)}
`;
    }
    if (revisionContext.bindingValidation) {
      executionRepairSemanticContext += `
CURRENT SEMANTIC BINDING VALIDATION:
${JSON.stringify(revisionContext.bindingValidation, null, 2)}
`;
    }
    const modelParams: FeatureParameter[] = (targetModel || revisionContext.featureModel)?.parameters || [];
    const lockedIds = revisionContext.lockedParameterIds || modelParams.filter((p) => p.locked).map((p) => p.id);
    if (lockedIds.length > 0) {
      const lockedDetails = lockedIds.map((id) => {
        const p = modelParams.find((param) => param.id === id);
        return `- Parameter ID: ${id} | Semantic Name: ${p?.name || p?.semanticName || id} | Constant: const ${p?.jscadConstantName || p?.name || id} | Value: ${p?.value !== undefined ? p.value : 'N/A'} ${p?.unit || 'mm'}`;
      });
      executionRepairSemanticContext += `
LOCKED SEMANTIC PARAMETERS:
${lockedDetails.join('\n')}
`;
    }
    if (revisionContext.featureModel?.codeBindings && Object.keys(revisionContext.featureModel.codeBindings).length > 0) {
      executionRepairSemanticContext += `
CODE BINDING ABI TO PRESERVE:
${JSON.stringify(revisionContext.featureModel.codeBindings, null, 2)}
`;
    }
  } else if (featureModel) {
    executionRepairSemanticContext += `
AUTHORITATIVE SEMANTIC FEATURE MODEL:
${JSON.stringify(featureModel, null, 2)}
`;
    const modelParams: FeatureParameter[] = featureModel.parameters || [];
    const lockedParams = modelParams.filter((p) => p.locked);
    if (lockedParams.length > 0) {
      const lockedDetails = lockedParams.map((p) => `- Parameter ID: ${p.id} | Semantic Name: ${p.name || p.semanticName || p.id} | Constant: const ${p.jscadConstantName || p.name || p.id} | Value: ${p.value !== undefined ? p.value : 'N/A'} ${p.unit || 'mm'}`);
      executionRepairSemanticContext += `
LOCKED SEMANTIC PARAMETERS:
${lockedDetails.join('\n')}
`;
    }
  }

  const specToInclude = designSpecification || revisionContext?.designSpecification;
  if (specToInclude) {
    executionRepairSemanticContext += `
FORMAL DESIGN SPECIFICATION:
${JSON.stringify(specToInclude, null, 2)}
`;
  }

  if (designChecklist && Array.isArray(designChecklist) && designChecklist.length > 0) {
    executionRepairSemanticContext += `
CRITICAL DESIGN CHECKLIST EXPECTATIONS:
${designChecklist.map((c: any) => `- [${c.severity || c.importance || 'CRITICAL'}] ${c.title || c.requirement || c.id || 'Check'}: ${c.description || c.notes || ''}`).join('\n')}
`;
  }

  const stage2Prompt = `RUNTIME ERROR REPAIR: Auto-Repairing Geometry (Attempt 1/1):
The generated JSCAD code failed execution with the following error:
>>> ${lastExecutionError}

Original Prompt: "${prompt}"
Mandatory Technical Requirements:
${JSON.stringify(requirements, null, 2)}
${executionRepairSemanticContext}

Failing Code:
\`\`\`js
${failingCode}
\`\`\`

CAD EXECUTION & RUNTIME REPAIR RULES:
1. REPAIR ONLY THE EXECUTION FAILURE (syntax error, invalid CSG/boolean operation, bad transform input, invalid geometry construction, undefined local helper, empty geometry).
2. DO NOT REDESIGN OR SIMPLIFY THE OBJECT.
3. PRESERVE THE SEMANTIC ABI:
   - DO NOT rename top-level parameter constants (e.g. const <jscadConstantName> = <value>;).
   - DO NOT change exact parameter constant values unless the execution error is directly caused by an invalid numeric value AND the semantic model explicitly authorizes a different value.
   - DO NOT rename or delete kpFeature_<featureId>() wrapper functions.
   - DO NOT delete failing feature wrappers to "fix" an error — keep every feature wrapper connected to executable main() geometry.
   - DO NOT remove unrelated or preserved features.
   - PRESERVE registered deterministic builder calls (createThroughHole, createCountersinkHole, createCounterboreHole, createElongatedSlot, createCableOpening, createMountingBoss, createPCBStandoff, createReinforcingRib, createCornerGusset, createLinearHolePattern, createCircularHolePattern, createDrainageSlotPattern). Do NOT rewrite them with raw primitive geometry.
   - PRESERVE WORLD-SPACE WRAPPER ABI: Every feature wrapper kpFeature_<featureId>() must return world-positioned geometry. A repair may NOT fix code by moving spatial transforms outside kpFeature_<id>().
4. If this is a revision, ensure the code satisfies the TARGET SEMANTIC FEATURE MODEL (all added/modified features must remain present and functional).
5. DO NOT modify locked parameter values.
6. PRESERVE MULTI-PIECE ABI when the failing code or user request is multi-piece: keep kpPart_<id>() wrappers, getParts(), stable part IDs/names/quantities, and separate solids. Never fix execution by unioning independent printed pieces.
7. Return ONLY executable @jscad/modeling JavaScript preserving the original single-piece or multi-piece structure. Single-piece may use main() returning one solid; multi-piece must retain getParts() and main() returning getParts().map((part) => part.geometry).`;

  let stage2Result: GeminiCallResult;
  try {
    stage2Result = await callGeminiWithResilience(ai, {
      purpose: 'cad_execution_repair',
      contents: stage2Prompt,
      config: {
        systemInstruction,
      },
      enableThinking: true,
    });
  } catch (repairApiErr: any) {
    if (repairApiErr?.requestRecords && Array.isArray(repairApiErr.requestRecords)) {
      repairApiErr.requestRecords.forEach((r: AIRequestRecord) => {
        modelsUsedSet.add(r.model);
        requestRecords.push(r);
      });
      totalModelCalls += (repairApiErr.totalModelCalls || repairApiErr.requestRecords.length);
    }
    attachTelemetryAndRethrow(repairApiErr);
  }

  totalModelCalls += stage2Result.attempts;
  stage2Result.requestRecords.forEach((r) => {
    modelsUsedSet.add(r.model);
    requestRecords.push(r);
  });

  const extractedCode2 = extractAndValidateJscad(stage2Result.text);
  if (extractedCode2) {
    const reservedErr2 = validateReservedBuilderUsage(extractedCode2);
    if (reservedErr2) {
      lastExecutionError = reservedErr2.message;
    } else {
      const execResult2 = executeJscadServerSide(extractedCode2);
      if (execResult2.success && execResult2.measurements && execResult2.measurements.isNonEmpty) {
        return {
          code: extractedCode2,
          measurements: execResult2.measurements,
          repairAttempts: 1,
          requestRecords,
          modelsUsed: Array.from(modelsUsedSet),
          totalModelCalls,
        };
      }
      lastExecutionError = execResult2.error || 'Execution returned empty or invalid geometry';
    }
  } else {
    lastExecutionError = 'Repaired code did not contain a valid main() function declaration';
  }

  const execErr: any = new Error(`Generated JSCAD code could not be executed into valid geometry: ${lastExecutionError}`);
  execErr.errorCategory = 'JSCAD_EXECUTION_ERROR';
  attachTelemetryAndRethrow(execErr);
}

// ---------------------------------------------------------------------------
// Revision Requirements Updater (Preserves Previous Constraints)
// ---------------------------------------------------------------------------
async function updateRequirementsForRevision(
  originalPrompt: string,
  revisionPrompt: string,
  previousRequirements: any,
  ai: GoogleGenAI,
  referenceImages: ProjectReferenceImage[] = []
): Promise<{
  requirements: any;
  requestRecords: AIRequestRecord[];
  modelsUsed: string[];
  totalModelCalls: number;
}> {
  const systemInstruction = `You are a precision CAD specification engineer managing parametric revisions.
TASK:
1. Update technical requirements based on the user's revision prompt: "${revisionPrompt}".
2. PRESERVE EVERY PREVIOUS REQUIREMENT (dimensions, holes, slots, features, hardware, referenceObject) that was NOT explicitly modified or removed by the user.
3. Modify only the properties affected by the revision.
4. Update "designDecisions" and "suggestedImprovements" to match the new state.

Output ONLY valid JSON matching the ExtractedRequirements schema.`;

  try {
    const revisionContents: any[] = [{
      text: `Original Base Prompt: "${originalPrompt}"
Previous Specifications:
${JSON.stringify(previousRequirements || {}, null, 2)}

User Revision Request: "${revisionPrompt}"

Update the technical requirements while preserving all untouched features and reference object constraints. Reference photographs are visual evidence only: explicit written dimensions and measured photo notes remain authoritative.`,
    }];
    appendReferenceImagesToContents(revisionContents, referenceImages);

    const geminiRes = await callGeminiWithResilience(ai, {
      purpose: 'design_reasoning',
      contents: revisionContents,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(geminiRes.text);
    if (!parsed.referenceObject && previousRequirements?.referenceObject) {
      parsed.referenceObject = previousRequirements.referenceObject;
    }
    return {
      requirements: parsed,
      requestRecords: geminiRes.requestRecords,
      modelsUsed: Array.from(new Set(geminiRes.requestRecords.map((r) => r.model))),
      totalModelCalls: geminiRes.attempts,
    };
  } catch (err: any) {
    console.warn('Revision requirements update fallback:', err);
    return {
      requirements: {
        ...(previousRequirements || {}),
        features: [
          ...(previousRequirements?.features || []),
          `Revision: ${revisionPrompt}`,
        ],
        explicitRequirements: [
          ...(previousRequirements?.explicitRequirements || []),
          revisionPrompt,
        ],
        designDecisions: [
          ...(previousRequirements?.designDecisions || []),
          `Applied revision: ${revisionPrompt}`,
        ],
      },
      requestRecords: err?.requestRecords || [],
      modelsUsed: err?.modelsUsed || [],
      totalModelCalls: err?.totalModelCalls || (err?.requestRecords?.length ?? 0),
    };
  }
}

// ---------------------------------------------------------------------------
// Offline / Explicit Template Generator (Only when explicitly invoked)
// ---------------------------------------------------------------------------
function synthesizeOfflineJscad(prompt: string): string {
  const p = prompt.toLowerCase();
  const numbers = prompt.match(/\d+(\.\d+)?/g)?.map(Number) || [];
  const primaryDim = numbers[0] || 120;
  const secondaryDim = numbers[1] || 80;
  const tertiaryDim = numbers[2] || 35;

  if (p.includes('planter') || p.includes('pot') || p.includes('plant')) {
    return `// Parametric Planter & Reservoir (Template)
// Key dimensions in millimeters (live editable)
const totalHeight = ${primaryDim >= 20 ? primaryDim : 130}.0;
const outerDiameter = ${secondaryDim >= 20 ? secondaryDim : 110}.0;
const wallThickness = 3.2;
const reservoirHeight = ${tertiaryDim >= 10 ? tertiaryDim : 30}.0;
const innerPotDiameter = outerDiameter - 18.0;
const drainageHoleDiameter = 6.0;

function main() {
  const outerRadius = outerDiameter / 2;
  const innerRadius = outerRadius - wallThickness;
  const potInnerRadius = innerPotDiameter / 2;
  
  const outerPot = cylinder({ radius: outerRadius, height: totalHeight, segments: 48 });
  const outerHollow = cylinder({ radius: innerRadius, height: totalHeight, segments: 48 });
  const outerShell = subtract(outerPot, translate([0, 0, wallThickness * 2], outerHollow));

  const basketHeight = totalHeight - reservoirHeight;
  const innerBasket = cylinder({ radius: potInnerRadius, height: basketHeight, segments: 48 });
  const innerCavity = cylinder({ radius: potInnerRadius - wallThickness, height: basketHeight + 10, segments: 48 });
  const basketShell = subtract(innerBasket, translate([0, 0, wallThickness * 1.5], innerCavity));

  const drainage = cylinder({ radius: drainageHoleDiameter / 2, height: wallThickness * 4, segments: 16 });
  const basketWithHoles = subtract(basketShell, translate([0, 0, -2], drainage));

  const assembly = union(outerShell, translate([0, 0, reservoirHeight], basketWithHoles));
  return translate([0, 0, totalHeight / 2], assembly);
}`;
  }

  if (p.includes('bracket') || p.includes('mount') || p.includes('brace')) {
    return `// Parametric Reinforced Angle Bracket (Template)
// Key dimensions in millimeters (live editable)
const legLengthA = ${primaryDim >= 20 ? primaryDim : 60}.0;
const legLengthB = ${secondaryDim >= 20 ? secondaryDim : 60}.0;
const bracketWidth = ${tertiaryDim >= 10 ? tertiaryDim : 35}.0;
const plateThickness = 5.0;
const gussetThickness = 4.0;
const holeDiameter = 5.2;

function main() {
  const legA = cuboid({ size: [legLengthA, bracketWidth, plateThickness] });
  const legB = cuboid({ size: [plateThickness, bracketWidth, legLengthB] });
  const gussetSize = Math.min(legLengthA, legLengthB) - plateThickness - 5;
  const gusset = cuboid({ size: [gussetSize, gussetThickness, gussetSize] });

  const baseStructure = union(
    translate([legLengthA / 2, 0, plateThickness / 2], legA),
    translate([plateThickness / 2, 0, legLengthB / 2], legB),
    translate([gussetSize / 2 + plateThickness, 0, gussetSize / 2 + plateThickness], gusset)
  );

  const hole = cylinder({ radius: holeDiameter / 2, height: plateThickness * 3, segments: 24 });
  return subtract(
    baseStructure,
    translate([legLengthA * 0.7, 0, 0], hole),
    translate([0, 0, legLengthB * 0.7], rotateY(Math.PI / 2, hole))
  );
}`;
  }

  return `// Parametric Electronics Enclosure Box (Template)
// Key dimensions in millimeters (live editable)
const boxLength = ${primaryDim >= 20 ? primaryDim : 100}.0;
const boxWidth = ${secondaryDim >= 20 ? secondaryDim : 60}.0;
const boxHeight = ${tertiaryDim >= 10 ? tertiaryDim : 25}.0;
const wallThickness = 3.0;
const cornerRadius = 3.0;
const mountingHoleDiameter = 4.0;
const cornerInset = 8.0;

function main() {
  const outerBox = roundedCuboid({
    size: [boxLength, boxWidth, boxHeight],
    roundRadius: cornerRadius,
    segments: 24
  });

  const innerCavity = roundedCuboid({
    size: [boxLength - (wallThickness * 2), boxWidth - (wallThickness * 2), boxHeight + 5],
    roundRadius: Math.max(1, cornerRadius - 1),
    segments: 24
  });

  const hollow = subtract(outerBox, translate([0, 0, wallThickness], innerCavity));
  const hole = cylinder({ radius: mountingHoleDiameter / 2, height: wallThickness * 4, segments: 24 });

  const hX = (boxLength / 2) - cornerInset;
  const hY = (boxWidth / 2) - cornerInset;

  const withHoles = subtract(
    hollow,
    translate([hX, hY, 0], hole),
    translate([-hX, hY, 0], hole),
    translate([hX, -hY, 0], hole),
    translate([-hX, -hY, 0], hole)
  );

  return translate([0, 0, boxHeight / 2], withHoles);
}`;
}

function sanitizeErrorDetails(raw: any): string {
  const str = typeof raw === 'string' ? raw : raw?.stack || raw?.message || JSON.stringify(raw) || '';
  return str
    .replace(/AIza[0-9A-Za-z-_]{35}/g, '[REDACTED_API_KEY]')
    .replace(/Bearer\s+[a-zA-Z0-9_\-\.]+/gi, 'Bearer [REDACTED_TOKEN]')
    .replace(/key=[a-zA-Z0-9_\-]+/gi, 'key=[REDACTED]');
}

interface CleanedError {
  message: string;
  errorCategory: string;
  technicalDetails: string;
  statusCode: number;
}

function cleanErrorMessage(err: any): CleanedError {
  const msg = String(err?.message || err || '');
  let rawStatus: number = 0;
  if (typeof err?.status === 'number') rawStatus = err.status;
  else if (typeof err?.statusCode === 'number') rawStatus = err.statusCode;
  else if (typeof err?.code === 'number') rawStatus = err.code;
  else if (typeof err?.error?.code === 'number') rawStatus = err.error.code;
  else if (typeof err?.response?.status === 'number') rawStatus = err.response.status;
  else if (err?.isTimeout) rawStatus = 504;

  const technicalDetails = sanitizeErrorDetails(err);

  // 401: Invalid or missing API key
  if (
    rawStatus === 401 ||
    msg.includes('401') ||
    msg.includes('UNAUTHENTICATED') ||
    msg.includes('API key not valid') ||
    msg.includes('invalid api_key') ||
    msg.includes('Invalid API key') ||
    msg.includes('GEMINI_API_KEY is not configured')
  ) {
    return {
      message: 'Invalid or missing Gemini API credential.',
      errorCategory: 'AUTH_ERROR',
      technicalDetails,
      statusCode: 401,
    };
  }

  // 403: Permission denied
  if (
    rawStatus === 403 ||
    msg.includes('403') ||
    msg.includes('PERMISSION_DENIED') ||
    msg.includes('permission')
  ) {
    return {
      message: 'Gemini API credential does not have permission to access this model or project.',
      errorCategory: 'PERMISSION_ERROR',
      technicalDetails,
      statusCode: 403,
    };
  }

  // 429: Rate limit / Quota
  if (
    rawStatus === 429 ||
    msg.includes('429') ||
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('quota') ||
    msg.includes('Quota exceeded') ||
    msg.includes('rate limit') ||
    msg.includes('rate_limit')
  ) {
    return {
      message: 'Gemini AI rate limit reached. Please wait a few seconds before generating again, or switch to Template Mode.',
      errorCategory: 'RATE_LIMIT',
      technicalDetails,
      statusCode: 429,
    };
  }

  // 404: Model unavailable
  if (
    rawStatus === 404 ||
    msg.includes('404') ||
    msg.includes('NOT_FOUND') ||
    msg.includes('is not supported') ||
    msg.includes('no longer available') ||
    msg.includes('model not found')
  ) {
    return {
      message: 'Requested Gemini model is unavailable.',
      errorCategory: 'MODEL_UNAVAILABLE',
      technicalDetails,
      statusCode: 404,
    };
  }

  // Timeout / 504 / DEADLINE_EXCEEDED
  if (
    rawStatus === 504 ||
    rawStatus === 408 ||
    err?.errorCategory === 'REQUEST_TIMEOUT' ||
    msg.includes('504') ||
    msg.includes('DEADLINE_EXCEEDED') ||
    msg.includes('Deadline expired') ||
    msg.includes('timeout') ||
    msg.includes('timed out') ||
    msg.includes('ETIMEDOUT') ||
    err?.error?.status === 'DEADLINE_EXCEEDED'
  ) {
    return {
      message: 'AI operation timed out before a valid model was produced. Please retry or switch to Template Mode.',
      errorCategory: 'REQUEST_TIMEOUT',
      technicalDetails,
      statusCode: 504,
    };
  }

  // 503 / Unavailable / Overloaded
  if (
    rawStatus === 503 ||
    msg.includes('503') ||
    msg.includes('UNAVAILABLE') ||
    msg.includes('high demand') ||
    msg.includes('overloaded') ||
    msg.includes('Service Unavailable')
  ) {
    return {
      message: 'Gemini AI is temporarily experiencing high traffic. Please retry in a few moments, or switch to Template Mode.',
      errorCategory: 'GEMINI_UNAVAILABLE',
      technicalDetails,
      statusCode: 503,
    };
  }

  // Security violations
  if (
    msg.includes('Security violation') ||
    msg.includes('security sandbox') ||
    msg.includes('forbidden') ||
    msg.includes('FORBIDDEN_SECURITY')
  ) {
    return {
      message: 'Generated code violated security sandbox constraints.',
      errorCategory: 'SECURITY_REJECTION',
      technicalDetails,
      statusCode: 422,
    };
  }

  // Organic unconfigured
  if (
    msg.includes('Organic mesh generation provider not configured') ||
    msg.includes('Organic 3D Engine not configured')
  ) {
    return {
      message: 'Organic 3D Engine not configured. The requested model requires a Text-to-3D neural mesh engine rather than the Parametric CAD engine.',
      errorCategory: 'ORGANIC_UNCONFIGURED',
      technicalDetails,
      statusCode: 422,
    };
  }

  // Hybrid unconfigured
  if (
    msg.includes('Hybrid organic/mechanical generation provider not configured')
  ) {
    return {
      message: 'Hybrid organic/mechanical generation provider not configured.',
      errorCategory: 'HYBRID_UNCONFIGURED',
      technicalDetails,
      statusCode: 422,
    };
  }

  // Empty or degenerate geometry
  if (
    msg.includes('empty or degenerate') ||
    msg.includes('zero valid polygons') ||
    msg.includes('empty or invalid geometry') ||
    msg.includes('INVALID_GEOMETRY')
  ) {
    return {
      message: 'Generated model produced empty or degenerate geometry.',
      errorCategory: 'INVALID_GEOMETRY',
      technicalDetails,
      statusCode: 422,
    };
  }

  // JSCAD execution / runtime errors
  if (
    msg.includes('JSCAD') ||
    msg.includes('execution error') ||
    msg.includes('could not generate valid executable CAD') ||
    msg.includes('ReferenceError') ||
    msg.includes('TypeError') ||
    msg.includes('SyntaxError') ||
    msg.includes('main() returned')
  ) {
    return {
      message: 'Generated JSCAD code could not be executed into valid geometry.',
      errorCategory: 'JSCAD_EXECUTION_ERROR',
      technicalDetails,
      statusCode: 422,
    };
  }

  // 400 / INVALID_ARGUMENT
  if (
    rawStatus === 400 ||
    msg.includes('400') ||
    msg.includes('INVALID_ARGUMENT') ||
    msg.includes('bad request')
  ) {
    return {
      message: 'Gemini rejected the request parameters.',
      errorCategory: 'INVALID_REQUEST',
      technicalDetails,
      statusCode: 400,
    };
  }

  return {
    message: err?.message || 'Failed to complete parametric CAD generation.',
    errorCategory: 'UNKNOWN_ERROR',
    technicalDetails,
    statusCode: 500,
  };
}

function getErrorDiagnostics(err: any) {
  const records: AIRequestRecord[] = Array.isArray(err?.requestRecords)
    ? err.requestRecords
    : [];

  return {
    modelUsed: getLastSuccessfulModel(records),
    modelsUsed:
      err?.modelsUsed ?? Array.from(new Set(records.map((r: AIRequestRecord) => r.model))),
    requestRecords: records,
    aiCallsMade: err?.totalModelCalls ?? records.length,
  };
}

// -------------------------------------------------------------
// GET /api/health
// -------------------------------------------------------------
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// -------------------------------------------------------------
// POST /api/extract-requirements
// -------------------------------------------------------------
app.post('/api/extract-requirements', async (req, res) => {
  const { prompt, referenceImages = [] } = req.body;
  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({
      error: 'Prompt string is required',
      errorCategory: 'INVALID_REQUEST',
      statusCode: 400,
    });
  }

  const ai = getGeminiClient();
  if (!ai) {
    return res.status(401).json({
      error: 'Invalid or missing Gemini API credential.',
      errorCategory: 'AUTH_ERROR',
      technicalDetails: 'GEMINI_API_KEY environment variable is not set.',
      statusCode: 401,
    });
  }

  try {
    const extraction = await extractRequirements(prompt, ai, referenceImages);
    return res.json({
      requirements: extraction.requirements,
      diagnostics: {
        modelUsed: extraction.aiMetadata.modelUsed,
        modelsUsed: extraction.aiMetadata.modelsUsed,
        aiCallsMade: extraction.aiMetadata.totalModelCalls,
        requestRecords: extraction.aiMetadata.requestRecords,
        durationMs: extraction.aiMetadata.durationMs,
      },
    });
  } catch (err: any) {
    console.error('Extract requirements error:', err);
    const cleaned = cleanErrorMessage(err);
    return res.status(cleaned.statusCode).json({
      error: cleaned.message,
      errorCategory: cleaned.errorCategory,
      technicalDetails: cleaned.technicalDetails,
      statusCode: cleaned.statusCode,
      diagnostics: getErrorDiagnostics(err),
    });
  }
});

// -------------------------------------------------------------
// POST /api/generate-jscad
// -------------------------------------------------------------
app.post('/api/generate-jscad', async (req, res) => {
  const {
    prompt,
    useTemplate,
    requirements,
    simplifyToParametric,
    mode,
    featureModel,
    designSpecification,
    designChecklist,
    referenceImages,
  } = req.body;
  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({
      error: 'Prompt is required',
      errorCategory: 'INVALID_REQUEST',
      statusCode: 400,
    });
  }

  const startTime = Date.now();
  const generationId = `gen_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

  // Explicit template mode request
  if (useTemplate) {
    const code = synthesizeOfflineJscad(prompt);
    const execTest = executeJscadServerSide(code);
    return res.json({
      code,
      source: 'template',
      generationId,
      requirements: requirements || {
        objectName: 'Template Model',
        classification: 'parametric',
        units: 'mm',
        overallDimensions: { width: 100, depth: 60, height: 25 },
        features: ['Template preset model'],
        quantities: {},
        spatialArrangements: [],
        printConsiderations: ['Base flat at Z=0'],
        warnings: [],
      },
      diagnostics: {
        generationId,
        timestamp: Date.now(),
        modelUsed: 'template-library',
        modelsUsed: ['template-library'],
        aiCallsMade: 0,
        repairAttempts: 0,
        latencyMs: Date.now() - startTime,
        measuredDimensions: execTest.measurements?.dimensions,
        measuredVolumeMm3: execTest.measurements?.actualVolumeMm3 ?? execTest.measurements?.volumeMm3,
        polygonCount: execTest.measurements?.polygonCount,
        triangleCount: execTest.measurements?.triangleCount,
        vertexCount: execTest.measurements?.vertexCount,
        isManifold: execTest.measurements?.isManifold,
        nonManifoldEdgeCount: execTest.measurements?.nonManifoldEdgeCount,
      },
      validationReport: {
        items: [
          {
            id: 'template_notice',
            label: 'Template Mode (Explicit Selection)',
            status: 'warning',
            detail: 'Synthesized from standard mechanical template library',
            requirementText: prompt,
            verificationSource: 'user-assumption',
          },
        ],
        overallScore: null,
        passed: true,
        verdict: 'PARTIALLY_VERIFIED',
        summary: 'Template model loaded directly by user selection.',
        missingFeatures: [],
        warnings: ['This is a parametric template model.'],
      },
    });
  }

  // If AI is not configured, return clear AUTH_ERROR
  const ai = getGeminiClient();
  if (!ai) {
    return res.status(401).json({
      error: 'Invalid or missing Gemini API credential.',
      errorCategory: 'AUTH_ERROR',
      technicalDetails: 'GEMINI_API_KEY environment variable is not configured.',
      statusCode: 401,
      canSimplifyToParametric: false,
    });
  }

  try {
    // Stage 1: Extract Requirements if not provided
    const reqs = requirements || (await extractRequirements(prompt, ai, referenceImages || [])).requirements;

    // Dual-Engine & Hybrid Routing (Bypassed if user explicitly requested simplifyToParametric)
    if (!simplifyToParametric) {
      const isHighConfidenceOrganic =
        reqs.isOrganicOnly ||
        (reqs.classification === 'organic' && (reqs.classificationConfidence ?? 1) >= 0.85);

      if (isHighConfidenceOrganic) {
        return res.status(422).json({
          error: `Organic 3D Engine not configured. The requested organic model ("${reqs.objectName || prompt}") requires a Text-to-3D neural mesh engine rather than the Parametric CAD engine.`,
          errorCategory: 'ORGANIC_UNCONFIGURED',
          technicalDetails: 'Sculptural organic request requires neural mesh generator.',
          statusCode: 422,
          canSimplifyToParametric: true,
          classification: 'organic',
          requirements: reqs,
        });
      }

      const hasExplicitSculpturalRequirement =
        Array.isArray(reqs.sculpturalRequirements) &&
        reqs.sculpturalRequirements.length > 0 &&
        reqs.sculpturalRequirements[0] !== 'none';

      const isHighConfidenceHybrid =
        reqs.classification === 'hybrid' &&
        (reqs.classificationConfidence ?? 1) >= 0.85 &&
        hasExplicitSculpturalRequirement;

      if (isHighConfidenceHybrid) {
        return res.status(422).json({
          error: `Hybrid organic/mechanical generation provider not configured. Models combining organic freeform sculptures with precision mechanical mounting features require a dedicated hybrid generation provider.`,
          errorCategory: 'HYBRID_UNCONFIGURED',
          technicalDetails: 'Hybrid organic-mechanical prompt routed away from pure CSG engine.',
          statusCode: 422,
          canSimplifyToParametric: true,
          classification: 'hybrid',
          requirements: reqs,
        });
      }
    }

    // Stage 2: CAD Generation with Server Execution Self-Repair (Throws on failure)
    const genResult = await generateAndRepairJscad({
      prompt,
      requirements: reqs,
      ai,
      isRevision: false,
      mode,
      featureModel,
      designSpecification,
      designChecklist,
      referenceImages,
    });

    const latencyMs = Date.now() - startTime;
    const actualModelUsed = getLastSuccessfulModel(genResult.requestRecords);

    return res.json({
      code: genResult.code,
      source: 'ai',
      generationId,
      requirements: reqs,
      diagnostics: {
        generationId,
        timestamp: Date.now(),
        modelUsed: actualModelUsed,
        modelsUsed: genResult.modelsUsed,
        requestRecords: genResult.requestRecords,
        aiCallsMade: genResult.totalModelCalls,
        repairAttempts: genResult.repairAttempts,
        latencyMs,
        measuredDimensions: genResult.measurements?.dimensions,
        measuredVolumeMm3: genResult.measurements?.actualVolumeMm3 ?? genResult.measurements?.volumeMm3,
        polygonCount: genResult.measurements?.polygonCount,
        triangleCount: genResult.measurements?.triangleCount,
        vertexCount: genResult.measurements?.vertexCount,
        isManifold: genResult.measurements?.isManifold,
        nonManifoldEdgeCount: genResult.measurements?.nonManifoldEdgeCount,
      },
      validationReport: {
        items: [
          {
            id: 'manifold_check',
            label: 'Closed Watertight Mesh',
            status: genResult.measurements?.isManifold ? 'verified' : 'warning',
            detail: genResult.measurements?.isManifold ? 'Manifold geometry' : 'Non-manifold edges detected',
            requirementText: 'Mesh must be closed',
            verificationSource: 'geometry',
          },
        ],
        overallScore: null,
        passed: !!genResult.measurements?.isManifold,
        verdict: genResult.measurements?.isManifold ? 'VERIFIED' : 'PARTIALLY_VERIFIED',
        summary: 'CAD geometry compiled and verified through server-side CSG kernel.',
        missingFeatures: [],
        warnings: genResult.measurements?.isManifold ? [] : ['Non-manifold geometry'],
      },
    });
  } catch (err: any) {
    console.error('Error generating JSCAD code:', err);
    const cleaned = cleanErrorMessage(err);
    return res.status(cleaned.statusCode).json({
      error: cleaned.message,
      errorCategory: cleaned.errorCategory,
      technicalDetails: cleaned.technicalDetails,
      statusCode: cleaned.statusCode,
      diagnostics: getErrorDiagnostics(err),
      canSimplifyToParametric:
        cleaned.errorCategory === 'ORGANIC_UNCONFIGURED' ||
        cleaned.errorCategory === 'HYBRID_UNCONFIGURED',
    });
  }
});

// -------------------------------------------------------------
// POST /api/revise-jscad
// -------------------------------------------------------------
app.post('/api/revise-jscad', async (req, res) => {
  const {
    originalPrompt,
    revisionHistory,
    currentCode,
    revisionPrompt,
    userInstruction,
    previousRequirements,
    revisionContext,
    mode,
    featureModel,
    designSpecification,
    designChecklist,
    referenceImages,
  } = req.body;

  const actualPrompt = revisionPrompt || userInstruction;
  if (!currentCode || !actualPrompt) {
    return res.status(400).json({
      error: 'currentCode and revisionPrompt/userInstruction are required',
      errorCategory: 'INVALID_REQUEST',
      statusCode: 400,
    });
  }

  const startTime = Date.now();
  const generationId = `gen_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

  const ai = getGeminiClient();
  if (!ai) {
    return res.status(401).json({
      error: 'Invalid or missing Gemini API credential.',
      errorCategory: 'AUTH_ERROR',
      technicalDetails: 'GEMINI_API_KEY environment variable is not configured.',
      statusCode: 401,
    });
  }

  try {
    let updatedReqs = revisionContext?.designSpecification || designSpecification;
    let updateReqsRecords: AIRequestRecord[] = [];
    let updateReqsModels: string[] = [];
    let updateReqsCalls = 0;

    // If no structured spec provided or confidence is low, fall back to AI requirement update
    if (!updatedReqs || !updatedReqs.primaryObject) {
      const updateRes = await updateRequirementsForRevision(
        originalPrompt || actualPrompt,
        actualPrompt,
        previousRequirements,
        ai,
        referenceImages || []
      );
      updatedReqs = updateRes.requirements;
      updateReqsRecords = updateRes.requestRecords;
      updateReqsModels = updateRes.modelsUsed;
      updateReqsCalls = updateRes.totalModelCalls;
    }

    const effectiveFeatureModel = revisionContext?.featureModel || featureModel;
    const effectiveSpec = revisionContext?.designSpecification || designSpecification || updatedReqs;

    const genResult = await generateAndRepairJscad({
      prompt: actualPrompt,
      requirements: updatedReqs,
      ai,
      isRevision: true,
      previousCode: currentCode,
      revisionContext,
      mode,
      featureModel: effectiveFeatureModel,
      designSpecification: effectiveSpec,
      designChecklist,
      referenceImages,
    });

    const mergedRequestRecords = [...updateReqsRecords, ...genResult.requestRecords];
    const mergedModelsUsed = Array.from(new Set([...updateReqsModels, ...genResult.modelsUsed]));
    const mergedTotalCalls = updateReqsCalls + genResult.totalModelCalls;

    const latencyMs = Date.now() - startTime;
    const actualModelUsed = getLastSuccessfulModel(mergedRequestRecords);

    return res.json({
      code: genResult.code,
      source: 'ai',
      generationId,
      requirements: updatedReqs,
      diagnostics: {
        generationId,
        timestamp: Date.now(),
        modelUsed: actualModelUsed,
        modelsUsed: mergedModelsUsed,
        requestRecords: mergedRequestRecords,
        aiCallsMade: mergedTotalCalls,
        repairAttempts: genResult.repairAttempts,
        latencyMs,
        measuredDimensions: genResult.measurements?.dimensions,
        measuredVolumeMm3: genResult.measurements?.actualVolumeMm3 ?? genResult.measurements?.volumeMm3,
        polygonCount: genResult.measurements?.polygonCount,
        triangleCount: genResult.measurements?.triangleCount,
        vertexCount: genResult.measurements?.vertexCount,
        isManifold: genResult.measurements?.isManifold,
        nonManifoldEdgeCount: genResult.measurements?.nonManifoldEdgeCount,
      },
      validationReport: {
        items: [
          {
            id: 'manifold_check',
            label: 'Closed Watertight Mesh',
            status: genResult.measurements?.isManifold ? 'verified' : 'warning',
            detail: genResult.measurements?.isManifold ? 'Manifold geometry' : 'Non-manifold edges detected',
            requirementText: 'Mesh must be closed',
            verificationSource: 'geometry',
          },
        ],
        overallScore: null,
        passed: !!genResult.measurements?.isManifold,
        verdict: genResult.measurements?.isManifold ? 'VERIFIED' : 'PARTIALLY_VERIFIED',
        summary: 'Revised CAD geometry compiled and verified.',
        missingFeatures: [],
        warnings: genResult.measurements?.isManifold ? [] : ['Non-manifold geometry'],
      },
    });
  } catch (err: any) {
    console.error('Error revising JSCAD model:', err);
    const cleaned = cleanErrorMessage(err);
    return res.status(cleaned.statusCode).json({
      error: cleaned.message,
      errorCategory: cleaned.errorCategory,
      technicalDetails: cleaned.technicalDetails,
      statusCode: cleaned.statusCode,
      diagnostics: getErrorDiagnostics(err),
    });
  }
});

// -------------------------------------------------------------
// POST /api/review-fidelity (Visual & Geometric Review)
// -------------------------------------------------------------
app.post('/api/review-fidelity', async (req, res) => {
  const { specification, code, geometryStats, deterministicChecks, views, purpose } = req.body;
  if (!code) {
    return res.status(400).json({ error: 'JSCAD code is required for fidelity review' });
  }

  const validPurpose = (purpose === 'final_visual_review' || purpose === 'visual_fidelity_review')
    ? purpose
    : 'visual_fidelity_review';

  const ai = getGeminiClient();
  if (!ai) {
    return res.status(401).json({
      error: 'Invalid or missing Gemini API credential.',
      errorCategory: 'AUTH_ERROR',
      statusCode: 401,
    });
  }

  try {
    const spec = specification || {
      primaryObject: 'Mechanical Component',
      intendedFunction: 'Functional printed part',
      requiredFeatures: [],
    };

    const systemInstruction = `You are a Lead Mechanical & Industrial Design Quality Inspector evaluating 3D printable CAD models.
You compare the structured Design Specification, geometry stats, and multi-view rendered images against the generated JSCAD source script.

REVIEW MANDATES:
1. Object Integrity: Does the model actually function as the requested "${spec.primaryObject}"?
2. Feature Verification: Are all required functional features (drainage slots, mounting holes, retaining lips, cable slots, ribs) present and properly dimensioned?
3. Usability & Ergonomics: Does the part allow easy physical access/insertion without catching or jamming?
4. Manufacturing & FDM Printability: Is the base flat at Z=0? Are overhangs reasonable without requiring destructive supports?
5. Honest Scoring: If critical features or dimensions are missing or flawed, score low and set requiresRepair: true.

Output strictly valid JSON matching this schema:
{
  "overallScore": number (0-100),
  "verdict": "PASS" | "NEEDS_MINOR_CORRECTION" | "NEEDS_MAJOR_CORRECTION" | "INVALID_DESIGN",
  "scoreBreakdown": {
    "intentMatch": number (0-100),
    "dimensions": number (0-100),
    "requiredFeatures": number (0-100),
    "printability": number (0-100),
    "visualMatch": number (0-100)
  },
  "verifiedRequirements": ["Feature or requirement 1 that succeeded", "Feature 2"],
  "missingFeatures": ["Missing feature 1"],
  "visualMismatch": ["Visual defect description 1"],
  "problems": [
    {
      "requirement": "Name of requirement or feature",
      "issue": "Specific failure or omission description",
      "severity": "critical" | "important" | "minor",
      "affectedFeatureId": "feat_xxx",
      "recommendedCorrection": "Specific CAD fix (e.g. increase clearance to 3mm, add 4mm wide slot)"
    }
  ],
  "requiresRepair": boolean,
  "summary": "Concise factual 2-sentence review summary"
}`;

    const textPrompt = `DESIGN SPECIFICATION:
${JSON.stringify(spec, null, 2)}

MEASURED GEOMETRY STATS:
${JSON.stringify(geometryStats || {}, null, 2)}

DETERMINISTIC CHECKS:
${JSON.stringify(deterministicChecks || [], null, 2)}

GENERATED JSCAD SOURCE CODE:
\`\`\`js
${code}
\`\`\`

Perform the visual and mechanical fidelity review.`;

    const contents: any[] = [{ text: textPrompt }];

    // Attach rendered snapshot views if provided
    if (views) {
      for (const [viewKey, dataUrl] of Object.entries(views)) {
        if (typeof dataUrl === 'string' && dataUrl.startsWith('data:image/')) {
          const match = dataUrl.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
          if (match) {
            contents.push({
              inlineData: {
                mimeType: match[1],
                data: match[2],
              },
            });
          }
        }
      }
    }

    const geminiRes = await callGeminiWithResilience(ai, {
      purpose: validPurpose,
      contents,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(geminiRes.text);
    parsed.designSpecification = spec;
    if (typeof parsed.requiresRepair === 'undefined') {
      parsed.requiresRepair = parsed.correctionNeeded ?? (parsed.verdict === 'NEEDS_MINOR_CORRECTION' || parsed.verdict === 'NEEDS_MAJOR_CORRECTION');
    }
    if (!Array.isArray(parsed.verifiedRequirements)) {
      parsed.verifiedRequirements = parsed.verifiedChecks || [];
    }
    if (!Array.isArray(parsed.missingFeatures)) {
      parsed.missingFeatures = [];
    }
    if (!Array.isArray(parsed.visualMismatch)) {
      parsed.visualMismatch = [];
    }
    if (!Array.isArray(parsed.problems)) {
      parsed.problems = [];
    }

    const actualModelUsed = getLastSuccessfulModel(geminiRes.requestRecords) || geminiRes.model;
    const modelsUsed = Array.from(new Set(geminiRes.requestRecords.map((r: any) => r.model)));

    return res.json({
      review: parsed,
      modelUsed: actualModelUsed,
      durationMs: geminiRes.durationMs,
      diagnostics: {
        modelUsed: actualModelUsed,
        modelsUsed,
        aiCallsMade: geminiRes.attempts,
        requestRecords: geminiRes.requestRecords,
        durationMs: geminiRes.durationMs,
      },
    });
  } catch (err: any) {
    console.error('Fidelity review error:', err);
    const cleaned = cleanErrorMessage(err);
    return res.status(cleaned.statusCode).json({
      error: cleaned.message,
      errorCategory: cleaned.errorCategory,
      statusCode: cleaned.statusCode,
      diagnostics: getErrorDiagnostics(err),
    });
  }
});

// -------------------------------------------------------------
// POST /api/targeted-repair (Targeted 1-Pass Precision Repair)
// -------------------------------------------------------------
app.post('/api/targeted-repair', async (req, res) => {
  const {
    originalPrompt,
    currentCode,
    specification,
    reviewResult,
    deterministicChecks,
    geometryStats,
    featureModel,
    bindingValidation,
    lockedParameterIds,
  } = req.body;
  if (!currentCode) {
    return res.status(400).json({ error: 'currentCode is required for targeted repair' });
  }

  const startTime = Date.now();
  const generationId = `gen_repair_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

  const ai = getGeminiClient();
  if (!ai) {
    return res.status(401).json({
      error: 'Invalid or missing Gemini API credential.',
      errorCategory: 'AUTH_ERROR',
      statusCode: 401,
    });
  }

  try {
    const problemsList = [...(reviewResult?.problems || [])];

    // Include failed critical deterministic checks in problemsList
    if (deterministicChecks && Array.isArray(deterministicChecks)) {
      deterministicChecks.forEach((chk: any) => {
        if (chk.status === 'failed' || chk.status === 'FAIL' || chk.passed === false) {
          problemsList.push({
            severity: chk.importance || chk.severity || 'CRITICAL',
            requirement: `Deterministic Check: ${chk.description || chk.title || chk.requirement || chk.id}`,
            issue: chk.notes || chk.failureReason || `Deterministic check failed (Expected: ${chk.expected}, Actual: ${chk.actual ?? 'unmatched'})`,
            recommendedCorrection: chk.expected !== undefined ? `Adjust geometry so dimension/feature satisfies: ${chk.expected}` : 'Correct geometric dimensions and features to satisfy check',
          });
        }
      });
    }

    function formatParamLiteral(val: any): string {
      if (typeof val === 'string') return JSON.stringify(val);
      if (typeof val === 'boolean') return String(val);
      if (typeof val === 'number') return Number.isFinite(val) ? String(val) : '0';
      if (val === undefined || val === null) return '0';
      return JSON.stringify(val);
    }

    // Add binding validation issues with exact missing constant values and expected builders
    if (bindingValidation) {
      if (Array.isArray(bindingValidation.criticalUnboundParameters) && bindingValidation.criticalUnboundParameters.length > 0) {
        bindingValidation.criticalUnboundParameters.forEach((paramId: string) => {
          const paramObj = featureModel?.parameters?.find((p: any) => p.id === paramId);
          const feat = featureModel?.features?.find((f: any) => f.id === paramObj?.featureId);
          const requiredConstName = paramObj?.jscadConstantName || paramObj?.name || paramId;
          const requiredValue = paramObj?.value !== undefined ? paramObj.value : 0;
          const formattedVal = formatParamLiteral(requiredValue);
          const unit = paramObj?.unit || 'mm';
          const isLocked = paramObj?.locked ? 'YES' : 'NO';

          problemsList.push({
            severity: 'CRITICAL',
            requirement: `Parameter Binding: ${paramObj?.name || paramId}`,
            issue: `Missing required top-level numeric constant \`const ${requiredConstName} = ...;\` for Feature: ${feat?.id || paramObj?.featureId || 'unknown'}, Parameter: ${paramObj?.name || paramId} (ID: ${paramId}). Required value: ${requiredValue} ${unit}, Locked: ${isLocked}.`,
            recommendedCorrection: `Declare \`const ${requiredConstName} = ${formattedVal};\` at the top level and use it in ${feat ? `kpFeature_${feat.id.replace(/[^a-zA-Z0-9_]/g, '_')}()` : 'geometry calculations'}.`,
          });
        });
      }

      if (Array.isArray(bindingValidation.missingBuilderFeatures) && bindingValidation.missingBuilderFeatures.length > 0) {
        bindingValidation.missingBuilderFeatures.forEach((featId: string) => {
          const feat = featureModel?.features?.find((f: any) => f.id === featId);
          const wrapperName = `kpFeature_${featId.replace(/[^a-zA-Z0-9_]/g, '_')}`;
          const builderSpec = feat?.type ? FEATURE_BUILDER_REGISTRY[feat.type] : undefined;
          const builderDesc = builderSpec
            ? `Required deterministic builder: ${builderSpec.builderName}`
            : 'Required standard builder or CSG operation';

          problemsList.push({
            severity: feat?.criticality === 'critical' ? 'CRITICAL' : 'IMPORTANT',
            requirement: `Feature Binding: ${feat?.label || feat?.name || featId}`,
            issue: `Feature: ${featId}. Required wrapper: \`${wrapperName}()\`. ${builderDesc}.`,
            recommendedCorrection: `Implement and call \`${wrapperName}()\` using ${builderSpec ? `\`${builderSpec.builderName}\`` : 'deterministic builders'} and combine in main().`,
          });
        });
      }
    }

    const problemsFormatted = problemsList
      .map(
        (p: any, idx: number) =>
          `${idx + 1}. [${p.severity || 'CRITICAL'}] ${p.requirement}: ${p.issue}. Suggested fix: ${p.recommendedCorrection || 'Fix geometry'}`
      )
      .join('\n');

    let lockedContext = '';
    const modelParams: FeatureParameter[] = featureModel?.parameters || [];
    const lockedIds = lockedParameterIds || modelParams.filter((p) => p.locked).map((p) => p.id);
    if (Array.isArray(lockedIds) && lockedIds.length > 0) {
      const lockedDetails = lockedIds.map((id: string) => {
        const p = modelParams.find((param) => param.id === id);
        return `- Parameter ID: ${id} | Semantic Name: ${p?.name || p?.semanticName || id} | Constant: const ${p?.jscadConstantName || p?.name || id} | Value: ${p?.value !== undefined ? p.value : 'N/A'} ${p?.unit || 'mm'}`;
      });
      lockedContext = `\nLOCKED SEMANTIC PARAMETERS (DO NOT CHANGE VALUES OF THESE CONSTANTS):\n${lockedDetails.join('\n')}\n`;
    }

    const builderDocs = getFeatureBuilderPromptDocs(featureModel?.features);

    const systemInstruction = `You are a precision mechanical CAD engineer performing a targeted ONE-PASS correction on existing @jscad/modeling code.

STRICT CORRECTION RULES:
1. PRESERVE EVERYTHING THAT ALREADY PASSES.
2. DO NOT redesign the model from scratch or replace working geometry.
3. Fix ONLY the specific reported problems and feature bindings identified in the design audit.
4. Maintain top-level named constants.
5. Implement clean feature wrapper functions (kpFeature_<featureId>) for bound features adhering strictly to the World-Space Selection ABI (positioning and orientation must be inside the wrapper, NO outer transforms in main()).
6. Preserve existing:
   - feature IDs
   - kpFeature_<featureId>() names
   - jscadConstantName values
   - parameter values
   - locked parameters
   - relationships
   - builder assignments
   unless the reported defect explicitly requires a change.
7. DO NOT redefine or re-declare reserved standard builder functions (createThroughHole, createCountersinkHole, createElongatedSlot, etc.).
8. PRESERVE MULTI-PIECE ABI if current code/request contains multiple printable pieces: keep kpPart_<id>(), getParts(), stable part metadata/quantities, and separate solids; do not fuse parts.
9. Return ONLY executable @jscad/modeling JavaScript preserving the original single-piece or multi-piece structure. No markdown commentary.

${builderDocs}`;

    let semanticRepairContext = '';
    if (featureModel) {
      semanticRepairContext += `
AUTHORITATIVE SEMANTIC FEATURE MODEL:
${JSON.stringify(featureModel, null, 2)}
`;
    }
    if (bindingValidation) {
      semanticRepairContext += `
CURRENT SEMANTIC BINDING VALIDATION:
${JSON.stringify(bindingValidation, null, 2)}
`;
    }

    const contentPrompt = `ORIGINAL USER REQUEST: "${originalPrompt}"

STRUCTURED DESIGN SPECIFICATION:
${JSON.stringify(specification || {}, null, 2)}
${semanticRepairContext}
${lockedContext}
PROBLEMS TO FIX IN THIS ONE TARGETED PASS:
${problemsFormatted || 'Refine geometry features, feature bindings, and clearances.'}

CURRENT WORKING JSCAD CODE:
\`\`\`js
${currentCode}
\`\`\`

Perform the targeted correction and return the complete, repaired JSCAD script.`;

    const geminiRes = await callGeminiWithResilience(ai, {
      purpose: 'precision_correction',
      contents: contentPrompt,
      config: {
        systemInstruction,
      },
      enableThinking: true,
    });

    const cleanCode = extractAndValidateJscad(geminiRes.text);
    if (!cleanCode) {
      throw new Error('Repaired code did not contain a valid main() function declaration');
    }

    const reservedErr = validateReservedBuilderUsage(cleanCode);
    if (reservedErr) {
      throw new Error(`Repaired code validation error: ${reservedErr.message}`);
    }

    const execTest = executeJscadServerSide(cleanCode);
    if (!execTest.success || !execTest.measurements || !execTest.measurements.isNonEmpty) {
      throw new Error(`Repaired geometry execution failed: ${execTest.error || 'degenerate geometry'}`);
    }

    const latencyMs = Date.now() - startTime;
    const actualModelUsed = getLastSuccessfulModel(geminiRes.requestRecords) || geminiRes.model;
    const modelsUsed = Array.from(new Set(geminiRes.requestRecords.map((r: any) => r.model)));

    return res.json({
      code: cleanCode,
      source: 'ai',
      generationId,
      diagnostics: {
        generationId,
        timestamp: Date.now(),
        modelUsed: actualModelUsed,
        modelsUsed,
        requestRecords: geminiRes.requestRecords,
        aiCallsMade: geminiRes.attempts,
        repairAttempts: 1,
        latencyMs,
        measuredDimensions: execTest.measurements?.dimensions,
        measuredVolumeMm3: execTest.measurements?.actualVolumeMm3 ?? execTest.measurements?.volumeMm3,
        polygonCount: execTest.measurements?.polygonCount,
        triangleCount: execTest.measurements?.triangleCount,
        vertexCount: execTest.measurements?.vertexCount,
        isManifold: execTest.measurements?.isManifold,
        nonManifoldEdgeCount: execTest.measurements?.nonManifoldEdgeCount,
      },
      validationReport: {
        items: [
          {
            id: 'targeted_repair_pass',
            label: 'Targeted Precision Repair',
            status: 'verified',
            detail: `Corrected ${problemsList.length} reported design issue(s)`,
            verificationSource: 'ai-review',
            isHardRequirement: true,
          },
        ],
        overallScore: null,
        passed: true,
        verdict: 'VERIFIED',
        summary: `Targeted precision repair successfully applied for ${problemsList.length} issue(s).`,
        missingFeatures: [],
        warnings: [],
      },
    });
  } catch (err: any) {
    console.error('Targeted repair error:', err);
    const cleaned = cleanErrorMessage(err);
    return res.status(cleaned.statusCode).json({
      error: cleaned.message,
      errorCategory: cleaned.errorCategory,
      technicalDetails: cleaned.technicalDetails,
      statusCode: cleaned.statusCode,
      diagnostics: getErrorDiagnostics(err),
    });
  }
});

// -------------------------------------------------------------
// POST /api/fix-missing-features
// -------------------------------------------------------------
app.post('/api/fix-missing-features', async (req, res) => {
  const { originalPrompt, currentCode, requirements, missingFeatures } = req.body;
  const startTime = Date.now();
  const generationId = `gen_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

  const ai = getGeminiClient();
  if (!ai) {
    return res.status(401).json({
      error: 'Invalid or missing Gemini API credential.',
      errorCategory: 'AUTH_ERROR',
      technicalDetails: 'GEMINI_API_KEY environment variable is not configured.',
      statusCode: 401,
    });
  }

  try {
    const fixPrompt = `Please fix the following missing or unverified features in the current model: ${missingFeatures.join(', ')}. Keep all other verified features intact.`;
    const genResult = await generateAndRepairJscad({
      prompt: fixPrompt,
      requirements,
      ai,
      isRevision: true,
      previousCode: currentCode,
    });

    const latencyMs = Date.now() - startTime;
    const actualModelUsed = getLastSuccessfulModel(genResult.requestRecords);

    return res.json({
      code: genResult.code,
      requirements,
      generationId,
      diagnostics: {
        generationId,
        timestamp: Date.now(),
        modelUsed: actualModelUsed,
        modelsUsed: genResult.modelsUsed,
        requestRecords: genResult.requestRecords,
        aiCallsMade: genResult.totalModelCalls,
        repairAttempts: genResult.repairAttempts,
        latencyMs,
        measuredDimensions: genResult.measurements?.dimensions,
        measuredVolumeMm3: genResult.measurements?.actualVolumeMm3 ?? genResult.measurements?.volumeMm3,
        polygonCount: genResult.measurements?.polygonCount,
        triangleCount: genResult.measurements?.triangleCount,
        vertexCount: genResult.measurements?.vertexCount,
        isManifold: genResult.measurements?.isManifold,
        nonManifoldEdgeCount: genResult.measurements?.nonManifoldEdgeCount,
      },
      validationReport: {
        items: [
          {
            id: 'feature_fix_pass',
            label: 'Feature Repair Pass',
            status: genResult.measurements?.isManifold ? 'verified' : 'warning',
            detail: `Repaired geometry: ${missingFeatures.join(', ')}`,
            requirementText: missingFeatures.join(', '),
            verificationSource: 'geometry',
            isHardRequirement: true,
          },
        ],
        overallScore: null,
        passed: !!genResult.measurements?.isManifold,
        verdict: genResult.measurements?.isManifold ? 'VERIFIED' : 'PARTIALLY_VERIFIED',
        summary: `Feature repair pass complete for: ${missingFeatures.join(', ')}.`,
        missingFeatures: [],
        warnings: genResult.measurements?.isManifold ? [] : ['Non-manifold edges detected in repaired geometry.'],
      },
    });
  } catch (err: any) {
    console.error('Error fixing missing features:', err);
    const cleaned = cleanErrorMessage(err);
    return res.status(cleaned.statusCode).json({
      error: cleaned.message,
      errorCategory: cleaned.errorCategory,
      technicalDetails: cleaned.technicalDetails,
      statusCode: cleaned.statusCode,
      diagnostics: getErrorDiagnostics(err),
    });
  }
});

// -------------------------------------------------------------
// POST /api/explain-slicer
// -------------------------------------------------------------
app.post('/api/explain-slicer', async (req, res) => {
  try {
    const { settings, geometry, printer, filament, mustHoldLiquid } = req.body;
    const ai = getGeminiClient();

    if (ai) {
      try {
        const promptText = `
Model Geometry:
- Dimensions (XYZ): ${geometry.dimensions.x} x ${geometry.dimensions.y} x ${geometry.dimensions.z} mm
- Volume: ${geometry.volumeCm3} cm³ (${geometry.volumeMm3} mm³)
- Surface Area: ${geometry.surfaceAreaMm2} mm²
- Estimated Weight: ${geometry.estimatedWeightGrams} g
- Height-to-Width Aspect Ratio: ${geometry.heightToWidthRatio}
- Overhang Ratio: ${(geometry.overhangRatio * 100).toFixed(1)}% (Steep overhangs present: ${geometry.hasSteepOverhangs})
- Manifold: ${geometry.isManifold}
- Must Hold Liquid / Watertight Mode: ${mustHoldLiquid ? 'YES' : 'NO'}

Target Printer:
- Model: ${printer.name}
- Build Volume: ${printer.buildVolume.x}x${printer.buildVolume.y}x${printer.buildVolume.z} mm
- Extruder Kinematics: ${printer.driveType.toUpperCase()} Drive
- Nozzle: ${printer.nozzleDiameter} mm
- Max Volumetric Flow: ${printer.maxVolumetricFlow} mm³/s
- Enclosed: ${printer.isEnclosed ? 'Yes' : 'No'}

Selected Filament:
- Material: ${filament.name}
- Recommended Temps: Nozzle ${filament.nozzleTempRange[0]}-${filament.nozzleTempRange[1]}°C, Bed ${filament.bedTempRange[0]}-${filament.bedTempRange[1]}°C
- Warp Risk: ${filament.warpRisk}
- Shrinkage: ${filament.shrinkagePercent}%

Calculated Slicer Overrides:
- Nozzle Temp: ${settings.nozzleTempFirstLayer}°C (Layer 1), ${settings.nozzleTempOtherLayers}°C (Other)
- Bed Temp: ${settings.bedTemp}°C
- Layer Height: ${settings.layerHeight} mm (First: ${settings.firstLayerHeight} mm)
- Perimeters / Wall Loops: ${settings.wallLoops}
- Infill: ${settings.infillPercent}% ${settings.infillPattern}
- Outer Wall Speed: ${settings.outerWallSpeed} mm/s | Inner Wall: ${settings.innerWallSpeed} mm/s | Infill: ${settings.infillSpeed} mm/s
- Cooling Fan: ${settings.fanPercent}%
- Retraction: ${settings.retractionDistance} mm @ ${settings.retractionSpeed} mm/s
- Supports: ${settings.supportsEnabled ? `Enabled (${settings.supportType})` : 'None'}
- Brim: ${settings.brimEnabled ? `Enabled (${settings.brimWidthMm} mm)` : 'None'}
- Flow Compensation: ${settings.flowCompensation}x
- Estimated Print Time: ${settings.estimatedPrintTimeMinutes} mins
`;

        const systemInstruction = `You are a world-class additive manufacturing engineer. Explain concisely in plain, professional engineering language WHY these specific slicer parameters were derived for this geometry, material, and kinematics.
Keep the explanation focused on:
1. Thermal bonding, layer heights, and perimeter choices (and liquid-holding tightness if active).
2. Kinematics, speed scaling, volumetric flow limits, and vibration dampening.
3. Bed adhesion (brims), warp mitigation, and overhang support strategy.
Do NOT output greetings or fluff. Use 2 to 3 concise, highly informative paragraphs or bullet points with bold sub-headers.`;

        const geminiRes = await callGeminiWithResilience(ai, {
          purpose: 'design_reasoning',
          contents: promptText,
          config: {
            systemInstruction,
          },
        });

        if (geminiRes?.text) {
          return res.json({ explanation: geminiRes.text });
        }
      } catch (geminiErr: any) {
        console.warn('Gemini explanation fallback:', geminiErr?.message || geminiErr);
      }
    }

    const explanation = `**Thermal & Interlayer Fusion:**
Extruder is locked to ${settings.nozzleTempFirstLayer}°C on the initial layer and ${settings.nozzleTempOtherLayers}°C for continuous extrusion, mated with a ${settings.bedTemp}°C heated bed. With ${settings.wallLoops} perimeters and a ${settings.layerHeight} mm layer step (${settings.firstLayerHeight} mm initial), this guarantees superior layer-to-layer weld strength and hydrostatic integrity${mustHoldLiquid ? ' (watertight liquid containment mode fully active)' : ''}.

**Kinematics & Volumetric Flow Limits:**
Speed is balanced with outer perimeters at ${settings.outerWallSpeed} mm/s and infill at ${settings.infillSpeed} mm/s to adhere strictly beneath the ${printer.name}'s max volumetric threshold of ${printer.maxVolumetricFlow} mm³/s. Extrusion retraction is optimized for ${printer.driveType.toUpperCase()} kinematics at ${settings.retractionDistance} mm @ ${settings.retractionSpeed} mm/s to eliminate stringing and nozzle pressure buildup.

**Adhesion & Overhang Mitigation:**
${settings.brimEnabled ? `A ${settings.brimWidthMm} mm brim has been dynamically engaged to counteract the ${filament.shrinkagePercent}% thermal shrinkage rate of ${filament.name}.` : 'Direct build-plate adhesion is sufficient for this geometry footprint.'} ${settings.supportsEnabled ? `Snug ${settings.supportType} supports are enabled to scaffold steep overhang angles without marring surface finish.` : 'Geometry contains self-supporting angles within the safe printable envelope.'}`;

    return res.json({ explanation });
  } catch (err: any) {
    console.error('Error in slicer explanation:', err);
    return res.status(500).json({ error: err?.message || 'Failed to explain slicer settings' });
  }
});

// -------------------------------------------------------------
// WEBSOCKET REAL-TIME PRINTER TELEMETRY
// -------------------------------------------------------------
const wss = new WebSocketServer({ server, path: '/ws' });

interface SimulationState {
  active: boolean;
  status: 'idle' | 'preheating' | 'calibrating' | 'printing' | 'completed' | 'paused';
  progressPercent: number;
  currentLayer: number;
  totalLayers: number;
  nozzleTemp: number;
  targetNozzleTemp: number;
  bedTemp: number;
  targetBedTemp: number;
  fanSpeedPercent: number;
  printTimeElapsedSec: number;
  printTimeRemainingSec: number;
  currentSpeedMmS: number;
  flowRateMm3S: number;
  printerName: string;
  message: string;
}

let activeSim: SimulationState = {
  active: false,
  status: 'idle',
  progressPercent: 0,
  currentLayer: 0,
  totalLayers: 320,
  nozzleTemp: 24,
  targetNozzleTemp: 0,
  bedTemp: 22,
  targetBedTemp: 0,
  fanSpeedPercent: 0,
  printTimeElapsedSec: 0,
  printTimeRemainingSec: 0,
  currentSpeedMmS: 0,
  flowRateMm3S: 0,
  printerName: 'Bambu Lab X1-Carbon',
  message: 'Printer standby. Ready for G-code transmission.',
};

let simInterval: NodeJS.Timeout | null = null;

function broadcastTelemetry() {
  const payload = JSON.stringify({ type: 'telemetry', data: activeSim });
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(payload);
    }
  });
}

function startPrintSimulation(config: any) {
  if (simInterval) clearInterval(simInterval);

  activeSim = {
    active: true,
    status: 'preheating',
    progressPercent: 0,
    currentLayer: 0,
    totalLayers: Math.max(50, Math.round((config?.dimensions?.z || 100) / (config?.layerHeight || 0.2))),
    nozzleTemp: 24,
    targetNozzleTemp: config?.nozzleTemp || 220,
    bedTemp: 23,
    targetBedTemp: config?.bedTemp || 60,
    fanSpeedPercent: 0,
    printTimeElapsedSec: 0,
    printTimeRemainingSec: (config?.printTimeMinutes || 45) * 60,
    currentSpeedMmS: 0,
    flowRateMm3S: 0,
    printerName: config?.printerName || 'Bambu Lab X1-Carbon',
    message: 'Heating nozzle and heated bed to target extrusion temperatures...',
  };

  let tickCount = 0;
  simInterval = setInterval(() => {
    tickCount++;
    activeSim.printTimeElapsedSec += 2;

    if (activeSim.status === 'preheating') {
      activeSim.nozzleTemp = Math.min(
        activeSim.targetNozzleTemp,
        Math.round(activeSim.nozzleTemp + (activeSim.targetNozzleTemp - 24) * 0.08 + Math.random() * 4)
      );
      activeSim.bedTemp = Math.min(
        activeSim.targetBedTemp,
        Math.round(activeSim.bedTemp + (activeSim.targetBedTemp - 22) * 0.06 + Math.random() * 2)
      );

      if (activeSim.nozzleTemp >= activeSim.targetNozzleTemp - 1 && activeSim.bedTemp >= activeSim.targetBedTemp - 1) {
        activeSim.status = 'calibrating';
        activeSim.message = 'Performing auto bed leveling mesh and vibration resonance compensation...';
      }
    } else if (activeSim.status === 'calibrating') {
      if (tickCount > 10) {
        activeSim.status = 'printing';
        activeSim.fanSpeedPercent = config?.fanPercent || 100;
        activeSim.message = 'Printing First Layer with flow compensation active.';
      }
    } else if (activeSim.status === 'printing') {
      const increment = 100 / Math.max(30, activeSim.totalLayers * 0.4);
      activeSim.progressPercent = Math.min(100, Number((activeSim.progressPercent + increment).toFixed(1)));
      activeSim.currentLayer = Math.min(
        activeSim.totalLayers,
        Math.max(1, Math.floor((activeSim.progressPercent / 100) * activeSim.totalLayers))
      );
      activeSim.printTimeRemainingSec = Math.max(0, Math.round(activeSim.printTimeRemainingSec - 2.5));
      activeSim.currentSpeedMmS = Math.round((config?.outerWallSpeed || 150) + (Math.random() * 40 - 20));
      activeSim.flowRateMm3S = Number((12.5 + Math.sin(tickCount) * 3.2).toFixed(1));

      activeSim.nozzleTemp = activeSim.targetNozzleTemp + Math.round(Math.random() * 2 - 1);
      activeSim.bedTemp = activeSim.targetBedTemp + Math.round(Math.random() * 1 - 0.5);

      if (activeSim.progressPercent >= 100) {
        activeSim.status = 'completed';
        activeSim.progressPercent = 100;
        activeSim.currentSpeedMmS = 0;
        activeSim.flowRateMm3S = 0;
        activeSim.fanSpeedPercent = 0;
        activeSim.targetNozzleTemp = 0;
        activeSim.targetBedTemp = 0;
        activeSim.message = 'Print completed successfully. Cooling hotend and presenting build plate.';
        if (simInterval) clearInterval(simInterval);
      } else {
        activeSim.message = `Printing Layer ${activeSim.currentLayer} / ${activeSim.totalLayers} (${activeSim.progressPercent}%)`;
      }
    }

    broadcastTelemetry();
  }, 1000);
}

wss.on('connection', (ws) => {
  ws.send(JSON.stringify({ type: 'telemetry', data: activeSim }));

  ws.on('message', (messageRaw) => {
    try {
      const msg = JSON.parse(messageRaw.toString());
      if (msg.type === 'start_sim') {
        startPrintSimulation(msg.config);
      } else if (msg.type === 'cancel_sim') {
        if (simInterval) clearInterval(simInterval);
        activeSim.status = 'idle';
        activeSim.active = false;
        activeSim.progressPercent = 0;
        activeSim.targetNozzleTemp = 0;
        activeSim.targetBedTemp = 0;
        activeSim.currentSpeedMmS = 0;
        activeSim.flowRateMm3S = 0;
        activeSim.message = 'Print job cancelled. Extruder parked.';
        broadcastTelemetry();
      }
    } catch (e) {
      console.error('WS Error:', e);
    }
  });
});

// Catch-all for API endpoints to prevent falling through to Vite HTML SPA middleware
app.use('/api', (req, res) => {
  res.status(404).json({ error: `API endpoint not found: ${req.method} ${req.originalUrl || req.url}` });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`KatPrint server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
