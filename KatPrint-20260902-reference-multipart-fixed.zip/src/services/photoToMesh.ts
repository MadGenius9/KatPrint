import * as THREE from 'three';

export interface PhotoToMeshResult {
  geometry?: THREE.BufferGeometry;
  isConfigured: boolean;
  isManifold: boolean;
  warnings: string[];
  providerNote: string;
  errorMessage?: string;
}

/**
 * Service module for Neural / Photogrammetry Mesh Reconstruction.
 * Explicitly reports provider status and avoids pretending synthetic test primitives are real scans.
 */
export async function photoToMesh(imageBlob: Blob | File | string): Promise<PhotoToMeshResult> {
  // Check if real provider endpoint is configured
  const hasConfiguredProvider = false;

  if (!hasConfiguredProvider) {
    return {
      isConfigured: false,
      isManifold: false,
      warnings: [
        'Photo-to-Mesh provider not configured.',
        'To enable real photogrammetry or neural image-to-3D, configure an external photogrammetry service (e.g., Tripo3D, CSM, Instant-Mesh, or local Meshroom worker).',
      ],
      providerNote:
        'Photo-to-Mesh provider is currently unconfigured. Uploaded images will not be silently replaced with fake geometry.',
      errorMessage: 'Photo-to-Mesh provider not configured.',
    };
  }

  throw new Error('Photo-to-Mesh provider not configured.');
}

/**
 * Creates a watertight test solid for the photogrammetry pipeline
 */
function createSamplePhotogrammetricMesh(): THREE.BufferGeometry {
  // Create a composite mechanical solid: chamfered base + hollow cylinder + reinforcement ribs
  const groupGeom = new THREE.BufferGeometry();
  
  // High quality manifold torus knot / mechanical adapter for visual test
  const knot = new THREE.TorusKnotGeometry(25, 8, 96, 24, 2, 3);
  knot.scale(1, 1, 0.8);
  knot.rotateX(Math.PI / 2);
  knot.computeVertexNormals();

  // Add colors for overhangs
  const pos = knot.getAttribute('position');
  const normals = knot.getAttribute('normal');
  const colors: number[] = [];

  for (let i = 0; i < pos.count; i++) {
    const nz = normals.getZ(i);
    const isOverhang = nz < -0.65;
    colors.push(isOverhang ? 0.98 : 0.42, isOverhang ? 0.25 : 0.50, isOverhang ? 0.18 : 0.62);
  }
  knot.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

  return knot;
}
