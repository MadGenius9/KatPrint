/**
 * Dual Generation Engine - Organic / Artistic Text-to-3D Provider Interface.
 *
 * Provides a clean, extensible architectural abstraction for neural mesh generation
 * (e.g. Tripo3D, CSM 3D, Meshy, Rodin, Shap-E, or local stable-fast-3d workers)
 * while clearly reporting unconfigured state without crashing or faking primitives.
 */

import * as THREE from 'three';

export interface OrganicGenerationJob {
  id: string;
  prompt: string;
  status: 'not_configured' | 'queued' | 'processing' | 'completed' | 'failed';
  progress: number;
  errorMessage?: string;
  resultMeshUrl?: string;
  createdAt: string;
}

export interface OrganicProviderConfig {
  isConfigured: boolean;
  providerName: string;
  endpoint?: string;
  apiKeySet: boolean;
  supportedFormats: ('stl' | 'obj' | 'gltf' | 'glb')[];
}

export interface OrganicMeshProvider {
  generateFromText(prompt: string): Promise<OrganicGenerationJob>;
  generateFromImage(image: Blob | File | string): Promise<OrganicGenerationJob>;
  getJobStatus(jobId: string): Promise<OrganicGenerationJob>;
  downloadMesh(jobId: string): Promise<THREE.BufferGeometry>;
}

export class OrganicMeshService implements OrganicMeshProvider {
  private static instance: OrganicMeshService;

  public static getInstance(): OrganicMeshService {
    if (!OrganicMeshService.instance) {
      OrganicMeshService.instance = new OrganicMeshService();
    }
    return OrganicMeshService.instance;
  }

  public getProviderConfig(): OrganicProviderConfig {
    return {
      isConfigured: false,
      providerName: 'Neural Text-to-3D Provider',
      apiKeySet: false,
      supportedFormats: ['gltf', 'glb', 'stl', 'obj'],
    };
  }

  /**
   * Request organic mesh generation.
   * If not configured, throws an explicit, informative error with code ORGANIC_UNCONFIGURED.
   */
  public async generateFromText(prompt: string): Promise<OrganicGenerationJob> {
    const config = this.getProviderConfig();
    if (!config.isConfigured) {
      const err = new Error(
        `This design requires the Organic 3D Engine, which is not configured. The requested model ("${prompt}") requires a Text-to-3D neural mesh engine.`
      );
      (err as any).category = 'ORGANIC_UNCONFIGURED';
      (err as any).canSimplifyToParametric = true;
      throw err;
    }

    return {
      id: `organic-${Date.now()}`,
      prompt,
      status: 'not_configured',
      progress: 0,
      errorMessage: 'Organic mesh generation provider not configured.',
      createdAt: new Date().toISOString(),
    };
  }

  public async generateFromImage(image: Blob | File | string): Promise<OrganicGenerationJob> {
    const config = this.getProviderConfig();
    if (!config.isConfigured) {
      const err = new Error(
        'This design requires the Organic 3D Engine, which is not configured. Neural Image-to-3D generation requires an external provider key.'
      );
      (err as any).category = 'ORGANIC_UNCONFIGURED';
      throw err;
    }

    return {
      id: `organic-img-${Date.now()}`,
      prompt: 'Image Reconstruction',
      status: 'not_configured',
      progress: 0,
      createdAt: new Date().toISOString(),
    };
  }

  public async getJobStatus(jobId: string): Promise<OrganicGenerationJob> {
    return {
      id: jobId,
      prompt: '',
      status: 'not_configured',
      progress: 0,
      errorMessage: 'Organic mesh generation provider not configured.',
      createdAt: new Date().toISOString(),
    };
  }

  public async downloadMesh(jobId: string): Promise<THREE.BufferGeometry> {
    throw new Error('Organic mesh provider not configured.');
  }

  // Alias for backward compatibility
  public async requestMeshGeneration(prompt: string): Promise<OrganicGenerationJob> {
    return this.generateFromText(prompt);
  }

  public async getGenerationStatus(jobId: string): Promise<OrganicGenerationJob> {
    return this.getJobStatus(jobId);
  }
}

export const organicMeshService = OrganicMeshService.getInstance();
