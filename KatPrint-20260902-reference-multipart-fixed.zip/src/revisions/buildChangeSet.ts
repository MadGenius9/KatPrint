import {
  DesignChangeSet,
  ModelVersion,
  KatPrintProject,
  RevisionRequest,
} from '../projects/projectTypes';

export function constructTargetedRevisionPrompt(
  instruction: string,
  changeSet: DesignChangeSet,
  activeVersion: ModelVersion,
  project?: KatPrintProject
): string {
  const changesFormatted = changeSet.requestedChanges
    .map((c) => `• [MODIFY] ${c.feature}: ${c.change}${c.fromValue ? ` (was: ${c.fromValue} → target: ${c.toValue || 'updated'})` : ''}`)
    .join('\n');

  const preservedFormatted = changeSet.preservedFeatures
    .map((p) => `• [PRESERVE] ${p}`)
    .join('\n');

  const memory = project?.projectMemory;
  const decisionsFormatted = memory?.importantDecisions?.length
    ? `\nIMPORTANT PROJECT DECISIONS (DO NOT VIOLATE):\n${memory.importantDecisions.map((d) => `• ${d}`).join('\n')}`
    : '';

  const rejectionsFormatted = memory?.userRejectedOptions?.length
    ? `\nREJECTED DESIGN DIRECTIONS (STRICTLY FORBIDDEN):\n${memory.userRejectedOptions.map((r) => `• ${r}`).join('\n')}`
    : '';

  return `USER REVISION INSTRUCTION: "${instruction}"

TARGETED CHANGE DIRECTIVES:
${changesFormatted}

PRESERVED FEATURES (DO NOT DRIFT OR REMOVE):
${preservedFormatted}${decisionsFormatted}${rejectionsFormatted}

ACTIVE SPECIFICATION BASELINE:
${JSON.stringify(changeSet.newDesignSpecification, null, 2)}

Modify the existing CAD code to apply ONLY the requested changes. Preserve all unchanged geometry, mounting interfaces, and dimensions.`;
}
