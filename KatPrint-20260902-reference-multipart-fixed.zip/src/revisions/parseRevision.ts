import {
  KatPrintProject,
  ModelVersion,
  DesignChangeSet,
  DesignChange,
  DesignSpecification,
} from '../projects/projectTypes';
import { validateDesignSpecification } from '../engine/designIntent/designSpecification';

export function parseRevisionInstruction(
  instruction: string,
  activeVersion: ModelVersion,
  project?: KatPrintProject
): DesignChangeSet {
  const text = instruction.trim();
  const lower = text.toLowerCase();

  // 1. Check for Natural Language Undo ("undo that", "go back", "revert last change", "go back to before...")
  if (
    /^(?:undo|undo that|go back|revert|revert that|cancel that|remove the last change)/i.test(lower) ||
    lower.includes('go back to the version before') ||
    lower.includes('go back to before')
  ) {
    let targetVersionId: string | undefined;
    if (project && project.versions && project.versions.length > 1) {
      // If user says "go back to before the screw holes" or "go back to version before cable opening"
      if (lower.includes('before')) {
        const afterBefore = lower.split('before')[1]?.trim().replace(/^the\s+/i, '').replace(/^that\s+/i, '');
        if (afterBefore) {
          const keyword = afterBefore.toLowerCase();
          // Find first version that introduced this feature
          const introIndex = project.versions.findIndex((v) => {
            const labelMatch = v.label?.toLowerCase().includes(keyword);
            const summaryMatch = v.changeSummary?.toLowerCase().includes(keyword);
            const instructionMatch = v.userInstruction?.toLowerCase().includes(keyword);
            const featuresMatch = v.designSpecification?.requiredFeatures?.some((f) =>
              f.name.toLowerCase().includes(keyword) || f.description?.toLowerCase().includes(keyword)
            );
            return labelMatch || summaryMatch || instructionMatch || featuresMatch;
          });

          if (introIndex > 0) {
            // Target is the version immediately BEFORE it was introduced
            targetVersionId = project.versions[introIndex - 1].id;
          } else {
            // Fallback: search backwards for a version lacking this keyword
            const matchVer = project.versions
              .slice()
              .reverse()
              .find((v) => {
                const labelMatch = v.label?.toLowerCase().includes(keyword);
                const summaryMatch = v.changeSummary?.toLowerCase().includes(keyword);
                return !labelMatch && !summaryMatch && v.id !== activeVersion.id;
              });
            if (matchVer) targetVersionId = matchVer.id;
          }
        }
      }

      if (!targetVersionId) {
        // Find previous version in timeline
        const currentIndex = project.versions.findIndex((v) => v.id === activeVersion.id);
        if (currentIndex > 0) {
          targetVersionId = project.versions[currentIndex - 1].id;
        } else if (project.versions.length >= 2) {
          targetVersionId = project.versions[project.versions.length - 2].id;
        }
      }
    }

    return {
      requestedChanges: [
        {
          feature: 'Project History',
          change: 'Revert to previous stable version state',
          category: 'feature',
        },
      ],
      preservedFeatures: ['All baseline project requirements'],
      potentiallyAffectedRequirements: ['Last applied revision modifications'],
      newDesignSpecification: validateDesignSpecification(activeVersion.designSpecification, activeVersion.prompt || instruction),
      confidence: 0.95,
      isNaturalUndo: true,
      targetRestoreVersionId: targetVersionId,
      explanation: `Natural undo requested: reverting to previous version state.`,
    };
  }

  const spec: DesignSpecification = validateDesignSpecification(
    activeVersion.designSpecification,
    activeVersion.prompt || instruction
  );
  const currentDims = activeVersion.geometryMetadata?.dimensions || { x: 100, y: 60, z: 25 };
  const requestedChanges: DesignChange[] = [];
  const preservedFeatures: string[] = [];

  // Track existing features
  const existingFeatureNames = (spec.requiredFeatures || []).map((f) => f.name);

  // 2. Relative dimensional adjustments
  if (!spec.explicitDimensions) spec.explicitDimensions = [];
  if (!spec.requiredFeatures) spec.requiredFeatures = [];
  if (!spec.structuralRequirements) spec.structuralRequirements = [];

  const getDimValue = (axis: 'x' | 'y' | 'z', fallback: number): number => {
    const found = spec.explicitDimensions.find((d) => d.axis === axis);
    return found ? found.value : fallback;
  };

  const setDimValue = (axis: 'x' | 'y' | 'z', name: string, value: number) => {
    const existing = spec.explicitDimensions.find((d) => d.axis === axis);
    if (existing) {
      existing.value = value;
    } else {
      spec.explicitDimensions.push({
        name,
        value,
        axis,
        source: 'explicit',
      });
    }
  };

  // 2a. Width
  const widthAddMatch = lower.match(/(?:make (?:it |the base |the body )?)?(\d+(?:\.\d+)?)\s*mm\s*wider/i) ||
                        lower.match(/widen (?:the base |it |the body )?by\s*(\d+(?:\.\d+)?)\s*mm/i) ||
                        lower.match(/(?:increase|add)\s*(?:the\s+)?width\s*(?:by\s+)?(\d+(?:\.\d+)?)\s*mm/i);
  if (widthAddMatch) {
    const delta = parseFloat(widthAddMatch[1]);
    const oldW = getDimValue('x', currentDims.x);
    const newW = Number((oldW + delta).toFixed(1));
    setDimValue('x', 'Width', newW);

    requestedChanges.push({
      feature: 'Width Dimension',
      change: `Increase width by ${delta} mm`,
      fromValue: `${oldW} mm`,
      toValue: `${newW} mm`,
      category: 'dimension',
    });
  }

  const widthNarrowMatch = lower.match(/(?:make (?:it |the base )?)?(\d+(?:\.\d+)?)\s*mm\s*(?:narrower|smaller in width)/i) ||
                           lower.match(/(?:decrease|reduce)\s*(?:the\s+)?width\s*(?:by\s+)?(\d+(?:\.\d+)?)\s*mm/i);
  if (widthNarrowMatch) {
    const delta = parseFloat(widthNarrowMatch[1]);
    const oldW = getDimValue('x', currentDims.x);
    const newW = Math.max(10, Number((oldW - delta).toFixed(1)));
    setDimValue('x', 'Width', newW);

    requestedChanges.push({
      feature: 'Width Dimension',
      change: `Decrease width by ${delta} mm`,
      fromValue: `${oldW} mm`,
      toValue: `${newW} mm`,
      category: 'dimension',
    });
  }

  // 2b. Height
  if (lower.includes('double the height') || lower.includes('twice as tall')) {
    const oldH = getDimValue('z', currentDims.z);
    const newH = Number((oldH * 2).toFixed(1));
    setDimValue('z', 'Height', newH);

    requestedChanges.push({
      feature: 'Height Dimension',
      change: `Double vertical height`,
      fromValue: `${oldH} mm`,
      toValue: `${newH} mm`,
      category: 'dimension',
    });
  }

  const heightAddMatch = lower.match(/(?:make (?:it )?)?(\d+(?:\.\d+)?)\s*mm\s*taller/i) ||
                         lower.match(/(?:increase|add)\s*(?:the\s+)?height\s*(?:by\s+)?(\d+(?:\.\d+)?)\s*mm/i);
  if (heightAddMatch) {
    const delta = parseFloat(heightAddMatch[1]);
    const oldH = getDimValue('z', currentDims.z);
    const newH = Number((oldH + delta).toFixed(1));
    setDimValue('z', 'Height', newH);

    requestedChanges.push({
      feature: 'Height Dimension',
      change: `Increase height by ${delta} mm`,
      fromValue: `${oldH} mm`,
      toValue: `${newH} mm`,
      category: 'dimension',
    });
  }

  // 2c. Wall Thickness
  const wallMatch = lower.match(/walls?\s*(\d+(?:\.\d+)?)\s*mm\s*thicker/i) ||
                    lower.match(/make (?:the )?walls?\s*(\d+(?:\.\d+)?)\s*mm/i);
  if (wallMatch) {
    const val = parseFloat(wallMatch[1]);
    const oldWall = 3.0;
    const newWall = lower.includes('thicker') ? Number((oldWall + val).toFixed(1)) : val;
    spec.structuralRequirements.push(`Wall thickness ${newWall}mm`);

    requestedChanges.push({
      feature: 'Wall Thickness',
      change: lower.includes('thicker') ? `Thicken walls by ${val} mm` : `Set wall thickness to ${val} mm`,
      fromValue: `${oldWall} mm`,
      toValue: `${newWall} mm`,
      category: 'dimension',
    });
  }

  // 3. Feature additions
  if (lower.includes('mounting hole') || lower.includes('screw hole') || lower.includes('bolt hole')) {
    const countMatch = lower.match(/(?:add|with)\s+(\w+|\d+)\s*(?:countersunk\s*)?(?:mounting|screw|bolt)?\s*holes?/i);
    let count = 2;
    if (countMatch) {
      if (countMatch[1] === 'two' || countMatch[1] === '2') count = 2;
      else if (countMatch[1] === 'four' || countMatch[1] === '4') count = 4;
      else if (countMatch[1] === 'three' || countMatch[1] === '3') count = 3;
      else if (!isNaN(parseInt(countMatch[1]))) count = parseInt(countMatch[1]);
    }
    const isCountersunk = lower.includes('countersunk') || lower.includes('countersink');

    requestedChanges.push({
      feature: 'Mounting Holes',
      change: `Add ${count} ${isCountersunk ? 'countersunk ' : ''}mounting fastener holes`,
      toValue: `${count} holes`,
      category: 'interface',
    });

    spec.requiredFeatures.push({
      id: `feat_${Date.now()}_holes`,
      name: `${count} Mounting Fastener Holes`,
      description: `${count} holes for mechanical screw mounting${isCountersunk ? ' with countersinks' : ''}`,
      source: 'explicit',
      confidence: 1,
    });
  }

  if (lower.includes('cable') && (lower.includes('slot') || lower.includes('opening') || lower.includes('hole') || lower.includes('pass'))) {
    requestedChanges.push({
      feature: 'Cable Clearance',
      change: 'Add cable routing pass-through slot/opening',
      toValue: 'Cable routing opening',
      category: 'feature',
    });

    spec.requiredFeatures.push({
      id: `feat_${Date.now()}_cable`,
      name: 'Cable Pass-Through Channel',
      description: 'Dedicated slot for wire/cable clearance',
      source: 'explicit',
      confidence: 1,
    });
  }

  if (lower.includes('round') && (lower.includes('corner') || lower.includes('front') || lower.includes('edge'))) {
    requestedChanges.push({
      feature: 'Corner Radius / Fillet',
      change: 'Apply smooth rounding/fillet to outer perimeter corners',
      toValue: 'Filleted corners',
      category: 'aesthetic',
    });
  }

  // 4. Pronoun & Context matching ("move those holes", "make that opening smaller")
  if (lower.includes('those holes') || lower.includes('the holes')) {
    if (lower.includes('farther apart') || lower.includes('outward') || lower.includes('wider spacing')) {
      requestedChanges.push({
        feature: 'Hole Spacing',
        change: 'Increase distance between mounting fastener holes',
        category: 'interface',
      });
    }
  }

  // If no specific pattern hit, create general intent change
  if (requestedChanges.length === 0) {
    requestedChanges.push({
      feature: 'Design Geometry',
      change: text,
      category: 'feature',
    });
  }

  // Determine preserved features from existing spec
  for (const name of existingFeatureNames) {
    const isTargeted = requestedChanges.some((c) => c.feature.toLowerCase().includes(name.toLowerCase()) || name.toLowerCase().includes(c.feature.toLowerCase()));
    if (!isTargeted && !preservedFeatures.includes(name)) {
      preservedFeatures.push(name);
    }
  }

  // Always preserve key manufacturing constraints
  if (!preservedFeatures.includes('Flat Z=0 print bed adhesion base')) {
    preservedFeatures.push('Flat Z=0 print bed adhesion base');
  }
  if (!preservedFeatures.includes('Manifold watertight solid boundaries')) {
    preservedFeatures.push('Manifold watertight solid boundaries');
  }

  return {
    requestedChanges,
    preservedFeatures,
    potentiallyAffectedRequirements: requestedChanges.map((c) => c.feature),
    newDesignSpecification: spec,
    confidence: requestedChanges.length > 0 ? 0.92 : 0.8,
    isNaturalUndo: false,
    explanation: `Interpreted revision: ${requestedChanges.map((c) => c.change).join(', ')}.`,
  };
}
