import React, { useState } from 'react';
import {
  Camera,
  Upload,
  Cpu,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Info,
} from 'lucide-react';
import { photoToMesh, PhotoToMeshResult } from '../services/photoToMesh';
import * as THREE from 'three';

interface PhotoToMeshEditorProps {
  onGeometryGenerated: (geom: THREE.BufferGeometry) => void;
}

export const PhotoToMeshEditor: React.FC<PhotoToMeshEditorProps> = ({
  onGeometryGenerated,
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [diagnostics, setDiagnostics] = useState<PhotoToMeshResult | null>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    setPreviewUrl(url);

    setIsProcessing(true);
    try {
      const result = await photoToMesh(file);
      setDiagnostics(result);
      if (result.geometry) {
        onGeometryGenerated(result.geometry);
      }
    } catch (err: any) {
      console.error('PhotoToMesh failed:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSampleRun = async () => {
    setIsProcessing(true);
    try {
      const result = await photoToMesh('sample_object.png');
      setDiagnostics(result);
      if (result.geometry) {
        onGeometryGenerated(result.geometry);
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex flex-col gap-4 text-kf-text">
      <div className="flex items-center justify-between">
        <label htmlFor="file-upload-photo" className="text-xs font-semibold uppercase tracking-wider text-kf-muted font-mono flex items-center gap-1.5">
          <Camera className="w-3.5 h-3.5 text-kf-pink" />
          <span>Photo to Neural Mesh (Stub)</span>
        </label>
        <span className="text-[11px] text-kf-warn font-mono bg-kf-warn/10 border border-kf-warn/30 px-2 py-0.5 rounded-md">
          Service Stub
        </span>
      </div>

      {/* Upload Box */}
      <div className="relative border-2 border-dashed border-kf-border hover:border-kf-pink/50 bg-kf-panel rounded-lg p-4 text-center transition">
        <input
          type="file"
          id="file-upload-photo"
          accept="image/*"
          onChange={handleFileUpload}
          disabled={isProcessing}
          className="absolute inset-0 opacity-0 cursor-pointer w-full h-full disabled:cursor-not-allowed"
        />
        <div className="flex flex-col items-center justify-center gap-2">
          {previewUrl ? (
            <img
              src={previewUrl}
              alt="Scan source"
              className="w-20 h-20 object-cover rounded-md border border-kf-border mb-1"
            />
          ) : (
            <div className="w-12 h-12 rounded-full bg-kf-panel-2 border border-kf-border flex items-center justify-center text-kf-pink">
              <Upload className="w-5 h-5" />
            </div>
          )}
          <div className="flex flex-col">
            <span className="text-xs font-medium text-kf-text">
              Upload object photograph or scan reference
            </span>
            <span className="text-[11px] text-kf-muted">
              Photogrammetry provider service module ready for pipeline ingestion
            </span>
          </div>
        </div>
      </div>

      <button
        type="button"
        id="btn-run-photo-mesh"
        onClick={handleSampleRun}
        disabled={isProcessing}
        className="w-full flex items-center justify-center gap-2 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-50 text-[#0A0004] font-semibold py-2.5 px-3 rounded-md text-xs transition shadow-md shadow-kf-pink/20"
      >
        {isProcessing ? (
          <>
            <RefreshCw className="w-4 h-4 animate-spin text-[#0A0004]" />
            <span>Reconstructing Watertight Geometry...</span>
          </>
        ) : (
          <>
            <Cpu className="w-4 h-4 text-[#0A0004]" />
            <span>Run Neural Reconstruction Test</span>
          </>
        )}
      </button>

      {/* Provider & Watertightness Audit Card */}
      {diagnostics && (
        <div className="border border-kf-border bg-kf-panel rounded-lg p-3.5 flex flex-col gap-2.5 shadow-sm">
          <div className="flex items-center justify-between border-b border-kf-border pb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-kf-text font-mono">
              Mesh Diagnostics
            </span>
            <span
              className={`text-[11px] font-mono px-2 py-0.5 rounded-md flex items-center gap-1 border ${
                diagnostics.isManifold
                  ? 'bg-kf-ok/10 border-kf-ok/40 text-kf-ok'
                  : 'bg-kf-fail/10 border-kf-fail/40 text-kf-fail'
              }`}
            >
              {diagnostics.isManifold ? (
                <>
                  <CheckCircle2 className="w-3 h-3" /> Manifold & Watertight
                </>
              ) : (
                <>
                  <AlertTriangle className="w-3 h-3" /> Non-Manifold Edges
                </>
              )}
            </span>
          </div>

          {diagnostics.warnings.map((warn, i) => (
            <div
              key={i}
              className="bg-kf-warn/10 border border-kf-warn/40 p-2.5 rounded-md text-[11px] text-kf-warn flex items-start gap-1.5"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-kf-warn shrink-0 mt-0.5" />
              <span>{warn}</span>
            </div>
          ))}

          <div className="bg-kf-panel-2 border border-kf-border p-2.5 rounded-md text-[11px] text-kf-muted flex items-start gap-2">
            <Info className="w-4 h-4 text-kf-pink shrink-0 mt-0.5" />
            <span className="font-mono text-[10px] leading-relaxed">
              {diagnostics.providerNote}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
