import React, { useState, useEffect, useRef } from 'react';
import {
  SemanticFeatureModel,
  SemanticFeature,
} from '../../features/featureTypes';
import { getFeatureSelectionAvailability, FeatureSelectionDiagnostics } from '../../features/featureSelection';
import { FeatureParameterEditor } from './FeatureParameterEditor';
import {
  Layers,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  XCircle,
  ChevronDown,
  ChevronRight,
  Sliders,
  Sparkles,
  Link,
  Target,
  Box,
  Eye,
  X,
  Activity,
  Cpu,
  ShieldCheck,
} from 'lucide-react';
import { getRelationshipSummary } from '../../features/featureRelationships';

interface FeatureInspectorProps {
  featureModel?: SemanticFeatureModel | null;
  cadCode?: string;
  selectedFeatureId?: string | null;
  selectedFeatureIds?: string[];
  selectionDiagnostics?: FeatureSelectionDiagnostics | null;
  onSelectFeature?: (featureId: string | null) => void;
  onFocusFeature?: (featureId: string) => void;
  onUpdateParameter?: (parameterId: string, newValue: number | string | boolean) => void;
  onToggleLock?: (parameterId: string, currentLocked: boolean) => void;
  onReconstructFeatureModel?: () => void;
  isApplying?: boolean;
  isReadOnly?: boolean;
}

export const FeatureInspector: React.FC<FeatureInspectorProps> = ({
  featureModel,
  cadCode,
  selectedFeatureId: externalSelectedFeatureId,
  selectedFeatureIds: externalSelectedFeatureIds,
  selectionDiagnostics,
  onSelectFeature,
  onFocusFeature,
  onUpdateParameter,
  onToggleLock,
  onReconstructFeatureModel,
  isApplying,
  isReadOnly = false,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [showDiagnosticsDetail, setShowDiagnosticsDetail] = useState(false);
  const [localSelectedFeatureId, setLocalSelectedFeatureId] = useState<string | null>(null);
  const featureItemRefs = useRef<Map<string, HTMLDivElement>>(new Map());

  const activeSelectedId =
    externalSelectedFeatureId !== undefined
      ? externalSelectedFeatureId
      : localSelectedFeatureId;

  const activeSelectedIds =
    externalSelectedFeatureIds && externalSelectedFeatureIds.length > 0
      ? externalSelectedFeatureIds
      : activeSelectedId
      ? [activeSelectedId]
      : [];

  const handleSelectFeature = (featureId: string | null) => {
    if (onSelectFeature) {
      onSelectFeature(featureId);
    } else {
      setLocalSelectedFeatureId(featureId);
    }
  };

  // Auto-scroll to selected feature if selected from 3D viewport
  useEffect(() => {
    if (activeSelectedId && !isCollapsed) {
      const el = featureItemRefs.current.get(activeSelectedId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }
  }, [activeSelectedId, isCollapsed]);

  if (!featureModel) {
    return (
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs text-slate-600 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-slate-500" />
            <span className="font-semibold text-slate-700">Semantic Feature Model</span>
          </div>
          {onReconstructFeatureModel && !isReadOnly && (
            <button
              type="button"
              onClick={onReconstructFeatureModel}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Analyze & Upgrade Model
            </button>
          )}
        </div>
        <p className="mt-2 text-slate-500 text-[11px] leading-relaxed">
          This model was generated with a legacy format. Click "Analyze & Upgrade Model" to detect
          identifiable CAD features and enable direct parameter editing.
        </p>
      </div>
    );
  }

  const { features, parameters, relationships, codeBindings } = featureModel;

  const getStatusBadge = (feat: SemanticFeature) => {
    switch (feat.status) {
      case 'verified':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800">
            <CheckCircle2 className="w-3 h-3" />
            Verified
          </span>
        );
      case 'failed':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-100 text-rose-800">
            <XCircle className="w-3 h-3" />
            Failed
          </span>
        );
      case 'planned':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-100 text-blue-800">
            <Sliders className="w-3 h-3" />
            Planned
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-200 text-slate-700">
            <HelpCircle className="w-3 h-3" />
            Unknown
          </span>
        );
    }
  };

  const getFeatureParamSnippet = (feat: SemanticFeature) => {
    const p = feat.parameters;
    if (p.diameter) return `Ø ${p.diameter} mm`;
    if (p.width && p.depth && (p.height || p.thickness)) {
      return `${p.width} × ${p.depth} × ${p.height || p.thickness} mm`;
    }
    if (p.width && p.length) return `${p.width} × ${p.length} mm`;
    if (p.thickness) return `t = ${p.thickness} mm`;
    if (p.radius) return `R ${p.radius} mm`;
    if (p.angleDeg) return `${p.angleDeg}°`;
    return null;
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden text-slate-800">
      {/* Header */}
      <div
        className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between cursor-pointer select-none hover:bg-slate-100/80 transition"
        onClick={() => setIsCollapsed(!isCollapsed)}
      >
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-600" />
          <span className="font-semibold text-xs tracking-wide uppercase text-slate-700">
            Model Features ({features.length})
          </span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <span className="text-emerald-700 font-medium">
              {features.filter((f) => f.status === 'verified').length} verified
            </span>
          </div>
          {isCollapsed ? (
            <ChevronRight className="w-4 h-4 text-slate-400" />
          ) : (
            <ChevronDown className="w-4 h-4 text-slate-400" />
          )}
        </div>
      </div>

      {/* Multi-Selection Banner */}
      {!isCollapsed && activeSelectedIds.length > 1 && (
        <div className="bg-indigo-50 border-b border-indigo-100 px-3.5 py-2 flex items-center justify-between text-xs text-indigo-900">
          <div className="flex items-center gap-2">
            <Target className="w-3.5 h-3.5 text-indigo-600" />
            <span className="font-semibold">{activeSelectedIds.length} Features Selected in 3D</span>
          </div>
          <button
            type="button"
            onClick={() => handleSelectFeature(null)}
            className="text-[11px] font-medium text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
          >
            <X className="w-3 h-3" />
            Clear Selection
          </button>
        </div>
      )}

      {/* World-Space ABI Diagnostics Banner (if violations exist) */}
      {!isCollapsed && featureModel.selectionValidation && !featureModel.selectionValidation.valid && (
        <div className="bg-amber-50/80 border-b border-amber-200 px-3.5 py-2 text-xs text-amber-900 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div className="min-w-0">
            <div className="font-semibold">Spatial Selection ABI Violation Detected</div>
            <div className="text-[11px] text-amber-700 leading-normal">
              {featureModel.selectionValidation.invalidFeatureIds.length} feature(s) transformed outside their wrapper in main().
              3D pick proxies are disabled for those features until repaired to guarantee spatial accuracy.
            </div>
          </div>
        </div>
      )}

      {!isCollapsed && (
        <div className="p-3 space-y-2 max-h-[480px] overflow-y-auto">
          {features.map((feature) => {
            const isSelected = activeSelectedIds.includes(feature.id);
            const isPrimary = activeSelectedId === feature.id;
            const snippet = getFeatureParamSnippet(feature);
            const outgoingRels = relationships.filter((r) => r.sourceFeatureId === feature.id);
            const availability = getFeatureSelectionAvailability(feature, featureModel, cadCode, featureModel.selectionValidation);
            const isPickable = availability.isPickable;

            return (
              <div
                key={feature.id}
                ref={(el) => {
                  if (el) featureItemRefs.current.set(feature.id, el);
                  else featureItemRefs.current.delete(feature.id);
                }}
                className={`rounded-lg border transition ${
                  isSelected
                    ? isPrimary
                      ? 'border-cyan-500 bg-cyan-50/40 ring-2 ring-cyan-400 shadow-xs'
                      : 'border-indigo-400 bg-indigo-50/30 ring-1 ring-indigo-300'
                    : 'border-slate-200 bg-slate-50/50 hover:bg-white hover:border-slate-300'
                }`}
              >
                {/* Feature Summary Row */}
                <div
                  className="p-2.5 flex items-center justify-between cursor-pointer select-none"
                  onClick={() => handleSelectFeature(isSelected && activeSelectedIds.length === 1 ? null : feature.id)}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <button
                      type="button"
                      className="text-slate-400 hover:text-slate-600 transition"
                      aria-label="Toggle feature details"
                    >
                      {isSelected ? (
                        <ChevronDown className="w-3.5 h-3.5 text-cyan-600" />
                      ) : (
                        <ChevronRight className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-xs text-slate-900 truncate">
                          {feature.label}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500 px-1.5 py-0.2 rounded bg-slate-100 border border-slate-200">
                          {feature.type}
                        </span>
                        {isSelected && (
                          <span className="inline-flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-cyan-100 text-cyan-800 border border-cyan-200">
                            <Target className="w-2.5 h-2.5" />
                            3D Selected
                          </span>
                        )}
                        {availability.worldSpaceValid === false ? (
                          <span
                            className="text-[9px] text-amber-800 bg-amber-100 px-1.5 py-0.2 rounded border border-amber-300 font-medium"
                            title={availability.reason || 'Outer transform in main() violates World-Space ABI'}
                          >
                            Spatial Misplacement
                          </span>
                        ) : availability.isDeadWrapper ? (
                          <span
                            className="text-[9px] text-rose-700 bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200"
                            title={availability.reason || 'Wrapper function not connected to main model geometry'}
                          >
                            Dead Wrapper
                          </span>
                        ) : !isPickable ? (
                          <span
                            className="text-[9px] text-amber-700 bg-amber-50 px-1 rounded border border-amber-200"
                            title={availability.reason || 'Feature function wrapper not found in code'}
                          >
                            Unbound
                          </span>
                        ) : availability.confidence === 'exact' ? (
                          <span
                            className="text-[9px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200 font-medium"
                            title="Exact 3D World-Space Picking Proven"
                          >
                            Exact Pick
                          </span>
                        ) : availability.confidence === 'strong' ? (
                          <span
                            className="text-[9px] text-indigo-700 bg-indigo-50 px-1.5 py-0.2 rounded border border-indigo-200 font-medium"
                            title="Strong Semantic Picking"
                          >
                            3D Pickable
                          </span>
                        ) : (
                          <span
                            className="text-[9px] text-slate-600 bg-slate-100 px-1.5 py-0.2 rounded border border-slate-200"
                            title="Approximate Legacy Picking"
                          >
                            Approx Pick
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate mt-0.5">
                        {feature.purpose}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 ml-2">
                    {onFocusFeature && isPickable && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectFeature(feature.id);
                          onFocusFeature(feature.id);
                        }}
                        title="Focus Camera in 3D Viewport"
                        className="p-1 rounded text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {snippet && (
                      <span className="text-[11px] font-mono font-medium text-slate-600 bg-white border border-slate-200 px-1.5 py-0.5 rounded shadow-2xs">
                        {snippet}
                      </span>
                    )}
                    {getStatusBadge(feature)}
                  </div>
                </div>

                {/* Expanded Parameter & Relationship Detail */}
                {isSelected && (
                  <div className="px-3 pb-3 pt-1 border-t border-slate-200/80 space-y-2.5 bg-white/80 rounded-b-lg">
                    {/* Read-Only History Notice */}
                    {isReadOnly && (
                      <div className="text-[11px] text-amber-800 bg-amber-50 p-2 rounded border border-amber-200 flex items-center gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                        <span>Viewing historical version. Direct edits are disabled. Restore this version to edit.</span>
                      </div>
                    )}

                    {/* ABI Violation Detail (if any) */}
                    {availability.worldSpaceValid === false && availability.reason && (
                      <div className="text-[11px] text-amber-800 bg-amber-50 p-2 rounded border border-amber-200 flex items-start gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-semibold">Selection Suppressed: </span>
                          <span>{availability.reason}</span>
                        </div>
                      </div>
                    )}

                    {/* Verification Notes */}
                    {feature.verificationNotes && (
                      <div className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded border border-slate-200 flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{feature.verificationNotes}</span>
                      </div>
                    )}

                    {/* Relationships */}
                    {outgoingRels.length > 0 && (
                      <div className="space-y-1">
                        <div className="text-[10px] uppercase font-semibold text-slate-500 tracking-wider flex items-center gap-1">
                          <Link className="w-3 h-3" />
                          Feature Relationships
                        </div>
                        <div className="space-y-0.5">
                          {outgoingRels.map((rel) => (
                            <div
                              key={rel.id}
                              className="text-[11px] text-slate-600 bg-slate-50 px-2 py-1 rounded border border-slate-100"
                            >
                              {getRelationshipSummary(rel, features)}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Parameters Editor */}
                    {onUpdateParameter && !isReadOnly && (
                      <FeatureParameterEditor
                        feature={feature}
                        parameters={parameters}
                        model={featureModel}
                        onUpdateParameter={onUpdateParameter}
                        onToggleLock={onToggleLock}
                        isApplying={isApplying}
                      />
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Semantic Selection Diagnostics Footer */}
      {!isCollapsed && selectionDiagnostics && (
        <div className="border-t border-slate-200 bg-slate-50/80 px-3.5 py-2.5 text-[11px] text-slate-600">
          <div
            className="flex items-center justify-between cursor-pointer select-none"
            onClick={() => setShowDiagnosticsDetail(!showDiagnosticsDetail)}
          >
            <div className="flex items-center gap-1.5 font-medium text-slate-700">
              <Activity className="w-3.5 h-3.5 text-blue-600" />
              <span>3D Selection Engine</span>
            </div>
            <div className="flex items-center gap-2 font-mono text-[10px]">
              <span className="bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded border border-blue-200">
                {selectionDiagnostics.selectableFeatureCount}/{selectionDiagnostics.totalFeatures} Pickable
              </span>
              <span className="text-slate-400">
                {selectionDiagnostics.selectionProxyBuildMs.toFixed(1)}ms
              </span>
              {showDiagnosticsDetail ? (
                <ChevronDown className="w-3 h-3 text-slate-400" />
              ) : (
                <ChevronRight className="w-3 h-3 text-slate-400" />
              )}
            </div>
          </div>

          {showDiagnosticsDetail && (
            <div className="mt-2.5 pt-2 border-t border-slate-200/80 grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-600">
              <div className="bg-white p-2 rounded border border-slate-200 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Pick Proxies:</span>
                  <span className="font-semibold text-slate-800">{selectionDiagnostics.selectableFeatureCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Unselectable:</span>
                  <span className={selectionDiagnostics.unselectableFeatureCount > 0 ? 'text-amber-600 font-semibold' : 'text-slate-800'}>
                    {selectionDiagnostics.unselectableFeatureCount}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Proxy Cache:</span>
                  <span className="text-emerald-700 font-semibold">{selectionDiagnostics.featureSelectionCacheHit ? 'HIT (Cached)' : 'MISS (Built)'}</span>
                </div>
              </div>
              <div className="bg-white p-2 rounded border border-slate-200 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">ABI Status:</span>
                  <span className={selectionDiagnostics.worldSpaceValidationPassed ? 'text-emerald-700 font-semibold' : 'text-rose-600 font-semibold'}>
                    {selectionDiagnostics.worldSpaceValidationPassed ? 'VALID' : 'VIOLATION'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">ABI Violations:</span>
                  <span className="text-slate-800">{selectionDiagnostics.worldSpaceViolationCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Build Time:</span>
                  <span className="text-slate-800">{selectionDiagnostics.selectionProxyBuildMs.toFixed(1)} ms</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

