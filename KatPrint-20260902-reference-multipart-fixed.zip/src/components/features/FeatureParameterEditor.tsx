import React, { useState, useEffect } from 'react';
import {
  SemanticFeature,
  FeatureParameter,
  SemanticFeatureModel,
} from '../../features/featureTypes';
import { Lock, Unlock, Check, Sparkles } from 'lucide-react';

interface FeatureParameterEditorProps {
  feature: SemanticFeature;
  parameters: FeatureParameter[];
  model: SemanticFeatureModel;
  onUpdateParameter: (parameterId: string, newValue: number | string | boolean) => void;
  onToggleLock?: (parameterId: string, currentLocked: boolean) => void;
  isApplying?: boolean;
}

export const FeatureParameterEditor: React.FC<FeatureParameterEditorProps> = ({
  feature,
  parameters,
  model: _model,
  onUpdateParameter,
  onToggleLock,
  isApplying,
}) => {
  const featureParams = parameters.filter((p) => feature.parameterIds.includes(p.id) || p.featureId === feature.id);
  const [localValues, setLocalValues] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    featureParams.forEach((p) => {
      initial[p.id] = String(p.value);
    });
    return initial;
  });

  // Keep local values synchronized with prop changes (e.g. revisions, undo, feature switching)
  useEffect(() => {
    const nextValues: Record<string, string> = {};
    featureParams.forEach((p) => {
      nextValues[p.id] = String(p.value);
    });
    setLocalValues(nextValues);
  }, [feature.id, parameters]);

  const handleChange = (paramId: string, strVal: string) => {
    setLocalValues((prev) => ({ ...prev, [paramId]: strVal }));
  };

  const handleBlurOrEnter = (param: FeatureParameter) => {
    const raw = localValues[param.id];
    if (raw === undefined) return;

    if (param.unit === 'boolean' || typeof param.value === 'boolean') {
      const boolVal = raw === 'true';
      if (boolVal !== param.value) {
        onUpdateParameter(param.id, boolVal);
      }
      return;
    }

    const num = parseFloat(raw);
    if (!isNaN(num) && num !== param.value) {
      onUpdateParameter(param.id, num);
    }
  };

  if (featureParams.length === 0) {
    return (
      <div className="p-3 text-xs text-slate-500 italic bg-slate-50 rounded-md border border-slate-200">
        No direct editable parameters for this feature.
      </div>
    );
  }

  return (
    <div className="space-y-3 pt-2">
      <div className="text-xs font-semibold uppercase tracking-wider text-slate-600">
        Feature Parameters ({feature.label})
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {featureParams.map((param) => {
          const isNum = typeof param.value === 'number';
          const isBool = typeof param.value === 'boolean' || param.unit === 'boolean';
          const isLocked = !!param.locked;

          return (
            <div
              key={param.id}
              className={`p-2.5 rounded-lg border text-xs transition-colors ${
                isLocked
                  ? 'bg-slate-100/70 border-slate-300 text-slate-500'
                  : 'bg-white border-slate-200 hover:border-blue-300 shadow-sm'
              }`}
            >
              <div className="flex items-center justify-between gap-1 mb-1.5">
                <span className="font-medium text-slate-700 capitalize">
                  {param.name.replace(/([A-Z])/g, ' $1')}
                </span>
                <div className="flex items-center gap-1">
                  {param.critical && (
                    <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-amber-100 text-amber-800 rounded">
                      Critical
                    </span>
                  )}
                  {onToggleLock && (
                    <button
                      type="button"
                      onClick={() => onToggleLock(param.id, isLocked)}
                      title={isLocked ? 'Unlock parameter' : 'Lock parameter against accidental changes'}
                      className="p-0.5 text-slate-400 hover:text-slate-700 transition"
                    >
                      {isLocked ? (
                        <Lock className="w-3.5 h-3.5 text-amber-600" />
                      ) : (
                        <Unlock className="w-3.5 h-3.5" />
                      )}
                    </button>
                  )}
                </div>
              </div>

              {isBool ? (
                <label className="flex items-center gap-2 cursor-pointer mt-1">
                  <input
                    type="checkbox"
                    checked={param.value === true}
                    disabled={isLocked || isApplying}
                    onChange={(e) => {
                      onUpdateParameter(param.id, e.target.checked);
                    }}
                    className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                  />
                  <span className="text-slate-600">{param.value ? 'Enabled' : 'Disabled'}</span>
                </label>
              ) : (
                <div className="flex items-center gap-1.5">
                  <input
                    type={isNum ? 'number' : 'text'}
                    step={param.step ?? 0.5}
                    min={param.min}
                    max={param.max}
                    disabled={isLocked || isApplying}
                    value={localValues[param.id] ?? String(param.value)}
                    onChange={(e) => handleChange(param.id, e.target.value)}
                    onBlur={() => handleBlurOrEnter(param)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleBlurOrEnter(param);
                    }}
                    className="w-full px-2 py-1 text-xs font-mono bg-slate-50 border border-slate-300 rounded focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 disabled:opacity-50"
                  />
                  {param.unit && (
                    <span className="text-slate-500 font-mono text-[11px] select-none">
                      {param.unit}
                    </span>
                  )}
                </div>
              )}

              {param.description && (
                <div className="text-[10px] text-slate-600 mt-1 leading-tight">
                  {param.description}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
