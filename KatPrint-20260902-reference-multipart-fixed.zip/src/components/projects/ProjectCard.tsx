import React, { useState } from 'react';
import {
  Folder,
  Copy,
  Trash2,
  Edit2,
  Download,
  Star,
  CheckCircle2,
  Clock,
  Layers,
  Printer,
  ChevronRight,
  MoreVertical,
} from 'lucide-react';
import { KatPrintProject } from '../../projects/projectTypes';

interface ProjectCardProps {
  project: KatPrintProject;
  isActive?: boolean;
  onOpen: (project: KatPrintProject) => void;
  onDuplicate: (project: KatPrintProject) => void;
  onRename: (project: KatPrintProject, newName: string) => void;
  onDelete: (project: KatPrintProject) => void;
  onToggleFavorite: (project: KatPrintProject) => void;
  onExport: (project: KatPrintProject) => void;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({
  project,
  isActive = false,
  onOpen,
  onDuplicate,
  onRename,
  onDelete,
  onToggleFavorite,
  onExport,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(project.name);
  const [showMenu, setShowMenu] = useState(false);

  const versions = project?.versions || [];
  const activeVersion = versions.find((v) => v.id === project?.currentVersionId) ||
                        (versions.length > 0 ? versions[versions.length - 1] : null);

  const matchScore = activeVersion?.designMatchScore ?? activeVersion?.fidelityReview?.overallScore;
  const versionCount = versions.length;
  const currentVerNumber = activeVersion ? `V${activeVersion.versionNumber}` : 'V0';

  const formattedDate = new Date(project.updatedAt).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const handleSaveName = () => {
    if (editName.trim() && editName.trim() !== project.name) {
      onRename(project, editName.trim());
    }
    setIsEditing(false);
  };

  return (
    <div
      className={`group relative bg-kf-card/90 hover:bg-kf-card border rounded-xl overflow-hidden transition-all duration-200 shadow-md flex flex-col ${
        isActive ? 'border-kf-pink ring-1 ring-kf-pink/30' : 'border-kf-border hover:border-kf-pink/40'
      }`}
    >
      {/* Top Preview / Thumbnail Canvas */}
      <div
        className="relative h-44 bg-[#0A0507] flex items-center justify-center cursor-pointer overflow-hidden border-b border-kf-border/40"
        onClick={() => onOpen(project)}
      >
        {project.thumbnail || activeVersion?.thumbnail ? (
          <img
            src={project.thumbnail || activeVersion?.thumbnail}
            alt={project.name}
            className="w-full h-full object-contain p-2 group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="flex flex-col items-center gap-2 text-kf-muted">
            <Layers className="w-10 h-10 text-kf-pink/40" />
            <span className="text-[11px] font-mono">No 3D Preview Yet</span>
          </div>
        )}

        {/* Favorite Star Button */}
        <button
          type="button"
          aria-label={project.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(project);
          }}
          className="absolute top-2.5 right-2.5 p-1.5 rounded-lg bg-black/60 hover:bg-black/80 backdrop-blur-sm transition text-kf-text cursor-pointer"
        >
          <Star
            className={`w-4 h-4 ${
              project.isFavorite ? 'text-amber-400 fill-amber-400' : 'text-kf-muted hover:text-white'
            }`}
          />
        </button>

        {/* Version Badge */}
        <div className="absolute bottom-2.5 left-2.5 flex items-center gap-1.5">
          <span className="bg-black/70 backdrop-blur-sm border border-white/10 text-kf-pink font-mono text-[11px] font-bold px-2 py-0.5 rounded-md">
            {currentVerNumber}
          </span>
          {matchScore !== undefined && (
            <span
              className={`bg-black/70 backdrop-blur-sm border font-mono text-[11px] font-bold px-2 py-0.5 rounded-md ${
                matchScore >= 90
                  ? 'text-kf-pass border-kf-pass/40'
                  : matchScore >= 75
                  ? 'text-amber-400 border-amber-400/40'
                  : 'text-kf-fail border-kf-fail/40'
              }`}
            >
              {matchScore}% Match
            </span>
          )}
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 flex-1 flex flex-col justify-between gap-3">
        <div>
          {/* Title row */}
          <div className="flex items-start justify-between gap-2">
            {isEditing ? (
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                onBlur={handleSaveName}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSaveName();
                  if (e.key === 'Escape') setIsEditing(false);
                }}
                autoFocus
                className="w-full text-sm font-bold bg-kf-bg text-kf-text px-2 py-1 rounded border border-kf-pink outline-none"
              />
            ) : (
              <h3
                className="text-sm font-bold text-kf-text line-clamp-1 hover:text-kf-pink transition cursor-pointer"
                onClick={() => onOpen(project)}
                title={project.name}
              >
                {project.name}
              </h3>
            )}

            {/* Overflow Dropdown */}
            <div className="relative">
              <button
                type="button"
                aria-label="Project actions"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowMenu(!showMenu);
                }}
                className="p-1 rounded hover:bg-kf-hover text-kf-muted hover:text-kf-text transition cursor-pointer"
              >
                <MoreVertical className="w-4 h-4" />
              </button>

              {showMenu && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowMenu(false);
                    }}
                  />
                  <div className="absolute right-0 top-6 z-50 w-44 bg-kf-card border border-kf-border rounded-lg shadow-xl py-1 text-xs text-kf-text">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowMenu(false);
                        setIsEditing(true);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-kf-hover flex items-center gap-2"
                    >
                      <Edit2 className="w-3.5 h-3.5 text-kf-muted" />
                      <span>Rename Project</span>
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowMenu(false);
                        onDuplicate(project);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-kf-hover flex items-center gap-2"
                    >
                      <Copy className="w-3.5 h-3.5 text-kf-muted" />
                      <span>Duplicate</span>
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowMenu(false);
                        onExport(project);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-kf-hover flex items-center gap-2"
                    >
                      <Download className="w-3.5 h-3.5 text-kf-muted" />
                      <span>Export .katprint</span>
                    </button>
                    <div className="h-px bg-kf-border my-1" />
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowMenu(false);
                        onDelete(project);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-kf-fail/20 text-kf-fail flex items-center gap-2"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete Project</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Description / Category */}
          <p className="text-xs text-kf-muted mt-1 line-clamp-2">
            {activeVersion?.designSpecification?.primaryObject || project.originalPrompt}
          </p>
        </div>

        {/* Metadata Footer */}
        <div className="pt-2 border-t border-kf-border/40 flex items-center justify-between text-[11px] text-kf-muted">
          <div className="flex items-center gap-1.5" title={`Updated ${formattedDate}`}>
            <Clock className="w-3.5 h-3.5" />
            <span>{formattedDate}</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="font-mono text-kf-text/80">
              {versionCount} {versionCount === 1 ? 'ver' : 'vers'}
            </span>
            <button
              type="button"
              onClick={() => onOpen(project)}
              className="p-1 rounded bg-kf-pink/10 hover:bg-kf-pink text-kf-pink hover:text-[#0A0004] transition cursor-pointer"
              title="Open Project"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
