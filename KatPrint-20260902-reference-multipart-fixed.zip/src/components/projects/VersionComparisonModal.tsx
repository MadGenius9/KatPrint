import React, { useState, useMemo, useEffect, useRef } from 'react';
import * as THREE from 'three';
import {
  GitCompare,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Download,
  Layers,
  Sparkles,
  Columns,
  Maximize2,
} from 'lucide-react';
import { ModelVersion, KatPrintProject, VersionComparisonData } from '../../projects/projectTypes';
import { compareVersions } from '../../versions/compareVersions';
import { executeJscadCode } from '../../engine/jscadRunner';
import { sanitizeStlFilename } from '../../versions/versionService';

export interface VersionComparisonModalProps {
  project: KatPrintProject;
  initialVersionA?: ModelVersion | null;
  initialVersionB?: ModelVersion | null;
  versionA?: ModelVersion | null;
  versionB?: ModelVersion | null;
  onClose: () => void;
  onRestoreVersion?: (version: ModelVersion) => void;
  onExportVersionStl?: (version: ModelVersion) => void;
}

export const VersionComparisonModal: React.FC<VersionComparisonModalProps> = ({
  project,
  initialVersionA,
  initialVersionB,
  versionA: propVersionA,
  versionB: propVersionB,
  onClose,
  onRestoreVersion,
  onExportVersionStl,
}) => {
  if (!project || !project.versions || project.versions.length === 0) {
    return null;
  }

  const versions = project.versions;
  const initialA = propVersionA || initialVersionA;
  const initialB = propVersionB || initialVersionB;

  const [versionAId, setVersionAId] = useState<string>(
    initialA?.id || (versions.length >= 2 ? versions[versions.length - 2].id : versions[0]?.id || '')
  );
  const [versionBId, setVersionBId] = useState<string>(
    initialB?.id || (versions.length > 0 ? versions[versions.length - 1].id : '')
  );

  const [comparisonTab, setComparisonTab] = useState<'metrics' | 'features' | 'code'>('metrics');

  const versionA = versions.find((v) => v.id === versionAId) || versions[0];
  const versionB = versions.find((v) => v.id === versionBId) || versions[versions.length - 1];

  const comparisonData: VersionComparisonData | null = useMemo(() => {
    if (!versionA || !versionB) return null;
    return compareVersions(versionA, versionB);
  }, [versionA, versionB]);

  // Mini canvas previews for Version A and Version B
  const canvasRefA = useRef<HTMLCanvasElement>(null);
  const canvasRefB = useRef<HTMLCanvasElement>(null);
  const [previewErrorA, setPreviewErrorA] = useState(false);
  const [previewErrorB, setPreviewErrorB] = useState(false);

  useEffect(() => {
    if (!versionA || !canvasRefA.current) return;
    const ok = renderPreviewToCanvas(versionA.cadCode || '', canvasRefA.current);
    setPreviewErrorA(!ok);
  }, [versionA]);

  useEffect(() => {
    if (!versionB || !canvasRefB.current) return;
    const ok = renderPreviewToCanvas(versionB.cadCode || '', canvasRefB.current);
    setPreviewErrorB(!ok);
  }, [versionB]);

  const renderPreviewToCanvas = (code: string, canvas: HTMLCanvasElement): boolean => {
    if (!code || !code.trim()) return false;
    try {
      const geom = executeJscadCode(code);
      if (!geom || (geom.attributes.position && geom.attributes.position.count === 0)) {
        return false;
      }
      const scene = new THREE.Scene();
      scene.background = new THREE.Color(0x0a0507);

      const camera = new THREE.PerspectiveCamera(45, canvas.width / canvas.height, 1, 1000);
      const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
      renderer.setSize(canvas.clientWidth, canvas.clientHeight);

      geom.computeBoundingSphere();
      const radius = geom.boundingSphere?.radius || 50;
      const center = geom.boundingSphere?.center || new THREE.Vector3();

      const material = new THREE.MeshStandardMaterial({
        color: 0xff3366,
        metalness: 0.2,
        roughness: 0.4,
      });
      const mesh = new THREE.Mesh(geom, material);
      mesh.position.sub(center);
      scene.add(mesh);

      // Light setup
      const hemiLight = new THREE.HemisphereLight(0xffffff, 0x222222, 1.2);
      scene.add(hemiLight);
      const dirLight = new THREE.DirectionalLight(0xffffff, 1.0);
      dirLight.position.set(100, 150, 100);
      scene.add(dirLight);

      camera.position.set(radius * 1.8, radius * 1.5, radius * 2.0);
      camera.lookAt(0, 0, 0);
      renderer.render(scene, camera);
      return true;
    } catch (e) {
      console.warn('Error rendering version comparison thumbnail:', e);
      return false;
    }
  };

  if (!versionA || !versionB || !comparisonData) {
    return null;
  }

  const { dimensionDiffs, volumeDiff, triangleCountDiff, scoreDiff, addedFeatures, removedFeatures, preservedFeatures, specificationDiffs, featureModelDiff } =
    comparisonData;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-kf-card border border-kf-border rounded-2xl max-w-5xl w-full h-[90vh] flex flex-col shadow-2xl overflow-hidden text-kf-text">
        {/* Header */}
        <div className="p-4 border-b border-kf-border bg-kf-bg/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-kf-pink/10 text-kf-pink">
              <GitCompare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-kf-text">
                Compare Design Versions
              </h2>
              <p className="text-xs text-kf-muted">
                Inspect dimensional deltas, volume changes, and feature additions between any two versions.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-kf-hover text-kf-muted hover:text-kf-text text-sm font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Version Pickers Header */}
        <div className="p-4 bg-kf-bg/40 border-b border-kf-border grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Version A Selector */}
          <div className="bg-kf-card p-3 rounded-xl border border-kf-border flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-bold bg-kf-bg px-2 py-1 rounded border border-kf-border">
                Base (A)
              </span>
              <select
                value={versionAId}
                onChange={(e) => setVersionAId(e.target.value)}
                className="bg-kf-bg text-xs font-bold text-kf-text rounded px-2.5 py-1.5 border border-kf-border focus:border-kf-pink outline-none"
              >
                {versions.map((v) => (
                  <option key={v.id} value={v.id}>
                    V{v.versionNumber} — {v.label}
                  </option>
                ))}
              </select>
            </div>
            <button
              type="button"
              onClick={() => onRestoreVersion(versionA)}
              className="text-[11px] font-mono text-kf-muted hover:text-kf-pink flex items-center gap-1 transition cursor-pointer"
              title="Restore Version A"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Restore</span>
            </button>
          </div>

          {/* Version B Selector */}
          <div className="bg-kf-card p-3 rounded-xl border border-kf-pink/40 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-bold bg-kf-pink text-[#0A0004] px-2 py-1 rounded">
                Compare (B)
              </span>
              <select
                value={versionBId}
                onChange={(e) => setVersionBId(e.target.value)}
                className="bg-kf-bg text-xs font-bold text-kf-text rounded px-2.5 py-1.5 border border-kf-border focus:border-kf-pink outline-none"
              >
                {versions.map((v) => (
                  <option key={v.id} value={v.id}>
                    V{v.versionNumber} — {v.label}
                  </option>
                ))}
              </select>
            </div>
            <button
              type="button"
              onClick={() => onRestoreVersion(versionB)}
              className="text-[11px] font-mono text-kf-muted hover:text-kf-pink flex items-center gap-1 transition cursor-pointer"
              title="Restore Version B"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Restore</span>
            </button>
          </div>
        </div>

        {/* 3D Side-by-Side Thumbnails */}
        <div className="grid grid-cols-2 gap-4 p-4 bg-[#0A0507] border-b border-kf-border">
          <div className="relative h-44 rounded-xl overflow-hidden border border-kf-border/40 flex items-center justify-center bg-black/40">
            <canvas ref={canvasRefA} className={`w-full h-full object-contain ${previewErrorA ? 'hidden' : 'block'}`} />
            {previewErrorA && (
              <div className="p-4 text-center">
                <p className="text-xs text-kf-muted font-medium">Preview unavailable for this version.</p>
              </div>
            )}
            <div className="absolute top-2 left-2 bg-black/70 backdrop-blur-md px-2 py-0.5 rounded text-[11px] font-mono font-bold text-white border border-white/10">
              V{versionA.versionNumber} Preview
            </div>
          </div>
          <div className="relative h-44 rounded-xl overflow-hidden border border-kf-pink/30 flex items-center justify-center bg-black/40">
            <canvas ref={canvasRefB} className={`w-full h-full object-contain ${previewErrorB ? 'hidden' : 'block'}`} />
            {previewErrorB && (
              <div className="p-4 text-center">
                <p className="text-xs text-kf-muted font-medium">Preview unavailable for this version.</p>
              </div>
            )}
            <div className="absolute top-2 left-2 bg-black/70 backdrop-blur-md px-2 py-0.5 rounded text-[11px] font-mono font-bold text-kf-pink border border-kf-pink/30">
              V{versionB.versionNumber} Preview
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-kf-border bg-kf-bg/60">
          <button
            type="button"
            onClick={() => setComparisonTab('metrics')}
            className={`pb-2 px-3 text-xs font-mono font-bold border-b-2 transition cursor-pointer ${
              comparisonTab === 'metrics'
                ? 'border-kf-pink text-kf-pink'
                : 'border-transparent text-kf-muted hover:text-kf-text'
            }`}
          >
            Dimensional & Geometric Diffs
          </button>
          <button
            type="button"
            onClick={() => setComparisonTab('features')}
            className={`pb-2 px-3 text-xs font-mono font-bold border-b-2 transition cursor-pointer ${
              comparisonTab === 'features'
                ? 'border-kf-pink text-kf-pink'
                : 'border-transparent text-kf-muted hover:text-kf-text'
            }`}
          >
            Feature Diffs & Specifications ({addedFeatures.length + removedFeatures.length})
          </button>
          <button
            type="button"
            onClick={() => setComparisonTab('code')}
            className={`pb-2 px-3 text-xs font-mono font-bold border-b-2 transition cursor-pointer ${
              comparisonTab === 'code'
                ? 'border-kf-pink text-kf-pink'
                : 'border-transparent text-kf-muted hover:text-kf-text'
            }`}
          >
            JSCAD Script Changes
          </button>
        </div>

        {/* Comparison Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {comparisonTab === 'metrics' && (
            <div className="space-y-4">
              {/* Metrics Table */}
              <div className="border border-kf-border rounded-xl overflow-hidden">
                <table className="w-full text-xs text-left">
                  <thead className="bg-kf-bg text-kf-muted font-mono uppercase text-[10px] border-b border-kf-border">
                    <tr>
                      <th className="p-3">Measurement</th>
                      <th className="p-3">V{versionA.versionNumber}</th>
                      <th className="p-3">V{versionB.versionNumber}</th>
                      <th className="p-3">Delta Difference</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-kf-border/40 font-mono">
                    <tr>
                      <td className="p-3 font-medium text-kf-text">Width (X)</td>
                      <td className="p-3 text-kf-muted">{dimensionDiffs.width.a.toFixed(1)} mm</td>
                      <td className="p-3 text-kf-text font-bold">{dimensionDiffs.width.b.toFixed(1)} mm</td>
                      <td className="p-3">
                        <span
                          className={`font-bold ${
                            dimensionDiffs.width.diff > 0
                              ? 'text-kf-pass'
                              : dimensionDiffs.width.diff < 0
                              ? 'text-amber-400'
                              : 'text-kf-muted'
                          }`}
                        >
                          {dimensionDiffs.width.diff > 0 ? `+${dimensionDiffs.width.diff} mm` : `${dimensionDiffs.width.diff} mm`}
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-kf-text">Depth (Y)</td>
                      <td className="p-3 text-kf-muted">{dimensionDiffs.depth.a.toFixed(1)} mm</td>
                      <td className="p-3 text-kf-text font-bold">{dimensionDiffs.depth.b.toFixed(1)} mm</td>
                      <td className="p-3">
                        <span
                          className={`font-bold ${
                            dimensionDiffs.depth.diff > 0
                              ? 'text-kf-pass'
                              : dimensionDiffs.depth.diff < 0
                              ? 'text-amber-400'
                              : 'text-kf-muted'
                          }`}
                        >
                          {dimensionDiffs.depth.diff > 0 ? `+${dimensionDiffs.depth.diff} mm` : `${dimensionDiffs.depth.diff} mm`}
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-kf-text">Height (Z)</td>
                      <td className="p-3 text-kf-muted">{dimensionDiffs.height.a.toFixed(1)} mm</td>
                      <td className="p-3 text-kf-text font-bold">{dimensionDiffs.height.b.toFixed(1)} mm</td>
                      <td className="p-3">
                        <span
                          className={`font-bold ${
                            dimensionDiffs.height.diff > 0
                              ? 'text-kf-pass'
                              : dimensionDiffs.height.diff < 0
                              ? 'text-amber-400'
                              : 'text-kf-muted'
                          }`}
                        >
                          {dimensionDiffs.height.diff > 0 ? `+${dimensionDiffs.height.diff} mm` : `${dimensionDiffs.height.diff} mm`}
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-kf-text">Solid Volume</td>
                      <td className="p-3 text-kf-muted">{(volumeDiff.a / 1000).toFixed(1)} cm³</td>
                      <td className="p-3 text-kf-text font-bold">{(volumeDiff.b / 1000).toFixed(1)} cm³</td>
                      <td className="p-3">
                        <span
                          className={`font-bold ${
                            volumeDiff.percentChange > 0
                              ? 'text-kf-pass'
                              : volumeDiff.percentChange < 0
                              ? 'text-amber-400'
                              : 'text-kf-muted'
                          }`}
                        >
                          {volumeDiff.percentChange > 0 ? `+${volumeDiff.percentChange}%` : `${volumeDiff.percentChange}%`}
                        </span>
                      </td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-kf-text">Design Match Score</td>
                      <td className="p-3 text-kf-muted">
                        {scoreDiff.a !== null ? `${scoreDiff.a}%` : 'Not Evaluated'}
                      </td>
                      <td className="p-3 text-kf-text font-bold">
                        {scoreDiff.b !== null ? `${scoreDiff.b}%` : 'Not Evaluated'}
                      </td>
                      <td className="p-3">
                        {scoreDiff.diff !== null ? (
                          <span
                            className={`font-bold ${
                              scoreDiff.diff > 0 ? 'text-kf-pass' : scoreDiff.diff < 0 ? 'text-kf-fail' : 'text-kf-muted'
                            }`}
                          >
                            {scoreDiff.diff > 0 ? `+${scoreDiff.diff}%` : `${scoreDiff.diff}%`}
                          </span>
                        ) : (
                          <span className="text-kf-muted font-mono">—</span>
                        )}
                      </td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-kf-text">Mesh Triangle Polygons</td>
                      <td className="p-3 text-kf-muted">{triangleCountDiff.a}</td>
                      <td className="p-3 text-kf-text font-bold">{triangleCountDiff.b}</td>
                      <td className="p-3 text-kf-muted">{triangleCountDiff.diff >= 0 ? `+${triangleCountDiff.diff}` : triangleCountDiff.diff}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {comparisonTab === 'features' && (
            <div className="space-y-4">
              {/* Feature Changes */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Added Features */}
                <div className="bg-kf-bg p-4 rounded-xl border border-kf-pass/30 space-y-2">
                  <div className="flex items-center gap-2 text-kf-pass font-bold text-xs">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Added Features in V{versionB.versionNumber}</span>
                  </div>
                  {addedFeatures.length > 0 ? (
                    <ul className="space-y-1 text-xs">
                      {addedFeatures.map((f, i) => (
                        <li key={i} className="text-kf-text flex items-center gap-1.5">
                          <span className="text-kf-pass font-bold">+</span> {f}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-xs text-kf-muted">No newly added features.</p>
                  )}
                </div>

                {/* Removed Features */}
                <div className="bg-kf-bg p-4 rounded-xl border border-kf-fail/30 space-y-2">
                  <div className="flex items-center gap-2 text-kf-fail font-bold text-xs">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Removed / Altered from V{versionA.versionNumber}</span>
                  </div>
                  {removedFeatures.length > 0 ? (
                    <ul className="space-y-1 text-xs">
                      {removedFeatures.map((f, i) => (
                        <li key={i} className="text-kf-text flex items-center gap-1.5">
                          <span className="text-kf-fail font-bold">-</span> {f}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-xs text-kf-muted">No removed baseline features.</p>
                  )}
                </div>
              </div>

              {/* Semantic Feature Model Parameter Differences */}
              {featureModelDiff && featureModelDiff.modifiedFeatures.length > 0 && (
                <div className="bg-kf-bg p-4 rounded-xl border border-kf-pink/30 space-y-3">
                  <div className="flex items-center gap-2 text-kf-pink font-bold text-xs">
                    <Sparkles className="w-4 h-4" />
                    <span>Semantic Parameter Changes</span>
                  </div>
                  <div className="space-y-2">
                    {featureModelDiff.modifiedFeatures.map((mf, i) => (
                      <div key={i} className="bg-kf-card p-3 rounded-lg border border-kf-border space-y-1.5">
                        <div className="text-xs font-bold text-kf-text">{mf.feature.label} <span className="text-[10px] font-mono text-kf-muted">({mf.feature.type})</span></div>
                        <div className="space-y-1">
                          {mf.parameterChanges.map((pc, j) => (
                            <div key={j} className="text-xs flex items-center justify-between font-mono">
                              <span className="text-kf-muted">{pc.parameterName}:</span>
                              <div className="flex items-center gap-2">
                                <span className="text-kf-muted line-through">{String(pc.oldValue)}{pc.unit ? ' ' + pc.unit : ''}</span>
                                <ArrowRight className="w-3 h-3 text-kf-pink" />
                                <span className="text-kf-pass font-bold">{String(pc.newValue)}{pc.unit ? ' ' + pc.unit : ''}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Specification differences */}
              {specificationDiffs.length > 0 && (
                <div className="bg-kf-bg p-4 rounded-xl border border-kf-border space-y-2">
                  <h4 className="text-xs font-bold text-kf-text">Specification Diffs</h4>
                  <div className="space-y-2">
                    {specificationDiffs.map((diff, i) => (
                      <div key={i} className="text-xs flex items-center justify-between border-b border-kf-border/40 pb-1.5">
                        <span className="text-kf-muted font-medium">{diff.label}</span>
                        <div className="flex items-center gap-2 font-mono">
                          <span className="text-kf-muted">{diff.valueA}</span>
                          <ArrowRight className="w-3 h-3 text-kf-pink" />
                          <span className="text-kf-text font-bold">{diff.valueB}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {comparisonTab === 'code' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <div className="text-xs font-mono font-bold text-kf-muted mb-2">
                    V{versionA.versionNumber} Script ({(versionA.cadCode || '').split('\n').length} lines)
                  </div>
                  <pre className="bg-[#050002] border border-kf-border p-3 rounded-xl text-[11px] font-mono text-kf-text/80 max-h-96 overflow-y-auto">
                    {versionA.cadCode || '// No script recorded'}
                  </pre>
                </div>
                <div>
                  <div className="text-xs font-mono font-bold text-kf-pink mb-2">
                    V{versionB.versionNumber} Script ({(versionB.cadCode || '').split('\n').length} lines)
                  </div>
                  <pre className="bg-[#050002] border border-kf-pink/30 p-3 rounded-xl text-[11px] font-mono text-kf-text/90 max-h-96 overflow-y-auto">
                    {versionB.cadCode || '// No script recorded'}
                  </pre>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-kf-border bg-kf-bg/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              type="button"
              disabled={!versionA.exportValidation?.allowed}
              onClick={() => onExportVersionStl?.(versionA)}
              className="px-3 py-1.5 rounded-lg bg-kf-card hover:bg-kf-hover border border-kf-border text-xs font-medium text-kf-text transition disabled:opacity-40 flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export V{versionA.versionNumber} STL</span>
            </button>
            <button
              type="button"
              disabled={!versionB.exportValidation?.allowed}
              onClick={() => onExportVersionStl?.(versionB)}
              className="px-3 py-1.5 rounded-lg bg-kf-card hover:bg-kf-hover border border-kf-border text-xs font-medium text-kf-text transition disabled:opacity-40 flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export V{versionB.versionNumber} STL</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-kf-card hover:bg-kf-hover border border-kf-border text-xs font-medium text-kf-text transition cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              onClick={() => {
                if (onRestoreVersion) {
                  onRestoreVersion(versionB);
                }
                onClose();
              }}
              className="px-4 py-2 rounded-lg bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Restore V{versionB.versionNumber} to Active</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
