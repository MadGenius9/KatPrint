import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  Send,
  Sparkles,
  Bot,
  User,
  RotateCcw,
  CheckCircle2,
  Layers,
  Zap,
  ShieldCheck,
  CornerDownLeft,
  GitBranch,
  Eye,
  ArrowLeft,
} from 'lucide-react';
import { DesignConversationMessage, KatPrintProject, ModelVersion } from '../../projects/projectTypes';
import { Target, X as CloseIcon } from 'lucide-react';

export interface ProjectConversationPanelProps {
  project: KatPrintProject;
  activeVersion: ModelVersion | null;
  viewingVersionId?: string | null;
  selectedFeatureId?: string | null;
  selectedFeatureIds?: string[];
  onDeselectFeature?: () => void;
  isProcessing?: boolean;
  onSendInstruction: (instruction: string) => void;
  onUndo?: () => void;
  onSelectVersion?: (versionId: string) => void;
  onRestoreVersion?: (version: ModelVersion) => void;
  onBranchVersion?: (version: ModelVersion) => void;
  onReturnToCurrent?: () => void;
  autoApply?: boolean;
  onToggleAutoApply?: (enabled: boolean) => void;
}

export const ProjectConversationPanel: React.FC<ProjectConversationPanelProps> = ({
  project,
  activeVersion,
  viewingVersionId,
  selectedFeatureId,
  selectedFeatureIds,
  onDeselectFeature,
  isProcessing = false,
  onSendInstruction,
  onUndo,
  onSelectVersion,
  onRestoreVersion,
  onBranchVersion,
  onReturnToCurrent,
  autoApply,
  onToggleAutoApply,
}) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const processing = isProcessing;
  const autoApplyEnabled = autoApply !== undefined ? autoApply : !!project.projectSettings?.autoApplyProposedChanges;

  const messages = project.conversation || [];
  const canUndo = (project?.versions?.length || 0) > 1;

  const headVersion = (project.versions || []).find((v) => v.id === project.currentVersionId) ||
    project.versions?.[project.versions.length - 1] || null;

  const isHistorical = Boolean(viewingVersionId && viewingVersionId !== project.currentVersionId);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, processing]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || processing || isHistorical) return;
    const text = inputText.trim();
    setInputText('');
    onSendInstruction(text);
  };

  const handleTriggerUndo = () => {
    if (onUndo) onUndo();
  };

  const suggestions = [
    'Make the base 15 mm wider',
    'Add two 5 mm mounting holes',
    'Round the front corners',
    'Add a cable routing opening',
    'Make it 10 mm taller',
    'Undo that last change',
  ];

  const features = activeVersion?.featureModel?.features || [];
  const activeSelectedIds =
    selectedFeatureIds && selectedFeatureIds.length > 0
      ? selectedFeatureIds
      : selectedFeatureId
      ? [selectedFeatureId]
      : [];

  const selectedFeatures = features.filter((f) => activeSelectedIds.includes(f.id));

  return (
    <div className="flex flex-col h-full bg-kf-card border border-kf-border rounded-xl overflow-hidden shadow-lg text-kf-text">
      {/* Header */}
      <div className="p-3.5 border-b border-kf-border bg-kf-bg/60 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-kf-pink" />
          <h3 className="text-xs font-bold font-mono uppercase tracking-wider text-kf-text">
            Conversational Design AI
          </h3>
        </div>
        <div className="flex items-center gap-3">
          {onUndo && !isHistorical && (
            <button
              type="button"
              id="btn-conversation-undo"
              onClick={handleTriggerUndo}
              disabled={!canUndo || processing}
              className="text-[10px] font-mono text-kf-muted hover:text-kf-pink flex items-center gap-1 disabled:opacity-30 disabled:hover:text-kf-muted transition cursor-pointer px-1.5 py-0.5 rounded border border-kf-border/40 hover:border-kf-pink/40"
              title="Undo last revision"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Undo</span>
            </button>
          )}

          {onToggleAutoApply && (
            <label className="flex items-center gap-1.5 text-[10px] font-mono text-kf-muted cursor-pointer select-none">
              <input
                type="checkbox"
                id="checkbox-auto-apply"
                checked={autoApplyEnabled}
                onChange={(e) => onToggleAutoApply(e.target.checked)}
                className="w-3 h-3 rounded accent-kf-pink cursor-pointer"
              />
              <span>Auto-apply</span>
            </label>
          )}

          <div className="flex items-center gap-1 text-[11px] font-mono text-kf-muted">
            <span>{isHistorical ? 'Viewing:' : 'Active:'}</span>
            <span className="text-kf-pink font-bold">V{activeVersion?.versionNumber || 1}</span>
          </div>
        </div>
      </div>

      {/* Historical Version Viewing Banner */}
      {isHistorical && activeVersion && (
        <div className="bg-amber-500/10 border-b border-amber-500/30 p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-amber-400 shrink-0" />
            <div className="text-xs text-amber-200">
              You are previewing <strong className="text-amber-100 font-mono">V{activeVersion.versionNumber} ({activeVersion.label})</strong>. Current project head is <strong className="text-amber-100 font-mono">V{headVersion?.versionNumber || 'Head'}</strong>.
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            {onReturnToCurrent && (
              <button
                type="button"
                id="btn-banner-return-head"
                onClick={onReturnToCurrent}
                className="bg-kf-panel hover:bg-kf-panel-2 border border-kf-border text-kf-text font-mono text-[11px] px-2.5 py-1 rounded transition cursor-pointer flex items-center gap-1"
              >
                <ArrowLeft className="w-3 h-3" />
                <span>Return to Head</span>
              </button>
            )}
            {onBranchVersion && (
              <button
                type="button"
                id="btn-banner-branch-version"
                onClick={() => onBranchVersion(activeVersion)}
                className="bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-mono font-bold text-[11px] px-2.5 py-1 rounded transition cursor-pointer flex items-center gap-1"
              >
                <GitBranch className="w-3 h-3" />
                <span>Branch from V{activeVersion.versionNumber}</span>
              </button>
            )}
            {onRestoreVersion && (
              <button
                type="button"
                id="btn-banner-restore-version"
                onClick={() => onRestoreVersion(activeVersion)}
                className="bg-kf-panel-2 hover:bg-kf-border text-kf-text border border-kf-border font-mono text-[11px] px-2 py-1 rounded transition cursor-pointer"
              >
                Restore
              </button>
            )}
          </div>
        </div>
      )}

      {/* Messages Stream */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          const relatedVer = msg.relatedVersionId
            ? project?.versions?.find((v) => v.id === msg.relatedVersionId)
            : null;

          return (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              {/* Avatar */}
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs ${
                  isUser
                    ? 'bg-kf-pink text-[#0A0004] font-bold'
                    : 'bg-kf-bg border border-kf-pink/30 text-kf-pink'
                }`}
              >
                {isUser ? <User className="w-3.5 h-3.5" /> : <Bot className="w-4 h-4" />}
              </div>

              {/* Message Bubble */}
              <div
                className={`max-w-[85%] rounded-xl p-3 text-xs leading-relaxed space-y-2 ${
                  isUser
                    ? 'bg-kf-pink text-[#0A0004] font-medium shadow-sm'
                    : 'bg-kf-bg/90 border border-kf-border text-kf-text shadow-sm'
                }`}
              >
                <p className="whitespace-pre-wrap">{msg.content}</p>

                {/* KatPrint Change Details & Badges */}
                {!isUser && (msg.changes?.length || relatedVer) && (
                  <div className="pt-2 border-t border-kf-border/40 space-y-1.5 text-[11px]">
                    {msg.changes && msg.changes.length > 0 && (
                      <div className="space-y-1">
                        <span className="font-mono text-[10px] uppercase text-kf-muted font-bold">
                          Applied Changes:
                        </span>
                        <ul className="space-y-0.5 font-mono text-kf-text/90 pl-1">
                          {msg.changes.map((change, i) => (
                            <li key={i} className="flex items-start gap-1">
                              <span className="text-kf-pink">•</span>
                              <span>{change}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="flex items-center gap-2 pt-1">
                      {relatedVer && onSelectVersion && (
                        <button
                          type="button"
                          onClick={() => onSelectVersion(relatedVer.id)}
                          className="bg-kf-card hover:bg-kf-hover border border-kf-border text-kf-pink font-mono font-bold px-2 py-0.5 rounded text-[10px] flex items-center gap-1 transition cursor-pointer"
                        >
                          <Layers className="w-3 h-3" />
                          <span>View V{relatedVer.versionNumber}</span>
                        </button>
                      )}

                      {msg.designMatchScore !== undefined && msg.designMatchScore !== null && (
                        <span
                          className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                            msg.designMatchScore >= 90
                              ? 'bg-kf-pass/10 text-kf-pass border-kf-pass/30'
                              : 'bg-amber-400/10 text-amber-300 border-amber-400/30'
                          }`}
                        >
                          {msg.designMatchScore}% Match
                        </span>
                      )}
                    </div>
                  </div>
                )}

                <div
                  className={`text-[9px] font-mono text-right ${
                    isUser ? 'text-[#0A0004]/60' : 'text-kf-muted'
                  }`}
                >
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          );
        })}

        {/* Processing Indicator */}
        {isProcessing && (
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-lg bg-kf-bg border border-kf-pink/30 flex items-center justify-center text-kf-pink shrink-0">
              <Bot className="w-4 h-4 animate-pulse" />
            </div>
            <div className="bg-kf-bg/90 border border-kf-border rounded-xl p-3 text-xs text-kf-muted flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-kf-pink animate-ping" />
              <span className="font-mono">KatPrint is revising CAD model & verifying geometry...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 3D Feature Selection Context Banner */}
      {selectedFeatures.length > 0 && (
        <div className="px-3.5 py-1.5 bg-cyan-950/70 border-t border-cyan-800/60 flex items-center justify-between text-xs text-cyan-200">
          <div className="flex items-center gap-2 truncate">
            <Target className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="text-[11px] font-mono font-medium truncate">
              {selectedFeatures.length === 1
                ? `3D Selected: ${selectedFeatures[0].label} (${selectedFeatures[0].type})`
                : `3D Selected: ${selectedFeatures.length} features (${selectedFeatures.map((f) => f.label).join(', ')})`}
            </span>
          </div>
          {onDeselectFeature && (
            <button
              type="button"
              onClick={onDeselectFeature}
              className="text-cyan-400 hover:text-cyan-200 p-0.5 rounded transition shrink-0 ml-2"
              title="Clear 3D selection"
            >
              <CloseIcon className="w-3 h-3" />
            </button>
          )}
        </div>
      )}

      {/* Suggestion Chips */}
      {!isHistorical && (
        <div className="px-3 py-2 bg-kf-bg/40 border-t border-kf-border flex items-center gap-1.5 overflow-x-auto text-[11px] no-scrollbar">
          <span className="text-[10px] font-mono text-kf-muted uppercase shrink-0">Suggestions:</span>
          {suggestions.map((sug) => (
            <button
              key={sug}
              type="button"
              onClick={() => {
                setInputText(sug);
              }}
              className="shrink-0 bg-kf-card hover:bg-kf-hover border border-kf-border px-2.5 py-1 rounded-full text-kf-muted hover:text-kf-text transition cursor-pointer text-[11px]"
            >
              {sug}
            </button>
          ))}
        </div>
      )}

      {/* Input Box */}
      <form onSubmit={handleSubmit} className="p-3 border-t border-kf-border bg-kf-bg/80 flex items-center gap-2">
        <input
          type="text"
          id="input-conversation-revision"
          placeholder={
            isHistorical
              ? 'Direct revision is disabled for historical preview. Branch or restore to revise.'
              : 'e.g. "Make the base 15 mm wider and add 2 screw holes"'
          }
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          disabled={isProcessing || isHistorical}
          className="flex-1 bg-kf-card border border-kf-border focus:border-kf-pink rounded-lg px-3 py-2 text-xs text-kf-text placeholder-kf-muted outline-none transition disabled:opacity-50"
        />
        <button
          type="submit"
          id="btn-send-conversation-revision"
          disabled={!inputText.trim() || isProcessing || isHistorical}
          className="p-2 rounded-lg bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] transition disabled:opacity-40 cursor-pointer shadow-sm"
          title="Send Revision Request"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
