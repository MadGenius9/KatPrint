import React, { useState, useEffect } from 'react';
import {
  Database,
  Trash2,
  Download,
  AlertTriangle,
  HardDrive,
  CheckCircle2,
  RefreshCw,
  FileArchive,
} from 'lucide-react';
import { StorageUsageStats, KatPrintProject } from '../../projects/projectTypes';
import { projectRepository } from '../../projects/projectRepository';

interface StorageManagementModalProps {
  isOpen?: boolean;
  onClose: () => void;
  onDataCleared?: () => void;
  onStorageCleared?: () => void;
}

export const StorageManagementModal: React.FC<StorageManagementModalProps> = ({
  isOpen = true,
  onClose,
  onDataCleared,
  onStorageCleared,
}) => {
  if (!isOpen) return null;

  const [stats, setStats] = useState<StorageUsageStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isClearing, setIsClearing] = useState(false);
  const [cleanedImagesCount, setCleanedImagesCount] = useState<number | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const loadStats = async () => {
    setIsLoading(true);
    try {
      const s = await projectRepository.getStorageUsage();
      setStats(s);
    } catch (e) {
      console.warn('Error loading storage stats:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, []);

  const handleCleanImages = async () => {
    try {
      const count = await projectRepository.deleteOldInspectionImages();
      setCleanedImagesCount(count);
      await loadStats();
    } catch (e) {
      console.error('Error cleaning images:', e);
    }
  };

  const handleExportBackup = async () => {
    try {
      const projects = await projectRepository.listProjects();
      const backup = {
        app: 'KatPrint CAD',
        format: 'katprint-full-backup',
        exportedAt: new Date().toISOString(),
        projects,
      };
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `KatPrint_Backup_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Error exporting backup:', e);
    }
  };

  const handleClearAll = async () => {
    setIsClearing(true);
    try {
      await projectRepository.clearAllData();
      if (typeof onDataCleared === 'function') {
        onDataCleared();
      }
      if (typeof onStorageCleared === 'function') {
        onStorageCleared();
      }
      onClose();
    } catch (e) {
      console.error('Error clearing data:', e);
    } finally {
      setIsClearing(false);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-kf-card border border-kf-border rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-6 text-kf-text">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-kf-border pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-kf-pink/10 text-kf-pink">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-kf-text">Storage & Persistence Management</h3>
              <p className="text-xs text-kf-muted">Local IndexedDB design database</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-kf-muted hover:text-kf-text text-sm font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-kf-bg p-3.5 rounded-xl border border-kf-border text-center">
            <span className="text-[10px] font-mono text-kf-muted uppercase block mb-1">Projects</span>
            <span className="text-xl font-bold font-mono text-kf-text">
              {isLoading ? '...' : stats?.projectCount ?? 0}
            </span>
          </div>
          <div className="bg-kf-bg p-3.5 rounded-xl border border-kf-border text-center">
            <span className="text-[10px] font-mono text-kf-muted uppercase block mb-1">Versions</span>
            <span className="text-xl font-bold font-mono text-kf-pink">
              {isLoading ? '...' : stats?.versionCount ?? 0}
            </span>
          </div>
          <div className="bg-kf-bg p-3.5 rounded-xl border border-kf-border text-center">
            <span className="text-[10px] font-mono text-kf-muted uppercase block mb-1">Used Space</span>
            <span className="text-xl font-bold font-mono text-kf-pass">
              {isLoading ? '...' : formatBytes(stats?.estimatedBytes ?? 0)}
            </span>
          </div>
        </div>

        {/* Storage Optimization Actions */}
        <div className="space-y-3">
          <h4 className="text-xs font-mono font-bold uppercase text-kf-muted">Storage Utilities</h4>

          {/* Clean image cache */}
          <div className="bg-kf-bg p-3 rounded-xl border border-kf-border flex items-center justify-between gap-3">
            <div>
              <span className="text-xs font-bold text-kf-text block">Free Inspection View Cache</span>
              <span className="text-[11px] text-kf-muted">
                Removes stored multi-view snapshots while preserving all CAD code, versions, and geometry.
              </span>
            </div>
            <button
              type="button"
              onClick={handleCleanImages}
              className="px-3 py-1.5 rounded-lg bg-kf-card hover:bg-kf-hover border border-kf-border text-xs font-medium text-kf-text transition shrink-0 cursor-pointer"
            >
              Clean Images
            </button>
          </div>

          {cleanedImagesCount !== null && (
            <div className="p-2.5 rounded-lg bg-kf-pass/10 border border-kf-pass/30 text-xs text-kf-pass flex items-center gap-2 font-mono">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Cleaned {cleanedImagesCount} cached image sets to reclaim storage.</span>
            </div>
          )}

          {/* Export Full Backup */}
          <div className="bg-kf-bg p-3 rounded-xl border border-kf-border flex items-center justify-between gap-3">
            <div>
              <span className="text-xs font-bold text-kf-text block">Download Complete Backup</span>
              <span className="text-[11px] text-kf-muted">
                Exports all projects, versions, and conversations as a portable JSON backup.
              </span>
            </div>
            <button
              type="button"
              onClick={handleExportBackup}
              className="px-3 py-1.5 rounded-lg bg-kf-card hover:bg-kf-hover border border-kf-border text-xs font-medium text-kf-text transition shrink-0 flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Backup</span>
            </button>
          </div>
        </div>

        {/* Destructive Clear */}
        <div className="pt-3 border-t border-kf-border">
          {showClearConfirm ? (
            <div className="bg-kf-fail/10 border border-kf-fail/40 p-4 rounded-xl space-y-3">
              <div className="flex items-center gap-2 text-kf-fail text-xs font-bold">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Confirm resetting entire local KatPrint workspace?</span>
              </div>
              <p className="text-[11px] text-kf-muted">
                This will delete all saved projects and design versions from your local browser database.
              </p>
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowClearConfirm(false)}
                  className="px-3 py-1.5 rounded-lg bg-kf-card border border-kf-border text-xs text-kf-muted transition"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleClearAll}
                  disabled={isClearing}
                  className="px-3 py-1.5 rounded-lg bg-kf-fail hover:bg-red-600 text-white text-xs font-bold transition flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>{isClearing ? 'Clearing...' : 'Yes, Delete All'}</span>
                </button>
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setShowClearConfirm(true)}
              className="text-xs text-kf-fail hover:underline flex items-center gap-1.5 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All Local Workspace Data...</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
