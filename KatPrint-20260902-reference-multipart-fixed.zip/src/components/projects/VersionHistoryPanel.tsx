import React, { useState } from 'react';
import {
  History,
  GitBranch,
  RotateCcw,
  Eye,
  GitCompare,
  Download,
  Edit2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Sparkles,
  Layers,
  ChevronRight,
  Activity,
} from 'lucide-react';
import { ModelVersion, KatPrintProject } from '../../projects/projectTypes';
import { sanitizeStlFilename } from '../../versions/versionService';

export interface VersionHistoryPanelProps {
  project: KatPrintProject;
  activeVersionId?: string | null;
  viewingVersionId?: string | null;
  onSelectVersionToView: (version: ModelVersion) => void;
  onRestoreVersion?: (version: ModelVersion) => void;
  onBranchVersion?: (version: ModelVersion) => void;
  onCompareVersions?: (versionA: ModelVersion, versionB: ModelVersion) => void;
  onRenameVersionLabel?: (versionId: string, newLabel: string) => void;
  onExportVersionStl?: (version: ModelVersion) => void;
  onViewDiagnostics?: (version: ModelVersion) => void;
}

export const VersionHistoryPanel: React.FC<VersionHistoryPanelProps> = ({
  project,
  activeVersionId = null,
  viewingVersionId = null,
  onSelectVersionToView,
  onRestoreVersion,
  onBranchVersion,
  onCompareVersions,
  onRenameVersionLabel,
  onExportVersionStl,
  onViewDiagnostics,
}) => {
  const [editingVersionId, setEditingVersionId] = useState<string | null>(null);
  const [editLabel, setEditLabel] = useState('');

  const handleSelectToView = (ver: ModelVersion) => {
    onSelectVersionToView(ver);
  };

  const versions = project?.versions || [];
  const versionsReversed = [...versions].reverse();
  const currentHeadVersion = versions.find((v) => v.id === project?.currentVersionId) ||
                             (versions.length > 0 ? versions[versions.length - 1] : null);
  const viewingVersion = versions.find((v) => v.id === viewingVersionId) || currentHeadVersion;

  const isViewingHistorical = viewingVersion && currentHeadVersion && viewingVersion.id !== currentHeadVersion.id;

  const handleStartRename = (ver: ModelVersion) => {
    setEditingVersionId(ver.id);
    setEditLabel(ver.label);
  };

  const handleSaveRename = (versionId: string) => {
    if (editLabel.trim()) {
      onRenameVersionLabel(versionId, editLabel.trim());
    }
    setEditingVersionId(null);
  };

  return (
    <div className="flex flex-col h-full bg-kf-card border border-kf-border rounded-xl overflow-hidden shadow-lg text-kf-text">
      {/* Header */}
      <div className="p-3.5 border-b border-kf-border bg-kf-bg/60 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-kf-pink" />
          <h3 className="text-xs font-bold font-mono uppercase tracking-wider text-kf-text">
            Version Timeline ({versions.length})
          </h3>
        </div>
        <span className="text-[11px] font-mono text-kf-muted">
          Current: V{currentHeadVersion?.versionNumber || 1}
        </span>
      </div>

      {/* Historical View Warning Banner */}
      {isViewingHistorical && viewingVersion && currentHeadVersion && (
        <div className="bg-amber-500/10 border-b border-amber-500/30 p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-amber-300">
            <Eye className="w-4 h-4 shrink-0" />
            <span>
              <strong>Viewing V{viewingVersion.versionNumber}</strong> (Project head is V{currentHeadVersion.versionNumber})
            </span>
          </div>
          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              type="button"
              onClick={() => {
                if (onRestoreVersion) onRestoreVersion(viewingVersion);
              }}
              className="px-2.5 py-1 rounded bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] text-[11px] font-mono font-bold transition flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Restore This</span>
            </button>
            <button
              type="button"
              onClick={() => handleSelectToView(currentHeadVersion)}
              className="px-2.5 py-1 rounded bg-kf-card hover:bg-kf-hover border border-kf-border text-[11px] text-kf-text transition cursor-pointer"
            >
              Return to V{currentHeadVersion.versionNumber}
            </button>
          </div>
        </div>
      )}

      {/* Version List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {versionsReversed.length > 0 ? (
          versionsReversed.map((ver, idx) => {
            const isHead = ver.id === currentHeadVersion?.id;
            const isViewing = ver.id === (viewingVersionId || currentHeadVersion?.id);
            const score = ver.designMatchScore ?? ver.fidelityReview?.overallScore;
            const dims = ver.geometryMetadata?.dimensions;

            return (
              <div
                key={ver.id}
                className={`p-3 rounded-xl border transition-all duration-200 relative ${
                  isViewing
                    ? 'bg-kf-pink/5 border-kf-pink shadow-sm'
                    : 'bg-kf-bg/60 border-kf-border/80 hover:border-kf-border hover:bg-kf-hover/40'
                }`}
              >
                {/* Top Row: Version Badge, Label, Timestamp */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={`font-mono text-xs font-bold px-2 py-0.5 rounded-md ${
                          isHead
                            ? 'bg-kf-pink text-[#0A0004]'
                            : 'bg-kf-card border border-kf-border text-kf-text'
                        }`}
                      >
                        V{ver.versionNumber}
                      </span>

                      {isHead && (
                        <span className="text-[10px] font-mono bg-kf-pink/20 text-kf-pink px-1.5 py-0.5 rounded">
                          HEAD
                        </span>
                      )}

                      {isViewing && !isHead && (
                        <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded flex items-center gap-1">
                          <Eye className="w-2.5 h-2.5" />
                          VIEWING
                        </span>
                      )}

                      {score !== undefined && (
                        <span
                          className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            score >= 90
                              ? 'bg-kf-pass/20 text-kf-pass'
                              : score >= 75
                              ? 'bg-amber-400/20 text-amber-300'
                              : 'bg-kf-fail/20 text-kf-fail'
                          }`}
                        >
                          {score}% Match
                        </span>
                      )}
                    </div>

                    {/* Label */}
                    <div className="mt-1.5">
                      {editingVersionId === ver.id ? (
                        <div className="flex items-center gap-1.5">
                          <input
                            type="text"
                            value={editLabel}
                            onChange={(e) => setEditLabel(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveRename(ver.id);
                              if (e.key === 'Escape') setEditingVersionId(null);
                            }}
                            className="text-xs bg-kf-card text-kf-text px-2 py-1 rounded border border-kf-pink outline-none w-full"
                            autoFocus
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveRename(ver.id)}
                            className="text-[10px] font-bold bg-kf-pink text-[#0A0004] px-2 py-1 rounded"
                          >
                            Save
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 group/title">
                          <span className="text-xs font-bold text-kf-text line-clamp-1">
                            {ver.label}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleStartRename(ver)}
                            className="opacity-0 group-hover/title:opacity-100 p-0.5 text-kf-muted hover:text-kf-text transition"
                            title="Rename Version Label"
                          >
                            <Edit2 className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  <span className="text-[10px] text-kf-muted shrink-0 flex items-center gap-1">
                    <Clock className="w-2.5 h-2.5" />
                    {new Date(ver.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                {/* Change Summary */}
                {ver.changeSummary && (
                  <p className="text-[11px] text-kf-muted/90 mt-1.5 line-clamp-2 bg-kf-bg/80 p-1.5 rounded border border-kf-border/40 font-mono">
                    {ver.changeSummary}
                  </p>
                )}

                {/* Metrics Chips */}
                {dims && (
                  <div className="flex items-center gap-2 mt-2 text-[10px] font-mono text-kf-muted flex-wrap">
                    <span className="bg-kf-card px-1.5 py-0.5 rounded border border-kf-border/60">
                      {dims.x.toFixed(0)} × {dims.y.toFixed(0)} × {dims.z.toFixed(0)} mm
                    </span>
                    <span className="bg-kf-card px-1.5 py-0.5 rounded border border-kf-border/60">
                      {((ver.geometryMetadata?.volumeMm3 || 0) / 1000).toFixed(1)} cm³
                    </span>
                    <span
                      className={`px-1.5 py-0.5 rounded border ${
                        ver.geometryMetadata?.isManifold
                          ? 'bg-kf-pass/10 text-kf-pass border-kf-pass/30'
                          : 'bg-kf-fail/10 text-kf-fail border-kf-fail/30'
                      }`}
                    >
                      {ver.geometryMetadata?.isManifold ? 'Watertight' : 'Non-manifold'}
                    </span>
                  </div>
                )}

                {/* Action Bar */}
                <div className="flex items-center justify-between gap-1.5 mt-3 pt-2 border-t border-kf-border/50 text-[11px]">
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleSelectToView(ver)}
                      className={`px-2 py-1 rounded flex items-center gap-1 transition cursor-pointer ${
                        isViewing
                          ? 'bg-kf-pink/20 text-kf-pink font-bold'
                          : 'hover:bg-kf-hover text-kf-muted hover:text-kf-text'
                      }`}
                      title="Inspect 3D Geometry in Viewer"
                    >
                      <Eye className="w-3 h-3" />
                      <span>{isViewing ? 'Viewing' : 'View'}</span>
                    </button>

                    {currentHeadVersion && currentHeadVersion.id !== ver.id && onCompareVersions && (
                      <button
                        type="button"
                        onClick={() => onCompareVersions(ver, currentHeadVersion)}
                        className="px-2 py-1 rounded hover:bg-kf-hover text-kf-muted hover:text-kf-text flex items-center gap-1 transition cursor-pointer"
                        title="Compare against Current Head"
                      >
                        <GitCompare className="w-3 h-3" />
                        <span>Compare</span>
                      </button>
                    )}

                    {onBranchVersion && (
                      <button
                        type="button"
                        onClick={() => onBranchVersion(ver)}
                        className="px-2 py-1 rounded hover:bg-kf-hover text-kf-muted hover:text-kf-text flex items-center gap-1 transition cursor-pointer"
                        title="Branch New Design From This Version"
                      >
                        <GitBranch className="w-3 h-3" />
                        <span>Branch</span>
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    {ver.generationDiagnostics && onViewDiagnostics && (
                      <button
                        type="button"
                        onClick={() => onViewDiagnostics(ver)}
                        className="p-1 rounded hover:bg-kf-hover text-kf-muted hover:text-kf-pink transition cursor-pointer"
                        title="View Diagnostics for Version"
                      >
                        <Activity className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {onExportVersionStl && (
                      <button
                        type="button"
                        disabled={!ver.exportValidation?.allowed}
                        onClick={() => onExportVersionStl(ver)}
                        className="p-1 rounded hover:bg-kf-hover text-kf-muted hover:text-kf-text transition disabled:opacity-40 cursor-pointer"
                        title={
                          ver.exportValidation?.allowed
                            ? `Export ${sanitizeStlFilename(project.name, ver.versionNumber)}`
                            : ver.exportValidation?.reason || 'STL Export unavailable'
                        }
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-8 text-kf-muted text-xs">
            No versions recorded yet. Generate your first design to create V1.
          </div>
        )}
      </div>
    </div>
  );
};
