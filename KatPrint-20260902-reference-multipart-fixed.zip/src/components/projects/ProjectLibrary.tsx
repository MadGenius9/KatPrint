import React, { useState, useMemo, useRef } from 'react';
import {
  FolderPlus,
  Search,
  Upload,
  Database,
  Star,
  Sparkles,
  Layers,
  Clock,
  Trash2,
  AlertTriangle,
  FileCode2,
  Plus,
} from 'lucide-react';
import { KatPrintProject } from '../../projects/projectTypes';
import { ProjectCard } from './ProjectCard';
import { inferProjectName } from '../../projects/projectService';

export interface ProjectLibraryProps {
  projects: KatPrintProject[];
  activeProjectId?: string | null;
  onOpenProject: (project: KatPrintProject) => void;
  onCreateProject: (prompt: string, name?: string) => void;
  onDuplicateProject: (project: KatPrintProject) => void;
  onRenameProject: (project: KatPrintProject, newName: string) => void;
  onDeleteProject: (projectId: string) => void;
  onToggleFavorite: (projectId: string) => void;
  onExportProject: (project: KatPrintProject) => void;
  onImportProject: (fileContent: string) => void;
  onOpenStorageManager: () => void;
}

export const ProjectLibrary: React.FC<ProjectLibraryProps> = ({
  projects,
  activeProjectId,
  onOpenProject,
  onCreateProject,
  onDuplicateProject,
  onRenameProject,
  onDeleteProject,
  onToggleFavorite,
  onExportProject,
  onImportProject,
  onOpenStorageManager,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTab, setFilterTab] = useState<'all' | 'favorites' | 'recent'>('all');
  const [isNewProjectModalOpen, setIsNewProjectModalOpen] = useState(false);
  const [newProjectPrompt, setNewProjectPrompt] = useState('');
  const [newProjectCustomName, setNewProjectCustomName] = useState('');
  const [projectToDelete, setProjectToDelete] = useState<KatPrintProject | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleOpen = (p: KatPrintProject) => {
    onOpenProject(p);
  };

  const handleCreate = (prompt: string, name?: string) => {
    onCreateProject(prompt, name);
  };

  const handleDuplicate = (p: KatPrintProject) => {
    onDuplicateProject(p);
  };

  const handleRename = (p: KatPrintProject, newName: string) => {
    onRenameProject(p, newName);
  };

  const handleDelete = (p: KatPrintProject) => {
    onDeleteProject(p.id);
  };

  const handleToggleFav = (p: KatPrintProject) => {
    onToggleFavorite(p.id);
  };

  const handleExport = (p: KatPrintProject) => {
    onExportProject(p);
  };

  const handleImport = (fileContent: string) => {
    onImportProject(fileContent);
  };

  const handleOpenStorage = () => {
    onOpenStorageManager();
  };

  // Filter & Search Projects
  const filteredProjects = useMemo(() => {
    return projects.filter((p) => {
      // Search
      const matchesSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.originalPrompt.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.tags?.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

      if (!matchesSearch) return false;

      // Tab filter
      if (filterTab === 'favorites') return !!p.isFavorite;
      if (filterTab === 'recent') {
        const daysDiff = (Date.now() - new Date(p.updatedAt).getTime()) / (1000 * 60 * 60 * 24);
        return daysDiff <= 7;
      }
      return true;
    });
  }, [projects, searchQuery, filterTab]);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectPrompt.trim()) return;
    const name = newProjectCustomName.trim() || inferProjectName(newProjectPrompt);
    handleCreate(newProjectPrompt.trim(), name);
    setIsNewProjectModalOpen(false);
    setNewProjectPrompt('');
    setNewProjectCustomName('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        handleImport(content);
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const quickStarters = [
    {
      title: 'Dr. Squatch Soap Dish',
      prompt: '105 mm × 80 mm × 20 mm soap dish with 8 drainage slots, curved ribbed floor for bar drying, and 3 mm rim',
    },
    {
      title: 'Under-Desk Xbox Mount',
      prompt: 'Under-desk mount for Xbox Wireless Controller with 2 countersunk M4 screw holes, trigger clearance, and 3.5 mm thick walls',
    },
    {
      title: 'Desktop Phone Stand',
      prompt: 'Ergonomic desktop phone stand with 65-degree tilt, 14 mm front lip, non-slip base, and 16 mm wide bottom cable routing slot',
    },
    {
      title: 'Electronics Enclosure',
      prompt: '100 mm × 60 mm × 25 mm electronics box with 3 mm walls, four corner M3 screw mounts, and side cable pass-through',
    },
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-kf-bg overflow-y-auto p-6 md:p-8 text-kf-text">
      <div className="max-w-7xl mx-auto w-full space-y-6">
        {/* Top Header Row */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-kf-border/40 pb-6">
          <div>
            <div className="flex items-center gap-3">
              <span className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
                <span className="text-kf-pink">🌸</span> My Projects
              </span>
              <span className="bg-kf-pink/10 text-kf-pink border border-kf-pink/20 text-xs font-mono font-bold px-2.5 py-0.5 rounded-full">
                {projects.length} Saved
              </span>
            </div>
            <p className="text-xs text-kf-muted mt-1">
              Persistent AI CAD workspace with complete version history, cumulative revisions, and printable exports.
            </p>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            {/* Storage Manager Button */}
            <button
              type="button"
              onClick={handleOpenStorage}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-kf-card hover:bg-kf-hover border border-kf-border text-xs font-medium text-kf-muted hover:text-kf-text transition cursor-pointer"
              title="Storage & Data Management"
            >
              <Database className="w-3.5 h-3.5" />
              <span>Storage</span>
            </button>

            {/* Import Button */}
            <input
              type="file"
              ref={fileInputRef}
              accept=".katprint,.json"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-kf-card hover:bg-kf-hover border border-kf-border text-xs font-medium text-kf-text transition cursor-pointer"
              title="Import .katprint project package"
            >
              <Upload className="w-3.5 h-3.5 text-kf-muted" />
              <span>Import</span>
            </button>

            {/* New Project Button */}
            <button
              type="button"
              onClick={() => setIsNewProjectModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] text-xs font-bold font-mono transition shadow-md shadow-kf-pink/20 cursor-pointer"
            >
              <FolderPlus className="w-4 h-4" />
              <span>New Project</span>
            </button>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Tab Filter */}
          <div className="flex items-center gap-1 bg-kf-card p-1 rounded-lg border border-kf-border self-start">
            <button
              type="button"
              onClick={() => setFilterTab('all')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition cursor-pointer ${
                filterTab === 'all' ? 'bg-kf-pink text-[#0A0004] font-bold' : 'text-kf-muted hover:text-kf-text'
              }`}
            >
              All Projects ({projects.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterTab('favorites')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition flex items-center gap-1.5 cursor-pointer ${
                filterTab === 'favorites' ? 'bg-kf-pink text-[#0A0004] font-bold' : 'text-kf-muted hover:text-kf-text'
              }`}
            >
              <Star className="w-3 h-3" />
              <span>Favorites ({projects.filter((p) => p.isFavorite).length})</span>
            </button>
            <button
              type="button"
              onClick={() => setFilterTab('recent')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition flex items-center gap-1.5 cursor-pointer ${
                filterTab === 'recent' ? 'bg-kf-pink text-[#0A0004] font-bold' : 'text-kf-muted hover:text-kf-text'
              }`}
            >
              <Clock className="w-3 h-3" />
              <span>Recent (7d)</span>
            </button>
          </div>

          {/* Search Input */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-kf-muted absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search projects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-kf-card border border-kf-border rounded-lg pl-9 pr-3 py-1.5 text-xs text-kf-text placeholder-kf-muted focus:border-kf-pink outline-none transition"
            />
          </div>
        </div>

        {/* Project Grid */}
        {filteredProjects.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredProjects.map((project) => (
              <ProjectCard
                key={project.id}
                project={project}
                isActive={project.id === activeProjectId}
                onOpen={onOpenProject}
                onDuplicate={onDuplicateProject}
                onRename={onRenameProject}
                onDelete={(p) => setProjectToDelete(p)}
                onToggleFavorite={handleToggleFav}
                onExport={onExportProject}
              />
            ))}
          </div>
        ) : (
          <div className="bg-kf-card/40 border border-kf-border/60 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4">
            <div className="w-14 h-14 rounded-full bg-kf-pink/10 border border-kf-pink/20 flex items-center justify-center text-kf-pink">
              <Layers className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-base font-bold text-kf-text">
                {searchQuery ? 'No matching projects found' : 'No projects saved yet'}
              </h3>
              <p className="text-xs text-kf-muted max-w-md mt-1">
                {searchQuery
                  ? `No projects matched "${searchQuery}". Try a different keyword or clear the search filter.`
                  : 'Create your first 3D CAD design project with natural language or pick one of the verified design starters below.'}
              </p>
            </div>

            {!searchQuery && (
              <div className="mt-4 w-full max-w-2xl text-left">
                <div className="text-xs font-mono text-kf-pink font-bold mb-3 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Recommended Design Starters:</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {quickStarters.map((starter) => (
                    <button
                      key={starter.title}
                      type="button"
                      onClick={() => {
                        handleCreate(starter.prompt, starter.title);
                      }}
                      className="p-3 bg-kf-card hover:bg-kf-hover border border-kf-border hover:border-kf-pink/40 rounded-xl text-left transition flex flex-col justify-between gap-2 cursor-pointer group"
                    >
                      <div className="text-xs font-bold text-kf-text group-hover:text-kf-pink transition">
                        {starter.title}
                      </div>
                      <div className="text-[11px] text-kf-muted line-clamp-2">
                        {starter.prompt}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* New Project Modal */}
      {isNewProjectModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-kf-card border border-kf-border rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-kf-border pb-3">
              <h2 className="text-base font-bold text-kf-text flex items-center gap-2">
                <FolderPlus className="w-5 h-5 text-kf-pink" />
                <span>Create New Design Project</span>
              </h2>
              <button
                type="button"
                onClick={() => setIsNewProjectModalOpen(false)}
                className="text-kf-muted hover:text-kf-text text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-kf-muted mb-1">
                  Design Prompt (Describe what you want to create):
                </label>
                <textarea
                  rows={3}
                  placeholder="e.g. 100 mm × 60 mm × 25 mm electronics enclosure with 3 mm walls, four corner mounting holes, and cable slots"
                  value={newProjectPrompt}
                  onChange={(e) => setNewProjectPrompt(e.target.value)}
                  className="w-full bg-kf-bg border border-kf-border rounded-lg p-3 text-xs text-kf-text placeholder-kf-muted focus:border-kf-pink outline-none resize-none"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-kf-muted mb-1">
                  Project Title (Optional, auto-inferred if empty):
                </label>
                <input
                  type="text"
                  placeholder="e.g. Electronics Enclosure V1"
                  value={newProjectCustomName}
                  onChange={(e) => setNewProjectCustomName(e.target.value)}
                  className="w-full bg-kf-bg border border-kf-border rounded-lg px-3 py-2 text-xs text-kf-text placeholder-kf-muted focus:border-kf-pink outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewProjectModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-kf-bg hover:bg-kf-hover border border-kf-border text-xs text-kf-muted transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!newProjectPrompt.trim()}
                  className="px-5 py-2 rounded-lg bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] text-xs font-mono font-bold transition disabled:opacity-50 shadow-md cursor-pointer"
                >
                  Create & Generate
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {projectToDelete && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-kf-card border border-kf-fail/40 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-kf-fail">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="text-base font-bold text-kf-text">
                Delete "{projectToDelete.name}"?
              </h3>
            </div>
            <p className="text-xs text-kf-muted leading-relaxed">
              This will permanently delete the project, its {projectToDelete.versions?.length || 0} saved model versions, and complete design conversation history from KatPrint.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setProjectToDelete(null)}
                className="px-4 py-2 rounded-lg bg-kf-bg hover:bg-kf-hover border border-kf-border text-xs text-kf-muted transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleDelete(projectToDelete);
                  setProjectToDelete(null);
                }}
                className="px-4 py-2 rounded-lg bg-kf-fail hover:bg-red-600 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Project</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
