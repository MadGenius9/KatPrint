import React, { useState, useMemo } from 'react';
import {
  Grid,
  Layers,
  X,
  Printer,
  Download,
  Clock,
  Flame,
  CheckCircle2,
  AlertTriangle,
  Sliders,
  Maximize2,
  Package,
} from 'lucide-react';
import { ExecutedModelPart, PrinterSpec, FilamentSpec, PrintPlatePlan, PrintPlate } from '../../types';
import { computePrintPlatePlan } from '../../engine/printPlatePacker';
import { PART_PALETTE } from './MultiPartManager';
import { downloadMultiPartZip } from '../../engine/stlExporter';

export interface PlateLayoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  parts: ExecutedModelPart[];
  printer: PrinterSpec;
  filament?: FilamentSpec;
  projectName: string;
  versionLabel?: string;
  scaleFactor?: number;
}

export const PlateLayoutModal: React.FC<PlateLayoutModalProps> = ({
  isOpen,
  onClose,
  parts = [],
  printer,
  filament,
  projectName,
  versionLabel = 'V1',
  scaleFactor = 1.0,
}) => {
  const [partSpacingMm, setPartSpacingMm] = useState(10);
  const [bedMarginMm, setBedMarginMm] = useState(10);
  const [selectedPlateIndex, setSelectedPlateIndex] = useState(0);

  // Scaled parts for accurate plate nesting
  const scaledParts = useMemo(() => {
    return parts.map((p) => {
      const origDims = p.stats?.dimensions || { x: 20, y: 20, z: 20 };
      const origVol = p.stats?.volumeCm3 || 5;
      const origWeight = p.stats?.estimatedWeightGrams || 6;
      return {
        ...p,
        stats: {
          ...p.stats,
          dimensions: {
            x: origDims.x * scaleFactor,
            y: origDims.y * scaleFactor,
            z: origDims.z * scaleFactor,
          },
          volumeCm3: origVol * Math.pow(scaleFactor, 3),
          estimatedWeightGrams: origWeight * Math.pow(scaleFactor, 3),
        } as any,
      };
    });
  }, [parts, scaleFactor]);

  const platePlan: PrintPlatePlan = useMemo(() => {
    return computePrintPlatePlan(scaledParts, printer, {
      partSpacingMm,
      bedMarginMm,
    });
  }, [scaledParts, printer, partSpacingMm, bedMarginMm]);

  const activePlate: PrintPlate = platePlan.plates[selectedPlateIndex] || platePlan.plates[0];

  const bedWidth = printer.buildVolume.x;
  const bedDepth = printer.buildVolume.y;

  // Aspect ratio for SVG canvas
  const canvasWidth = 480;
  const canvasHeight = Math.max(300, (canvasWidth * (bedDepth / bedWidth)));

  // SVG coordinate transformation scale
  const scaleX = (canvasWidth - 40) / bedWidth;
  const scaleY = (canvasHeight - 40) / bedDepth;
  const renderScale = Math.min(scaleX, scaleY);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-[#121114] border border-[#26242a] rounded-2xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#26242a] bg-[#161519]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <Grid className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">Print Bed Nesting & Plate Packing</h2>
                <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  {platePlan.totalPlates} {platePlan.totalPlates === 1 ? 'Plate' : 'Plates'} Required
                </span>
              </div>
              <p className="text-xs text-[#9d98a0]">
                Optimized 2D shelf arrangement on {printer.name} ({printer.buildVolume.x}×{printer.buildVolume.y}×{printer.buildVolume.z} mm build volume).
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-[#9d98a0] hover:text-white hover:bg-[#201e24] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 p-6 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Visual 2D Print Bed Canvas */}
          <div className="lg:col-span-7 flex flex-col items-center justify-center bg-[#0d0c0f] border border-[#232128] rounded-2xl p-4 relative">
            {/* Plate Selector Tabs */}
            {platePlan.plates.length > 1 && (
              <div className="w-full flex items-center gap-2 mb-4 overflow-x-auto pb-1">
                {platePlan.plates.map((plate, idx) => (
                  <button
                    key={plate.plateIndex}
                    onClick={() => setSelectedPlateIndex(idx)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 shrink-0 ${
                      selectedPlateIndex === idx
                        ? 'bg-blue-500 text-white shadow-md shadow-blue-500/20'
                        : 'bg-[#1a1820] text-[#9d98a5] hover:text-white border border-[#2b2836]'
                    }`}
                  >
                    <span>{plate.plateName}</span>
                    <span className="text-[10px] opacity-80">({plate.items.length} items)</span>
                  </button>
                ))}
              </div>
            )}

            {/* 2D Print Bed SVG */}
            <div className="relative w-full flex items-center justify-center">
              <svg
                width={canvasWidth}
                height={canvasHeight}
                viewBox={`0 0 ${canvasWidth} ${canvasHeight}`}
                className="overflow-visible select-none"
              >
                {/* Bed Outline */}
                <rect
                  x="20"
                  y="20"
                  width={bedWidth * renderScale}
                  height={bedDepth * renderScale}
                  rx="8"
                  fill="#151419"
                  stroke="#33303d"
                  strokeWidth="2"
                />

                {/* Printable Margin Guideline */}
                <rect
                  x={20 + bedMarginMm * renderScale}
                  y={20 + bedMarginMm * renderScale}
                  width={(bedWidth - bedMarginMm * 2) * renderScale}
                  height={(bedDepth - bedMarginMm * 2) * renderScale}
                  rx="6"
                  fill="none"
                  stroke="#26242e"
                  strokeWidth="1.5"
                  strokeDasharray="4 4"
                />

                {/* Center Crosshair */}
                <line
                  x1={20 + (bedWidth / 2) * renderScale}
                  y1="20"
                  x2={20 + (bedWidth / 2) * renderScale}
                  y2={20 + bedDepth * renderScale}
                  stroke="#22202a"
                  strokeWidth="1"
                />
                <line
                  x1="20"
                  y1={20 + (bedDepth / 2) * renderScale}
                  x2={20 + bedWidth * renderScale}
                  y2={20 + (bedDepth / 2) * renderScale}
                  stroke="#22202a"
                  strokeWidth="1"
                />

                {/* Origin Indicator */}
                <text x="28" y="38" fill="#585463" fontSize="10" fontFamily="monospace">
                  (0, 0)
                </text>
                <text x={10 + bedWidth * renderScale} y={35 + bedDepth * renderScale} fill="#585463" fontSize="10" fontFamily="monospace">
                  {bedWidth}×{bedDepth} mm
                </text>

                {/* Placed Part Rectangles */}
                {activePlate &&
                  activePlate.items.map((item, idx) => {
                    const origPartIdx = parts.findIndex((p) => p.id === item.partId);
                    const color = PART_PALETTE[(origPartIdx >= 0 ? origPartIdx : idx) % PART_PALETTE.length];
                    
                    // Transform from centered coordinates to top-left SVG coords
                    const svgCenterX = 20 + (bedWidth / 2 + item.position.x) * renderScale;
                    const svgCenterY = 20 + (bedDepth / 2 + item.position.y) * renderScale;
                    const svgW = item.dimensions.x * renderScale;
                    const svgH = item.dimensions.y * renderScale;
                    const svgX = svgCenterX - svgW / 2;
                    const svgY = svgCenterY - svgH / 2;

                    return (
                      <g key={item.instanceId} className="cursor-pointer">
                        <rect
                          x={svgX}
                          y={svgY}
                          width={svgW}
                          height={svgH}
                          rx="4"
                          fill={color}
                          fillOpacity="0.25"
                          stroke={color}
                          strokeWidth="2"
                        />
                        {/* Part Label */}
                        <text
                          x={svgCenterX}
                          y={svgCenterY - 2}
                          fill="#ffffff"
                          fontSize={Math.max(9, Math.min(12, svgW / 5))}
                          fontWeight="bold"
                          textAnchor="middle"
                          dominantBaseline="middle"
                        >
                          {item.partName}
                        </text>
                        <text
                          x={svgCenterX}
                          y={svgCenterY + 11}
                          fill="#a39ea8"
                          fontSize={Math.max(8, Math.min(10, svgW / 6))}
                          textAnchor="middle"
                          dominantBaseline="middle"
                          fontFamily="monospace"
                        >
                          {item.dimensions.x.toFixed(0)}×{item.dimensions.y.toFixed(0)} mm
                        </text>
                      </g>
                    );
                  })}
              </svg>
            </div>
          </div>

          {/* Right Column: Plate Statistics & Layout Controls */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            {/* Active Plate Metrics */}
            <div className="bg-[#16151a] border border-[#282531] rounded-2xl p-4 space-y-4 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  {activePlate?.plateName || 'Plate 1'} Summary
                </span>
                <span className="text-xs text-blue-400 font-semibold font-mono">
                  {activePlate?.occupiedAreaPercent || 0}% Bed Occupied
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#121115] p-3 rounded-xl border border-[#201e26] space-y-1">
                  <div className="text-[10px] uppercase font-bold text-[#8c8694] flex items-center gap-1">
                    <Clock className="w-3 h-3 text-blue-400" />
                    Est. Print Time
                  </div>
                  <div className="text-sm font-bold text-white">
                    {Math.floor((activePlate?.estimatedPrintTimeMinutes || 0) / 60)}h {(activePlate?.estimatedPrintTimeMinutes || 0) % 60}m
                  </div>
                </div>

                <div className="bg-[#121115] p-3 rounded-xl border border-[#201e26] space-y-1">
                  <div className="text-[10px] uppercase font-bold text-[#8c8694] flex items-center gap-1">
                    <Flame className="w-3 h-3 text-pink-400" />
                    Plate Filament
                  </div>
                  <div className="text-sm font-bold text-pink-400">
                    {(activePlate?.estimatedWeightGrams || 0).toFixed(1)} g ({filament?.name || 'PLA'})
                  </div>
                </div>
              </div>

              {/* Items on this Plate */}
              <div className="space-y-1.5 pt-2 border-t border-[#23212b]">
                <div className="text-[11px] font-semibold text-[#8c8694]">Parts on this plate ({activePlate?.items.length}):</div>
                <div className="space-y-1 max-h-36 overflow-y-auto">
                  {activePlate?.items.map((item, idx) => {
                    const origPartIdx = parts.findIndex((p) => p.id === item.partId);
                    const color = PART_PALETTE[(origPartIdx >= 0 ? origPartIdx : idx) % PART_PALETTE.length];
                    return (
                      <div key={item.instanceId} className="flex items-center justify-between text-xs p-1.5 rounded-lg bg-[#191820] border border-[#25232d]">
                        <div className="flex items-center gap-2">
                          <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
                          <span className="text-white font-medium">{item.partName}</span>
                        </div>
                        <span className="font-mono text-[11px] text-[#8c8694]">
                          {item.dimensions.x.toFixed(0)}×{item.dimensions.y.toFixed(0)}×{item.dimensions.z.toFixed(0)} mm
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Spacing & Margin Sliders */}
            <div className="bg-[#16151a] border border-[#282531] rounded-2xl p-4 space-y-3">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-blue-400" />
                Plate Packing Parameters
              </span>

              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs text-[#9d98a5]">
                  <span>Part-to-Part Spacing:</span>
                  <span className="font-mono text-white font-bold">{partSpacingMm} mm</span>
                </div>
                <input
                  type="range"
                  min="4"
                  max="25"
                  step="1"
                  value={partSpacingMm}
                  onChange={(e) => setPartSpacingMm(Number(e.target.value))}
                  className="w-full accent-blue-500 h-1.5 bg-[#25232d] rounded-lg cursor-pointer"
                />
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs text-[#9d98a5]">
                  <span>Bed Edge Margin:</span>
                  <span className="font-mono text-white font-bold">{bedMarginMm} mm</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="25"
                  step="1"
                  value={bedMarginMm}
                  onChange={(e) => setBedMarginMm(Number(e.target.value))}
                  className="w-full accent-blue-500 h-1.5 bg-[#25232d] rounded-lg cursor-pointer"
                />
              </div>
            </div>

            {/* Total Assembly Print Overview */}
            <div className="p-3.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-xs text-blue-200 flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="font-bold text-white">Full Assembly Batch Total:</div>
                <div className="text-[11px] text-blue-300">
                  {platePlan.totalEstimatedWeightGrams.toFixed(1)}g total • ~{Math.floor(platePlan.totalEstimatedPrintTimeMinutes / 60)}h {platePlan.totalEstimatedPrintTimeMinutes % 60}m across {platePlan.totalPlates} plate{platePlan.totalPlates > 1 ? 's' : ''}
                </div>
              </div>
              <button
                onClick={() => downloadMultiPartZip({
                  projectName,
                  versionLabel,
                  parts,
                  scale: scaleFactor,
                  filamentType: filament?.name || 'PLA',
                  printerName: printer.name,
                })}
                className="px-3 py-1.5 rounded-xl bg-blue-500 hover:bg-blue-600 text-white font-bold text-xs shadow-md shadow-blue-500/20 transition-all flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Export ZIP
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
