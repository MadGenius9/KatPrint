import { KatPrintProject, ModelVersion, DesignConversationMessage, StorageUsageStats } from '../projects/projectTypes';
import { duplicateProjectGraph, normalizeKatPrintProject } from '../projects/projectService';

const DB_NAME = 'katprint_workspace_db';
const DB_VERSION = 1;
const STORE_PROJECTS = 'projects';
const STORE_THUMBNAILS = 'thumbnails';

// In-memory fallback cache in case IndexedDB fails or is unavailable
let memoryProjectsCache: Map<string, KatPrintProject> = new Map();

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB is not supported in this environment.'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;

      if (!db.objectStoreNames.contains(STORE_PROJECTS)) {
        const projectStore = db.createObjectStore(STORE_PROJECTS, { keyPath: 'id' });
        projectStore.createIndex('updatedAt', 'updatedAt', { unique: false });
        projectStore.createIndex('name', 'name', { unique: false });
      }

      if (!db.objectStoreNames.contains(STORE_THUMBNAILS)) {
        db.createObjectStore(STORE_THUMBNAILS, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Failed to open IndexedDB database.'));
  });
}

export class IndexedDbProjectRepository {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private getDB(): Promise<IDBDatabase> {
    if (!this.dbPromise) {
      this.dbPromise = openDatabase().catch((err) => {
        console.warn('IndexedDB unavailable, operating in in-memory fallback mode:', err);
        throw err;
      });
    }
    return this.dbPromise;
  }

  async listProjects(): Promise<KatPrintProject[]> {
    try {
      const db = await this.getDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_PROJECTS, 'readonly');
        const store = tx.objectStore(STORE_PROJECTS);
        const request = store.getAll();

        request.onsuccess = async () => {
          const rawList = (request.result as any[]) || [];
          const list: KatPrintProject[] = [];
          const unmigrated: KatPrintProject[] = [];

          for (const raw of rawList) {
            const project = normalizeKatPrintProject(raw);
            list.push(project);
            if (!raw.dataSchemaVersion || raw.dataSchemaVersion < 3) {
              unmigrated.push(project);
            }
          }

          // Sort by updatedAt descending
          list.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
          // Sync in-memory cache
          list.forEach((p) => memoryProjectsCache.set(p.id, p));

          // Asynchronously persist any migrated projects back to DB without blocking
          if (unmigrated.length > 0) {
            (async () => {
              for (const proj of unmigrated) {
                try {
                  await this.updateProject(proj);
                } catch (e) {
                  console.warn('Failed to persist migrated project:', proj.id, e);
                }
              }
            })();
          }

          resolve(list);
        };
        request.onerror = () => reject(request.error);
      });
    } catch {
      const list = Array.from(memoryProjectsCache.values()).map((p) => normalizeKatPrintProject(p));
      list.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      return list;
    }
  }

  async getProject(id: string): Promise<KatPrintProject | null> {
    try {
      const db = await this.getDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_PROJECTS, 'readonly');
        const store = tx.objectStore(STORE_PROJECTS);
        const request = store.get(id);

        request.onsuccess = () => {
          const raw = request.result;
          if (!raw) {
            resolve(null);
            return;
          }
          const project = normalizeKatPrintProject(raw);
          memoryProjectsCache.set(project.id, project);

          // If unmigrated schema, persist migrated version back
          if (!raw.dataSchemaVersion || raw.dataSchemaVersion < 3) {
            this.updateProject(project).catch((e) =>
              console.warn('Failed to persist migrated single project:', project.id, e)
            );
          }

          resolve(project);
        };
        request.onerror = () => reject(request.error);
      });
    } catch {
      const cached = memoryProjectsCache.get(id);
      return cached ? normalizeKatPrintProject(cached) : null;
    }
  }

  async createProject(project: KatPrintProject): Promise<KatPrintProject> {
    const normalized = normalizeKatPrintProject(project);
    normalized.updatedAt = new Date().toISOString();
    if (!normalized.createdAt) {
      normalized.createdAt = normalized.updatedAt;
    }

    try {
      const db = await this.getDB();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(STORE_PROJECTS, 'readwrite');
        const store = tx.objectStore(STORE_PROJECTS);
        const request = store.put(normalized);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    } catch (err) {
      console.warn('Writing to IndexedDB failed, storing in memory:', err);
    }

    memoryProjectsCache.set(normalized.id, normalized);
    return normalized;
  }

  async updateProject(project: KatPrintProject): Promise<KatPrintProject> {
    const normalized = normalizeKatPrintProject(project);
    normalized.updatedAt = new Date().toISOString();

    try {
      const db = await this.getDB();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(STORE_PROJECTS, 'readwrite');
        const store = tx.objectStore(STORE_PROJECTS);
        const request = store.put(normalized);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    } catch (err) {
      console.warn('Updating IndexedDB failed, updating in memory:', err);
    }

    memoryProjectsCache.set(normalized.id, normalized);
    return normalized;
  }

  async saveProject(project: KatPrintProject): Promise<KatPrintProject> {
    return this.createProject(project);
  }

  async deleteProject(id: string): Promise<void> {
    try {
      const db = await this.getDB();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(STORE_PROJECTS, 'readwrite');
        const store = tx.objectStore(STORE_PROJECTS);
        const request = store.delete(id);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    } catch (err) {
      console.warn('Deleting from IndexedDB failed:', err);
    }

    memoryProjectsCache.delete(id);
  }

  async duplicateProject(id: string, newName?: string): Promise<KatPrintProject> {
    const original = await this.getProject(id);
    if (!original) {
      throw new Error(`Project with ID ${id} not found.`);
    }

    const duplicated = duplicateProjectGraph(original, newName);
    return this.createProject(duplicated);
  }

  async saveVersion(projectId: string, version: ModelVersion): Promise<void> {
    const project = await this.getProject(projectId);
    if (!project) {
      throw new Error(`Project ${projectId} not found to attach version.`);
    }

    if (!project.versions) project.versions = [];

    // Check if version already exists
    const existingIndex = project.versions.findIndex((v) => v.id === version.id);
    if (existingIndex >= 0) {
      project.versions[existingIndex] = version;
    } else {
      project.versions.push(version);
    }

    project.currentVersionId = version.id;
    if (version.thumbnail) {
      project.thumbnail = version.thumbnail;
    }

    await this.updateProject(project);
  }

  async saveConversationMessage(projectId: string, message: DesignConversationMessage): Promise<void> {
    const project = await this.getProject(projectId);
    if (!project) return;

    if (!project.conversation) project.conversation = [];
    project.conversation.push(message);
    await this.updateProject(project);
  }

  async getStorageUsage(): Promise<StorageUsageStats> {
    const projects = await this.listProjects();
    const versionCount = projects.reduce((sum, p) => sum + (p.versions?.length || 0), 0);

    // Approximate storage byte size
    const jsonStr = JSON.stringify(projects);
    const estimatedBytes = new Blob([jsonStr]).size;

    return {
      projectCount: projects.length,
      versionCount,
      estimatedBytes,
      lastUpdated: new Date().toISOString(),
    };
  }

  async deleteOldInspectionImages(): Promise<number> {
    const projects = await this.listProjects();
    let cleaned = 0;

    for (const project of projects) {
      let modified = false;
      for (const ver of (project.versions || [])) {
        if (ver.inspectionImages) {
          ver.inspectionImages = undefined;
          modified = true;
          cleaned++;
        }
      }
      if (modified) {
        await this.updateProject(project);
      }
    }

    return cleaned;
  }

  async clearAllData(): Promise<void> {
    try {
      const db = await this.getDB();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction([STORE_PROJECTS, STORE_THUMBNAILS], 'readwrite');
        tx.objectStore(STORE_PROJECTS).clear();
        tx.objectStore(STORE_THUMBNAILS).clear();
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    } catch (err) {
      console.warn('Error clearing IndexedDB data:', err);
    }

    memoryProjectsCache.clear();
  }

  async exportProjectFile(projectId: string): Promise<Blob> {
    const project = await this.getProject(projectId);
    if (!project) {
      throw new Error(`Project ${projectId} not found.`);
    }

    const { serializeProject } = await import('../projects/projectSerializer');
    const json = serializeProject(project);
    return new Blob([json], { type: 'application/json' });
  }

  async importProjectFile(jsonContent: string): Promise<KatPrintProject> {
    const { deserializeProject } = await import('../projects/projectSerializer');
    const existingList = await this.listProjects();
    const existingIds = existingList.map((p) => p.id);

    const project = deserializeProject(jsonContent, existingIds);
    return this.createProject(project);
  }
}

export const defaultProjectRepository = new IndexedDbProjectRepository();
