import { ModelVersion, VersionComparisonData } from '../projects/projectTypes';
import { compareFeatureModels } from '../features/featureModel';

export function compareVersions(versionA: ModelVersion, versionB: ModelVersion): VersionComparisonData {
  const dimA = versionA.geometryMetadata?.dimensions || { x: 0, y: 0, z: 0 };
  const dimB = versionB.geometryMetadata?.dimensions || { x: 0, y: 0, z: 0 };

  const volA = versionA.geometryMetadata?.volumeMm3 || 0;
  const volB = versionB.geometryMetadata?.volumeMm3 || 0;
  const volDiff = volB - volA;
  const volPercent = volA > 0 ? (volDiff / volA) * 100 : 0;

  const triA = versionA.geometryMetadata?.triangleCount || 0;
  const triB = versionB.geometryMetadata?.triangleCount || 0;

  const scoreA = versionA.designMatchScore ?? versionA.fidelityReview?.overallScore ?? null;
  const scoreB = versionB.designMatchScore ?? versionB.fidelityReview?.overallScore ?? null;
  const scoreDiffVal = scoreA !== null && scoreB !== null ? scoreB - scoreA : null;

  const featuresA = (versionA.designSpecification?.requiredFeatures || []).map((f) => f.name.toLowerCase());
  const featuresB = (versionB.designSpecification?.requiredFeatures || []).map((f) => f.name.toLowerCase());

  const addedFeatures = (versionB.designSpecification?.requiredFeatures || [])
    .filter((fb) => !featuresA.includes(fb.name.toLowerCase()))
    .map((f) => f.name);

  const removedFeatures = (versionA.designSpecification?.requiredFeatures || [])
    .filter((fa) => !featuresB.includes(fa.name.toLowerCase()))
    .map((f) => f.name);

  const preservedFeatures = (versionB.designSpecification?.requiredFeatures || [])
    .filter((fb) => featuresA.includes(fb.name.toLowerCase()))
    .map((f) => f.name);

  const specDiffs: Array<{ label: string; valueA: string; valueB: string }> = [];

  const specA = versionA.designSpecification;
  const specB = versionB.designSpecification;

  if (specA && specB) {
    if (specA.primaryObject !== specB.primaryObject) {
      specDiffs.push({ label: 'Primary Object', valueA: specA.primaryObject || 'N/A', valueB: specB.primaryObject || 'N/A' });
    }
    if (specA.intendedFunction !== specB.intendedFunction) {
      specDiffs.push({ label: 'Intended Function', valueA: specA.intendedFunction || 'N/A', valueB: specB.intendedFunction || 'N/A' });
    }
    const targetA = specA.compatibilityTargets?.map((c) => (typeof c === 'string' ? c : c.name)).join(', ') || 'None';
    const targetB = specB.compatibilityTargets?.map((c) => (typeof c === 'string' ? c : c.name)).join(', ') || 'None';
    if (targetA !== targetB) {
      specDiffs.push({ label: 'Compatibility Target', valueA: targetA, valueB: targetB });
    }
    if (specA.mountingStyle !== specB.mountingStyle) {
      specDiffs.push({ label: 'Mounting Style', valueA: specA.mountingStyle || 'None', valueB: specB.mountingStyle || 'None' });
    }
  }

  const codeChanged = (versionA.cadCode || '').trim() !== (versionB.cadCode || '').trim();
  const featureModelDiff = compareFeatureModels(versionA.featureModel, versionB.featureModel);

  return {
    versionA,
    versionB,
    dimensionDiffs: {
      width: { a: dimA.x, b: dimB.x, diff: Number((dimB.x - dimA.x).toFixed(2)) },
      depth: { a: dimA.y, b: dimB.y, diff: Number((dimB.y - dimA.y).toFixed(2)) },
      height: { a: dimA.z, b: dimB.z, diff: Number((dimB.z - dimA.z).toFixed(2)) },
    },
    volumeDiff: {
      a: volA,
      b: volB,
      diff: Number(volDiff.toFixed(1)),
      percentChange: Number(volPercent.toFixed(1)),
    },
    triangleCountDiff: {
      a: triA,
      b: triB,
      diff: triB - triA,
    },
    scoreDiff: {
      a: scoreA,
      b: scoreB,
      diff: scoreDiffVal,
    },
    manifoldStatus: {
      a: versionA.geometryMetadata?.isManifold ?? false,
      b: versionB.geometryMetadata?.isManifold ?? false,
    },
    addedFeatures,
    removedFeatures,
    preservedFeatures,
    specificationDiffs: specDiffs,
    codeChanged,
    featureModelDiff,
  };
}
