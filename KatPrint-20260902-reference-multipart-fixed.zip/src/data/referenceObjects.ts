import { ReferenceObject } from '../types';

export interface KnownReferenceItem {
  id: string;
  name: string;
  aliases: string[];
  dimensions: {
    width: number;
    depth: number;
    height: number;
    diameter?: number;
  };
  recommendedClearanceMm: number;
  confidence: 'verified' | 'estimated';
  description: string;
  category: 'electronics' | 'tools' | 'household' | 'beverage' | 'plumbing' | 'hardware';
}

export const KNOWN_REFERENCE_OBJECTS: KnownReferenceItem[] = [
  {
    id: 'dr_squatch_soap',
    name: 'Dr. Squatch Soap Bar',
    aliases: ['dr squatch', 'squatch bar', 'dr. squatch', 'squatch soap', 'dr.squatch'],
    dimensions: { width: 76.2, depth: 76.2, height: 25.4 }, // standard 3" x 3" x 1"
    recommendedClearanceMm: 2.0,
    confidence: 'verified',
    description: 'Square cold process bar (3" × 3" × 1")',
    category: 'household',
  },
  {
    id: 'standard_soap_bar',
    name: 'Standard Bar Soap (Dove / Dial)',
    aliases: ['soap bar', 'bar soap', 'bath soap', 'dove bar'],
    dimensions: { width: 88.0, depth: 56.0, height: 26.0 },
    recommendedClearanceMm: 3.0,
    confidence: 'verified',
    description: 'Standard rectangular rounded bar soap',
    category: 'household',
  },
  {
    id: 'iphone_15',
    name: 'Apple iPhone 15 / 14 / 13',
    aliases: ['iphone 15', 'iphone 14', 'iphone 13', 'iphone', 'standard iphone'],
    dimensions: { width: 71.6, depth: 7.8, height: 147.6 },
    recommendedClearanceMm: 1.5,
    confidence: 'verified',
    description: '6.1-inch standard smartphone body',
    category: 'electronics',
  },
  {
    id: 'iphone_15_pro_max',
    name: 'Apple iPhone 15 Pro Max',
    aliases: ['iphone 15 pro max', 'iphone 14 pro max', 'iphone max', 'pro max'],
    dimensions: { width: 76.7, depth: 8.25, height: 159.9 },
    recommendedClearanceMm: 1.5,
    confidence: 'verified',
    description: '6.7-inch flagship smartphone body',
    category: 'electronics',
  },
  {
    id: 'xbox_controller',
    name: 'Xbox Wireless Controller',
    aliases: ['xbox controller', 'xbox series x controller', 'xbox one controller', 'gamepad'],
    dimensions: { width: 155.0, depth: 108.0, height: 63.0 },
    recommendedClearanceMm: 3.0,
    confidence: 'verified',
    description: 'Xbox Series X/S standard gamepad',
    category: 'electronics',
  },
  {
    id: 'ps5_dualsense',
    name: 'PlayStation 5 DualSense Controller',
    aliases: ['ps5 controller', 'dualsense', 'playstation 5 controller', 'ps5 gamepad'],
    dimensions: { width: 160.0, depth: 106.0, height: 66.0 },
    recommendedClearanceMm: 3.0,
    confidence: 'verified',
    description: 'Sony PlayStation 5 DualSense controller',
    category: 'electronics',
  },
  {
    id: 'stanley_tumbler_40oz',
    name: 'Stanley Quencher 40 oz Tumbler',
    aliases: ['stanley tumbler', 'stanley cup', '40oz stanley', 'stanley 40oz', 'quencher'],
    dimensions: { width: 100.0, depth: 100.0, height: 260.0, diameter: 78.0 }, // base diameter 78mm
    recommendedClearanceMm: 2.5,
    confidence: 'verified',
    description: '40 oz insulated tumbler with 78mm tapered base',
    category: 'beverage',
  },
  {
    id: 'yeti_20oz_tumbler',
    name: 'YETI Rambler 20 oz Tumbler',
    aliases: ['yeti tumbler', 'yeti 20oz', 'rambler 20oz', 'yeti cup'],
    dimensions: { width: 88.0, depth: 88.0, height: 175.0, diameter: 70.0 }, // base diameter 70mm
    recommendedClearanceMm: 2.0,
    confidence: 'verified',
    description: '20 oz insulated tumbler with 70mm base',
    category: 'beverage',
  },
  {
    id: 'milwaukee_m18_battery',
    name: 'Milwaukee M18 RedLithium Battery',
    aliases: ['milwaukee m18', 'm18 battery', 'milwaukee battery'],
    dimensions: { width: 78.0, depth: 120.0, height: 68.0 },
    recommendedClearanceMm: 1.5,
    confidence: 'verified',
    description: 'Milwaukee M18 standard tool slide battery pack',
    category: 'tools',
  },
  {
    id: 'dewalt_20v_battery',
    name: 'DeWalt 20V MAX Battery',
    aliases: ['dewalt 20v', 'dewalt battery', '20v max battery'],
    dimensions: { width: 75.0, depth: 115.0, height: 65.0 },
    recommendedClearanceMm: 1.5,
    confidence: 'verified',
    description: 'DeWalt 20V MAX slide battery pack',
    category: 'tools',
  },
  {
    id: 'aa_battery',
    name: 'AA Alkaline / Rechargeable Battery',
    aliases: ['aa battery', 'double a battery', 'aa batteries'],
    dimensions: { width: 14.5, depth: 14.5, height: 50.5, diameter: 14.5 },
    recommendedClearanceMm: 0.5,
    confidence: 'verified',
    description: 'Standard 14.5mm × 50.5mm cylindrical cell',
    category: 'hardware',
  },
  {
    id: '18650_battery',
    name: '18650 Li-Ion Cell',
    aliases: ['18650', '18650 battery', '18650 cell'],
    dimensions: { width: 18.5, depth: 18.5, height: 65.2, diameter: 18.5 },
    recommendedClearanceMm: 0.5,
    confidence: 'verified',
    description: '18.5mm × 65.2mm lithium-ion cylindrical cell',
    category: 'hardware',
  },
  {
    id: 'pvc_pipe_2in',
    name: '2-Inch Schedule 40 PVC Pipe',
    aliases: ['2 inch pvc', '2" pvc', '2in pvc', '2-inch pipe'],
    dimensions: { width: 60.3, depth: 60.3, height: 100.0, diameter: 60.3 }, // OD: 2.375" = 60.33 mm
    recommendedClearanceMm: 1.0,
    confidence: 'verified',
    description: 'Standard 2" Sch 40 PVC (Outer Diameter: 60.3 mm)',
    category: 'plumbing',
  },
  {
    id: 'pvc_pipe_1in',
    name: '1-Inch Schedule 40 PVC Pipe',
    aliases: ['1 inch pvc', '1" pvc', '1in pvc', '1-inch pipe'],
    dimensions: { width: 33.4, depth: 33.4, height: 100.0, diameter: 33.4 }, // OD: 1.315" = 33.4 mm
    recommendedClearanceMm: 0.8,
    confidence: 'verified',
    description: 'Standard 1" Sch 40 PVC (Outer Diameter: 33.4 mm)',
    category: 'plumbing',
  },
  {
    id: 'credit_card',
    name: 'Standard Credit / ID Card (CR80)',
    aliases: ['credit card', 'id card', 'business card', 'gift card'],
    dimensions: { width: 85.6, depth: 0.8, height: 54.0 },
    recommendedClearanceMm: 1.0,
    confidence: 'verified',
    description: 'ISO/IEC 7810 ID-1 standard card (85.60 × 53.98 × 0.76 mm)',
    category: 'household',
  },
];

/**
 * Searches known reference object database for a matching item in the prompt
 */
export function findKnownReferenceObject(prompt: string): ReferenceObject | null {
  const p = prompt.toLowerCase();
  for (const item of KNOWN_REFERENCE_OBJECTS) {
    if (item.aliases.some((alias) => p.includes(alias.toLowerCase()))) {
      return {
        name: item.name,
        dimensions: { ...item.dimensions },
        confidence: item.confidence,
        clearanceMm: item.recommendedClearanceMm,
        sourceNote: item.description,
      };
    }
  }
  return null;
}
