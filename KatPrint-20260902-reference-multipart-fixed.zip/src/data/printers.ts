import { PrinterSpec } from '../types';

export const INITIAL_PRINTERS: PrinterSpec[] = [
  // ---------- CREALITY — Ender ----------
  { id: 'ender-3-v2', name: 'Creality Ender 3 V2', buildVolume: { x: 220, y: 220, z: 250 }, nozzleDiameter: 0.4, driveType: 'bowden', isEnclosed: false, maxVolumetricFlow: 11 },
  { id: 'ender-3-s1-pro', name: 'Creality Ender 3 S1 Pro', buildVolume: { x: 220, y: 220, z: 270 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 15 },
  { id: 'ender-3-v3-se', name: 'Creality Ender 3 V3 SE', buildVolume: { x: 220, y: 220, z: 250 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 12 },
  { id: 'ender-3-v3-ke', name: 'Creality Ender 3 V3 KE', buildVolume: { x: 220, y: 220, z: 240 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 20 },
  { id: 'ender-3-v3', name: 'Creality Ender 3 V3', buildVolume: { x: 220, y: 220, z: 250 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 24 },
  { id: 'ender-3-v3-plus', name: 'Creality Ender 3 V3 Plus', buildVolume: { x: 300, y: 300, z: 330 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 24 },
  { id: 'ender-5-s1', name: 'Creality Ender 5 S1', buildVolume: { x: 220, y: 220, z: 280 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 18 },
  { id: 'ender-5-max', name: 'Creality Ender 5 Max', buildVolume: { x: 400, y: 400, z: 400 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 28 },

  // ---------- CREALITY — K1 (enclosed CoreXY) ----------
  { id: 'creality-k1', name: 'Creality K1', buildVolume: { x: 220, y: 220, z: 250 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 30 },
  { id: 'creality-k1-se', name: 'Creality K1 SE', buildVolume: { x: 220, y: 220, z: 250 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 28 },
  { id: 'creality-k1c', name: 'Creality K1C', buildVolume: { x: 220, y: 220, z: 250 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 32 },
  { id: 'creality-k1-max', name: 'Creality K1 Max', buildVolume: { x: 300, y: 300, z: 300 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 32 },

  // ---------- CREALITY — K2 (CFS flagships) ----------
  { id: 'creality-k2', name: 'Creality K2', buildVolume: { x: 260, y: 260, z: 260 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 32 },
  { id: 'creality-k2-pro', name: 'Creality K2 Pro', buildVolume: { x: 260, y: 260, z: 260 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 34 },
  { id: 'creality-k2-plus', name: 'Creality K2 Plus', buildVolume: { x: 350, y: 350, z: 350 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 36 },

  // ---------- CREALITY — other ----------
  { id: 'creality-hi', name: 'Creality Hi', buildVolume: { x: 260, y: 260, z: 300 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 22 },
  { id: 'creality-cr10-se', name: 'Creality CR-10 SE', buildVolume: { x: 220, y: 220, z: 265 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 20 },
  { id: 'creality-cr-m4', name: 'Creality CR-M4', buildVolume: { x: 450, y: 450, z: 470 }, nozzleDiameter: 0.4, driveType: 'bowden', isEnclosed: false, maxVolumetricFlow: 22 },

  // ---------- BAMBU LAB ----------
  { id: 'bambu-a1-mini', name: 'Bambu Lab A1 mini', buildVolume: { x: 180, y: 180, z: 180 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 28 },
  { id: 'bambu-a1', name: 'Bambu Lab A1', buildVolume: { x: 256, y: 256, z: 256 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 28 },
  { id: 'bambu-p1p', name: 'Bambu Lab P1P', buildVolume: { x: 256, y: 256, z: 256 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 32 },
  { id: 'bambu-p1s', name: 'Bambu Lab P1S', buildVolume: { x: 256, y: 256, z: 256 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 32 },
  { id: 'bambu-x1c', name: 'Bambu Lab X1-Carbon', buildVolume: { x: 256, y: 256, z: 256 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 32 },
  { id: 'bambu-x1e', name: 'Bambu Lab X1E', buildVolume: { x: 256, y: 256, z: 256 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 32 },
  { id: 'bambu-h2d', name: 'Bambu Lab H2D', buildVolume: { x: 350, y: 320, z: 325 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 36 },

  // ---------- PRUSA ----------
  { id: 'prusa-mini', name: 'Prusa MINI+', buildVolume: { x: 180, y: 180, z: 180 }, nozzleDiameter: 0.4, driveType: 'bowden', isEnclosed: false, maxVolumetricFlow: 15 },
  { id: 'prusa-mk3s', name: 'Prusa MK3S+', buildVolume: { x: 250, y: 210, z: 210 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 15 },
  { id: 'prusa-mk4', name: 'Prusa MK4 / MK4S', buildVolume: { x: 250, y: 210, z: 220 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 22 },
  { id: 'prusa-core-one', name: 'Prusa CORE One', buildVolume: { x: 250, y: 220, z: 270 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 24 },
  { id: 'prusa-xl', name: 'Prusa XL', buildVolume: { x: 360, y: 360, z: 360 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 26 },

  // ---------- ELEGOO ----------
  { id: 'elegoo-neptune-4-pro', name: 'Elegoo Neptune 4 Pro', buildVolume: { x: 225, y: 225, z: 265 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 25 },
  { id: 'elegoo-neptune-4-max', name: 'Elegoo Neptune 4 Max', buildVolume: { x: 420, y: 420, z: 480 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 25 },
  { id: 'elegoo-centauri-carbon', name: 'Elegoo Centauri Carbon', buildVolume: { x: 256, y: 256, z: 256 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 28 },

  // ---------- ANYCUBIC ----------
  { id: 'anycubic-kobra-2-pro', name: 'Anycubic Kobra 2 Pro', buildVolume: { x: 220, y: 220, z: 250 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 20 },
  { id: 'anycubic-kobra-3', name: 'Anycubic Kobra 3', buildVolume: { x: 250, y: 250, z: 260 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 25 },
  { id: 'anycubic-kobra-3-max', name: 'Anycubic Kobra 3 Max', buildVolume: { x: 420, y: 420, z: 500 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 25 },

  // ---------- SOVOL / QIDI / VORON ----------
  { id: 'sovol-sv06-plus', name: 'Sovol SV06 Plus', buildVolume: { x: 300, y: 300, z: 340 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 20 },
  { id: 'sovol-sv08', name: 'Sovol SV08', buildVolume: { x: 350, y: 350, z: 345 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 30 },
  { id: 'qidi-q1-pro', name: 'QIDI Q1 Pro', buildVolume: { x: 245, y: 245, z: 245 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 25 },
  { id: 'qidi-x-plus-3', name: 'QIDI X-Plus 3', buildVolume: { x: 280, y: 280, z: 270 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 28 },
  { id: 'voron-24-350', name: 'Voron 2.4 (350mm)', buildVolume: { x: 350, y: 350, z: 330 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: true, maxVolumetricFlow: 35 },

  // ---------- CUSTOM ----------
  { id: 'custom', name: 'Custom Printer', buildVolume: { x: 300, y: 300, z: 300 }, nozzleDiameter: 0.4, driveType: 'direct', isEnclosed: false, maxVolumetricFlow: 20, isCustom: true },
];
