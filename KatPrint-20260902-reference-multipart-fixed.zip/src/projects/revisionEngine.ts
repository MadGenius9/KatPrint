import {
  KatPrintProject,
  ModelVersion,
  DesignConversationMessage,
} from './projectTypes';
import { parseRevisionInstruction } from '../revisions/parseRevision';
import { getNextVersionNumber, createVersionLabel, buildModelVersion } from './projectService';
import { restoreVersionAsNewHead, branchNewVersion } from '../versions/versionService';
import { updateProjectMemoryFromVersion } from './projectMemory';
import { executeJscadCode } from '../engine/jscadRunner';
import { analyzeBufferGeometry } from '../engine/geometryUtils';
import {
  requestJscadRevision,
  requestFidelityReview,
  requestTargetedRepair,
  RevisionContextPayload,
} from '../services/geminiService';
import { renderInspectionViews, generateCadThumbnail } from '../engine/designVerification/renderInspectionViews';
import { performDeterministicInspection } from '../engine/designVerification/geometryVerification';
import { generateDesignChecklist } from '../engine/designIntent/designChecklist';
import { validateDesignSpecification } from '../engine/designIntent/designSpecification';
import { buildGenerationDiagnostics } from './generationDiagnostics';
import { AIRequestRecord } from '../types';
import {
  SemanticFeatureModel,
  SemanticRevisionOpType,
  resolveSemanticRevision,
  verifySemanticFeatureModel,
  reconstructLegacyFeatureModel,
  updateParameterValue,
  updateJscadConstants,
  planSemanticFeatureModel,
  finalizeFeatureModelForCode,
} from '../features';

export { restoreVersionAsNewHead, branchNewVersion, parseRevisionInstruction };

export interface ApplyRevisionOutcome {
  updatedProject: KatPrintProject;
  newVersion: ModelVersion;
  isUndo: boolean;
  changeSummary: string;
}

export async function applyRevisionToProject(params: {
  project: KatPrintProject;
  instruction: string;
  currentCode: string;
  selectedFilamentDensity?: number;
  selectedFeatureIds?: string[];
  onProgress?: (stage: string) => void;
}): Promise<ApplyRevisionOutcome> {
  const { project, instruction, currentCode, selectedFilamentDensity = 1.24, selectedFeatureIds, onProgress } = params;

  const currentVer =
    project.versions.find((v) => v.id === project.currentVersionId) ||
    project.versions[project.versions.length - 1];

  if (!currentVer) {
    throw new Error('Cannot revise project: no active version exists.');
  }

  onProgress?.('interpreting_change');
  const changeSet = parseRevisionInstruction(instruction, currentVer, project);

  // 1. Natural Undo check
  if (changeSet.isNaturalUndo && changeSet.targetRestoreVersionId) {
    onProgress?.('restoring_version');
    const updatedVersions = restoreVersionAsNewHead(project.versions, changeSet.targetRestoreVersionId);
    const newHead = updatedVersions.find((v) => v.isCurrentHead)!;

    const undoMsg: DesignConversationMessage = {
      id: `msg_${Date.now()}`,
      projectId: project.id,
      role: 'katprint',
      content: `Reverted to state before previous change (${newHead.label}). Created V${newHead.versionNumber}.`,
      timestamp: new Date().toISOString(),
      relatedVersionId: newHead.id,
      actionType: 'undo',
    };

    const updatedProject: KatPrintProject = {
      ...project,
      versions: updatedVersions,
      currentVersionId: newHead.id,
      conversation: [...project.conversation, undoMsg],
      updatedAt: new Date().toISOString(),
      thumbnail: newHead.thumbnail || project.thumbnail,
      projectMemory: updateProjectMemoryFromVersion(project.projectMemory, newHead, `Undo: restore V${newHead.versionNumber}`),
    };

    return {
      updatedProject,
      newVersion: newHead,
      isUndo: true,
      changeSummary: `Reverted to previous version (${newHead.label}).`,
    };
  }

  // 2. Feature Model Check & Direct Semantic Resolution
  let currentFeatureModel: SemanticFeatureModel = currentVer.featureModel ||
    reconstructLegacyFeatureModel(
      currentVer.cadCode || currentCode,
      project.originalPrompt || instruction,
      currentVer.designSpecification,
      currentVer.geometryMetadata
    ).model;

  const semanticResolution = resolveSemanticRevision(
    currentFeatureModel,
    instruction,
    currentVer.cadCode || currentCode,
    selectedFeatureIds
  );

  const mode = project.projectSettings?.generationMode || 'precision';
  const startTime = Date.now();
  let repairAttemptsCount = 0;
  const collectedRequestRecords: AIRequestRecord[] = [];

  let revisedCode = semanticResolution.updatedCadCode || currentVer.cadCode || currentCode;
  let activeFeatureModel = semanticResolution.updatedModel;
  let changeSummary = semanticResolution.explanation;

  // If directly resolved without LLM, test geometry compilation
  let directCompilationSuccess = false;
  if (semanticResolution.wasDirectlyResolved && semanticResolution.updatedCadCode) {
    try {
      const testGeom = executeJscadCode(semanticResolution.updatedCadCode);
      const testStats = analyzeBufferGeometry(testGeom, selectedFilamentDensity);
      if (testStats.isManifold && testStats.volumeMm3 > 0) {
        directCompilationSuccess = true;
        revisedCode = semanticResolution.updatedCadCode;
      }
    } catch {
      directCompilationSuccess = false;
    }
  }

  // If not directly resolved, invoke Gemini Revision API
  if (!directCompilationSuccess) {
    onProgress?.('revising_cad');
    const spec = currentVer.designSpecification;
    const newSpec = changeSet.newDesignSpecification || spec;

    const prevReqs = spec
      ? {
          primaryObject: spec.primaryObject,
          requiredFeatures: spec.requiredFeatures?.map((f) => f.name) || [],
          explicitDimensions: spec.explicitDimensions || [],
        }
      : undefined;

    const recentConversation = (project.conversation || [])
      .slice(-8)
      .map((m) => ({ role: m.role, content: m.content, timestamp: m.timestamp }));

    const existingMemory = project.projectMemory || {};
    const currentMemory = {
      ...existingMemory,
      importantDecisions: existingMemory.importantDecisions || [],
      userRejectedOptions: existingMemory.userRejectedOptions || [],
    };

    const lockedParameterIds = (currentFeatureModel.parameters || [])
      .filter((p) => p.locked)
      .map((p) => p.id);

    const revisionContext: RevisionContextPayload = {
      requestedChanges: changeSet.requestedChanges || [],
      preservedFeatures: changeSet.preservedFeatures || [],
      designSpecification: newSpec,
      projectMemory: currentMemory,
      recentConversation,
      featureModel: currentFeatureModel,
      targetFeatureModel: semanticResolution.updatedModel,
      semanticOperation: semanticResolution.operation,
      bindingValidation: currentFeatureModel.bindingValidation,
      lockedParameterIds,
      selectedFeatureIds,
    };

    const reviseRes = await requestJscadRevision({
      revisionPrompt: instruction,
      userInstruction: instruction,
      previousRequirements: prevReqs as any,
      revisionContext,
      currentCode: currentVer.cadCode || currentCode,
      originalPrompt: project.originalPrompt,
      referenceImages: project.referenceImages,
    });

    revisedCode = reviseRes.code;
    changeSummary = reviseRes.explanation || changeSet.explanation || instruction;

    if (reviseRes.diagnostics?.requestRecords) {
      collectedRequestRecords.push(...reviseRes.diagnostics.requestRecords);
    }
  }

  // 3. Execute and inspect revised geometry
  let geom = executeJscadCode(revisedCode);
  let stats = analyzeBufferGeometry(geom, selectedFilamentDensity);

  const isLegacy = currentFeatureModel.generationStrategy === 'legacy-reconstructed';
  const bindingMode = isLegacy ? 'legacy' : 'strict';

  // Finalize activeFeatureModel before inspection/review
  activeFeatureModel = finalizeFeatureModelForCode(
    semanticResolution.updatedModel,
    revisedCode,
    stats,
    bindingMode
  );

  const spec = currentVer.designSpecification ? validateDesignSpecification(currentVer.designSpecification, project.originalPrompt || instruction) : null;
  const rawNewSpec = changeSet.newDesignSpecification || spec;
  const newSpec = rawNewSpec ? validateDesignSpecification(rawNewSpec, instruction) : null;
  const checklist = newSpec ? generateDesignChecklist(newSpec) : [];
  let inspection = newSpec
    ? performDeterministicInspection(geom, revisedCode, newSpec, checklist)
    : { items: [], passedChecksCount: 0, totalChecksCount: 0, criticalPassed: true, checks: checklist, warnings: [] };

  const bindingValidation = activeFeatureModel.bindingValidation;
  const hasCriticalBindingDefects =
    (bindingValidation?.criticalUnboundParameters.length ?? 0) > 0 ||
    (bindingValidation?.missingBuilderFeatures.some((fid) =>
      activeFeatureModel.features.find((f) => f.id === fid)?.criticality === 'critical'
    ) ?? false);

  let review = undefined;
  let score: number | null = null;

  if (mode === 'precision' && newSpec && !directCompilationSuccess) {
    try {
      const views = await renderInspectionViews(geom);
      const reviewRes = await requestFidelityReview({
        specification: newSpec,
        code: revisedCode,
        geometryStats: stats,
        deterministicChecks: inspection.checks,
        views,
        purpose: 'visual_fidelity_review',
      });
      if (reviewRes.diagnostics?.requestRecords) {
        collectedRequestRecords.push(...reviewRes.diagnostics.requestRecords);
      }
      review = reviewRes.review;
      score = typeof review.overallScore === 'number' ? review.overallScore : null;

      // Targeted 1-pass repair if review or deterministic inspection or semantic binding fails
      const needsCorrection =
        !inspection.criticalPassed ||
        review.requiresRepair ||
        (review.problems && review.problems.length > 0 && review.verdict !== 'PASS') ||
        hasCriticalBindingDefects;

      if (needsCorrection) {
        onProgress?.('correcting_revision');
        try {
          repairAttemptsCount += 1;
          const lockedParameterIds = (activeFeatureModel.parameters || [])
            .filter((p) => p.locked)
            .map((p) => p.id);

          const repairResult = await requestTargetedRepair({
            originalPrompt: instruction,
            currentCode: revisedCode,
            specification: newSpec,
            reviewResult: review,
            deterministicChecks: inspection.checks,
            geometryStats: stats,
            featureModel: activeFeatureModel,
            bindingValidation: activeFeatureModel.bindingValidation,
            lockedParameterIds,
          });
          if (repairResult.diagnostics?.requestRecords) {
            collectedRequestRecords.push(...repairResult.diagnostics.requestRecords);
          }

          revisedCode = repairResult.code;
          geom = executeJscadCode(revisedCode);
          stats = analyzeBufferGeometry(geom, selectedFilamentDensity);
          inspection = performDeterministicInspection(geom, revisedCode, newSpec, checklist);

          // Re-finalize post-repair activeFeatureModel
          activeFeatureModel = finalizeFeatureModelForCode(
            activeFeatureModel,
            revisedCode,
            stats,
            bindingMode
          );

          const postViews = await renderInspectionViews(geom);
          const finalReviewRes = await requestFidelityReview({
            specification: newSpec,
            code: revisedCode,
            geometryStats: stats,
            deterministicChecks: inspection.checks,
            views: postViews,
            purpose: 'final_visual_review',
          });
          if (finalReviewRes.diagnostics?.requestRecords) {
            collectedRequestRecords.push(...finalReviewRes.diagnostics.requestRecords);
          }
          review = finalReviewRes.review;
          score = typeof review.overallScore === 'number' ? review.overallScore : null;
        } catch (repairErr) {
          console.warn('Revision targeted repair failed, keeping revised model:', repairErr);
        }
      }
    } catch (revErr) {
      console.warn('Fidelity review error during revision:', revErr);
    }
  } else {
    score = null;
  }

  // 4. Final Feature Verification
  const finalFeatureModel = activeFeatureModel;
  const featureVerification = verifySemanticFeatureModel(finalFeatureModel, stats, revisedCode);

  // Generate thumbnail from actual revised 3D geometry
  const thumbnail = generateCadThumbnail(geom);
  const nextVerNum = getNextVersionNumber(project.versions);
  const now = new Date().toISOString();

  const newVersion = buildModelVersion({
    projectId: project.id,
    versionNumber: nextVerNum,
    parentVersionId: currentVer.id,
    label: createVersionLabel(nextVerNum, instruction, 'REVISION'),
    createdAt: now,
    prompt: instruction,
    userInstruction: instruction,
    cadCode: revisedCode,
    geometryMetadata: stats,
    changeSummary,
    changeType: 'REVISION',
    isCurrentHead: true,
    designMatchScore: score,
    designSpecification: newSpec,
    designChecklist: inspection.checks,
    featureModel: finalFeatureModel,
    fidelityReview: review,
    thumbnail: thumbnail || undefined,
    semanticRevisionOperation: semanticResolution.operation,
    generationDiagnostics: buildGenerationDiagnostics({
      generationId: `gen_${Date.now()}`,
      timestamp: Date.now(),
      mode,
      requestRecords: collectedRequestRecords,
      repairAttempts: repairAttemptsCount,
      status: 'success',
      totalDurationMs: Date.now() - startTime,
      latencyMs: Date.now() - startTime,
      measuredDimensions: stats.dimensions,
      measuredVolumeMm3: stats.volumeMm3,
      triangleCount: stats.triangleCount,
      vertexCount: stats.triangleCount * 3,
      isManifold: stats.isManifold,
      nonManifoldEdgeCount: stats.nonManifoldEdgeCount,
      precisionScore: typeof score === 'number' ? score : undefined,
      semanticFeatureCount: finalFeatureModel.features.length,
      verifiedFeatureCount: featureVerification.verifiedCount,
      failedFeatureCount: featureVerification.failedCount,
      unknownFeatureCount: featureVerification.unknownCount,
      boundFeatureCount: finalFeatureModel.bindingValidation?.boundFeatures.length,
      builderBoundFeatureCount: finalFeatureModel.bindingValidation?.builderBoundFeatures.length,
      criticalUnboundParameterCount: finalFeatureModel.bindingValidation?.criticalUnboundParameters.length,
      missingBuilderFeatureCount: finalFeatureModel.bindingValidation?.missingBuilderFeatures.length,
      parameterEditCount: semanticResolution.operation.parameterChanges?.length || 0,
      featureAdditions: semanticResolution.operation.addedFeatures?.length || 0,
      featureRemovals: semanticResolution.operation.removedFeatureIds?.length || 0,
    }),
  });

  const updatedVersions: ModelVersion[] = project.versions.map((v) => ({ ...v, isCurrentHead: false }));
  updatedVersions.push(newVersion);

  const matchText =
    score !== null
      ? `Design Match: **${Math.round(score)}%**`
      : stats.isManifold
      ? `Geometry: **Manifold**`
      : `Geometry: **Validation Required / Non-Manifold**`;
  const featureText = `Features: **${featureVerification.verifiedCount}/${finalFeatureModel.features.length} verified**`;

  const assistantMsg: DesignConversationMessage = {
    id: `msg_${Date.now()}`,
    projectId: project.id,
    role: 'katprint',
    content: `Applied revision: **${instruction}**\n\n- ${changeSummary}\n- Dimensions: ${stats.dimensions.x.toFixed(1)} × ${stats.dimensions.y.toFixed(1)} × ${stats.dimensions.z.toFixed(1)} mm\n- ${featureText}\n- ${matchText}`,
    timestamp: now,
    relatedVersionId: newVersion.id,
    actionType: 'revise',
    designMatchScore: score,
    fidelityReviewResult: review,
  };

  const userMsg: DesignConversationMessage = {
    id: `msg_u_${Date.now()}`,
    projectId: project.id,
    role: 'user',
    content: instruction,
    timestamp: now,
    relatedVersionId: newVersion.id,
  };

  const updatedProject: KatPrintProject = {
    ...project,
    currentVersionId: newVersion.id,
    versions: updatedVersions,
    conversation: [...project.conversation, userMsg, assistantMsg],
    projectMemory: updateProjectMemoryFromVersion(project.projectMemory, newVersion, instruction),
    thumbnail: thumbnail || project.thumbnail,
    updatedAt: now,
  };

  return {
    updatedProject,
    newVersion,
    isUndo: false,
    changeSummary,
  };
}

export interface BoundParameterUpdate {
  parameterId: string;
  newValue: number | string | boolean;
  allowLockedOverride?: boolean;
}

/**
 * Directly applies one or more bound parameter changes to the active project atomically,
 * recompiles JSCAD without LLM generation, validates geometry, and creates a single ModelVersion.
 */
export async function applyBoundParameterChangesToProject(params: {
  project: KatPrintProject;
  updates: BoundParameterUpdate[];
  selectedFilamentDensity?: number;
  operationType?: SemanticRevisionOpType;
  customSummary?: string;
  featureIds?: string[];
  manipulatorType?: string;
}): Promise<ApplyRevisionOutcome> {
  const {
    project,
    updates,
    selectedFilamentDensity = 1.24,
    operationType,
    customSummary,
    featureIds,
    manipulatorType,
  } = params;

  if (!updates || updates.length === 0) {
    throw new Error('Cannot update parameters: no parameter updates provided.');
  }

  const currentVer =
    project.versions.find((v) => v.id === project.currentVersionId) ||
    project.versions[project.versions.length - 1];

  if (!currentVer) {
    throw new Error('Cannot update parameters: no active version.');
  }

  let model =
    currentVer.featureModel ||
    reconstructLegacyFeatureModel(
      currentVer.cadCode,
      project.originalPrompt || '',
      currentVer.designSpecification,
      currentVer.geometryMetadata
    ).model;

  const isLegacy = model.generationStrategy === 'legacy-reconstructed';

  // 1. Validate locks and prepare constant updates
  let currentModel = model;
  const constantUpdates: Array<{ constantName: string; newValue: number | string | boolean }> = [];
  const appliedParamChanges: any[] = [];
  const affectedFeatureIdSet = new Set<string>(featureIds || []);

  for (const update of updates) {
    const targetParam = currentModel.parameters.find((p) => p.id === update.parameterId);
    if (!targetParam) {
      throw new Error(`Parameter "${update.parameterId}" not found in model.`);
    }

    if (targetParam.locked && !update.allowLockedOverride) {
      const err: any = new Error(
        `Cannot modify locked parameter "${targetParam.semanticName || targetParam.name}". Unlock it first to adjust.`
      );
      err.code = 'PARAMETER_LOCKED';
      throw err;
    }

    if (targetParam.featureId) {
      affectedFeatureIdSet.add(targetParam.featureId);
    }

    const { updatedModel, change } = updateParameterValue(currentModel, update.parameterId, update.newValue);
    currentModel = updatedModel;

    // Look up stored codeBindings first
    let boundConstantName: string | undefined = undefined;
    if (currentModel.codeBindings) {
      for (const binding of currentModel.codeBindings) {
        const match = binding.parameterBindings.find((pb) => pb.parameterId === update.parameterId);
        if (match && match.constantName) {
          boundConstantName = match.constantName;
          break;
        }
      }
    }

    const primaryConst = boundConstantName || targetParam.jscadConstantName || targetParam.name || update.parameterId;
    constantUpdates.push({ constantName: primaryConst, newValue: update.newValue });

    if (change) {
      appliedParamChanges.push({
        ...change,
        lockOverride: targetParam.locked ? true : undefined,
      });
    } else {
      appliedParamChanges.push({
        parameterId: update.parameterId,
        featureId: targetParam.featureId || '',
        paramName: targetParam.name || update.parameterId,
        oldValue: targetParam.value ?? 0,
        newValue: update.newValue,
        unit: targetParam.unit || 'mm',
        lockOverride: targetParam.locked ? true : undefined,
      });
    }
  }

  // 2. Batch apply to JSCAD code
  let updateRes = updateJscadConstants(currentVer.cadCode, constantUpdates);

  // Fallback for legacy reconstructed models if some constants weren't matched directly
  if (updateRes.modifiedCount < constantUpdates.length && isLegacy) {
    for (const update of updates) {
      const targetParam = model.parameters.find((p) => p.id === update.parameterId);
      if (!targetParam) continue;

      const candidateNames = [
        targetParam.name,
        targetParam.jscadConstantName,
        update.parameterId,
        targetParam.semanticName ? targetParam.semanticName.replace(/\s+/g, '') : '',
        targetParam.semanticName
          ? targetParam.semanticName.charAt(0).toLowerCase() + targetParam.semanticName.slice(1).replace(/\s+/g, '')
          : '',
      ].filter(Boolean) as string[];

      for (const cand of candidateNames) {
        const fallbackRes = updateJscadConstants(updateRes.updatedCode, [
          { constantName: cand, newValue: update.newValue },
        ]);
        if (fallbackRes.modifiedCount > 0) {
          updateRes = fallbackRes;
          break;
        }
      }
    }
  }

  // Strictly reject no-op updates: code must change
  if (updateRes.modifiedCount === 0 || updateRes.updatedCode === currentVer.cadCode) {
    const err: any = new Error(
      isLegacy
        ? 'Parameter(s) are not bound to executable CAD geometry in this version.'
        : `Parameter(s) are not bound to exact executable CAD constants (${constantUpdates.map((c) => c.constantName).join(', ')}).`
    );
    err.code = 'PARAMETER_NOT_BOUND';
    throw err;
  }

  const updatedCode = updateRes.updatedCode;
  const geom = executeJscadCode(updatedCode);
  const stats = analyzeBufferGeometry(geom, selectedFilamentDensity);
  const bindingMode = isLegacy ? 'legacy' : 'strict';
  const finalModel = finalizeFeatureModelForCode(currentModel, updatedCode, stats, bindingMode);
  const featureVerification = verifySemanticFeatureModel(finalModel, stats, updatedCode);

  const nextVerNum = getNextVersionNumber(project.versions);
  const resolvedOpType: SemanticRevisionOpType =
    operationType ||
    (manipulatorType === 'POSITION'
      ? 'MOVE_FEATURE'
      : manipulatorType === 'DIAMETER' ||
        manipulatorType === 'RADIUS' ||
        manipulatorType === 'WIDTH' ||
        manipulatorType === 'LENGTH' ||
        manipulatorType === 'HEIGHT' ||
        manipulatorType === 'DEPTH' ||
        manipulatorType === 'THICKNESS'
      ? 'RESIZE_FEATURE'
      : 'SET_PARAMETER');

  const defaultSummary =
    updates.length === 1
      ? `Adjusted parameter ${model.parameters.find((p) => p.id === updates[0].parameterId)?.semanticName || updates[0].parameterId} to ${updates[0].newValue}`
      : `Updated ${updates.length} parameters via direct 3D manipulation`;
  const changeSummary = customSummary || defaultSummary;

  const now = new Date().toISOString();
  const thumbnail = generateCadThumbnail(geom);

  const semanticOp = {
    operation: resolvedOpType,
    featureIds: Array.from(affectedFeatureIdSet),
    parameterChanges: appliedParamChanges,
    reason: changeSummary,
    confidence: 1.0,
  };

  const newVersion = buildModelVersion({
    projectId: project.id,
    versionNumber: nextVerNum,
    parentVersionId: currentVer.id,
    label: createVersionLabel(nextVerNum, changeSummary, 'REVISION'),
    createdAt: now,
    prompt: changeSummary,
    userInstruction: changeSummary,
    cadCode: updatedCode,
    geometryMetadata: stats,
    changeSummary,
    changeType: 'REVISION',
    isCurrentHead: true,
    designSpecification: currentVer.designSpecification,
    designChecklist: currentVer.designChecklist,
    featureModel: finalModel,
    thumbnail: thumbnail || undefined,
    semanticRevisionOperation: semanticOp,
    generationDiagnostics: buildGenerationDiagnostics({
      generationId: `gen_param_${Date.now()}`,
      timestamp: Date.now(),
      mode: 'fast',
      repairAttempts: 0,
      status: 'success',
      measuredDimensions: stats.dimensions,
      measuredVolumeMm3: stats.volumeMm3,
      triangleCount: stats.triangleCount,
      vertexCount: stats.triangleCount * 3,
      isManifold: stats.isManifold,
      semanticFeatureCount: finalModel.features.length,
      verifiedFeatureCount: featureVerification.verifiedCount,
      failedFeatureCount: featureVerification.failedCount,
      unknownFeatureCount: featureVerification.unknownCount,
      boundFeatureCount: finalModel.bindingValidation?.boundFeatures.length,
      builderBoundFeatureCount: finalModel.bindingValidation?.builderBoundFeatures.length,
      criticalUnboundParameterCount: finalModel.bindingValidation?.criticalUnboundParameters.length,
      missingBuilderFeatureCount: finalModel.bindingValidation?.missingBuilderFeatures.length,
      parameterEditCount: updates.length,
    }),
  });

  const updatedVersions: ModelVersion[] = project.versions.map((v) => ({ ...v, isCurrentHead: false }));
  updatedVersions.push(newVersion);

  const assistantMsg: DesignConversationMessage = {
    id: `msg_${Date.now()}`,
    projectId: project.id,
    role: 'katprint',
    content: `Updated model: **${changeSummary}**\n\n- New Dimensions: ${stats.dimensions.x.toFixed(1)} × ${stats.dimensions.y.toFixed(1)} × ${stats.dimensions.z.toFixed(1)} mm\n- Verified Features: ${featureVerification.verifiedCount}/${finalModel.features.length}`,
    timestamp: now,
    relatedVersionId: newVersion.id,
    actionType: 'revise',
  };

  const updatedProject: KatPrintProject = {
    ...project,
    currentVersionId: newVersion.id,
    versions: updatedVersions,
    conversation: [...project.conversation, assistantMsg],
    projectMemory: updateProjectMemoryFromVersion(project.projectMemory, newVersion, changeSummary),
    thumbnail: thumbnail || project.thumbnail,
    updatedAt: now,
  };

  return {
    updatedProject,
    newVersion,
    isUndo: false,
    changeSummary,
  };
}

/**
 * Directly updates a single feature parameter in the active project and creates a new ModelVersion.
 */
export async function applyDirectParameterUpdateToProject(params: {
  project: KatPrintProject;
  parameterId: string;
  newValue: number | string | boolean;
  selectedFilamentDensity?: number;
  allowLockedOverride?: boolean;
}): Promise<ApplyRevisionOutcome> {
  const { project, parameterId, newValue, selectedFilamentDensity = 1.24, allowLockedOverride = false } = params;

  return applyBoundParameterChangesToProject({
    project,
    updates: [{ parameterId, newValue, allowLockedOverride }],
    selectedFilamentDensity,
  });
}

