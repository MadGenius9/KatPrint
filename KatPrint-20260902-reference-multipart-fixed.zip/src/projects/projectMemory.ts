import { ProjectMemory, DesignSpecification, ModelVersion } from './projectTypes';

export function initializeProjectMemory(prompt: string, spec?: DesignSpecification): ProjectMemory {
  let width: number | undefined;
  let depth: number | undefined;
  let height: number | undefined;

  if (spec) {
    const explicit = Array.isArray(spec.explicitDimensions) ? spec.explicitDimensions : [];
    const critical = Array.isArray(spec.criticalDimensions) ? spec.criticalDimensions : [];
    const inferred = Array.isArray(spec.inferredDimensions) ? spec.inferredDimensions : [];
    const allDims = [...explicit, ...critical, ...inferred];
    for (const d of allDims) {
      if (!d) continue;
      const name = (typeof d === 'string' ? d : d.name || '').toLowerCase();
      const val = typeof d === 'object' && d !== null ? d.value : undefined;
      const axis = typeof d === 'object' && d !== null ? d.axis : undefined;
      if (typeof val === 'number') {
        if (axis === 'x' || name.includes('width') || name.includes('length')) width = val;
        if (axis === 'y' || name.includes('depth')) depth = val;
        if (axis === 'z' || name.includes('height')) height = val;
      }
    }
  }

  const memory: ProjectMemory = {
    objectPurpose: spec?.primaryObject || inferObjectPurposeFromPrompt(prompt),
    currentDimensions: width || depth || height ? { width, depth, height } : undefined,
    currentFeatures: spec?.requiredFeatures ? spec.requiredFeatures.map((f) => f.name) : [],
    compatibilityTargets: spec?.compatibilityTargets
      ? spec.compatibilityTargets.map((c) => (typeof c === 'string' ? c : c.name))
      : [],
    mountingInterfaces: spec?.mountingRequirements || [],
    importantDecisions: [],
    userRejectedOptions: [],
    unresolvedRequirements: [],
  };

  extractInitialDecisionsFromPrompt(prompt, memory);
  return memory;
}

export function updateProjectMemoryFromVersion(
  currentMemory: ProjectMemory = {},
  version: ModelVersion,
  userInstruction?: string
): ProjectMemory {
  const updated: ProjectMemory = { ...currentMemory };

  const spec = version.designSpecification;
  if (spec) {
    if (spec.primaryObject) updated.objectPurpose = spec.primaryObject;
    const explicit = Array.isArray(spec.explicitDimensions) ? spec.explicitDimensions : [];
    const critical = Array.isArray(spec.criticalDimensions) ? spec.criticalDimensions : [];
    const inferred = Array.isArray(spec.inferredDimensions) ? spec.inferredDimensions : [];
    const allDims = [...explicit, ...critical, ...inferred];
    let width = updated.currentDimensions?.width;
    let depth = updated.currentDimensions?.depth;
    let height = updated.currentDimensions?.height;

    for (const d of allDims) {
      if (!d) continue;
      const name = (typeof d === 'string' ? d : d.name || '').toLowerCase();
      const val = typeof d === 'object' && d !== null ? d.value : undefined;
      const axis = typeof d === 'object' && d !== null ? d.axis : undefined;
      if (typeof val === 'number') {
        if (axis === 'x' || name.includes('width') || name.includes('length')) width = val;
        if (axis === 'y' || name.includes('depth')) depth = val;
        if (axis === 'z' || name.includes('height')) height = val;
      }
    }

    if (width || depth || height) {
      updated.currentDimensions = { width, depth, height };
    }

    if (spec.requiredFeatures) {
      updated.currentFeatures = spec.requiredFeatures.map((f) => f.name);
    }
    if (spec.compatibilityTargets) {
      const targets = spec.compatibilityTargets.map((c) => (typeof c === 'string' ? c : c.name));
      updated.compatibilityTargets = Array.from(new Set([...(updated.compatibilityTargets || []), ...targets]));
    }
  }

  if (userInstruction) {
    extractUserConstraintsAndRejections(userInstruction, updated);
  }

  return updated;
}

export function extractUserConstraintsAndRejections(instruction: string, memory: ProjectMemory): void {
  const lower = instruction.toLowerCase();

  // Detect negative constraints (rejected options)
  const negativePatterns = [
    { pattern: /(?:don't|do not|no|never|without)\s+(?:use\s+)?(?:adhesive|tape|stickers?|glue)/i, item: 'No adhesive mounting (use screws/mechanical fasteners only)' },
    { pattern: /(?:don't|do not|no|never|without)\s+(?:supports?|overhangs?)/i, item: 'Strictly support-free 3D printing design' },
    { pattern: /(?:don't|do not|no|never)\s+(?:change|move|alter)\s+(?:the\s+)?(?:hole|spacing|holes)/i, item: 'Preserve exact mounting hole spacing' },
    { pattern: /(?:don't|do not|no|never|without)\s+(?:a\s+)?(?:lid|cover|top)/i, item: 'Open top design (no lid)' },
    { pattern: /(?:don't|do not|no|never|without)\s+(?:a\s+)?(?:bottom|floor)/i, item: 'Open bottom/pass-through design' },
    { pattern: /(?:keep|make)\s+(?:the\s+)?front\s+open/i, item: 'Keep front face unobstructed' },
    { pattern: /(?:don't|do not|no)\s+(?:sharp|square)\s+corners/i, item: 'All external corners must be filleted/rounded' },
  ];

  if (!memory.userRejectedOptions) memory.userRejectedOptions = [];
  if (!memory.importantDecisions) memory.importantDecisions = [];

  for (const { pattern, item } of negativePatterns) {
    if (pattern.test(lower) && !memory.userRejectedOptions.includes(item)) {
      memory.userRejectedOptions.push(item);
    }
  }

  // Detect positive permanent decisions
  if (lower.includes('countersunk') || lower.includes('countersink')) {
    if (!memory.importantDecisions.includes('Fastener holes must be countersunk')) {
      memory.importantDecisions.push('Fastener holes must be countersunk');
    }
  }
  if (lower.includes('waterproof') || lower.includes('hold liquid') || lower.includes('watertight')) {
    if (!memory.importantDecisions.includes('Solid watertight enclosure without bottom drainage')) {
      memory.importantDecisions.push('Solid watertight enclosure without bottom drainage');
    }
  }
  if (lower.includes('snap fit') || lower.includes('snap-fit')) {
    if (!memory.importantDecisions.includes('Snap-fit mechanical retention clips')) {
      memory.importantDecisions.push('Snap-fit mechanical retention clips');
    }
  }
}

function extractInitialDecisionsFromPrompt(prompt: string, memory: ProjectMemory): void {
  extractUserConstraintsAndRejections(prompt, memory);
}

function inferObjectPurposeFromPrompt(prompt: string): string {
  const p = prompt.trim();
  if (p.length < 50) return p;
  const words = p.split(/\s+/).slice(0, 8).join(' ');
  return `${words}...`;
}
