import { KatPrintProject, ModelVersion } from './projectTypes';
import { normalizeModelVersion } from './projectService';

export interface KatPrintPackage {
  app: 'KatPrint CAD';
  format: 'katprint-project-package';
  schemaVersion: '2.0';
  exportedAt: string;
  checksum?: string;
  project: KatPrintProject;
}

export function serializeProject(project: KatPrintProject): string {
  const pkg: KatPrintPackage = {
    app: 'KatPrint CAD',
    format: 'katprint-project-package',
    schemaVersion: '2.0',
    exportedAt: new Date().toISOString(),
    project,
  };
  return JSON.stringify(pkg, null, 2);
}

export function validateProjectPackage(parsed: any): KatPrintPackage {
  if (!parsed || typeof parsed !== 'object') {
    throw new Error('Invalid project package: Root must be an object.');
  }

  if (parsed.format !== 'katprint-project-package') {
    // Check if it's direct legacy project JSON
    if (parsed.id && Array.isArray(parsed.versions) && parsed.name) {
      return {
        app: 'KatPrint CAD',
        format: 'katprint-project-package',
        schemaVersion: '2.0',
        exportedAt: new Date().toISOString(),
        project: parsed as KatPrintProject,
      };
    }
    throw new Error('Invalid project package: Unrecognized format descriptor.');
  }

  if (parsed.schemaVersion !== '2.0' && parsed.schemaVersion !== '1.0') {
    throw new Error(`Unsupported package schema version: ${parsed.schemaVersion}`);
  }

  const proj = parsed.project;
  if (!proj || typeof proj !== 'object') {
    throw new Error('Invalid project package: Missing project data payload.');
  }

  if (typeof proj.name !== 'string' || !proj.name.trim()) {
    throw new Error('Invalid project package: Project is missing a valid name.');
  }

  if (!Array.isArray(proj.versions)) {
    throw new Error('Invalid project package: Missing or invalid versions list.');
  }

  return parsed as KatPrintPackage;
}

export function deserializeProject(jsonStr: string, existingProjectIds: string[] = []): KatPrintProject {
  let parsed: any;
  try {
    parsed = JSON.parse(jsonStr);
  } catch {
    throw new Error('Failed to parse project file: Invalid JSON syntax.');
  }

  const validatedPkg = validateProjectPackage(parsed);
  return normalizeImportedProject(validatedPkg.project, existingProjectIds);
}

export function normalizeImportedProject(
  proj: Partial<KatPrintProject>,
  existingProjectIds: string[] = []
): KatPrintProject {
  const now = new Date().toISOString();
  const needsNewId = !proj.id || existingProjectIds.includes(proj.id);
  const targetProjectId = needsNewId
    ? `proj_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`
    : proj.id!;

  // Remap version IDs if new project ID is assigned to ensure collision safety
  const versionIdMap = new Map<string, string>();
  const rawVersions = proj.versions || [];

  if (needsNewId) {
    rawVersions.forEach((v) => {
      if (v.id) {
        versionIdMap.set(v.id, `ver_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
      }
    });
  }

  const normalizedVersions: ModelVersion[] = rawVersions.map((v) => {
    const norm = normalizeModelVersion(v);
    const newVerId = needsNewId && v.id ? versionIdMap.get(v.id) || norm.id : norm.id;
    const remappedParent = needsNewId && v.parentVersionId ? versionIdMap.get(v.parentVersionId) || null : norm.parentVersionId;
    const remappedSource = needsNewId && v.sourceVersionId ? versionIdMap.get(v.sourceVersionId) || undefined : norm.sourceVersionId;

    return {
      ...norm,
      id: newVerId,
      projectId: targetProjectId,
      parentVersionId: remappedParent,
      sourceVersionId: remappedSource,
    };
  });

  let currentVersionId = proj.currentVersionId || null;
  if (needsNewId && currentVersionId && versionIdMap.has(currentVersionId)) {
    currentVersionId = versionIdMap.get(currentVersionId)!;
  } else if (!currentVersionId && normalizedVersions.length > 0) {
    currentVersionId = normalizedVersions[normalizedVersions.length - 1].id;
  }

  return {
    id: targetProjectId,
    name: proj.name || 'Imported Project',
    originalPrompt: proj.originalPrompt || '',
    createdAt: proj.createdAt || now,
    updatedAt: now,
    currentVersionId,
    versions: normalizedVersions,
    conversation: (proj.conversation || []).map((m) => ({
      ...m,
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      projectId: targetProjectId,
      versionId: needsNewId && m.versionId ? versionIdMap.get(m.versionId) || undefined : m.versionId,
      relatedVersionId: needsNewId && m.relatedVersionId ? versionIdMap.get(m.relatedVersionId) || undefined : m.relatedVersionId,
    })),
    projectSettings: proj.projectSettings ? {
      printerId: proj.projectSettings.printerId || 'bambu-x1c',
      filamentId: proj.projectSettings.filamentId || 'pla',
      generationMode: proj.projectSettings.generationMode || 'precision',
      autoApplyProposedChanges: !!proj.projectSettings.autoApplyProposedChanges,
      enableThinking: proj.projectSettings.enableThinking !== false,
      scaleFactor: proj.projectSettings.scaleFactor || 1.0,
      mustHoldLiquid: !!proj.projectSettings.mustHoldLiquid,
    } : {
      printerId: 'bambu-x1c',
      filamentId: 'pla',
      generationMode: 'precision',
      autoApplyProposedChanges: false,
      enableThinking: true,
      scaleFactor: 1.0,
      mustHoldLiquid: false,
    },
    referenceObjects: proj.referenceObjects || [],
    referenceImages: proj.referenceImages || [],
    projectMemory: proj.projectMemory,
    tags: proj.tags || [],
    isFavorite: !!proj.isFavorite,
    thumbnail: proj.thumbnail,
  };
}

export function exportProjectPackage(project: KatPrintProject): void {
  const json = serializeProject(project);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  
  const cleanName = (project.name || 'katprint-project')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  
  a.href = url;
  a.download = `${cleanName || 'project'}.katprint`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function importProjectPackage(fileOrJson: File | string, existingProjectIds: string[] = []): Promise<KatPrintProject> {
  if (typeof fileOrJson === 'string') {
    return deserializeProject(fileOrJson, existingProjectIds);
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const project = deserializeProject(text, existingProjectIds);
        resolve(project);
      } catch (err) {
        reject(err instanceof Error ? err : new Error('Failed to parse project file.'));
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file.'));
    reader.readAsText(fileOrJson);
  });
}
