import {
  KatPrintProject,
  ModelVersion,
  DesignConversationMessage,
  StorageUsageStats,
} from './projectTypes';
import { defaultProjectRepository } from '../storage/indexedDbRepository';

export interface IProjectRepository {
  listProjects(): Promise<KatPrintProject[]>;
  getProject(id: string): Promise<KatPrintProject | null>;
  createProject(project: KatPrintProject): Promise<KatPrintProject>;
  updateProject(project: KatPrintProject): Promise<KatPrintProject>;
  saveProject(project: KatPrintProject): Promise<KatPrintProject>;
  deleteProject(id: string): Promise<void>;
  duplicateProject(id: string, newName?: string): Promise<KatPrintProject>;
  saveVersion(projectId: string, version: ModelVersion): Promise<void>;
  saveConversationMessage(projectId: string, message: DesignConversationMessage): Promise<void>;
  getStorageUsage(): Promise<StorageUsageStats>;
  deleteOldInspectionImages(): Promise<number>;
  clearAllData(): Promise<void>;
  exportProjectFile(projectId: string): Promise<Blob>;
  importProjectFile(jsonContent: string): Promise<KatPrintProject>;
}

// Current singleton implementation backed by IndexedDB
export const projectRepository: IProjectRepository = defaultProjectRepository;
