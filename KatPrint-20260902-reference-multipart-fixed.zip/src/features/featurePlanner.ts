import {
  SemanticFeatureModel,
  SemanticFeature,
  FeatureParameter,
  FeatureRelationship,
  FeatureConstraint,
} from './featureTypes';
import { createFeatureParameter } from './featureParameters';
import { createFeatureRelationship } from './featureRelationships';
import { createFeatureConstraint } from './featureConstraints';
import { DesignSpecification, DesignCheck } from '../types';

export function planSemanticFeatureModel(
  spec: DesignSpecification,
  prompt: string,
  _checklist?: DesignCheck[]
): SemanticFeatureModel {
  const lowerPrompt = prompt.toLowerCase();
  const lowerObject = (spec.primaryObject || '').toLowerCase();
  const modelId = `sfm_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

  const features: SemanticFeature[] = [];
  const parameters: FeatureParameter[] = [];
  const relationships: FeatureRelationship[] = [];
  const constraints: FeatureConstraint[] = [];

  // Determine Primary Archetype
  const isSoapDish =
    lowerPrompt.includes('soap') ||
    lowerObject.includes('soap') ||
    lowerPrompt.includes('dr. squatch') ||
    lowerPrompt.includes('squatch');
  const isControllerMount =
    lowerPrompt.includes('controller') ||
    lowerPrompt.includes('xbox') ||
    lowerPrompt.includes('playstation') ||
    lowerPrompt.includes('gamepad');
  const isPhoneStand =
    lowerPrompt.includes('phone') ||
    lowerPrompt.includes('smartphone') ||
    lowerPrompt.includes('tablet stand') ||
    lowerPrompt.includes('desk stand');
  const isWallPlate =
    lowerPrompt.includes('wall plate') ||
    lowerPrompt.includes('faceplate') ||
    lowerPrompt.includes('mounting plate') ||
    lowerPrompt.includes('switch plate');

  // Base dimensions extracted or inferred
  const explicitDims = Array.isArray(spec?.explicitDimensions) ? spec.explicitDimensions : [];
  const inferredDims = Array.isArray(spec?.inferredDimensions) ? spec.inferredDimensions : [];

  const widthDim =
    explicitDims.find((d) => d.axis === 'x' || (d.name && d.name.toLowerCase().includes('width')))?.value ||
    inferredDims.find((d) => d.axis === 'x' || (d.name && d.name.toLowerCase().includes('width')))?.value ||
    (isSoapDish ? 120 : isControllerMount ? 140 : isPhoneStand ? 85 : isWallPlate ? 115 : 100);

  const depthDim =
    explicitDims.find((d) => d.axis === 'y' || (d.name && (d.name.toLowerCase().includes('depth') || d.name.toLowerCase().includes('length'))))?.value ||
    inferredDims.find((d) => d.axis === 'y' || (d.name && (d.name.toLowerCase().includes('depth') || d.name.toLowerCase().includes('length'))))?.value ||
    (isSoapDish ? 85 : isControllerMount ? 90 : isPhoneStand ? 80 : isWallPlate ? 70 : 80);

  const heightDim =
    explicitDims.find((d) => d.axis === 'z' || (d.name && (d.name.toLowerCase().includes('height') || d.name.toLowerCase().includes('thickness'))))?.value ||
    inferredDims.find((d) => d.axis === 'z' || (d.name && (d.name.toLowerCase().includes('height') || d.name.toLowerCase().includes('thickness'))))?.value ||
    (isSoapDish ? 20 : isControllerMount ? 65 : isPhoneStand ? 95 : isWallPlate ? 4 : 25);

  const baseFeatureId = isWallPlate || isControllerMount ? 'mounting_plate' : 'base_body';

  // 1. PRIMARY BASE FEATURE
  if (isWallPlate || isControllerMount) {
    const plateThickness = isWallPlate ? heightDim : 5;
    const feat: SemanticFeature = {
      id: baseFeatureId,
      type: 'PLATE',
      label: 'Mounting Plate',
      purpose: 'Primary structural base and mounting surface.',
      parameters: {
        width: widthDim,
        depth: depthDim,
        thickness: plateThickness,
      },
      parameterIds: ['plate_width', 'plate_depth', 'plate_thickness'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'base',
      aliases: ['base plate', 'mounting plate', 'flange plate', 'main plate'],
      status: 'planned',
    };
    features.push(feat);

    parameters.push(
      createFeatureParameter({
        id: 'plate_width',
        featureId: feat.id,
        name: 'width',
        semanticName: 'plate_width',
        value: widthDim,
        unit: 'mm',
        source: 'explicit',
        critical: true,
      }),
      createFeatureParameter({
        id: 'plate_depth',
        featureId: feat.id,
        name: 'depth',
        semanticName: 'plate_depth',
        value: depthDim,
        unit: 'mm',
        source: 'explicit',
        critical: true,
      }),
      createFeatureParameter({
        id: 'plate_thickness',
        featureId: feat.id,
        name: 'thickness',
        semanticName: 'plate_thickness',
        value: plateThickness,
        unit: 'mm',
        source: 'inferred',
        min: 2,
        max: 20,
      })
    );
  } else {
    const feat: SemanticFeature = {
      id: baseFeatureId,
      type: 'BASE_BODY',
      label: 'Base Body',
      purpose: 'Foundational solid body of the print.',
      parameters: {
        width: widthDim,
        depth: depthDim,
        height: heightDim,
      },
      parameterIds: ['base_width', 'base_depth', 'base_height'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'base',
      aliases: ['main body', 'base', 'chassis', 'tray'],
      status: 'planned',
    };
    features.push(feat);

    parameters.push(
      createFeatureParameter({
        id: 'base_width',
        featureId: feat.id,
        name: 'width',
        semanticName: 'base_width',
        value: widthDim,
        unit: 'mm',
        source: 'explicit',
        critical: true,
      }),
      createFeatureParameter({
        id: 'base_depth',
        featureId: feat.id,
        name: 'depth',
        semanticName: 'base_depth',
        value: depthDim,
        unit: 'mm',
        source: 'explicit',
        critical: true,
      }),
      createFeatureParameter({
        id: 'base_height',
        featureId: feat.id,
        name: 'height',
        semanticName: 'base_height',
        value: heightDim,
        unit: 'mm',
        source: 'explicit',
        critical: true,
      })
    );
  }

  // 2. ARCHETYPE-SPECIFIC MECHANICAL FEATURES

  // Archetype A: Soap Dish (Dr. Squatch or general)
  if (isSoapDish) {
    const soapBarRef = spec.compatibilityTargets.find((t) => t.name.toLowerCase().includes('soap')) || {
      name: 'Dr. Squatch Soap Bar',
      clearanceMm: 4,
    };

    // Soap Cavity / Resting Tray
    const cavity: SemanticFeature = {
      id: 'soap_cavity',
      type: 'CAVITY',
      label: 'Soap Bar Cavity',
      purpose: 'Internal recessed pocket sized to securely rest a standard soap bar with clearance.',
      parameters: {
        width: 85,
        depth: 85,
        depthRecess: 10,
        clearance: soapBarRef.clearanceMm || 4,
      },
      parameterIds: ['soap_cavity_width', 'soap_cavity_depth', 'soap_cavity_clearance'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'subtract',
      aliases: ['soap pocket', 'recess', 'soap tray cavity'],
      status: 'planned',
    };
    features.push(cavity);
    parameters.push(
      createFeatureParameter({ id: 'soap_cavity_width', featureId: cavity.id, name: 'width', semanticName: 'soap_cavity_width', value: 85, unit: 'mm', source: 'reference', critical: true }),
      createFeatureParameter({ id: 'soap_cavity_depth', featureId: cavity.id, name: 'depth', semanticName: 'soap_cavity_depth', value: 85, unit: 'mm', source: 'reference', critical: true }),
      createFeatureParameter({ id: 'soap_cavity_clearance', featureId: cavity.id, name: 'clearance', semanticName: 'soap_cavity_clearance', value: soapBarRef.clearanceMm || 4, unit: 'mm', source: 'reference' })
    );
    relationships.push(createFeatureRelationship({ sourceFeatureId: cavity.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Cavity cuts into base body' }));

    // Drainage Slot Pattern
    const drainage: SemanticFeature = {
      id: 'drainage_slot_pattern',
      type: 'DRAINAGE_SLOT',
      label: 'Drainage Slot Pattern',
      purpose: 'Series of through-slots allowing water egress so soap stays dry.',
      parameters: {
        slotWidth: 4,
        slotLength: 50,
        count: 5,
        spacing: 12,
      },
      parameterIds: ['drain_slot_width', 'drain_slot_length', 'drain_slot_count', 'drain_slot_spacing'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'subtract',
      aliases: ['drainage slots', 'weep slots', 'water drainage', 'drain holes'],
      status: 'planned',
    };
    features.push(drainage);
    parameters.push(
      createFeatureParameter({ id: 'drain_slot_width', featureId: drainage.id, name: 'slotWidth', semanticName: 'drain_slot_width', value: 4, unit: 'mm', source: 'default' }),
      createFeatureParameter({ id: 'drain_slot_length', featureId: drainage.id, name: 'slotLength', semanticName: 'drain_slot_length', value: 50, unit: 'mm', source: 'default' }),
      createFeatureParameter({ id: 'drain_slot_count', featureId: drainage.id, name: 'count', semanticName: 'drain_slot_count', value: 5, unit: 'count', source: 'default' }),
      createFeatureParameter({ id: 'drain_slot_spacing', featureId: drainage.id, name: 'spacing', semanticName: 'drain_slot_spacing', value: 12, unit: 'mm', source: 'default' })
    );
    relationships.push(createFeatureRelationship({ sourceFeatureId: drainage.id, targetFeatureId: cavity.id, relationshipType: 'subtracts_from', description: 'Slots pass through soap floor' }));

    // Raised Support Ridges
    const ridges: SemanticFeature = {
      id: 'raised_support_ridges',
      type: 'SUPPORT',
      label: 'Raised Soap Support Ridges',
      purpose: 'Elevates the soap bar above the floor for maximum airflow and drainage.',
      parameters: {
        ridgeHeight: 3,
        ridgeThickness: 2.5,
        count: 4,
      },
      parameterIds: ['ridge_height', 'ridge_thickness'],
      source: 'inferred',
      criticality: 'important',
      geometryOperation: 'add',
      aliases: ['support ribs', 'soap ridges', 'drying ribs'],
      status: 'planned',
    };
    features.push(ridges);
    parameters.push(
      createFeatureParameter({ id: 'ridge_height', featureId: ridges.id, name: 'ridgeHeight', semanticName: 'ridge_height', value: 3, unit: 'mm', source: 'inferred' }),
      createFeatureParameter({ id: 'ridge_thickness', featureId: ridges.id, name: 'ridgeThickness', semanticName: 'ridge_thickness', value: 2.5, unit: 'mm', source: 'inferred' })
    );
    relationships.push(createFeatureRelationship({ sourceFeatureId: ridges.id, targetFeatureId: cavity.id, relationshipType: 'attached_to', description: 'Ridges sit on cavity floor' }));

    // Retaining Rim
    const rim: SemanticFeature = {
      id: 'retaining_rim',
      type: 'LIP',
      label: 'Retaining Perimeter Rim',
      purpose: 'Perimeter lip keeping soap bar from sliding off.',
      parameters: {
        rimHeight: 6,
        rimThickness: 3.5,
      },
      parameterIds: ['rim_height', 'rim_thickness'],
      source: 'inferred',
      criticality: 'important',
      geometryOperation: 'add',
      aliases: ['retaining lip', 'soap rim', 'outer lip'],
      status: 'planned',
    };
    features.push(rim);
    parameters.push(
      createFeatureParameter({ id: 'rim_height', featureId: rim.id, name: 'rimHeight', semanticName: 'rim_height', value: 6, unit: 'mm', source: 'inferred' }),
      createFeatureParameter({ id: 'rim_thickness', featureId: rim.id, name: 'rimThickness', semanticName: 'rim_thickness', value: 3.5, unit: 'mm', source: 'inferred' })
    );
  }

  // Archetype B: Controller Mount (Under desk / wall)
  else if (isControllerMount) {
    const isUnderDesk = lowerPrompt.includes('under') || lowerPrompt.includes('desk');

    // Mounting Holes (Left and Right)
    const holeLeft: SemanticFeature = {
      id: 'mounting_hole_left',
      type: 'COUNTERSINK',
      label: 'Mounting Hole Left',
      purpose: 'Countersunk screw hole for secure under-desk or wall fastening.',
      parameters: {
        diameter: 4.5,
        headDiameter: 9.0,
        positionX: -35,
        positionY: 0,
      },
      parameterIds: ['mounting_hole_diameter', 'mounting_hole_left_x'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'subtract',
      aliases: ['left hole', 'left screw hole', 'first mounting hole', 'that left hole'],
      status: 'planned',
    };
    const holeRight: SemanticFeature = {
      id: 'mounting_hole_right',
      type: 'COUNTERSINK',
      label: 'Mounting Hole Right',
      purpose: 'Countersunk screw hole symmetric to left mounting hole.',
      parameters: {
        diameter: 4.5,
        headDiameter: 9.0,
        positionX: 35,
        positionY: 0,
      },
      parameterIds: ['mounting_hole_diameter', 'mounting_hole_right_x'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'subtract',
      aliases: ['right hole', 'right screw hole', 'second mounting hole', 'that right hole'],
      status: 'planned',
    };
    features.push(holeLeft, holeRight);

    parameters.push(
      createFeatureParameter({ id: 'mounting_hole_diameter', featureId: holeLeft.id, name: 'diameter', semanticName: 'mounting_hole_diameter', value: 4.5, unit: 'mm', source: 'explicit', critical: true }),
      createFeatureParameter({ id: 'mounting_hole_left_x', featureId: holeLeft.id, name: 'positionX', semanticName: 'mounting_hole_left_x', value: -35, unit: 'mm', source: 'explicit' }),
      createFeatureParameter({ id: 'mounting_hole_right_x', featureId: holeRight.id, name: 'positionX', semanticName: 'mounting_hole_right_x', value: 35, unit: 'mm', source: 'explicit' }),
      createFeatureParameter({ id: 'mounting_hole_spacing', featureId: baseFeatureId, name: 'spacing', semanticName: 'mounting_hole_spacing', value: 70, unit: 'mm', source: 'explicit', critical: true })
    );

    relationships.push(
      createFeatureRelationship({ sourceFeatureId: holeLeft.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Left hole passes through plate' }),
      createFeatureRelationship({ sourceFeatureId: holeRight.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Right hole passes through plate' }),
      createFeatureRelationship({ sourceFeatureId: holeRight.id, targetFeatureId: holeLeft.id, relationshipType: 'mirrored_from', description: 'Right hole mirrored across X=0' })
    );

    constraints.push(
      createFeatureConstraint({
        name: 'Mounting Hole Spacing',
        description: 'Center-to-center spacing between left and right mounting holes',
        constraintType: 'distance',
        affectedFeatureIds: [holeLeft.id, holeRight.id],
        value: 70,
        tolerance: 1.0,
      })
    );

    // Controller Cradle Arms
    const cradleLeft: SemanticFeature = {
      id: 'controller_cradle_left',
      type: 'CRADLE',
      label: 'Controller Cradle Arm Left',
      purpose: 'Contoured resting arm cradling the left controller grip.',
      parameters: {
        width: 30,
        dropHeight: 45,
        thickness: 5,
      },
      parameterIds: ['cradle_arm_thickness', 'cradle_drop_height'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'add',
      aliases: ['left cradle', 'left arm', 'left grip holder'],
      status: 'planned',
    };
    const cradleRight: SemanticFeature = {
      id: 'controller_cradle_right',
      type: 'CRADLE',
      label: 'Controller Cradle Arm Right',
      purpose: 'Contoured resting arm cradling the right controller grip.',
      parameters: {
        width: 30,
        dropHeight: 45,
        thickness: 5,
      },
      parameterIds: ['cradle_arm_thickness', 'cradle_drop_height'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'add',
      aliases: ['right cradle', 'right arm', 'right grip holder'],
      status: 'planned',
    };
    features.push(cradleLeft, cradleRight);

    parameters.push(
      createFeatureParameter({ id: 'cradle_arm_thickness', featureId: cradleLeft.id, name: 'thickness', semanticName: 'cradle_arm_thickness', value: 5, unit: 'mm', source: 'inferred' }),
      createFeatureParameter({ id: 'cradle_drop_height', featureId: cradleLeft.id, name: 'dropHeight', semanticName: 'cradle_drop_height', value: 45, unit: 'mm', source: 'inferred' })
    );

    relationships.push(
      createFeatureRelationship({ sourceFeatureId: cradleLeft.id, targetFeatureId: baseFeatureId, relationshipType: isUnderDesk ? 'below' : 'attached_to', description: 'Cradle hangs from mounting plate' }),
      createFeatureRelationship({ sourceFeatureId: cradleRight.id, targetFeatureId: baseFeatureId, relationshipType: isUnderDesk ? 'below' : 'attached_to', description: 'Cradle hangs from mounting plate' }),
      createFeatureRelationship({ sourceFeatureId: cradleRight.id, targetFeatureId: cradleLeft.id, relationshipType: 'mirrored_from', description: 'Symmetric cradle arms' })
    );

    // Reinforcing Support Ribs
    const ribLeft: SemanticFeature = {
      id: 'support_rib_left',
      type: 'RIB',
      label: 'Support Rib Left',
      purpose: 'Reinforces the left cradle arm against flex and load bending.',
      parameters: {
        thickness: 3.5,
        height: 25,
      },
      parameterIds: ['support_rib_thickness'],
      source: 'inferred',
      criticality: 'important',
      geometryOperation: 'add',
      aliases: ['left rib', 'left support gusset', 'left brace'],
      status: 'planned',
    };
    const ribRight: SemanticFeature = {
      id: 'support_rib_right',
      type: 'RIB',
      label: 'Support Rib Right',
      purpose: 'Reinforces the right cradle arm against flex and load bending.',
      parameters: {
        thickness: 3.5,
        height: 25,
      },
      parameterIds: ['support_rib_thickness'],
      source: 'inferred',
      criticality: 'important',
      geometryOperation: 'add',
      aliases: ['right rib', 'right support gusset', 'right brace'],
      status: 'planned',
    };
    features.push(ribLeft, ribRight);
    parameters.push(
      createFeatureParameter({ id: 'support_rib_thickness', featureId: ribLeft.id, name: 'thickness', semanticName: 'support_rib_thickness', value: 3.5, unit: 'mm', source: 'inferred' })
    );
    relationships.push(
      createFeatureRelationship({ sourceFeatureId: ribLeft.id, targetFeatureId: cradleLeft.id, relationshipType: 'reinforces', description: 'Rib reinforces left cradle' }),
      createFeatureRelationship({ sourceFeatureId: ribRight.id, targetFeatureId: cradleRight.id, relationshipType: 'reinforces', description: 'Rib reinforces right cradle' })
    );
  }

  // Archetype C: Phone Stand
  else if (isPhoneStand) {
    // Back Support Wall / Rest
    const backSupport: SemanticFeature = {
      id: 'back_support',
      type: 'WALL',
      label: 'Back Support Angle',
      purpose: 'Inclined back plane supporting phone or tablet at comfortable viewing angle.',
      parameters: {
        angleDeg: 70,
        height: 85,
        thickness: 3.5,
      },
      parameterIds: ['stand_angle_deg', 'back_support_height', 'wall_thickness'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'add',
      aliases: ['back rest', 'support wall', 'inclined support', 'phone back'],
      status: 'planned',
    };
    features.push(backSupport);
    parameters.push(
      createFeatureParameter({ id: 'stand_angle_deg', featureId: backSupport.id, name: 'angleDeg', semanticName: 'stand_angle_deg', value: 70, unit: 'deg', source: 'inferred' }),
      createFeatureParameter({ id: 'back_support_height', featureId: backSupport.id, name: 'height', semanticName: 'back_support_height', value: 85, unit: 'mm', source: 'inferred' }),
      createFeatureParameter({ id: 'wall_thickness', featureId: backSupport.id, name: 'thickness', semanticName: 'wall_thickness', value: 3.5, unit: 'mm', source: 'inferred', min: 2.0 })
    );
    relationships.push(createFeatureRelationship({ sourceFeatureId: backSupport.id, targetFeatureId: baseFeatureId, relationshipType: 'attached_to', description: 'Back support rises from base' }));

    // Retaining Lip
    const retainingLip: SemanticFeature = {
      id: 'retaining_lip',
      type: 'LIP',
      label: 'Retaining Lip',
      purpose: 'Forward hooked shelf preventing device from sliding off the stand.',
      parameters: {
        lipHeight: 14,
        shelfDepth: 16,
        thickness: 3.5,
      },
      parameterIds: ['retaining_lip_height', 'shelf_depth'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'add',
      aliases: ['phone shelf', 'front lip', 'holder lip', 'retaining hook'],
      status: 'planned',
    };
    features.push(retainingLip);
    parameters.push(
      createFeatureParameter({ id: 'retaining_lip_height', featureId: retainingLip.id, name: 'lipHeight', semanticName: 'retaining_lip_height', value: 14, unit: 'mm', source: 'inferred' }),
      createFeatureParameter({ id: 'shelf_depth', featureId: retainingLip.id, name: 'shelfDepth', semanticName: 'shelf_depth', value: 16, unit: 'mm', source: 'inferred' })
    );
    relationships.push(createFeatureRelationship({ sourceFeatureId: retainingLip.id, targetFeatureId: baseFeatureId, relationshipType: 'attached_to', description: 'Shelf is attached to base' }));

    // Cable Pass-Through Opening
    const cableSlot: SemanticFeature = {
      id: 'charging_cable_slot',
      type: 'CABLE_OPENING',
      label: 'Charging Cable Opening',
      purpose: 'Pass-through opening allowing Lightning/USB-C charging cables to connect while docked.',
      parameters: {
        slotWidth: 16,
        slotDepth: 12,
      },
      parameterIds: ['cable_slot_width', 'cable_slot_depth'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'subtract',
      aliases: ['cable opening', 'charger opening', 'bottom slot', 'charging slot', 'cable slot'],
      status: 'planned',
    };
    features.push(cableSlot);
    parameters.push(
      createFeatureParameter({ id: 'cable_slot_width', featureId: cableSlot.id, name: 'slotWidth', semanticName: 'cable_slot_width', value: 16, unit: 'mm', source: 'explicit', critical: true }),
      createFeatureParameter({ id: 'cable_slot_depth', featureId: cableSlot.id, name: 'slotDepth', semanticName: 'cable_slot_depth', value: 12, unit: 'mm', source: 'inferred' })
    );
    relationships.push(createFeatureRelationship({ sourceFeatureId: cableSlot.id, targetFeatureId: retainingLip.id, relationshipType: 'subtracts_from', description: 'Cable slot cuts through shelf and base' }));
  }

  // Archetype D: Wall Plate / Faceplate / Holes & Cutouts
  else if (isWallPlate || lowerPrompt.includes('hole') || lowerPrompt.includes('screw') || lowerPrompt.includes('slot')) {
    // Parse hole quantity explicitly
    let holeCount = 0;
    if (lowerPrompt.includes('one hole') || lowerPrompt.includes('1 hole') || lowerPrompt.includes('single hole') || lowerPrompt.includes('through hole in the center') || lowerPrompt.includes('center hole') || lowerPrompt.includes('one 8 mm hole')) {
      holeCount = 1;
    } else if (lowerPrompt.includes('two hole') || lowerPrompt.includes('2 hole') || lowerPrompt.includes('two screw') || lowerPrompt.includes('2 screw')) {
      holeCount = 2;
    } else if (lowerPrompt.includes('three hole') || lowerPrompt.includes('3 hole')) {
      holeCount = 3;
    } else if (lowerPrompt.includes('four hole') || lowerPrompt.includes('4 hole') || lowerPrompt.includes('four screw') || lowerPrompt.includes('4 screw') || isWallPlate) {
      holeCount = 4;
    } else if (lowerPrompt.includes('six hole') || lowerPrompt.includes('6 hole')) {
      holeCount = 6;
    } else if (lowerPrompt.includes('hole') || lowerPrompt.includes('screw')) {
      holeCount = 1; // Default to 1 hole if unspecified, NOT 4
    }

    const holeDiameter = spec.explicitDimensions.find((d) => d.name.toLowerCase().includes('hole'))?.value || 5.0;

    if (holeCount === 1) {
      const isCenter = lowerPrompt.includes('center') || !lowerPrompt.includes('offset');
      const hole: SemanticFeature = {
        id: 'center_hole',
        type: 'HOLE',
        label: 'Center Through Hole',
        purpose: 'Center cylindrical through hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: 0, posY: 0 },
        parameterIds: ['hole_diameter', 'hole_pos_x', 'hole_pos_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['center hole', 'through hole', 'hole 1'],
        status: 'planned',
      };
      features.push(hole);
      parameters.push(
        createFeatureParameter({ id: 'hole_diameter', featureId: hole.id, name: 'diameter', semanticName: 'hole_diameter', value: holeDiameter, unit: 'mm', source: 'explicit', critical: true }),
        createFeatureParameter({ id: 'hole_pos_x', featureId: hole.id, name: 'posX', semanticName: 'hole_pos_x', value: 0, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'hole_pos_y', featureId: hole.id, name: 'posY', semanticName: 'hole_pos_y', value: 0, unit: 'mm', source: 'explicit' })
      );
      relationships.push(createFeatureRelationship({ sourceFeatureId: hole.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Hole cuts through base body' }));
    } else if (holeCount === 2) {
      const spacing = Math.max(20, widthDim - 30);
      const hole1: SemanticFeature = {
        id: 'mounting_hole_left',
        type: 'HOLE',
        label: 'Mounting Hole Left',
        purpose: 'Left mounting through hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: -spacing / 2, posY: 0 },
        parameterIds: ['mounting_hole_diameter', 'mounting_hole_left_x', 'mounting_hole_left_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['left hole', 'hole 1'],
        status: 'planned',
      };
      const hole2: SemanticFeature = {
        id: 'mounting_hole_right',
        type: 'HOLE',
        label: 'Mounting Hole Right',
        purpose: 'Right mounting through hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: spacing / 2, posY: 0 },
        parameterIds: ['mounting_hole_diameter', 'mounting_hole_right_x', 'mounting_hole_right_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['right hole', 'hole 2'],
        status: 'planned',
      };
      features.push(hole1, hole2);
      parameters.push(
        createFeatureParameter({ id: 'mounting_hole_diameter', featureId: hole1.id, name: 'diameter', semanticName: 'mounting_hole_diameter', value: holeDiameter, unit: 'mm', source: 'explicit', critical: true }),
        createFeatureParameter({ id: 'mounting_hole_left_x', featureId: hole1.id, name: 'posX', semanticName: 'mounting_hole_left_x', value: -spacing / 2, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_left_y', featureId: hole1.id, name: 'posY', semanticName: 'mounting_hole_left_y', value: 0, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_right_x', featureId: hole2.id, name: 'posX', semanticName: 'mounting_hole_right_x', value: spacing / 2, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_right_y', featureId: hole2.id, name: 'posY', semanticName: 'mounting_hole_right_y', value: 0, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_spacing', featureId: baseFeatureId, name: 'spacing', semanticName: 'mounting_hole_spacing', value: spacing, unit: 'mm', source: 'explicit', critical: true })
      );
      relationships.push(
        createFeatureRelationship({ sourceFeatureId: hole1.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Hole cuts through base body' }),
        createFeatureRelationship({ sourceFeatureId: hole2.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Hole cuts through base body' })
      );
    } else if (holeCount === 4) {
      const offsetX = Math.max(8, widthDim / 2 - 12);
      const offsetY = Math.max(8, depthDim / 2 - 12);
      const isCountersink = lowerPrompt.includes('countersink') || lowerPrompt.includes('countersunk');
      const holeType = isCountersink ? 'COUNTERSINK' : 'HOLE';

      const hole1: SemanticFeature = {
        id: 'mounting_hole_top_left',
        type: holeType,
        label: 'Mounting Hole Top-Left',
        purpose: 'Corner fastener hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: -offsetX, posY: offsetY },
        parameterIds: ['mounting_hole_diameter', 'mounting_hole_tl_x', 'mounting_hole_tl_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['top left hole', 'hole 1'],
        status: 'planned',
      };
      const hole2: SemanticFeature = {
        id: 'mounting_hole_top_right',
        type: holeType,
        label: 'Mounting Hole Top-Right',
        purpose: 'Corner fastener hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: offsetX, posY: offsetY },
        parameterIds: ['mounting_hole_diameter', 'mounting_hole_tr_x', 'mounting_hole_tr_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['top right hole', 'hole 2'],
        status: 'planned',
      };
      const hole3: SemanticFeature = {
        id: 'mounting_hole_bottom_left',
        type: holeType,
        label: 'Mounting Hole Bottom-Left',
        purpose: 'Corner fastener hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: -offsetX, posY: -offsetY },
        parameterIds: ['mounting_hole_diameter', 'mounting_hole_bl_x', 'mounting_hole_bl_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['bottom left hole', 'hole 3'],
        status: 'planned',
      };
      const hole4: SemanticFeature = {
        id: 'mounting_hole_bottom_right',
        type: holeType,
        label: 'Mounting Hole Bottom-Right',
        purpose: 'Corner fastener hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: offsetX, posY: -offsetY },
        parameterIds: ['mounting_hole_diameter', 'mounting_hole_br_x', 'mounting_hole_br_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['bottom right hole', 'hole 4'],
        status: 'planned',
      };

      features.push(hole1, hole2, hole3, hole4);
      parameters.push(
        createFeatureParameter({ id: 'mounting_hole_diameter', featureId: hole1.id, name: 'diameter', semanticName: 'mounting_hole_diameter', value: holeDiameter, unit: 'mm', source: 'explicit', critical: true }),
        createFeatureParameter({ id: 'mounting_hole_tl_x', featureId: hole1.id, name: 'posX', semanticName: 'mounting_hole_tl_x', value: -offsetX, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_tl_y', featureId: hole1.id, name: 'posY', semanticName: 'mounting_hole_tl_y', value: offsetY, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_tr_x', featureId: hole2.id, name: 'posX', semanticName: 'mounting_hole_tr_x', value: offsetX, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_tr_y', featureId: hole2.id, name: 'posY', semanticName: 'mounting_hole_tr_y', value: offsetY, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_bl_x', featureId: hole3.id, name: 'posX', semanticName: 'mounting_hole_bl_x', value: -offsetX, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_bl_y', featureId: hole3.id, name: 'posY', semanticName: 'mounting_hole_bl_y', value: -offsetY, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_br_x', featureId: hole4.id, name: 'posX', semanticName: 'mounting_hole_br_x', value: offsetX, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_br_y', featureId: hole4.id, name: 'posY', semanticName: 'mounting_hole_br_y', value: -offsetY, unit: 'mm', source: 'explicit' })
      );

      [hole1, hole2, hole3, hole4].forEach((h) => {
        relationships.push(createFeatureRelationship({ sourceFeatureId: h.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Hole cuts through plate' }));
      });
    }
  }

  // 3. Ergonomic Finishing Features (Rounding / Fillet)
  const rounding: SemanticFeature = {
    id: 'corner_rounding',
    type: 'ROUNDING',
    label: 'Corner Rounding',
    purpose: 'Smooth exterior corner radius for comfortable handling and printability.',
    parameters: {
      radius: 4,
    },
    parameterIds: ['corner_radius'],
    source: 'inferred',
    criticality: 'optional',
    geometryOperation: 'finish',
    aliases: ['edge fillets', 'rounded corners', 'smooth edges'],
    status: 'planned',
  };
  features.push(rounding);
  parameters.push(
    createFeatureParameter({ id: 'corner_radius', featureId: rounding.id, name: 'radius', semanticName: 'corner_radius', value: 4, unit: 'mm', source: 'inferred' })
  );
  relationships.push(createFeatureRelationship({ sourceFeatureId: rounding.id, targetFeatureId: baseFeatureId, relationshipType: 'attached_to', description: 'Rounds base corners' }));

  // Global Minimum Wall Thickness Constraint
  constraints.push(
    createFeatureConstraint({
      name: 'Minimum Wall Thickness',
      description: 'Ensures all printable walls remain at least 2.4 mm thick for rigidity',
      constraintType: 'min_value',
      affectedFeatureIds: features.map((f) => f.id),
      parameterKeys: ['wall_thickness', 'thickness', 'plate_thickness'],
      value: 2.4,
    })
  );

  return {
    modelId,
    objectType: spec.primaryObject || 'Mechanical Part',
    baseFeatureId,
    features,
    relationships,
    parameters,
    constraints,
    generationStrategy: spec.generationStrategy || 'Feature-based CSG construction',
    schemaVersion: 3,
  };
}
