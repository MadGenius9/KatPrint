export type FeatureType =
  | 'BASE_BODY'
  | 'PLATE'
  | 'WALL'
  | 'SHELL'
  | 'CAVITY'
  | 'POCKET'
  | 'HOLE'
  | 'COUNTERBORE'
  | 'COUNTERSINK'
  | 'THREADED_HOLE'
  | 'SLOT'
  | 'CHANNEL'
  | 'CUTOUT'
  | 'BOSS'
  | 'STANDOFF'
  | 'RIB'
  | 'GUSSET'
  | 'LIP'
  | 'FLANGE'
  | 'HOOK'
  | 'CLIP'
  | 'TAB'
  | 'SNAP_FIT'
  | 'RAIL'
  | 'CRADLE'
  | 'SUPPORT'
  | 'FOOT'
  | 'HINGE'
  | 'DOVETAIL'
  | 'DRAINAGE_HOLE'
  | 'DRAINAGE_SLOT'
  | 'CABLE_OPENING'
  | 'VENT'
  | 'TEXT'
  | 'PATTERN_LINEAR'
  | 'PATTERN_CIRCULAR'
  | 'FILLET'
  | 'CHAMFER'
  | 'ROUNDING'
  | 'CUSTOM_PARAMETRIC';

export type FeatureSource =
  | 'explicit'
  | 'inferred'
  | 'reference'
  | 'template'
  | 'revision';

export type FeatureCriticality = 'critical' | 'important' | 'optional';

export type GeometryOperation =
  | 'base'
  | 'add'
  | 'subtract'
  | 'intersect'
  | 'pattern'
  | 'finish';

export type FeatureStatus =
  | 'planned'
  | 'generated'
  | 'verified'
  | 'unknown'
  | 'failed';

export type ParameterUnit = 'mm' | 'deg' | 'count' | 'boolean' | 'ratio';

export type ParameterSource =
  | 'explicit'
  | 'inferred'
  | 'reference'
  | 'default'
  | 'revision';

export interface FeatureParameter {
  id: string;
  featureId: string;
  name: string;
  semanticName: string;
  value: number | string | boolean;
  unit?: ParameterUnit;
  min?: number;
  max?: number;
  step?: number;
  source: ParameterSource;
  locked?: boolean;
  critical?: boolean;
  description?: string;
  jscadConstantName?: string;
}

export interface GeometrySelectionMetadata {
  boundingBox?: {
    min: [number, number, number];
    max: [number, number, number];
  };
  approximateCenter?: [number, number, number];
  featureIndex?: number;
  debugColorHex?: string;
}

export type FeatureVerificationEvidence =
  | 'PARAMETER_BOUND'
  | 'BUILDER_CALL_BOUND'
  | 'GEOMETRY_MEASURED'
  | 'GEOMETRY_REGION_IDENTIFIED'
  | 'VISUAL_REVIEW'
  | 'SOURCE_HINT_ONLY'
  | 'NONE';

export interface SemanticFeature {
  id: string;
  partId?: string;
  type: FeatureType;
  label: string;
  purpose: string;
  parameters: Record<string, number | string | boolean>;
  parameterIds: string[];
  parentFeatureId?: string;
  childFeatureIds?: string[];
  source: FeatureSource;
  criticality: FeatureCriticality;
  geometryOperation: GeometryOperation;
  verificationStrategy?: string;
  aliases?: string[];
  status?: FeatureStatus;
  evidence?: FeatureVerificationEvidence;
  geometrySelectionMetadata?: GeometrySelectionMetadata;
  verificationNotes?: string;
}

export type RelationshipType =
  | 'attached_to'
  | 'subtracts_from'
  | 'reinforces'
  | 'aligned_with'
  | 'centered_on'
  | 'mirrored_from'
  | 'patterned_from'
  | 'inside'
  | 'outside'
  | 'above'
  | 'below'
  | 'references'
  | 'fits'
  | 'supports';

export interface FeatureRelationship {
  id: string;
  sourceFeatureId: string;
  targetFeatureId: string;
  relationshipType: RelationshipType;
  description?: string;
  parameters?: Record<string, any>;
}

export type ConstraintType =
  | 'distance'
  | 'alignment'
  | 'equality'
  | 'min_value'
  | 'max_value'
  | 'clearance'
  | 'symmetry'
  | 'orientation';

export interface FeatureConstraint {
  id: string;
  name: string;
  description: string;
  constraintType: ConstraintType;
  affectedFeatureIds: string[];
  parameterKeys?: string[];
  value?: number | string | boolean;
  tolerance?: number;
  isLocked?: boolean;
}

export interface FeatureCodeBinding {
  featureId: string;
  featureFunctionName?: string;
  featureFunctionUsed?: boolean;
  builderName?: string;
  builderCallConfirmed?: boolean;
  parameterBindings: {
    parameterId: string;
    constantName: string;
  }[];
  functionNames?: string[];
}

export interface FeatureBindingValidation {
  boundFeatures: string[];
  partiallyBoundFeatures: string[];
  unboundFeatures: string[];

  boundParameters: string[];
  unboundParameters: string[];

  criticalUnboundParameters: string[];

  builderBoundFeatures: string[];
  missingBuilderFeatures: string[];

  valid: boolean;
}

export interface FeatureSelectionValidationInfo {
  valid: boolean;
  invalidFeatureIds: string[];
  violations: Array<{
    featureId: string;
    wrapperName: string;
    transform: 'translate' | 'rotate' | 'scale' | 'center' | 'align' | 'unknown';
    message: string;
  }>;
}

export interface SemanticFeatureModel {
  modelId: string;
  objectType: string;
  baseFeatureId: string;
  features: SemanticFeature[];
  relationships: FeatureRelationship[];
  parameters: FeatureParameter[];
  constraints: FeatureConstraint[];
  codeBindings?: FeatureCodeBinding[];
  bindingValidation?: FeatureBindingValidation;
  selectionValidation?: FeatureSelectionValidationInfo;
  generationStrategy: string;
  schemaVersion: number;
}

export type SemanticRevisionOpType =
  | 'SET_PARAMETER'
  | 'INCREMENT_PARAMETER'
  | 'ADD_FEATURE'
  | 'REMOVE_FEATURE'
  | 'MOVE_FEATURE'
  | 'RESIZE_FEATURE'
  | 'DUPLICATE_FEATURE'
  | 'PATTERN_FEATURE'
  | 'REPLACE_FEATURE'
  | 'ADD_PART'
  | 'REMOVE_PART'
  | 'DUPLICATE_PART'
  | 'CHANGE_PART_QUANTITY';

export interface ParameterChange {
  parameterId: string;
  featureId: string;
  paramName: string;
  oldValue: number | string | boolean;
  newValue: number | string | boolean;
  delta?: number;
  unit?: string;
}

export interface SemanticRevisionOperation {
  operation: SemanticRevisionOpType;
  featureIds: string[];
  parameterChanges?: ParameterChange[];
  addedFeatures?: SemanticFeature[];
  removedFeatureIds?: string[];
  reason: string;
  confidence: number;
}
