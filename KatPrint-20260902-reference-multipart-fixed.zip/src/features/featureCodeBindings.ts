import {
  SemanticFeatureModel,
  FeatureCodeBinding,
  FeatureBindingValidation,
} from './featureTypes';
import { FEATURE_BUILDER_REGISTRY, getFeatureFunctionName } from './featureGenerators';

/**
 * Returns the set of function names reachable via the call graph starting from `main()`.
 * Checks direct calls in `main()` as well as intermediate helper function calls.
 */
export function getReachableFunctionsFromMain(code: string): Set<string> {
  const funcRegex = /(?:async\s+)?function\s+([a-zA-Z0-9_$]+)\s*\([^)]*\)\s*\{([\s\S]*?)\n\}/g;
  const funcBodies: Record<string, string> = {};
  let match: RegExpExecArray | null;
  while ((match = funcRegex.exec(code)) !== null) {
    funcBodies[match[1]] = match[2];
  }

  const reachable = new Set<string>();
  if (!funcBodies['main']) {
    return reachable;
  }

  const queue: string[] = ['main'];
  const visited = new Set<string>(['main']);

  while (queue.length > 0) {
    const currentFn = queue.shift()!;
    const body = funcBodies[currentFn] || '';

    for (const fnName of Object.keys(funcBodies)) {
      if (fnName === 'main' || visited.has(fnName)) continue;
      const callRegex = new RegExp(`\\b${fnName}\\s*\\(`, 'm');
      if (callRegex.test(body)) {
        reachable.add(fnName);
        visited.add(fnName);
        queue.push(fnName);
      }
    }
  }

  return reachable;
}

/**
 * Scans JSCAD code and extracts constant declarations like `const mountingHoleDiameter = 5.0;`
 * and maps them to SemanticFeatureModel parameters and feature wrapper functions.
 *
 * In 'strict' mode (default for Phase 3 models), requires exact constant names matching
 * `param.jscadConstantName` (or `param.name` if not specified).
 * In 'legacy' mode, allows case-insensitive candidate guessing.
 */
export function extractFeatureCodeBindings(
  code: string,
  model: SemanticFeatureModel,
  mode: 'strict' | 'legacy' = 'strict'
): FeatureCodeBinding[] {
  const bindings: FeatureCodeBinding[] = [];

  // Match all top-level constants: const variableName = 12.34;
  const constRegex = /(?:const|let|var)\s+([a-zA-Z0-9_$]+)\s*=\s*([-0-9.]+|true|false|'[^']*'|"[^"]*")/g;
  const foundConstants: Record<string, string | number | boolean> = {};
  let match: RegExpExecArray | null;

  while ((match = constRegex.exec(code)) !== null) {
    const rawVal = match[2];
    if (rawVal === 'true') foundConstants[match[1]] = true;
    else if (rawVal === 'false') foundConstants[match[1]] = false;
    else if (rawVal.startsWith("'") || rawVal.startsWith('"')) foundConstants[match[1]] = rawVal.slice(1, -1);
    else foundConstants[match[1]] = parseFloat(rawVal);
  }

  // Extract function definitions and their bodies: function name(...) { body }
  const funcRegex = /(?:async\s+)?function\s+([a-zA-Z0-9_$]+)\s*\([^)]*\)\s*\{([\s\S]*?)\n\}/g;
  const foundFunctions: Record<string, string> = {};
  while ((match = funcRegex.exec(code)) !== null) {
    foundFunctions[match[1]] = match[2];
  }

  const reachableFunctions = getReachableFunctionsFromMain(code);
  const hasMain = Object.prototype.hasOwnProperty.call(foundFunctions, 'main');

  for (const feature of model.features) {
    const paramBindings: { parameterId: string; constantName: string }[] = [];

    for (const paramId of feature.parameterIds) {
      const param = model.parameters.find((p) => p.id === paramId);
      if (!param) continue;

      if (mode === 'strict') {
        const targetConst = param.jscadConstantName || param.name;
        if (targetConst && Object.prototype.hasOwnProperty.call(foundConstants, targetConst)) {
          paramBindings.push({
            parameterId: param.id,
            constantName: targetConst,
          });
        }
      } else {
        // Legacy candidate resolution
        const candidates = [
          param.jscadConstantName,
          param.name,
          param.semanticName,
          param.semanticName ? param.semanticName.replace(/_/g, '') : '',
        ].filter(Boolean) as string[];

        for (const cand of candidates) {
          const matchedKey = Object.keys(foundConstants).find(
            (k) => k.toLowerCase() === cand.toLowerCase()
          );
          if (matchedKey) {
            paramBindings.push({
              parameterId: param.id,
              constantName: matchedKey,
            });
            break;
          }
        }
      }
    }

    // Match feature-specific wrapper function name (e.g. kpFeature_mounting_hole_left)
    const expectedFnName = getFeatureFunctionName(feature.id);
    let featureFunctionName: string | undefined = undefined;
    let builderCallConfirmed = false;
    const builderSpec = FEATURE_BUILDER_REGISTRY[feature.type];
    const builderName = builderSpec?.builderName;

    if (foundFunctions[expectedFnName]) {
      featureFunctionName = expectedFnName;
      const fnBody = foundFunctions[expectedFnName];
      if (builderName) {
        const bRegex = new RegExp(`\\b${builderName}\\s*\\(`, 'm');
        builderCallConfirmed = bRegex.test(fnBody);
      }
    } else if (mode === 'legacy') {
      // Legacy fallback matching for other function names
      const matchedFn = Object.keys(foundFunctions).find((fn) => {
        const lower = fn.toLowerCase();
        const featIdLower = feature.id.toLowerCase().replace(/_/g, '');
        return lower === `kpfeature_${featIdLower}` || lower === featIdLower;
      });
      if (matchedFn) {
        featureFunctionName = matchedFn;
        const fnBody = foundFunctions[matchedFn];
        if (builderName) {
          const bRegex = new RegExp(`\\b${builderName}\\s*\\(`, 'm');
          builderCallConfirmed = bRegex.test(fnBody);
        }
      }
    }

    const featureFunctionUsed = featureFunctionName
      ? hasMain
        ? reachableFunctions.has(featureFunctionName)
        : new RegExp(`\\b${featureFunctionName}\\s*\\(`).test(code)
      : false;

    bindings.push({
      featureId: feature.id,
      featureFunctionName,
      featureFunctionUsed,
      builderName,
      builderCallConfirmed: builderCallConfirmed && featureFunctionUsed,
      parameterBindings: paramBindings,
      functionNames: featureFunctionName ? [featureFunctionName] : [],
    });
  }

  return bindings;
}

/**
 * Validates whether the SemanticFeatureModel parameters and feature types
 * are strictly and correctly bound in the generated JSCAD source code.
 */
export function validateFeatureBindings(
  model: SemanticFeatureModel,
  code: string,
  mode: 'strict' | 'legacy' = 'strict'
): FeatureBindingValidation {
  const bindings = model.codeBindings || extractFeatureCodeBindings(code, model, mode);

  const boundFeatures: string[] = [];
  const partiallyBoundFeatures: string[] = [];
  const unboundFeatures: string[] = [];

  const boundParameters: string[] = [];
  const unboundParameters: string[] = [];
  const criticalUnboundParameters: string[] = [];

  const builderBoundFeatures: string[] = [];
  const missingBuilderFeatures: string[] = [];

  // Check each feature
  for (const feature of model.features) {
    const binding = bindings.find((b) => b.featureId === feature.id);
    const expectedParamIds = feature.parameterIds;
    const boundParamIds = (binding?.parameterBindings || []).map((pb) => pb.parameterId);

    // Check builder presence feature-specifically
    const builderSpec = FEATURE_BUILDER_REGISTRY[feature.type];
    if (builderSpec) {
      if (binding?.builderCallConfirmed && binding?.featureFunctionUsed) {
        builderBoundFeatures.push(feature.id);
      } else if (mode === 'legacy') {
        // If single feature of this type in legacy model, check if code calls builder anywhere
        const sameTypeFeatures = model.features.filter((f) => f.type === feature.type);
        const builderCallRegex = new RegExp(`\\b${builderSpec.builderName}\\s*\\(`, 'm');
        if (sameTypeFeatures.length === 1 && builderCallRegex.test(code)) {
          builderBoundFeatures.push(feature.id);
        } else {
          missingBuilderFeatures.push(feature.id);
        }
      } else {
        missingBuilderFeatures.push(feature.id);
      }
    }

    if (expectedParamIds.length === 0) {
      // Feature has no parameters, presence check via builder or feature binding
      if (builderSpec) {
        if (builderBoundFeatures.includes(feature.id)) {
          boundFeatures.push(feature.id);
        } else {
          unboundFeatures.push(feature.id);
        }
      } else {
        boundFeatures.push(feature.id);
      }
      continue;
    }

    let fullyBound = true;
    let anyBound = false;

    for (const pId of expectedParamIds) {
      const isBound = boundParamIds.includes(pId);
      const paramObj = model.parameters.find((p) => p.id === pId);
      const isCritical = feature.criticality === 'critical' || paramObj?.critical === true;

      if (isBound) {
        anyBound = true;
        if (!boundParameters.includes(pId)) boundParameters.push(pId);
      } else {
        fullyBound = false;
        if (!unboundParameters.includes(pId)) unboundParameters.push(pId);
        if (isCritical && !criticalUnboundParameters.includes(pId)) {
          criticalUnboundParameters.push(pId);
        }
      }
    }

    if (builderSpec && missingBuilderFeatures.includes(feature.id)) {
      if (anyBound) {
        partiallyBoundFeatures.push(feature.id);
      } else {
        unboundFeatures.push(feature.id);
      }
    } else if (fullyBound) {
      boundFeatures.push(feature.id);
    } else if (anyBound) {
      partiallyBoundFeatures.push(feature.id);
    } else {
      unboundFeatures.push(feature.id);
    }
  }

  const valid =
    criticalUnboundParameters.length === 0 &&
    missingBuilderFeatures.length === 0 &&
    unboundFeatures.length === 0;

  return {
    boundFeatures,
    partiallyBoundFeatures,
    unboundFeatures,
    boundParameters,
    unboundParameters,
    criticalUnboundParameters,
    builderBoundFeatures,
    missingBuilderFeatures,
    valid,
  };
}

/**
 * Updates a JSCAD script deterministically by updating the numeric constant values
 * associated with modified parameters.
 */
export function updateJscadConstants(
  code: string,
  updates: { constantName: string; newValue: number | string | boolean }[]
): { updatedCode: string; modifiedCount: number } {
  let updatedCode = code;
  let modifiedCount = 0;

  for (const { constantName, newValue } of updates) {
    // Regex matching const/let/var name = <value>;
    const regex = new RegExp(
      `((?:const|let|var)\\s+${constantName}\\s*=\\s*)([-0-9.]+|true|false|'[^']*'|"[^"]*")(\\s*;)`,
      'g'
    );
    if (regex.test(updatedCode)) {
      const formattedValue = typeof newValue === 'string' ? `'${newValue}'` : `${newValue}`;
      updatedCode = updatedCode.replace(regex, `$1${formattedValue}$3`);
      modifiedCount++;
    }
  }

  return { updatedCode, modifiedCount };
}
