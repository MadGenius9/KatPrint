import * as THREE from 'three';
import * as jscadModelingLib from '@jscad/modeling';
import {
  SemanticFeatureModel,
  SemanticFeature,
  FeatureType,
  GeometryOperation,
  FeatureCodeBinding,
} from './featureTypes';
import { jscadGeomToThree } from '../engine/geometryUtils';
import { validateCadCodeSecurity } from '../engine/codeSecurity';
import {
  JSCAD_FEATURE_BUILDER_LIB,
  validateReservedBuilderUsage,
  getFeatureFunctionName,
} from './featureGenerators';
import { extractFeatureCodeBindings } from './featureCodeBindings';

export interface FeatureSelectionGeometry {
  featureId: string;
  featureType: FeatureType;
  label: string;
  geometryOperation: GeometryOperation;
  geometry: THREE.BufferGeometry;
  boundingBox: {
    min: [number, number, number];
    max: [number, number, number];
  };
  center: [number, number, number];
  volumeMm3: number;
  selectable: boolean;
  selectionConfidence: 'exact' | 'strong' | 'approximate';
  reason?: string;
  isCutterProxy?: boolean;
}

export interface FeatureSelectionDiagnostics {
  selectableFeatureCount: number;
  unselectableFeatureCount: number;
  selectionProxyBuildMs: number;
  featureSelectionCacheHit: boolean;
  totalFeatures: number;
  worldSpaceValidationPassed: boolean;
  worldSpaceViolationCount: number;
  mispositionedFeatureCount: number;
  mispositionedFeatureIds: string[];
  featuresSummary: Array<{
    id: string;
    label: string;
    type: FeatureType;
    selectable: boolean;
    reason?: string;
  }>;
}

export interface FeatureSelectionResult {
  finalGeometry: THREE.BufferGeometry;
  featureGeometries: FeatureSelectionGeometry[];
  diagnostics: FeatureSelectionDiagnostics;
}

export interface FeatureWrapperWorldSpaceValidation {
  valid: boolean;
  violations: Array<{
    featureId: string;
    wrapperName: string;
    transform: 'translate' | 'rotate' | 'scale' | 'center' | 'align' | 'unknown';
    message: string;
  }>;
  invalidFeatureIds: string[];
}

export interface FeatureSelectionAvailability {
  isPickable: boolean;
  confidence: 'exact' | 'strong' | 'approximate' | 'none';
  reason?: string;
  wrapperName?: string;
  binding?: FeatureCodeBinding;
  isDeadWrapper?: boolean;
  hasExecutableFunction?: boolean;
  worldSpaceValid?: boolean;
  featureFunctionUsed?: boolean;
}

/**
 * Validates that feature wrappers in JSCAD code adhere to the World-Space ABI.
 * Feature wrapper functions (kpFeature_<id>) MUST return geometry in model world coordinates.
 * Outer transformations (translate, rotate, scale, center, align) around kpFeature_* calls in main() are disallowed.
 */
export function validateFeatureWrapperWorldSpaceUsage(
  code: string,
  featureModel?: SemanticFeatureModel | null
): FeatureWrapperWorldSpaceValidation {
  if (!code || typeof code !== 'string') {
    return { valid: true, violations: [], invalidFeatureIds: [] };
  }

  const violations: FeatureWrapperWorldSpaceValidation['violations'] = [];
  const invalidFeatureIds: string[] = [];
  const featureWrapperMap = new Map<string, { featureId: string; wrapperName: string }>();

  if (featureModel && Array.isArray(featureModel.features)) {
    for (const f of featureModel.features) {
      const binding = featureModel.codeBindings?.find((b) => b.featureId === f.id);
      const name = binding?.featureFunctionName || getFeatureFunctionName(f.id);
      featureWrapperMap.set(name, { featureId: f.id, wrapperName: name });
    }
  }

  // Also discover any kpFeature_* functions in code
  const fnRegex = /function\s+(kpFeature_[a-zA-Z0-9_$]+)/g;
  let m: RegExpExecArray | null;
  while ((m = fnRegex.exec(code)) !== null) {
    const fnName = m[1];
    if (!featureWrapperMap.has(fnName)) {
      const derivedId = fnName.replace(/^kpFeature_/, '');
      featureWrapperMap.set(fnName, { featureId: derivedId, wrapperName: fnName });
    }
  }

  const transformChecks = [
    { type: 'translate' as const, regexStr: '\\btranslate\\s*\\([^;]*?\\b' },
    { type: 'rotate' as const, regexStr: '\\b(?:rotate|rotateX|rotateY|rotateZ)\\s*\\([^;]*?\\b' },
    { type: 'scale' as const, regexStr: '\\bscale\\s*\\([^;]*?\\b' },
    { type: 'center' as const, regexStr: '\\bcenter\\s*\\([^;]*?\\b' },
    { type: 'align' as const, regexStr: '\\balign\\s*\\([^;]*?\\b' },
  ];

  for (const { featureId, wrapperName } of featureWrapperMap.values()) {
    for (const check of transformChecks) {
      const outerTransformRegex = new RegExp(
        `${check.regexStr}${wrapperName}\\s*\\(`,
        'm'
      );
      if (outerTransformRegex.test(code)) {
        violations.push({
          featureId,
          wrapperName,
          transform: check.type,
          message: `World-Space ABI Violation: Outer '${check.type}' transformation applied around '${wrapperName}()'. Feature wrappers must return positioned geometry in final world coordinates directly.`,
        });
        invalidFeatureIds.push(featureId);
        break;
      }
    }
  }

  return {
    valid: violations.length === 0,
    violations,
    invalidFeatureIds: Array.from(new Set(invalidFeatureIds)),
  };
}

/**
 * Authoritative helper to evaluate whether a semantic feature can be selected in 3D viewport.
 * Checks binding existence, wrapper function definition, world-space ABI compliance, and reachability.
 */
export function getFeatureSelectionAvailability(
  feature: SemanticFeature,
  featureModel?: SemanticFeatureModel | null,
  code?: string,
  worldSpaceValidation?: FeatureWrapperWorldSpaceValidation
): FeatureSelectionAvailability {
  if (!featureModel || !Array.isArray(featureModel.features)) {
    return {
      isPickable: false,
      confidence: 'none',
      reason: 'No semantic feature model loaded.',
    };
  }

  const expectedFnName = getFeatureFunctionName(feature.id);
  const binding =
    featureModel.codeBindings?.find((b) => b.featureId === feature.id) ||
    (code ? extractFeatureCodeBindings(code, featureModel, 'strict').find((b) => b.featureId === feature.id) : undefined);

  const wrapperName = binding?.featureFunctionName || expectedFnName;
  const hasExecutableFunction = Boolean(
    wrapperName &&
      code &&
      (code.includes(`function ${wrapperName}`) || code.includes(`${wrapperName}()`) || code.includes(wrapperName))
  );

  const wsVal =
    worldSpaceValidation ||
    (code
      ? validateFeatureWrapperWorldSpaceUsage(code, featureModel)
      : { valid: true, violations: [], invalidFeatureIds: [] });
  const isWorldSpaceViolation = wsVal.invalidFeatureIds.includes(feature.id);
  const worldSpaceValid = !isWorldSpaceViolation;

  const isLegacy = featureModel.generationStrategy === 'legacy-reconstructed';

  // 1. Check for world-space ABI violations
  if (isWorldSpaceViolation) {
    const violation = wsVal.violations.find((v) => v.featureId === feature.id);
    return {
      isPickable: false,
      confidence: 'none',
      reason:
        violation?.message ||
        'Feature wrapper is spatially transformed outside its semantic wrapper, so its 3D selection position cannot be trusted.',
      wrapperName,
      binding,
      hasExecutableFunction,
      worldSpaceValid: false,
      featureFunctionUsed: binding?.featureFunctionUsed,
    };
  }

  // 2. Dead wrapper: explicitly disconnected from main geometry
  if (binding?.featureFunctionUsed === false) {
    return {
      isPickable: false,
      confidence: 'none',
      isDeadWrapper: true,
      reason: 'Dead wrapper (wrapper function not connected to main geometry).',
      wrapperName,
      binding,
      hasExecutableFunction,
      worldSpaceValid: true,
      featureFunctionUsed: false,
    };
  }

  // 3. Strict mode evaluation
  if (!isLegacy) {
    if (!binding || !binding.featureFunctionName || !hasExecutableFunction) {
      return {
        isPickable: false,
        confidence: 'none',
        reason: 'No feature function wrapper found in CAD script.',
        wrapperName: undefined,
        binding,
        hasExecutableFunction: false,
        worldSpaceValid: true,
        featureFunctionUsed: binding?.featureFunctionUsed,
      };
    }

    if (binding.featureFunctionUsed !== true) {
      return {
        isPickable: false,
        confidence: 'none',
        reason: 'Feature wrapper reachability unproven (featureFunctionUsed is not true).',
        wrapperName,
        binding,
        hasExecutableFunction: true,
        worldSpaceValid: true,
        featureFunctionUsed: binding.featureFunctionUsed,
      };
    }

    return {
      isPickable: true,
      confidence: 'exact',
      wrapperName,
      binding,
      hasExecutableFunction: true,
      worldSpaceValid: true,
      featureFunctionUsed: true,
    };
  } else {
    // 4. Legacy model mode: allow weaker reachability evidence if wrapper exists
    if (!hasExecutableFunction) {
      return {
        isPickable: false,
        confidence: 'none',
        reason: 'No executable feature wrapper found in legacy script.',
        wrapperName: undefined,
        binding,
        hasExecutableFunction: false,
        worldSpaceValid: true,
        featureFunctionUsed: binding?.featureFunctionUsed,
      };
    }

    const confidence = binding?.featureFunctionUsed === true ? 'strong' : 'approximate';
    return {
      isPickable: true,
      confidence,
      reason: 'Legacy approximate selection',
      wrapperName,
      binding,
      hasExecutableFunction: true,
      worldSpaceValid: true,
      featureFunctionUsed: binding?.featureFunctionUsed,
    };
  }
}

// ---------------------------------------------------------------------------
// In-Memory Feature Selection Cache
// ---------------------------------------------------------------------------
interface CacheEntry {
  cacheKey: string;
  result: FeatureSelectionResult;
  timestamp: number;
}

const selectionCache = new Map<string, CacheEntry>();
const MAX_CACHE_ENTRIES = 20;

/**
 * Produces a stable, compact cryptographic-like hash of all semantic selection-relevant data,
 * including all features, all parameters (without slicing), all code bindings, and world-space validation status.
 */
export function stableSemanticSelectionFingerprint(featureModel?: SemanticFeatureModel | null): string {
  if (!featureModel) return 'no_model';

  let str = `schema:${featureModel.schemaVersion || 0}|strat:${featureModel.generationStrategy || 'default'}|`;

  if (Array.isArray(featureModel.features)) {
    str += 'feats:' + featureModel.features.map((f) => `${f.id}:${f.type}:${f.geometryOperation || 'add'}`).join(',') + '|';
  }

  if (Array.isArray(featureModel.parameters)) {
    str += 'params:' + featureModel.parameters.map((p) => `${p.id}:${p.value}`).join(',') + '|';
  }

  if (Array.isArray(featureModel.codeBindings)) {
    str +=
      'bindings:' +
      featureModel.codeBindings
        .map((b) => {
          const pbStr = (b.parameterBindings || []).map((pb) => `${pb.parameterId}=${pb.constantName}`).join('&');
          return `${b.featureId}:${b.featureFunctionName}:${b.featureFunctionUsed}:${b.builderName || ''}:${b.builderCallConfirmed || false}:[${pbStr}]`;
        })
        .join(',') +
      '|';
  }

  if (featureModel.selectionValidation) {
    str += 'selval:' + (featureModel.selectionValidation.invalidFeatureIds || []).join(',') + '|';
  }

  // 32-bit FNV-1a hash
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16);
}

function computeCacheKey(
  versionId: string | undefined,
  code: string,
  featureModel?: SemanticFeatureModel,
  scaleFactor: number = 1.0
): string {
  let codeHash = 0x811c9dc5;
  for (let i = 0; i < code.length; i++) {
    codeHash ^= code.charCodeAt(i);
    codeHash = Math.imul(codeHash, 0x01000193);
  }
  const codeHashStr = (codeHash >>> 0).toString(16);
  const fingerprint = stableSemanticSelectionFingerprint(featureModel);
  return `${versionId || 'noid'}_code[${codeHashStr}]_fp[${fingerprint}]_s${scaleFactor}`;
}

export function clearFeatureSelectionCache(): void {
  selectionCache.clear();
}

/**
 * Builds the JSCAD execution sandbox runtime
 */
function buildSandboxContext(): Record<string, any> {
  const modelingLib: any = jscadModelingLib;
  const rawJscad = modelingLib?.default?.primitives
    ? modelingLib.default
    : modelingLib?.primitives
    ? modelingLib
    : (modelingLib?.default || modelingLib || {});

  const rawPrimitives = rawJscad.primitives || modelingLib?.primitives || {};
  const rawBooleans = rawJscad.booleans || modelingLib?.booleans || {};
  const rawTransforms = rawJscad.transforms || modelingLib?.transforms || {};
  const rawExtrusions = rawJscad.extrusions || modelingLib?.extrusions || {};
  const rawHulls = rawJscad.hulls || modelingLib?.hulls || {};
  const rawExpansions = rawJscad.expansions || modelingLib?.expansions || {};
  const rawGeometries = rawJscad.geometries || modelingLib?.geometries || {};
  const rawMeasurements = rawJscad.measurements || modelingLib?.measurements || {};
  const rawColors = rawJscad.colors || modelingLib?.colors || {};
  const rawMaths = rawJscad.maths || modelingLib?.maths || {};
  const rawUtils = rawJscad.utils || modelingLib?.utils || {};

  const safeCube = (o: any) => rawPrimitives.cube ? rawPrimitives.cube(o) : (rawPrimitives.cuboid ? rawPrimitives.cuboid(o) : o);
  const safeCuboid = (o: any) => rawPrimitives.cuboid ? rawPrimitives.cuboid(o) : (rawPrimitives.cube ? rawPrimitives.cube(o) : o);
  const safeRoundedCuboid = (o: any) => rawPrimitives.roundedCuboid ? rawPrimitives.roundedCuboid(o) : safeCuboid(o);
  const safeCylinder = (o: any) => rawPrimitives.cylinder ? rawPrimitives.cylinder(o) : o;
  const safeCone = (o: any) => rawPrimitives.cylinder ? rawPrimitives.cylinder(o) : o;
  const safeSphere = (o: any) => rawPrimitives.sphere ? rawPrimitives.sphere(o) : o;
  const safeTorus = (o: any) => rawPrimitives.torus ? rawPrimitives.torus(o) : o;

  const safeSubtract = (...args: any[]) => rawBooleans.subtract ? rawBooleans.subtract(...args) : args[0];
  const safeUnion = (...args: any[]) => rawBooleans.union ? rawBooleans.union(...args) : args[0];
  const safeIntersect = (...args: any[]) => rawBooleans.intersect ? rawBooleans.intersect(...args) : args[0];

  const safeTranslate = (offset: any, ...geoms: any[]) => rawTransforms.translate ? rawTransforms.translate(offset, ...geoms) : geoms[0];
  const safeRotate = (angles: any, ...geoms: any[]) => rawTransforms.rotate ? rawTransforms.rotate(angles, ...geoms) : geoms[0];
  const safeRotateX = (rad: any, ...geoms: any[]) => rawTransforms.rotateX ? rawTransforms.rotateX(rad, ...geoms) : geoms[0];
  const safeRotateY = (rad: any, ...geoms: any[]) => rawTransforms.rotateY ? rawTransforms.rotateY(rad, ...geoms) : geoms[0];
  const safeRotateZ = (rad: any, ...geoms: any[]) => rawTransforms.rotateZ ? rawTransforms.rotateZ(rad, ...geoms) : geoms[0];
  const safeScale = (factors: any, ...geoms: any[]) => rawTransforms.scale ? rawTransforms.scale(factors, ...geoms) : geoms[0];
  const safeCenter = (options: any, ...geoms: any[]) => rawTransforms.center ? rawTransforms.center(options, ...geoms) : geoms[0];
  const safeAlign = (options: any, ...geoms: any[]) => rawTransforms.align ? rawTransforms.align(options, ...geoms) : geoms[0];

  const safeExtrudeLinear = (options: any, geom: any) => rawExtrusions.extrudeLinear ? rawExtrusions.extrudeLinear(options, geom) : geom;
  const safeExtrudeRotate = (options: any, geom: any) => rawExtrusions.extrudeRotate ? rawExtrusions.extrudeRotate(options, geom) : geom;
  const safeExtrudeRectangular = (options: any, geom: any) => rawExtrusions.extrudeRectangular ? rawExtrusions.extrudeRectangular(options, geom) : geom;

  const safeHull = (...geoms: any[]) => rawHulls.hull ? rawHulls.hull(...geoms) : geoms[0];
  const safeHullChain = (...geoms: any[]) => rawHulls.hullChain ? rawHulls.hullChain(...geoms) : geoms[0];
  const safeExpand = (options: any, geom: any) => rawExpansions.expand ? rawExpansions.expand(options, geom) : geom;
  const safeOffset = (options: any, geom: any) => rawExpansions.offset ? rawExpansions.offset(options, geom) : geom;
  const safeColorize = (color: any, ...geoms: any[]) => rawColors.colorize ? rawColors.colorize(color, ...geoms) : geoms[0];

  return {
    primitives: {
      cube: safeCube,
      cuboid: safeCuboid,
      roundedCuboid: safeRoundedCuboid,
      cylinder: safeCylinder,
      cylinderElliptic: rawPrimitives.cylinderElliptic || safeCylinder,
      cone: safeCone,
      sphere: safeSphere,
      torus: safeTorus,
      polygon: rawPrimitives.polygon || ((o: any) => o),
      rectangle: rawPrimitives.rectangle || ((o: any) => o),
      roundedRectangle: rawPrimitives.roundedRectangle || ((o: any) => o),
      circle: rawPrimitives.circle || ((o: any) => o),
      ellipse: rawPrimitives.ellipse || ((o: any) => o),
      star: rawPrimitives.star || ((o: any) => o),
      polyhedron: rawPrimitives.polyhedron || ((o: any) => o),
    },
    booleans: {
      subtract: safeSubtract,
      union: safeUnion,
      intersect: safeIntersect,
    },
    transforms: {
      translate: safeTranslate,
      rotate: safeRotate,
      rotateX: safeRotateX,
      rotateY: safeRotateY,
      rotateZ: safeRotateZ,
      scale: safeScale,
      center: safeCenter,
      align: safeAlign,
      mirror: rawTransforms.mirror || ((o: any, g: any) => g),
    },
    extrusions: {
      extrudeLinear: safeExtrudeLinear,
      extrudeRotate: safeExtrudeRotate,
      extrudeRectangular: safeExtrudeRectangular,
      slice: rawExtrusions.slice || ((o: any) => o),
    },
    hulls: {
      hull: safeHull,
      hullChain: safeHullChain,
    },
    expansions: {
      expand: safeExpand,
      offset: safeOffset,
    },
    measurements: rawMeasurements,
    colors: {
      colorize: safeColorize,
      colorNameToRgb: rawColors.colorNameToRgb || ((n: any) => [0.5, 0.5, 0.5, 1]),
      hexToRgb: rawColors.hexToRgb || ((h: any) => [0.5, 0.5, 0.5, 1]),
      rgbToHex: rawColors.rgbToHex || (() => '#888888'),
    },
    maths: rawMaths,
    utils: rawUtils,
    geometries: rawGeometries,

    cube: safeCube,
    cuboid: safeCuboid,
    roundedCuboid: safeRoundedCuboid,
    cylinder: safeCylinder,
    cylinderElliptic: rawPrimitives.cylinderElliptic || safeCylinder,
    cone: safeCone,
    sphere: safeSphere,
    torus: safeTorus,
    polygon: rawPrimitives.polygon || ((o: any) => o),
    rectangle: rawPrimitives.rectangle || ((o: any) => o),
    roundedRectangle: rawPrimitives.roundedRectangle || ((o: any) => o),
    circle: rawPrimitives.circle || ((o: any) => o),
    ellipse: rawPrimitives.ellipse || ((o: any) => o),
    star: rawPrimitives.star || ((o: any) => o),
    polyhedron: rawPrimitives.polyhedron || ((o: any) => o),

    subtract: safeSubtract,
    union: safeUnion,
    intersect: safeIntersect,

    translate: safeTranslate,
    rotate: safeRotate,
    rotateX: safeRotateX,
    rotateY: safeRotateY,
    rotateZ: safeRotateZ,
    scale: safeScale,
    center: safeCenter,
    align: safeAlign,

    extrudeLinear: safeExtrudeLinear,
    extrudeRotate: safeExtrudeRotate,
    extrudeRectangular: safeExtrudeRectangular,

    hull: safeHull,
    hullChain: safeHullChain,
    expand: safeExpand,
    offset: safeOffset,
    colorize: safeColorize,

    Math: Math,
    degToRad: (deg: number) => (deg * Math.PI) / 180,
    radToDeg: (rad: number) => (rad * 180) / Math.PI,
  };
}

/**
 * Executes CAD code and all reachable semantic feature wrapper functions,
 * converting them into Three.js geometries transformed into the same aligned
 * coordinate frame as the main model.
 */
export function executeSemanticFeatureGeometries(
  code: string,
  featureModel?: SemanticFeatureModel,
  options?: {
    scaleFactor?: number;
    versionId?: string;
  }
): FeatureSelectionResult {
  const startTime = Date.now();
  const scaleFactor = options?.scaleFactor ?? 1.0;

  if (!code || typeof code !== 'string' || !code.trim()) {
    throw new Error('FEATURE_SELECTION_ERROR: Empty CAD script.');
  }

  // 1. Security validation
  const sec = validateCadCodeSecurity(code);
  if (!sec.isSafe) {
    throw new Error(`SECURITY_REJECTION: ${sec.violations.join('; ')}`);
  }

  // 2. Clean imports & check reserved builders
  const cleanCode = code
    .replace(/^import\s+.*?from\s+['"].*?['"];?/gm, '')
    .replace(/const\s+.*?\s*=\s*require\(.*?\);?/gm, '')
    .trim();

  const reservedErr = validateReservedBuilderUsage(cleanCode);
  if (reservedErr) {
    throw new Error(`RESERVED_BUILDER_REDEFINITION: ${reservedErr.message}`);
  }

  // 3. Build sandbox
  const sandbox = buildSandboxContext();
  const sandboxKeys = Object.keys(sandbox);
  const sandboxValues = Object.values(sandbox);

  // 4. Map known feature functions to execute
  const knownWrappers: Array<{
    featureId: string;
    fnName: string;
    feature: SemanticFeature;
  }> = [];

  if (featureModel && Array.isArray(featureModel.features)) {
    for (const feature of featureModel.features) {
      // Find binding
      const binding = featureModel.codeBindings?.find((b) => b.featureId === feature.id);
      const fnName = binding?.featureFunctionName || getFeatureFunctionName(feature.id);
      knownWrappers.push({
        featureId: feature.id,
        fnName,
        feature,
      });
    }
  }

  // 5. Wrap script to evaluate main() and each known feature wrapper
  const featureExecStatements = knownWrappers
    .map(
      (w) => `
        try {
          if (typeof ${w.fnName} === 'function') {
            __featureSolids['${w.featureId}'] = ${w.fnName}();
          }
        } catch (e) {
          __featureErrors['${w.featureId}'] = e.message;
        }
      `
    )
    .join('\n');

  const wrappedScript = `
    ${JSCAD_FEATURE_BUILDER_LIB}

    ${cleanCode}

    const __featureSolids = {};
    const __featureErrors = {};

    ${featureExecStatements}

    let __finalSolid = null;
    if (typeof main === 'function') {
      __finalSolid = main();
    } else {
      throw new Error("No main() function declared in JSCAD code.");
    }

    return {
      finalSolid: __finalSolid,
      featureSolids: __featureSolids,
      featureErrors: __featureErrors,
    };
  `;

  let compiledFn: Function;
  try {
    // eslint-disable-next-line @typescript-eslint/no-implied-eval
    compiledFn = new Function(...sandboxKeys, wrappedScript);
  } catch (parseErr: any) {
    throw new Error(`FEATURE_SELECTION_ERROR: Syntax error compiling CAD script: ${parseErr.message}`);
  }

  let executionResult: {
    finalSolid: any;
    featureSolids: Record<string, any>;
    featureErrors: Record<string, string>;
  };

  try {
    executionResult = compiledFn(...sandboxValues);
  } catch (runtimeErr: any) {
    throw new Error(`FEATURE_SELECTION_ERROR: Execution failed: ${runtimeErr.message}`);
  }

  if (!executionResult.finalSolid) {
    throw new Error('FEATURE_SELECTION_ERROR: main() returned null, undefined, or empty geometry.');
  }

  // 6. Convert final solid to Three.js BufferGeometry and determine bed alignment transform
  const finalGeom = jscadGeomToThree(executionResult.finalSolid);
  finalGeom.scale(scaleFactor, scaleFactor, scaleFactor);
  finalGeom.computeBoundingBox();

  const finalBox = finalGeom.boundingBox || new THREE.Box3();
  const centerX = (finalBox.min.x + finalBox.max.x) / 2;
  const centerY = (finalBox.min.y + finalBox.max.y) / 2;
  const minZ = finalBox.min.z;

  // Center XY at (0,0) and rest on Z=0
  finalGeom.translate(-centerX, -centerY, -minZ);
  finalGeom.computeBoundingBox();
  finalGeom.computeVertexNormals();

  // 7. Validate world-space ABI usage across all wrappers before building pick proxies
  const worldSpaceValidation = validateFeatureWrapperWorldSpaceUsage(cleanCode, featureModel);

  // 8. Process each semantic feature geometry
  const featureGeometries: FeatureSelectionGeometry[] = [];
  const featuresSummary: FeatureSelectionDiagnostics['featuresSummary'] = [];

  let selectableCount = 0;
  let unselectableCount = 0;

  if (featureModel && Array.isArray(featureModel.features)) {
    for (const feature of featureModel.features) {
      const availability = getFeatureSelectionAvailability(
        feature,
        featureModel,
        cleanCode,
        worldSpaceValidation
      );

      const isSubtractive =
        feature.geometryOperation === 'subtract' ||
        [
          'HOLE',
          'COUNTERSINK',
          'COUNTERBORE',
          'THREADED_HOLE',
          'SLOT',
          'CHANNEL',
          'CUTOUT',
          'CAVITY',
          'POCKET',
          'DRAINAGE_HOLE',
          'DRAINAGE_SLOT',
          'CABLE_OPENING',
          'VENT',
        ].includes(feature.type);

      if (!availability.isPickable) {
        unselectableCount++;
        featuresSummary.push({
          id: feature.id,
          label: feature.label || feature.id,
          type: feature.type,
          selectable: false,
          reason: availability.reason || 'Feature is not selectable',
        });
        continue;
      }

      const solid = executionResult.featureSolids[feature.id];
      const errorMsg = executionResult.featureErrors[feature.id];

      if (!solid) {
        unselectableCount++;
        featuresSummary.push({
          id: feature.id,
          label: feature.label || feature.id,
          type: feature.type,
          selectable: false,
          reason: errorMsg
            ? `Wrapper execution error: ${errorMsg}`
            : 'No executable feature wrapper found or function returned null',
        });
        continue;
      }

      try {
        const featGeom = jscadGeomToThree(solid);
        if (!featGeom.getAttribute('position') || featGeom.getAttribute('position').count === 0) {
          unselectableCount++;
          featuresSummary.push({
            id: feature.id,
            label: feature.label || feature.id,
            type: feature.type,
            selectable: false,
            reason: 'Empty feature geometry generated by wrapper',
          });
          continue;
        }

        // Apply identical scaling & world coordinate alignment
        featGeom.scale(scaleFactor, scaleFactor, scaleFactor);
        featGeom.translate(-centerX, -centerY, -minZ);
        featGeom.computeBoundingBox();
        featGeom.computeBoundingSphere();
        featGeom.computeVertexNormals();

        const box = featGeom.boundingBox || new THREE.Box3();
        const minCoord: [number, number, number] = [box.min.x, box.min.y, box.min.z];
        const maxCoord: [number, number, number] = [box.max.x, box.max.y, box.max.z];
        const centerCoord: [number, number, number] = [
          (box.min.x + box.max.x) / 2,
          (box.min.y + box.max.y) / 2,
          (box.min.z + box.max.z) / 2,
        ];

        const dx = Math.max(0.1, box.max.x - box.min.x);
        const dy = Math.max(0.1, box.max.y - box.min.y);
        const dz = Math.max(0.1, box.max.z - box.min.z);
        const volumeMm3 = dx * dy * dz;

        const selectionConfidence = availability.confidence === 'none' ? 'approximate' : availability.confidence;

        const item: FeatureSelectionGeometry = {
          featureId: feature.id,
          featureType: feature.type,
          label: feature.label || feature.id,
          geometryOperation: feature.geometryOperation || (isSubtractive ? 'subtract' : 'add'),
          geometry: featGeom,
          boundingBox: {
            min: minCoord,
            max: maxCoord,
          },
          center: centerCoord,
          volumeMm3,
          selectable: true,
          selectionConfidence,
          isCutterProxy: isSubtractive,
        };

        featureGeometries.push(item);
        selectableCount++;
        featuresSummary.push({
          id: feature.id,
          label: feature.label || feature.id,
          type: feature.type,
          selectable: true,
        });
      } catch (geomErr: any) {
        unselectableCount++;
        featuresSummary.push({
          id: feature.id,
          label: feature.label || feature.id,
          type: feature.type,
          selectable: false,
          reason: `Failed converting solid to BufferGeometry: ${geomErr.message}`,
        });
      }
    }
  }

  const durationMs = Date.now() - startTime;

  const diagnostics: FeatureSelectionDiagnostics = {
    selectableFeatureCount: selectableCount,
    unselectableFeatureCount: unselectableCount,
    selectionProxyBuildMs: durationMs,
    featureSelectionCacheHit: false,
    totalFeatures: featureModel?.features?.length || 0,
    worldSpaceValidationPassed: worldSpaceValidation.valid,
    worldSpaceViolationCount: worldSpaceValidation.violations.length,
    mispositionedFeatureCount: worldSpaceValidation.invalidFeatureIds.length,
    mispositionedFeatureIds: worldSpaceValidation.invalidFeatureIds,
    featuresSummary,
  };

  return {
    finalGeometry: finalGeom,
    featureGeometries,
    diagnostics,
  };
}

/**
 * Retrieves cached feature selection geometries or executes them if not cached.
 */
export function getOrComputeFeatureSelection(
  versionId: string | undefined,
  code: string,
  featureModel?: SemanticFeatureModel,
  scaleFactor: number = 1.0
): FeatureSelectionResult {
  const key = computeCacheKey(versionId, code, featureModel, scaleFactor);
  const cached = selectionCache.get(key);

  if (cached) {
    return {
      ...cached.result,
      diagnostics: {
        ...cached.result.diagnostics,
        featureSelectionCacheHit: true,
      },
    };
  }

  const result = executeSemanticFeatureGeometries(code, featureModel, {
    scaleFactor,
    versionId,
  });

  // Manage cache capacity
  if (selectionCache.size >= MAX_CACHE_ENTRIES) {
    const oldestKey = selectionCache.keys().next().value;
    if (oldestKey) selectionCache.delete(oldestKey);
  }

  selectionCache.set(key, {
    cacheKey: key,
    result,
    timestamp: Date.now(),
  });

  return result;
}

// ---------------------------------------------------------------------------
// Selection Priority & Candidate Ranking Rules
// ---------------------------------------------------------------------------

/**
 * Returns a priority score for feature selection.
 * Higher score = higher priority when raycaster hits multiple intersecting proxies.
 *
 * Specific subtractive cutter (hole, slot, pocket) > Specific additive feature (rib, boss) > Pattern > Base body
 */
export function getFeatureSelectionPriority(
  type: FeatureType,
  geometryOperation: GeometryOperation,
  volumeMm3: number = 1000
): number {
  // 1. Subtractive features inside openings have highest priority (scores 1000-1500)
  if (
    [
      'HOLE',
      'COUNTERSINK',
      'COUNTERBORE',
      'THREADED_HOLE',
      'SLOT',
      'CHANNEL',
      'CUTOUT',
      'CABLE_OPENING',
      'DRAINAGE_HOLE',
      'DRAINAGE_SLOT',
      'VENT',
      'CAVITY',
      'POCKET',
    ].includes(type) ||
    geometryOperation === 'subtract'
  ) {
    // Smaller hole / slot gets even higher priority (e.g. M3 hole over large cavity)
    return 1500 - Math.min(400, Math.log10(Math.max(1, volumeMm3)) * 50);
  }

  // 2. Specific mechanical & structural details (scores 500-900)
  if (
    [
      'RIB',
      'GUSSET',
      'BOSS',
      'STANDOFF',
      'LIP',
      'FLANGE',
      'HOOK',
      'CLIP',
      'TAB',
      'SNAP_FIT',
      'RAIL',
      'CRADLE',
      'SUPPORT',
      'FOOT',
      'HINGE',
      'DOVETAIL',
      'TEXT',
      'FILLET',
      'CHAMFER',
    ].includes(type)
  ) {
    return 900 - Math.min(300, Math.log10(Math.max(1, volumeMm3)) * 40);
  }

  // 3. Pattern features (scores 300-400)
  if (type === 'PATTERN_LINEAR' || type === 'PATTERN_CIRCULAR' || geometryOperation === 'pattern') {
    return 350;
  }

  // 4. Base body / general shells / plates have lowest priority so they don't steal clicks (scores 10-100)
  if (['BASE_BODY', 'PLATE', 'SHELL', 'WALL'].includes(type) || geometryOperation === 'base') {
    return 50;
  }

  return 200;
}

export interface IntersectionCandidate {
  featureId: string;
  featureType: FeatureType;
  label: string;
  geometryOperation: GeometryOperation;
  distance: number;
  priority: number;
  volumeMm3: number;
  point: THREE.Vector3;
}

/**
 * Filters and ranks intersected feature proxies.
 * Returns best candidate and all candidate options if ambiguous.
 */
export function rankSelectionIntersections(
  intersects: Array<{
    object: THREE.Object3D;
    distance: number;
    point: THREE.Vector3;
  }>,
  featureMap: Map<string, FeatureSelectionGeometry>
): {
  primaryFeatureId: string | null;
  candidates: IntersectionCandidate[];
} {
  if (!intersects || intersects.length === 0) {
    return { primaryFeatureId: null, candidates: [] };
  }

  const candidateMap = new Map<string, IntersectionCandidate>();

  for (const hit of intersects) {
    const featureId = (hit.object as any).userData?.semanticFeatureId;
    if (!featureId) continue;

    const featureData = featureMap.get(featureId);
    if (!featureData || !featureData.selectable) continue;

    const priority = getFeatureSelectionPriority(
      featureData.featureType,
      featureData.geometryOperation,
      featureData.volumeMm3
    );

    if (!candidateMap.has(featureId)) {
      candidateMap.set(featureId, {
        featureId,
        featureType: featureData.featureType,
        label: featureData.label,
        geometryOperation: featureData.geometryOperation,
        distance: hit.distance,
        priority,
        volumeMm3: featureData.volumeMm3,
        point: hit.point,
      });
    } else {
      const existing = candidateMap.get(featureId)!;
      if (hit.distance < existing.distance) {
        existing.distance = hit.distance;
        existing.point = hit.point;
      }
    }
  }

  const candidateList = Array.from(candidateMap.values());
  if (candidateList.length === 0) {
    return { primaryFeatureId: null, candidates: [] };
  }

  // Sort by Priority (descending), then Volume (ascending - smaller specific features first), then Distance (ascending)
  candidateList.sort((a, b) => {
    // If priority difference is significant (> 100), high priority wins
    const prioDiff = b.priority - a.priority;
    if (Math.abs(prioDiff) > 100) return prioDiff;

    // Subtractive features always beat base bodies
    const aSub = a.geometryOperation === 'subtract';
    const bSub = b.geometryOperation === 'subtract';
    if (aSub && !bSub) return -1;
    if (!aSub && bSub) return 1;

    // If both are specific features, prefer smaller volume
    const volDiff = a.volumeMm3 - b.volumeMm3;
    if (Math.abs(volDiff) > 50) return volDiff;

    // Closer to camera
    return a.distance - b.distance;
  });

  return {
    primaryFeatureId: candidateList[0]?.featureId || null,
    candidates: candidateList,
  };
}
