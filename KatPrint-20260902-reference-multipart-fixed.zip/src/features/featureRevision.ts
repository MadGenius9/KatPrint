import {
  SemanticFeatureModel,
  SemanticFeature,
  SemanticRevisionOperation,
  FeatureParameter,
  FeatureType,
} from './featureTypes';
import {
  updateParameterValue,
  adjustNumericParameter,
  createFeatureParameter,
  canModifyParameter,
  isExplicitParameterOverride,
} from './featureParameters';
import { updateJscadConstants } from './featureCodeBindings';
import { createFeatureRelationship } from './featureRelationships';

export interface SemanticRevisionResolution {
  wasDirectlyResolved: boolean;
  operation: SemanticRevisionOperation;
  updatedModel: SemanticFeatureModel;
  updatedCadCode?: string;
  explanation: string;
}

/**
 * Resolves natural language revision instructions against a SemanticFeatureModel.
 * Supports contextual references to 3D selected features ("this", "that", "these", "those", "them", "it").
 */
export function resolveSemanticRevision(
  model: SemanticFeatureModel,
  instruction: string,
  currentCadCode: string,
  selectedFeatureIds?: string[]
): SemanticRevisionResolution {
  const lower = instruction.toLowerCase().trim();
  const hasSelection = Array.isArray(selectedFeatureIds) && selectedFeatureIds.length > 0;
  const selectedFeatures = hasSelection
    ? model.features.filter((f) => selectedFeatureIds.includes(f.id))
    : [];

  const usesSingleDeictic =
    /\b(this|that|it|the selected|this feature|that feature|selected item)\b/i.test(instruction);
  const usesPluralDeictic =
    /\b(these|those|them|both|all of these|selected features|these features|selected items)\b/i.test(instruction);
  const usesDeictic = usesSingleDeictic || usesPluralDeictic;

  // 1. MATCH EXPLICIT FEATURES BY NAME / ALIAS / TYPE IN TEXT
  const explicitlyMentionedFeatures: SemanticFeature[] = [];
  for (const feature of model.features) {
    const featureIdNorm = feature.id.toLowerCase().replace(/_/g, ' ');
    const labelNorm = feature.label.toLowerCase();
    const typeNorm = feature.type.toLowerCase().replace(/_/g, ' ');

    let hit = lower.includes(featureIdNorm) || lower.includes(labelNorm);
    if (!hit && feature.aliases) {
      for (const alias of feature.aliases) {
        if (lower.includes(alias.toLowerCase())) {
          hit = true;
          break;
        }
      }
    }
    // Specific domain keywords for feature types (e.g. "mounting hole", "support rib", "cable slot")
    if (!hit) {
      if (lower.includes('countersink') && (feature.type === 'COUNTERSINK' || feature.id.includes('countersink'))) hit = true;
      else if (lower.includes('counterbore') && (feature.type === 'COUNTERBORE' || feature.id.includes('counterbore'))) hit = true;
      else if (lower.includes('rib') && (feature.type === 'RIB' || feature.id.includes('rib'))) hit = true;
      else if (lower.includes('gusset') && (feature.type === 'GUSSET' || feature.id.includes('gusset'))) hit = true;
      else if (lower.includes('lip') && (feature.type === 'LIP' || feature.id.includes('lip'))) hit = true;
      else if (lower.includes('slot') && (feature.type === 'SLOT' || feature.id.includes('slot'))) hit = true;
      else if (lower.includes('cable') && (feature.type === 'CABLE_OPENING' || feature.id.includes('cable'))) hit = true;
      else if (lower.includes('drainage') && (feature.type === 'DRAINAGE_HOLE' || feature.type === 'DRAINAGE_SLOT' || feature.id.includes('drainage'))) hit = true;
    }

    if (hit) {
      explicitlyMentionedFeatures.push(feature);
    }
  }

  // 2. DETERMINE TARGET FEATURES (Prioritization rules)
  // Rule 1: If text explicitly names feature(s) and does NOT use deictic pointer ("this", "that"), explicit text wins.
  // Rule 2: If user uses deictic pointer ("this", "that", "these", "selected"), 3D selection wins.
  // Rule 3: If user text is generic/ambiguous and 3D selection exists, 3D selection wins.
  const targetFeatures: SemanticFeature[] = [];
  if (usesDeictic && hasSelection) {
    targetFeatures.push(...selectedFeatures);
  } else if (explicitlyMentionedFeatures.length > 0) {
    targetFeatures.push(...explicitlyMentionedFeatures);
  } else if (hasSelection) {
    targetFeatures.push(...selectedFeatures);
  }

  const matchedFeatures = targetFeatures;

  // Check specific intent patterns

  // PATTERN A: HOLE SPACING / MOVE HOLES OUTWARD / INWARD (with selection or keyword)
  const isSpacingOrMoveApart =
    lower.includes('outward') ||
    lower.includes('inward') ||
    lower.includes('apart') ||
    lower.includes('spacing') ||
    lower.includes('farther');

  const refersToHoles =
    lower.includes('hole') ||
    lower.includes('holes') ||
    lower.includes('mounting') ||
    (hasSelection && selectedFeatures.some((f) => f.type === 'HOLE' || f.type === 'COUNTERSINK' || f.type === 'COUNTERBORE'));

  if (isSpacingOrMoveApart && refersToHoles) {
    const deltaMatch = lower.match(/([+-]?\d+(?:\.\d+)?)\s*(?:mm)?/);
    const deltaVal = deltaMatch ? parseFloat(deltaMatch[1]) : 5.0;
    const isOutward = lower.includes('outward') || lower.includes('apart') || lower.includes('farther');
    const actualDelta = isOutward ? deltaVal : -deltaVal;

    // Use selected holes if provided, otherwise find holes in model
    const leftHole =
      (hasSelection && selectedFeatures.find((f) => f.id.includes('left') || f.id.includes('1'))) ||
      (hasSelection && selectedFeatures[0]) ||
      model.features.find((f) => f.id.includes('left') || f.id.includes('1'));

    const rightHole =
      (hasSelection && selectedFeatures.find((f) => f.id.includes('right') || f.id.includes('2') || (leftHole && f.id !== leftHole.id))) ||
      (hasSelection && selectedFeatures[1]) ||
      model.features.find((f) => f.id.includes('right') || f.id.includes('2'));

    const spacingParam = model.parameters.find(
      (p) => p.semanticName.includes('spacing') || p.id.includes('spacing')
    );

    let currentModel = model;
    const paramChanges = [];
    const constantUpdates: { constantName: string; newValue: number }[] = [];

    if (spacingParam && typeof spacingParam.value === 'number') {
      const isAllowed = canModifyParameter(spacingParam, instruction);
      const isOverride = spacingParam.locked && isAllowed;
      if (isAllowed) {
        const newSpacing = Math.max(5, spacingParam.value + actualDelta * 2);
        const res = updateParameterValue(currentModel, spacingParam.id, newSpacing);
        currentModel = res.updatedModel;
        if (res.change) paramChanges.push({ ...res.change, lockOverride: isOverride });
        if (spacingParam.jscadConstantName) {
          constantUpdates.push({ constantName: spacingParam.jscadConstantName, newValue: newSpacing });
        }
      }
    }

    // Also adjust individual positions if present
    const leftParam = model.parameters.find(
      (p) => p.featureId === leftHole?.id && (p.name === 'positionX' || p.name === 'x' || p.semanticName.includes('pos_x'))
    );
    const rightParam = model.parameters.find(
      (p) => p.featureId === rightHole?.id && (p.name === 'positionX' || p.name === 'x' || p.semanticName.includes('pos_x'))
    );

    if (leftParam && typeof leftParam.value === 'number' && canModifyParameter(leftParam, instruction)) {
      const newLeft = leftParam.value - actualDelta;
      const res = updateParameterValue(currentModel, leftParam.id, newLeft);
      currentModel = res.updatedModel;
      if (res.change) paramChanges.push(res.change);
      if (leftParam.jscadConstantName) {
        constantUpdates.push({ constantName: leftParam.jscadConstantName, newValue: newLeft });
      }
    }

    if (rightParam && typeof rightParam.value === 'number' && canModifyParameter(rightParam, instruction)) {
      const newRight = rightParam.value + actualDelta;
      const res = updateParameterValue(currentModel, rightParam.id, newRight);
      currentModel = res.updatedModel;
      if (res.change) paramChanges.push(res.change);
      if (rightParam.jscadConstantName) {
        constantUpdates.push({ constantName: rightParam.jscadConstantName, newValue: newRight });
      }
    }

    const { updatedCode, modifiedCount } = updateJscadConstants(currentCadCode, constantUpdates);

    const affectedIds = [leftHole?.id, rightHole?.id].filter(Boolean) as string[];
    const operation: SemanticRevisionOperation = {
      operation: 'MOVE_FEATURE',
      featureIds: affectedIds.length > 0 ? affectedIds : ['mounting_hole_left', 'mounting_hole_right'],
      parameterChanges: paramChanges,
      reason: `Moved mounting holes ${deltaVal} mm ${isOutward ? 'outward (increased spacing)' : 'inward (decreased spacing)'}.`,
      confidence: 0.95,
    };

    if (modifiedCount > 0 || paramChanges.length > 0) {
      return {
        wasDirectlyResolved: modifiedCount > 0,
        operation,
        updatedModel: currentModel,
        updatedCadCode: modifiedCount > 0 ? updatedCode : undefined,
        explanation: `Moved mounting holes ${deltaVal} mm ${isOutward ? 'farther apart' : 'closer together'}.`,
      };
    }
  }

  // PATTERN B: CABLE OPENING / SLOT WIDTH OR DEPTH (or selected slot)
  const isWidthChange =
    lower.includes('wider') ||
    lower.includes('narrower') ||
    lower.includes('larger') ||
    lower.includes('bigger') ||
    lower.includes('width');

  const refersToSlot =
    lower.includes('cable') ||
    lower.includes('slot') ||
    lower.includes('opening') ||
    lower.includes('charger') ||
    (hasSelection && selectedFeatures.some((f) => f.type === 'SLOT' || f.type === 'CABLE_OPENING' || f.type === 'CUTOUT'));

  if (isWidthChange && (refersToSlot || (hasSelection && selectedFeatures.length === 1))) {
    const deltaMatch = lower.match(/([+-]?\d+(?:\.\d+)?)\s*(?:mm)?/);
    const deltaVal = deltaMatch ? parseFloat(deltaMatch[1]) : 4.0;
    const isWider = lower.includes('wider') || lower.includes('larger') || lower.includes('bigger');
    const actualDelta = isWider ? deltaVal : -deltaVal;

    const slotFeature =
      (hasSelection && selectedFeatures.find((f) => f.type === 'CABLE_OPENING' || f.type === 'SLOT' || f.type === 'CUTOUT')) ||
      (hasSelection && selectedFeatures[0]) ||
      model.features.find(
        (f) => f.id.includes('cable') || f.id.includes('slot') || f.type === 'CABLE_OPENING' || f.type === 'SLOT'
      );

    if (slotFeature) {
      const widthParam = model.parameters.find(
        (p) =>
          p.featureId === slotFeature.id &&
          (p.name.toLowerCase().includes('width') ||
            p.semanticName.toLowerCase().includes('width') ||
            p.name.toLowerCase().includes('diameter') ||
            p.name.toLowerCase().includes('size'))
      );

      if (widthParam && typeof widthParam.value === 'number' && canModifyParameter(widthParam, instruction)) {
        const newWidth = Math.max(2, widthParam.value + actualDelta);
        const { updatedModel, change } = updateParameterValue(model, widthParam.id, newWidth);
        const constantUpdates = widthParam.jscadConstantName
          ? [{ constantName: widthParam.jscadConstantName, newValue: newWidth }]
          : [];

        const { updatedCode, modifiedCount } = updateJscadConstants(currentCadCode, constantUpdates);

        const operation: SemanticRevisionOperation = {
          operation: 'RESIZE_FEATURE',
          featureIds: [slotFeature.id],
          parameterChanges: change ? [change] : [],
          reason: `Adjusted ${slotFeature.label} width by ${actualDelta > 0 ? '+' : ''}${actualDelta} mm.`,
          confidence: 0.95,
        };

        return {
          wasDirectlyResolved: modifiedCount > 0,
          operation,
          updatedModel,
          updatedCadCode: modifiedCount > 0 ? updatedCode : undefined,
          explanation: `Updated ${slotFeature.label} width from ${widthParam.value} mm to ${newWidth} mm.`,
        };
      }
    }
  }

  // PATTERN C: DIRECT DIAMETER / SIZE EDIT ON SELECTED OR TARGET FEATURES
  const diaMatch = lower.match(/(?:diameter|dia|size|radius|hole)\s*(?:to\s*|=\s*|\s+is\s+)?([+-]?\d+(?:\.\d+)?)\s*(?:mm)?/);
  if (diaMatch && matchedFeatures.length > 0) {
    const targetVal = parseFloat(diaMatch[1]);
    let currentModel = model;
    const paramChanges = [];
    const constantUpdates: { constantName: string; newValue: number }[] = [];
    const affectedFeatureIds: string[] = [];

    for (const targetFeat of matchedFeatures) {
      const diaParam = currentModel.parameters.find(
        (p) =>
          p.featureId === targetFeat.id &&
          (p.name.toLowerCase().includes('dia') ||
            p.name.toLowerCase().includes('radius') ||
            p.name.toLowerCase().includes('size') ||
            p.semanticName.toLowerCase().includes('dia'))
      );

      if (diaParam && typeof diaParam.value === 'number' && canModifyParameter(diaParam, instruction)) {
        const { updatedModel, change } = updateParameterValue(currentModel, diaParam.id, targetVal);
        currentModel = updatedModel;
        if (change) paramChanges.push(change);
        affectedFeatureIds.push(targetFeat.id);
        if (diaParam.jscadConstantName) {
          constantUpdates.push({ constantName: diaParam.jscadConstantName, newValue: targetVal });
        }
      }
    }

    if (affectedFeatureIds.length > 0) {
      const { updatedCode, modifiedCount } = updateJscadConstants(currentCadCode, constantUpdates);

      const operation: SemanticRevisionOperation = {
        operation: 'SET_PARAMETER',
        featureIds: affectedFeatureIds,
        parameterChanges: paramChanges,
        reason: `Directly updated diameter for ${affectedFeatureIds.length} feature(s) to ${targetVal} mm.`,
        confidence: 0.95,
      };

      const labels = matchedFeatures
        .filter((f) => affectedFeatureIds.includes(f.id))
        .map((f) => f.label)
        .join(', ');

      return {
        wasDirectlyResolved: modifiedCount > 0,
        operation,
        updatedModel: currentModel,
        updatedCadCode: modifiedCount > 0 ? updatedCode : undefined,
        explanation: `Changed diameter of ${labels} to ${targetVal} mm.`,
      };
    }
  }

  // PATTERN C: WALL THICKNESS
  if (lower.includes('wall') && (lower.includes('thicker') || lower.includes('thinner') || lower.includes('thickness'))) {
    const deltaMatch = lower.match(/([+-]?\d+(?:\.\d+)?)\s*(?:mm)?/);
    const deltaVal = deltaMatch ? parseFloat(deltaMatch[1]) : 1.0;
    const isThicker = lower.includes('thicker');
    const actualDelta = isThicker ? deltaVal : -deltaVal;

    const wallParam = model.parameters.find(
      (p) => p.name.toLowerCase().includes('wall') || p.semanticName.toLowerCase().includes('wall_thickness') || p.name === 'thickness'
    );

    if (wallParam && typeof wallParam.value === 'number' && canModifyParameter(wallParam, instruction)) {
      const newThickness = Math.max(1.5, wallParam.value + actualDelta);
      const { updatedModel, change } = updateParameterValue(model, wallParam.id, newThickness);
      const constantUpdates = wallParam.jscadConstantName
        ? [{ constantName: wallParam.jscadConstantName, newValue: newThickness }]
        : [];
      const { updatedCode, modifiedCount } = updateJscadConstants(currentCadCode, constantUpdates);

      const operation: SemanticRevisionOperation = {
        operation: 'SET_PARAMETER',
        featureIds: [wallParam.featureId],
        parameterChanges: change ? [change] : [],
        reason: `Changed wall thickness by ${actualDelta > 0 ? '+' : ''}${actualDelta} mm to ${newThickness} mm.`,
        confidence: 0.95,
      };

      return {
        wasDirectlyResolved: modifiedCount > 0,
        operation,
        updatedModel,
        updatedCadCode: modifiedCount > 0 ? updatedCode : undefined,
        explanation: `Adjusted wall thickness from ${wallParam.value} mm to ${newThickness} mm.`,
      };
    }
  }

  // PATTERN D: REMOVE FEATURE (e.g. "Remove the rear support rib")
  if (lower.startsWith('remove') || lower.includes('delete') || lower.includes('get rid of')) {
    const targetFeature = matchedFeatures[0] || model.features.find((f) => {
      if (lower.includes('rib') && (f.type === 'RIB' || f.id.includes('rib'))) return true;
      if (lower.includes('slot') && (f.type === 'SLOT' || f.id.includes('slot') || f.id.includes('cable'))) return true;
      if (lower.includes('lip') && (f.type === 'LIP' || f.id.includes('lip'))) return true;
      return false;
    });

    if (targetFeature) {
      const newFeatures = model.features.filter((f) => f.id !== targetFeature.id);
      const newParams = model.parameters.filter((p) => p.featureId !== targetFeature.id);
      const newRels = model.relationships.filter(
        (r) => r.sourceFeatureId !== targetFeature.id && r.targetFeatureId !== targetFeature.id
      );

      const updatedModel: SemanticFeatureModel = {
        ...model,
        features: newFeatures,
        parameters: newParams,
        relationships: newRels,
      };

      const operation: SemanticRevisionOperation = {
        operation: 'REMOVE_FEATURE',
        featureIds: [targetFeature.id],
        removedFeatureIds: [targetFeature.id],
        reason: `Removed feature ${targetFeature.label} (${targetFeature.id}) per user instruction.`,
        confidence: 0.9,
      };

      return {
        wasDirectlyResolved: false, // Needs CAD regeneration to cleanly remove geometry
        operation,
        updatedModel,
        explanation: `Removed feature "${targetFeature.label}" from design plan.`,
      };
    }
  }

  // PATTERN E: ADD FEATURE (e.g. "Add two countersunk screw holes")
  if (lower.startsWith('add') || lower.includes('create') || lower.includes('include')) {
    let addedType: FeatureType = 'HOLE';
    let label = 'New Feature';
    let featId = `feat_${Date.now()}`;

    if (lower.includes('countersink') || lower.includes('countersunk')) {
      addedType = 'COUNTERSINK';
      label = 'Countersunk Hole';
      featId = `mounting_hole_${model.features.filter((f) => f.type === 'COUNTERSINK').length + 1}`;
    } else if (lower.includes('hole')) {
      addedType = 'HOLE';
      label = 'Mounting Hole';
      featId = `mounting_hole_${model.features.filter((f) => f.type === 'HOLE').length + 1}`;
    } else if (lower.includes('rib') || lower.includes('gusset')) {
      addedType = 'RIB';
      label = 'Reinforcing Rib';
      featId = `support_rib_${model.features.filter((f) => f.type === 'RIB').length + 1}`;
    } else if (lower.includes('slot') || lower.includes('opening')) {
      addedType = 'SLOT';
      label = 'Clearance Slot';
      featId = `slot_${model.features.filter((f) => f.type === 'SLOT').length + 1}`;
    }

    const newFeature: SemanticFeature = {
      id: featId,
      type: addedType,
      label,
      purpose: `User requested feature: ${instruction}`,
      parameters: { size: 5 },
      parameterIds: [`${featId}_size`],
      source: 'revision',
      criticality: 'important',
      geometryOperation: addedType === 'RIB' ? 'add' : 'subtract',
      status: 'planned',
    };

    const newParam = createFeatureParameter({
      id: `${featId}_size`,
      featureId: newFeature.id,
      name: 'size',
      semanticName: `${featId}_size`,
      value: 5,
      unit: 'mm',
      source: 'revision',
    });

    const newRel = createFeatureRelationship({
      sourceFeatureId: newFeature.id,
      targetFeatureId: model.baseFeatureId,
      relationshipType: addedType === 'RIB' ? 'attached_to' : 'subtracts_from',
      description: `New feature added to base ${model.baseFeatureId}`,
    });

    const updatedModel: SemanticFeatureModel = {
      ...model,
      features: [...model.features, newFeature],
      parameters: [...model.parameters, newParam],
      relationships: [...model.relationships, newRel],
    };

    const operation: SemanticRevisionOperation = {
      operation: 'ADD_FEATURE',
      featureIds: [newFeature.id],
      addedFeatures: [newFeature],
      reason: `Added new ${addedType} feature "${label}".`,
      confidence: 0.9,
    };

    return {
      wasDirectlyResolved: false,
      operation,
      updatedModel,
      explanation: `Added new ${addedType} feature "${label}" to design plan.`,
    };
  }

  // FALLBACK: GENERAL PARAMETER / DIMENSION ADJUSTMENT
  const dimMatch = lower.match(/(?:make|set|change)?\s*(?:the\s+)?([a-z_]+)\s*(?:to\s*|=\s*|\s+is\s+)?([+-]?\d+(?:\.\d+)?)\s*(?:mm)?/);
  if (dimMatch) {
    const targetName = dimMatch[1];
    const targetValue = parseFloat(dimMatch[2]);

    const targetParam = model.parameters.find(
      (p) =>
        p.name.toLowerCase() === targetName.toLowerCase() ||
        p.semanticName.toLowerCase().includes(targetName.toLowerCase()) ||
        p.id.toLowerCase().includes(targetName.toLowerCase())
    );

    if (targetParam && !isNaN(targetValue) && canModifyParameter(targetParam, instruction)) {
      const { updatedModel, change } = updateParameterValue(model, targetParam.id, targetValue);
      const constantUpdates = targetParam.jscadConstantName
        ? [{ constantName: targetParam.jscadConstantName, newValue: targetValue }]
        : [];
      const { updatedCode, modifiedCount } = updateJscadConstants(currentCadCode, constantUpdates);

      const operation: SemanticRevisionOperation = {
        operation: 'SET_PARAMETER',
        featureIds: [targetParam.featureId],
        parameterChanges: change ? [change] : [],
        reason: `Directly updated parameter ${targetParam.semanticName} to ${targetValue}.`,
        confidence: 0.9,
      };

      return {
        wasDirectlyResolved: modifiedCount > 0,
        operation,
        updatedModel,
        updatedCadCode: modifiedCount > 0 ? updatedCode : undefined,
        explanation: `Set ${targetParam.semanticName} to ${targetValue} mm.`,
      };
    }
  }

  // Fallback: Full semantic revision needed via LLM
  return {
    wasDirectlyResolved: false,
    operation: {
      operation: 'REPLACE_FEATURE',
      featureIds: matchedFeatures.map((f) => f.id),
      reason: instruction,
      confidence: 0.7,
    },
    updatedModel: model,
    explanation: `Feature model prepared for conversational revision: "${instruction}".`,
  };
}
