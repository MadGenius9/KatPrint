import {
  FeatureParameter,
  SemanticFeature,
  SemanticFeatureModel,
  ParameterChange,
} from './featureTypes';

/**
 * Converts a snake_case or kebab-case parameter ID to a camelCase JSCAD constant identifier.
 */
export function toJscadConstantName(name: string): string {
  return name
    .replace(/[-_]([a-z0-9])/gi, (_, letter) => letter.toUpperCase())
    .replace(/[^a-zA-Z0-9]/g, '');
}

/**
 * Creates a standard FeatureParameter object
 */
export function createFeatureParameter(params: {
  id: string;
  featureId: string;
  name: string;
  semanticName: string;
  value: number | string | boolean;
  unit?: 'mm' | 'deg' | 'count' | 'boolean' | 'ratio';
  min?: number;
  max?: number;
  step?: number;
  source?: 'explicit' | 'inferred' | 'reference' | 'default' | 'revision';
  locked?: boolean;
  critical?: boolean;
  description?: string;
}): FeatureParameter {
  const jscadConstantName = toJscadConstantName(params.semanticName || params.name);
  return {
    id: params.id,
    featureId: params.featureId,
    name: params.name,
    semanticName: params.semanticName || params.name,
    value: params.value,
    unit: params.unit || 'mm',
    min: params.min,
    max: params.max,
    step: params.step ?? (typeof params.value === 'number' ? (params.value < 5 ? 0.1 : 0.5) : undefined),
    source: params.source || 'default',
    locked: params.locked || false,
    critical: params.critical || false,
    description: params.description,
    jscadConstantName,
  };
}

/**
 * Finds a parameter by semantic name or id in a feature model
 */
export function findParameter(
  model: SemanticFeatureModel,
  predicate: (param: FeatureParameter) => boolean
): FeatureParameter | undefined {
  return model.parameters.find(predicate);
}

/**
 * Updates a parameter value in the model and returns a cloned model with the update and diff record.
 */
export function updateParameterValue(
  model: SemanticFeatureModel,
  parameterId: string,
  newValue: number | string | boolean
): { updatedModel: SemanticFeatureModel; change: ParameterChange | null } {
  const paramIndex = model.parameters.findIndex((p) => p.id === parameterId);
  if (paramIndex === -1) {
    return { updatedModel: model, change: null };
  }

  const oldParam = model.parameters[paramIndex];
  const oldValue = oldParam.value;
  const delta =
    typeof oldValue === 'number' && typeof newValue === 'number'
      ? newValue - oldValue
      : undefined;

  const updatedParam: FeatureParameter = {
    ...oldParam,
    value: newValue,
    source: 'revision',
  };

  const newParameters = [...model.parameters];
  newParameters[paramIndex] = updatedParam;

  // Also update in the parent feature's parameters dictionary
  const newFeatures = model.features.map((feature) => {
    if (feature.id === oldParam.featureId) {
      return {
        ...feature,
        parameters: {
          ...feature.parameters,
          [oldParam.name]: newValue,
        },
      };
    }
    return feature;
  });

  const change: ParameterChange = {
    parameterId: oldParam.id,
    featureId: oldParam.featureId,
    paramName: oldParam.semanticName,
    oldValue,
    newValue,
    delta,
    unit: oldParam.unit,
  };

  const updatedModel: SemanticFeatureModel = {
    ...model,
    features: newFeatures,
    parameters: newParameters,
  };

  return { updatedModel, change };
}

/**
 * Applies relative mathematical adjustment to a parameter (e.g. delta = +5, or multiplier = 1.5)
 */
export function adjustNumericParameter(
  model: SemanticFeatureModel,
  parameterId: string,
  options: { delta?: number; multiplier?: number; absolute?: number }
): { updatedModel: SemanticFeatureModel; change: ParameterChange | null } {
  const param = model.parameters.find((p) => p.id === parameterId);
  if (!param || typeof param.value !== 'number') {
    return { updatedModel: model, change: null };
  }

  let nextValue = param.value;
  if (options.absolute !== undefined) {
    nextValue = options.absolute;
  } else if (options.multiplier !== undefined) {
    nextValue = param.value * options.multiplier;
  } else if (options.delta !== undefined) {
    nextValue = param.value + options.delta;
  }

  if (param.min !== undefined && nextValue < param.min) nextValue = param.min;
  if (param.max !== undefined && nextValue > param.max) nextValue = param.max;

  // Round to reasonable decimal precision
  nextValue = Math.round(nextValue * 100) / 100;

  return updateParameterValue(model, parameterId, nextValue);
}

/**
 * Determines whether a parameter can be modified given its lock status and optional user instruction.
 * A locked parameter can ONLY be modified if:
 * 1. The instruction specifically identifies that parameter or feature (e.g. paramName, semanticName, jscadConstantName, or featureId)
 *    AND contains a direct modification action (e.g. 'change', 'set', 'make', 'move', 'resize', 'increase', 'decrease', 'thicken', 'thin', 'widen', 'narrow')
 *    OR contains an explicit unlock directive ('unlock', 'force', 'override', 'ignore lock').
 * 2. Generic requests ("Make the box larger", "Make everything wider") preserve locked parameters.
 */
export function isExplicitParameterOverride(param: FeatureParameter, instruction?: string): boolean {
  if (!param.locked) return true;
  if (!instruction) return false;

  const lower = instruction.toLowerCase();

  // Specifically identify this parameter or feature
  const paramName = (param.name || '').toLowerCase().replace(/_/g, ' ').trim();
  const jscadName = (param.jscadConstantName || '').toLowerCase().replace(/_/g, ' ').trim();
  const semanticName = (param.semanticName || '').toLowerCase().replace(/_/g, ' ').trim();
  const featureId = (param.featureId || '').toLowerCase().replace(/_/g, ' ').trim();

  const isIdentified =
    (paramName.length > 2 && lower.includes(paramName)) ||
    (jscadName.length > 2 && lower.includes(jscadName)) ||
    (semanticName.length > 2 && lower.includes(semanticName)) ||
    (featureId.length > 2 && lower.includes(featureId));

  if (!isIdentified) {
    // If not specifically identified, allow only if explicit "unlock all" / "override all" intent
    const hasGlobalUnlockIntent =
      lower.includes('unlock all') ||
      lower.includes('force all') ||
      lower.includes('override all');
    return hasGlobalUnlockIntent;
  }

  // Parameter/feature is specifically identified. Check for direct action or unlock intent:
  const hasDirectAction =
    /\b(change|set|make|move|resize|increase|decrease|thicken|thin|widen|narrow|adjust|modify|update|scale|expand|shrink|raise|lower)\b/i.test(lower);

  const hasUnlockIntent =
    lower.includes('unlock') ||
    lower.includes('force') ||
    lower.includes('override') ||
    lower.includes('ignore lock') ||
    lower.includes('unlocked');

  return hasDirectAction || hasUnlockIntent;
}

export function canModifyParameter(param: FeatureParameter, instruction?: string): boolean {
  if (!param.locked) return true;
  return isExplicitParameterOverride(param, instruction);
}

/**
 * Sets lock status on a parameter
 */
export function setParameterLock(
  model: SemanticFeatureModel,
  parameterId: string,
  locked: boolean
): SemanticFeatureModel {
  return {
    ...model,
    parameters: model.parameters.map((p) =>
      p.id === parameterId ? { ...p, locked } : p
    ),
  };
}

/**
 * Toggles lock status on a parameter
 */
export function toggleParameterLock(
  model: SemanticFeatureModel,
  parameterId: string,
  locked?: boolean
): SemanticFeatureModel {
  const target = model.parameters.find((p) => p.id === parameterId);
  const nextLock = locked !== undefined ? locked : !target?.locked;
  return setParameterLock(model, parameterId, nextLock);
}

