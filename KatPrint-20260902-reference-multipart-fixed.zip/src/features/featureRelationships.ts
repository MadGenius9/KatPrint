import {
  FeatureRelationship,
  RelationshipType,
  SemanticFeature,
} from './featureTypes';

export function createFeatureRelationship(params: {
  id?: string;
  sourceFeatureId: string;
  targetFeatureId: string;
  relationshipType: RelationshipType;
  description?: string;
  parameters?: Record<string, any>;
}): FeatureRelationship {
  return {
    id: params.id || `rel_${params.sourceFeatureId}_${params.relationshipType}_${params.targetFeatureId}`,
    sourceFeatureId: params.sourceFeatureId,
    targetFeatureId: params.targetFeatureId,
    relationshipType: params.relationshipType,
    description: params.description,
    parameters: params.parameters,
  };
}

export function findRelationshipsForFeature(
  relationships: FeatureRelationship[],
  featureId: string
): { incoming: FeatureRelationship[]; outgoing: FeatureRelationship[] } {
  const outgoing = relationships.filter((r) => r.sourceFeatureId === featureId);
  const incoming = relationships.filter((r) => r.targetFeatureId === featureId);
  return { incoming, outgoing };
}

export function getRelationshipSummary(
  rel: FeatureRelationship,
  features: SemanticFeature[]
): string {
  const source = features.find((f) => f.id === rel.sourceFeatureId)?.label || rel.sourceFeatureId;
  const target = features.find((f) => f.id === rel.targetFeatureId)?.label || rel.targetFeatureId;

  switch (rel.relationshipType) {
    case 'attached_to':
      return `${source} is attached to ${target}`;
    case 'subtracts_from':
      return `${source} cuts into ${target}`;
    case 'reinforces':
      return `${source} reinforces ${target}`;
    case 'aligned_with':
      return `${source} is aligned with ${target}`;
    case 'centered_on':
      return `${source} is centered on ${target}`;
    case 'mirrored_from':
      return `${source} is mirrored from ${target}`;
    case 'patterned_from':
      return `${source} is patterned from ${target}`;
    case 'inside':
      return `${source} sits inside ${target}`;
    case 'outside':
      return `${source} sits outside ${target}`;
    case 'above':
      return `${source} sits above ${target}`;
    case 'below':
      return `${source} sits below ${target}`;
    case 'references':
      return `${source} references ${target}`;
    case 'fits':
      return `${source} fits ${target}`;
    case 'supports':
      return `${source} supports ${target}`;
    default:
      return `${source} -> ${target} (${rel.relationshipType})`;
  }
}
