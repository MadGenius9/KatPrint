import { FeatureType, SemanticFeature } from './featureTypes';

/**
 * Standard deterministic parametric JSCAD feature generators.
 * Provides helper code snippets and geometric generators for standard mechanical features.
 */

export const RESERVED_BUILDER_NAMES = [
  'createThroughHole',
  'createCounterboreHole',
  'createCountersinkHole',
  'createElongatedSlot',
  'createCableOpening',
  'createMountingBoss',
  'createReinforcingRib',
  'createCornerGusset',
  'createLinearHolePattern',
  'createCircularHolePattern',
  'createDrainageSlotPattern',
  'createPCBStandoff',
] as const;

export type ReservedBuilderName = (typeof RESERVED_BUILDER_NAMES)[number];

export interface FeatureBuilderSpec {
  builderName: ReservedBuilderName;
  description: string;
  signature: string;
  parameters: string[];
  exampleCall: string;
}

export const FEATURE_BUILDER_REGISTRY: Record<string, FeatureBuilderSpec> = {
  HOLE: {
    builderName: 'createThroughHole',
    description: 'Creates a cylindrical through hole with lead-in depth margin',
    signature: 'createThroughHole(diameter, depth, posX = 0, posY = 0, posZ = 0)',
    parameters: ['diameter', 'depth', 'posX', 'posY', 'posZ'],
    exampleCall: 'createThroughHole(mountingHoleDiameter, plateThickness, holeX, holeY, 0)',
  },
  COUNTERSINK: {
    builderName: 'createCountersinkHole',
    description: 'Creates a standard 90° countersunk screw hole',
    signature: 'createCountersinkHole(holeDiameter, headDiameter, totalDepth, angleDeg = 90, posX = 0, posY = 0, posZ = 0)',
    parameters: ['holeDiameter', 'headDiameter', 'totalDepth', 'angleDeg', 'posX', 'posY', 'posZ'],
    exampleCall: 'createCountersinkHole(screwHoleDiameter, screwHeadDiameter, plateThickness, 90, holeX, holeY, 0)',
  },
  COUNTERBORE: {
    builderName: 'createCounterboreHole',
    description: 'Creates a cylindrical counterbore hole for socket-head cap screws',
    signature: 'createCounterboreHole(holeDiameter, boreDiameter, boreDepth, totalDepth, posX = 0, posY = 0, posZ = 0)',
    parameters: ['holeDiameter', 'boreDiameter', 'boreDepth', 'totalDepth', 'posX', 'posY', 'posZ'],
    exampleCall: 'createCounterboreHole(holeDiameter, counterboreDiameter, counterboreDepth, totalDepth, holeX, holeY, 0)',
  },
  SLOT: {
    builderName: 'createElongatedSlot',
    description: 'Creates an elongated stadium slot with rounded ends',
    signature: 'createElongatedSlot(width, length, depth, posX = 0, posY = 0, posZ = 0, rotateDeg = 0)',
    parameters: ['width', 'length', 'depth', 'posX', 'posY', 'posZ', 'rotateDeg'],
    exampleCall: 'createElongatedSlot(slotWidth, slotLength, plateThickness, slotX, slotY, 0, slotAngle)',
  },
  CABLE_OPENING: {
    builderName: 'createCableOpening',
    description: 'Creates a strain-relief / pass-through opening with radiused corners',
    signature: 'createCableOpening(width, depth, height, posX = 0, posY = 0, posZ = 0)',
    parameters: ['width', 'depth', 'height', 'posX', 'posY', 'posZ'],
    exampleCall: 'createCableOpening(cableSlotWidth, cableSlotDepth, plateThickness, cableSlotX, cableSlotY, 0)',
  },
  BOSS: {
    builderName: 'createMountingBoss',
    description: 'Creates a cylindrical boss / standoff with a pilot hole',
    signature: 'createMountingBoss(outerDiameter, innerDiameter, height, posX = 0, posY = 0, posZ = 0)',
    parameters: ['outerDiameter', 'innerDiameter', 'height', 'posX', 'posY', 'posZ'],
    exampleCall: 'createMountingBoss(bossOuterDiameter, bossInnerDiameter, bossHeight, bossX, bossY, 0)',
  },
  STANDOFF: {
    builderName: 'createPCBStandoff',
    description: 'Creates a PCB mounting standoff with core screw pilot hole',
    signature: 'createPCBStandoff(outerDiameter, pilotDiameter, height, posX = 0, posY = 0, posZ = 0)',
    parameters: ['outerDiameter', 'pilotDiameter', 'height', 'posX', 'posY', 'posZ'],
    exampleCall: 'createPCBStandoff(standoffDiameter, standoffPilotDiameter, standoffHeight, standoffX, standoffY, 0)',
  },
  RIB: {
    builderName: 'createReinforcingRib',
    description: 'Creates a structural reinforcing rib to increase stiffness',
    signature: 'createReinforcingRib(thickness, height, length, posX = 0, posY = 0, posZ = 0, angleDeg = 0)',
    parameters: ['thickness', 'height', 'length', 'posX', 'posY', 'posZ', 'angleDeg'],
    exampleCall: 'createReinforcingRib(ribThickness, ribHeight, ribLength, ribX, ribY, ribZ, ribAngle)',
  },
  GUSSET: {
    builderName: 'createCornerGusset',
    description: 'Creates a 45° triangular corner gusset brace',
    signature: 'createCornerGusset(legSize, thickness, posX = 0, posY = 0, posZ = 0)',
    parameters: ['legSize', 'thickness', 'posX', 'posY', 'posZ'],
    exampleCall: 'createCornerGusset(gussetSize, wallThickness, cornerX, cornerY, 0)',
  },
  PATTERN_LINEAR: {
    builderName: 'createLinearHolePattern',
    description: 'Creates a linear array of through holes along X or Y axis',
    signature: 'createLinearHolePattern(diameter, depth, count, spacing, axis = "x", startOffset = 0, otherPos = 0, posZ = 0)',
    parameters: ['diameter', 'depth', 'count', 'spacing', 'axis', 'startOffset', 'otherPos', 'posZ'],
    exampleCall: 'createLinearHolePattern(holeDiameter, plateThickness, holeCount, holeSpacing, "x", 0, holeY, 0)',
  },
  PATTERN_CIRCULAR: {
    builderName: 'createCircularHolePattern',
    description: 'Creates a circular bolt circle / pattern of through holes',
    signature: 'createCircularHolePattern(diameter, depth, count, pitchRadius, centerPosX = 0, centerPosY = 0, posZ = 0)',
    parameters: ['diameter', 'depth', 'count', 'pitchRadius', 'centerPosX', 'centerPosY', 'posZ'],
    exampleCall: 'createCircularHolePattern(holeDiameter, plateThickness, boltCount, boltCircleRadius, 0, 0, 0)',
  },
  DRAINAGE_SLOT: {
    builderName: 'createDrainageSlotPattern',
    description: 'Creates an array of drainage/ventilation slots',
    signature: 'createDrainageSlotPattern(slotWidth, slotLength, slotDepth, count, spacing, posX = 0, posY = 0, posZ = 0)',
    parameters: ['slotWidth', 'slotLength', 'slotDepth', 'count', 'spacing', 'posX', 'posY', 'posZ'],
    exampleCall: 'createDrainageSlotPattern(slotWidth, slotLength, plateThickness, slotCount, slotSpacing, 0, 0, 0)',
  },
  DRAINAGE_HOLE: {
    builderName: 'createThroughHole',
    description: 'Creates a drainage hole with lead-in depth margin',
    signature: 'createThroughHole(diameter, depth, posX = 0, posY = 0, posZ = 0)',
    parameters: ['diameter', 'depth', 'posX', 'posY', 'posZ'],
    exampleCall: 'createThroughHole(drainageDiameter, plateThickness, drainX, drainY, 0)',
  },
};

/**
 * Validates that generated code does not redefine reserved KatPrint builder functions.
 * Returns null if valid, or an error object if a reserved builder was redefined.
 */
export function validateReservedBuilderUsage(code: string): { code: 'RESERVED_BUILDER_REDEFINITION'; message: string; builderName: string } | null {
  for (const name of RESERVED_BUILDER_NAMES) {
    const funcRegex = new RegExp(`(?:async\\s+)?function\\s+${name}\\s*\\(`, 'm');
    const constRegex = new RegExp(`(?:const|let|var)\\s+${name}\\s*=\\s*(?:\\(|function)`, 'm');
    if (funcRegex.test(code) || constRegex.test(code)) {
      return {
        code: 'RESERVED_BUILDER_REDEFINITION',
        message: `Generated code redefines reserved KatPrint runtime builder '${name}'. Do not declare function or variable '${name}', call it directly.`,
        builderName: name,
      };
    }
  }
  return null;
}

/**
 * Returns the stable executable feature wrapper function name for a semantic feature.
 * Format: kpFeature_<sanitizedFeatureId>
 */
export function getFeatureFunctionName(featureId: string): string {
  const sanitized = featureId.replace(/[^a-zA-Z0-9_]/g, '_');
  return `kpFeature_${sanitized}`;
}

/**
 * Strips any user/AI redefinition of reserved KatPrint builder functions from code.
 */
export function stripBuilderRedefinitions(code: string): string {
  let cleaned = code;
  for (const name of RESERVED_BUILDER_NAMES) {
    // Matches function name(...) { ... } or const name = (...) => { ... }
    const funcRegex = new RegExp(
      `(?:async\\s+)?function\\s+${name}\\s*\\([^)]*\\)\\s*\\{[\\s\\S]*?\\n\\}`,
      'g'
    );
    const constRegex = new RegExp(
      `(?:const|let|var)\\s+${name}\\s*=\\s*\\([^)]*\\)\\s*=>\\s*\\{[\\s\\S]*?\\n\\};?`,
      'g'
    );
    cleaned = cleaned.replace(funcRegex, `/* KatPrint Runtime: ${name} provided by preamble */`);
    cleaned = cleaned.replace(constRegex, `/* KatPrint Runtime: ${name} provided by preamble */`);
  }
  return cleaned;
}

export function getFeatureBuilderForType(type: FeatureType | string): FeatureBuilderSpec | undefined {
  return FEATURE_BUILDER_REGISTRY[type];
}

export function getFeatureBuilderPromptDocs(features?: SemanticFeature[]): string {
  let doc = `KATPRINT VERIFIED DETERMINISTIC FEATURE BUILDERS & EXECUTABLE FEATURE ABI:
The runtime environment provides pre-compiled, mathematically verified builder functions.
DO NOT redefine these functions in your code. Simply call them directly.

Available Deterministic Builders:
1. createThroughHole(diameter, depth, posX = 0, posY = 0, posZ = 0)
2. createCountersinkHole(holeDiameter, headDiameter, totalDepth, angleDeg = 90, posX = 0, posY = 0, posZ = 0)
3. createCounterboreHole(holeDiameter, boreDiameter, boreDepth, totalDepth, posX = 0, posY = 0, posZ = 0)
4. createElongatedSlot(width, length, depth, posX = 0, posY = 0, posZ = 0, rotateDeg = 0)
5. createCableOpening(width, depth, height, posX = 0, posY = 0, posZ = 0)
6. createMountingBoss(outerDiameter, innerDiameter, height, posX = 0, posY = 0, posZ = 0)
7. createPCBStandoff(outerDiameter, pilotDiameter, height, posX = 0, posY = 0, posZ = 0)
8. createReinforcingRib(thickness, height, length, posX = 0, posY = 0, posZ = 0, angleDeg = 0)
9. createCornerGusset(legSize, thickness, posX = 0, posY = 0, posZ = 0)
10. createLinearHolePattern(diameter, depth, count, spacing, axis = 'x', startOffset = 0, otherPos = 0, posZ = 0)
11. createCircularHolePattern(diameter, depth, count, pitchRadius, centerPosX = 0, centerPosY = 0, posZ = 0)
12. createDrainageSlotPattern(slotWidth, slotLength, slotDepth, count, spacing, posX = 0, posY = 0, posZ = 0)

FEATURE WRAPPER FUNCTION CONTRACT:
To make each semantic feature individually editable and verifiable, each feature MUST have its own dedicated function returning its geometry solid, named \`kpFeature_<featureId>()\`.
Inside main(), call each feature function and combine them using booleans.union() or booleans.subtract().

Example Structure:
\`\`\`js
// Parameter Constants
const baseWidth = 100;
const baseDepth = 80;
const baseThickness = 5;
const mountingHoleDiameter = 5;
const mountingHoleSpacing = 60;

function kpFeature_base_plate() {
  return primitives.roundedCuboid({ size: [baseWidth, baseDepth, baseThickness], roundRadius: 3 });
}

function kpFeature_mounting_hole_left() {
  return createThroughHole(mountingHoleDiameter, baseThickness, -mountingHoleSpacing / 2, 0, 0);
}

function kpFeature_mounting_hole_right() {
  return createThroughHole(mountingHoleDiameter, baseThickness, mountingHoleSpacing / 2, 0, 0);
}

function main() {
  const base = kpFeature_base_plate();
  const holeL = kpFeature_mounting_hole_left();
  const holeR = kpFeature_mounting_hole_right();
  return booleans.subtract(base, holeL, holeR);
}
\`\`\`
`;

  if (Array.isArray(features) && features.length > 0) {
    const validFeatures = features.filter((f) => f && typeof f === 'object' && typeof f.id === 'string');
    if (validFeatures.length > 0) {
      doc += `\nREQUIRED FEATURE BUILDER & WRAPPER ASSIGNMENTS FOR THIS MODEL:\n`;
      for (const f of validFeatures) {
        const b = f.type ? FEATURE_BUILDER_REGISTRY[f.type] : undefined;
        const fnName = getFeatureFunctionName(f.id);
        const label = f.label || f.id;
        if (b) {
          doc += `- Feature "${f.id}" (${label}, Type: ${f.type}) -> Declare function \`${fnName}()\` calling \`${b.builderName}(...)\` with its constants.\n`;
        } else {
          doc += `- Feature "${f.id}" (${label}, Type: ${f.type || 'CUSTOM_PARAMETRIC'}) -> Declare function \`${fnName}()\` returning its solid.\n`;
        }
      }
    }
  }

  return doc;
}

export const JSCAD_FEATURE_BUILDER_LIB = `
// ==========================================
// KATPRINT DETERMINISTIC FEATURE BUILDERS
// ==========================================

function createThroughHole(diameter, depth, posX = 0, posY = 0, posZ = 0) {
  const radius = diameter / 2;
  const cylinderGeom = primitives.cylinder({
    radius: radius,
    height: depth + 4,
    segments: Math.max(24, Math.round(diameter * 4))
  });
  return transforms.translate([posX, posY, posZ], cylinderGeom);
}

function createCounterboreHole(holeDiameter, boreDiameter, boreDepth, totalDepth, posX = 0, posY = 0, posZ = 0) {
  const throughHole = primitives.cylinder({
    radius: holeDiameter / 2,
    height: totalDepth + 4,
    segments: 32
  });
  const counterbore = primitives.cylinder({
    radius: boreDiameter / 2,
    height: boreDepth + 1,
    segments: 32
  });
  const shiftedBore = transforms.translate([0, 0, (totalDepth / 2) - (boreDepth / 2) + 0.5], counterbore);
  const combined = booleans.union(throughHole, shiftedBore);
  return transforms.translate([posX, posY, posZ], combined);
}

function createCountersinkHole(holeDiameter, headDiameter, totalDepth, angleDeg = 90, posX = 0, posY = 0, posZ = 0) {
  const throughHole = primitives.cylinder({
    radius: holeDiameter / 2,
    height: totalDepth + 4,
    segments: 32
  });
  const coneHeight = (headDiameter - holeDiameter) / (2 * Math.tan((angleDeg / 2) * (Math.PI / 180)));
  const cone = primitives.cylinderElliptic({
    height: coneHeight + 0.5,
    startRadius: [holeDiameter / 2, holeDiameter / 2],
    endRadius: [headDiameter / 2, headDiameter / 2],
    segments: 32
  });
  const shiftedCone = transforms.translate([0, 0, (totalDepth / 2) - (coneHeight / 2) + 0.25], cone);
  const combined = booleans.union(throughHole, shiftedCone);
  return transforms.translate([posX, posY, posZ], combined);
}

function createElongatedSlot(width, length, depth, posX = 0, posY = 0, posZ = 0, rotateDeg = 0) {
  const radius = width / 2;
  const straightLength = Math.max(0.1, length - width);
  const rect = primitives.cuboid({ size: [straightLength, width, depth + 4] });
  const c1 = transforms.translate([-straightLength / 2, 0, 0], primitives.cylinder({ radius: radius, height: depth + 4, segments: 24 }));
  const c2 = transforms.translate([straightLength / 2, 0, 0], primitives.cylinder({ radius: radius, height: depth + 4, segments: 24 }));
  const slotGeom = booleans.union(rect, c1, c2);
  const rotated = rotateDeg !== 0 ? transforms.rotateZ((rotateDeg * Math.PI) / 180, slotGeom) : slotGeom;
  return transforms.translate([posX, posY, posZ], rotated);
}

function createCableOpening(width, depth, height, posX = 0, posY = 0, posZ = 0) {
  const radius = Math.min(width, depth) / 3;
  return transforms.translate([posX, posY, posZ], primitives.roundedCuboid({
    size: [width, depth, height + 4],
    roundRadius: radius,
    segments: 16
  }));
}

function createMountingBoss(outerDiameter, innerDiameter, height, posX = 0, posY = 0, posZ = 0) {
  const outer = primitives.cylinder({ radius: outerDiameter / 2, height: height, segments: 32 });
  const inner = primitives.cylinder({ radius: innerDiameter / 2, height: height + 2, segments: 24 });
  const boss = booleans.subtract(outer, inner);
  return transforms.translate([posX, posY, posZ + (height / 2)], boss);
}

function createReinforcingRib(thickness, height, length, posX = 0, posY = 0, posZ = 0, angleDeg = 0) {
  const ribBox = primitives.cuboid({ size: [length, thickness, height] });
  const rotated = angleDeg !== 0 ? transforms.rotateZ((angleDeg * Math.PI) / 180, ribBox) : ribBox;
  return transforms.translate([posX, posY, posZ + (height / 2)], rotated);
}

function createCornerGusset(legSize, thickness, posX = 0, posY = 0, posZ = 0) {
  const prism = primitives.cuboid({ size: [legSize, legSize, thickness] });
  const cutter = transforms.translate([legSize / 2, legSize / 2, 0], transforms.rotateZ(Math.PI / 4, primitives.cuboid({ size: [legSize * 1.5, legSize * 1.5, thickness + 2] })));
  const gusset = booleans.subtract(prism, cutter);
  return transforms.translate([posX, posY, posZ], gusset);
}

function createLinearHolePattern(diameter, depth, count, spacing, axis = 'x', startOffset = 0, otherPos = 0, posZ = 0) {
  const holes = [];
  const totalSpan = (count - 1) * spacing;
  const start = -totalSpan / 2 + startOffset;
  for (let i = 0; i < count; i++) {
    const pos = start + (i * spacing);
    const posX = axis === 'x' ? pos : otherPos;
    const posY = axis === 'y' ? pos : otherPos;
    holes.push(createThroughHole(diameter, depth, posX, posY, posZ));
  }
  return holes.length === 1 ? holes[0] : booleans.union(...holes);
}

function createCircularHolePattern(diameter, depth, count, pitchRadius, centerPosX = 0, centerPosY = 0, posZ = 0) {
  const holes = [];
  const angleStep = (2 * Math.PI) / count;
  for (let i = 0; i < count; i++) {
    const angle = i * angleStep;
    const posX = centerPosX + Math.cos(angle) * pitchRadius;
    const posY = centerPosY + Math.sin(angle) * pitchRadius;
    holes.push(createThroughHole(diameter, depth, posX, posY, posZ));
  }
  return holes.length === 1 ? holes[0] : booleans.union(...holes);
}

function createDrainageSlotPattern(slotWidth, slotLength, slotDepth, count, spacing, posX = 0, posY = 0, posZ = 0) {
  const slots = [];
  const totalSpan = (count - 1) * spacing;
  const start = -totalSpan / 2;
  for (let i = 0; i < count; i++) {
    const yOffset = start + (i * spacing);
    slots.push(createElongatedSlot(slotWidth, slotLength, slotDepth, posX, posY + yOffset, posZ));
  }
  return slots.length === 1 ? slots[0] : booleans.union(...slots);
}

function createPCBStandoff(outerDiameter, pilotDiameter, height, posX = 0, posY = 0, posZ = 0) {
  return createMountingBoss(outerDiameter, pilotDiameter, height, posX, posY, posZ);
}
`;
