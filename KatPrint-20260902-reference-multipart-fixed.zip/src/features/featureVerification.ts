import {
  SemanticFeatureModel,
  SemanticFeature,
  FeatureStatus,
  FeatureVerificationEvidence,
  FeatureBindingValidation,
} from './featureTypes';
import { GeometryInspectionStats, ModelGeometryStats } from '../types';
import { FEATURE_BUILDER_REGISTRY } from './featureGenerators';
import { validateFeatureBindings } from './featureCodeBindings';

export interface FeatureVerificationResult {
  verifiedCount: number;
  failedCount: number;
  unknownCount: number;
  updatedModel: SemanticFeatureModel;
  report: {
    featureId: string;
    label: string;
    status: FeatureStatus;
    evidence: FeatureVerificationEvidence;
    notes: string;
  }[];
}

/**
 * Performs feature-level verification against measured geometry, code structure,
 * and exact code bindings.
 */
export function verifySemanticFeatureModel(
  model: SemanticFeatureModel,
  geometry?: GeometryInspectionStats | ModelGeometryStats | null,
  code?: string,
  bindingValidation?: FeatureBindingValidation
): FeatureVerificationResult {
  let verifiedCount = 0;
  let failedCount = 0;
  let unknownCount = 0;

  const report: {
    featureId: string;
    label: string;
    status: FeatureStatus;
    evidence: FeatureVerificationEvidence;
    notes: string;
  }[] = [];

  const rawCode = code || '';
  const validation = bindingValidation || (code ? validateFeatureBindings(model, code) : model.bindingValidation);

  const updatedFeatures: SemanticFeature[] = model.features.map((feature) => {
    let status: FeatureStatus = 'unknown';
    let evidence: FeatureVerificationEvidence = 'NONE';
    let notes = '';

    // Check if model has valid geometry at all
    const vol = geometry
      ? ('volumeMm3' in geometry ? geometry.volumeMm3 : (geometry as any).volumeCm3 * 1000) || 0
      : 0;
    if (!geometry || vol <= 0 || (geometry.isManifold === false && geometry.dimensions.x <= 0)) {
      status = 'failed';
      evidence = 'NONE';
      notes = 'Overall geometry is empty or failed to evaluate.';
      failedCount++;
      report.push({ featureId: feature.id, label: feature.label, status, evidence, notes });
      return { ...feature, status, evidence, verificationNotes: notes };
    }

    const isFullyBound = validation ? validation.boundFeatures.includes(feature.id) : false;
    const isPartiallyBound = validation ? validation.partiallyBoundFeatures.includes(feature.id) : false;
    const isBuilderBound = validation ? validation.builderBoundFeatures.includes(feature.id) : false;
    const builderSpec = FEATURE_BUILDER_REGISTRY[feature.type];

    // 1. BASE BODY / PLATE Verification
    if (feature.type === 'BASE_BODY' || feature.type === 'PLATE') {
      const expectedW = Number(feature.parameters.width) || 0;
      const expectedD = Number(feature.parameters.depth) || 0;
      const expectedH = Number(feature.parameters.height || feature.parameters.thickness) || 0;

      const measX = geometry.dimensions.x;
      const measY = geometry.dimensions.y;
      const measZ = geometry.dimensions.z;

      // Default explicit tolerance: +/- 0.5 mm
      const tol = 0.5;
      const matchX = expectedW <= 0 || Math.abs(measX - expectedW) <= tol;
      const matchY = expectedD <= 0 || Math.abs(measY - expectedD) <= tol;
      const matchZ = expectedH <= 0 || Math.abs(measZ - expectedH) <= tol;

      if (matchX && matchY && matchZ) {
        status = 'verified';
        evidence = 'GEOMETRY_MEASURED';
        notes = `Base envelope measured [${measX.toFixed(1)} x ${measY.toFixed(1)} x ${measZ.toFixed(1)} mm] matches planned dimensions within ±${tol} mm.`;
      } else {
        status = 'failed';
        evidence = 'GEOMETRY_MEASURED';
        notes = `Measured base [${measX.toFixed(1)} x ${measY.toFixed(1)} x ${measZ.toFixed(1)} mm] deviates from expected [${expectedW} x ${expectedD} x ${expectedH} mm] beyond ±${tol} mm tolerance.`;
      }
    }

    // 2. HOLE / COUNTERSINK / COUNTERBORE / DRAINAGE_HOLE Verification
    else if (
      feature.type === 'HOLE' ||
      feature.type === 'COUNTERSINK' ||
      feature.type === 'COUNTERBORE' ||
      feature.type === 'DRAINAGE_HOLE'
    ) {
      if (builderSpec && isBuilderBound && geometry.isManifold) {
        status = 'verified';
        evidence = 'BUILDER_CALL_BOUND';
        notes = `Verified deterministic builder call (${builderSpec.builderName}) bound to manifold solid geometry.`;
      } else if (isFullyBound && geometry.isManifold) {
        // Parameter constant bound, but without verified builder call it is parameter bound only
        status = 'unknown';
        evidence = 'PARAMETER_BOUND';
        notes = `Feature parameter constants declared and bound. Geometric boolean subtraction unverified without deterministic builder call.`;
      } else if (isPartiallyBound) {
        status = 'unknown';
        evidence = 'PARAMETER_BOUND';
        notes = `Some feature parameters bound; full deterministic binding not confirmed.`;
      } else {
        status = 'unknown';
        evidence = rawCode.includes('cylinder') ? 'SOURCE_HINT_ONLY' : 'NONE';
        notes = `Feature-specific parameter binding or builder call was not confirmed.`;
      }
    }

    // 3. SLOT / DRAINAGE SLOT / CABLE OPENING Verification
    else if (
      feature.type === 'SLOT' ||
      feature.type === 'DRAINAGE_SLOT' ||
      feature.type === 'CABLE_OPENING' ||
      feature.type === 'CHANNEL' ||
      feature.type === 'VENT'
    ) {
      if (builderSpec && isBuilderBound && geometry.isManifold) {
        status = 'verified';
        evidence = 'BUILDER_CALL_BOUND';
        notes = `Verified deterministic slot builder (${builderSpec.builderName}) bound to manifold solid.`;
      } else if (isFullyBound && geometry.isManifold) {
        status = 'unknown';
        evidence = 'PARAMETER_BOUND';
        notes = `Pass-through cutout parameters bound to constants. Physical clearance unverified without deterministic builder call.`;
      } else if (isPartiallyBound) {
        status = 'unknown';
        evidence = 'PARAMETER_BOUND';
        notes = `Partial parameter binding detected for cutout.`;
      } else {
        status = 'unknown';
        evidence = rawCode.includes('subtract') ? 'SOURCE_HINT_ONLY' : 'NONE';
        notes = `Pass-through cutout geometry not bound to verified builder or parameter constants.`;
      }
    }

    // 4. RIB / GUSSET / BOSS / STANDOFF / CRADLE Verification
    else if (
      feature.type === 'RIB' ||
      feature.type === 'GUSSET' ||
      feature.type === 'BOSS' ||
      feature.type === 'STANDOFF' ||
      feature.type === 'SUPPORT' ||
      feature.type === 'CRADLE' ||
      feature.type === 'LIP' ||
      feature.type === 'WALL'
    ) {
      if (builderSpec && isBuilderBound && geometry.isManifold) {
        status = 'verified';
        evidence = 'BUILDER_CALL_BOUND';
        notes = `Verified additive structural geometry generated via ${builderSpec.builderName} with bound constants. (Geometric presence confirmed; load capacity unverified without FEA).`;
      } else if (isFullyBound) {
        status = 'unknown';
        evidence = 'PARAMETER_BOUND';
        notes = `Additive feature parameters declared and bound. Geometric addition unverified without deterministic builder call.`;
      } else {
        status = 'unknown';
        evidence = rawCode.includes('union') ? 'SOURCE_HINT_ONLY' : 'NONE';
        notes = `Structural reinforcement presence unverified.`;
      }
    }

    // 5. FINISHING (FILLET / CHAMFER / ROUNDING)
    else if (feature.type === 'FILLET' || feature.type === 'CHAMFER' || feature.type === 'ROUNDING') {
      if (isFullyBound && (rawCode.includes('roundRadius') || rawCode.includes('roundedCuboid') || rawCode.includes('roundedRectangle'))) {
        status = 'unknown';
        evidence = 'PARAMETER_BOUND';
        notes = `Edge treatment parameter constants bound in code. Standalone geometry presence unverified without edge-level topological analysis.`;
      } else {
        const hasRounding =
          rawCode.includes('roundedcuboid') ||
          rawCode.includes('roundradius') ||
          rawCode.includes('chamfer') ||
          rawCode.includes('fillet');
        status = 'unknown';
        evidence = hasRounding ? 'SOURCE_HINT_ONLY' : 'NONE';
        notes = hasRounding ? `Corner rounding primitives present in generation source (unbound parameter).` : `Rounding parameters unverified.`;
      }
    } else {
      status = (isFullyBound && isBuilderBound) ? 'verified' : 'unknown';
      evidence = isFullyBound ? (isBuilderBound ? 'BUILDER_CALL_BOUND' : 'PARAMETER_BOUND') : 'NONE';
      notes = `Feature status evaluated against CAD bindings.`;
    }

    if (status === 'verified') verifiedCount++;
    else if (status === 'failed') failedCount++;
    else unknownCount++;

    report.push({ featureId: feature.id, label: feature.label, status, evidence, notes });
    return { ...feature, status, evidence, verificationNotes: notes };
  });

  const updatedModel: SemanticFeatureModel = {
    ...model,
    features: updatedFeatures,
    bindingValidation: validation,
  };

  return {
    verifiedCount,
    failedCount,
    unknownCount,
    updatedModel,
    report,
  };
}
