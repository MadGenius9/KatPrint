import {
  SemanticFeatureModel,
  SemanticFeature,
  FeatureParameter,
  FeatureRelationship,
  FeatureConstraint,
} from './featureTypes';
import { extractFeatureCodeBindings, validateFeatureBindings } from './featureCodeBindings';
import { verifySemanticFeatureModel } from './featureVerification';
import { validateFeatureWrapperWorldSpaceUsage } from './featureSelection';
import { planSemanticFeatureModel } from './featurePlanner';
import { createDefaultDesignSpecification, validateDesignSpecification } from '../engine/designIntent/designSpecification';
import { DesignSpecification, ModelGeometryStats, GeometryInspectionStats } from '../types';
import { createFeatureParameter } from './featureParameters';

export interface FeatureModelDiff {
  hasChanges: boolean;
  addedFeatures: SemanticFeature[];
  removedFeatures: SemanticFeature[];
  modifiedFeatures: {
    feature: SemanticFeature;
    parameterChanges: {
      parameterName: string;
      oldValue: number | string | boolean;
      newValue: number | string | boolean;
      unit?: string;
    }[];
  }[];
  summary: string[];
}

/**
 * Authoritative pipeline function to extract strict code bindings, validate them,
 * verify semantic features, and return a finalized SemanticFeatureModel.
 */
export function finalizeFeatureModelForCode(
  featureModel: SemanticFeatureModel,
  code: string,
  geometry?: ModelGeometryStats | GeometryInspectionStats | null,
  mode: 'strict' | 'legacy' = 'strict'
): SemanticFeatureModel {
  // 1. Extract feature code bindings
  const codeBindings = extractFeatureCodeBindings(code, featureModel, mode);

  // 2. Validate bindings
  const modelWithBindings: SemanticFeatureModel = {
    ...featureModel,
    codeBindings,
  };
  const bindingValidation = validateFeatureBindings(modelWithBindings, code, mode);

  // 3. Verify semantic features against measured geometry and validated bindings
  const verificationResult = verifySemanticFeatureModel(
    modelWithBindings,
    geometry,
    code,
    bindingValidation
  );

  // 4. Validate world-space wrapper usage
  const selectionValidation = validateFeatureWrapperWorldSpaceUsage(code, modelWithBindings);

  return {
    ...verificationResult.updatedModel,
    codeBindings,
    bindingValidation,
    selectionValidation,
  };
}

/**
 * Compares two semantic feature models to provide human-readable difference summaries.
 */
export function compareFeatureModels(
  prevModel?: SemanticFeatureModel | null,
  newModel?: SemanticFeatureModel | null
): FeatureModelDiff {
  if (!prevModel && !newModel) {
    return { hasChanges: false, addedFeatures: [], removedFeatures: [], modifiedFeatures: [], summary: [] };
  }
  if (!prevModel && newModel) {
    return {
      hasChanges: true,
      addedFeatures: newModel.features,
      removedFeatures: [],
      modifiedFeatures: [],
      summary: [`Initial semantic feature model created with ${newModel.features.length} features.`],
    };
  }
  if (prevModel && !newModel) {
    return {
      hasChanges: true,
      addedFeatures: [],
      removedFeatures: prevModel.features,
      modifiedFeatures: [],
      summary: ['Semantic feature model was removed.'],
    };
  }

  const prev = prevModel!;
  const next = newModel!;

  const addedFeatures: SemanticFeature[] = next.features.filter(
    (nf) => !prev.features.some((pf) => pf.id === nf.id)
  );
  const removedFeatures: SemanticFeature[] = prev.features.filter(
    (pf) => !next.features.some((nf) => nf.id === pf.id)
  );

  const modifiedFeatures: {
    feature: SemanticFeature;
    parameterChanges: {
      parameterName: string;
      oldValue: number | string | boolean;
      newValue: number | string | boolean;
      unit?: string;
    }[];
  }[] = [];

  const summary: string[] = [];

  for (const newFeat of next.features) {
    const prevFeat = prev.features.find((pf) => pf.id === newFeat.id);
    if (!prevFeat) continue;

    const paramChanges: {
      parameterName: string;
      oldValue: number | string | boolean;
      newValue: number | string | boolean;
      unit?: string;
    }[] = [];

    const allKeys = Array.from(
      new Set([...Object.keys(prevFeat.parameters), ...Object.keys(newFeat.parameters)])
    );

    for (const key of allKeys) {
      const oldVal = prevFeat.parameters[key];
      const newVal = newFeat.parameters[key];
      if (oldVal !== newVal && oldVal !== undefined && newVal !== undefined) {
        const paramDef = next.parameters.find(
          (p) => p.featureId === newFeat.id && p.name === key
        );
        paramChanges.push({
          parameterName: key,
          oldValue: oldVal,
          newValue: newVal,
          unit: paramDef?.unit || 'mm',
        });
        summary.push(
          `${newFeat.label} [${key}]: ${oldVal} → ${newVal}${paramDef?.unit ? ' ' + paramDef.unit : ''}`
        );
      }
    }

    if (paramChanges.length > 0) {
      modifiedFeatures.push({ feature: newFeat, parameterChanges: paramChanges });
    }
  }

  for (const added of addedFeatures) {
    summary.push(`Added feature: ${added.label} (${added.type})`);
  }
  for (const removed of removedFeatures) {
    summary.push(`Removed feature: ${removed.label}`);
  }

  return {
    hasChanges: addedFeatures.length > 0 || removedFeatures.length > 0 || modifiedFeatures.length > 0,
    addedFeatures,
    removedFeatures,
    modifiedFeatures,
    summary,
  };
}

/**
 * Reconstructs a SemanticFeatureModel for legacy Phase 2 models that do not have one.
 */
export function reconstructLegacyFeatureModel(
  code: string,
  prompt: string,
  spec?: DesignSpecification | null,
  geometry?: ModelGeometryStats | GeometryInspectionStats | null
): { model: SemanticFeatureModel; confidence: number } {
  const actualSpec = spec ? validateDesignSpecification(spec, prompt) : createDefaultDesignSpecification(prompt);
  const plannedModel = planSemanticFeatureModel(actualSpec, prompt);

  // Extract real constants from the legacy code
  const bindings = extractFeatureCodeBindings(code, plannedModel, 'legacy');
  const updatedParameters: FeatureParameter[] = plannedModel.parameters.map((param) => {
    // Check if code contains matching constant
    const matchBinding = bindings
      .flatMap((b) => b.parameterBindings)
      .find((pb) => pb.parameterId === param.id);

    if (matchBinding) {
      const regex = new RegExp(`(?:const|let|var)\\s+${matchBinding.constantName}\\s*=\\s*([-0-9.]+)`);
      const match = code.match(regex);
      if (match) {
        const parsed = parseFloat(match[1]);
        if (!isNaN(parsed)) {
          return {
            ...param,
            value: parsed,
            source: 'inferred',
            jscadConstantName: matchBinding.constantName,
          };
        }
      }
    }
    return param;
  });

  const reconstructed: SemanticFeatureModel = {
    ...plannedModel,
    generationStrategy: 'legacy-reconstructed',
    parameters: updatedParameters,
    codeBindings: bindings,
    schemaVersion: 3,
  };

  const finalized = finalizeFeatureModelForCode(reconstructed, code, geometry, 'legacy');
  const confidence = bindings.some((b) => b.parameterBindings.length > 0) ? 0.85 : 0.65;
  return { model: finalized, confidence };
}
