import { FeatureConstraint, ConstraintType, FeatureParameter } from './featureTypes';

export function createFeatureConstraint(params: {
  id?: string;
  name: string;
  description: string;
  constraintType: ConstraintType;
  affectedFeatureIds: string[];
  parameterKeys?: string[];
  value?: number | string | boolean;
  tolerance?: number;
  isLocked?: boolean;
}): FeatureConstraint {
  return {
    id: params.id || `const_${params.constraintType}_${params.affectedFeatureIds.join('_')}`,
    name: params.name,
    description: params.description,
    constraintType: params.constraintType,
    affectedFeatureIds: params.affectedFeatureIds,
    parameterKeys: params.parameterKeys,
    value: params.value,
    tolerance: params.tolerance,
    isLocked: params.isLocked || false,
  };
}

export function evaluateConstraint(
  constraint: FeatureConstraint,
  parameters: FeatureParameter[]
): { satisfied: boolean; message: string; diff?: number } {
  if (constraint.constraintType === 'min_value' && typeof constraint.value === 'number') {
    const relevant = parameters.filter(
      (p) =>
        constraint.affectedFeatureIds.includes(p.featureId) &&
        (!constraint.parameterKeys || constraint.parameterKeys.includes(p.name))
    );
    for (const param of relevant) {
      if (typeof param.value === 'number' && param.value < constraint.value) {
        return {
          satisfied: false,
          message: `${param.semanticName} (${param.value} mm) violates minimum constraint >= ${constraint.value} mm`,
          diff: constraint.value - param.value,
        };
      }
    }
    return { satisfied: true, message: 'Constraint satisfied' };
  }

  if (constraint.constraintType === 'equality') {
    const relevant = parameters.filter(
      (p) =>
        constraint.affectedFeatureIds.includes(p.featureId) &&
        (!constraint.parameterKeys || constraint.parameterKeys.includes(p.name))
    );
    if (relevant.length > 1) {
      const firstVal = relevant[0].value;
      for (let i = 1; i < relevant.length; i++) {
        if (relevant[i].value !== firstVal) {
          return {
            satisfied: false,
            message: `${relevant[i].semanticName} (${relevant[i].value}) does not match ${relevant[0].semanticName} (${firstVal})`,
          };
        }
      }
    }
    return { satisfied: true, message: 'Constraint satisfied' };
  }

  return { satisfied: true, message: 'Constraint evaluated' };
}
