import * as THREE from 'three';
import {
  SemanticFeatureModel,
  SemanticFeature,
  FeatureParameter,
  FeatureType,
  SemanticRevisionOpType,
  FeatureConstraint,
} from './featureTypes';
import { FeatureSelectionGeometry } from './featureSelection';
import { updateJscadConstants } from './featureCodeBindings';

export type ManipulatorType =
  | 'POSITION'
  | 'WIDTH'
  | 'LENGTH'
  | 'HEIGHT'
  | 'DEPTH'
  | 'DIAMETER'
  | 'RADIUS'
  | 'ANGLE'
  | 'THICKNESS'
  | 'SPACING';

export type ManipulatorAxis = 'X' | 'Y' | 'Z' | 'XY' | 'XYZ' | 'RADIAL' | 'NORMAL';

export interface FeatureManipulator {
  id: string;
  featureId: string;
  type: ManipulatorType;
  axis: ManipulatorAxis;
  parameterIds: string[];
  origin: [number, number, number];
  direction?: [number, number, number];
  currentValue: number;
  unit: 'mm' | 'deg';
  min?: number;
  max?: number;
  step?: number;
  label: string;
  enabled: boolean;
  locked?: boolean;
  reasonDisabled?: string;
  secondaryValue?: number;
}

export interface FeatureManipulationDefinition {
  featureId: string;
  manipulators: FeatureManipulator[];
  directlyManipulable: boolean;
  reason?: string;
  isMultiFeature?: boolean;
  featureIds?: string[];
}

export interface ParameterDeltaChange {
  parameterId: string;
  featureId: string;
  paramName: string;
  oldValue: number;
  newValue: number;
  delta: number;
  unit?: string;
  lockOverride?: boolean;
}

export interface FeatureManipulationPreviewState {
  featureId: string;
  featureIds: string[];
  manipulatorId: string;
  manipulatorType: ManipulatorType;
  axis: ManipulatorAxis;
  initialValue: number;
  currentValue: number;
  delta: number;
  origin: [number, number, number];
  parameterChanges: ParameterDeltaChange[];
  isValid: boolean;
  validationMessage?: string;
}

/**
 * Controlled set of directly manipulable feature types in Phase 3.3.
 */
export const DIRECTLY_MANIPULABLE_FEATURE_TYPES: FeatureType[] = [
  'HOLE',
  'COUNTERSINK',
  'COUNTERBORE',
  'THREADED_HOLE',
  'SLOT',
  'CABLE_OPENING',
  'PLATE',
  'WALL',
  'BOSS',
  'STANDOFF',
  'RIB',
  'GUSSET',
  'CAVITY',
  'POCKET',
];

/**
 * Snaps a numeric value to the specified increment.
 */
export function snapValue(value: number, snapMm: number): number {
  if (!snapMm || snapMm <= 0) return Math.round(value * 100) / 100;
  const factor = 1 / snapMm;
  const snapped = Math.round(value * factor) / factor;
  return Math.round(snapped * 1000) / 1000;
}

/**
 * Checks if a parameter is bound in the JSCAD code.
 */
function isParameterBoundInCad(
  param: FeatureParameter,
  model: SemanticFeatureModel,
  cadCode: string
): { isBound: boolean; constantName?: string } {
  // 1. Check explicit codeBindings
  if (model.codeBindings) {
    for (const binding of model.codeBindings) {
      const match = binding.parameterBindings.find((pb) => pb.parameterId === param.id);
      if (match && match.constantName) {
        // Confirm constant appears in code
        const constRegex = new RegExp(`\\b${match.constantName}\\b`);
        if (constRegex.test(cadCode)) {
          return { isBound: true, constantName: match.constantName };
        }
      }
    }
  }

  // 2. Check direct constant names on parameter
  const candidateNames = [
    param.jscadConstantName,
    param.name,
    param.id,
  ].filter(Boolean) as string[];

  for (const name of candidateNames) {
    const regex = new RegExp(`(?:const|let|var)\\s+${name}\\s*=\\s*[-0-9.]+`);
    if (regex.test(cadCode)) {
      return { isBound: true, constantName: name };
    }
  }

  return { isBound: false };
}

/**
 * Computes semantic 3D manipulation controls for a selected feature.
 * Strictly verifies bound parameters before generating handles.
 */
export function getFeatureManipulationDefinition(
  feature: SemanticFeature,
  featureModel: SemanticFeatureModel,
  cadCode: string,
  featureGeom?: FeatureSelectionGeometry | null
): FeatureManipulationDefinition {
  const manipulators: FeatureManipulator[] = [];
  const featureType = feature.type;

  if (!DIRECTLY_MANIPULABLE_FEATURE_TYPES.includes(featureType)) {
    return {
      featureId: feature.id,
      manipulators: [],
      directlyManipulable: false,
      reason: `Feature type ${featureType} is editable via Feature Inspector.`,
    };
  }

  // World-Space Origin for gizmos
  let origin: [number, number, number] = [0, 0, 0];
  if (featureGeom?.center) {
    origin = [...featureGeom.center];
  } else if (feature.geometrySelectionMetadata?.boundingBox) {
    const bb = feature.geometrySelectionMetadata.boundingBox;
    origin = [
      (bb.min[0] + bb.max[0]) / 2,
      (bb.min[1] + bb.max[1]) / 2,
      (bb.min[2] + bb.max[2]) / 2,
    ];
  }

  const featureParams = featureModel.parameters.filter(
    (p) => feature.parameterIds.includes(p.id) || p.featureId === feature.id
  );

  // Helper to find parameter by candidate semantic names
  const findParam = (...names: string[]): FeatureParameter | undefined => {
    return featureParams.find((p) => {
      const lowerName = (p.name || '').toLowerCase();
      const lowerSem = (p.semanticName || '').toLowerCase();
      const lowerId = (p.id || '').toLowerCase();
      return names.some(
        (n) =>
          lowerName === n.toLowerCase() ||
          lowerSem === n.toLowerCase() ||
          lowerId.endsWith(`_${n.toLowerCase()}`) ||
          lowerId.includes(n.toLowerCase())
      );
    });
  };

  // -------------------------------------------------------------------------
  // 1. HOLE / COUNTERSINK / COUNTERBORE / THREADED_HOLE
  // -------------------------------------------------------------------------
  if (
    featureType === 'HOLE' ||
    featureType === 'COUNTERSINK' ||
    featureType === 'COUNTERBORE' ||
    featureType === 'THREADED_HOLE'
  ) {
    // X Position
    const paramX = findParam('x', 'posX', 'pos_x', 'position_x', 'hole_x', 'center_x');
    if (paramX && typeof paramX.value === 'number') {
      const binding = isParameterBoundInCad(paramX, featureModel, cadCode);
      if (binding.isBound) {
        origin[0] = paramX.value;
        manipulators.push({
          id: `${feature.id}_pos_x`,
          featureId: feature.id,
          type: 'POSITION',
          axis: 'X',
          parameterIds: [paramX.id],
          origin: [...origin],
          direction: [1, 0, 0],
          currentValue: paramX.value,
          unit: 'mm',
          min: paramX.min,
          max: paramX.max,
          step: paramX.step || 1.0,
          label: 'Move X',
          enabled: !paramX.locked,
          locked: paramX.locked,
          reasonDisabled: paramX.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Y Position
    const paramY = findParam('y', 'posY', 'pos_y', 'position_y', 'hole_y', 'center_y');
    if (paramY && typeof paramY.value === 'number') {
      const binding = isParameterBoundInCad(paramY, featureModel, cadCode);
      if (binding.isBound) {
        origin[1] = paramY.value;
        manipulators.push({
          id: `${feature.id}_pos_y`,
          featureId: feature.id,
          type: 'POSITION',
          axis: 'Y',
          parameterIds: [paramY.id],
          origin: [...origin],
          direction: [0, 1, 0],
          currentValue: paramY.value,
          unit: 'mm',
          min: paramY.min,
          max: paramY.max,
          step: paramY.step || 1.0,
          label: 'Move Y',
          enabled: !paramY.locked,
          locked: paramY.locked,
          reasonDisabled: paramY.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Z Position (if vertically positioned)
    const paramZ = findParam('z', 'posZ', 'pos_z', 'position_z', 'hole_z', 'center_z');
    if (paramZ && typeof paramZ.value === 'number') {
      const binding = isParameterBoundInCad(paramZ, featureModel, cadCode);
      if (binding.isBound) {
        origin[2] = paramZ.value;
        manipulators.push({
          id: `${feature.id}_pos_z`,
          featureId: feature.id,
          type: 'POSITION',
          axis: 'Z',
          parameterIds: [paramZ.id],
          origin: [...origin],
          direction: [0, 0, 1],
          currentValue: paramZ.value,
          unit: 'mm',
          min: paramZ.min,
          max: paramZ.max,
          step: paramZ.step || 1.0,
          label: 'Move Z',
          enabled: !paramZ.locked,
          locked: paramZ.locked,
          reasonDisabled: paramZ.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Diameter Handle
    const paramDia = findParam(
      'diameter',
      'holeDiameter',
      'hole_diameter',
      'radius',
      'dia',
      'hole_radius'
    );
    if (paramDia && typeof paramDia.value === 'number') {
      const binding = isParameterBoundInCad(paramDia, featureModel, cadCode);
      if (binding.isBound) {
        const isRadius = paramDia.name.toLowerCase().includes('radius');
        const diameterVal = isRadius ? paramDia.value * 2 : paramDia.value;
        manipulators.push({
          id: `${feature.id}_diameter`,
          featureId: feature.id,
          type: isRadius ? 'RADIUS' : 'DIAMETER',
          axis: 'RADIAL',
          parameterIds: [paramDia.id],
          origin: [...origin],
          direction: [1, 0, 0],
          currentValue: diameterVal,
          unit: 'mm',
          min: paramDia.min || 1.0,
          max: paramDia.max || 100.0,
          step: paramDia.step || 0.5,
          label: isRadius ? 'Radius' : 'Diameter',
          enabled: !paramDia.locked,
          locked: paramDia.locked,
          reasonDisabled: paramDia.locked ? 'Parameter is locked' : undefined,
        });
      }
    }
  }

  // -------------------------------------------------------------------------
  // 2. SLOT / CABLE_OPENING
  // -------------------------------------------------------------------------
  else if (featureType === 'SLOT' || featureType === 'CABLE_OPENING') {
    // Position X & Y
    const paramX = findParam('x', 'posX', 'pos_x', 'position_x', 'slot_x', 'opening_x');
    if (paramX && typeof paramX.value === 'number') {
      const binding = isParameterBoundInCad(paramX, featureModel, cadCode);
      if (binding.isBound) {
        origin[0] = paramX.value;
        manipulators.push({
          id: `${feature.id}_pos_x`,
          featureId: feature.id,
          type: 'POSITION',
          axis: 'X',
          parameterIds: [paramX.id],
          origin: [...origin],
          direction: [1, 0, 0],
          currentValue: paramX.value,
          unit: 'mm',
          min: paramX.min,
          max: paramX.max,
          step: paramX.step || 1.0,
          label: 'Move X',
          enabled: !paramX.locked,
          locked: paramX.locked,
          reasonDisabled: paramX.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    const paramY = findParam('y', 'posY', 'pos_y', 'position_y', 'slot_y', 'opening_y');
    if (paramY && typeof paramY.value === 'number') {
      const binding = isParameterBoundInCad(paramY, featureModel, cadCode);
      if (binding.isBound) {
        origin[1] = paramY.value;
        manipulators.push({
          id: `${feature.id}_pos_y`,
          featureId: feature.id,
          type: 'POSITION',
          axis: 'Y',
          parameterIds: [paramY.id],
          origin: [...origin],
          direction: [0, 1, 0],
          currentValue: paramY.value,
          unit: 'mm',
          min: paramY.min,
          max: paramY.max,
          step: paramY.step || 1.0,
          label: 'Move Y',
          enabled: !paramY.locked,
          locked: paramY.locked,
          reasonDisabled: paramY.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Width
    const paramW = findParam('width', 'slotWidth', 'slot_width', 'opening_width', 'w');
    if (paramW && typeof paramW.value === 'number') {
      const binding = isParameterBoundInCad(paramW, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_width`,
          featureId: feature.id,
          type: 'WIDTH',
          axis: 'X',
          parameterIds: [paramW.id],
          origin: [...origin],
          direction: [1, 0, 0],
          currentValue: paramW.value,
          unit: 'mm',
          min: paramW.min || 2.0,
          max: paramW.max,
          step: paramW.step || 1.0,
          label: 'Width',
          enabled: !paramW.locked,
          locked: paramW.locked,
          reasonDisabled: paramW.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Length
    const paramL = findParam('length', 'slotLength', 'slot_length', 'opening_length', 'l', 'height');
    if (paramL && typeof paramL.value === 'number') {
      const binding = isParameterBoundInCad(paramL, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_length`,
          featureId: feature.id,
          type: 'LENGTH',
          axis: 'Y',
          parameterIds: [paramL.id],
          origin: [...origin],
          direction: [0, 1, 0],
          currentValue: paramL.value,
          unit: 'mm',
          min: paramL.min || 2.0,
          max: paramL.max,
          step: paramL.step || 1.0,
          label: 'Length',
          enabled: !paramL.locked,
          locked: paramL.locked,
          reasonDisabled: paramL.locked ? 'Parameter is locked' : undefined,
        });
      }
    }
  }

  // -------------------------------------------------------------------------
  // 3. PLATE
  // -------------------------------------------------------------------------
  else if (featureType === 'PLATE') {
    // Width
    const paramW = findParam('width', 'plateWidth', 'plate_width', 'box_width', 'w');
    if (paramW && typeof paramW.value === 'number') {
      const binding = isParameterBoundInCad(paramW, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_width`,
          featureId: feature.id,
          type: 'WIDTH',
          axis: 'X',
          parameterIds: [paramW.id],
          origin: [origin[0] + paramW.value / 2, origin[1], origin[2]],
          direction: [1, 0, 0],
          currentValue: paramW.value,
          unit: 'mm',
          min: paramW.min || 10.0,
          max: paramW.max,
          step: paramW.step || 1.0,
          label: 'Plate Width',
          enabled: !paramW.locked,
          locked: paramW.locked,
          reasonDisabled: paramW.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Length / Depth
    const paramL = findParam('length', 'depth', 'plateLength', 'plate_length', 'plate_depth', 'd');
    if (paramL && typeof paramL.value === 'number') {
      const binding = isParameterBoundInCad(paramL, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_length`,
          featureId: feature.id,
          type: 'LENGTH',
          axis: 'Y',
          parameterIds: [paramL.id],
          origin: [origin[0], origin[1] + paramL.value / 2, origin[2]],
          direction: [0, 1, 0],
          currentValue: paramL.value,
          unit: 'mm',
          min: paramL.min || 10.0,
          max: paramL.max,
          step: paramL.step || 1.0,
          label: 'Plate Length',
          enabled: !paramL.locked,
          locked: paramL.locked,
          reasonDisabled: paramL.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Thickness
    const paramT = findParam(
      'thickness',
      'plateThickness',
      'plate_thickness',
      'wall_thickness',
      'height',
      'h'
    );
    if (paramT && typeof paramT.value === 'number') {
      const binding = isParameterBoundInCad(paramT, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_thickness`,
          featureId: feature.id,
          type: 'THICKNESS',
          axis: 'Z',
          parameterIds: [paramT.id],
          origin: [origin[0], origin[1], origin[2] + paramT.value],
          direction: [0, 0, 1],
          currentValue: paramT.value,
          unit: 'mm',
          min: paramT.min || 1.2,
          max: paramT.max || 50.0,
          step: paramT.step || 0.5,
          label: 'Thickness',
          enabled: !paramT.locked,
          locked: paramT.locked,
          reasonDisabled: paramT.locked ? 'Parameter is locked' : undefined,
        });
      }
    }
  }

  // -------------------------------------------------------------------------
  // 4. WALL
  // -------------------------------------------------------------------------
  else if (featureType === 'WALL') {
    // Height
    const paramH = findParam('height', 'wallHeight', 'wall_height', 'h');
    if (paramH && typeof paramH.value === 'number') {
      const binding = isParameterBoundInCad(paramH, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_height`,
          featureId: feature.id,
          type: 'HEIGHT',
          axis: 'Z',
          parameterIds: [paramH.id],
          origin: [origin[0], origin[1], origin[2] + paramH.value / 2],
          direction: [0, 0, 1],
          currentValue: paramH.value,
          unit: 'mm',
          min: paramH.min || 2.0,
          max: paramH.max,
          step: paramH.step || 1.0,
          label: 'Wall Height',
          enabled: !paramH.locked,
          locked: paramH.locked,
          reasonDisabled: paramH.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Thickness
    const paramT = findParam('thickness', 'wallThickness', 'wall_thickness', 't');
    if (paramT && typeof paramT.value === 'number') {
      const binding = isParameterBoundInCad(paramT, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_thickness`,
          featureId: feature.id,
          type: 'THICKNESS',
          axis: 'NORMAL',
          parameterIds: [paramT.id],
          origin: [...origin],
          direction: [1, 0, 0],
          currentValue: paramT.value,
          unit: 'mm',
          min: paramT.min || 1.6,
          max: paramT.max || 20.0,
          step: paramT.step || 0.2,
          label: 'Wall Thickness',
          enabled: !paramT.locked,
          locked: paramT.locked,
          reasonDisabled: paramT.locked ? 'Parameter is locked' : undefined,
        });
      }
    }
  }

  // -------------------------------------------------------------------------
  // 5. BOSS / STANDOFF
  // -------------------------------------------------------------------------
  else if (featureType === 'BOSS' || featureType === 'STANDOFF') {
    // Position X & Y
    const paramX = findParam('x', 'posX', 'pos_x', 'position_x', 'boss_x', 'standoff_x');
    if (paramX && typeof paramX.value === 'number') {
      const binding = isParameterBoundInCad(paramX, featureModel, cadCode);
      if (binding.isBound) {
        origin[0] = paramX.value;
        manipulators.push({
          id: `${feature.id}_pos_x`,
          featureId: feature.id,
          type: 'POSITION',
          axis: 'X',
          parameterIds: [paramX.id],
          origin: [...origin],
          direction: [1, 0, 0],
          currentValue: paramX.value,
          unit: 'mm',
          min: paramX.min,
          max: paramX.max,
          step: paramX.step || 1.0,
          label: 'Move X',
          enabled: !paramX.locked,
          locked: paramX.locked,
          reasonDisabled: paramX.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    const paramY = findParam('y', 'posY', 'pos_y', 'position_y', 'boss_y', 'standoff_y');
    if (paramY && typeof paramY.value === 'number') {
      const binding = isParameterBoundInCad(paramY, featureModel, cadCode);
      if (binding.isBound) {
        origin[1] = paramY.value;
        manipulators.push({
          id: `${feature.id}_pos_y`,
          featureId: feature.id,
          type: 'POSITION',
          axis: 'Y',
          parameterIds: [paramY.id],
          origin: [...origin],
          direction: [0, 1, 0],
          currentValue: paramY.value,
          unit: 'mm',
          min: paramY.min,
          max: paramY.max,
          step: paramY.step || 1.0,
          label: 'Move Y',
          enabled: !paramY.locked,
          locked: paramY.locked,
          reasonDisabled: paramY.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Diameter
    const paramDia = findParam(
      'diameter',
      'bossDiameter',
      'boss_diameter',
      'outer_diameter',
      'standoff_diameter'
    );
    if (paramDia && typeof paramDia.value === 'number') {
      const binding = isParameterBoundInCad(paramDia, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_diameter`,
          featureId: feature.id,
          type: 'DIAMETER',
          axis: 'RADIAL',
          parameterIds: [paramDia.id],
          origin: [...origin],
          direction: [1, 0, 0],
          currentValue: paramDia.value,
          unit: 'mm',
          min: paramDia.min || 2.0,
          max: paramDia.max,
          step: paramDia.step || 0.5,
          label: 'Diameter',
          enabled: !paramDia.locked,
          locked: paramDia.locked,
          reasonDisabled: paramDia.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Height
    const paramH = findParam('height', 'standoffHeight', 'standoff_height', 'boss_height', 'h');
    if (paramH && typeof paramH.value === 'number') {
      const binding = isParameterBoundInCad(paramH, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_height`,
          featureId: feature.id,
          type: 'HEIGHT',
          axis: 'Z',
          parameterIds: [paramH.id],
          origin: [origin[0], origin[1], origin[2] + paramH.value],
          direction: [0, 0, 1],
          currentValue: paramH.value,
          unit: 'mm',
          min: paramH.min || 1.0,
          max: paramH.max,
          step: paramH.step || 1.0,
          label: 'Height',
          enabled: !paramH.locked,
          locked: paramH.locked,
          reasonDisabled: paramH.locked ? 'Parameter is locked' : undefined,
        });
      }
    }
  }

  // -------------------------------------------------------------------------
  // 6. RIB / GUSSET
  // -------------------------------------------------------------------------
  else if (featureType === 'RIB' || featureType === 'GUSSET') {
    // Length / Width
    const paramL = findParam('length', 'width', 'rib_length', 'gusset_length');
    if (paramL && typeof paramL.value === 'number') {
      const binding = isParameterBoundInCad(paramL, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_length`,
          featureId: feature.id,
          type: 'LENGTH',
          axis: 'X',
          parameterIds: [paramL.id],
          origin: [...origin],
          direction: [1, 0, 0],
          currentValue: paramL.value,
          unit: 'mm',
          min: paramL.min || 2.0,
          max: paramL.max,
          step: paramL.step || 1.0,
          label: 'Length',
          enabled: !paramL.locked,
          locked: paramL.locked,
          reasonDisabled: paramL.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Height
    const paramH = findParam('height', 'rib_height', 'gusset_height', 'h');
    if (paramH && typeof paramH.value === 'number') {
      const binding = isParameterBoundInCad(paramH, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_height`,
          featureId: feature.id,
          type: 'HEIGHT',
          axis: 'Z',
          parameterIds: [paramH.id],
          origin: [origin[0], origin[1], origin[2] + paramH.value / 2],
          direction: [0, 0, 1],
          currentValue: paramH.value,
          unit: 'mm',
          min: paramH.min || 2.0,
          max: paramH.max,
          step: paramH.step || 1.0,
          label: 'Height',
          enabled: !paramH.locked,
          locked: paramH.locked,
          reasonDisabled: paramH.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Thickness
    const paramT = findParam('thickness', 'rib_thickness', 'gusset_thickness', 't');
    if (paramT && typeof paramT.value === 'number') {
      const binding = isParameterBoundInCad(paramT, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_thickness`,
          featureId: feature.id,
          type: 'THICKNESS',
          axis: 'NORMAL',
          parameterIds: [paramT.id],
          origin: [...origin],
          direction: [0, 1, 0],
          currentValue: paramT.value,
          unit: 'mm',
          min: paramT.min || 1.2,
          max: paramT.max || 10.0,
          step: paramT.step || 0.2,
          label: 'Thickness',
          enabled: !paramT.locked,
          locked: paramT.locked,
          reasonDisabled: paramT.locked ? 'Parameter is locked' : undefined,
        });
      }
    }
  }

  // -------------------------------------------------------------------------
  // 7. CAVITY / POCKET
  // -------------------------------------------------------------------------
  else if (featureType === 'CAVITY' || featureType === 'POCKET') {
    // Width
    const paramW = findParam('width', 'pocket_width', 'cavity_width', 'w');
    if (paramW && typeof paramW.value === 'number') {
      const binding = isParameterBoundInCad(paramW, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_width`,
          featureId: feature.id,
          type: 'WIDTH',
          axis: 'X',
          parameterIds: [paramW.id],
          origin: [...origin],
          direction: [1, 0, 0],
          currentValue: paramW.value,
          unit: 'mm',
          min: paramW.min || 2.0,
          max: paramW.max,
          step: paramW.step || 1.0,
          label: 'Width',
          enabled: !paramW.locked,
          locked: paramW.locked,
          reasonDisabled: paramW.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Length
    const paramL = findParam('length', 'depth', 'pocket_length', 'cavity_length', 'l');
    if (paramL && typeof paramL.value === 'number') {
      const binding = isParameterBoundInCad(paramL, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_length`,
          featureId: feature.id,
          type: 'LENGTH',
          axis: 'Y',
          parameterIds: [paramL.id],
          origin: [...origin],
          direction: [0, 1, 0],
          currentValue: paramL.value,
          unit: 'mm',
          min: paramL.min || 2.0,
          max: paramL.max,
          step: paramL.step || 1.0,
          label: 'Length',
          enabled: !paramL.locked,
          locked: paramL.locked,
          reasonDisabled: paramL.locked ? 'Parameter is locked' : undefined,
        });
      }
    }

    // Depth
    const paramD = findParam('depth', 'height', 'pocket_depth', 'cavity_depth', 'h');
    if (paramD && typeof paramD.value === 'number') {
      const binding = isParameterBoundInCad(paramD, featureModel, cadCode);
      if (binding.isBound) {
        manipulators.push({
          id: `${feature.id}_depth`,
          featureId: feature.id,
          type: 'DEPTH',
          axis: 'Z',
          parameterIds: [paramD.id],
          origin: [...origin],
          direction: [0, 0, -1],
          currentValue: paramD.value,
          unit: 'mm',
          min: paramD.min || 1.0,
          max: paramD.max,
          step: paramD.step || 1.0,
          label: 'Depth',
          enabled: !paramD.locked,
          locked: paramD.locked,
          reasonDisabled: paramD.locked ? 'Parameter is locked' : undefined,
        });
      }
    }
  }

  const directlyManipulable = manipulators.some((m) => m.enabled);
  const reason =
    manipulators.length === 0
      ? 'No directly manipulable parameters are bound to executable CAD.'
      : !directlyManipulable
      ? 'Parameters are locked from 3D dragging. Unlock in Feature Inspector.'
      : undefined;

  return {
    featureId: feature.id,
    manipulators,
    directlyManipulable,
    reason,
  };
}

/**
 * Computes multi-feature manipulation controls (e.g. Spacing between two holes).
 */
export function getMultiFeatureManipulationDefinition(
  features: SemanticFeature[],
  featureModel: SemanticFeatureModel,
  cadCode: string,
  featureGeoms?: Map<string, FeatureSelectionGeometry> | null
): FeatureManipulationDefinition | null {
  if (features.length < 2) return null;

  // Pattern 1: Two Holes or Mounts (Symmetric Spacing)
  const isAllHoles = features.every((f) =>
    ['HOLE', 'COUNTERSINK', 'COUNTERBORE', 'THREADED_HOLE', 'BOSS', 'STANDOFF'].includes(f.type)
  );

  if (isAllHoles && features.length === 2) {
    const featA = features[0];
    const featB = features[1];

    const paramsA = featureModel.parameters.filter((p) => p.featureId === featA.id);
    const paramsB = featureModel.parameters.filter((p) => p.featureId === featB.id);

    const xA = paramsA.find((p) => p.name.toLowerCase().includes('x'));
    const xB = paramsB.find((p) => p.name.toLowerCase().includes('x'));

    if (
      xA &&
      xB &&
      typeof xA.value === 'number' &&
      typeof xB.value === 'number' &&
      isParameterBoundInCad(xA, featureModel, cadCode).isBound &&
      isParameterBoundInCad(xB, featureModel, cadCode).isBound
    ) {
      const geomA = featureGeoms?.get(featA.id);
      const geomB = featureGeoms?.get(featB.id);

      const centerA = geomA?.center || [xA.value, 0, 0];
      const centerB = geomB?.center || [xB.value, 0, 0];

      const midOrigin: [number, number, number] = [
        (centerA[0] + centerB[0]) / 2,
        (centerA[1] + centerB[1]) / 2,
        (centerA[2] + centerB[2]) / 2,
      ];

      const currentSpacing = Math.abs(xB.value - xA.value);

      return {
        featureId: `${featA.id}_${featB.id}`,
        isMultiFeature: true,
        featureIds: [featA.id, featB.id],
        directlyManipulable: !xA.locked && !xB.locked,
        manipulators: [
          {
            id: `multi_spacing_${featA.id}_${featB.id}`,
            featureId: `${featA.id}_${featB.id}`,
            type: 'SPACING',
            axis: 'X',
            parameterIds: [xA.id, xB.id],
            origin: midOrigin,
            direction: [1, 0, 0],
            currentValue: currentSpacing,
            unit: 'mm',
            min: 5.0,
            max: 500.0,
            step: 1.0,
            label: 'Hole Spacing',
            enabled: !xA.locked && !xB.locked,
            locked: xA.locked || xB.locked,
            reasonDisabled: xA.locked || xB.locked ? 'One or more hole coordinates are locked.' : undefined,
          },
        ],
      };
    }
  }

  return null;
}

/**
 * Validates proposed parameter values against FeatureConstraints (MIN, MAX, LOCKED, EQUAL, etc.).
 */
export function validateManipulationConstraints(
  model: SemanticFeatureModel,
  changes: Array<{ parameterId: string; newValue: number }>
): {
  valid: boolean;
  violations: string[];
  clampedChanges: Array<{ parameterId: string; newValue: number }>;
} {
  const violations: string[] = [];
  const clampedChanges = changes.map((c) => ({ ...c }));

  for (const change of clampedChanges) {
    const param = model.parameters.find((p) => p.id === change.parameterId);
    if (!param) continue;

    // Check hard min parameter clamp
    if (param.min !== undefined && change.newValue < param.min) {
      violations.push(`${param.semanticName || param.name} must be >= ${param.min} mm.`);
      change.newValue = param.min;
    }

    // Check hard max parameter clamp
    if (param.max !== undefined && change.newValue > param.max) {
      violations.push(`${param.semanticName || param.name} must be <= ${param.max} mm.`);
      change.newValue = param.max;
    }

    // Check explicit model constraints
    for (const constr of model.constraints || []) {
      if (
        constr.affectedFeatureIds.includes(param.featureId) &&
        (!constr.parameterKeys || constr.parameterKeys.includes(param.name))
      ) {
        if (constr.constraintType === 'min_value' && typeof constr.value === 'number') {
          if (change.newValue < constr.value) {
            violations.push(`${constr.description || constr.name} (Min: ${constr.value} mm)`);
            change.newValue = constr.value;
          }
        } else if (constr.constraintType === 'max_value' && typeof constr.value === 'number') {
          if (change.newValue > constr.value) {
            violations.push(`${constr.description || constr.name} (Max: ${constr.value} mm)`);
            change.newValue = constr.value;
          }
        }
      }
    }
  }

  return {
    valid: violations.length === 0,
    violations,
    clampedChanges,
  };
}
