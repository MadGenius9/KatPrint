import { FeatureType, GeometryOperation, ParameterUnit } from './featureTypes';

export interface ExpectedParameterDef {
  name: string;
  semanticName: string;
  unit: ParameterUnit;
  defaultValue: number | string | boolean;
  min?: number;
  max?: number;
  description: string;
}

export interface FeatureTypeDefinition {
  type: FeatureType;
  label: string;
  category: 'primary' | 'subtractive' | 'additive' | 'structural' | 'pattern' | 'finishing';
  defaultGeometryOp: GeometryOperation;
  description: string;
  expectedParameters: ExpectedParameterDef[];
  verificationRules?: {
    requiresNonZeroVolume?: boolean;
    requiresHoleDetection?: boolean;
    requiresClearanceCheck?: boolean;
    minWallCheck?: boolean;
  };
}

export const FEATURE_REGISTRY: Record<FeatureType, FeatureTypeDefinition> = {
  BASE_BODY: {
    type: 'BASE_BODY',
    label: 'Base Body',
    category: 'primary',
    defaultGeometryOp: 'base',
    description: 'The foundational primary mass or hull of the component.',
    expectedParameters: [
      { name: 'width', semanticName: 'base_width', unit: 'mm', defaultValue: 100, min: 5, max: 500, description: 'Overall base width along X' },
      { name: 'depth', semanticName: 'base_depth', unit: 'mm', defaultValue: 80, min: 5, max: 500, description: 'Overall base depth along Y' },
      { name: 'height', semanticName: 'base_height', unit: 'mm', defaultValue: 20, min: 1, max: 500, description: 'Overall base height along Z' },
    ],
  },
  PLATE: {
    type: 'PLATE',
    label: 'Mounting / Base Plate',
    category: 'primary',
    defaultGeometryOp: 'base',
    description: 'Flat planar mounting or base surface.',
    expectedParameters: [
      { name: 'width', semanticName: 'plate_width', unit: 'mm', defaultValue: 100, min: 5, max: 500, description: 'Plate width along X' },
      { name: 'depth', semanticName: 'plate_depth', unit: 'mm', defaultValue: 80, min: 5, max: 500, description: 'Plate depth along Y' },
      { name: 'thickness', semanticName: 'plate_thickness', unit: 'mm', defaultValue: 4, min: 1.5, max: 50, description: 'Plate thickness along Z' },
    ],
  },
  WALL: {
    type: 'WALL',
    label: 'Wall / Enclosure Flange',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Vertical or inclined barrier wall.',
    expectedParameters: [
      { name: 'thickness', semanticName: 'wall_thickness', unit: 'mm', defaultValue: 3, min: 1.2, max: 30, description: 'Structural wall thickness' },
      { name: 'height', semanticName: 'wall_height', unit: 'mm', defaultValue: 40, min: 2, max: 400, description: 'Wall height' },
    ],
  },
  SHELL: {
    type: 'SHELL',
    label: 'Hollow Shell',
    category: 'additive',
    defaultGeometryOp: 'base',
    description: 'Hollow outer housing envelope.',
    expectedParameters: [
      { name: 'wallThickness', semanticName: 'shell_wall_thickness', unit: 'mm', defaultValue: 2.8, min: 1.2, max: 20, description: 'Uniform shell wall thickness' },
    ],
  },
  CAVITY: {
    type: 'CAVITY',
    label: 'Internal Cavity',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'Subtracted volume designed to house or cradle an object.',
    expectedParameters: [
      { name: 'width', semanticName: 'cavity_width', unit: 'mm', defaultValue: 60, min: 1, max: 400, description: 'Internal cavity width' },
      { name: 'depth', semanticName: 'cavity_depth', unit: 'mm', defaultValue: 40, min: 1, max: 400, description: 'Internal cavity depth' },
      { name: 'height', semanticName: 'cavity_height', unit: 'mm', defaultValue: 25, min: 1, max: 400, description: 'Internal cavity depth/height' },
      { name: 'clearance', semanticName: 'cavity_clearance', unit: 'mm', defaultValue: 1.5, min: 0.2, max: 10, description: 'Fit clearance around target' },
    ],
  },
  POCKET: {
    type: 'POCKET',
    label: 'Pocket / Recess',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'Blind recessed pocket or indentation.',
    expectedParameters: [
      { name: 'width', semanticName: 'pocket_width', unit: 'mm', defaultValue: 30, min: 1, max: 400, description: 'Pocket width' },
      { name: 'depth', semanticName: 'pocket_depth', unit: 'mm', defaultValue: 30, min: 1, max: 400, description: 'Pocket depth' },
      { name: 'recessDepth', semanticName: 'pocket_recess_depth', unit: 'mm', defaultValue: 5, min: 0.5, max: 100, description: 'Depth of recess' },
    ],
  },
  HOLE: {
    type: 'HOLE',
    label: 'Through Hole',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'Circular through-hole for fasteners, pins, or wiring.',
    expectedParameters: [
      { name: 'diameter', semanticName: 'hole_diameter', unit: 'mm', defaultValue: 5, min: 0.8, max: 100, description: 'Hole diameter' },
      { name: 'depth', semanticName: 'hole_depth', unit: 'mm', defaultValue: 20, min: 1, max: 300, description: 'Hole cylinder depth' },
      { name: 'positionX', semanticName: 'hole_pos_x', unit: 'mm', defaultValue: 0, description: 'X position relative to origin' },
      { name: 'positionY', semanticName: 'hole_pos_y', unit: 'mm', defaultValue: 0, description: 'Y position relative to origin' },
    ],
  },
  COUNTERBORE: {
    type: 'COUNTERBORE',
    label: 'Counterbored Hole',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'Stepped cylindrical hole for socket head cap screws.',
    expectedParameters: [
      { name: 'holeDiameter', semanticName: 'cb_hole_diameter', unit: 'mm', defaultValue: 5, min: 1, max: 50, description: 'Inner clearance hole diameter' },
      { name: 'boreDiameter', semanticName: 'cb_bore_diameter', unit: 'mm', defaultValue: 9.5, min: 2, max: 80, description: 'Outer head recess diameter' },
      { name: 'boreDepth', semanticName: 'cb_bore_depth', unit: 'mm', defaultValue: 5.5, min: 0.5, max: 40, description: 'Head recess depth' },
    ],
  },
  COUNTERSINK: {
    type: 'COUNTERSINK',
    label: 'Countersunk Hole',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'Conical recessed hole for flat-head wood or machine screws.',
    expectedParameters: [
      { name: 'holeDiameter', semanticName: 'cs_hole_diameter', unit: 'mm', defaultValue: 4.5, min: 1, max: 40, description: 'Shaft clearance diameter' },
      { name: 'headDiameter', semanticName: 'cs_head_diameter', unit: 'mm', defaultValue: 9, min: 2, max: 60, description: 'Top surface conical head diameter' },
      { name: 'headAngleDeg', semanticName: 'cs_head_angle', unit: 'deg', defaultValue: 90, min: 60, max: 120, description: 'Countersink angle (standard 90 deg)' },
    ],
  },
  THREADED_HOLE: {
    type: 'THREADED_HOLE',
    label: 'Threaded / Heat-Set Insert Hole',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'Tapered pilot hole sized for brass heat-set threaded inserts.',
    expectedParameters: [
      { name: 'insertDiameter', semanticName: 'insert_diameter', unit: 'mm', defaultValue: 4.6, min: 1.5, max: 20, description: 'Outer insert pilot hole diameter' },
      { name: 'insertDepth', semanticName: 'insert_depth', unit: 'mm', defaultValue: 6.0, min: 2, max: 30, description: 'Pilot hole depth' },
    ],
  },
  SLOT: {
    type: 'SLOT',
    label: 'Elongated Slot',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'Elongated rectangular or stadium slot for adjustment or venting.',
    expectedParameters: [
      { name: 'width', semanticName: 'slot_width', unit: 'mm', defaultValue: 6, min: 1, max: 150, description: 'Slot width' },
      { name: 'length', semanticName: 'slot_length', unit: 'mm', defaultValue: 25, min: 2, max: 300, description: 'Slot total length' },
      { name: 'depth', semanticName: 'slot_depth', unit: 'mm', defaultValue: 10, min: 0.5, max: 100, description: 'Through slot depth' },
    ],
  },
  CHANNEL: {
    type: 'CHANNEL',
    label: 'Channel / Groove',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'Routing channel for wires, cables, or sliding inserts.',
    expectedParameters: [
      { name: 'width', semanticName: 'channel_width', unit: 'mm', defaultValue: 8, min: 1, max: 100, description: 'Channel track width' },
      { name: 'depth', semanticName: 'channel_depth', unit: 'mm', defaultValue: 6, min: 1, max: 100, description: 'Channel track depth' },
    ],
  },
  CUTOUT: {
    type: 'CUTOUT',
    label: 'Clearance Cutout',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'General geometric subtraction to provide clearance or access.',
    expectedParameters: [
      { name: 'width', semanticName: 'cutout_width', unit: 'mm', defaultValue: 30, min: 1, max: 300, description: 'Cutout width' },
      { name: 'height', semanticName: 'cutout_height', unit: 'mm', defaultValue: 20, min: 1, max: 300, description: 'Cutout height' },
    ],
  },
  BOSS: {
    type: 'BOSS',
    label: 'Mounting Boss',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Raised circular or hexagonal cylindrical pillar for screws or inserts.',
    expectedParameters: [
      { name: 'outerDiameter', semanticName: 'boss_outer_diameter', unit: 'mm', defaultValue: 10, min: 3, max: 60, description: 'Outer boss diameter' },
      { name: 'height', semanticName: 'boss_height', unit: 'mm', defaultValue: 12, min: 2, max: 150, description: 'Boss height above surface' },
      { name: 'innerHoleDiameter', semanticName: 'boss_inner_diameter', unit: 'mm', defaultValue: 3.2, min: 0.8, max: 40, description: 'Pilot hole diameter inside boss' },
    ],
  },
  STANDOFF: {
    type: 'STANDOFF',
    label: 'PCB / Component Standoff',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Elevated post to support circuit boards or secondary plates.',
    expectedParameters: [
      { name: 'diameter', semanticName: 'standoff_diameter', unit: 'mm', defaultValue: 7, min: 3, max: 40, description: 'Standoff outer diameter' },
      { name: 'height', semanticName: 'standoff_height', unit: 'mm', defaultValue: 8, min: 2, max: 100, description: 'Height elevating PCB' },
      { name: 'pilotHoleDiameter', semanticName: 'standoff_pilot_diameter', unit: 'mm', defaultValue: 2.8, min: 1, max: 20, description: 'Screw pilot diameter' },
    ],
  },
  RIB: {
    type: 'RIB',
    label: 'Reinforcing Rib',
    category: 'structural',
    defaultGeometryOp: 'add',
    description: 'Thin web reinforcing perpendicular walls against bending.',
    expectedParameters: [
      { name: 'thickness', semanticName: 'rib_thickness', unit: 'mm', defaultValue: 2.4, min: 1.2, max: 20, description: 'Rib web thickness' },
      { name: 'height', semanticName: 'rib_height', unit: 'mm', defaultValue: 25, min: 2, max: 200, description: 'Rib vertical height' },
      { name: 'length', semanticName: 'rib_length', unit: 'mm', defaultValue: 30, min: 2, max: 300, description: 'Rib horizontal run' },
    ],
  },
  GUSSET: {
    type: 'GUSSET',
    label: 'Corner Gusset',
    category: 'structural',
    defaultGeometryOp: 'add',
    description: 'Triangular reinforcement brace bridging 90-degree internal corners.',
    expectedParameters: [
      { name: 'thickness', semanticName: 'gusset_thickness', unit: 'mm', defaultValue: 3, min: 1.2, max: 25, description: 'Gusset thickness' },
      { name: 'size', semanticName: 'gusset_size', unit: 'mm', defaultValue: 15, min: 3, max: 100, description: 'Gusset leg length' },
    ],
  },
  LIP: {
    type: 'LIP',
    label: 'Retaining Lip / Rim',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Raised perimeter edge preventing contained objects from slipping off.',
    expectedParameters: [
      { name: 'height', semanticName: 'lip_height', unit: 'mm', defaultValue: 6, min: 1, max: 50, description: 'Lip height above floor' },
      { name: 'thickness', semanticName: 'lip_thickness', unit: 'mm', defaultValue: 3, min: 1.2, max: 20, description: 'Lip boundary thickness' },
    ],
  },
  FLANGE: {
    type: 'FLANGE',
    label: 'Mounting Flange',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Projecting collar or rim for securing or fastening to another surface.',
    expectedParameters: [
      { name: 'extension', semanticName: 'flange_extension', unit: 'mm', defaultValue: 15, min: 3, max: 150, description: 'Flange overhang extension' },
      { name: 'thickness', semanticName: 'flange_thickness', unit: 'mm', defaultValue: 4, min: 1.5, max: 30, description: 'Flange thickness' },
    ],
  },
  HOOK: {
    type: 'HOOK',
    label: 'Hanging Hook',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Curved or J-profile cantilever hook.',
    expectedParameters: [
      { name: 'throatDepth', semanticName: 'hook_throat_depth', unit: 'mm', defaultValue: 25, min: 5, max: 150, description: 'Hook inner opening depth' },
      { name: 'tipHeight', semanticName: 'hook_tip_height', unit: 'mm', defaultValue: 15, min: 3, max: 100, description: 'Hook front tip retention height' },
      { name: 'thickness', semanticName: 'hook_thickness', unit: 'mm', defaultValue: 8, min: 3, max: 40, description: 'Hook arm thickness' },
    ],
  },
  CLIP: {
    type: 'CLIP',
    label: 'Retention Clip',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Flexible retention clip or clamp.',
    expectedParameters: [
      { name: 'gap', semanticName: 'clip_gap', unit: 'mm', defaultValue: 10, min: 1, max: 80, description: 'Clip gripping opening' },
      { name: 'armThickness', semanticName: 'clip_arm_thickness', unit: 'mm', defaultValue: 2.8, min: 1.5, max: 15, description: 'Clip arm spring thickness' },
    ],
  },
  TAB: {
    type: 'TAB',
    label: 'Mounting / Interlocking Tab',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Protruding indexing or alignment tab.',
    expectedParameters: [
      { name: 'width', semanticName: 'tab_width', unit: 'mm', defaultValue: 12, min: 2, max: 100, description: 'Tab width' },
      { name: 'length', semanticName: 'tab_length', unit: 'mm', defaultValue: 8, min: 2, max: 60, description: 'Tab extension' },
      { name: 'thickness', semanticName: 'tab_thickness', unit: 'mm', defaultValue: 3, min: 1.2, max: 20, description: 'Tab thickness' },
    ],
  },
  SNAP_FIT: {
    type: 'SNAP_FIT',
    label: 'Cantilever Snap-Fit',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Flexible cantilever beam with latching head for toolless jointing.',
    expectedParameters: [
      { name: 'beamLength', semanticName: 'snap_beam_length', unit: 'mm', defaultValue: 20, min: 5, max: 80, description: 'Cantilever beam flex length' },
      { name: 'beamThickness', semanticName: 'snap_beam_thickness', unit: 'mm', defaultValue: 2.2, min: 1.2, max: 8, description: 'Cantilever beam thickness' },
      { name: 'catchDepth', semanticName: 'snap_catch_depth', unit: 'mm', defaultValue: 1.8, min: 0.5, max: 10, description: 'Latch tooth overhang' },
    ],
  },
  RAIL: {
    type: 'RAIL',
    label: 'Guide Rail / Slide Track',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Linear guiding extrusion.',
    expectedParameters: [
      { name: 'width', semanticName: 'rail_width', unit: 'mm', defaultValue: 8, min: 2, max: 50, description: 'Rail guide width' },
      { name: 'height', semanticName: 'rail_height', unit: 'mm', defaultValue: 5, min: 1.5, max: 50, description: 'Rail guide height' },
      { name: 'length', semanticName: 'rail_length', unit: 'mm', defaultValue: 80, min: 10, max: 400, description: 'Rail track length' },
    ],
  },
  CRADLE: {
    type: 'CRADLE',
    label: 'Ergonomic Device Cradle',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Curved or contoured holding arms supporting controllers, phones, or tools.',
    expectedParameters: [
      { name: 'cradleWidth', semanticName: 'cradle_width', unit: 'mm', defaultValue: 120, min: 20, max: 300, description: 'Overall cradle span' },
      { name: 'cradleDepth', semanticName: 'cradle_depth', unit: 'mm', defaultValue: 60, min: 10, max: 200, description: 'Cradle resting depth' },
      { name: 'cradleAngle', semanticName: 'cradle_angle', unit: 'deg', defaultValue: 15, min: 0, max: 60, description: 'Tilt angle for ergonomics' },
    ],
  },
  SUPPORT: {
    type: 'SUPPORT',
    label: 'Internal / Surface Support',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Raised support pad, pylon, or spacer structure.',
    expectedParameters: [
      { name: 'height', semanticName: 'support_height', unit: 'mm', defaultValue: 5, min: 1, max: 100, description: 'Support elevation' },
      { name: 'width', semanticName: 'support_width', unit: 'mm', defaultValue: 15, min: 2, max: 200, description: 'Support footprint' },
    ],
  },
  FOOT: {
    type: 'FOOT',
    label: 'Non-Slip / Elevated Foot',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Base standoff foot or recess for rubber bumper pads.',
    expectedParameters: [
      { name: 'diameter', semanticName: 'foot_diameter', unit: 'mm', defaultValue: 12, min: 3, max: 50, description: 'Foot diameter' },
      { name: 'height', semanticName: 'foot_height', unit: 'mm', defaultValue: 3, min: 0.5, max: 30, description: 'Foot elevation' },
    ],
  },
  HINGE: {
    type: 'HINGE',
    label: 'Print-in-Place / Pin Hinge',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Pivot knuckle joint for folding lids or articulation.',
    expectedParameters: [
      { name: 'pinDiameter', semanticName: 'hinge_pin_diameter', unit: 'mm', defaultValue: 3, min: 1.5, max: 15, description: 'Pivot pin shaft diameter' },
      { name: 'knuckleOuterDiameter', semanticName: 'hinge_knuckle_diameter', unit: 'mm', defaultValue: 8, min: 3, max: 30, description: 'Knuckle outer wall diameter' },
      { name: 'clearance', semanticName: 'hinge_clearance', unit: 'mm', defaultValue: 0.4, min: 0.2, max: 1.0, description: 'Print-in-place rotational gap' },
    ],
  },
  DOVETAIL: {
    type: 'DOVETAIL',
    label: 'Dovetail Interlock Joint',
    category: 'additive',
    defaultGeometryOp: 'add',
    description: 'Trapezoidal interlocking joint for modular assembly.',
    expectedParameters: [
      { name: 'width', semanticName: 'dovetail_width', unit: 'mm', defaultValue: 12, min: 3, max: 60, description: 'Dovetail base width' },
      { name: 'depth', semanticName: 'dovetail_depth', unit: 'mm', defaultValue: 8, min: 2, max: 40, description: 'Dovetail slide depth' },
      { name: 'angle', semanticName: 'dovetail_angle', unit: 'deg', defaultValue: 15, min: 8, max: 30, description: 'Flaring angle' },
    ],
  },
  DRAINAGE_HOLE: {
    type: 'DRAINAGE_HOLE',
    label: 'Drainage / Weep Hole',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'Through hole allowing water or liquid egress.',
    expectedParameters: [
      { name: 'diameter', semanticName: 'drain_hole_diameter', unit: 'mm', defaultValue: 4, min: 1.5, max: 25, description: 'Drainage hole diameter' },
    ],
  },
  DRAINAGE_SLOT: {
    type: 'DRAINAGE_SLOT',
    label: 'Drainage Slot / Louver',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'Subtracted slot for liquid runoff (soap dishes, planters).',
    expectedParameters: [
      { name: 'width', semanticName: 'drain_slot_width', unit: 'mm', defaultValue: 4, min: 1.5, max: 30, description: 'Drainage slot width' },
      { name: 'length', semanticName: 'drain_slot_length', unit: 'mm', defaultValue: 40, min: 5, max: 200, description: 'Drainage slot length' },
    ],
  },
  CABLE_OPENING: {
    type: 'CABLE_OPENING',
    label: 'Cable Pass-Through Opening',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'Opening sized for USB, power cables, and connector heads.',
    expectedParameters: [
      { name: 'width', semanticName: 'cable_opening_width', unit: 'mm', defaultValue: 15, min: 5, max: 80, description: 'Cable opening width (clears connector head)' },
      { name: 'depth', semanticName: 'cable_opening_depth', unit: 'mm', defaultValue: 10, min: 3, max: 50, description: 'Cable opening depth' },
    ],
  },
  VENT: {
    type: 'VENT',
    label: 'Ventilation Grille',
    category: 'subtractive',
    defaultGeometryOp: 'subtract',
    description: 'Airflow grille slot or honeycomb opening.',
    expectedParameters: [
      { name: 'slotWidth', semanticName: 'vent_slot_width', unit: 'mm', defaultValue: 2.5, min: 1, max: 15, description: 'Individual vent slot width' },
      { name: 'spacing', semanticName: 'vent_spacing', unit: 'mm', defaultValue: 5, min: 2, max: 30, description: 'Pitch between slots' },
    ],
  },
  TEXT: {
    type: 'TEXT',
    label: 'Embossed / Engraved Text',
    category: 'finishing',
    defaultGeometryOp: 'add',
    description: '3D label or branding text.',
    expectedParameters: [
      { name: 'height', semanticName: 'text_extrusion_height', unit: 'mm', defaultValue: 0.8, min: 0.2, max: 10, description: 'Embossing relief height' },
    ],
  },
  PATTERN_LINEAR: {
    type: 'PATTERN_LINEAR',
    label: 'Linear Array Pattern',
    category: 'pattern',
    defaultGeometryOp: 'pattern',
    description: '1D or 2D repeating grid pattern of child features.',
    expectedParameters: [
      { name: 'count', semanticName: 'pattern_count', unit: 'count', defaultValue: 4, min: 2, max: 50, description: 'Number of instances' },
      { name: 'spacing', semanticName: 'pattern_spacing', unit: 'mm', defaultValue: 20, min: 1, max: 300, description: 'Center-to-center spacing' },
    ],
  },
  PATTERN_CIRCULAR: {
    type: 'PATTERN_CIRCULAR',
    label: 'Circular / Polar Pattern',
    category: 'pattern',
    defaultGeometryOp: 'pattern',
    description: 'Radial repeating circular array around a center axis.',
    expectedParameters: [
      { name: 'count', semanticName: 'pattern_count', unit: 'count', defaultValue: 6, min: 2, max: 64, description: 'Number of radial instances' },
      { name: 'pitchRadius', semanticName: 'pattern_pitch_radius', unit: 'mm', defaultValue: 35, min: 5, max: 300, description: 'Bolt circle / pitch radius' },
    ],
  },
  FILLET: {
    type: 'FILLET',
    label: 'Edge Fillet',
    category: 'finishing',
    defaultGeometryOp: 'finish',
    description: 'Concave or convex rounding along edges to reduce stress concentration.',
    expectedParameters: [
      { name: 'radius', semanticName: 'fillet_radius', unit: 'mm', defaultValue: 2, min: 0.5, max: 50, description: 'Fillet radius' },
    ],
  },
  CHAMFER: {
    type: 'CHAMFER',
    label: 'Edge Chamfer',
    category: 'finishing',
    defaultGeometryOp: 'finish',
    description: 'Beveled 45-degree corner edge for clean print lead-in and ease of insertion.',
    expectedParameters: [
      { name: 'size', semanticName: 'chamfer_size', unit: 'mm', defaultValue: 1.5, min: 0.2, max: 30, description: 'Chamfer setback dimension' },
    ],
  },
  ROUNDING: {
    type: 'ROUNDING',
    label: 'Corner Rounding',
    category: 'finishing',
    defaultGeometryOp: 'finish',
    description: 'Rounded external corners for ergonomic and aesthetic handling.',
    expectedParameters: [
      { name: 'radius', semanticName: 'rounding_radius', unit: 'mm', defaultValue: 4, min: 1, max: 50, description: 'Corner rounding radius' },
    ],
  },
  CUSTOM_PARAMETRIC: {
    type: 'CUSTOM_PARAMETRIC',
    label: 'Custom Parametric Geometry',
    category: 'primary',
    defaultGeometryOp: 'add',
    description: 'Application-specific custom parametric geometry.',
    expectedParameters: [],
  },
};

export function getFeatureTypeDefinition(type: FeatureType): FeatureTypeDefinition {
  return FEATURE_REGISTRY[type] || FEATURE_REGISTRY.CUSTOM_PARAMETRIC;
}

export function getAllFeatureTypes(): FeatureTypeDefinition[] {
  return Object.values(FEATURE_REGISTRY);
}
