import {
  DesignSpecification,
  DesignCheck,
  DesignCheckType,
  DesignCheckImportance,
} from '../../types';
import { validateDesignSpecification } from './designSpecification';

export function buildDesignChecklist(rawSpec: DesignSpecification): DesignCheck[] {
  const spec = validateDesignSpecification(rawSpec, rawSpec?.originalPrompt || '');
  const checks: DesignCheck[] = [];
  let counter = 1;

  // 1. Manifold & Geometry Sanity (Always CRITICAL)
  checks.push({
    id: `chk_${counter++}_manifold`,
    description: '3D geometry must be a closed, watertight, manifold mesh with finite coordinates',
    type: 'PRINTABILITY',
    importance: 'CRITICAL',
    verificationMethod: 'deterministic_geom',
    expected: true,
    status: 'UNKNOWN',
    notes: 'Checks non-manifold edge count == 0 and vertex validity',
  });

  checks.push({
    id: `chk_${counter++}_volume`,
    description: '3D model must have real, non-zero physical volume',
    type: 'STRUCTURE',
    importance: 'CRITICAL',
    verificationMethod: 'deterministic_geom',
    expected: true,
    status: 'UNKNOWN',
    notes: 'Signed tetrahedron volume calculation > 0 mm³',
  });

  checks.push({
    id: `chk_${counter++}_flat_base`,
    description: 'Model base must sit flat at Z=0 for print bed adhesion',
    type: 'PRINTABILITY',
    importance: 'CRITICAL',
    verificationMethod: 'deterministic_geom',
    expected: true,
    status: 'UNKNOWN',
    notes: 'Verifies Z_min is 0 mm',
  });

  const explicitDims = Array.isArray(spec.explicitDimensions) ? spec.explicitDimensions : [];
  const inferredDims = Array.isArray(spec.inferredDimensions) ? spec.inferredDimensions : [];
  const compatTargets = Array.isArray(spec.compatibilityTargets) ? spec.compatibilityTargets : [];
  const mountReqs = Array.isArray(spec.mountingRequirements) ? spec.mountingRequirements : [];
  const reqFeatures = Array.isArray(spec.requiredFeatures) ? spec.requiredFeatures : [];
  const structReqs = Array.isArray(spec.structuralRequirements) ? spec.structuralRequirements : [];

  // 2. Explicit Dimensions
  for (const dim of explicitDims) {
    checks.push({
      id: `chk_${counter++}_dim_${(dim.name || 'dim').toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
      description: `Dimension "${dim.name}" matches ${dim.value} mm within ±${dim.toleranceMm || 1.5} mm`,
      type: 'DIMENSION',
      importance: dim.isCritical ? 'CRITICAL' : 'IMPORTANT',
      axis: dim.axis,
      verificationMethod: 'deterministic_geom',
      expected: dim.value,
      tolerance: dim.toleranceMm || 1.5,
      status: 'UNKNOWN',
      notes: `Explicit dimension from prompt: ${dim.description || dim.name}`,
    });
  }

  // 3. Inferred Dimensions (if no explicit dimensions)
  if (explicitDims.length === 0) {
    for (const dim of inferredDims) {
      checks.push({
        id: `chk_${counter++}_inferred_dim_${(dim.name || 'dim').toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
        description: `Dimension "${dim.name}" is reasonably scaled around ${dim.value} mm (±${dim.toleranceMm || 4.0} mm)`,
        type: 'DIMENSION',
        importance: 'IMPORTANT',
        axis: dim.axis,
        verificationMethod: 'deterministic_geom',
        expected: dim.value,
        tolerance: dim.toleranceMm || 4.0,
        status: 'UNKNOWN',
        notes: `Inferred baseline dimension for ${spec.primaryObject}`,
      });
    }
  }

  // 4. Compatibility Targets & Clearances
  for (const target of compatTargets) {
    checks.push({
      id: `chk_${counter++}_compat_${(target.name || 'target').toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
      description: `Accommodates "${target.name}" (${target.relationship}) with +${target.clearanceMm} mm clearance`,
      type: 'FIT',
      importance: 'CRITICAL',
      verificationMethod: 'deterministic_geom',
      expected: `${target.relationship} ${target.name} (+${target.clearanceMm}mm)`,
      status: 'UNKNOWN',
      notes: target.notes || `Fit verification for reference item ${target.name}`,
    });
  }

  // 4b. Mounting Requirements
  for (const mount of mountReqs) {
    checks.push({
      id: `chk_${counter++}_mount_${counter}`,
      description: `Mounting Requirement: ${mount}`,
      type: 'STRUCTURE',
      importance: 'IMPORTANT',
      verificationMethod: 'source_code',
      expected: mount,
      status: 'UNKNOWN',
      notes: `Mounting interface and installation clearances`,
    });
  }

  // 5. Required Functional Features
  for (const feat of reqFeatures) {
    const featName = feat.name || 'Feature';
    const isDrainage = featName.toLowerCase().includes('drain') || featName.toLowerCase().includes('slot');
    const isCable = featName.toLowerCase().includes('cable') || featName.toLowerCase().includes('wire');
    const isHole = featName.toLowerCase().includes('hole') || featName.toLowerCase().includes('mount') || featName.toLowerCase().includes('screw');

    checks.push({
      id: `chk_${counter++}_feat_${feat.id || featName.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
      description: `Required Feature: ${featName} — ${feat.description || ''}`,
      type: isDrainage || isCable ? 'RELATIONSHIP' : isHole ? 'STRUCTURE' : 'FEATURE',
      importance: feat.confidence > 0.85 ? 'CRITICAL' : 'IMPORTANT',
      verificationMethod: 'ai_vision',
      expected: true,
      status: 'UNKNOWN',
      notes: feat.reason || `Essential feature for ${spec.primaryObject}`,
    });
  }

  // 6. Wall Thickness & Structural Requirements
  for (const req of structReqs) {
    checks.push({
      id: `chk_${counter++}_struct_${counter}`,
      description: `Structural Requirement: ${req}`,
      type: 'STRUCTURE',
      importance: 'IMPORTANT',
      verificationMethod: 'deterministic_geom',
      expected: req,
      status: 'UNKNOWN',
      notes: 'Verified via geometric wall thickness & volume',
    });
  }

  // 7. Visual Fidelity & Overall Appearance
  checks.push({
    id: `chk_${counter++}_visual_fidelity`,
    description: `Generated 3D model visually and mechanically functions as a "${spec.primaryObject}"`,
    type: 'VISUAL',
    importance: 'CRITICAL',
    verificationMethod: 'ai_vision',
    expected: spec.intendedFunction,
    status: 'UNKNOWN',
    notes: 'Multi-view rendered snapshot inspection by AI reviewer',
  });

  return checks;
}

export const generateDesignChecklist = buildDesignChecklist;
