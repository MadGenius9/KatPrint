import { DesignFeature, FitRequirement, PrintRequirement, DesignAssumption, RequirementSource } from '../../types';

export interface CategoryKnowledgeRule {
  category: string;
  keywords: string[];
  defaultIntendedFunction: string;
  defaultMountingStyle: string;
  defaultDimensions?: {
    width?: number;
    depth?: number;
    height?: number;
  };
  inferredFeatures: Array<{
    id: string;
    name: string;
    description: string;
    reason: string;
    importance: 'CRITICAL' | 'IMPORTANT' | 'OPTIONAL';
  }>;
  fitRules: Array<{
    target: string;
    defaultClearanceMm: number;
    fitType: 'loose' | 'snug' | 'snap-fit' | 'press-fit' | 'slide-in' | 'clearance';
    reason: string;
  }>;
  printRules: {
    orientation: string;
    flatBaseRequired: boolean;
    minWallThicknessMm: number;
    supportFreeGoal: boolean;
    maxOverhangAngleDeg: number;
  };
  commonAssumptions: string[];
}

export const COMMON_SENSE_RULES: CategoryKnowledgeRule[] = [
  {
    category: 'SOAP_DISH',
    keywords: ['soap dish', 'soap tray', 'soap holder', 'bar soap', 'soap stand', 'squatch'],
    defaultIntendedFunction: 'Elevate soap bar above standing water, allow rapid drainage and 360-degree airflow drying to prevent softening',
    defaultMountingStyle: 'desktop / countertop',
    inferredFeatures: [
      {
        id: 'feat_drainage',
        name: 'Drainage Slots or Channels',
        description: 'Through-slots or sloped channels (3.5-5.0 mm wide) allowing accumulated water to drain freely',
        reason: 'Prevents soap bar from sitting in water pool and degrading',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_drying_ribs',
        name: 'Raised Airflow Drying Ribs',
        description: 'Elevated contact ridges (3.0-4.5 mm height) with minimal surface contact',
        reason: 'Lifts soap off the base plate for airflow',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_retaining_rim',
        name: 'Perimeter Retaining Rim',
        description: 'Outer perimeter lip or chamfered rim (8.0-14.0 mm height) to contain soap bar securely',
        reason: 'Prevents wet soap from sliding off countertop',
        importance: 'IMPORTANT',
      },
      {
        id: 'feat_filleted_corners',
        name: 'Ergonomic Rounded Corners',
        description: 'Smooth filleted outer edges (4.0-8.0 mm radius)',
        reason: 'Comfortable handling and easy cleaning',
        importance: 'OPTIONAL',
      },
    ],
    fitRules: [
      {
        target: 'Soap Bar',
        defaultClearanceMm: 2.5,
        fitType: 'loose',
        reason: 'Allows easy drop-in and removal even when wet or swollen with water',
      },
    ],
    printRules: {
      orientation: 'Flat on build plate at Z=0',
      flatBaseRequired: true,
      minWallThicknessMm: 2.8,
      supportFreeGoal: true,
      maxOverhangAngleDeg: 45,
    },
    commonAssumptions: [
      'Bathroom vanity, shower ledge, or kitchen countertop use',
      'Requires water drainage and elevated airflow ribs',
      'Printed flat on build plate without support material',
    ],
  },
  {
    category: 'PHONE_STAND',
    keywords: ['phone stand', 'phone holder', 'phone dock', 'iphone stand', 'smartphone stand', 'tablet stand', 'desk stand'],
    defaultIntendedFunction: 'Hold smartphone at comfortable viewing angle with cable pass-through for charging while docked',
    defaultMountingStyle: 'desktop / tabletop',
    inferredFeatures: [
      {
        id: 'feat_angled_backrest',
        name: 'Ergonomic Angled Backrest',
        description: 'Back support angled between 65° and 75° for optimal hands-free desk viewing',
        reason: 'Prevents phone from falling forward while providing comfortable viewing angle',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_retaining_lip',
        name: 'Front Retaining Lip',
        description: 'Front shelf lip with 12.0-16.0 mm depth to capture phone with case',
        reason: 'Prevents phone from sliding off shelf',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_cable_pass',
        name: 'Bottom Cable Pass-Through Slot',
        description: 'Central bottom slot (12.0-16.0 mm wide) allowing charging cable connector insertion while standing',
        reason: 'Allows charging without turning phone upside down',
        importance: 'IMPORTANT',
      },
      {
        id: 'feat_weighted_base',
        name: 'Stable Weighted Footprint',
        description: 'Wide base plate (depth >= 75 mm) extending backward to prevent tipping when tapping screen',
        reason: 'Screen tap stability',
        importance: 'CRITICAL',
      },
    ],
    fitRules: [
      {
        target: 'Smartphone with Case',
        defaultClearanceMm: 3.0,
        fitType: 'loose',
        reason: 'Accommodates standard protective cases up to 14mm thickness',
      },
    ],
    printRules: {
      orientation: 'Side profile or flat base on build plate',
      flatBaseRequired: true,
      minWallThicknessMm: 3.2,
      supportFreeGoal: true,
      maxOverhangAngleDeg: 45,
    },
    commonAssumptions: [
      'Desktop or nightstand hands-free viewing',
      'Cable slot needed for bottom charging',
      'Stable wide footprint to avoid tipping during touch interaction',
    ],
  },
  {
    category: 'CONTROLLER_HOLDER',
    keywords: ['controller holder', 'xbox controller', 'ps5 controller', 'game controller', 'controller mount', 'gamepad mount', 'controller dock'],
    defaultIntendedFunction: 'Securely cradle game controller, protecting trigger and joystick mechanisms while enabling quick single-handed retrieval',
    defaultMountingStyle: 'under-desk / wall mount',
    inferredFeatures: [
      {
        id: 'feat_cradle_arms',
        name: 'Contoured Grip Support Arms',
        description: 'Ergonomic dual-arm cradle matching controller handle curves',
        reason: 'Evenly distributes weight and holds controller securely',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_trigger_clearance',
        name: 'Trigger & Bumper Clearance Relief',
        description: 'Recessed rear/top geometry preventing accidental trigger or bumper button depression',
        reason: 'Protects spring-loaded triggers from constant wear and accidental inputs',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_quick_grab',
        name: 'Low Front Profile for Quick Grab',
        description: 'Open front access allowing natural grip and quick slide-out extraction',
        reason: 'User ergonomic accessibility',
        importance: 'IMPORTANT',
      },
      {
        id: 'feat_mounting_interface',
        name: 'Counterbore Screw Holes / Mounting Plate',
        description: 'Reinforced top or rear mounting flange with countersunk screw holes (M4/M5)',
        reason: 'Secure mechanical mounting to desk underside or wall',
        importance: 'CRITICAL',
      },
    ],
    fitRules: [
      {
        target: 'Game Controller',
        defaultClearanceMm: 2.0,
        fitType: 'snug',
        reason: 'Stable hold without pinching shell or scratching matte surface',
      },
    ],
    printRules: {
      orientation: 'Mounting plate flat against build plate',
      flatBaseRequired: true,
      minWallThicknessMm: 3.5,
      supportFreeGoal: true,
      maxOverhangAngleDeg: 50,
    },
    commonAssumptions: [
      'Under-desk or wall mounting with M4/M5 wood screws',
      'Must avoid trigger and analog stick pressure',
      'Sufficient clearance for quick single-handed removal',
    ],
  },
  {
    category: 'WALL_MOUNT_BRACKET',
    keywords: ['wall mount', 'bracket', 'angle bracket', 'shelf bracket', 'brace', 'corner bracket', 'mount'],
    defaultIntendedFunction: 'Mechanically support loads by fastening securely to vertical or horizontal surfaces',
    defaultMountingStyle: 'wall mount',
    inferredFeatures: [
      {
        id: 'feat_mounting_flange',
        name: 'Mounting Flanges with Counterbore Holes',
        description: 'Mounting surface with 4.5-5.5 mm screw pass-through holes and 8.5 mm counterbores for flush screw heads',
        reason: 'Flush mounting to walls or wood without screw heads protruding',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_structural_gusset',
        name: 'Triangular Reinforcement Gusset / Rib',
        description: 'Structural web (3.5-5.0 mm thick) along the internal corner angle',
        reason: 'Resists cantilever bending deflection under load',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_heavy_walls',
        name: 'Load-Bearing Wall Thickness',
        description: 'Wall thickness >= 4.0 mm for structural rigidity',
        reason: 'Handles mechanical shear and torque loads',
        importance: 'CRITICAL',
      },
    ],
    fitRules: [
      {
        target: 'Mounting Hardware (M4/M5 Screws)',
        defaultClearanceMm: 0.5,
        fitType: 'clearance',
        reason: 'Smooth screw insertion without binding',
      },
    ],
    printRules: {
      orientation: 'Side profile or back flange flat on build plate',
      flatBaseRequired: true,
      minWallThicknessMm: 4.0,
      supportFreeGoal: true,
      maxOverhangAngleDeg: 45,
    },
    commonAssumptions: [
      'FDM printed in PLA/PETG with high wall loops (4+) for strength',
      'Countersunk screw mounting to studs or drywall anchors',
    ],
  },
  {
    category: 'TOOTHBRUSH_HOLDER',
    keywords: ['toothbrush holder', 'tooth brush', 'bathroom organizer', 'dental', 'toothbrush stand'],
    defaultIntendedFunction: 'Hold toothbrushes upright, preventing standing water accumulation and cross-contact',
    defaultMountingStyle: 'desktop / countertop',
    inferredFeatures: [
      {
        id: 'feat_drainage_base',
        name: 'Elevated Drainage Holes & Drip Base',
        description: 'Perforated bottom holes (4.0-6.0 mm) and elevated base legs allowing moisture to escape completely',
        reason: 'Prevents mold and bacteria from standing water at bottom of handle cavity',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_upright_slots',
        name: 'Individual Upright Holding Slots',
        description: 'Divided cylindrical or oval openings (14.0-20.0 mm diameter) to keep brushes separate',
        reason: 'Hygienic separation between brush heads',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_stable_weighted_base',
        name: 'Low Center of Gravity Base',
        description: 'Broad weighted bottom preventing tipping from top-heavy electric toothbrushes',
        reason: 'Physical stability',
        importance: 'IMPORTANT',
      },
    ],
    fitRules: [
      {
        target: 'Toothbrush Handle',
        defaultClearanceMm: 3.0,
        fitType: 'loose',
        reason: 'Easy drop-in insertion and removal without sticking',
      },
    ],
    printRules: {
      orientation: 'Vertical upright orientation with flat base at Z=0',
      flatBaseRequired: true,
      minWallThicknessMm: 2.5,
      supportFreeGoal: true,
      maxOverhangAngleDeg: 45,
    },
    commonAssumptions: [
      'Wet environment requiring complete passive water drainage',
      'Accommodates manual and electric brush handle diameters',
    ],
  },
  {
    category: 'PLANTER_POT',
    keywords: ['planter', 'plant pot', 'pot', 'flower pot', 'succulent', 'self-watering'],
    defaultIntendedFunction: 'Contain potting soil and root ball with optimal drainage or reservoir wicking',
    defaultMountingStyle: 'tabletop / freestanding',
    inferredFeatures: [
      {
        id: 'feat_drainage_hole',
        name: 'Bottom Drainage Port',
        description: 'Central drainage hole (6.0-10.0 mm diameter) or wicking slots',
        reason: 'Prevents root rot from over-watering',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_drip_catch',
        name: 'Integrated Drip Catch Basin / Saucer',
        description: 'Interlocking or integrated saucer rim catching excess drain water',
        reason: 'Protects furniture and surfaces from runoff',
        importance: 'IMPORTANT',
      },
      {
        id: 'feat_sturdy_shell',
        name: 'Watertight Wall Thickness',
        description: 'Walls >= 3.2 mm thick to withstand wet soil expansion pressure',
        reason: 'Long-term structural integrity and water containment',
        importance: 'CRITICAL',
      },
    ],
    fitRules: [
      {
        target: 'Nursery Pot / Root Ball',
        defaultClearanceMm: 5.0,
        fitType: 'loose',
        reason: 'Generous room for soil medium and root growth',
      },
    ],
    printRules: {
      orientation: 'Upright vase-like orientation with base at Z=0',
      flatBaseRequired: true,
      minWallThicknessMm: 3.0,
      supportFreeGoal: true,
      maxOverhangAngleDeg: 45,
    },
    commonAssumptions: [
      'Tabletop or windowsill use',
      'Adequate wall thickness to prevent seepage',
      'Support-free printing in vase orientation',
    ],
  },
  {
    category: 'ENCLOSURE_BOX',
    keywords: ['enclosure', 'box', 'case', 'housing', 'electronics box', 'project box'],
    defaultIntendedFunction: 'Enclose and protect internal electronics or components with accessible lid and cable routing',
    defaultMountingStyle: 'freestanding / surface mount',
    inferredFeatures: [
      {
        id: 'feat_internal_cavity',
        name: 'Spacious Internal Cavity',
        description: 'Hollow inner volume with uniform wall thickness (2.5-3.5 mm)',
        reason: 'Houses internal PCB, wiring, and modules',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_lid_rebate',
        name: 'Stepped Lid Alignment Lip / Rebate',
        description: 'Interlocking 1.5 mm stepped lip with 0.35 mm clearance tolerance',
        reason: 'Precise lid alignment and light/dust sealing',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_corner_standoffs',
        name: 'Corner Screw Standoffs / Mounting Bosses',
        description: 'Internal cylindrical corner bosses for M3/M4 fastening screws',
        reason: 'Secure lid fastening and PCB mounting',
        importance: 'IMPORTANT',
      },
    ],
    fitRules: [
      {
        target: 'Lid Interlock',
        defaultClearanceMm: 0.35,
        fitType: 'snug',
        reason: 'Friction fit lid closure with standard FDM tolerances',
      },
    ],
    printRules: {
      orientation: 'Box base and lid printed flat side down on build plate',
      flatBaseRequired: true,
      minWallThicknessMm: 2.8,
      supportFreeGoal: true,
      maxOverhangAngleDeg: 45,
    },
    commonAssumptions: [
      'Two-part shell (base + lid) or open project box',
      '0.35mm tolerance for mating lid features',
    ],
  },
  {
    category: 'BATTERY_HOLDER',
    keywords: ['battery holder', 'm18', 'dewalt', 'makita', '18650', 'aa battery', 'battery rack', 'battery caddy'],
    defaultIntendedFunction: 'Store and organize battery packs with positive retention and easy slide access',
    defaultMountingStyle: 'wall mount / under-shelf',
    inferredFeatures: [
      {
        id: 'feat_slide_rails',
        name: 'Battery Slide Retention Rails',
        description: 'Matching flange rails with 1.2-1.8 mm clearance matching slide tool slots',
        reason: 'Holds battery securely under vibration or inverted mounting',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_latch_stop',
        name: 'Positive Latch Stop Tab',
        description: 'Rear retention stop preventing battery from sliding through during insertion',
        reason: 'Positive insertion tactile feedback',
        importance: 'CRITICAL',
      },
      {
        id: 'feat_mounting_holes',
        name: 'Countersunk Screw Holes',
        description: 'Countersunk holes for M4 wood screws',
        reason: 'Firm fastening to workshop wall or under-bench surface',
        importance: 'CRITICAL',
      },
    ],
    fitRules: [
      {
        target: 'Battery Pack',
        defaultClearanceMm: 1.5,
        fitType: 'slide-in',
        reason: 'Smooth slide-in engagement without binding',
      },
    ],
    printRules: {
      orientation: 'Mounting plate flat on build plate',
      flatBaseRequired: true,
      minWallThicknessMm: 3.5,
      supportFreeGoal: true,
      maxOverhangAngleDeg: 45,
    },
    commonAssumptions: [
      'Workshop wall or under-shelf mounting',
      'Handles frequent battery insertions and removals',
    ],
  },
];

export function findMatchingKnowledge(prompt: string): CategoryKnowledgeRule | null {
  const p = prompt.toLowerCase();
  for (const rule of COMMON_SENSE_RULES) {
    if (rule.keywords.some((kw) => p.includes(kw))) {
      return rule;
    }
  }
  return null;
}
