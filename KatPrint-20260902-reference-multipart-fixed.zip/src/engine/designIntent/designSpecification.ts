import {
  DesignSpecification,
  CompatibilityTarget,
  DimensionRequirement,
  DesignFeature,
  FitRequirement,
  PrintRequirement,
  DesignAssumption,
  RequirementSource,
  ExtractedRequirements,
} from '../../types';
import { findMatchingKnowledge } from './designKnowledge';

export function createDefaultDesignSpecification(prompt: string): DesignSpecification {
  return {
    originalPrompt: prompt,
    primaryObject: 'Mechanical Component',
    category: 'PARAMETRIC_FUNCTIONAL',
    intendedFunction: 'General manufactured 3D print component',
    targetUseCase: 'General utility',
    mountingStyle: 'freestanding',
    compatibilityTargets: [],
    explicitDimensions: [],
    inferredDimensions: [
      {
        name: 'Overall Width',
        value: 80,
        toleranceMm: 1.5,
        source: 'inferred',
        description: 'Estimated default width',
      },
      {
        name: 'Overall Depth',
        value: 80,
        toleranceMm: 1.5,
        source: 'inferred',
        description: 'Estimated default depth',
      },
      {
        name: 'Overall Height',
        value: 30,
        toleranceMm: 1.5,
        source: 'inferred',
        description: 'Estimated default height',
      },
    ],
    criticalDimensions: [],
    requiredFeatures: [
      {
        id: 'feat_default_base',
        name: 'Flat Base Interface',
        description: 'Planar base surface at Z=0 for build plate adhesion',
        source: 'inferred',
        confidence: 0.95,
        reason: 'Essential for FDM 3D printing',
      },
    ],
    optionalFeatures: [],
    mountingRequirements: [],
    fitRequirements: [],
    ergonomicRequirements: ['Rounded outer corners'],
    structuralRequirements: ['Wall thickness >= 2.8 mm'],
    aestheticRequirements: ['Clean CAD styling'],
    printRequirements: [
      {
        orientation: 'Flat on build plate at Z=0',
        flatBaseRequired: true,
        minWallThicknessMm: 2.8,
        supportFreeGoal: true,
        maxOverhangAngleDeg: 45,
      },
    ],
    assumptions: [
      {
        category: 'material',
        assumption: 'Standard FDM printing in PLA or PETG',
        source: 'inferred',
        confidence: 0.9,
        reason: 'Most common hobbyist 3D printing process',
      },
      {
        category: 'mounting',
        assumption: 'Freestanding or surface mount',
        source: 'inferred',
        confidence: 0.85,
        reason: 'Default when not specified in prompt',
      },
    ],
    unresolvedQuestions: [],
    generationStrategy: 'Parametric CSG modeling with primitives and boolean operations',
    confidence: 85,
  };
}

export function buildDesignSpecification(
  prompt: string,
  reqs?: ExtractedRequirements
): DesignSpecification {
  const fallback = createDefaultDesignSpecification(prompt);
  if (!reqs) return fallback;

  const knowledgeRule = findMatchingKnowledge(prompt);
  const category = (reqs.inferredCategory as any) || (knowledgeRule ? knowledgeRule.category : 'PARAMETRIC_FUNCTIONAL');

  const explicitDimensions: DimensionRequirement[] = [];
  const inferredDimensions: DimensionRequirement[] = [];

  const dims = reqs.overallDimensions;
  const refDims = reqs.referenceObject?.dimensions;
  const refClearance = reqs.referenceObject?.clearanceMm || 2.0;
  const planDims = reqs.designPlan?.inferredDimensions;

  // 1. Width / X Axis
  if (dims?.width) {
    explicitDimensions.push({
      name: 'Overall Width',
      value: dims.width,
      toleranceMm: 1.5,
      axis: 'x',
      source: 'explicit',
      description: 'Width specified in prompt',
    });
  } else if (refDims?.width) {
    const calculatedWidth = Number(refDims.width) + refClearance * 2 + 6.0; // item + 2x clearance + 2x wall
    inferredDimensions.push({
      name: 'Overall Width',
      value: Math.round(calculatedWidth * 10) / 10,
      toleranceMm: 2.0,
      axis: 'x',
      source: 'reference_database',
      description: `Inferred width sized for ${reqs.referenceObject?.name || 'reference item'} + ${refClearance}mm clearance`,
    });
  } else if (planDims?.width) {
    inferredDimensions.push({
      name: 'Overall Width',
      value: planDims.width,
      toleranceMm: 2.5,
      axis: 'x',
      source: 'inferred',
      description: 'AI design plan inferred width',
    });
  } else if (knowledgeRule?.defaultDimensions?.width) {
    inferredDimensions.push({
      name: 'Overall Width',
      value: knowledgeRule.defaultDimensions.width,
      toleranceMm: 3.0,
      axis: 'x',
      source: 'inferred',
      description: 'Knowledge base typical width',
    });
  } else {
    inferredDimensions.push({
      name: 'Overall Width',
      value: 80,
      toleranceMm: 3.0,
      axis: 'x',
      source: 'inferred',
      description: 'Estimated default width',
    });
  }

  // 2. Depth / Y Axis
  const specifiedDepth = dims?.depth || dims?.length;
  if (specifiedDepth) {
    explicitDimensions.push({
      name: 'Overall Depth',
      value: specifiedDepth,
      toleranceMm: 1.5,
      axis: 'y',
      source: 'explicit',
      description: 'Depth/length specified in prompt',
    });
  } else if (refDims?.depth) {
    const calculatedDepth = Number(refDims.depth) + refClearance * 2 + 6.0;
    inferredDimensions.push({
      name: 'Overall Depth',
      value: Math.round(calculatedDepth * 10) / 10,
      toleranceMm: 2.0,
      axis: 'y',
      source: 'reference_database',
      description: `Inferred depth sized for ${reqs.referenceObject?.name || 'reference item'} + ${refClearance}mm clearance`,
    });
  } else if (planDims?.depth) {
    inferredDimensions.push({
      name: 'Overall Depth',
      value: planDims.depth,
      toleranceMm: 2.5,
      axis: 'y',
      source: 'inferred',
      description: 'AI design plan inferred depth',
    });
  } else if (knowledgeRule?.defaultDimensions?.depth) {
    inferredDimensions.push({
      name: 'Overall Depth',
      value: knowledgeRule.defaultDimensions.depth,
      toleranceMm: 3.0,
      axis: 'y',
      source: 'inferred',
      description: 'Knowledge base typical depth',
    });
  } else {
    inferredDimensions.push({
      name: 'Overall Depth',
      value: 80,
      toleranceMm: 3.0,
      axis: 'y',
      source: 'inferred',
      description: 'Estimated default depth',
    });
  }

  // 3. Height / Z Axis
  if (dims?.height) {
    explicitDimensions.push({
      name: 'Overall Height',
      value: dims.height,
      toleranceMm: 1.5,
      axis: 'z',
      source: 'explicit',
      description: 'Height specified in prompt',
    });
  } else if (refDims?.height) {
    const calculatedHeight = Math.max(15, Math.min(Number(refDims.height) * 0.6, Number(refDims.height) + 10));
    inferredDimensions.push({
      name: 'Overall Height',
      value: Math.round(calculatedHeight * 10) / 10,
      toleranceMm: 2.0,
      axis: 'z',
      source: 'reference_database',
      description: `Inferred height sized for ${reqs.referenceObject?.name || 'reference item'} capture`,
    });
  } else if (planDims?.height) {
    inferredDimensions.push({
      name: 'Overall Height',
      value: planDims.height,
      toleranceMm: 2.5,
      axis: 'z',
      source: 'inferred',
      description: 'AI design plan inferred height',
    });
  } else if (knowledgeRule?.defaultDimensions?.height) {
    inferredDimensions.push({
      name: 'Overall Height',
      value: knowledgeRule.defaultDimensions.height,
      toleranceMm: 3.0,
      axis: 'z',
      source: 'inferred',
      description: 'Knowledge base typical height',
    });
  } else {
    inferredDimensions.push({
      name: 'Overall Height',
      value: 30,
      toleranceMm: 3.0,
      axis: 'z',
      source: 'inferred',
      description: 'Estimated default height',
    });
  }

  // 4. Diameter if present
  if (dims?.diameter) {
    explicitDimensions.push({
      name: 'Diameter',
      value: dims.diameter,
      toleranceMm: 1.5,
      axis: 'diameter',
      source: 'explicit',
      description: 'Diameter specified in prompt',
    });
  } else if (refDims?.diameter) {
    const calculatedDiam = Number(refDims.diameter) + refClearance * 2;
    inferredDimensions.push({
      name: 'Diameter',
      value: Math.round(calculatedDiam * 10) / 10,
      toleranceMm: 2.0,
      axis: 'diameter',
      source: 'reference_database',
      description: `Diameter sized for ${reqs.referenceObject?.name || 'tumbler/bottle'} base`,
    });
  }

  // Required Features
  const requiredFeatures: DesignFeature[] = [];
  if (knowledgeRule) {
    for (const feat of knowledgeRule.inferredFeatures) {
      requiredFeatures.push({
        id: feat.id,
        name: feat.name,
        description: feat.description,
        source: 'inferred',
        confidence: 0.92,
        reason: feat.reason,
      });
    }
  }

  if (Array.isArray(reqs.features)) {
    for (const feat of reqs.features) {
      if (!requiredFeatures.some((rf) => rf.name.toLowerCase() === feat.toLowerCase())) {
        requiredFeatures.push({
          id: `feat_${feat.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
          name: feat,
          description: feat,
          source: 'explicit',
          confidence: 0.95,
          reason: 'Extracted from user prompt',
        });
      }
    }
  }

  // Compatibility Targets
  const compatibilityTargets: CompatibilityTarget[] = [];
  if (reqs.referenceObject) {
    compatibilityTargets.push({
      name: reqs.referenceObject.name,
      relationship: 'holds',
      dimensions: reqs.referenceObject.dimensions,
      clearanceMm: reqs.referenceObject.clearanceMm || 2.0,
      source: 'reference_database',
      notes: reqs.referenceObject.sourceNote,
    });
  }

  // Mounting Requirements
  const mountingRequirements: string[] = [];
  const mountingStyle = reqs.mountingStyle || (knowledgeRule ? knowledgeRule.defaultMountingStyle : 'freestanding');
  if (mountingStyle && mountingStyle !== 'none' && mountingStyle !== 'freestanding') {
    mountingRequirements.push(`${mountingStyle} mounting interface`);
  }
  if (Array.isArray(reqs.fastenersOrHardware)) {
    for (const fast of reqs.fastenersOrHardware) {
      mountingRequirements.push(`Hardware mounting: ${fast}`);
    }
  }
  if (Array.isArray(reqs.designPlan?.mountingDetails)) {
    for (const detail of reqs.designPlan.mountingDetails) {
      mountingRequirements.push(detail);
    }
  }
  const lowerPrompt = prompt.toLowerCase();
  if (
    mountingStyle?.toLowerCase().includes('screw') ||
    mountingStyle?.toLowerCase().includes('under-desk') ||
    lowerPrompt.includes('screw') ||
    lowerPrompt.includes('under desk') ||
    lowerPrompt.includes('under-desk') ||
    lowerPrompt.includes('wall mount')
  ) {
    if (!mountingRequirements.some((m) => m.toLowerCase().includes('screw') || m.toLowerCase().includes('hole'))) {
      mountingRequirements.push('Mounting screw holes with countersink/counterbore tool access');
    }
  }

  // Fit Requirements
  const fitRequirements: FitRequirement[] = [];
  if (reqs.referenceObject) {
    fitRequirements.push({
      target: reqs.referenceObject.name,
      clearanceMm: reqs.referenceObject.clearanceMm || 2.0,
      fitType: (reqs.referenceObject.clearanceMm || 2.0) <= 0.8 ? 'snug' : 'clearance',
      source: 'reference_database',
    });
  }
  if (Array.isArray(reqs.tolerancesOrClearances)) {
    for (const tol of reqs.tolerancesOrClearances) {
      fitRequirements.push({
        target: tol,
        clearanceMm: 1.5,
        fitType: 'clearance',
        source: 'explicit',
      });
    }
  }

  const assumptions: DesignAssumption[] = (reqs.designDecisions || []).map((dec) => ({
    category: 'feature',
    assumption: dec,
    source: 'inferred',
    confidence: 0.9,
    reason: 'Derived by CAD engine for structural integrity',
  }));

  // Calculate Comprehensive Weighted Design Confidence
  // 1. Classification confidence (max 25 pts)
  const classConf = typeof reqs.classificationConfidence === 'number' ? reqs.classificationConfidence : 0.85;
  const classificationScore = classConf * 25;

  // 2. Reference-object certainty (max 15 pts)
  let refCertaintyScore = 10;
  if (reqs.referenceObject) {
    refCertaintyScore = reqs.referenceObject.confidence === 'verified' ? 15 : 12;
  } else if (knowledgeRule) {
    refCertaintyScore = 12;
  }

  // 3. Critical dimension coverage (max 20 pts)
  let dimensionScore = 8;
  if (explicitDimensions.length >= 3) {
    dimensionScore = 20;
  } else if (explicitDimensions.length === 2) {
    dimensionScore = 16;
  } else if (explicitDimensions.length === 1) {
    dimensionScore = 12;
  } else if (reqs.overallDimensions?.width || reqs.overallDimensions?.depth) {
    dimensionScore = 10;
  }

  // 4. Mounting-interface certainty (max 10 pts)
  let mountingScore = 10;
  if (mountingStyle !== 'freestanding') {
    mountingScore = mountingRequirements.length > 0 ? 10 : 6;
  }

  // 5. Fit-interface certainty (max 10 pts)
  let fitScore = 10;
  if (reqs.referenceObject || fitRequirements.length > 0) {
    fitScore = fitRequirements.length > 0 ? 10 : 8;
  }

  // 6. Explicit vs inferred ratio bonus (max 10 pts)
  const explicitCount = requiredFeatures.filter((f) => f.source === 'explicit').length;
  const totalFeatures = requiredFeatures.length;
  const explicitRatio = totalFeatures > 0 ? explicitCount / totalFeatures : 0.5;
  const explicitBonus = explicitRatio * 10;

  // 7. AI designPlan confidence weight (max 10 pts)
  let planScore = 8;
  if (reqs.designPlan?.confidenceScore) {
    planScore = Math.min(10, reqs.designPlan.confidenceScore * 10);
  }

  // Base sum
  let rawScore =
    classificationScore +
    refCertaintyScore +
    dimensionScore +
    mountingScore +
    fitScore +
    explicitBonus +
    planScore;

  // 8. Penalty for unresolved critical questions (-4 pts each, max -20 pts)
  const unresolvedCount = Array.isArray(reqs.unspecifiedProperties) ? reqs.unspecifiedProperties.length : 0;
  const penalty = Math.min(20, unresolvedCount * 4);
  rawScore -= penalty;

  const finalConfidence = Math.max(30, Math.min(99, Math.round(rawScore)));

  return {
    originalPrompt: prompt,
    primaryObject: reqs.primaryObject || reqs.objectName || fallback.primaryObject,
    category,
    intendedFunction: reqs.designPlan?.function || (knowledgeRule ? knowledgeRule.defaultIntendedFunction : fallback.intendedFunction),
    targetUseCase: reqs.designPlan?.targetUseCase || fallback.targetUseCase,
    mountingStyle,
    compatibilityTargets,
    explicitDimensions,
    inferredDimensions,
    criticalDimensions: reqs.designPlan?.criticalDimensions || [],
    requiredFeatures: requiredFeatures.length > 0 ? requiredFeatures : fallback.requiredFeatures,
    optionalFeatures: (reqs.suggestedImprovements || []).map((s, i) => ({
      id: `opt_${i}`,
      name: s,
      description: s,
      source: 'inferred' as RequirementSource,
      confidence: 0.7,
    })),
    mountingRequirements,
    fitRequirements,
    ergonomicRequirements: ['Rounded outer corners and edge chamfers'],
    structuralRequirements: [`Wall thickness >= ${reqs.wallThicknessMm || 2.8} mm`, 'Filleted internal stress risers'],
    aestheticRequirements: ['Clean parametric mechanical styling'],
    printRequirements: [
      {
        orientation: knowledgeRule ? knowledgeRule.printRules.orientation : 'Flat on build plate at Z=0',
        flatBaseRequired: true,
        minWallThicknessMm: reqs.wallThicknessMm || (knowledgeRule ? knowledgeRule.printRules.minWallThicknessMm : 2.8),
        supportFreeGoal: true,
        maxOverhangAngleDeg: 45,
      },
    ],
    assumptions: assumptions.length > 0 ? assumptions : fallback.assumptions,
    unresolvedQuestions: reqs.unspecifiedProperties || [],
    generationStrategy: 'Parametric CSG Construction with Primitives and Boolean Operations',
    confidence: finalConfidence,
  };
}

export function normalizeDimensionRequirementList(
  dims: any,
  fallback: DimensionRequirement[] = []
): DimensionRequirement[] {
  if (!dims) return fallback;
  if (Array.isArray(dims)) {
    return dims.map((d, i) => {
      if (typeof d === 'string') {
        return {
          name: d,
          value: 0,
          toleranceMm: 2.0,
          axis: 'any' as const,
          source: 'inferred' as const,
          description: d,
          isCritical: true,
        };
      }
      if (typeof d === 'object' && d !== null) {
        return {
          name: d.name || `Dimension ${i + 1}`,
          value: typeof d.value === 'number' ? d.value : (typeof d.value === 'string' ? parseFloat(d.value) || 0 : 0),
          toleranceMm: typeof d.toleranceMm === 'number' ? d.toleranceMm : 2.0,
          axis: d.axis || 'any',
          source: d.source || 'inferred',
          description: d.description || '',
          isCritical: !!d.isCritical,
        };
      }
      return {
        name: 'Dimension',
        value: typeof d === 'number' ? d : 0,
        toleranceMm: 2.0,
        axis: 'any' as const,
        source: 'inferred' as const,
      };
    });
  }
  if (typeof dims === 'object' && dims !== null) {
    const result: DimensionRequirement[] = [];
    if (typeof dims.width === 'number' || typeof dims.x === 'number') {
      result.push({
        name: 'Overall Width',
        value: dims.width ?? dims.x,
        toleranceMm: 2.0,
        axis: 'x',
        source: 'inferred',
        description: 'Inferred width',
      });
    }
    if (typeof dims.depth === 'number' || typeof dims.length === 'number' || typeof dims.y === 'number') {
      result.push({
        name: 'Overall Depth',
        value: dims.depth ?? dims.length ?? dims.y,
        toleranceMm: 2.0,
        axis: 'y',
        source: 'inferred',
        description: 'Inferred depth',
      });
    }
    if (typeof dims.height === 'number' || typeof dims.thickness === 'number' || typeof dims.z === 'number') {
      result.push({
        name: 'Overall Height',
        value: dims.height ?? dims.thickness ?? dims.z,
        toleranceMm: 2.0,
        axis: 'z',
        source: 'inferred',
        description: 'Inferred height',
      });
    }
    if (result.length > 0) return result;
  }
  return fallback;
}

export function validateDesignSpecification(spec: Partial<DesignSpecification> | null | undefined, prompt: string): DesignSpecification {
  const fallback = createDefaultDesignSpecification(prompt || '');
  if (!spec || typeof spec !== 'object') return fallback;

  return {
    originalPrompt: spec.originalPrompt || prompt || fallback.originalPrompt,
    primaryObject: spec.primaryObject || fallback.primaryObject,
    category: spec.category || fallback.category,
    intendedFunction: spec.intendedFunction || fallback.intendedFunction,
    targetUseCase: spec.targetUseCase || fallback.targetUseCase,
    mountingStyle: spec.mountingStyle || fallback.mountingStyle,
    compatibilityTargets: Array.isArray(spec.compatibilityTargets) ? spec.compatibilityTargets : [],
    explicitDimensions: normalizeDimensionRequirementList(spec.explicitDimensions, []),
    inferredDimensions: normalizeDimensionRequirementList(spec.inferredDimensions, fallback.inferredDimensions),
    criticalDimensions: normalizeDimensionRequirementList(spec.criticalDimensions, []),
    requiredFeatures: Array.isArray(spec.requiredFeatures) && spec.requiredFeatures.length > 0
      ? spec.requiredFeatures
      : fallback.requiredFeatures,
    optionalFeatures: Array.isArray(spec.optionalFeatures) ? spec.optionalFeatures : [],
    mountingRequirements: Array.isArray(spec.mountingRequirements) ? spec.mountingRequirements : [],
    fitRequirements: Array.isArray(spec.fitRequirements) ? spec.fitRequirements : [],
    ergonomicRequirements: Array.isArray(spec.ergonomicRequirements) ? spec.ergonomicRequirements : fallback.ergonomicRequirements,
    structuralRequirements: Array.isArray(spec.structuralRequirements) ? spec.structuralRequirements : fallback.structuralRequirements,
    aestheticRequirements: Array.isArray(spec.aestheticRequirements) ? spec.aestheticRequirements : fallback.aestheticRequirements,
    printRequirements: Array.isArray(spec.printRequirements) && spec.printRequirements.length > 0
      ? spec.printRequirements
      : fallback.printRequirements,
    assumptions: Array.isArray(spec.assumptions) ? spec.assumptions : fallback.assumptions,
    unresolvedQuestions: Array.isArray(spec.unresolvedQuestions) ? spec.unresolvedQuestions : [],
    generationStrategy: spec.generationStrategy || fallback.generationStrategy,
    confidence: typeof spec.confidence === 'number' ? Math.max(0, Math.min(100, spec.confidence)) : fallback.confidence,
  };
}
