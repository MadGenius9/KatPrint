import * as THREE from 'three';
import earcut from 'earcut';

export interface SilhouetteOptions {
  threshold: number; // 0 - 255
  invert: boolean;
  thicknessMm: number;
  targetWidthMm: number;
}

/**
 * Traces the outer contour of a binary image and extrudes it into a 3D solid
 */
export function generateSilhouetteGeometry(
  canvas: HTMLCanvasElement,
  options: SilhouetteOptions
): THREE.BufferGeometry {
  const { threshold, invert, thicknessMm, targetWidthMm } = options;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return new THREE.BoxGeometry(targetWidthMm, targetWidthMm, thicknessMm);

  const width = canvas.width;
  const height = canvas.height;
  const imgData = ctx.getImageData(0, 0, width, height).data;

  // Build binary grid (1 = foreground/solid, 0 = background)
  const grid: Uint8Array = new Uint8Array(width * height);
  let solidPixelCount = 0;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      const r = imgData[idx];
      const g = imgData[idx + 1];
      const b = imgData[idx + 2];
      const a = imgData[idx + 3];

      let isSolid = false;
      if (a < 64) {
        isSolid = invert;
      } else {
        const gray = 0.299 * r + 0.587 * g + 0.114 * b;
        isSolid = invert ? gray >= threshold : gray < threshold;
      }

      const val = isSolid ? 1 : 0;
      grid[y * width + x] = val;
      if (val === 1) solidPixelCount++;
    }
  }

  // Fallback if empty image
  if (solidPixelCount < 10) {
    return new THREE.CylinderGeometry(targetWidthMm / 2, targetWidthMm / 2, thicknessMm, 32);
  }

  // Trace outer boundary contour using directional contour walking
  const contour = traceOuterContour(grid, width, height);
  if (contour.length < 3) {
    return new THREE.BoxGeometry(targetWidthMm, targetWidthMm, thicknessMm);
  }

  // Simplify contour to eliminate redundant points and collinear noise
  const simplified = simplifyPolygon(contour, 1.2);
  if (simplified.length < 3) {
    return new THREE.BoxGeometry(targetWidthMm, targetWidthMm, thicknessMm);
  }

  // Calculate bounding box of contour to center and scale to targetWidthMm
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const pt of simplified) {
    if (pt[0] < minX) minX = pt[0];
    if (pt[0] > maxX) maxX = pt[0];
    if (pt[1] < minY) minY = pt[1];
    if (pt[1] > maxY) maxY = pt[1];
  }

  const origW = Math.max(1, maxX - minX);
  const origH = Math.max(1, maxY - minY);
  const scale = targetWidthMm / Math.max(origW, origH);
  const centerX = (minX + maxX) / 2;
  const centerY = (minY + maxY) / 2;

  // Flattened 2D coordinates for earcut
  const flat2D: number[] = [];
  const ring3D: [number, number][] = [];

  for (const pt of simplified) {
    const xMm = (pt[0] - centerX) * scale;
    const yMm = -(pt[1] - centerY) * scale; // Invert Y for proper Cartesian 3D orientation
    flat2D.push(xMm, yMm);
    ring3D.push([xMm, yMm]);
  }

  // Triangulate 2D polygon with earcut
  const triangleIndices = earcut(flat2D);
  if (triangleIndices.length === 0) {
    return new THREE.BoxGeometry(targetWidthMm, targetWidthMm, thicknessMm);
  }

  const positions: number[] = [];
  const normals: number[] = [];
  const colors: number[] = [];

  const addTriangle = (
    v0: [number, number, number],
    v1: [number, number, number],
    v2: [number, number, number]
  ) => {
    const ax = v1[0] - v0[0], ay = v1[1] - v0[1], az = v1[2] - v0[2];
    const bx = v2[0] - v0[0], by = v2[1] - v0[1], bz = v2[2] - v0[2];
    let nx = ay * bz - az * by;
    let ny = az * bx - ax * bz;
    let nz = ax * by - ay * bx;
    const len = Math.hypot(nx, ny, nz);
    if (len > 1e-6) {
      nx /= len; ny /= len; nz /= len;
    } else {
      nx = 0; ny = 0; nz = 1;
    }

    const isOverhang = nz < -0.65;
    const r = isOverhang ? 0.98 : 0.42;
    const g = isOverhang ? 0.25 : 0.50;
    const b = isOverhang ? 0.18 : 0.62;

    positions.push(...v0, ...v1, ...v2);
    normals.push(nx, ny, nz, nx, ny, nz, nx, ny, nz);
    colors.push(r, g, b, r, g, b, r, g, b);
  };

  // 1. TOP CAP (at Z = thicknessMm)
  for (let i = 0; i < triangleIndices.length; i += 3) {
    const i0 = triangleIndices[i];
    const i1 = triangleIndices[i + 1];
    const i2 = triangleIndices[i + 2];

    const v0: [number, number, number] = [ring3D[i0][0], ring3D[i0][1], thicknessMm];
    const v1: [number, number, number] = [ring3D[i1][0], ring3D[i1][1], thicknessMm];
    const v2: [number, number, number] = [ring3D[i2][0], ring3D[i2][1], thicknessMm];

    addTriangle(v0, v1, v2);
  }

  // 2. BOTTOM CAP (at Z = 0, inverted winding)
  for (let i = 0; i < triangleIndices.length; i += 3) {
    const i0 = triangleIndices[i];
    const i1 = triangleIndices[i + 1];
    const i2 = triangleIndices[i + 2];

    const v0: [number, number, number] = [ring3D[i0][0], ring3D[i0][1], 0];
    const v1: [number, number, number] = [ring3D[i1][0], ring3D[i1][1], 0];
    const v2: [number, number, number] = [ring3D[i2][0], ring3D[i2][1], 0];

    // Clockwise for facing down
    addTriangle(v0, v2, v1);
  }

  // 3. EXTRUDED SIDE WALLS
  const N = ring3D.length;
  for (let i = 0; i < N; i++) {
    const nextIdx = (i + 1) % N;
    const p1 = ring3D[i];
    const p2 = ring3D[nextIdx];

    const top1: [number, number, number] = [p1[0], p1[1], thicknessMm];
    const top2: [number, number, number] = [p2[0], p2[1], thicknessMm];
    const bot1: [number, number, number] = [p1[0], p1[1], 0];
    const bot2: [number, number, number] = [p2[0], p2[1], 0];

    // 2 triangles per quad
    addTriangle(bot1, top2, top1);
    addTriangle(bot1, bot2, top2);
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

  geometry.computeBoundingBox();
  geometry.computeBoundingSphere();
  return geometry;
}

/**
 * Traces outer contour points from binary grid (Moore neighborhood / radial sweep)
 */
function traceOuterContour(grid: Uint8Array, w: number, h: number): [number, number][] {
  // Find first solid pixel
  let startX = -1, startY = -1;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (grid[y * w + x] === 1) {
        startX = x;
        startY = y;
        break;
      }
    }
    if (startX !== -1) break;
  }

  if (startX === -1) return [];

  // Moore-Neighbor Tracing
  const directions = [
    [-1, -1], [0, -1], [1, -1],
    [1, 0],   [1, 1],  [0, 1],
    [-1, 1],  [-1, 0]
  ];

  const contour: [number, number][] = [];
  let currX = startX;
  let currY = startY;
  let dirIdx = 0;
  const maxSteps = w * h;
  let steps = 0;

  contour.push([currX, currY]);

  while (steps < maxSteps) {
    steps++;
    let found = false;
    // Search 8 neighbors clockwise
    for (let i = 0; i < 8; i++) {
      const testDir = (dirIdx + i) % 8;
      const nx = currX + directions[testDir][0];
      const ny = currY + directions[testDir][1];

      if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
        if (grid[ny * w + nx] === 1) {
          currX = nx;
          currY = ny;
          dirIdx = (testDir + 5) % 8; // Backtrack direction
          found = true;
          break;
        }
      }
    }

    if (!found) break;
    if (currX === startX && currY === startY && contour.length > 2) {
      break; // Closed loop found
    }
    contour.push([currX, currY]);
  }

  return contour;
}

/**
 * Douglas-Peucker polygon decimation
 */
function simplifyPolygon(points: [number, number][], epsilon: number): [number, number][] {
  if (points.length <= 4) return points;

  // Subsample if very large to prevent lag
  let pts = points;
  if (pts.length > 500) {
    const step = Math.ceil(pts.length / 400);
    pts = pts.filter((_, idx) => idx % step === 0);
  }

  let dmax = 0;
  let index = 0;
  const end = pts.length - 1;

  for (let i = 1; i < end; i++) {
    const d = perpendicularDistance(pts[i], pts[0], pts[end]);
    if (d > dmax) {
      index = i;
      dmax = d;
    }
  }

  if (dmax > epsilon) {
    const recResults1 = simplifyPolygon(pts.slice(0, index + 1), epsilon);
    const recResults2 = simplifyPolygon(pts.slice(index), epsilon);
    return recResults1.slice(0, -1).concat(recResults2);
  } else {
    return [pts[0], pts[end]];
  }
}

function perpendicularDistance(
  pt: [number, number],
  lineA: [number, number],
  lineB: [number, number]
): number {
  const dx = lineB[0] - lineA[0];
  const dy = lineB[1] - lineA[1];
  const len = Math.hypot(dx, dy);
  if (len === 0) return Math.hypot(pt[0] - lineA[0], pt[1] - lineA[1]);
  return Math.abs(dy * pt[0] - dx * pt[1] + lineB[0] * lineA[1] - lineB[1] * lineA[0]) / len;
}
