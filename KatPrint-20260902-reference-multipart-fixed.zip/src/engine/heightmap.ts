import * as THREE from 'three';

export interface HeightmapOptions {
  maxDepthMm: number;
  baseThicknessMm: number;
  widthMm: number;
  lengthMm: number;
  resolution: number; // e.g. 64, 96, 128
  invert: boolean;
}

/**
 * Generates a closed, watertight 3D solid from a grayscale heightmap image
 */
export function generateHeightmapGeometry(
  canvas: HTMLCanvasElement,
  options: HeightmapOptions
): THREE.BufferGeometry {
  const { maxDepthMm, baseThicknessMm, widthMm, lengthMm, resolution, invert } = options;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return new THREE.BoxGeometry(widthMm, lengthMm, baseThicknessMm);

  const imgWidth = canvas.width;
  const imgHeight = canvas.height;
  const imgData = ctx.getImageData(0, 0, imgWidth, imgHeight).data;

  const resX = resolution;
  const resY = Math.max(8, Math.round(resolution * (imgHeight / imgWidth)));

  const gridZ: number[][] = [];
  const halfW = widthMm / 2;
  const halfL = lengthMm / 2;

  // Sample grayscale values
  for (let iy = 0; iy < resY; iy++) {
    gridZ[iy] = [];
    for (let ix = 0; ix < resX; ix++) {
      const u = ix / (resX - 1);
      const v = iy / (resY - 1);
      const px = Math.min(imgWidth - 1, Math.floor(u * imgWidth));
      const py = Math.min(imgHeight - 1, Math.floor(v * imgHeight));
      const idx = (py * imgWidth + px) * 4;

      const r = imgData[idx];
      const g = imgData[idx + 1];
      const b = imgData[idx + 2];
      let brightness = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0;

      if (invert) {
        brightness = 1.0 - brightness;
      }

      const zHeight = baseThicknessMm + brightness * maxDepthMm;
      gridZ[iy][ix] = zHeight;
    }
  }

  const positions: number[] = [];
  const normals: number[] = [];
  const colors: number[] = [];

  const getTopVertex = (ix: number, iy: number): [number, number, number] => {
    const x = (ix / (resX - 1) - 0.5) * widthMm;
    const y = ((resY - 1 - iy) / (resY - 1) - 0.5) * lengthMm;
    const z = gridZ[iy][ix];
    return [x, y, z];
  };

  const getBaseVertex = (ix: number, iy: number): [number, number, number] => {
    const x = (ix / (resX - 1) - 0.5) * widthMm;
    const y = ((resY - 1 - iy) / (resY - 1) - 0.5) * lengthMm;
    return [x, y, 0];
  };

  const addTriangle = (
    v0: [number, number, number],
    v1: [number, number, number],
    v2: [number, number, number]
  ) => {
    // Normal
    const ax = v1[0] - v0[0], ay = v1[1] - v0[1], az = v1[2] - v0[2];
    const bx = v2[0] - v0[0], by = v2[1] - v0[1], bz = v2[2] - v0[2];
    let nx = ay * bz - az * by;
    let ny = az * bx - ax * bz;
    let nz = ax * by - ay * bx;
    const len = Math.hypot(nx, ny, nz);
    if (len > 1e-6) {
      nx /= len; ny /= len; nz /= len;
    } else {
      nx = 0; ny = 0; nz = 1;
    }

    const isOverhang = nz < -0.65;
    const r = isOverhang ? 0.98 : 0.42;
    const g = isOverhang ? 0.25 : 0.50;
    const b = isOverhang ? 0.18 : 0.62;

    positions.push(...v0, ...v1, ...v2);
    normals.push(nx, ny, nz, nx, ny, nz, nx, ny, nz);
    colors.push(r, g, b, r, g, b, r, g, b);
  };

  // 1. TOP SURFACE MESH
  for (let iy = 0; iy < resY - 1; iy++) {
    for (let ix = 0; ix < resX - 1; ix++) {
      const v00 = getTopVertex(ix, iy);
      const v10 = getTopVertex(ix + 1, iy);
      const v01 = getTopVertex(ix, iy + 1);
      const v11 = getTopVertex(ix + 1, iy + 1);

      // Two triangles per grid quad (CCW winding)
      addTriangle(v00, v10, v11);
      addTriangle(v00, v11, v01);
    }
  }

  // 2. BOTTOM BASE (Z = 0, flat, facing downwards, clockwise for -Z)
  for (let iy = 0; iy < resY - 1; iy++) {
    for (let ix = 0; ix < resX - 1; ix++) {
      const b00 = getBaseVertex(ix, iy);
      const b10 = getBaseVertex(ix + 1, iy);
      const b01 = getBaseVertex(ix, iy + 1);
      const b11 = getBaseVertex(ix + 1, iy + 1);

      addTriangle(b00, b11, b10);
      addTriangle(b00, b01, b11);
    }
  }

  // 3. FOUR SIDE WALLS (watertight closure)
  // South Wall (iy = 0)
  for (let ix = 0; ix < resX - 1; ix++) {
    const t0 = getTopVertex(ix, 0);
    const t1 = getTopVertex(ix + 1, 0);
    const b0 = getBaseVertex(ix, 0);
    const b1 = getBaseVertex(ix + 1, 0);
    addTriangle(b0, t1, t0);
    addTriangle(b0, b1, t1);
  }

  // North Wall (iy = resY - 1)
  for (let ix = 0; ix < resX - 1; ix++) {
    const t0 = getTopVertex(ix, resY - 1);
    const t1 = getTopVertex(ix + 1, resY - 1);
    const b0 = getBaseVertex(ix, resY - 1);
    const b1 = getBaseVertex(ix + 1, resY - 1);
    addTriangle(b0, t0, t1);
    addTriangle(b0, t1, b1);
  }

  // West Wall (ix = 0)
  for (let iy = 0; iy < resY - 1; iy++) {
    const t0 = getTopVertex(0, iy);
    const t1 = getTopVertex(0, iy + 1);
    const b0 = getBaseVertex(0, iy);
    const b1 = getBaseVertex(0, iy + 1);
    addTriangle(b0, t0, t1);
    addTriangle(b0, t1, b1);
  }

  // East Wall (ix = resX - 1)
  for (let iy = 0; iy < resY - 1; iy++) {
    const t0 = getTopVertex(resX - 1, iy);
    const t1 = getTopVertex(resX - 1, iy + 1);
    const b0 = getBaseVertex(resX - 1, iy);
    const b1 = getBaseVertex(resX - 1, iy + 1);
    addTriangle(b0, t1, t0);
    addTriangle(b0, b1, t1);
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

  geometry.computeBoundingBox();
  geometry.computeBoundingSphere();
  return geometry;
}
