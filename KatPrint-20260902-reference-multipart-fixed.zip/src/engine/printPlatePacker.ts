import { ExecutedModelPart, PrinterSpec, PrintPlatePlan, PrintPlate, PlacedPartInstance } from '../types';

export interface PackingOptions {
  partSpacingMm?: number;
  bedMarginMm?: number;
  layerHeightMm?: number;
  printSpeedMmS?: number;
  infillPercent?: number;
}

/**
 * Computes an optimal 2D guillotine/shelf nesting layout for multi-part 3D prints across one or more print beds
 */
export function computePrintPlatePlan(
  parts: ExecutedModelPart[],
  printer: PrinterSpec,
  options: PackingOptions = {}
): PrintPlatePlan {
  const partSpacing = options.partSpacingMm ?? 10;
  const bedMargin = options.bedMarginMm ?? 10;
  const layerHeight = options.layerHeightMm ?? 0.2;
  const printSpeed = options.printSpeedMmS ?? 60;
  const infillFactor = ((options.infillPercent ?? 20) / 100) * 0.4 + 0.6; // Infill scaling factor

  const bedWidth = Math.max(50, printer.buildVolume.x - bedMargin * 2);
  const bedDepth = Math.max(50, printer.buildVolume.y - bedMargin * 2);
  const bedHeight = printer.buildVolume.z;

  // Flatten all part instances based on their required quantities
  const instancesToPlace: Array<{
    instanceId: string;
    partId: string;
    partName: string;
    width: number;
    depth: number;
    height: number;
    volumeCm3: number;
    weightGrams: number;
    requiresSupports: boolean;
  }> = [];

  parts.forEach((part, partIdx) => {
    const qty = Math.max(1, part.quantity || 1);
    const dims = part.stats?.dimensions || { x: 20, y: 20, z: 20 };
    const w = Math.max(1, dims.x);
    const d = Math.max(1, dims.y);
    const h = Math.max(1, dims.z);
    const vol = part.stats?.volumeCm3 || (w * d * h) / 1000;
    const weight = part.stats?.estimatedWeightGrams || vol * 1.24;

    for (let q = 1; q <= qty; q++) {
      instancesToPlace.push({
        instanceId: `${part.id}_inst_${q}`,
        partId: part.id,
        partName: qty > 1 ? `${part.name} (#${q})` : part.name,
        width: w,
        depth: d,
        height: h,
        volumeCm3: vol,
        weightGrams: weight,
        requiresSupports: !!part.requiresSupports,
      });
    }
  });

  // Sort largest footprint first for efficient shelf packing
  instancesToPlace.sort((a, b) => (b.width * b.depth) - (a.width * a.depth));

  const plates: PrintPlate[] = [];
  let currentPlateIndex = 0;
  let unplaced = [...instancesToPlace];

  while (unplaced.length > 0) {
    const currentPlateItems: PlacedPartInstance[] = [];
    const remainingForNextPlate: typeof unplaced = [];

    let currentX = -bedWidth / 2;
    let currentY = -bedDepth / 2;
    let rowMaxDepth = 0;
    let plateVol = 0;
    let plateWeight = 0;
    let plateAreaOccupied = 0;

    for (const item of unplaced) {
      // Check if part exceeds maximum z build height
      const partFitsZ = item.height <= bedHeight;

      // Check if item fits in current row
      if (currentX + item.width <= bedWidth / 2 && currentY + item.depth <= bedDepth / 2) {
        // Place item centered at current position
        const posX = currentX + item.width / 2;
        const posY = currentY + item.depth / 2;
        const posZ = 0; // Sitting flat on bed

        currentPlateItems.push({
          instanceId: item.instanceId,
          partId: item.partId,
          partName: item.partName,
          position: { x: posX, y: posY, z: posZ },
          rotationZ: 0,
          dimensions: { x: item.width, y: item.depth, z: item.height },
          plateIndex: currentPlateIndex,
          requiresSupports: item.requiresSupports,
        });

        plateVol += item.volumeCm3;
        plateWeight += item.weightGrams;
        plateAreaOccupied += (item.width + partSpacing) * (item.depth + partSpacing);

        currentX += item.width + partSpacing;
        rowMaxDepth = Math.max(rowMaxDepth, item.depth);
      } else if (currentY + rowMaxDepth + partSpacing + item.depth <= bedDepth / 2) {
        // Start a new row on the same plate
        currentY += rowMaxDepth + partSpacing;
        currentX = -bedWidth / 2;
        rowMaxDepth = item.depth;

        const posX = currentX + item.width / 2;
        const posY = currentY + item.depth / 2;
        const posZ = 0;

        currentPlateItems.push({
          instanceId: item.instanceId,
          partId: item.partId,
          partName: item.partName,
          position: { x: posX, y: posY, z: posZ },
          rotationZ: 0,
          dimensions: { x: item.width, y: item.depth, z: item.height },
          plateIndex: currentPlateIndex,
          requiresSupports: item.requiresSupports,
        });

        plateVol += item.volumeCm3;
        plateWeight += item.weightGrams;
        plateAreaOccupied += (item.width + partSpacing) * (item.depth + partSpacing);

        currentX += item.width + partSpacing;
      } else {
        // Does not fit on this plate, defer to next plate
        remainingForNextPlate.push(item);
      }
    }

    // Estimate print time for this plate (minutes)
    // Approximate: (Volume in mm3 / (extrusion rate)) + (Z height layers * travel)
    const totalVolumeMm3 = plateVol * 1000;
    const volumetricFlowMm3s = Math.min(18, (printSpeed * 0.4 * layerHeight * 1.5));
    const printTimeSeconds = (totalVolumeMm3 / (volumetricFlowMm3s || 10)) * infillFactor + (currentPlateItems.length * 90);
    const printTimeMinutes = Math.max(12, Math.round(printTimeSeconds / 60));

    const occupiedPercent = Math.min(100, Math.round((plateAreaOccupied / (bedWidth * bedDepth)) * 100));

    plates.push({
      plateIndex: currentPlateIndex,
      plateName: `Plate ${currentPlateIndex + 1}`,
      items: currentPlateItems,
      occupiedAreaPercent: occupiedPercent,
      totalVolumeCm3: plateVol,
      estimatedWeightGrams: plateWeight,
      estimatedPrintTimeMinutes: printTimeMinutes,
      fitsOnBed: currentPlateItems.length > 0,
    });

    if (remainingForNextPlate.length === unplaced.length) {
      // Prevent infinite loop if an individual part is strictly larger than the bed itself
      // Force place on dedicated overflow plate with warning
      const oversized = remainingForNextPlate.shift()!;
      plates.push({
        plateIndex: currentPlateIndex + 1,
        plateName: `Plate ${currentPlateIndex + 2} (⚠️ Oversized)`,
        items: [{
          instanceId: oversized.instanceId,
          partId: oversized.partId,
          partName: `${oversized.partName} (Exceeds Bed Limits)`,
          position: { x: 0, y: 0, z: 0 },
          rotationZ: 0,
          dimensions: { x: oversized.width, y: oversized.depth, z: oversized.height },
          plateIndex: currentPlateIndex + 1,
          requiresSupports: oversized.requiresSupports,
        }],
        occupiedAreaPercent: 100,
        totalVolumeCm3: oversized.volumeCm3,
        estimatedWeightGrams: oversized.weightGrams,
        estimatedPrintTimeMinutes: 60,
        fitsOnBed: false,
      });
      unplaced = remainingForNextPlate;
      currentPlateIndex += 2;
    } else {
      unplaced = remainingForNextPlate;
      currentPlateIndex++;
    }
  }

  const totalVol = plates.reduce((acc, p) => acc + p.totalVolumeCm3, 0);
  const totalWeight = plates.reduce((acc, p) => acc + p.estimatedWeightGrams, 0);
  const totalTime = plates.reduce((acc, p) => acc + p.estimatedPrintTimeMinutes, 0);

  return {
    plates,
    totalPlates: plates.length,
    fitsAllOnOnePlate: plates.length === 1,
    totalVolumeCm3: totalVol,
    totalEstimatedWeightGrams: totalWeight,
    totalEstimatedPrintTimeMinutes: totalTime,
    printerBedDimensions: {
      x: printer.buildVolume.x,
      y: printer.buildVolume.y,
      z: printer.buildVolume.z,
    },
  };
}
