/**
 * Security and sandbox validator for generated JSCAD code.
 * Ensures generated code contains only pure geometric mathematical CAD logic
 * and prevents execution of dangerous system, network, or browser APIs.
 *
 * Implements token-aware comment & string literal stripping to avoid false positives
 * on words like "path", "process", "url", "location", "global", "http" inside comments or text.
 */

export interface SecurityScanResult {
  isSafe: boolean;
  violations: string[];
  sanitizedCode?: string;
}

/**
 * Strips comments and string literals from JavaScript code
 * so that innocent words inside text or comments do not trigger security rejections.
 */
export function stripCommentsAndStrings(code: string): string {
  if (!code || typeof code !== 'string') return '';

  let result = '';
  let inSingleLineComment = false;
  let inMultiLineComment = false;
  let inSingleQuote = false;
  let inDoubleQuote = false;
  let inTemplateLiteral = false;
  let isEscaped = false;

  for (let i = 0; i < code.length; i++) {
    const char = code[i];
    const nextChar = i + 1 < code.length ? code[i + 1] : '';

    if (inSingleLineComment) {
      if (char === '\n' || char === '\r') {
        inSingleLineComment = false;
        result += char;
      }
      continue;
    }

    if (inMultiLineComment) {
      if (char === '*' && nextChar === '/') {
        inMultiLineComment = false;
        i++; // skip '/'
      }
      continue;
    }

    if (inSingleQuote) {
      if (char === '\\') {
        isEscaped = !isEscaped;
      } else if (char === "'" && !isEscaped) {
        inSingleQuote = false;
      } else {
        isEscaped = false;
      }
      continue;
    }

    if (inDoubleQuote) {
      if (char === '\\') {
        isEscaped = !isEscaped;
      } else if (char === '"' && !isEscaped) {
        inDoubleQuote = false;
      } else {
        isEscaped = false;
      }
      continue;
    }

    if (inTemplateLiteral) {
      if (char === '\\') {
        isEscaped = !isEscaped;
      } else if (char === '`' && !isEscaped) {
        inTemplateLiteral = false;
      } else {
        isEscaped = false;
      }
      continue;
    }

    // Check for comment starts
    if (char === '/' && nextChar === '/') {
      inSingleLineComment = true;
      i++;
      continue;
    }

    if (char === '/' && nextChar === '*') {
      inMultiLineComment = true;
      i++;
      continue;
    }

    // Check for string starts
    if (char === "'") {
      inSingleQuote = true;
      isEscaped = false;
      result += "''";
      continue;
    }

    if (char === '"') {
      inDoubleQuote = true;
      isEscaped = false;
      result += '""';
      continue;
    }

    if (char === '`') {
      inTemplateLiteral = true;
      isEscaped = false;
      result += '``';
      continue;
    }

    result += char;
  }

  return result;
}

const FORBIDDEN_EXECUTABLE_PATTERNS: { regex: RegExp; reason: string }[] = [
  // Network APIs
  { regex: /\b(?:fetch|XMLHttpRequest|WebSocket|EventSource)\s*\(/i, reason: 'Network communication APIs are forbidden.' },
  
  // Dynamic code execution
  { regex: /\beval\s*\(/i, reason: 'Dynamic code execution (eval) is forbidden.' },
  { regex: /\bnew\s+Function\b/i, reason: 'Dynamic Function constructor is forbidden.' },
  { regex: /\bimportScripts\s*\(/i, reason: 'Dynamic script loading is forbidden.' },
  { regex: /\bWebAssembly\b/i, reason: 'WebAssembly execution is forbidden.' },

  // Node.js process / child_process / system access
  { regex: /\bprocess\.(?:env|exit|kill|cwd|chdir|mainModule|binding|dlopen|argv|pid)\b/i, reason: 'Node.js process manipulation is forbidden.' },
  { regex: /\bchild_process\b/i, reason: 'Process spawning is forbidden.' },
  { regex: /\b(?:__dirname|__filename)\b/i, reason: 'System path introspection is forbidden.' },

  // Dangerous module requires / imports (allow @jscad/modeling or jscad)
  { regex: /\brequire\s*\(\s*['"](?!@jscad\/|jscad)[^'"]+['"]\s*\)/i, reason: 'Arbitrary module require() is forbidden.' },
  { regex: /\bimport\s+.*?from\s+['"](?!@jscad\/|jscad)[^'"]+['"]/i, reason: 'External module imports are forbidden.' },
  { regex: /\bimport\s*\(/i, reason: 'Dynamic module import() is forbidden.' },

  // Timers
  { regex: /\b(?:setTimeout|setInterval|setImmediate)\s*\(/i, reason: 'Timer manipulation is forbidden.' },

  // DOM & Storage access (specific patterns; avoid banning bare CAD variables like location or cookie)
  { regex: /\b(?:window|document|localStorage|sessionStorage|indexedDB)\b/i, reason: 'DOM and browser storage access is forbidden.' },
  { regex: /\b(?:window|document)\s*\.\s*(?:location|cookie)\b/i, reason: 'DOM and browser storage access is forbidden.' },

  // Global scope escape & prototype pollution
  { regex: /\b(?:global|globalThis)\b/i, reason: 'Global scope access is forbidden.' },
  { regex: /\b(?:__proto__|prototype\.constructor)\b/i, reason: 'Prototype pollution is forbidden.' },
];

export function validateCadCodeSecurity(code: string): SecurityScanResult {
  if (!code || typeof code !== 'string') {
    return { isSafe: false, violations: ['Empty or non-string code provided'] };
  }

  // Strip comments and string literals first so words like "path" or "process" inside comments/strings are never flagged
  const strippedCode = stripCommentsAndStrings(code);

  const violations: string[] = [];

  for (const { regex, reason } of FORBIDDEN_EXECUTABLE_PATTERNS) {
    if (regex.test(strippedCode)) {
      violations.push(reason);
    }
  }

  if (violations.length > 0) {
    return {
      isSafe: false,
      violations,
    };
  }

  return {
    isSafe: true,
    violations: [],
  };
}
