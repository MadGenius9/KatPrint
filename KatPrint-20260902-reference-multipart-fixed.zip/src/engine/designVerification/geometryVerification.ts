import * as THREE from 'three';
import {
  DesignSpecification,
  DesignCheck,
  GeometryInspectionStats,
  DesignValidationItem,
} from '../../types';
import { analyzeBufferGeometry } from '../geometryUtils';

export interface DeterministicInspectionResult {
  stats: GeometryInspectionStats;
  checks: DesignCheck[];
  items: DesignValidationItem[];
  passedChecksCount: number;
  totalChecksCount: number;
  criticalPassed: boolean;
  warnings: string[];
}

export function performDeterministicInspection(
  geometry: THREE.BufferGeometry,
  code: string,
  spec: DesignSpecification,
  existingChecks?: DesignCheck[]
): DeterministicInspectionResult {
  const stats = analyzeBufferGeometry(geometry, 1.24); // default PLA density

  if (!geometry.boundingBox) {
    geometry.computeBoundingBox();
  }
  const bbox = geometry.boundingBox || new THREE.Box3();
  const minZ = bbox.min.z;

  const inspectionStats: GeometryInspectionStats = {
    dimensions: stats.dimensions,
    actualVolumeMm3: stats.volumeMm3,
    surfaceAreaMm2: stats.surfaceAreaMm2,
    polygonCount: stats.triangleCount,
    triangleCount: stats.triangleCount,
    vertexCount: stats.vertexCount,
    nonManifoldEdgeCount: stats.nonManifoldEdgeCount || 0,
    isManifold: stats.isManifold,
    isNonEmpty: stats.triangleCount > 0 && stats.volumeMm3 > 0,
  };

  const checks: DesignCheck[] = existingChecks ? [...existingChecks] : [];
  const items: DesignValidationItem[] = [];
  const warnings: string[] = [];

  const measuredX = stats.dimensions.x;
  const measuredY = stats.dimensions.y;
  const measuredZ = stats.dimensions.z;

  // Static code analysis helpers
  const lowerCode = code.toLowerCase();
  const hasCylinders = lowerCode.includes('cylinder(') || lowerCode.includes('cylinder (');
  const hasSubtract = lowerCode.includes('subtract(') || lowerCode.includes('subtract (');
  const hasHoles = hasSubtract && (hasCylinders || lowerCode.includes('hole') || lowerCode.includes('mount'));
  const hasDrainage = hasSubtract && (lowerCode.includes('drain') || lowerCode.includes('slot') || lowerCode.includes('grate') || lowerCode.includes('slat'));
  const hasRibs = lowerCode.includes('rib') || lowerCode.includes('ridge') || lowerCode.includes('reinforce') || lowerCode.includes('stiffener');
  const hasRounded = lowerCode.includes('roundedcuboid') || lowerCode.includes('roundradius') || lowerCode.includes('round(') || lowerCode.includes('chamfer');
  const hasCounterbores = lowerCode.includes('counterbore') || lowerCode.includes('countersink') || (hasHoles && (lowerCode.includes('head') || lowerCode.includes('recess')));

  for (const check of checks) {
    if (check.verificationMethod === 'deterministic_geom') {
      if (check.id.includes('manifold')) {
        const isPass = stats.isManifold && inspectionStats.isNonEmpty;
        check.status = isPass ? 'PASS' : 'FAIL';
        check.actual = stats.isManifold ? 'Closed 2-Manifold' : `Non-manifold (${stats.nonManifoldEdgeCount || 0} open edges)`;
        items.push({
          id: check.id,
          label: 'Manifold Watertight Mesh',
          status: isPass ? 'verified' : 'missing',
          detail: check.actual,
          requirementText: check.description,
          verificationSource: 'geometry',
          isHardRequirement: true,
        });
        if (!isPass) {
          warnings.push('Mesh geometry contains non-manifold edges or holes.');
        }
      } else if (check.id.includes('volume')) {
        const isPass = stats.volumeMm3 > 10;
        check.status = isPass ? 'PASS' : 'FAIL';
        check.actual = `${Math.round(stats.volumeMm3)} mm³ (${stats.volumeCm3.toFixed(2)} cm³)`;
        items.push({
          id: check.id,
          label: 'Physical Volume',
          status: isPass ? 'verified' : 'missing',
          detail: check.actual,
          requirementText: check.description,
          verificationSource: 'geometry',
          measuredValue: stats.volumeMm3,
          isHardRequirement: true,
        });
      } else if (check.id.includes('flat_base')) {
        const isFlatBase = Math.abs(minZ) <= 0.35;
        check.status = isFlatBase ? 'PASS' : 'FAIL';
        check.actual = isFlatBase
          ? `Z_min = ${minZ.toFixed(2)} mm (Planar at Z=0)`
          : `Z_min = ${minZ.toFixed(2)} mm (Base not seated at Z=0)`;
        items.push({
          id: check.id,
          label: 'Flat Printable Base at Z=0',
          status: isFlatBase ? 'verified' : 'warning',
          detail: check.actual,
          requirementText: check.description,
          verificationSource: 'geometry',
          isHardRequirement: true,
        });
        if (!isFlatBase) {
          warnings.push(`Model base is offset from build plate: Z_min = ${minZ.toFixed(2)} mm`);
        }
      } else if (check.type === 'DIMENSION') {
        const expectedVal = Number(check.expected);
        const tol = check.tolerance || 2.0;

        let bestMeasured: number | null = null;
        let axisLabel = '';

        const descLower = check.description.toLowerCase();
        if (check.axis === 'x' || descLower.includes('width')) {
          bestMeasured = measuredX;
          axisLabel = 'Width (X)';
        } else if (check.axis === 'y' || descLower.includes('depth') || descLower.includes('length')) {
          bestMeasured = measuredY;
          axisLabel = 'Depth (Y)';
        } else if (check.axis === 'z' || descLower.includes('height')) {
          bestMeasured = measuredZ;
          axisLabel = 'Height (Z)';
        } else if (check.axis === 'diameter' || descLower.includes('diameter')) {
          bestMeasured = Math.max(measuredX, measuredY);
          axisLabel = 'Diameter (XY)';
        }

        if (bestMeasured !== null && !isNaN(expectedVal)) {
          const delta = Math.abs(bestMeasured - expectedVal);
          const isMatch = delta <= tol;
          check.status = isMatch ? 'PASS' : 'FAIL';
          check.actual = `${axisLabel}: ${bestMeasured.toFixed(1)} mm (target ${expectedVal} ±${tol} mm, Δ ${delta.toFixed(1)} mm)`;

          items.push({
            id: check.id,
            label: check.description,
            status: isMatch ? 'verified' : 'missing',
            detail: check.actual,
            requirementText: check.description,
            verificationSource: 'geometry',
            measuredValue: bestMeasured,
            expectedValue: expectedVal,
            isHardRequirement: check.importance === 'CRITICAL',
          });

          if (!isMatch && check.importance === 'CRITICAL') {
            warnings.push(`Dimensional mismatch on ${axisLabel}: expected ${expectedVal} mm, measured ${bestMeasured.toFixed(1)} mm`);
          }
        } else {
          // Honest handling when axis is ambiguous or unmapped
          check.status = 'UNKNOWN';
          check.actual = 'Dimension axis unassigned — requires multi-view visual review';
          items.push({
            id: check.id,
            label: check.description,
            status: 'uncertain',
            detail: check.actual,
            requirementText: check.description,
            verificationSource: 'geometry',
            expectedValue: isNaN(expectedVal) ? undefined : expectedVal,
            isHardRequirement: check.importance === 'CRITICAL',
          });
        }
      } else if (check.type === 'FIT') {
        // Honest fit check: bounding box alone does not prove internal cavity fit
        const target = spec.compatibilityTargets.find((t) =>
          check.description.toLowerCase().includes(t.name.toLowerCase())
        );

        if (target?.dimensions) {
          const reqW = (target.dimensions.width || 0) + target.clearanceMm * 2;
          const reqD = (target.dimensions.depth || 0) + target.clearanceMm * 2;
          const footprintAccommodates = (measuredX >= reqW && measuredY >= reqD) || (measuredX >= reqD && measuredY >= reqW);

          check.status = 'UNKNOWN';
          check.actual = footprintAccommodates
            ? `Outer envelope (${measuredX.toFixed(1)} × ${measuredY.toFixed(1)} mm) accommodates target; internal interface requires visual review`
            : `External size (${measuredX.toFixed(1)} × ${measuredY.toFixed(1)} mm) is tight for target (${reqW.toFixed(1)} × ${reqD.toFixed(1)} mm); requires visual review`;
        } else {
          check.status = 'UNKNOWN';
          check.actual = `Interface geometry requires multi-view visual review`;
        }

        items.push({
          id: check.id,
          label: check.description,
          status: 'uncertain',
          detail: check.actual,
          requirementText: check.description,
          verificationSource: 'geometry',
          isHardRequirement: check.importance === 'CRITICAL',
        });
      } else if (check.type === 'STRUCTURE') {
        // Honest structural check: volume alone does not prove local wall thickness or ribs
        check.status = 'UNKNOWN';
        check.actual = `Structural wall thickness and ribbing require visual & slicing verification`;

        items.push({
          id: check.id,
          label: check.description,
          status: 'uncertain',
          detail: check.actual,
          requirementText: check.description,
          verificationSource: 'geometry',
        });
      }
    } else if (check.verificationMethod === 'source_code') {
      const desc = check.description.toLowerCase();
      const isDrain = desc.includes('drain') || desc.includes('slot') || desc.includes('slat');
      const isHole = desc.includes('hole') || desc.includes('mount') || desc.includes('screw');
      const isRoundedCorner = desc.includes('round') || desc.includes('fillet') || desc.includes('chamfer');
      const isCounterbore = desc.includes('counterbore') || desc.includes('countersink');
      const isRib = desc.includes('rib') || desc.includes('reinforce') || desc.includes('ridge');

      let verified = false;
      let evidence = '';
      if (isDrain && hasDrainage) {
        verified = true;
        evidence = 'Drainage subtraction found in JSCAD source';
      } else if (isCounterbore && hasCounterbores) {
        verified = true;
        evidence = 'Counterbore / countersink recess found in JSCAD source';
      } else if (isHole && hasHoles) {
        verified = true;
        evidence = 'Hole cylinder subtraction found in JSCAD source';
      } else if (isRoundedCorner && hasRounded) {
        verified = true;
        evidence = 'Rounded edge construction found in JSCAD source';
      } else if (isRib && hasRibs) {
        verified = true;
        evidence = 'Rib / reinforcement geometry found in JSCAD source';
      }

      check.status = verified ? 'PASS' : 'UNKNOWN';
      check.actual = verified ? evidence : 'Unverified in code syntax — requires visual confirmation';

      items.push({
        id: check.id,
        label: check.description,
        status: verified ? 'verified' : 'uncertain',
        detail: check.actual,
        requirementText: check.description,
        verificationSource: 'source-code',
      });
    }
  }

  const passedChecksCount = checks.filter((c) => c.status === 'PASS').length;
  const totalChecksCount = checks.length;
  const criticalPassed = !checks.some((c) => c.importance === 'CRITICAL' && c.status === 'FAIL');

  return {
    stats: inspectionStats,
    checks,
    items,
    passedChecksCount,
    totalChecksCount,
    criticalPassed,
    warnings,
  };
}
