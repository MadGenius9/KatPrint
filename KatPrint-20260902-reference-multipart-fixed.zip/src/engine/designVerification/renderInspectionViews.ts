import * as THREE from 'three';

export interface RenderedView {
  viewName: 'isometric' | 'front' | 'rear' | 'left' | 'right' | 'top' | 'bottom';
  dataUrl: string;
}

export interface MultiViewRenderSet {
  isometric: string;
  front: string;
  rear: string;
  left: string;
  right: string;
  top: string;
  bottom: string;
  allViews: RenderedView[];
}

export function renderInspectionViews(
  geometry: THREE.BufferGeometry,
  width: number = 384,
  height: number = 384
): MultiViewRenderSet {
  // Compute bounding box and center
  geometry.computeBoundingBox();
  const box = geometry.boundingBox || new THREE.Box3();
  const center = new THREE.Vector3();
  box.getCenter(center);
  const size = new THREE.Vector3();
  box.getSize(size);

  const maxDim = Math.max(size.x, size.y, size.z, 20);
  const cameraDistance = maxDim * 2.1;

  // Setup offscreen scene
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x18181b); // Neutral dark slate #18181b

  // Add grid floor
  const gridHelper = new THREE.GridHelper(maxDim * 3, 12, 0x4f46e5, 0x27272a);
  gridHelper.position.y = -size.z / 2; // base at floor
  scene.add(gridHelper);

  // Mesh setup with attractive material
  const material = new THREE.MeshStandardMaterial({
    color: 0xec4899, // KatPrint pink
    roughness: 0.35,
    metalness: 0.1,
    flatShading: false,
  });

  const mesh = new THREE.Mesh(geometry.clone(), material);
  // Center mesh at origin for rotation
  mesh.position.set(-center.x, -center.y, -center.z);
  const group = new THREE.Group();
  group.add(mesh);
  scene.add(group);

  // Lighting
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
  scene.add(ambientLight);

  const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.9);
  dirLight1.position.set(cameraDistance, cameraDistance * 1.5, cameraDistance);
  scene.add(dirLight1);

  const dirLight2 = new THREE.DirectionalLight(0xa5b4fc, 0.5);
  dirLight2.position.set(-cameraDistance, cameraDistance * 0.8, -cameraDistance);
  scene.add(dirLight2);

  // Camera setup
  const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, cameraDistance * 10);

  // Offscreen canvas and renderer
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;

  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    preserveDrawingBuffer: true,
  });
  renderer.setSize(width, height, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const viewConfigs: Array<{
    name: 'isometric' | 'front' | 'rear' | 'left' | 'right' | 'top' | 'bottom';
    camPos: THREE.Vector3;
    up?: THREE.Vector3;
  }> = [
    {
      name: 'isometric',
      camPos: new THREE.Vector3(cameraDistance * 0.8, cameraDistance * 0.8, cameraDistance * 0.8),
    },
    {
      name: 'front',
      camPos: new THREE.Vector3(0, -cameraDistance, 0),
      up: new THREE.Vector3(0, 0, 1),
    },
    {
      name: 'rear',
      camPos: new THREE.Vector3(0, cameraDistance, 0),
      up: new THREE.Vector3(0, 0, 1),
    },
    {
      name: 'left',
      camPos: new THREE.Vector3(-cameraDistance, 0, 0),
      up: new THREE.Vector3(0, 0, 1),
    },
    {
      name: 'right',
      camPos: new THREE.Vector3(cameraDistance, 0, 0),
      up: new THREE.Vector3(0, 0, 1),
    },
    {
      name: 'top',
      camPos: new THREE.Vector3(0, 0, cameraDistance),
      up: new THREE.Vector3(0, 1, 0),
    },
    {
      name: 'bottom',
      camPos: new THREE.Vector3(0, 0, -cameraDistance),
      up: new THREE.Vector3(0, 1, 0),
    },
  ];

  const allViews: RenderedView[] = [];
  const resultMap: Record<string, string> = {};

  for (const cfg of viewConfigs) {
    camera.position.copy(cfg.camPos);
    camera.up.copy(cfg.up || new THREE.Vector3(0, 0, 1));
    camera.lookAt(0, 0, 0);
    camera.updateProjectionMatrix();

    renderer.render(scene, camera);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    allViews.push({ viewName: cfg.name, dataUrl });
    resultMap[cfg.name] = dataUrl;
  }

  // Dispose offscreen resources
  renderer.dispose();
  material.dispose();

  return {
    isometric: resultMap['isometric'] || '',
    front: resultMap['front'] || '',
    rear: resultMap['rear'] || '',
    left: resultMap['left'] || '',
    right: resultMap['right'] || '',
    top: resultMap['top'] || '',
    bottom: resultMap['bottom'] || '',
    allViews,
  };
}

export function generateCadThumbnail(geometry: THREE.BufferGeometry, width: number = 384, height: number = 384): string {
  try {
    const views = renderInspectionViews(geometry, width, height);
    return views.isometric || '';
  } catch (err) {
    console.warn('Failed to generate CAD thumbnail:', err);
    return '';
  }
}
