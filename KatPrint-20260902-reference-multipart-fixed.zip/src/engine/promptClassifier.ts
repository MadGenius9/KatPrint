export interface KnownReferenceObject {
  name: string;
  aliases: string[];
  dimensions: { width: number; depth: number; height: number; diameter?: number };
  confidence: 'verified' | 'estimated';
  clearanceMm: number;
  sourceNote: string;
}

export const KNOWN_REFERENCE_OBJECTS: KnownReferenceObject[] = [
  {
    name: 'Dr. Squatch Soap Bar',
    aliases: [
      'dr squatch',
      'squatch bar',
      'dr. squatch',
      'squatch soap',
      'dr.squatch',
      'dr squatch soap',
      'dr squatch bar',
      'dr. squatch bar',
      'dr. squatch soap',
      'squatch',
    ],
    dimensions: { width: 76.2, depth: 76.2, height: 25.4 },
    confidence: 'verified',
    clearanceMm: 2.0,
    sourceNote: 'Standard 3" × 3" × 1" cold-process soap bar',
  },
  {
    name: 'Standard Bar Soap (Dove / Dial)',
    aliases: ['soap bar', 'bar soap', 'bath soap', 'dove bar', 'standard soap', 'hand soap bar'],
    dimensions: { width: 88.0, depth: 56.0, height: 26.0 },
    confidence: 'verified',
    clearanceMm: 3.0,
    sourceNote: 'Standard rectangular rounded bar soap',
  },
  {
    name: 'Apple iPhone 17 / 16 / 15 Pro Max',
    aliases: [
      'iphone 17 pro max',
      'iphone 17',
      'iphone 16 pro max',
      'iphone 16',
      'iphone 15 pro max',
      'iphone max',
      'pro max',
      'iphone 17 pro',
      'iphone 16 pro',
    ],
    dimensions: { width: 77.6, depth: 8.25, height: 163.0 },
    confidence: 'verified',
    clearanceMm: 1.5,
    sourceNote: '6.7-inch to 6.9-inch flagship smartphone body',
  },
  {
    name: 'Apple iPhone Standard (15 / 14 / 13)',
    aliases: ['iphone 15', 'iphone 14', 'iphone 13', 'iphone', 'standard iphone', 'iphone 12', 'smartphone', 'phone'],
    dimensions: { width: 71.6, depth: 7.8, height: 147.6 },
    confidence: 'verified',
    clearanceMm: 1.5,
    sourceNote: '6.1-inch standard smartphone body',
  },
  {
    name: 'Apple AirPods / AirPods Pro Case',
    aliases: ['airpods', 'airpods pro', 'airpod case', 'earbuds case', 'airpods case'],
    dimensions: { width: 60.6, depth: 21.7, height: 45.2 },
    confidence: 'verified',
    clearanceMm: 1.5,
    sourceNote: 'Apple wireless earbuds charging case',
  },
  {
    name: 'Xbox Wireless Controller',
    aliases: [
      'xbox controller',
      'xbox series x controller',
      'xbox one controller',
      'xbox wireless controller',
      'xbox gamepad',
      'xbox',
      'game controller',
      'controllers',
    ],
    dimensions: { width: 155.0, depth: 108.0, height: 63.0 },
    confidence: 'verified',
    clearanceMm: 3.0,
    sourceNote: 'Xbox Series X/S standard gamepad',
  },
  {
    name: 'PlayStation 5 DualSense Controller',
    aliases: ['ps5 controller', 'dualsense', 'playstation 5 controller', 'ps5 gamepad', 'dualsense controller', 'ps5'],
    dimensions: { width: 160.0, depth: 106.0, height: 66.0 },
    confidence: 'verified',
    clearanceMm: 3.0,
    sourceNote: 'Sony PlayStation 5 DualSense controller',
  },
  {
    name: 'Stanley Quencher 40 oz Tumbler',
    aliases: [
      'stanley tumbler',
      'stanley cup',
      'stanley 40 oz',
      'stanley 40oz',
      '40 oz stanley',
      '40oz stanley',
      'stanley quencher',
      'stanley',
      'tumbler',
    ],
    dimensions: { width: 100.0, depth: 100.0, height: 260.0, diameter: 78.0 },
    confidence: 'verified',
    clearanceMm: 2.5,
    sourceNote: '40 oz insulated tumbler with 78mm base diameter',
  },
  {
    name: 'Milwaukee M18 RedLithium Battery',
    aliases: [
      'milwaukee m18',
      'm18 battery',
      'milwaukee battery',
      'milwaukee m18 battery',
      'm18 redlithium',
      'm18',
    ],
    dimensions: { width: 78.0, depth: 120.0, height: 68.0 },
    confidence: 'verified',
    clearanceMm: 1.5,
    sourceNote: 'Milwaukee M18 tool slide battery pack',
  },
  {
    name: 'DeWalt 20V MAX Battery',
    aliases: ['dewalt battery', 'dewalt 20v', 'dewalt 20v max', 'dewalt'],
    dimensions: { width: 75.0, depth: 115.0, height: 65.0 },
    confidence: 'verified',
    clearanceMm: 1.5,
    sourceNote: 'DeWalt 20V slide tool battery pack',
  },
  {
    name: 'Makita 18V LXT Battery',
    aliases: ['makita battery', 'makita 18v', 'makita lxt', 'makita'],
    dimensions: { width: 72.0, depth: 114.0, height: 62.0 },
    confidence: 'verified',
    clearanceMm: 1.5,
    sourceNote: 'Makita 18V LXT slide battery pack',
  },
  {
    name: 'Yeti Rambler Tumbler / Bottle',
    aliases: [
      'yeti bottle',
      'yeti tumbler',
      'yeti rambler',
      'yeti cup',
      'yeti 26 oz',
      'yeti 36 oz',
      'yeti',
    ],
    dimensions: { width: 86.0, depth: 86.0, height: 240.0, diameter: 86.0 },
    confidence: 'verified',
    clearanceMm: 2.0,
    sourceNote: 'Yeti insulated drinkware (86mm base diameter)',
  },
  {
    name: 'Standard 12 oz Aluminum Soda Can',
    aliases: ['soda can', '12 oz can', 'beer can', 'aluminum can', 'can holder'],
    dimensions: { width: 66.0, depth: 66.0, height: 122.0, diameter: 66.0 },
    confidence: 'verified',
    clearanceMm: 1.5,
    sourceNote: 'Standard 12 fl oz beverage can (Ø66.0 mm)',
  },
  {
    name: 'Slim 12 oz Beverage Can',
    aliases: ['slim can', 'skinny can', 'white claw can', 'red bull can', 'slim 12 oz'],
    dimensions: { width: 58.0, depth: 58.0, height: 155.0, diameter: 58.0 },
    confidence: 'verified',
    clearanceMm: 1.5,
    sourceNote: 'Slim 12 fl oz beverage can (Ø58.0 mm)',
  },
  {
    name: 'Standard Coffee Mug',
    aliases: ['coffee mug', 'mug', 'tea cup', 'coffee cup'],
    dimensions: { width: 84.0, depth: 120.0, height: 95.0, diameter: 84.0 },
    confidence: 'verified',
    clearanceMm: 2.5,
    sourceNote: 'Standard ceramic mug with 35mm handle clearance',
  },
  {
    name: 'Standard Pencils & Pens',
    aliases: ['pencil', 'pencils', 'pen', 'pens', 'marker', 'markers'],
    dimensions: { width: 8.5, depth: 8.5, height: 175.0, diameter: 8.5 },
    confidence: 'verified',
    clearanceMm: 1.5,
    sourceNote: 'Standard hex or round writing instruments (Ø8.5 - 10.0 mm)',
  },
  {
    name: 'Credit Card / ID Badge',
    aliases: ['credit card', 'credit cards', 'business card', 'id card', 'wallet card'],
    dimensions: { width: 85.6, depth: 53.98, height: 0.8 },
    confidence: 'verified',
    clearanceMm: 1.2,
    sourceNote: 'ISO/IEC 7810 ID-1 standard card format',
  },
  {
    name: 'USB-C Cable & Connector',
    aliases: ['usb-c', 'usb c', 'usbc', 'charging cable', 'type c', 'usb cable'],
    dimensions: { width: 12.5, depth: 6.5, height: 25.0, diameter: 4.5 },
    confidence: 'verified',
    clearanceMm: 1.0,
    sourceNote: 'Standard USB-C molded connector head and 4.5mm cable relief',
  },
  {
    name: 'Standard Toothbrush',
    aliases: ['toothbrush', 'tooth brush', 'electric toothbrush', 'oral-b'],
    dimensions: { width: 16.0, depth: 16.0, height: 190.0, diameter: 16.0 },
    confidence: 'verified',
    clearanceMm: 2.0,
    sourceNote: 'Standard manual/electric toothbrush handle',
  },
  {
    name: 'Nintendo Switch Game Cartridge',
    aliases: ['switch cartridge', 'switch game', 'nintendo switch game', 'switch card'],
    dimensions: { width: 31.0, depth: 3.0, height: 21.0 },
    confidence: 'verified',
    clearanceMm: 0.8,
    sourceNote: 'Official Nintendo Switch media cartridge',
  },
  {
    name: 'GoPro Hero Action Camera',
    aliases: ['gopro camera', 'gopro hero', 'gopro mount', 'gopro 11', 'gopro 12', 'gopro 10', 'gopro'],
    dimensions: { width: 71.8, depth: 33.6, height: 50.8 },
    confidence: 'verified',
    clearanceMm: 1.5,
    sourceNote: 'Standard GoPro Hero action camera body',
  },
  {
    name: '2-Inch Schedule 40 PVC Pipe',
    aliases: ['2 inch pvc', '2" pvc', '2in pvc', '2-inch pipe', '2" pipe', '2 inch pipe'],
    dimensions: { width: 60.3, depth: 60.3, height: 100.0, diameter: 60.3 },
    confidence: 'verified',
    clearanceMm: 1.0,
    sourceNote: 'Standard 2" Sch 40 PVC (Outer Diameter: 60.3 mm)',
  },
  {
    name: '18650 Li-ion Battery Cell',
    aliases: ['18650', '18650 battery', '18650 cell', 'vape battery'],
    dimensions: { width: 18.4, depth: 18.4, height: 65.0, diameter: 18.4 },
    confidence: 'verified',
    clearanceMm: 0.6,
    sourceNote: 'Standard 18.4mm × 65.0mm cylindrical rechargeable cell',
  },
  {
    name: 'AA Battery',
    aliases: ['aa battery', 'double a battery', 'aa batteries', 'aa cell'],
    dimensions: { width: 14.5, depth: 14.5, height: 50.5, diameter: 14.5 },
    confidence: 'verified',
    clearanceMm: 0.5,
    sourceNote: 'Standard 14.5mm × 50.5mm cylindrical cell',
  },
  {
    name: 'AAA Battery',
    aliases: ['aaa battery', 'triple a battery', 'aaa batteries', 'aaa cell'],
    dimensions: { width: 10.5, depth: 10.5, height: 44.5, diameter: 10.5 },
    confidence: 'verified',
    clearanceMm: 0.5,
    sourceNote: 'Standard 10.5mm × 44.5mm cylindrical cell',
  },
];

export function matchKnownReference(prompt: string) {
  const p = prompt.toLowerCase();
  for (const obj of KNOWN_REFERENCE_OBJECTS) {
    if (obj.aliases.some((alias) => p.includes(alias))) {
      return {
        name: obj.name,
        dimensions: { ...obj.dimensions },
        confidence: obj.confidence,
        clearanceMm: obj.clearanceMm,
        sourceNote: obj.sourceNote,
      };
    }
  }
  return null;
}

export function buildStructuredDesignPlan(prompt: string, parsedObj?: any) {
  const p = prompt.toLowerCase();
  const knownRef = matchKnownReference(prompt);

  // Detect count
  let itemCount = 1;
  const countMatch = prompt.match(/\b(two|three|four|five|2|3|4|5)\s+(controllers?|phones?|batteries|slots|pens?|cans?|mugs?)\b/i);
  if (countMatch) {
    const word = countMatch[1].toLowerCase();
    if (word === 'two' || word === '2') itemCount = 2;
    else if (word === 'three' || word === '3') itemCount = 3;
    else if (word === 'four' || word === '4') itemCount = 4;
    else if (word === 'five' || word === '5') itemCount = 5;
  }

  // Detect mounting style
  let mountingStyle = 'freestanding';
  if (/under[\s-]desk|hang.*?under/i.test(p)) mountingStyle = 'under-desk mount';
  else if (/wall[\s-]mount|mount to wall|screw to wall|wall bracket/i.test(p)) mountingStyle = 'wall mount';
  else if (/snap[\s-]on|snap[\s-]fit|clip/i.test(p)) mountingStyle = 'snap-fit / clip';
  else if (/insert|cup[\s-]holder insert/i.test(p)) mountingStyle = 'drop-in insert';
  else if (/nightstand|desk|tabletop|counter/i.test(p)) mountingStyle = 'desktop / tabletop';

  // Detect object category
  let inferredCategory = 'PARAMETRIC_FUNCTIONAL';
  let primaryObject = 'functional part';
  let funcDesc = 'Practical mechanical utility';
  let targetUse = 'General everyday organization / mounting';
  let strategy = 'Parametric CAD CSG Construction';
  const structuralReqs: string[] = ['Minimum 3.0mm load-bearing walls', 'Flat base at Z=0 for build-plate adhesion'];
  const ergonomicReqs: string[] = ['Smooth chamfered / filleted corners'];
  const aestheticReqs: string[] = ['Clean geometric lines'];
  const assumptions: string[] = [];
  const keyFeatures: string[] = [];

  if (/soap\s*dish|soapdish/i.test(p)) {
    inferredCategory = 'CONTAINER_OR_TRAY';
    primaryObject = 'Soap Dish';
    funcDesc = 'Elevate soap bar, allow water drainage, and facilitate airflow drying';
    targetUse = 'Bathroom vanity / shower counter';
    keyFeatures.push('Raised drainage ribs', 'Water drain slots', 'Perimeter drip catch tray', 'Filleted ergonomic rim');
    assumptions.push('Assumed 2.5mm clearance around soap bar', 'Assumed raised drying ribs (3.5mm height)');
    strategy = 'Parametric Tray with Drainage Grate & Ribs';
  } else if (/controller.*(mount|holder|stand)|xbox.*controller|ps5.*controller/i.test(p)) {
    inferredCategory = 'HOLDER_OR_MOUNT';
    primaryObject = itemCount > 1 ? `Dual Game Controller Stand` : `Game Controller Mount`;
    funcDesc = 'Securely cradle game controller while protecting thumbsticks and triggers';
    targetUse = mountingStyle.includes('wall') ? 'Wall display / storage' : 'Desk gaming setup';
    keyFeatures.push('Ergonomic dual wing cradles', 'Trigger relief cutouts', mountingStyle.includes('wall') ? 'Countersunk M4 screw holes' : 'Weighted stable foot');
    assumptions.push('Added 3mm clearance for silicone controller grips', 'Angled cradle at 15° backward tilt for stability');
    strategy = 'Parametric Ergonomic Cradle & Mounting Flange';
  } else if (/phone.*stand|holds?.*phone|nightstand.*charg/i.test(p)) {
    inferredCategory = 'HOLDER_OR_MOUNT';
    primaryObject = 'Phone Stand with Charging Slot';
    funcDesc = 'Hold phone at optimal viewing angle while allowing charging cable to plug in';
    targetUse = 'Desk / nightstand bedside table';
    keyFeatures.push('70° viewing angle backrest', '14mm front lip stop', 'Bottom center USB-C cable pass-through slot', 'Cable routing channel');
    assumptions.push('Accommodates phones up to 15mm thick (with case)', 'Pass-through slot width 14mm for standard USB-C heads');
    strategy = 'Parametric Angled Stand with Cable Relief';
  } else if (/battery.*holder|m18.*battery|dewalt.*battery|makita.*battery/i.test(p)) {
    inferredCategory = 'HOLDER_OR_MOUNT';
    primaryObject = 'Tool Battery Holder';
    funcDesc = 'Store and latch slide-pack tool batteries securely';
    targetUse = 'Workshop wall / under-shelf storage';
    keyFeatures.push('Slide rail groove interface', 'Latch retention stop tab', 'Countersunk mounting screw holes');
    assumptions.push('Toleranced slide rails with 1.5mm sliding clearance', 'Load-bearing 4mm structural bracket');
    strategy = 'Parametric Slide Rail Fixture';
  } else if (/bracket|under[\s-]desk/i.test(p)) {
    inferredCategory = 'HOLDER_OR_MOUNT';
    primaryObject = 'Mounting Bracket';
    funcDesc = 'Mount equipment securely to underside of desk or wall';
    targetUse = 'Under-desk workstation organization';
    keyFeatures.push('Rigid triangular gussets', 'Countersunk screw holes for wood screws', 'Load-bearing flange');
    assumptions.push('Assumed 4.5mm wall thickness for structural rigidity', 'Standard 4.5mm screw clearance holes');
    strategy = 'Parametric Gusseted Angle Bracket';
  } else if (/tray.*(screws?|bits?|socket)|organizer.*tray|shallow tray/i.test(p)) {
    inferredCategory = 'CONTAINER_OR_TRAY';
    primaryObject = 'Parts Organizer Tray';
    funcDesc = 'Organize small screws, hardware, drill bits, and sockets';
    targetUse = 'Workbench / toolbox drawer';
    keyFeatures.push('Divided compartments', 'Radiused bottom corners (easy small-part scoop)', 'Stackable outer rim');
    assumptions.push('Interior bottom fillet radius 4mm for easy finger retrieval of tiny screws', 'Wall dividers 2.5mm');
    strategy = 'Parametric Grid Organizer with Radiused Pockets';
  } else if (/planter|pot.*drainage|cat.*planter/i.test(p)) {
    inferredCategory = /cat/i.test(p) ? 'PARAMETRIC_DECORATIVE' : 'CONTAINER_OR_TRAY';
    primaryObject = /cat/i.test(p) ? 'Cat Head Planter with Drainage' : 'Self-Draining Planter';
    funcDesc = 'Hold soil and succulent/plant while providing root drainage';
    targetUse = 'Indoor windowsill / desk decor';
    keyFeatures.push('Hollow soil cavity', 'Bottom 6mm drainage hole', 'Integrated drip reservoir rim', /cat/i.test(p) ? 'Cat ear geometric accents' : 'Subtle fluted exterior');
    assumptions.push('Watertight wall perimeter (3.2mm)', 'Drainage hole centered at base Z=0');
    strategy = 'Parametric Revolved Cavity with Drainage Bore';
  } else if (/cable.*clip|usb.*clip/i.test(p)) {
    inferredCategory = 'HOLDER_OR_MOUNT';
    primaryObject = 'USB Cable Clip';
    funcDesc = 'Route and retain charging cables neatly without binding';
    targetUse = 'Desk edge / nightstand wire management';
    keyFeatures.push('Snapping C-channel slot', 'Flex lead-in funnel chamfer', 'Flat adhesive/screw mounting base');
    assumptions.push('Cable channel diameter 4.5mm (fits standard USB-C / Lightning wires)', '0.8mm snap retention lip');
    strategy = 'Parametric Flexible C-Clip';
  } else if (/shift\s*knob|gear\s*knob/i.test(p)) {
    inferredCategory = 'THREAD_OR_MECHANICAL_PART';
    primaryObject = 'Custom Shift Knob';
    funcDesc = 'Comfortable vehicle gear shift knob with internal threaded socket';
    targetUse = 'Automotive interior / sim racing rig';
    keyFeatures.push('Ergonomic palm contour', 'Internal M12 / M10 threaded core cavity', 'Flat bottom seating shoulder');
    assumptions.push('Internal cylindrical bore 10.5mm for threaded insert or direct tapping', '50mm ergonomic grip diameter');
    strategy = 'Parametric Lathed Grip with Internal Thread Cavity';
  } else if (/box.*lid|enclosure|storage box/i.test(p)) {
    inferredCategory = 'ENCLOSURE';
    primaryObject = 'Storage Box with Snap Lid';
    funcDesc = 'Enclose and protect hardware, tools, or electronics';
    targetUse = 'Toolbox / workshop storage';
    keyFeatures.push('Recessed inner lip rebate', 'Friction snap-fit lid', 'Reinforced corner pillars');
    assumptions.push('Lid fit tolerance 0.35mm perimeter offset for clean snap-fit', 'Wall thickness 3.0mm');
    strategy = 'Parametric Two-Part Box & Mating Lid Assembly';
  } else if (/cup\s*holder.*insert|tumbler/i.test(p)) {
    inferredCategory = 'HOLDER_OR_MOUNT';
    primaryObject = 'Cup Holder Adapter Insert';
    funcDesc = 'Step down vehicle cup holder to fit smaller tumblers securely';
    targetUse = 'Car console cup holder';
    keyFeatures.push('Stepped dual-diameter cylinder', 'Top retaining lip flange', 'Bottom drainage / crumb hole');
    assumptions.push('Standard vehicle cup holder outer diameter 85mm, inner cup diameter 72mm');
    strategy = 'Parametric Stepped Adapter Ring';
  } else if (/toothbrush/i.test(p)) {
    inferredCategory = 'HOLDER_OR_MOUNT';
    primaryObject = 'Draining Toothbrush Stand';
    funcDesc = 'Hold toothbrushes vertically while allowing water runoff';
    targetUse = 'Bathroom sink vanity';
    keyFeatures.push('Vertical holding ports', 'Through-hole drainage channels', 'Stable flared anti-tip base');
    assumptions.push('Toothbrush port diameter 16mm to 24mm', 'Raised airflow feet');
    strategy = 'Parametric Multi-Port Stand';
  }

  // Calculate default inferred dimensions
  const dims = knownRef
    ? {
        width: Math.round((knownRef.dimensions.width || 80) + (knownRef.clearanceMm || 2) * 2 + 10),
        depth: Math.round((knownRef.dimensions.depth || 80) + (knownRef.clearanceMm || 2) * 2 + 10),
        height: Math.round((knownRef.dimensions.height || 30) + 6),
        diameter: knownRef.dimensions.diameter ? Math.round(knownRef.dimensions.diameter + (knownRef.clearanceMm || 2) * 2 + 8) : undefined,
      }
    : {
        width: 100,
        depth: 70,
        height: 35,
      };

  return {
    primaryObject,
    function: funcDesc,
    targetUseCase: targetUse,
    inferredCategory,
    referenceObject: knownRef
      ? {
          name: knownRef.name,
          dimensions: knownRef.dimensions,
          confidence: knownRef.confidence,
          clearanceMm: knownRef.clearanceMm,
          sourceNote: knownRef.sourceNote,
        }
      : null,
    inferredDimensions: dims,
    criticalDimensions: knownRef ? [`Inner cavity clearance: +${knownRef.clearanceMm || 2.0}mm around ${knownRef.name}`] : ['Standard 3.0mm wall thickness'],
    mountingStyle,
    structuralRequirements: structuralReqs,
    ergonomicRequirements: ergonomicReqs,
    aestheticRequirements: aestheticReqs,
    printConstraints: ['Orient flat at Z=0 for bed adhesion', 'Avoid overhangs steeper than 45° where possible'],
    confidenceScore: knownRef ? 0.96 : 0.90,
    assumptions: assumptions.length > 0 ? assumptions : ['Assumed standard 3.0mm wall thickness', 'Assumed flat base at Z=0'],
    missingCriticalInfo: [],
    generationStrategy: strategy,
    keyFeatures,
  };
}

export function classifyPromptIntent(
  prompt: string,
  parsedObj?: any
): {
  classification: 'PARAMETRIC' | 'ORGANIC' | 'HYBRID';
  confidence: number;
  primaryObject: string;
  referenceObject: string | null;
  referenceDetails: ReturnType<typeof matchKnownReference>;
  functionalRequirements: string[];
  decorativeRequirements: string[];
  sculpturalRequirements: string[];
  reason: string;
} {
  const p = prompt.toLowerCase();

  // 1. Identify primary manufactured functional object
  const functionalKeywords = [
    'soap dish',
    'soapdish',
    'dish',
    'tray',
    'holder',
    'stand',
    'mount',
    'bracket',
    'organizer',
    'enclosure',
    'box',
    'adapter',
    'spacer',
    'clamp',
    'shelf',
    'hook',
    'cup holder',
    'cupholder',
    'phone stand',
    'battery holder',
    'controller holder',
    'tool holder',
    'wall mount',
    'container',
    'drawer organizer',
    'cable guide',
    'pipe fitting',
    'fitting',
    'cover',
    'lid',
    'rack',
    'gear knob',
    'shift knob',
    'knob',
    'gear',
    'case',
    'bin',
    'jig',
    'fixture',
    'caddy',
    'dock',
    'coaster',
    'riser',
    'funnel',
    'clip',
    'handle',
    'spool',
    'wheel',
    'hinge',
    'latch',
    'catch',
    'washer',
    'bushing',
    'flange',
    'plug',
    'cap',
    'plate',
  ];

  let primaryObject = parsedObj?.primaryObject || '';
  if (!primaryObject) {
    for (const kw of functionalKeywords) {
      if (p.includes(kw)) {
        primaryObject = kw;
        break;
      }
    }
    if (!primaryObject) {
      if (/(?:figurine|statue|sculpture|bust|miniature)/i.test(p)) {
        primaryObject = 'sculpture / figurine';
      } else {
        primaryObject = prompt.slice(0, 30);
      }
    }
  }

  // 2. Identify reference object
  const knownRef = matchKnownReference(prompt);
  let referenceName = knownRef ? knownRef.name : null;
  if (!referenceName) {
    const forMatch = prompt.match(/(?:for|fitted for|fits?|holds?|holding|made for)\s+(?:a\s+|an\s+|the\s+)?([A-Za-z0-9\s\.\-]+?)(?:with|having|that|and|$|\.)/i);
    if (forMatch && forMatch[1]) {
      referenceName = forMatch[1].trim();
    }
  }

  // 3. Functional requirements extraction
  const functionalRequirements: string[] = [];
  if (/soap/i.test(p)) functionalRequirements.push('Hold soap bar securely');
  if (/drain|drainage|slot|hole/i.test(p)) functionalRequirements.push('Drainage slots/holes');
  if (/rib|airflow|raised/i.test(p)) functionalRequirements.push('Raised airflow drying ribs');
  if (/wall|mount|screw/i.test(p)) functionalRequirements.push('Wall mounting support');
  if (/cable|wire|pass/i.test(p)) functionalRequirements.push('Cable pass-through');
  if (/m\d|thread|insert|clamp/i.test(p)) functionalRequirements.push('Precision mechanical interface/thread');
  if (functionalRequirements.length === 0) functionalRequirements.push('Functional mechanical utility');

  // 4. Decorative requirements extraction
  const decorativeRequirements: string[] = [];
  if (/recess|emboss|text|name|word|font|dr\.?\s*squatch/i.test(p)) {
    decorativeRequirements.push('Recessed or embossed text/logo feature');
  }
  if (/footprint|silhouette|icon|pattern|hex|hexagon|ribs|curved|round/i.test(p)) {
    decorativeRequirements.push('Geometric or decorative surface styling');
  }
  if (decorativeRequirements.length === 0) decorativeRequirements.push('none');

  // 5. Sculptural requirements test
  const hasRealisticSculptBody =
    /(?:realistic|detailed|anatomical)\s+(?:dragon|sasquatch|skull|bust|statue|figurine|dog|animal|monster|hand|head|creature|face|body)/i.test(
      p
    ) ||
    /shaped\s+like\s+(?:a\s+)?(?:realistic|detailed)\s+(?:dragon|sasquatch|skull|hand|animal|monster)/i.test(
      p
    ) ||
    /(?:statue\s+of|sculpture\s+of|bust\s+of|figurine\s+of)\s+(?:a\s+)?(?:sasquatch|dragon|dog|animal|skull|monster|character|head|person)/i.test(
      p
    ) ||
    /make\s+a\s+(?:realistic\s+)?(?:dragon\s+figurine|sasquatch\s+figurine|dog\s+figurine|skull|statue\s+of|monster\s+miniature)/i.test(
      p
    );

  const isPureStatueOrFigurine =
    /(?:realistic\s+)?(?:dragon\s+figurine|sasquatch\s+figurine|dog\s+figurine|human\s+head\s+sculpture|anatomical\s+skull|monster\s+miniature|realistic\s+skull\b|statue\s+of\s+a\s+sasquatch)/i.test(
      p
    ) && !/(?:gear\s+knob|knob|dish|holder|mount|bracket|clamp|box|stand)/i.test(p);

  const hasPrecisionMechanicalInterface =
    /(?:m[3-8]|m12|thread|insert|mounting\s+hole|clamp\s+for|pipe\s+clamp|screw\s+hole|bolt\s+circle|flange)/i.test(
      p
    ) ||
    /(?:holding|holds)\s+(?:the\s+)?(?:soap|controller|battery|bottle|cup)/i.test(p);

  // Intent classification decision:
  // Condition 1: Pure sculpture / figurine -> ORGANIC
  if (isPureStatueOrFigurine) {
    return {
      classification: 'ORGANIC',
      confidence: 0.96,
      primaryObject: primaryObject || 'sculpture figurine',
      referenceObject: referenceName,
      referenceDetails: knownRef,
      functionalRequirements: ['Display / Aesthetic model'],
      decorativeRequirements,
      sculpturalRequirements: ['Freeform organic anatomical geometry'],
      reason: 'Primary requested object is a freeform sculpture/figurine with no precision mechanical assembly.',
    };
  }

  // Condition 2: Explicitly requires substantial realistic sculpture AND precision mechanical mounting -> HYBRID
  if (
    hasRealisticSculptBody &&
    hasPrecisionMechanicalInterface &&
    (p.includes('hand') ||
      p.includes('shaped like') ||
      p.includes('dragon-shaped') ||
      p.includes('skull-shaped') ||
      p.includes('eagle sculpture that mounts'))
  ) {
    return {
      classification: 'HYBRID',
      confidence: 0.92,
      primaryObject: primaryObject || 'hybrid object',
      referenceObject: referenceName,
      referenceDetails: knownRef,
      functionalRequirements,
      decorativeRequirements,
      sculpturalRequirements: ['Substantial freeform anatomical sculpture feature'],
      reason: 'Model combines substantial freeform sculpture geometry with precision mechanical mounting/fit requirements.',
    };
  }

  // Condition 3: Default is PARAMETRIC for functional manufactured objects
  return {
    classification: 'PARAMETRIC',
    confidence: 0.98,
    primaryObject: primaryObject || 'functional part',
    referenceObject: referenceName,
    referenceDetails: knownRef,
    functionalRequirements,
    decorativeRequirements,
    sculpturalRequirements: [],
    reason: 'Functional mechanical object with well-defined parametric geometry.',
  };
}
