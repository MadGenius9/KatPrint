import React, { useState } from 'react';
import {
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Settings,
} from 'lucide-react';
import { DesignChangeSet } from '../../projects/projectTypes';

interface ProposedChangesModalProps {
  changeSet: DesignChangeSet;
  userInstruction: string;
  onConfirm: (autoApplyFuture: boolean) => void;
  onCancel: () => void;
}

export const ProposedChangesModal: React.FC<ProposedChangesModalProps> = ({
  changeSet,
  userInstruction,
  onConfirm,
  onCancel,
}) => {
  const [autoApply, setAutoApply] = useState(false);

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-kf-card border border-kf-border rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 text-kf-text">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-kf-border pb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-kf-pink" />
            <h3 className="text-base font-bold text-kf-text">Proposed Design Changes</h3>
          </div>
          <span className="font-mono text-xs text-kf-pink bg-kf-pink/10 border border-kf-pink/30 px-2 py-0.5 rounded-md font-bold">
            {Math.round(changeSet.confidence * 100)}% Confidence
          </span>
        </div>

        {/* User Prompt */}
        <div className="bg-kf-bg p-3 rounded-xl border border-kf-border text-xs">
          <span className="text-[10px] font-mono uppercase text-kf-muted font-bold block mb-1">
            You Asked:
          </span>
          <p className="text-kf-text font-medium italic">"{userInstruction}"</p>
        </div>

        {/* Changes to Apply */}
        <div className="space-y-2">
          <span className="text-[10px] font-mono uppercase text-kf-muted font-bold block">
            Targeted Modifications:
          </span>
          <div className="space-y-1.5">
            {changeSet.requestedChanges.map((change, idx) => (
              <div
                key={idx}
                className="bg-kf-bg/80 border border-kf-border/80 p-2.5 rounded-lg text-xs flex items-center justify-between gap-2"
              >
                <div>
                  <span className="font-bold text-kf-text block">{change.feature}</span>
                  <span className="text-kf-muted text-[11px]">{change.change}</span>
                </div>
                {change.fromValue && (
                  <div className="flex items-center gap-1.5 font-mono text-xs">
                    <span className="text-kf-muted">{change.fromValue}</span>
                    <ArrowRight className="w-3 h-3 text-kf-pink" />
                    <span className="text-kf-pass font-bold">{change.toValue}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Preserved Features */}
        {changeSet.preservedFeatures.length > 0 && (
          <div className="space-y-1.5">
            <span className="text-[10px] font-mono uppercase text-kf-muted font-bold block flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-kf-pass" />
              <span>Preserved Constraints (Protected from Drift):</span>
            </span>
            <div className="flex flex-wrap gap-1.5">
              {changeSet.preservedFeatures.slice(0, 6).map((feat, idx) => (
                <span
                  key={idx}
                  className="bg-kf-bg text-[10px] font-mono text-kf-muted px-2 py-0.5 rounded border border-kf-border"
                >
                  ✓ {feat}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Auto apply checkbox */}
        <div className="pt-2">
          <label className="flex items-center gap-2 text-xs text-kf-muted hover:text-kf-text cursor-pointer select-none">
            <input
              type="checkbox"
              checked={autoApply}
              onChange={(e) => setAutoApply(e.target.checked)}
              className="rounded bg-kf-bg border-kf-border text-kf-pink focus:ring-0"
            />
            <span>Apply future high-confidence revisions automatically</span>
          </label>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 pt-2 border-t border-kf-border">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 rounded-lg bg-kf-bg hover:bg-kf-hover border border-kf-border text-xs text-kf-muted transition cursor-pointer"
          >
            Edit Instruction
          </button>
          <button
            type="button"
            onClick={() => onConfirm(autoApply)}
            className="px-5 py-2 rounded-lg bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] text-xs font-mono font-bold transition shadow-md cursor-pointer flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Apply Changes</span>
          </button>
        </div>
      </div>
    </div>
  );
};
