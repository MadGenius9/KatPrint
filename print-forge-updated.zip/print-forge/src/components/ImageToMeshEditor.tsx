import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Layers,
  Image as ImageIcon,
  Sliders,
  Maximize2,
  RefreshCw,
  Sun,
  Shield,
  AlertTriangle,
  CheckCircle2,
} from 'lucide-react';
import { ImageSubMode } from '../types';
import { generateHeightmapGeometry } from '../engine/heightmap';
import { generateSilhouetteGeometry } from '../engine/silhouette';
import * as THREE from 'three';

interface ImageToMeshEditorProps {
  onGeometryGenerated: (geom: THREE.BufferGeometry) => void;
}

const MAX_FILE_SIZE_BYTES = 20 * 1024 * 1024; // 20 MB
const ALLOWED_MIME_TYPES = ['image/png', 'image/jpeg', 'image/webp'];

export const ImageToMeshEditor: React.FC<ImageToMeshEditorProps> = ({
  onGeometryGenerated,
}) => {
  const [subMode, setSubMode] = useState<ImageSubMode>('heightmap');

  // Heightmap state
  const [maxDepthMm, setMaxDepthMm] = useState(12);
  const [baseThicknessMm, setBaseThicknessMm] = useState(3);
  const [resolution, setResolution] = useState(64);
  const [invertHeight, setInvertHeight] = useState(false);
  const [targetWidthMm, setTargetWidthMm] = useState(100);
  const [targetLengthMm, setTargetLengthMm] = useState(100);

  // Silhouette state
  const [threshold, setThreshold] = useState(128);
  const [invertSilhouette, setInvertSilhouette] = useState(false);
  const [thicknessMm, setThicknessMm] = useState(8);
  const [silhouetteWidthMm, setSilhouetteWidthMm] = useState(80);

  // Processing & Error State
  const [imageLoaded, setImageLoaded] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [sourceName, setSourceName] = useState<string>('Terrain Preset');

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageElRef = useRef<HTMLImageElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Draw loaded source image into canvas with aspect ratio preservation
  const drawImageToCanvas = useCallback((): boolean => {
    const canvas = canvasRef.current;
    if (!canvas) {
      setErrorMessage('Image canvas is unavailable.');
      return false;
    }
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) {
      setErrorMessage('Could not create the image drawing context.');
      return false;
    }

    const img = imageElRef.current;
    if (!img) {
      return false;
    }

    const sourceWidth = img.naturalWidth || img.width || 256;
    const sourceHeight = img.naturalHeight || img.height || 256;
    const maxDimension = 512;

    let canvasWidth = maxDimension;
    let canvasHeight = maxDimension;

    if (sourceWidth >= sourceHeight) {
      canvasWidth = maxDimension;
      canvasHeight = Math.max(1, Math.round((sourceHeight * maxDimension) / sourceWidth));
    } else {
      canvasHeight = maxDimension;
      canvasWidth = Math.max(1, Math.round((sourceWidth * maxDimension) / sourceHeight));
    }

    canvas.width = canvasWidth;
    canvas.height = canvasHeight;

    ctx.clearRect(0, 0, canvasWidth, canvasHeight);
    ctx.drawImage(img, 0, 0, canvasWidth, canvasHeight);
    return true;
  }, []);

  // Actual geometry builder
  const executeMeshGeneration = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) {
      setErrorMessage('Image canvas is unavailable.');
      return;
    }

    setIsGenerating(true);
    setErrorMessage(null);

    try {
      if (subMode === 'heightmap') {
        const geom = generateHeightmapGeometry(canvas, {
          maxDepthMm,
          baseThicknessMm,
          widthMm: targetWidthMm,
          lengthMm: targetLengthMm,
          resolution,
          invert: invertHeight,
        });
        onGeometryGenerated(geom);
      } else {
        const geom = generateSilhouetteGeometry(canvas, {
          threshold,
          invert: invertSilhouette,
          thicknessMm,
          targetWidthMm: silhouetteWidthMm,
        });
        onGeometryGenerated(geom);
      }
    } catch (err: any) {
      console.error('Image geometry generation error:', err);
      setErrorMessage(`Mesh generation failed: ${err.message || 'Unknown error'}`);
    } finally {
      setIsGenerating(false);
    }
  }, [
    subMode,
    maxDepthMm,
    baseThicknessMm,
    targetWidthMm,
    targetLengthMm,
    resolution,
    invertHeight,
    threshold,
    invertSilhouette,
    thicknessMm,
    silhouetteWidthMm,
    onGeometryGenerated,
  ]);

  // Debounced effect for parameter adjustments
  useEffect(() => {
    if (!imageLoaded) return;

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    debounceTimerRef.current = setTimeout(() => {
      executeMeshGeneration();
    }, 150);

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, [
    imageLoaded,
    subMode,
    maxDepthMm,
    baseThicknessMm,
    resolution,
    invertHeight,
    targetWidthMm,
    targetLengthMm,
    threshold,
    invertSilhouette,
    thicknessMm,
    silhouetteWidthMm,
    executeMeshGeneration,
  ]);

  // Load procedural presets
  const loadDefaultImage = (sampleType: 'terrain' | 'gear' | 'shield' = 'terrain') => {
    setErrorMessage(null);
    const canvas = canvasRef.current;
    if (!canvas) {
      setErrorMessage('Image canvas is unavailable.');
      return;
    }
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) {
      setErrorMessage('Could not create the image drawing context.');
      return;
    }

    const w = 256;
    const h = 256;
    canvas.width = w;
    canvas.height = h;

    if (sampleType === 'terrain') {
      setSourceName('Terrain Preset');
      const imgData = ctx.createImageData(w, h);
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const nx = (x / w) * 4;
          const ny = (y / h) * 4;
          const dist = Math.hypot(x - w / 2, y - h / 2) / (w / 2);

          let val = Math.sin(nx * 2) * Math.cos(ny * 2) * 0.5 + 0.5;
          val += Math.sin(nx * 6 + ny * 4) * 0.25;
          val += Math.cos(nx * 10 - ny * 8) * 0.12;
          val = Math.max(0, val * (1.1 - dist * 1.1));

          const byteVal = Math.min(255, Math.max(0, Math.floor(val * 255)));
          const idx = (y * w + x) * 4;
          imgData.data[idx] = byteVal;
          imgData.data[idx + 1] = byteVal;
          imgData.data[idx + 2] = byteVal;
          imgData.data[idx + 3] = 255;
        }
      }
      ctx.putImageData(imgData, 0, 0);
    } else if (sampleType === 'gear') {
      setSourceName('Gear Preset');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = '#000000';
      ctx.save();
      ctx.translate(w / 2, h / 2);

      const teeth = 8;
      ctx.beginPath();
      for (let i = 0; i < teeth * 2; i++) {
        const angle = (i * Math.PI) / teeth;
        const r = i % 2 === 0 ? 95 : 75;
        const gx = Math.cos(angle) * r;
        const gy = Math.sin(angle) * r;
        if (i === 0) ctx.moveTo(gx, gy);
        else ctx.lineTo(gx, gy);
      }
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(0, 0, 30, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    } else {
      setSourceName('Shield Preset');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = '#000000';
      ctx.beginPath();
      ctx.moveTo(w / 2, 20);
      ctx.lineTo(w - 25, 60);
      ctx.lineTo(w - 35, 180);
      ctx.lineTo(w / 2, 235);
      ctx.lineTo(35, 180);
      ctx.lineTo(25, 60);
      ctx.closePath();
      ctx.fill();
    }

    // Create an image snapshot from canvas for the ref so aspect ratio calculations work
    const sampleImg = new Image();
    sampleImg.onload = () => {
      imageElRef.current = sampleImg;
      setImageLoaded(true);
    };
    sampleImg.src = canvas.toDataURL();
  };

  // Initial preset
  useEffect(() => {
    loadDefaultImage('terrain');
  }, []);

  // Process selected or dropped file with full error handling and size checks
  const processImageFile = (file: File) => {
    setErrorMessage(null);

    // 1. Size limit check (20 MB)
    if (file.size > MAX_FILE_SIZE_BYTES) {
      setErrorMessage('This image is larger than 20 MB. Please use a smaller PNG, JPG, or WebP image.');
      return;
    }

    // 2. MIME type check
    if (!ALLOWED_MIME_TYPES.includes(file.type.toLowerCase()) && !/\.(png|jpe?g|webp)$/i.test(file.name)) {
      setErrorMessage("Couldn't read that image file. Try a PNG, JPG, or WebP image.");
      return;
    }

    const reader = new FileReader();

    reader.onerror = () => {
      setErrorMessage("Couldn't read that image file. Try a PNG, JPG, or WebP image.");
    };

    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (!dataUrl) {
        setErrorMessage("Couldn't read that image file. Try a PNG, JPG, or WebP image.");
        return;
      }

      const img = new Image();

      img.onerror = () => {
        setErrorMessage("Couldn't read that image file. Try a PNG, JPG, or WebP image.");
      };

      img.onload = () => {
        imageElRef.current = img;
        setSourceName(file.name);
        const drawn = drawImageToCanvas();
        if (drawn) {
          setImageLoaded(true);
        }
      };

      img.src = dataUrl;
    };

    reader.readAsDataURL(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processImageFile(file);
    }
    // Reset file input value so selecting the exact same file fires onChange again
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Drag and Drop handlers
  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(true);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);

    const file = e.dataTransfer.files?.[0];
    if (file) {
      processImageFile(file);
    }
  };

  return (
    <div className="flex flex-col gap-4 text-kf-text">
      {/* Submode Switcher */}
      <div className="grid grid-cols-2 gap-1.5 bg-kf-panel-2 p-1 rounded-lg border border-kf-border shadow-inner">
        <button
          type="button"
          id="btn-submode-heightmap"
          onClick={() => {
            setSubMode('heightmap');
            loadDefaultImage('terrain');
          }}
          className={`py-1.5 px-3 rounded-md text-xs font-mono font-medium transition ${
            subMode === 'heightmap'
              ? 'bg-kf-pink text-[#0A0004] font-semibold shadow-sm'
              : 'text-kf-muted hover:text-kf-text hover:bg-kf-border/40'
          }`}
        >
          Heightmap (Relief)
        </button>

        <button
          type="button"
          id="btn-submode-silhouette"
          onClick={() => {
            setSubMode('silhouette');
            loadDefaultImage('gear');
          }}
          className={`py-1.5 px-3 rounded-md text-xs font-mono font-medium transition ${
            subMode === 'silhouette'
              ? 'bg-kf-pink text-[#0A0004] font-semibold shadow-sm'
              : 'text-kf-muted hover:text-kf-text hover:bg-kf-border/40'
          }`}
        >
          Silhouette (Extrude)
        </button>
      </div>

      {/* Short mode help */}
      <p className="text-[11px] text-kf-muted font-mono leading-relaxed -mt-1 px-0.5">
        {subMode === 'heightmap'
          ? 'Brightness becomes height. Best for lithophanes, terrain, logos, and photo reliefs.'
          : 'Converts the outline into a flat extruded solid. Best for stamps, signs, and simple cutouts.'}
      </p>

      {/* Error Message Display */}
      {errorMessage && (
        <div className="p-3 bg-kf-fail/15 border border-kf-fail/40 rounded-lg text-xs text-kf-fail flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <div className="flex-1 font-mono text-[11px] leading-relaxed">
            {errorMessage}
          </div>
        </div>
      )}

      {/* Image Upload / Drop Area */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <label htmlFor="file-upload-image" className="text-xs font-semibold uppercase tracking-wider text-kf-muted font-mono flex items-center gap-1.5">
            <ImageIcon className="w-3.5 h-3.5 text-kf-pink" />
            <span>Input Image</span>
          </label>
          <span className="text-[11px] text-kf-ok font-mono flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            Runs in browser
          </span>
        </div>

        <div
          onDragEnter={handleDragEnter}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`relative border-2 border-dashed rounded-lg p-3 text-center transition ${
            isDraggingOver
              ? 'border-kf-pink bg-kf-pink/10 shadow-lg shadow-kf-pink/10'
              : 'border-kf-border hover:border-kf-pink/50 bg-kf-panel'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            id="file-upload-image"
            accept="image/png,image/jpeg,image/webp"
            onChange={handleFileInputChange}
            className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
          />
          <div className="flex items-center justify-center gap-3">
            <div className="relative shrink-0">
              <canvas
                ref={canvasRef}
                className="w-16 h-16 rounded-md border border-kf-border bg-black object-contain"
              />
              {isGenerating && (
                <div className="absolute inset-0 rounded-md bg-black/50 flex items-center justify-center">
                  <RefreshCw className="w-4 h-4 text-kf-pink animate-spin" />
                </div>
              )}
            </div>
            <div className="flex flex-col text-left min-w-0">
              <span className="text-xs font-medium text-kf-text truncate">
                {isDraggingOver
                  ? 'Drop image now…'
                  : sourceName
                    ? sourceName
                    : 'Drop image here or click to browse'}
              </span>
              <span className="text-[11px] text-kf-muted">
                PNG, JPG, or WebP · up to 20 MB · aspect ratio preserved
              </span>
            </div>
          </div>
        </div>

        {/* Preset Sample Images */}
        <div className="flex items-center gap-1.5 text-[11px] font-mono flex-wrap">
          <span className="text-kf-muted">Presets:</span>
          <button
            type="button"
            id="btn-sample-terrain"
            onClick={() => loadDefaultImage('terrain')}
            className="bg-kf-panel-2 hover:bg-kf-border text-kf-text px-2.5 py-1 rounded-md border border-kf-border transition"
          >
            Terrain
          </button>
          <button
            type="button"
            id="btn-sample-gear"
            onClick={() => loadDefaultImage('gear')}
            className="bg-kf-panel-2 hover:bg-kf-border text-kf-text px-2.5 py-1 rounded-md border border-kf-border transition"
          >
            Gear
          </button>
          <button
            type="button"
            id="btn-sample-shield"
            onClick={() => loadDefaultImage('shield')}
            className="bg-kf-panel-2 hover:bg-kf-border text-kf-text px-2.5 py-1 rounded-md border border-kf-border transition"
          >
            Shield
          </button>
          {isGenerating && (
            <span className="ml-auto flex items-center gap-1 text-kf-pink text-[11px]">
              <RefreshCw className="w-3 h-3 animate-spin" />
              <span>Updating mesh…</span>
            </span>
          )}
          {imageLoaded && !isGenerating && !errorMessage && (
            <span className="ml-auto flex items-center gap-1 text-kf-ok text-[11px]">
              <CheckCircle2 className="w-3 h-3" />
              <span>Ready</span>
            </span>
          )}
        </div>
      </div>

      {/* Mode-Specific Parameter Controls */}
      {subMode === 'heightmap' ? (
        <div className="border border-kf-border bg-kf-panel rounded-lg p-3.5 flex flex-col gap-3 shadow-sm">
          <div className="text-xs font-semibold uppercase tracking-wider text-kf-text font-mono flex items-center gap-2 border-b border-kf-border pb-2">
            <Sliders className="w-4 h-4 text-kf-pink" />
            <span>Heightmap Parameters</span>
          </div>

          {/* Target Size (was missing from UI) */}
          <div className="grid grid-cols-2 gap-2">
            <div className="flex flex-col gap-1.5 bg-kf-panel-2 p-2.5 rounded-md border border-kf-border">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-kf-muted">Width (X)</span>
                <span className="text-kf-pink font-semibold">{targetWidthMm} mm</span>
              </div>
              <input
                type="range"
                id="slider-target-width"
                min={20}
                max={220}
                step={5}
                value={targetWidthMm}
                onChange={(e) => setTargetWidthMm(parseInt(e.target.value, 10))}
                className="kf-slider w-full cursor-pointer"
              />
            </div>
            <div className="flex flex-col gap-1.5 bg-kf-panel-2 p-2.5 rounded-md border border-kf-border">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-kf-muted">Length (Y)</span>
                <span className="text-kf-pink font-semibold">{targetLengthMm} mm</span>
              </div>
              <input
                type="range"
                id="slider-target-length"
                min={20}
                max={220}
                step={5}
                value={targetLengthMm}
                onChange={(e) => setTargetLengthMm(parseInt(e.target.value, 10))}
                className="kf-slider w-full cursor-pointer"
              />
            </div>
          </div>

          {/* Max Depth */}
          <div className="flex flex-col gap-1.5 bg-kf-panel-2 p-2.5 rounded-md border border-kf-border">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-kf-muted">Max Z Relief Depth</span>
              <span className="text-kf-pink font-semibold">{maxDepthMm} mm</span>
            </div>
            <input
              type="range"
              id="slider-max-depth"
              min={2}
              max={40}
              step={1}
              value={maxDepthMm}
              onChange={(e) => setMaxDepthMm(parseInt(e.target.value, 10))}
              className="kf-slider w-full cursor-pointer"
            />
          </div>

          {/* Base Thickness */}
          <div className="flex flex-col gap-1.5 bg-kf-panel-2 p-2.5 rounded-md border border-kf-border">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-kf-muted">Base Wall Thickness</span>
              <span className="text-kf-pink font-semibold">{baseThicknessMm} mm</span>
            </div>
            <input
              type="range"
              id="slider-base-thickness"
              min={1}
              max={15}
              step={0.5}
              value={baseThicknessMm}
              onChange={(e) => setBaseThicknessMm(parseFloat(e.target.value))}
              className="kf-slider w-full cursor-pointer"
            />
          </div>

          {/* Grid Resolution */}
          <div className="flex flex-col gap-1.5 bg-kf-panel-2 p-2.5 rounded-md border border-kf-border">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-kf-muted">Mesh Grid Resolution</span>
              <span className="text-kf-pink font-semibold">{resolution} × {resolution}</span>
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {[32, 64, 96, 128].map((res) => (
                <button
                  key={res}
                  type="button"
                  id={`btn-res-${res}`}
                  onClick={() => setResolution(res)}
                  className={`py-1 text-[11px] font-mono rounded-md border transition ${
                    resolution === res
                      ? 'bg-kf-pink text-[#0A0004] border-kf-pink font-semibold'
                      : 'bg-kf-panel border-kf-border text-kf-muted hover:text-kf-text'
                  }`}
                >
                  {res}p
                </button>
              ))}
            </div>
          </div>

          {/* Invert toggle */}
          <div className="flex items-center justify-between pt-1">
            <span className="text-xs font-mono text-kf-muted">Invert Brightness (Negative)</span>
            <button
              type="button"
              id="btn-toggle-invert-height"
              onClick={() => setInvertHeight(!invertHeight)}
              className={`px-3 py-1 rounded-md text-[11px] font-mono transition ${
                invertHeight
                  ? 'bg-kf-pink text-[#0A0004] font-semibold'
                  : 'bg-kf-panel-2 border border-kf-border text-kf-muted hover:text-kf-text'
              }`}
            >
              {invertHeight ? 'Inverted' : 'Normal'}
            </button>
          </div>
        </div>
      ) : (
        <div className="border border-kf-border bg-kf-panel rounded-lg p-3.5 flex flex-col gap-3 shadow-sm">
          <div className="text-xs font-semibold uppercase tracking-wider text-kf-text font-mono flex items-center gap-2 border-b border-kf-border pb-2">
            <Sliders className="w-4 h-4 text-kf-pink" />
            <span>Silhouette Parameters</span>
          </div>

          {/* B/W Threshold Slider */}
          <div className="flex flex-col gap-1.5 bg-kf-panel-2 p-2.5 rounded-md border border-kf-border">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-kf-muted">B/W Luma Threshold</span>
              <span className="text-kf-pink font-semibold">{threshold} / 255</span>
            </div>
            <input
              type="range"
              id="slider-silhouette-threshold"
              min={10}
              max={245}
              step={1}
              value={threshold}
              onChange={(e) => setThreshold(parseInt(e.target.value, 10))}
              className="kf-slider w-full cursor-pointer"
            />
          </div>

          {/* Extrusion Thickness */}
          <div className="flex flex-col gap-1.5 bg-kf-panel-2 p-2.5 rounded-md border border-kf-border">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-kf-muted">Extrusion Height (Z)</span>
              <span className="text-kf-pink font-semibold">{thicknessMm} mm</span>
            </div>
            <input
              type="range"
              id="slider-silhouette-thickness"
              min={2}
              max={50}
              step={1}
              value={thicknessMm}
              onChange={(e) => setThicknessMm(parseInt(e.target.value, 10))}
              className="kf-slider w-full cursor-pointer"
            />
          </div>

          {/* Target Width */}
          <div className="flex flex-col gap-1.5 bg-kf-panel-2 p-2.5 rounded-md border border-kf-border">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-kf-muted">Target Width (XY)</span>
              <span className="text-kf-pink font-semibold">{silhouetteWidthMm} mm</span>
            </div>
            <input
              type="range"
              id="slider-silhouette-width"
              min={20}
              max={220}
              step={5}
              value={silhouetteWidthMm}
              onChange={(e) => setSilhouetteWidthMm(parseInt(e.target.value, 10))}
              className="kf-slider w-full cursor-pointer"
            />
          </div>

          {/* Invert Silhouette */}
          <div className="flex items-center justify-between pt-1">
            <span className="text-xs font-mono text-kf-muted">Invert Background / Foreground</span>
            <button
              type="button"
              id="btn-toggle-invert-silhouette"
              onClick={() => setInvertSilhouette(!invertSilhouette)}
              className={`px-3 py-1 rounded-md text-[11px] font-mono transition ${
                invertSilhouette
                  ? 'bg-kf-pink text-[#0A0004] font-semibold'
                  : 'bg-kf-panel-2 border border-kf-border text-kf-muted hover:text-kf-text'
              }`}
            >
              {invertSilhouette ? 'Inverted' : 'Normal'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
