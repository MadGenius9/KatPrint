import React, { useEffect, useRef, useState, useMemo, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { PrinterSpec, ReferenceObject, ExecutedModelPart } from '../types';
import {
  RotateCcw,
  Layers,
  Box,
  AlertTriangle,
  Grid,
  Ruler,
  Maximize2,
  Target,
  Eye,
  X,
  Sliders,
  CheckCircle2,
  Info,
  ChevronRight,
  Move,
  Lock,
  Sparkles,
  Check,
  Edit3,
} from 'lucide-react';
import {
  SemanticFeatureModel,
  SemanticFeature,
} from '../features/featureTypes';
import {
  FeatureSelectionGeometry,
  getOrComputeFeatureSelection,
  rankSelectionIntersections,
  IntersectionCandidate,
  FeatureSelectionDiagnostics,
} from '../features/featureSelection';
import {
  FeatureManipulator,
  FeatureManipulationDefinition,
  ManipulatorType,
  ManipulatorAxis,
  getFeatureManipulationDefinition,
  getMultiFeatureManipulationDefinition,
  validateManipulationConstraints,
  snapValue,
  FeatureManipulationPreviewState,
} from '../features/featureManipulation';
import { PART_PALETTE } from './assembly/MultiPartManager';

interface Viewer3DProps {
  geometry: THREE.BufferGeometry | null;
  printer: PrinterSpec;
  scaleFactor: number;
  highlightOverhangs: boolean;
  onToggleOverhangs: () => void;
  isGenerating?: boolean;
  referenceObject?: ReferenceObject | null;
  showDimensions?: boolean;
  onToggleDimensions?: () => void;

  // Multi-Part Assembly Props
  parts?: ExecutedModelPart[];
  isMultiPart?: boolean;
  selectedPartId?: string | null;
  onSelectPart?: (partId: string | null) => void;
  explodedOffset?: number;
  partVisibility?: Record<string, boolean>;

  // Semantic 3D Feature Selection Props
  featureModel?: SemanticFeatureModel | null;
  cadCode?: string;
  versionId?: string;
  selectedFeatureId?: string | null;
  selectedFeatureIds?: string[];
  onSelectFeature?: (featureId: string | null) => void;
  onMultiSelectFeatures?: (featureIds: string[]) => void;
  featureSelectionEnabled?: boolean;
  debugShowPickProxies?: boolean;
  onToggleDebugProxies?: () => void;
  focusFeature?: { featureId: string; nonce: number } | null;
  onFocusFeature?: (featureId: string) => void;
  onFeatureSelectionDiagnostics?: (diagnostics: FeatureSelectionDiagnostics) => void;

  // Phase 3.3 Direct Manipulation Props
  onManipulationCommit?: (params: {
    featureId: string;
    featureIds?: string[];
    manipulatorId: string;
    manipulatorType: ManipulatorType;
    parameterChanges: Array<{
      parameterId: string;
      newValue: number | string | boolean;
      oldValue?: number | string | boolean;
      unit?: string;
    }>;
    instructionSummary?: string;
  }) => Promise<void>;
  isManipulating?: boolean;
  isReadOnly?: boolean;
  snapMm?: number;
}

export const Viewer3D: React.FC<Viewer3DProps> = ({
  geometry,
  printer,
  scaleFactor,
  highlightOverhangs,
  onToggleOverhangs,
  isGenerating = false,
  referenceObject,
  showDimensions: initialShowDimensions = true,
  onToggleDimensions,
  parts = [],
  isMultiPart = false,
  selectedPartId = null,
  onSelectPart,
  explodedOffset = 0,
  partVisibility = {},
  featureModel,
  cadCode,
  versionId,
  selectedFeatureId,
  selectedFeatureIds: externalSelectedFeatureIds,
  onSelectFeature,
  onMultiSelectFeatures,
  featureSelectionEnabled = true,
  debugShowPickProxies = false,
  onToggleDebugProxies,
  focusFeature,
  onFocusFeature,
  onFeatureSelectionDiagnostics,
  onManipulationCommit,
  isManipulating = false,
  isReadOnly = false,
  snapMm = 1.0,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const meshRef = useRef<THREE.Mesh | null>(null);
  const partsGroupRef = useRef<THREE.Group | null>(null);
  const bedGridRef = useRef<THREE.Group | null>(null);
  const volumeBoxRef = useRef<THREE.LineSegments | null>(null);
  const dimensionsGroupRef = useRef<THREE.Group | null>(null);
  const refObjectGroupRef = useRef<THREE.Group | null>(null);

  // Semantic feature selection & manipulation groups
  const pickProxiesGroupRef = useRef<THREE.Group | null>(null);
  const featureHighlightGroupRef = useRef<THREE.Group | null>(null);
  const manipulatorsGroupRef = useRef<THREE.Group | null>(null);
  const ghostPreviewGroupRef = useRef<THREE.Group | null>(null);

  const [wireframe, setWireframe] = useState(false);
  const [showVolumeCage, setShowVolumeCage] = useState(true);
  const [localShowDimensions, setLocalShowDimensions] = useState(initialShowDimensions);
  const [localDebugShowProxies, setLocalDebugShowProxies] = useState(false);
  const [activePreset, setActivePreset] = useState<'iso' | 'top' | 'front' | 'side' | null>('iso');
  const [liveBounds, setLiveBounds] = useState<{ x: number; y: number; z: number } | null>(null);

  const isDebugProxies = onToggleDebugProxies ? debugShowPickProxies : localDebugShowProxies;
  const toggleDebugProxies = onToggleDebugProxies || (() => setLocalDebugShowProxies((v) => !v));

  // Hover & Disambiguation States
  const [hoveredFeature, setHoveredFeature] = useState<{
    featureId: string;
    label: string;
    type: string;
    isCutter?: boolean;
    screenX: number;
    screenY: number;
  } | null>(null);

  const [hoveredManipulator, setHoveredManipulator] = useState<FeatureManipulator | null>(null);

  const [disambiguationList, setDisambiguationList] = useState<{
    candidates: IntersectionCandidate[];
    screenX: number;
    screenY: number;
    isMultiKey?: boolean;
  } | null>(null);

  // Active Drag State
  const [activeDragManipulator, setActiveDragManipulator] = useState<FeatureManipulator | null>(null);
  const [manipulationPreview, setManipulationPreview] = useState<FeatureManipulationPreviewState | null>(null);
  const [isDirectNumberEditing, setIsDirectNumberEditing] = useState(false);
  const [activeDirectManipId, setActiveDirectManipId] = useState<string | null>(null);
  const [directNumberInputVal, setDirectNumberInputVal] = useState<string>('');
  const [currentSnapMm, setCurrentSnapMm] = useState<number>(snapMm || 1.0);

  const dragPlaneRef = useRef<THREE.Plane>(new THREE.Plane());
  const dragStartPlanePointRef = useRef<THREE.Vector3>(new THREE.Vector3());
  const dragInitialParamValuesRef = useRef<Map<string, number>>(new Map());
  const ghostInitialPositionsRef = useRef<Map<string, THREE.Vector3>>(new Map());

  const showDimensions = onToggleDimensions ? initialShowDimensions : localShowDimensions;
  const toggleDimensions = onToggleDimensions || (() => setLocalShowDimensions((v) => !v));

  // Resolved active selected feature IDs
  const activeSelectedIds = useMemo(() => {
    if (externalSelectedFeatureIds && externalSelectedFeatureIds.length > 0) {
      return externalSelectedFeatureIds;
    }
    return selectedFeatureId ? [selectedFeatureId] : [];
  }, [externalSelectedFeatureIds, selectedFeatureId]);

  // Compute or fetch cached feature selection geometries
  const selectionGeometriesResult = useMemo(() => {
    if (!cadCode || !featureSelectionEnabled) return null;
    try {
      return getOrComputeFeatureSelection(versionId, cadCode, featureModel || undefined, scaleFactor);
    } catch (e) {
      console.warn('Feature selection proxy generation skipped:', e);
      return null;
    }
  }, [versionId, cadCode, featureModel, scaleFactor, featureSelectionEnabled]);

  // Surface diagnostics to parent
  useEffect(() => {
    if (selectionGeometriesResult?.diagnostics && onFeatureSelectionDiagnostics) {
      onFeatureSelectionDiagnostics(selectionGeometriesResult.diagnostics);
    }
  }, [selectionGeometriesResult?.diagnostics, onFeatureSelectionDiagnostics]);

  const featureGeometries = selectionGeometriesResult?.featureGeometries || [];
  const featureGeomMap = useMemo(() => {
    const map = new Map<string, FeatureSelectionGeometry>();
    for (const fg of featureGeometries) {
      map.set(fg.featureId, fg);
    }
    return map;
  }, [featureGeometries]);

  // Track pointer interactions for distinction between click and orbit-drag
  const pointerDownPosRef = useRef<{ x: number; y: number; time: number } | null>(null);

  // Selected feature items
  const selectedFeatures = useMemo(() => {
    if (!featureModel || activeSelectedIds.length === 0) return [];
    return featureModel.features.filter((f) => activeSelectedIds.includes(f.id));
  }, [activeSelectedIds, featureModel]);

  const primarySelectedFeature = useMemo(() => {
    if (selectedFeatures.length === 0) return null;
    return selectedFeatures[selectedFeatures.length - 1];
  }, [selectedFeatures]);

  // Compute Direct Manipulation Controls for selected feature(s)
  const manipulationDefinition = useMemo<FeatureManipulationDefinition | null>(() => {
    if (!featureModel || !cadCode || selectedFeatures.length === 0) return null;

    if (selectedFeatures.length === 1) {
      const feat = selectedFeatures[0];
      const geom = featureGeomMap.get(feat.id);
      return getFeatureManipulationDefinition(feat, featureModel, cadCode, geom);
    }

    if (selectedFeatures.length === 2) {
      const multi = getMultiFeatureManipulationDefinition(selectedFeatures, featureModel, cadCode, featureGeomMap);
      if (multi) return multi;
    }

    return null;
  }, [selectedFeatures, featureModel, cadCode, featureGeomMap]);

  // ---------------------------------------------------------------------------
  // Scene Initialization
  // ---------------------------------------------------------------------------
  useEffect(() => {
    if (!containerRef.current || !canvasRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#08080A');
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 1, 2000);
    camera.position.set(220, -260, 240);
    camera.up.set(0, 0, 1); // Z is Up in 3D printing!
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.maxDistance = 1200;
    controls.minDistance = 20;
    controls.target.set(0, 0, 40);
    controlsRef.current = controls;

    // Groups for semantic picking & highlights & manipulation
    const pickGroup = new THREE.Group();
    pickGroup.name = 'semantic_pick_proxies';
    scene.add(pickGroup);
    pickProxiesGroupRef.current = pickGroup;

    const highlightGroup = new THREE.Group();
    highlightGroup.name = 'semantic_feature_highlights';
    scene.add(highlightGroup);
    featureHighlightGroupRef.current = highlightGroup;

    const manipGroup = new THREE.Group();
    manipGroup.name = 'semantic_feature_manipulators';
    scene.add(manipGroup);
    manipulatorsGroupRef.current = manipGroup;

    const ghostGroup = new THREE.Group();
    ghostGroup.name = 'semantic_manipulation_ghost';
    scene.add(ghostGroup);
    ghostPreviewGroupRef.current = ghostGroup;

    const partsGroup = new THREE.Group();
    partsGroup.name = 'multi_part_assembly_group';
    scene.add(partsGroup);
    partsGroupRef.current = partsGroup;

    // Lighting setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);


    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.15);
    dirLight1.position.set(150, 100, 300);
    dirLight1.castShadow = true;
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xffb8d0, 0.35);
    dirLight2.position.set(-150, -100, 150);
    scene.add(dirLight2);

    const rimLight = new THREE.DirectionalLight(0xff3d8a, 0.25);
    rimLight.position.set(0, 200, -50);
    scene.add(rimLight);

    // Animation loop
    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Resize observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: newW, height: newH } = entry.contentRect;
        if (newW > 0 && newH > 0 && cameraRef.current && rendererRef.current) {
          cameraRef.current.aspect = newW / newH;
          cameraRef.current.updateProjectionMatrix();
          rendererRef.current.setSize(newW, newH);
        }
      }
    });
    resizeObserver.observe(containerRef.current);

    return () => {
      cancelAnimationFrame(animationId);
      resizeObserver.disconnect();
      renderer.dispose();
    };
  }, []);

  // ---------------------------------------------------------------------------
  // Update Bed Grid & Build Volume Cage
  // ---------------------------------------------------------------------------
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (bedGridRef.current) scene.remove(bedGridRef.current);
    if (volumeBoxRef.current) scene.remove(volumeBoxRef.current);

    const { x: volX, y: volY, z: volZ } = printer.buildVolume;
    const bedGroup = new THREE.Group();

    const maxDim = Math.max(volX, volY);
    const divisions = Math.max(10, Math.round(maxDim / 10));
    const gridHelper = new THREE.GridHelper(maxDim, divisions, 0x3a3a46, 0x2a2a33);
    gridHelper.rotation.x = Math.PI / 2;
    bedGroup.add(gridHelper);

    const halfX = volX / 2;
    const halfY = volY / 2;
    const bedOutlineGeom = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-halfX, -halfY, 0),
      new THREE.Vector3(halfX, -halfY, 0),
      new THREE.Vector3(halfX, halfY, 0),
      new THREE.Vector3(-halfX, halfY, 0),
      new THREE.Vector3(-halfX, -halfY, 0),
    ]);
    const bedOutlineMat = new THREE.LineBasicMaterial({ color: 0xff3d8a, linewidth: 2 });
    const bedOutline = new THREE.Line(bedOutlineGeom, bedOutlineMat);
    bedGroup.add(bedOutline);

    const axesGroup = new THREE.Group();
    const xGeom = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(25, 0, 0),
    ]);
    axesGroup.add(new THREE.Line(xGeom, new THREE.LineBasicMaterial({ color: 0x8a828c, linewidth: 2 })));

    const yGeom = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0, 25, 0),
    ]);
    axesGroup.add(new THREE.Line(yGeom, new THREE.LineBasicMaterial({ color: 0x8a828c, linewidth: 2 })));

    const zGeom = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0, 0, 25),
    ]);
    axesGroup.add(new THREE.Line(zGeom, new THREE.LineBasicMaterial({ color: 0xff3d8a, linewidth: 2 })));
    axesGroup.position.set(-halfX, -halfY, 0.5);
    bedGroup.add(axesGroup);

    scene.add(bedGroup);
    bedGridRef.current = bedGroup;

    const boxGeom = new THREE.BoxGeometry(volX, volY, volZ);
    const boxEdges = new THREE.EdgesGeometry(boxGeom);
    const boxMat = new THREE.LineBasicMaterial({ color: 0x26262e, transparent: true, opacity: 0.8 });
    const boxLines = new THREE.LineSegments(boxEdges, boxMat);
    boxLines.position.set(0, 0, volZ / 2);
    boxLines.visible = showVolumeCage;
    scene.add(boxLines);
    volumeBoxRef.current = boxLines;
  }, [printer, showVolumeCage]);

  // ---------------------------------------------------------------------------
  // Update Geometry & Mesh & Multi-Part Assembly & Dimension Leader Lines
  // ---------------------------------------------------------------------------
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (meshRef.current) {
      scene.remove(meshRef.current);
      meshRef.current.geometry.dispose();
      meshRef.current = null;
    }
    if (partsGroupRef.current) {
      while (partsGroupRef.current.children.length > 0) {
        const child = partsGroupRef.current.children[0] as THREE.Mesh;
        partsGroupRef.current.remove(child);
        if (child.geometry) child.geometry.dispose();
        if (Array.isArray(child.material)) child.material.forEach((m) => m.dispose());
        else if (child.material) child.material.dispose();
      }
    }
    if (dimensionsGroupRef.current) {
      scene.remove(dimensionsGroupRef.current);
      dimensionsGroupRef.current = null;
    }
    if (refObjectGroupRef.current) {
      scene.remove(refObjectGroupRef.current);
      refObjectGroupRef.current = null;
    }

    if (!geometry && (!parts || parts.length === 0)) {
      setLiveBounds(null);
      return;
    }

    const hasMultiParts = parts && parts.length > 1;

    if (hasMultiParts && partsGroupRef.current) {
      // -----------------------------------------------------------------------
      // Multi-Part Assembly Mode
      // -----------------------------------------------------------------------
      // Compute global bounding box of all parts combined to center assembly
      const combinedBox = new THREE.Box3();
      parts.forEach((p) => {
        if (p.geometry) {
          const tempGeom = p.geometry.clone();
          tempGeom.scale(scaleFactor, scaleFactor, scaleFactor);
          tempGeom.computeBoundingBox();
          if (tempGeom.boundingBox) combinedBox.union(tempGeom.boundingBox);
          tempGeom.dispose();
        }
      });

      const centerX = (combinedBox.min.x + combinedBox.max.x) / 2;
      const centerY = (combinedBox.min.y + combinedBox.max.y) / 2;
      const minZ = combinedBox.min.z;

      const sizeX = Number((combinedBox.max.x - combinedBox.min.x).toFixed(1));
      const sizeY = Number((combinedBox.max.y - combinedBox.min.y).toFixed(1));
      const sizeZ = Number((combinedBox.max.z - combinedBox.min.z).toFixed(1));
      setLiveBounds({ x: sizeX, y: sizeY, z: sizeZ });

      parts.forEach((part, idx) => {
        if (!part.geometry) return;
        const isVisible = partVisibility[part.id] !== false;
        if (!isVisible) return;

        const partGeom = part.geometry.clone();
        partGeom.scale(scaleFactor, scaleFactor, scaleFactor);
        partGeom.translate(-centerX, -centerY, -minZ);
        partGeom.computeVertexNormals();

        const isSelected = selectedPartId === part.id;
        const colorHex = PART_PALETTE[idx % PART_PALETTE.length];
        const threeColor = new THREE.Color(colorHex);

        const material = new THREE.MeshStandardMaterial({
          color: isSelected ? 0xff0077 : threeColor,
          roughness: 0.35,
          metalness: 0.2,
          wireframe,
          side: THREE.DoubleSide,
        });

        const partMesh = new THREE.Mesh(partGeom, material);
        partMesh.castShadow = true;
        partMesh.receiveShadow = true;

        // Apply Exploded View Displacement
        if (explodedOffset > 0) {
          const angle = (idx / parts.length) * 2 * Math.PI;
          const expX = Math.cos(angle) * explodedOffset;
          const expY = Math.sin(angle) * explodedOffset;
          const expZ = idx === 0 ? 0 : explodedOffset * 0.45;
          partMesh.position.set(expX, expY, expZ);
        }

        if (!wireframe) {
          const edgesGeom = new THREE.EdgesGeometry(partGeom, 24);
          const edgeLines = new THREE.LineSegments(
            edgesGeom,
            new THREE.LineBasicMaterial({
              color: isSelected ? 0xffffff : 0x22222a,
              transparent: true,
              opacity: isSelected ? 0.95 : 0.45,
            })
          );
          partMesh.add(edgeLines);
        }

        partsGroupRef.current?.add(partMesh);
      });
    } else {
      // -----------------------------------------------------------------------
      // Single Part / Solid Mode
      // -----------------------------------------------------------------------
      if (!geometry) {
        setLiveBounds(null);
        return;
      }

      const geom = geometry.clone();
      geom.scale(scaleFactor, scaleFactor, scaleFactor);
      geom.computeBoundingBox();

      const box = geom.boundingBox;
      if (box) {
        const centerX = (box.min.x + box.max.x) / 2;
        const centerY = (box.min.y + box.max.y) / 2;
        const minZ = box.min.z;
        geom.translate(-centerX, -centerY, -minZ);
      }

      geom.computeVertexNormals();
      geom.computeBoundingBox();

      const currentBox = geom.boundingBox || new THREE.Box3();
      const sizeX = Number((currentBox.max.x - currentBox.min.x).toFixed(1));
      const sizeY = Number((currentBox.max.y - currentBox.min.y).toFixed(1));
      const sizeZ = Number((currentBox.max.z - currentBox.min.z).toFixed(1));
      setLiveBounds({ x: sizeX, y: sizeY, z: sizeZ });

      const hasVertexColors = geom.getAttribute('color') !== undefined;

      let material: THREE.Material;
      if (highlightOverhangs && hasVertexColors) {
        material = new THREE.MeshStandardMaterial({
          vertexColors: true,
          roughness: 0.35,
          metalness: 0.15,
          wireframe,
          side: THREE.DoubleSide,
        });
      } else {
        material = new THREE.MeshStandardMaterial({
          color: 0x2a2028,
          roughness: 0.35,
          metalness: 0.2,
          wireframe,
          side: THREE.DoubleSide,
        });
      }

      const mesh = new THREE.Mesh(geom, material);
      mesh.castShadow = true;
      mesh.receiveShadow = true;

      if (!wireframe) {
        const edgesGeom = new THREE.EdgesGeometry(geom, 22);
        const edgeLines = new THREE.LineSegments(
          edgesGeom,
          new THREE.LineBasicMaterial({ color: 0xff3d8a, transparent: true, opacity: 0.85 })
        );
        mesh.add(edgeLines);
      }

      scene.add(mesh);
      meshRef.current = mesh;

      // Dimension leader lines
      if (showDimensions && box) {
        const dimGroup = new THREE.Group();
        const hX = sizeX / 2;
        const hY = sizeY / 2;
        const zMax = sizeZ;

        const dimMat = new THREE.LineDashedMaterial({
          color: 0x00f0ff,
          dashSize: 3,
          gapSize: 2,
          transparent: true,
          opacity: 0.75,
        });

        const xLineGeom = new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(-hX, -hY - 8, 0.5),
          new THREE.Vector3(hX, -hY - 8, 0.5),
        ]);
        const xLine = new THREE.Line(xLineGeom, dimMat);
        xLine.computeLineDistances();
        dimGroup.add(xLine);

        const yLineGeom = new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(hX + 8, -hY, 0.5),
          new THREE.Vector3(hX + 8, hY, 0.5),
        ]);
        const yLine = new THREE.Line(yLineGeom, dimMat);
        yLine.computeLineDistances();
        dimGroup.add(yLine);

        const zLineGeom = new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(-hX - 8, -hY, 0),
          new THREE.Vector3(-hX - 8, -hY, zMax),
        ]);
        const zLine = new THREE.Line(zLineGeom, dimMat);
        zLine.computeLineDistances();
        dimGroup.add(zLine);

        scene.add(dimGroup);
        dimensionsGroupRef.current = dimGroup;
      }
    }
  }, [geometry, parts, explodedOffset, partVisibility, selectedPartId, scaleFactor, wireframe, highlightOverhangs, showDimensions]);

  // ---------------------------------------------------------------------------
  // Build Invisible Semantic Pick Meshes (UI-only Raycast Proxies)
  // ---------------------------------------------------------------------------
  useEffect(() => {
    const pickGroup = pickProxiesGroupRef.current;
    if (!pickGroup) return;

    // Clean existing pick meshes
    while (pickGroup.children.length > 0) {
      const child = pickGroup.children[0] as THREE.Mesh;
      pickGroup.remove(child);
      if (child.geometry) child.geometry.dispose();
      if (Array.isArray(child.material)) child.material.forEach((m) => m.dispose());
      else if (child.material) child.material.dispose();
    }

    if (!featureSelectionEnabled || featureGeometries.length === 0) return;

    for (const featGeom of featureGeometries) {
      if (!featGeom.selectable || !featGeom.geometry) continue;

      // Material for picking proxy (invisible unless debug mode is enabled)
      const proxyMat = new THREE.MeshBasicMaterial({
        color: featGeom.isCutterProxy ? 0xff0055 : 0x00f0ff,
        wireframe: true,
        transparent: true,
        opacity: isDebugProxies ? 0.45 : 0.0,
        visible: true, // MUST remain visible: true for Three.js raycasting to detect intersections!
        side: THREE.DoubleSide,
      });

      const proxyMesh = new THREE.Mesh(featGeom.geometry.clone(), proxyMat);
      proxyMesh.userData = {
        semanticFeatureId: featGeom.featureId,
        featureType: featGeom.featureType,
        geometryOperation: featGeom.geometryOperation,
        isCutterProxy: featGeom.isCutterProxy,
      };

      pickGroup.add(proxyMesh);
    }
  }, [featureGeometries, featureSelectionEnabled, isDebugProxies]);

  // ---------------------------------------------------------------------------
  // Render Feature Highlight Overlays for Selected Features
  // ---------------------------------------------------------------------------
  useEffect(() => {
    const highlightGroup = featureHighlightGroupRef.current;
    if (!highlightGroup) return;

    // Clean previous highlights
    while (highlightGroup.children.length > 0) {
      const child = highlightGroup.children[0] as THREE.Mesh;
      highlightGroup.remove(child);
      if (child.geometry) child.geometry.dispose();
      if (Array.isArray(child.material)) child.material.forEach((m) => m.dispose());
      else if (child.material) child.material.dispose();
    }

    if (activeSelectedIds.length === 0) return;

    for (const featId of activeSelectedIds) {
      const featGeom = featureGeomMap.get(featId);
      if (!featGeom || !featGeom.geometry) continue;

      const isCutter = featGeom.isCutterProxy;

      // Glowing translucent highlight mesh
      const highlightMat = new THREE.MeshStandardMaterial({
        color: isCutter ? 0xff0066 : 0x00e5ff,
        emissive: isCutter ? 0xff0066 : 0x00a0d0,
        emissiveIntensity: 0.6,
        roughness: 0.25,
        metalness: 0.8,
        transparent: true,
        opacity: isCutter ? 0.6 : 0.5,
        side: THREE.DoubleSide,
        depthTest: true,
      });

      const highlightMesh = new THREE.Mesh(featGeom.geometry.clone(), highlightMat);

      // Glowing edge outline
      const edgesGeom = new THREE.EdgesGeometry(featGeom.geometry, 20);
      const edgeLines = new THREE.LineSegments(
        edgesGeom,
        new THREE.LineBasicMaterial({
          color: isCutter ? 0xff55aa : 0x80ffff,
          linewidth: 2,
          transparent: true,
          opacity: 0.95,
        })
      );
      highlightMesh.add(edgeLines);

      highlightGroup.add(highlightMesh);
    }
  }, [activeSelectedIds, featureGeomMap]);

  // ---------------------------------------------------------------------------
  // Render 3D Direct Manipulation Handles & Gizmos
  // ---------------------------------------------------------------------------
  useEffect(() => {
    const manipGroup = manipulatorsGroupRef.current;
    if (!manipGroup) return;

    // Clean previous manipulators
    while (manipGroup.children.length > 0) {
      const child = manipGroup.children[0] as THREE.Object3D;
      manipGroup.remove(child);
      if ((child as any).geometry) (child as any).geometry.dispose();
      if (Array.isArray((child as any).material)) (child as any).material.forEach((m: any) => m.dispose());
      else if ((child as any).material) (child as any).material.dispose();
    }

    if (!manipulationDefinition || manipulationDefinition.manipulators.length === 0) return;

    for (const manip of manipulationDefinition.manipulators) {
      const handleRoot = new THREE.Group();
      handleRoot.position.set(manip.origin[0], manip.origin[1], manip.origin[2]);
      handleRoot.userData = { isManipulator: true, manipulator: manip };

      const isLocked = manip.locked;
      const isHovered = hoveredManipulator?.id === manip.id;
      const isActive = activeDragManipulator?.id === manip.id;

      // Axis / Type Color mapping
      let baseColor = 0x00f0ff;
      if (manip.axis === 'X') baseColor = 0xff385c; // Coral Red for X
      else if (manip.axis === 'Y') baseColor = 0x10b981; // Emerald Green for Y
      else if (manip.axis === 'Z') baseColor = 0x06b6d4; // Cyan Blue for Z
      else if (manip.type === 'DIAMETER' || manip.type === 'RADIUS') baseColor = 0xf59e0b; // Amber for Radial
      else if (manip.type === 'SPACING') baseColor = 0xa855f7; // Purple for Spacing
      else if (manip.type === 'WIDTH' || manip.type === 'LENGTH' || manip.type === 'HEIGHT' || manip.type === 'DEPTH' || manip.type === 'THICKNESS') {
        baseColor = 0xff3d8a; // KatPrint Pink for Dimension
      }

      if (isLocked) baseColor = 0x64748b; // Muted slate for locked

      const highlightColor = isActive ? 0xffffff : isHovered ? 0xffea00 : baseColor;

      const handleMat = new THREE.MeshStandardMaterial({
        color: highlightColor,
        emissive: highlightColor,
        emissiveIntensity: isActive ? 0.95 : isHovered ? 0.7 : 0.35,
        roughness: 0.25,
        metalness: 0.8,
        transparent: true,
        opacity: isLocked ? 0.45 : 0.95,
        depthTest: false, // Ensure handles render crisply on top of CAD geometry
      });

      if (manip.type === 'POSITION') {
        // Arrow pointing along direction
        const dir = new THREE.Vector3(...(manip.direction || [1, 0, 0])).normalize();
        const arrowLength = 22;
        const shaftRadius = isHovered || isActive ? 1.4 : 1.0;
        const headRadius = isHovered || isActive ? 2.8 : 2.2;
        const headLength = 6;

        const shaftGeom = new THREE.CylinderGeometry(shaftRadius, shaftRadius, arrowLength - headLength, 12);
        const headGeom = new THREE.ConeGeometry(headRadius, headLength, 16);

        shaftGeom.translate(0, (arrowLength - headLength) / 2, 0);
        headGeom.translate(0, arrowLength - headLength / 2, 0);

        const arrowGroup = new THREE.Group();
        const shaftMesh = new THREE.Mesh(shaftGeom, handleMat);
        const headMesh = new THREE.Mesh(headGeom, handleMat);
        arrowGroup.add(shaftMesh);
        arrowGroup.add(headMesh);

        // Align arrowGroup Y-axis with dir
        const up = new THREE.Vector3(0, 1, 0);
        arrowGroup.quaternion.setFromUnitVectors(up, dir);
        arrowGroup.userData = { isManipulatorHandle: true, manipulator: manip };
        shaftMesh.userData = { isManipulatorHandle: true, manipulator: manip };
        headMesh.userData = { isManipulatorHandle: true, manipulator: manip };

        handleRoot.add(arrowGroup);
      } else if (manip.type === 'DIAMETER' || manip.type === 'RADIUS') {
        // Ring or radial indicator around origin
        const radius = Math.max(4, manip.currentValue / 2);
        const tubeRadius = isHovered || isActive ? 1.2 : 0.8;
        const ringGeom = new THREE.TorusGeometry(radius, tubeRadius, 12, 32);

        const ringMesh = new THREE.Mesh(ringGeom, handleMat);
        ringMesh.userData = { isManipulatorHandle: true, manipulator: manip };
        handleRoot.add(ringMesh);

        // 4 grabbing node spheres at quadrants (0, 90, 180, 270 deg)
        for (let i = 0; i < 4; i++) {
          const angle = (i * Math.PI) / 2;
          const nodeGeom = new THREE.SphereGeometry(isHovered || isActive ? 2.0 : 1.5, 12, 12);
          const nodeMesh = new THREE.Mesh(nodeGeom, handleMat);
          nodeMesh.position.set(Math.cos(angle) * radius, Math.sin(angle) * radius, 0);
          nodeMesh.userData = { isManipulatorHandle: true, manipulator: manip };
          handleRoot.add(nodeMesh);
        }
      } else if (manip.type === 'SPACING') {
        // Double-ended spacing arrow
        const dir = new THREE.Vector3(...(manip.direction || [1, 0, 0])).normalize();
        const dist = Math.max(6, manip.currentValue / 2);
        const grabGeom = new THREE.SphereGeometry(isHovered || isActive ? 2.4 : 1.8, 12, 12);

        const grabMesh1 = new THREE.Mesh(grabGeom, handleMat);
        grabMesh1.position.copy(dir.clone().multiplyScalar(dist));
        grabMesh1.userData = { isManipulatorHandle: true, manipulator: manip };
        handleRoot.add(grabMesh1);

        const grabMesh2 = new THREE.Mesh(grabGeom, handleMat);
        grabMesh2.position.copy(dir.clone().multiplyScalar(-dist));
        grabMesh2.userData = { isManipulatorHandle: true, manipulator: manip };
        handleRoot.add(grabMesh2);

        // Line connecting them
        const lineGeom = new THREE.BufferGeometry().setFromPoints([
          dir.clone().multiplyScalar(-dist),
          dir.clone().multiplyScalar(dist),
        ]);
        const lineMat = new THREE.LineBasicMaterial({ color: highlightColor, linewidth: 2 });
        const lineMesh = new THREE.Line(lineGeom, lineMat);
        handleRoot.add(lineMesh);
      } else {
        // Dimension grab handle
        const dir = new THREE.Vector3(...(manip.direction || [1, 0, 0])).normalize();
        const dist = Math.max(6, manip.currentValue / 2);
        const grabGeom = new THREE.BoxGeometry(3.5, 3.5, 3.5);

        const grabMesh1 = new THREE.Mesh(grabGeom, handleMat);
        grabMesh1.position.copy(dir.clone().multiplyScalar(dist));
        grabMesh1.userData = { isManipulatorHandle: true, manipulator: manip };
        handleRoot.add(grabMesh1);

        const grabMesh2 = new THREE.Mesh(grabGeom, handleMat);
        grabMesh2.position.copy(dir.clone().multiplyScalar(-dist));
        grabMesh2.userData = { isManipulatorHandle: true, manipulator: manip };
        handleRoot.add(grabMesh2);
      }

      manipGroup.add(handleRoot);
    }
  }, [manipulationDefinition, hoveredManipulator, activeDragManipulator]);

  // ---------------------------------------------------------------------------
  // Camera Framing / Focus Method
  // ---------------------------------------------------------------------------
  const focusSelectedFeature = useCallback(
    (featureId: string) => {
      const featGeom = featureGeomMap.get(featureId);
      const camera = cameraRef.current;
      const controls = controlsRef.current;
      if (!featGeom || !camera || !controls) return;

      const [cx, cy, cz] = featGeom.center;
      const targetVec = new THREE.Vector3(cx, cy, cz);

      // Smoothly offset camera towards target
      controls.target.copy(targetVec);

      const dx = Math.max(15, featGeom.boundingBox.max[0] - featGeom.boundingBox.min[0]);
      const dy = Math.max(15, featGeom.boundingBox.max[1] - featGeom.boundingBox.min[1]);
      const dz = Math.max(15, featGeom.boundingBox.max[2] - featGeom.boundingBox.min[2]);
      const maxDim = Math.max(dx, dy, dz);

      const distance = Math.max(50, maxDim * 2.8);
      camera.position.set(cx + distance * 0.8, cy - distance * 0.8, cz + distance * 0.7);
      camera.lookAt(targetVec);
      controls.update();
    },
    [featureGeomMap]
  );

  // Synchronize camera focus when external focusFeature request is received
  useEffect(() => {
    if (focusFeature?.featureId) {
      focusSelectedFeature(focusFeature.featureId);
    }
  }, [focusFeature, focusSelectedFeature]);

  // ---------------------------------------------------------------------------
  // Pointer Event Handling (Manipulators, Hover, Click, Multi-Select, Raycasting)
  // ---------------------------------------------------------------------------
  const getRaycastHits = (clientX: number, clientY: number) => {
    if (!canvasRef.current || !cameraRef.current || !pickProxiesGroupRef.current) return [];
    const rect = canvasRef.current.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    const proxies = pickProxiesGroupRef.current.children;
    if (proxies.length === 0) return [];

    return raycaster.intersectObjects(proxies, false);
  };

  const getRaycastManipulators = (clientX: number, clientY: number) => {
    if (!canvasRef.current || !cameraRef.current || !manipulatorsGroupRef.current) return [];
    const rect = canvasRef.current.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    const children = manipulatorsGroupRef.current.children;
    if (children.length === 0) return [];

    return raycaster.intersectObjects(children, true);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    pointerDownPosRef.current = {
      x: e.clientX,
      y: e.clientY,
      time: Date.now(),
    };

    // 1. Check if clicking directly on a 3D Manipulator Handle
    const manipHits = getRaycastManipulators(e.clientX, e.clientY);
    const manipHit = manipHits.find((h) => h.object.userData?.isManipulatorHandle);

    if (manipHit && manipHit.object.userData?.manipulator) {
      const manip: FeatureManipulator = manipHit.object.userData.manipulator;

      if (isReadOnly || manip.locked) {
        return;
      }

      // Disable orbit camera controls during direct drag manipulation
      if (controlsRef.current) {
        controlsRef.current.enabled = false;
      }

      setActiveDragManipulator(manip);

      // Determine drag plane
      const camera = cameraRef.current;
      const dragPlane = dragPlaneRef.current;
      const originVec = new THREE.Vector3(...manip.origin);

      if (manip.type === 'POSITION' || manip.type === 'SPACING' || manip.type === 'WIDTH' || manip.type === 'LENGTH' || manip.type === 'HEIGHT') {
        const dir = new THREE.Vector3(...(manip.direction || [1, 0, 0])).normalize();
        const camView = camera ? camera.getWorldDirection(new THREE.Vector3()) : new THREE.Vector3(0, 0, -1);
        let planeNormal = camView.clone().cross(dir).cross(dir).normalize().negate();
        if (planeNormal.lengthSq() < 0.001) {
          planeNormal = camView.negate();
        }
        dragPlane.setFromNormalAndCoplanarPoint(planeNormal, originVec);
      } else {
        // Radial (XY plane)
        dragPlane.setFromNormalAndCoplanarPoint(new THREE.Vector3(0, 0, 1), originVec);
      }

      // Compute initial plane intersection point
      const rect = canvasRef.current!.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      const raycaster = new THREE.Raycaster();
      if (camera) raycaster.setFromCamera(new THREE.Vector2(x, y), camera);

      const startPt = new THREE.Vector3();
      raycaster.ray.intersectPlane(dragPlane, startPt);
      dragStartPlanePointRef.current.copy(startPt);

      // Initialize Ghost Mesh in Three.js for instant responsive visual feedback
      const ghostGroup = ghostPreviewGroupRef.current;
      if (ghostGroup) {
        while (ghostGroup.children.length > 0) {
          const child = ghostGroup.children[0] as THREE.Object3D;
          ghostGroup.remove(child);
          if ((child as any).geometry) (child as any).geometry.dispose();
          if ((child as any).material) (child as any).material.dispose();
        }

        for (const featId of activeSelectedIds) {
          const featGeom = featureGeomMap.get(featId);
          if (featGeom && featGeom.geometry) {
            const ghostMat = new THREE.MeshBasicMaterial({
              color: 0x00f0ff,
              wireframe: true,
              transparent: true,
              opacity: 0.8,
            });
            const ghostMesh = new THREE.Mesh(featGeom.geometry.clone(), ghostMat);
            ghostMesh.name = `ghost_${featId}`;
            ghostGroup.add(ghostMesh);
          }
        }
      }

      setManipulationPreview({
        featureId: manip.featureId,
        featureIds: [manip.featureId],
        manipulatorId: manip.id,
        manipulatorType: manip.type,
        axis: manip.axis,
        initialValue: manip.currentValue,
        currentValue: manip.currentValue,
        delta: 0,
        origin: manip.origin,
        parameterChanges: manip.parameterIds.map((pid) => ({
          parameterId: pid,
          featureId: manip.featureId,
          paramName: manip.label,
          oldValue: manip.currentValue,
          newValue: manip.currentValue,
          delta: 0,
          unit: manip.unit,
        })),
        isValid: true,
      });

      return;
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;

    // A. Handling Active Drag Manipulation
    if (activeDragManipulator) {
      const camera = cameraRef.current;
      if (!camera) return;

      const rect = canvasRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(x, y), camera);

      const currentPt = new THREE.Vector3();
      const hit = raycaster.ray.intersectPlane(dragPlaneRef.current, currentPt);

      if (hit) {
        let rawDelta = 0;
        const originVec = new THREE.Vector3(
          activeDragManipulator.origin[0],
          activeDragManipulator.origin[1],
          activeDragManipulator.origin[2]
        );

        if (activeDragManipulator.type === 'POSITION') {
          const dir = new THREE.Vector3(...(activeDragManipulator.direction || [1, 0, 0])).normalize();
          rawDelta = currentPt.clone().sub(dragStartPlanePointRef.current).dot(dir);
        } else if (activeDragManipulator.type === 'DIAMETER' || activeDragManipulator.type === 'RADIUS') {
          const startDist = dragStartPlanePointRef.current.distanceTo(originVec);
          const currDist = currentPt.distanceTo(originVec);
          rawDelta = (currDist - startDist) * (activeDragManipulator.type === 'DIAMETER' ? 2 : 1);
        } else if (activeDragManipulator.type === 'SPACING') {
          const dir = new THREE.Vector3(...(activeDragManipulator.direction || [1, 0, 0])).normalize();
          rawDelta = currentPt.clone().sub(dragStartPlanePointRef.current).dot(dir) * 2;
        } else {
          const dir = new THREE.Vector3(...(activeDragManipulator.direction || [1, 0, 0])).normalize();
          rawDelta = currentPt.clone().sub(dragStartPlanePointRef.current).dot(dir);
        }

        // Snapping: Shift = 0.1mm fine, Alt = free, default = currentSnapMm (1.0mm)
        const activeSnap = e.shiftKey ? 0.1 : e.altKey ? 0.01 : (currentSnapMm || 1.0);
        const snappedDelta = snapValue(rawDelta, activeSnap);
        let proposedValue = activeDragManipulator.currentValue + snappedDelta;

        // Clamp min/max bounds
        if (activeDragManipulator.min != null) proposedValue = Math.max(activeDragManipulator.min, proposedValue);
        if (activeDragManipulator.max != null) proposedValue = Math.min(activeDragManipulator.max, proposedValue);
        const finalDelta = proposedValue - activeDragManipulator.currentValue;

        // Validate parameter constraints
        const validation = featureModel
          ? validateManipulationConstraints(
              featureModel,
              activeDragManipulator.parameterIds.map((pid) => ({
                parameterId: pid,
                newValue: proposedValue,
              }))
            )
          : { valid: true, violations: [], clampedChanges: [] };

        setManipulationPreview({
          featureId: activeDragManipulator.featureId,
          featureIds: [activeDragManipulator.featureId],
          manipulatorId: activeDragManipulator.id,
          manipulatorType: activeDragManipulator.type,
          axis: activeDragManipulator.axis,
          initialValue: activeDragManipulator.currentValue,
          currentValue: proposedValue,
          delta: finalDelta,
          origin: activeDragManipulator.origin,
          parameterChanges: activeDragManipulator.parameterIds.map((pid) => ({
            parameterId: pid,
            featureId: activeDragManipulator.featureId,
            paramName: activeDragManipulator.label,
            oldValue: activeDragManipulator.currentValue,
            newValue: proposedValue,
            delta: finalDelta,
            unit: activeDragManipulator.unit,
          })),
          isValid: validation.valid,
          validationMessage: validation.violations.join(', ') || undefined,
        });

        // Update Ghost Mesh transform
        const ghostGroup = ghostPreviewGroupRef.current;
        if (ghostGroup && ghostGroup.children.length > 0) {
          if (activeDragManipulator.type === 'POSITION') {
            const dir = new THREE.Vector3(...(activeDragManipulator.direction || [1, 0, 0])).normalize();
            ghostGroup.position.copy(dir.clone().multiplyScalar(finalDelta));
          } else if (activeDragManipulator.type === 'DIAMETER' || activeDragManipulator.type === 'RADIUS') {
            const scale = activeDragManipulator.currentValue > 0 ? proposedValue / activeDragManipulator.currentValue : 1;
            ghostGroup.scale.set(scale, scale, 1);
          }
        }
      }

      if (canvasRef.current) canvasRef.current.style.cursor = 'grabbing';
      return;
    }

    // B. Check if dragging camera
    if (e.buttons > 0) {
      if (hoveredFeature) setHoveredFeature(null);
      if (hoveredManipulator) setHoveredManipulator(null);
      return;
    }

    // C. Check hover on 3D Manipulator handles
    const manipHits = getRaycastManipulators(e.clientX, e.clientY);
    const manipHit = manipHits.find((h) => h.object.userData?.isManipulatorHandle);

    if (manipHit && manipHit.object.userData?.manipulator) {
      const manip: FeatureManipulator = manipHit.object.userData.manipulator;
      setHoveredManipulator(manip);
      setHoveredFeature(null);
      if (canvasRef.current) canvasRef.current.style.cursor = manip.locked || isReadOnly ? 'not-allowed' : 'grab';
      return;
    }

    if (hoveredManipulator) {
      setHoveredManipulator(null);
    }

    // D. Check hover on semantic features
    if (!featureSelectionEnabled || featureGeometries.length === 0) return;

    const hits = getRaycastHits(e.clientX, e.clientY);
    const { primaryFeatureId } = rankSelectionIntersections(hits as any, featureGeomMap);

    if (primaryFeatureId) {
      const featGeom = featureGeomMap.get(primaryFeatureId);
      if (featGeom) {
        setHoveredFeature({
          featureId: primaryFeatureId,
          label: featGeom.label,
          type: featGeom.featureType,
          isCutter: featGeom.isCutterProxy,
          screenX: e.clientX,
          screenY: e.clientY,
        });
        if (canvasRef.current) canvasRef.current.style.cursor = 'pointer';
        return;
      }
    }

    if (hoveredFeature) {
      setHoveredFeature(null);
      if (canvasRef.current) canvasRef.current.style.cursor = 'default';
    }
  };

  const handlePointerUp = async (e: React.PointerEvent<HTMLCanvasElement>) => {
    // 1. Commit Active Drag Manipulation
    if (activeDragManipulator) {
      if (controlsRef.current) {
        controlsRef.current.enabled = true;
      }

      const manip = activeDragManipulator;
      const preview = manipulationPreview;

      setActiveDragManipulator(null);
      setHoveredManipulator(null);

      // Clean ghost mesh
      const ghostGroup = ghostPreviewGroupRef.current;
      if (ghostGroup) {
        ghostGroup.position.set(0, 0, 0);
        ghostGroup.scale.set(1, 1, 1);
        while (ghostGroup.children.length > 0) {
          const child = ghostGroup.children[0] as THREE.Object3D;
          ghostGroup.remove(child);
          if ((child as any).geometry) (child as any).geometry.dispose();
          if ((child as any).material) (child as any).material.dispose();
        }
      }

      if (preview && Math.abs(preview.delta) >= 0.001 && preview.isValid && onManipulationCommit) {
        if (manip.type === 'SPACING' && manipulationDefinition?.featureIds?.length === 2) {
          const featA = featureModel?.features.find((f) => f.id === manipulationDefinition.featureIds![0]);
          const featB = featureModel?.features.find((f) => f.id === manipulationDefinition.featureIds![1]);
          const paramA = featA?.parameterIds.find((id) => id.includes('pos') || id.includes('x') || id.includes('y'));
          const paramB = featB?.parameterIds.find((id) => id.includes('pos') || id.includes('x') || id.includes('y'));

          if (paramA && paramB) {
            const halfDelta = preview.delta / 2;
            const curValA = Number(featureModel?.parameters.find((p) => p.id === paramA)?.value ?? 0);
            const curValB = Number(featureModel?.parameters.find((p) => p.id === paramB)?.value ?? 0);

            await onManipulationCommit({
              featureId: manip.featureId,
              featureIds: manipulationDefinition.featureIds,
              manipulatorId: manip.id,
              manipulatorType: manip.type,
              parameterChanges: [
                { parameterId: paramA, newValue: curValA - halfDelta, oldValue: curValA, unit: manip.unit },
                { parameterId: paramB, newValue: curValB + halfDelta, oldValue: curValB, unit: manip.unit },
              ],
              instructionSummary: `Adjusted spacing between features to ${preview.currentValue} ${manip.unit}`,
            });
          }
        } else {
          await onManipulationCommit({
            featureId: manip.featureId,
            featureIds: [manip.featureId],
            manipulatorId: manip.id,
            manipulatorType: manip.type,
            parameterChanges: manip.parameterIds.map((pid) => ({
              parameterId: pid,
              newValue: preview.currentValue,
              oldValue: preview.initialValue,
              unit: manip.unit,
            })),
            instructionSummary: `Adjusted ${manip.label} to ${preview.currentValue} ${manip.unit}`,
          });
        }
      }

      setManipulationPreview(null);
      if (canvasRef.current) canvasRef.current.style.cursor = 'default';
      return;
    }

    const downPos = pointerDownPosRef.current;
    pointerDownPosRef.current = null;

    if (!downPos) return;

    const dist = Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y);
    const duration = Date.now() - downPos.time;

    // Only handle as click if movement < 6px and duration < 500ms
    if (dist >= 6 || duration >= 500) {
      return;
    }

    if (!featureSelectionEnabled) return;

    const hits = getRaycastHits(e.clientX, e.clientY);
    const { primaryFeatureId, candidates } = rankSelectionIntersections(hits as any, featureGeomMap);

    const isMultiKey = e.shiftKey || e.metaKey || e.ctrlKey;

    if (primaryFeatureId) {
      // Check if ambiguous (multiple distinct specific features overlapped)
      const topCandidates = candidates.filter((c) => c.priority >= 500);
      if (topCandidates.length > 1 && Math.abs(topCandidates[0].distance - topCandidates[1].distance) < 8) {
        // Show disambiguation popup WITHOUT pre-selecting
        setDisambiguationList({
          candidates: topCandidates,
          screenX: e.clientX,
          screenY: e.clientY,
          isMultiKey,
        });
        return;
      }

      setDisambiguationList(null);

      if (isMultiKey) {
        const nextIds = activeSelectedIds.includes(primaryFeatureId)
          ? activeSelectedIds.filter((id) => id !== primaryFeatureId)
          : [...activeSelectedIds, primaryFeatureId];

        if (onMultiSelectFeatures) {
          onMultiSelectFeatures(nextIds);
        }
        if (onSelectFeature) {
          onSelectFeature(nextIds[nextIds.length - 1] || null);
        }
      } else {
        onSelectFeature?.(primaryFeatureId);
        if (onMultiSelectFeatures) {
          onMultiSelectFeatures([primaryFeatureId]);
        }
      }
    } else {
      // Clicked on background: clear selection
      setDisambiguationList(null);
      onSelectFeature?.(null);
      if (onMultiSelectFeatures) onMultiSelectFeatures([]);
    }
  };

  // Keyboard shortcut: Escape to clear selection or cancel drag
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (activeDragManipulator) {
          if (controlsRef.current) controlsRef.current.enabled = true;
          setActiveDragManipulator(null);
          setManipulationPreview(null);
          const ghostGroup = ghostPreviewGroupRef.current;
          if (ghostGroup) {
            ghostGroup.position.set(0, 0, 0);
            ghostGroup.scale.set(1, 1, 1);
            while (ghostGroup.children.length > 0) {
              const child = ghostGroup.children[0] as THREE.Object3D;
              ghostGroup.remove(child);
            }
          }
          return;
        }

        setDisambiguationList(null);
        setHoveredFeature(null);
        setHoveredManipulator(null);
        onSelectFeature?.(null);
        if (onMultiSelectFeatures) onMultiSelectFeatures([]);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onSelectFeature, onMultiSelectFeatures, activeDragManipulator]);

  // ---------------------------------------------------------------------------
  // Camera Presets
  // ---------------------------------------------------------------------------
  const applyPreset = (preset: 'iso' | 'top' | 'front' | 'side') => {
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    if (!camera || !controls) return;

    setActivePreset(preset);
    controls.target.set(0, 0, (liveBounds?.z || 40) / 2);

    switch (preset) {
      case 'iso':
        camera.position.set(220, -260, 240);
        break;
      case 'top':
        camera.position.set(0, 0, 420);
        break;
      case 'front':
        camera.position.set(0, -420, (liveBounds?.z || 40) / 2);
        break;
      case 'side':
        camera.position.set(420, 0, (liveBounds?.z || 40) / 2);
        break;
    }
    controls.update();
  };

  // Direct Numeric Input Commit Handler
  const handleDirectNumericCommit = async (manip: FeatureManipulator) => {
    const num = parseFloat(directNumberInputVal);
    if (isNaN(num)) {
      setIsDirectNumberEditing(false);
      return;
    }

    const validation = featureModel
      ? validateManipulationConstraints(
          featureModel,
          manip.parameterIds.map((pid) => ({ parameterId: pid, newValue: num }))
        )
      : { valid: true, violations: [], clampedChanges: [] };

    if (!validation.valid) {
      alert(`Constraint violation: ${validation.violations.join(', ')}`);
      return;
    }

    setIsDirectNumberEditing(false);

    if (onManipulationCommit) {
      await onManipulationCommit({
        featureId: manip.featureId,
        featureIds: [manip.featureId],
        manipulatorId: manip.id,
        manipulatorType: manip.type,
        parameterChanges: manip.parameterIds.map((pid) => ({
          parameterId: pid,
          newValue: num,
          oldValue: manip.currentValue,
          unit: manip.unit,
        })),
        instructionSummary: `Set ${manip.label} to ${num} ${manip.unit}`,
      });
    }
  };


  return (
    <div
      ref={containerRef}
      id="viewport-container"
      className="relative w-full h-full bg-[#08080A] overflow-hidden select-none"
    >
      {/* 3D Canvas */}
      <canvas
        ref={canvasRef}
        id="cad-canvas"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="w-full h-full block touch-none"
      />

      {/* Floating Hover Tooltip */}
      {hoveredFeature && (
        <div
          className="fixed pointer-events-none z-50 transform -translate-x-1/2 -translate-y-full mb-3"
          style={{ left: hoveredFeature.screenX, top: hoveredFeature.screenY }}
        >
          <div className="bg-slate-900/95 backdrop-blur-md border border-cyan-500/50 shadow-2xl rounded-lg px-3 py-1.5 flex items-center gap-2 text-white animate-in fade-in zoom-in-95 duration-100">
            <Target className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <div className="flex flex-col">
              <span className="text-xs font-semibold tracking-tight">{hoveredFeature.label}</span>
              <div className="flex items-center gap-1 text-[10px] text-slate-400">
                <span className="font-mono text-cyan-300">{hoveredFeature.type}</span>
                <span>• Click to select</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Disambiguation Selection Menu */}
      {disambiguationList && (
        <div
          className="fixed z-50 transform -translate-x-1/2 mt-2 bg-slate-900/95 backdrop-blur-md border border-cyan-500/60 shadow-2xl rounded-xl p-2 text-white min-w-[200px]"
          style={{ left: disambiguationList.screenX, top: disambiguationList.screenY }}
        >
          <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-slate-800 text-[10px] uppercase font-bold text-slate-400 px-1">
            <span>Select Feature</span>
            <button
              type="button"
              onClick={() => setDisambiguationList(null)}
              className="text-slate-400 hover:text-white"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
          <div className="space-y-1">
            {disambiguationList.candidates.map((cand) => (
              <button
                key={cand.featureId}
                type="button"
                onClick={() => {
                  if (disambiguationList.isMultiKey) {
                    const nextIds = activeSelectedIds.includes(cand.featureId)
                      ? activeSelectedIds.filter((id) => id !== cand.featureId)
                      : [...activeSelectedIds, cand.featureId];
                    if (onMultiSelectFeatures) {
                      onMultiSelectFeatures(nextIds);
                    }
                    if (onSelectFeature) {
                      onSelectFeature(nextIds[nextIds.length - 1] || null);
                    }
                  } else {
                    onSelectFeature?.(cand.featureId);
                    if (onMultiSelectFeatures) {
                      onMultiSelectFeatures([cand.featureId]);
                    }
                  }
                  setDisambiguationList(null);
                }}
                className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-cyan-500/20 hover:text-cyan-200 flex items-center justify-between group transition"
              >
                <div className="flex items-center gap-2">
                  <Target className="w-3 h-3 text-cyan-400" />
                  <span className="font-medium">{cand.label}</span>
                </div>
                <span className="text-[10px] font-mono text-slate-400">{cand.featureType}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Top Left: Active Feature Selection HUD Badge */}
      {primarySelectedFeature && (
        <div className="absolute top-4 left-4 z-20 flex items-center gap-2 bg-slate-900/90 backdrop-blur-md border border-cyan-500/50 shadow-2xl px-3.5 py-2 rounded-xl text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-cyan-100">{primarySelectedFeature.label}</span>
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                  {primarySelectedFeature.type}
                </span>
                {activeSelectedIds.length > 1 && (
                  <span className="text-[10px] font-semibold text-indigo-300 bg-indigo-950 px-1.5 py-0.2 rounded border border-indigo-800">
                    +{activeSelectedIds.length - 1} more
                  </span>
                )}
              </div>
              <span className="text-[10px] text-slate-400 truncate max-w-[220px]">
                {primarySelectedFeature.purpose}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 ml-2 border-l border-slate-700/80 pl-2">
            <button
              type="button"
              onClick={() => focusSelectedFeature(primarySelectedFeature.id)}
              className="p-1 rounded text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition"
              title="Focus View on Feature"
            >
              <Eye className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => {
                onSelectFeature?.(null);
                if (onMultiSelectFeatures) onMultiSelectFeatures([]);
              }}
              className="p-1 rounded text-slate-400 hover:text-rose-300 hover:bg-slate-800 transition"
              title="Deselect Feature (Esc)"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Floating 3D Direct Manipulation HUD & Dimension Editor */}
      {manipulationDefinition && manipulationDefinition.manipulators.length > 0 && (
        <div className="absolute bottom-16 left-1/2 transform -translate-x-1/2 z-20 flex flex-col items-center gap-2 max-w-xl">
          {/* Main Floating Tool / Value Strip */}
          <div className="bg-slate-900/95 backdrop-blur-md border border-cyan-500/60 shadow-2xl px-4 py-2.5 rounded-2xl flex items-center gap-3 text-white">
            <div className="flex items-center gap-2 border-r border-slate-800 pr-3">
              <Move className="w-4 h-4 text-cyan-400" />
              <div className="flex flex-col">
                <span className="text-[10px] uppercase font-bold tracking-wider text-cyan-400">
                  3D Direct Manipulation
                </span>
                <span className="text-xs font-semibold text-slate-200">
                  {primarySelectedFeature?.name || manipulationDefinition.featureId}
                </span>
              </div>
            </div>

            {/* List of Manipulator Handles & Direct Value Badges */}
            <div className="flex items-center gap-2">
              {manipulationDefinition.manipulators.map((manip) => {
                const isHovered = hoveredManipulator?.id === manip.id;
                const isCurrentDrag = activeDragManipulator?.id === manip.id;
                const isEditingThis = isDirectNumberEditing && activeDirectManipId === manip.id;

                const displayVal =
                  isCurrentDrag && manipulationPreview
                    ? Number(manipulationPreview.currentValue.toFixed(2))
                    : Number(manip.currentValue.toFixed(2));

                return (
                  <div
                    key={manip.id}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs transition border ${
                      isCurrentDrag
                        ? 'bg-cyan-500/25 border-cyan-400 text-white shadow-lg shadow-cyan-500/20'
                        : isHovered
                        ? 'bg-slate-800 border-cyan-500/50 text-cyan-200'
                        : 'bg-slate-800/80 border-slate-700 text-slate-300'
                    }`}
                  >
                    <span className="text-[10px] font-mono text-slate-400">{manip.label}:</span>

                    {isEditingThis ? (
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          step="0.1"
                          autoFocus
                          value={directNumberInputVal}
                          onChange={(e) => setDirectNumberInputVal(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleDirectNumericCommit(manip);
                            if (e.key === 'Escape') setIsDirectNumberEditing(false);
                          }}
                          className="w-16 px-1.5 py-0.5 rounded bg-slate-950 border border-cyan-400 text-cyan-300 text-xs font-mono font-bold focus:outline-hidden"
                        />
                        <button
                          type="button"
                          onClick={() => handleDirectNumericCommit(manip)}
                          className="p-0.5 rounded hover:bg-cyan-500/20 text-cyan-400"
                        >
                          ✓
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          if (isReadOnly || manip.locked) return;
                          setActiveDirectManipId(manip.id);
                          setDirectNumberInputVal(String(manip.currentValue));
                          setIsDirectNumberEditing(true);
                        }}
                        disabled={isReadOnly || manip.locked}
                        className={`font-mono font-bold hover:underline cursor-pointer flex items-center gap-0.5 ${
                          manip.locked ? 'text-slate-500 cursor-not-allowed' : 'text-cyan-300 hover:text-cyan-100'
                        }`}
                        title={manip.locked ? 'Parameter is locked by constraint' : 'Click to type exact dimension'}
                      >
                        {displayVal}
                        <span className="text-[10px] font-normal text-slate-400">{manip.unit}</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Snapping Selection */}
            <div className="flex items-center gap-1 border-l border-slate-800 pl-3">
              <span className="text-[10px] font-mono text-slate-400">Snap:</span>
              {(['1.0', '0.5', '0.1', 'free'] as const).map((s) => {
                const val = s === 'free' ? 0.01 : parseFloat(s);
                const isSelected = currentSnapMm === val;
                return (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setCurrentSnapMm(val)}
                    className={`px-1.5 py-0.5 rounded text-[10px] font-mono transition ${
                      isSelected
                        ? 'bg-cyan-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    {s === 'free' ? 'Free' : `${s}mm`}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Live Dragging Feedback & Constraint Warning Banner */}
          {activeDragManipulator && manipulationPreview && (
            <div className="flex items-center gap-2">
              <div
                className={`px-3 py-1 rounded-lg text-[11px] font-mono shadow-xl flex items-center gap-2 border ${
                  manipulationPreview.isValid
                    ? 'bg-slate-900/90 text-cyan-300 border-cyan-500/40'
                    : 'bg-rose-950/90 text-rose-200 border-rose-500/60'
                }`}
              >
                <span>
                  Δ {manipulationPreview.delta >= 0 ? '+' : ''}
                  {manipulationPreview.delta.toFixed(2)} {activeDragManipulator.unit}
                </span>
                <span className="text-slate-500">•</span>
                <span>
                  Live: {manipulationPreview.currentValue.toFixed(2)} {activeDragManipulator.unit}
                </span>

                {!manipulationPreview.isValid && (
                  <span className="font-bold text-rose-400 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 text-rose-400 inline" />
                    {manipulationPreview.validationMessage || 'Constraint limit reached'}
                  </span>
                )}
              </div>
              <span className="text-[10px] text-slate-400 font-mono">Shift = 0.1mm • Alt = Free • Esc = Cancel</span>
            </div>
          )}
        </div>
      )}


      {/* Top Center Camera Presets */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 flex items-center gap-1 bg-kf-panel/90 backdrop-blur-md border border-kf-border p-1 rounded-lg shadow-xl z-10">
        <button
          id="btn-preset-iso"
          onClick={() => applyPreset('iso')}
          className={`px-2.5 py-1 rounded text-[11px] font-mono transition-colors ${
            activePreset === 'iso' ? 'bg-kf-pink text-white font-bold' : 'text-kf-muted hover:text-kf-text'
          }`}
        >
          ISO
        </button>
        <button
          id="btn-preset-top"
          onClick={() => applyPreset('top')}
          className={`px-2.5 py-1 rounded text-[11px] font-mono transition-colors ${
            activePreset === 'top' ? 'bg-kf-pink text-white font-bold' : 'text-kf-muted hover:text-kf-text'
          }`}
        >
          TOP
        </button>
        <button
          id="btn-preset-front"
          onClick={() => applyPreset('front')}
          className={`px-2.5 py-1 rounded text-[11px] font-mono transition-colors ${
            activePreset === 'front' ? 'bg-kf-pink text-white font-bold' : 'text-kf-muted hover:text-kf-text'
          }`}
        >
          FRONT
        </button>
        <button
          id="btn-preset-side"
          onClick={() => applyPreset('side')}
          className={`px-2.5 py-1 rounded text-[11px] font-mono transition-colors ${
            activePreset === 'side' ? 'bg-kf-pink text-white font-bold' : 'text-kf-muted hover:text-kf-text'
          }`}
        >
          SIDE
        </button>
        <div className="w-[1px] h-4 bg-kf-border mx-0.5" />
        <button
          id="btn-reset-view"
          onClick={() => applyPreset('iso')}
          className="p-1 rounded text-kf-muted hover:text-kf-text hover:bg-kf-panel-2 transition-colors"
          title="Reset Camera"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Top Right Viewport Controls */}
      <div className="absolute top-4 right-4 flex items-center gap-2 bg-kf-panel/90 backdrop-blur-md border border-kf-border p-1 rounded-lg shadow-xl z-10">
        <button
          id="btn-toggle-dimensions"
          onClick={toggleDimensions}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[11px] font-medium transition-colors ${
            showDimensions
              ? 'bg-kf-panel-2 text-[#00f0ff] border border-[#00f0ff]/40 shadow-xs'
              : 'text-kf-muted hover:text-kf-text'
          }`}
          title="Toggle 3D Leader Line Dimensions"
        >
          <Ruler className="w-3.5 h-3.5" />
          <span>Dimensions</span>
        </button>

        <button
          id="btn-toggle-overhangs"
          onClick={onToggleOverhangs}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[11px] font-medium transition-colors ${
            highlightOverhangs
              ? 'bg-kf-pink/15 text-kf-pink border border-kf-pink/40'
              : 'text-kf-muted hover:text-kf-text'
          }`}
          title="Toggle &gt;45° overhang warning heat map"
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>Overhangs</span>
        </button>

        <button
          id="btn-toggle-wireframe"
          onClick={() => setWireframe(!wireframe)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[11px] font-medium transition-colors ${
            wireframe
              ? 'bg-kf-pink/15 text-kf-pink border border-kf-pink/40'
              : 'text-kf-muted hover:text-kf-text hover:bg-kf-panel-2'
          }`}
          title="Toggle wireframe topology"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Wireframe</span>
        </button>

        <button
          id="btn-toggle-volume-cage"
          onClick={() => setShowVolumeCage(!showVolumeCage)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[11px] font-medium transition-colors ${
            showVolumeCage
              ? 'bg-kf-panel-2 text-kf-text border border-kf-border'
              : 'text-kf-muted hover:text-kf-text'
          }`}
          title="Toggle printer build volume boundary box"
        >
          <Box className="w-3.5 h-3.5" />
          <span>Volume Cage</span>
        </button>

        {featureGeometries.length > 0 && (
          <button
            id="btn-toggle-pick-proxies"
            onClick={toggleDebugProxies}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[11px] font-medium transition-colors ${
              isDebugProxies
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50'
                : 'text-kf-muted hover:text-kf-text'
            }`}
            title="Toggle Semantic Pick Proxies wireframe visibility"
          >
            <Target className="w-3.5 h-3.5" />
            <span>Proxies</span>
          </button>
        )}
      </div>

      {/* Live Dimension HUD Overlay in Viewport Bottom Left */}
      {liveBounds && geometry && (
        <div className="absolute bottom-4 left-4 flex flex-col gap-1.5 z-10">
          <div className="flex items-center gap-3 bg-kf-panel/90 backdrop-blur-md border border-kf-border px-3.5 py-2 rounded-lg shadow-xl text-[11px] font-mono text-kf-text">
            <div className="flex items-center gap-1.5">
              <span className="text-[#00f0ff] font-semibold">X:</span>
              <span>{liveBounds.x} mm</span>
            </div>
            <span className="text-kf-border">×</span>
            <div className="flex items-center gap-1.5">
              <span className="text-[#00f0ff] font-semibold">Y:</span>
              <span>{liveBounds.y} mm</span>
            </div>
            <span className="text-kf-border">×</span>
            <div className="flex items-center gap-1.5">
              <span className="text-[#00f0ff] font-semibold">Z:</span>
              <span>{liveBounds.z} mm</span>
            </div>
          </div>

          {referenceObject && (
            <div className="flex items-center gap-2 bg-kf-panel/90 backdrop-blur-md border border-kf-border px-3 py-1.5 rounded-lg shadow-xl text-[10px] font-mono">
              <span className="text-kf-muted">Fitting:</span>
              <span className="text-kf-text font-medium">{referenceObject.name}</span>
              <span
                className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                  referenceObject.confidence === 'verified'
                    ? 'bg-kf-green/15 text-kf-green border border-kf-green/30'
                    : 'bg-kf-warn/15 text-kf-warn border border-kf-warn/30'
                }`}
              >
                {referenceObject.confidence === 'verified' ? '✓ Verified Size' : '⚠ Estimated Size'}
              </span>
            </div>
          )}
        </div>
      )}

      {/* Bed Info Badge Bottom Right */}
      <div className="absolute bottom-4 right-4 bg-kf-panel/90 backdrop-blur-md border border-kf-border px-3.5 py-2 rounded-lg shadow-xl text-[11px] font-mono text-kf-muted flex items-center gap-2 z-10">
        <Grid className="w-3.5 h-3.5 text-kf-pink" />
        <span>
          Bed: {printer.buildVolume.x}×{printer.buildVolume.y}×{printer.buildVolume.z} mm
        </span>
      </div>

      {/* Empty State Overlay */}
      {!geometry && !isGenerating && (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-6 pointer-events-none bg-kf-bg/60 backdrop-blur-xs">
          <div className="flex flex-col items-center text-center max-w-sm">
            <svg className="w-24 h-24 mb-4" viewBox="0 0 96 96" fill="none" xmlns="http://www.w3.org/2000/svg">
              <line x1="12" y1="78" x2="84" y2="78" stroke="#FF3D8A" strokeWidth="1.5" strokeDasharray="4 4" />
              <line x1="32" y1="36" x2="68" y2="36" stroke="#3A3A46" strokeWidth="1.5" />
              <line x1="32" y1="36" x2="32" y2="68" stroke="#3A3A46" strokeWidth="1.5" />
              <line x1="68" y1="36" x2="68" y2="68" stroke="#3A3A46" strokeWidth="1.5" />
              <rect x="20" y="46" width="36" height="32" stroke="#3A3A46" strokeWidth="1.5" fill="none" />
              <line x1="20" y1="46" x2="32" y2="36" stroke="#3A3A46" strokeWidth="1.5" />
              <line x1="56" y1="46" x2="68" y2="36" stroke="#3A3A46" strokeWidth="1.5" />
              <line x1="56" y1="78" x2="68" y2="68" stroke="#3A3A46" strokeWidth="1.5" />
              <line x1="20" y1="78" x2="32" y2="68" stroke="#3A3A46" strokeWidth="1.5" />
            </svg>
            <h3 className="font-forge-serif text-lg font-bold text-kf-text mb-1">
              Describe what you want to 3D print.
            </h3>
            <p className="text-xs text-kf-muted font-sans">
              KatPrint will design the model, verify printability, and generate a clean STL.
            </p>
          </div>
        </div>
      )}

      {/* Loading State Overlay */}
      {isGenerating && (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-6 bg-kf-bg/75 backdrop-blur-sm pointer-events-none z-20">
          <div className="flex flex-col items-center gap-4">
            <div className="flex flex-col items-center gap-1.5">
              <div className="w-8 h-1.5 bg-kf-pink rounded-xs layer-anim-4 shadow-sm shadow-kf-pink/50" />
              <div className="w-14 h-1.5 bg-kf-pink rounded-xs layer-anim-3 shadow-sm shadow-kf-pink/50" />
              <div className="w-20 h-1.5 bg-kf-pink rounded-xs layer-anim-2 shadow-sm shadow-kf-pink/50" />
              <div className="w-28 h-1.5 bg-kf-pink rounded-xs layer-anim-1 shadow-sm shadow-kf-pink/50" />
            </div>
            <div className="flex flex-col items-center text-center">
              <span className="font-forge-serif text-sm font-semibold text-kf-text">
                Forging 3D Model...
              </span>
              <span className="text-[11px] font-mono text-kf-pink tracking-wide mt-0.5">
                GENERATING PARAMETRIC CAD &amp; SOLID GEOMETRY
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
