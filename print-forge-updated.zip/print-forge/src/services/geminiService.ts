import {
  ModelGeometryStats,
  PrinterSpec,
  FilamentSpec,
  SlicerSettings,
  ExtractedRequirements,
  DesignValidationReport,
  DesignSpecification,
  DesignCheck,
  FidelityReviewResult,
  GenerationMode,
  AIRequestRecord,
  ProjectReferenceImage,
} from '../types';
import {
  SemanticFeatureModel,
  SemanticRevisionOperation,
  FeatureBindingValidation,
} from '../features/featureTypes';
import {
  ProjectMemory,
  DesignChange,
} from '../projects/projectTypes';

export interface GenerateJscadResponse {
  code: string;
  source: 'ai' | 'template';
  generationId?: string;
  diagnostics?: any;
  requirements?: ExtractedRequirements;
  validationReport?: DesignValidationReport;
  explanation?: string;
}

export interface AiStageDiagnostics {
  modelUsed?: string;
  modelsUsed?: string[];
  aiCallsMade?: number;
  requestRecords?: AIRequestRecord[];
  durationMs?: number;
}

export interface ExtractRequirementsResponse {
  requirements: ExtractedRequirements;
  diagnostics?: AiStageDiagnostics;
}

export interface FidelityReviewResponse {
  review: FidelityReviewResult;
  diagnostics?: AiStageDiagnostics;
}

export function mapApiErrorMessage(err: any, status?: number): string {
  const str = String(err?.message || err || '');
  const s = status || (typeof err?.status === 'number' ? err.status : undefined) || (typeof err?.statusCode === 'number' ? err.statusCode : undefined);
  const cat = err?.errorCategory || '';

  // 1. Timeout errors handled FIRST (including 504 / DEADLINE_EXCEEDED)
  if (
    err?.isTimeout ||
    cat === 'REQUEST_TIMEOUT' ||
    cat === 'TIMEOUT_ERROR' ||
    s === 408 ||
    s === 504 ||
    str.includes('timed out') ||
    str.includes('timeout') ||
    str.includes('504') ||
    str.includes('DEADLINE_EXCEEDED') ||
    str.includes('Deadline expired') ||
    str.includes('AbortError')
  ) {
    return 'The AI operation timed out. Please try again with a simplified prompt or switch to Template Mode.';
  }

  // 2. 429 / Rate Limit / Quota
  if (
    s === 429 ||
    cat === 'QUOTA_EXCEEDED' ||
    cat === 'RATE_LIMIT' ||
    str.includes('429') ||
    str.includes('RESOURCE_EXHAUSTED') ||
    str.includes('quota') ||
    str.includes('Quota exceeded') ||
    str.includes('rate limit')
  ) {
    return 'Rate limit reached. Please wait a moment before generating again, or switch to Template Mode.';
  }

  // 3. 503 / UNAVAILABLE / Overloaded
  if (
    s === 503 ||
    cat === 'SERVICE_UNAVAILABLE' ||
    cat === 'GEMINI_UNAVAILABLE' ||
    str.includes('503') ||
    str.includes('UNAVAILABLE') ||
    str.includes('high demand') ||
    str.includes('overloaded')
  ) {
    return 'Gemini AI is experiencing high demand. Please try again in a few moments, or switch to Template Mode.';
  }

  // 4. Preserved high-level user-facing messages
  if (
    str.includes('Organic 3D Engine not configured') ||
    str.includes('Organic mesh generation provider not configured') ||
    str.includes('Hybrid organic/mechanical generation provider not configured') ||
    str.includes('Photo-to-Mesh provider not configured') ||
    str.includes('GEMINI_API_KEY is not configured') ||
    str.includes('AI model generation is unavailable') ||
    str.includes('Invalid or missing Gemini API credential')
  ) {
    return str;
  }

  // 5. HTML / JSON parsing / unexpected token errors (e.g. if server returned 502/504 HTML)
  if (
    str.includes('Unexpected token') ||
    str.includes('is not valid JSON') ||
    str.includes('<!doctype') ||
    str.includes('SyntaxError')
  ) {
    if (s && s >= 500) {
      return 'AI generation service is temporarily busy. Please try again in a few moments.';
    }
    return 'The server took too long to respond. Please try again or switch to Template Mode.';
  }

  // 6. Network connection error
  if (
    err?.isNetwork ||
    str.includes('Failed to fetch') ||
    str.includes('NetworkError') ||
    str.includes('ECONNREFUSED') ||
    str.includes('network')
  ) {
    return 'Unable to reach the CAD server. Please check your connection and retry.';
  }

  // 7. 4xx / Request Rejected
  if (
    (s && s >= 400 && s < 500) ||
    str.includes('400') ||
    str.includes('422') ||
    str.includes('INVALID_ARGUMENT')
  ) {
    return str || 'Request could not be processed. Try rephrasing your description.';
  }

  return str || 'An unexpected error occurred. Please try again.';
}

export function createApiError(data: any, status: number): Error & Record<string, any> {
  const message = data?.error || `Server responded with status ${status}`;
  const err: any = new Error(message);
  err.status = status;
  err.statusCode = status;
  err.errorCategory = data?.errorCategory || 'UNKNOWN_ERROR';
  err.technicalDetails = data?.technicalDetails;
  err.diagnostics = data?.diagnostics;
  err.raw = data;
  if (data?.canSimplifyToParametric !== undefined) {
    err.canSimplifyToParametric = data.canSimplifyToParametric;
  }
  if (data?.requirements) {
    err.requirements = data.requirements;
  }
  return err;
}

async function fetchWithTimeout(
  url: string,
  options: RequestInit = {},
  timeoutMs = 95000
): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    return response;
  } catch (err: any) {
    if (err.name === 'AbortError') {
      const timeoutError: any = new Error(`Request to ${url} timed out after ${Math.round(timeoutMs / 1000)}s.`);
      timeoutError.isTimeout = true;
      timeoutError.isNetwork = false;
      timeoutError.errorCategory = 'REQUEST_TIMEOUT';
      throw timeoutError;
    }
    throw err;
  } finally {
    clearTimeout(timeoutId);
  }
}

export async function extractPromptRequirements(
  prompt: string
): Promise<ExtractRequirementsResponse> {
  const res = await fetchWithTimeout('/api/extract-requirements', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt }),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    requirements: data.requirements,
    diagnostics: data.diagnostics,
  };
}

export async function requestJscadGeneration(
  prompt: string,
  options?: {
    requirements?: ExtractedRequirements;
    useTemplate?: boolean;
    simplifyToParametric?: boolean;
    mode?: GenerationMode;
    featureModel?: SemanticFeatureModel;
    designSpecification?: DesignSpecification;
    designChecklist?: DesignCheck[];
    referenceImages?: ProjectReferenceImage[];
  }
): Promise<GenerateJscadResponse> {
  let res: Response;
  try {
    res = await fetchWithTimeout('/api/generate-jscad', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt,
        requirements: options?.requirements,
        useTemplate: options?.useTemplate,
        simplifyToParametric: options?.simplifyToParametric,
        mode: options?.mode || 'precision',
        featureModel: options?.featureModel,
        designSpecification: options?.designSpecification,
        designChecklist: options?.designChecklist,
        referenceImages: options?.referenceImages,
      }),
    }, 95000);
  } catch (netErr: any) {
    console.error('Fetch network error during CAD generation:', netErr);
    const err: any = new Error(netErr.message || "Couldn't reach the server. Check your connection.");
    err.isNetwork = true;
    err.errorCategory = netErr.errorCategory || 'NETWORK_ERROR';
    throw err;
  }

  const rawText = await res.text();
  let data: any = {};
  try {
    data = JSON.parse(rawText);
  } catch (parseErr) {
    console.error('Non-JSON response received from /api/generate-jscad:', res.status, rawText.slice(0, 100));
    const err: any = new Error(res.ok ? "Couldn't reach the server. Check your connection." : `Server returned ${res.status}`);
    err.status = res.status;
    err.errorCategory = 'NETWORK_ERROR';
    throw err;
  }

  if (!res.ok) {
    console.error('Raw API Error from /api/generate-jscad:', res.status, data);
    throw createApiError(data, res.status);
  }

  if (!data.code) {
    throw new Error('No JSCAD code returned from server');
  }

  return {
    code: data.code,
    source: data.source || 'ai',
    generationId: data.generationId,
    diagnostics: data.diagnostics,
    requirements: data.requirements,
    validationReport: data.validationReport,
  };
}

export async function requestFidelityReview(payload: {
  specification: DesignSpecification;
  code: string;
  geometryStats: any;
  deterministicChecks: DesignCheck[];
  views: {
    isometric?: string;
    front?: string;
    rear?: string;
    top?: string;
    left?: string;
    right?: string;
  };
  purpose?: 'visual_fidelity_review' | 'final_visual_review';
}): Promise<FidelityReviewResponse> {
  const res = await fetchWithTimeout('/api/review-fidelity', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  const review: FidelityReviewResult = data.review;
  return {
    review,
    diagnostics: data.diagnostics,
  };
}

export async function requestTargetedRepair(payload: {
  originalPrompt: string;
  currentCode: string;
  specification: DesignSpecification;
  reviewResult: FidelityReviewResult;
  deterministicChecks: DesignCheck[];
  geometryStats: any;
  featureModel?: SemanticFeatureModel;
  bindingValidation?: FeatureBindingValidation;
  lockedParameterIds?: string[];
}): Promise<GenerateJscadResponse> {
  const res = await fetchWithTimeout('/api/targeted-repair', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    code: data.code,
    source: 'ai',
    generationId: data.generationId,
    diagnostics: data.diagnostics,
    requirements: data.requirements,
    validationReport: data.validationReport,
  };
}

export interface RevisionContextPayload {
  requestedChanges?: DesignChange[];
  preservedFeatures?: string[];
  designSpecification?: DesignSpecification | null;
  projectMemory?: ProjectMemory | Record<string, any>;
  recentConversation?: Array<{ role: string; content: string; timestamp?: string }>;
  featureModel?: SemanticFeatureModel;
  targetFeatureModel?: SemanticFeatureModel;
  semanticOperation?: SemanticRevisionOperation;
  bindingValidation?: FeatureBindingValidation;
  lockedParameterIds?: string[];
  selectedFeatureIds?: string[];
  selectedFeatureParameters?: string[];
}

export async function requestJscadRevision(payload: {
  originalPrompt: string;
  currentCode: string;
  revisionPrompt: string;
  userInstruction?: string;
  previousRequirements?: ExtractedRequirements;
  revisionContext?: RevisionContextPayload;
  referenceImages?: ProjectReferenceImage[];
}): Promise<GenerateJscadResponse> {
  const res = await fetchWithTimeout('/api/revise-jscad', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    code: data.code,
    source: data.source || 'ai',
    generationId: data.generationId,
    diagnostics: data.diagnostics,
    requirements: data.requirements,
    validationReport: data.validationReport,
  };
}

export async function requestFixMissingFeatures(payload: {
  originalPrompt: string;
  currentCode: string;
  requirements: ExtractedRequirements;
  missingFeatures: string[];
}): Promise<GenerateJscadResponse> {
  const res = await fetchWithTimeout('/api/fix-missing-features', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    code: data.code,
    source: 'ai',
    requirements: data.requirements,
    validationReport: data.validationReport,
  };
}

export async function requestSlicerExplanation(payload: {
  settings: SlicerSettings;
  geometry: ModelGeometryStats;
  printer: PrinterSpec;
  filament: FilamentSpec;
  mustHoldLiquid: boolean;
}): Promise<string> {
  let res: Response;
  try {
    res = await fetchWithTimeout('/api/explain-slicer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }, 95000);
  } catch (netErr: any) {
    console.error('Fetch network error during slicer explanation:', netErr);
    throw new Error("Couldn't reach the server. Check your connection.");
  }

  const rawText = await res.text();
  let data: any = {};
  try {
    data = JSON.parse(rawText);
  } catch (parseErr) {
    console.error('Non-JSON response received from /api/explain-slicer:', res.status, rawText.slice(0, 100));
    throw new Error(res.ok ? "Couldn't reach the server. Check your connection." : `Server responded with ${res.status}`);
  }

  if (!res.ok) {
    console.error('Raw API Error from /api/explain-slicer:', res.status, data);
    throw new Error(data.error || `Server responded with ${res.status}`);
  }

  return data.explanation;
}
