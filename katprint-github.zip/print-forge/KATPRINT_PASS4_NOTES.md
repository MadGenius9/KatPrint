# KatPrint Pass 4 — Generation Reliability

## Changes
- Precision multimodal targeted-repair loop can make up to 2 attempts instead of a hard-coded single attempt.
- Every repaired candidate is now re-audited for design intent and requirement coverage. The old pipeline reused the pre-repair audit, which could incorrectly score repaired geometry.
- Repair continuation now considers deterministic inspection, fidelity verdict, design-intent audit, critical audit defects, and unmet critical requirement coverage.
- Added a quality-improvement guard: if a repair does not improve the engineering candidate score, KatPrint stops spending AI calls on further repairs.
- Candidate history remains intact and the deterministic comparison gate still restores the best candidate, preventing a worse repair from replacing a better initial model.
- Generation diagnostics now report the actual number of repair attempts instead of deriving 0/1 from the final needsCorrection flag.

## Verification limitation
The uploaded project did not include node_modules. Full TypeScript/Vite/Vitest verification could not be executed in this environment without installing dependencies. Source changes were kept narrowly scoped to the existing precision-generation pipeline.
