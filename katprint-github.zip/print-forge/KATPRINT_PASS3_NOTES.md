# KatPrint Pass 3 — Photo Intelligence & Efficiency

## Changes
- Unified Image-to-Mesh uploads with the shared KatPrint image pipeline.
- Image-to-Mesh now inherits the same 25 MB validation and JPEG/PNG/WebP/HEIC/HEIF handling used by camera/photo inputs.
- Added an actionable HEIC fallback when a browser can send HEIC to Gemini but cannot decode it into a canvas for direct mesh tracing.
- Lazy-loaded the large Three.js `Viewer3D` module so it is not part of the initial UI execution path.
- Expanded Gemini photo analysis with a structured `reconstructionPlan` containing modeling strategy, primitives, boolean operations, critical/uncertain features, print orientation, and confidence.
- Strengthened the generated CAD brief so hidden geometry is not invented and uncertainty is explicitly carried into generation.

## Verification note
A full dependency install/build could not be completed in this environment because `npm install` timed out. The patch was therefore source-reviewed and packaged, but should still be built/tested by AI Studio/GitHub CI before production deployment.
