import type { Express, Request, Response } from 'express';
import type { GoogleGenAI } from '@google/genai';
import {
  PRIMARY_MODEL,
  callGeminiWithResilience,
  cleanErrorMessage,
  getErrorDiagnostics,
  getGeminiClient,
  AIRequestRecord,
} from '../gemini/client';

export interface PhotoAnalysisRequest {
  imageBase64?: string;
  imageDataUrl?: string;
  mimeType?: string;
  userPromptHint?: string;
  userKnownDimensions?: {
    widthMm?: number;
    heightMm?: number;
    depthMm?: number;
    referenceNote?: string;
  };
}

export interface PhotoAnalysisResponseData {
  primaryObject: string;
  probableObjectType: string;
  numberOfComponents: number;
  likelySeparateParts: Array<{
    name: string;
    description: string;
    printableSeparately: boolean;
  }>;
  symmetry: 'bilateral' | 'radial' | 'asymmetrical' | string;
  recognizableGeometry: string[];
  openingsHoles: string[];
  thinAreas: string[];
  proportions: string;
  estimatedDimensions: {
    known: boolean;
    reason: string;
    suggestedWidthMm?: number | null;
    suggestedHeightMm?: number | null;
    suggestedDepthMm?: number | null;
  };
  backgroundInterference: 'none' | 'low' | 'moderate' | 'high';
  imageQuality: 'excellent' | 'good' | 'fair' | 'poor';
  visibilityProblems: string[];
  additionalAnglesRecommended: boolean;
  recommendedAdditionalAngles: string[];
  likelyPrintabilityProblems: string[];
  suggestedPrompt: string;
  reconstructionPlan?: {
    modelingStrategy: string;
    primaryPrimitives: string[];
    booleanOperations: string[];
    criticalFeatures: string[];
    uncertainFeatures: string[];
    recommendedPrintOrientation: string;
    confidence: number;
  };
}

export async function analyzePhotoWithAI(
  ai: GoogleGenAI,
  data: PhotoAnalysisRequest
): Promise<{
  analysis: PhotoAnalysisResponseData;
  aiMetadata: {
    modelUsed: string;
    durationMs: number;
    requestRecords: AIRequestRecord[];
  };
}> {
  const startTime = Date.now();

  let mimeType = data.mimeType || 'image/jpeg';
  let base64Data = data.imageBase64 || '';

  if (data.imageDataUrl && data.imageDataUrl.startsWith('data:')) {
    const match = data.imageDataUrl.match(/^data:([^;]+);base64,(.+)$/);
    if (match) {
      mimeType = match[1];
      base64Data = match[2];
    }
  }

  if (!base64Data) {
    throw new Error('No image data provided for photo analysis.');
  }

  const systemInstruction = `You are a Senior Reverse Engineering Metrologist and 3D CAD Printing Specialist.
Analyze the provided photograph of an object to extract accurate physical, structural, and 3D printable manufacturing observations.

CRITICAL INSTRUCTIONS ON DIMENSIONS & SCALE:
- A single 2D photograph without a physical scale reference (such as a ruler, coin, or caliper) CANNOT determine exact physical millimeter dimensions.
- You must be honest: set estimatedDimensions.known = false unless the user provided known dimensions or a recognizable calibration object with fixed standard dimensions is clearly visible.
- Always explain why exact scale requires user confirmation or a reference object.
- If the user provided known dimensions (${JSON.stringify(data.userKnownDimensions || {})}), incorporate them into the calculations and proportions.

EXTRACT AND EVALUATE:
1. Primary object description and probable classification (functional mechanical, consumer accessory, enclosure, organizer, decorative, replacement bracket, etc.).
2. Number of logical components and whether they should be printed as separate interlocking/assembled parts (e.g., base + lid, main bracket + clamping arm).
3. Symmetry (bilateral, radial, rotational, or asymmetrical).
4. Recognizable CAD geometry (e.g., "cylindrical boss with chamfer", "hexagonal socket", "filleted outer perimeter", "countersunk screw holes").
5. Openings and through-holes (e.g., "cable passthrough notch", "M4 clearance holes", "ventilation slots").
6. Thin or fragile areas needing thickened reinforcement for FDM printing (minimum recommended 1.6mm-2.0mm wall thickness).
7. Proportions (aspect ratio, height-to-width ratio, diameter-to-depth).
8. Photographic quality check (lighting, shadows, occlusions, background clutter, blur).
9. Visibility limits: note any occluded sides (e.g., underside, back face) and advise if additional angles (top, side, rear, detail) would improve accuracy.
10. Printability challenges for 3D printing (overhangs exceeding 45 degrees, bridge spans, bed adhesion contact surface, layer orientation strength).
11. Build a reconstructionPlan for the CAD generator:
   - modelingStrategy: the safest parametric construction approach
   - primaryPrimitives: cylinders, boxes, extrusions, revolved profiles, etc.
   - booleanOperations: cuts/unions/intersections likely required
   - criticalFeatures: geometry that must survive reconstruction
   - uncertainFeatures: geometry hidden or ambiguous in the photos
   - recommendedPrintOrientation
   - confidence from 0-100
12. A suggestedPrompt that is not conversational fluff. It must be an implementation-ready CAD brief. Include object type, construction sequence, visible features, known dimensions, explicit unknowns, wall/clearance assumptions, part separation, symmetry, and print constraints. Never invent hidden geometry. Mark uncertain features for user confirmation.

Return strictly valid JSON conforming to the requested schema.`;

  const promptText = `Analyze this photographed object for 3D printing and CAD reconstruction.
User context / hints: "${data.userPromptHint || 'Analyze for 3D printable CAD reproduction'}"
User provided dimensions: ${JSON.stringify(data.userKnownDimensions || 'None specified')}`;

  const contents = [
    { text: promptText },
    {
      inlineData: {
        mimeType,
        data: base64Data,
      },
    },
  ];

  const result = await callGeminiWithResilience(ai, {
    purpose: 'photo_analysis',
    contents,
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
    },
    enableThinking: true,
    timeoutMs: 45000,
  });

  let parsed: any;
  try {
    const cleaned = result.text.trim().replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
    parsed = JSON.parse(cleaned);
  } catch (err) {
    console.error('Failed to parse photo analysis response as JSON:', result.text);
    parsed = {
      primaryObject: 'Unknown Object',
      probableObjectType: 'Custom mechanical part',
      numberOfComponents: 1,
      likelySeparateParts: [{ name: 'Main Body', description: 'Single contiguous part', printableSeparately: true }],
      symmetry: 'unknown',
      recognizableGeometry: ['Solid volumetric body'],
      openingsHoles: [],
      thinAreas: ['Ensure at least 1.6mm wall thickness for print durability'],
      proportions: 'Proportions extracted from visual frame',
      estimatedDimensions: {
        known: false,
        reason: 'Dimensions cannot be determined from a single 2D photo without a calibrated scale reference.',
      },
      backgroundInterference: 'low',
      imageQuality: 'good',
      visibilityProblems: ['Underside and rear angles are occluded'],
      additionalAnglesRecommended: true,
      recommendedAdditionalAngles: ['Top view', 'Rear side'],
      likelyPrintabilityProblems: ['Check overhangs and orientation before slicing'],
      suggestedPrompt: data.userPromptHint || 'Create a 3D printable model of this object',
      reconstructionPlan: {
        modelingStrategy: 'Parametric reconstruction from verified visible geometry',
        primaryPrimitives: ['Extruded or revolved primary body'],
        booleanOperations: [],
        criticalFeatures: [],
        uncertainFeatures: ['Rear and underside geometry require confirmation'],
        recommendedPrintOrientation: 'Largest stable planar face on build plate',
        confidence: 45,
      },
    };
  }

  // Fallback defaults if fields are missing
  const analysis: PhotoAnalysisResponseData = {
    primaryObject: parsed.primaryObject || 'Photographed Object',
    probableObjectType: parsed.probableObjectType || 'Custom Part',
    numberOfComponents: Number(parsed.numberOfComponents) || 1,
    likelySeparateParts: Array.isArray(parsed.likelySeparateParts) && parsed.likelySeparateParts.length > 0
      ? parsed.likelySeparateParts
      : [{ name: 'Main Body', description: 'Primary component', printableSeparately: true }],
    symmetry: parsed.symmetry || 'bilateral',
    recognizableGeometry: Array.isArray(parsed.recognizableGeometry) ? parsed.recognizableGeometry : [],
    openingsHoles: Array.isArray(parsed.openingsHoles) ? parsed.openingsHoles : [],
    thinAreas: Array.isArray(parsed.thinAreas) ? parsed.thinAreas : [],
    proportions: parsed.proportions || 'Standard aspect ratio',
    estimatedDimensions: {
      known: Boolean(parsed.estimatedDimensions?.known),
      reason:
        parsed.estimatedDimensions?.reason ||
        'Dimensions cannot be verified accurately from a 2D photograph alone without a physical ruler or calibration target.',
      suggestedWidthMm: parsed.estimatedDimensions?.suggestedWidthMm || null,
      suggestedHeightMm: parsed.estimatedDimensions?.suggestedHeightMm || null,
      suggestedDepthMm: parsed.estimatedDimensions?.suggestedDepthMm || null,
    },
    backgroundInterference: parsed.backgroundInterference || 'low',
    imageQuality: parsed.imageQuality || 'good',
    visibilityProblems: Array.isArray(parsed.visibilityProblems) ? parsed.visibilityProblems : [],
    additionalAnglesRecommended: Boolean(parsed.additionalAnglesRecommended),
    recommendedAdditionalAngles: Array.isArray(parsed.recommendedAdditionalAngles) ? parsed.recommendedAdditionalAngles : [],
    likelyPrintabilityProblems: Array.isArray(parsed.likelyPrintabilityProblems) ? parsed.likelyPrintabilityProblems : [],
    suggestedPrompt: parsed.suggestedPrompt || data.userPromptHint || 'Create a 3D printable model of this item',
    reconstructionPlan: parsed.reconstructionPlan ? {
      modelingStrategy: parsed.reconstructionPlan.modelingStrategy || 'Parametric reconstruction from visible geometry',
      primaryPrimitives: Array.isArray(parsed.reconstructionPlan.primaryPrimitives) ? parsed.reconstructionPlan.primaryPrimitives : [],
      booleanOperations: Array.isArray(parsed.reconstructionPlan.booleanOperations) ? parsed.reconstructionPlan.booleanOperations : [],
      criticalFeatures: Array.isArray(parsed.reconstructionPlan.criticalFeatures) ? parsed.reconstructionPlan.criticalFeatures : [],
      uncertainFeatures: Array.isArray(parsed.reconstructionPlan.uncertainFeatures) ? parsed.reconstructionPlan.uncertainFeatures : [],
      recommendedPrintOrientation: parsed.reconstructionPlan.recommendedPrintOrientation || 'Determine from largest stable planar face',
      confidence: Math.max(0, Math.min(100, Number(parsed.reconstructionPlan.confidence) || 50)),
    } : undefined,
  };

  return {
    analysis,
    aiMetadata: {
      modelUsed: result.model,
      durationMs: Date.now() - startTime,
      requestRecords: result.requestRecords,
    },
  };
}

export function registerPhotoAnalysis(app: Express, aiClient?: GoogleGenAI) {
  app.post('/api/analyze-photo', async (req: Request, res: Response) => {
    const ai = aiClient || getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        error: 'Gemini API is not configured or unavailable.',
        errorCategory: 'AI_UNAVAILABLE',
      });
    }

    try {
      const { imageBase64, imageDataUrl, mimeType, userPromptHint, userKnownDimensions } = req.body;
      if (!imageBase64 && !imageDataUrl) {
        return res.status(400).json({
          error: 'Missing image data in request payload.',
          errorCategory: 'INVALID_ARGUMENT',
        });
      }

      const result = await analyzePhotoWithAI(ai, {
        imageBase64,
        imageDataUrl,
        mimeType,
        userPromptHint,
        userKnownDimensions,
      });

      return res.json({
        success: true,
        analysis: result.analysis,
        aiMetadata: result.aiMetadata,
      });
    } catch (err: any) {
      console.error('Error in /api/analyze-photo:', err);
      const diagnostics = getErrorDiagnostics(err);
      return res.status(err.statusCode || 500).json({
        error: cleanErrorMessage(err.message || 'Photo analysis failed.'),
        errorCategory: err.errorCategory || 'PHOTO_ANALYSIS_ERROR',
        diagnostics,
      });
    }
  });
}
