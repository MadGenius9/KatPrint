import * as jscadModeling from '@jscad/modeling';
import { JSCAD_FEATURE_BUILDER_LIB } from '../../src/features/featureGenerators';

export function stripComments(code: string): string {
  return code
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .replace(/\/\/[^\n\r]*/g, ' ');
}

export function stripStringAndTemplateLiterals(code: string): string {
  return code
    .replace(/`(?:\\[\s\S]|[^`\\])*`/g, "''")
    .replace(/"(?:\\[\s\S]|[^"\\])*"/g, "''")
    .replace(/'(?:\\[\s\S]|[^'\\])*'/g, "''");
}

export function validateCodeSecurity(code: string): { isSafe: boolean; violation?: string } {
  // Step 1: Strip comments first
  const noComments = stripComments(code);

  // Step 2: Check forbidden import / require syntax on code without comments
  const modulePatterns = [
    { regex: /\bimport\s+.*?from\s+['"](?!@jscad\/|jscad)[^'"]+['"]/i, reason: 'External module imports are forbidden.' },
    { regex: /\bimport\s*\(/i, reason: 'Dynamic module import() is forbidden.' },
    { regex: /\brequire\s*\(\s*['"](?!@jscad\/|jscad)[^'"]+['"]\s*\)/i, reason: 'Dangerous CommonJS require() is forbidden.' },
  ];

  for (const { regex, reason } of modulePatterns) {
    if (regex.test(noComments)) {
      return { isSafe: false, violation: `Security violation: ${reason}` };
    }
  }

  // Step 3: Strip string and template literals to inspect only executable code tokens
  const executableOnly = stripStringAndTemplateLiterals(noComments);

  const executableForbiddenPatterns = [
    { regex: /\b(?:fetch|XMLHttpRequest|WebSocket|EventSource)\s*\(/i, reason: 'Network communication APIs are forbidden.' },
    { regex: /\beval\s*\(/i, reason: 'Dynamic code execution (eval) is forbidden.' },
    { regex: /\bnew\s+Function\b/i, reason: 'Dynamic Function constructor is forbidden.' },
    { regex: /\b(?:setTimeout|setInterval|setImmediate)\s*\(/i, reason: 'Timer manipulation is forbidden.' },
    { regex: /\bprocess\.(?:env|exit|kill|cwd|chdir|mainModule|binding|dlopen|argv|pid)\b/i, reason: 'Node.js process access is forbidden.' },
    { regex: /\bchild_process\b/i, reason: 'Process spawning is forbidden.' },
    { regex: /\b(?:window|document|localStorage|sessionStorage|indexedDB)\b/i, reason: 'DOM and browser storage access is forbidden.' },
    { regex: /\b(?:window|document)\s*\.\s*(?:location|cookie)\b/i, reason: 'DOM and browser storage access is forbidden.' },
    { regex: /\b(?:global|globalThis)\b/i, reason: 'Global scope access is forbidden.' },
    { regex: /\b(?:__proto__|prototype\.constructor)\b/i, reason: 'Prototype pollution is forbidden.' },
    { regex: /\bimportScripts\s*\(/i, reason: 'Dynamic script loading is forbidden.' },
    { regex: /\bWebAssembly\b/i, reason: 'WebAssembly execution is forbidden.' },
    { regex: /\b__dirname\b|\b__filename\b/i, reason: 'System path introspection is forbidden.' },
  ];

  for (const { regex, reason } of executableForbiddenPatterns) {
    if (regex.test(executableOnly)) {
      return { isSafe: false, violation: `Security violation: ${reason}` };
    }
  }

  return { isSafe: true };
}

// ---------------------------------------------------------------------------
// Server-Side JSCAD Execution Sandbox & Geometric Measurement
// ---------------------------------------------------------------------------
export interface GeometryMeasurements {
  dimensions: { x: number; y: number; z: number };
  boundingBox: [[number, number, number], [number, number, number]];
  polygonCount: number;
  triangleCount: number;
  vertexCount: number;
  actualVolumeMm3: number;
  volumeMm3: number;
  surfaceAreaMm2: number;
  nonManifoldEdgeCount: number;
  closureResidual: number;
  isClosed: boolean;
  isManifold: boolean;
  isNonEmpty: boolean;
}

export function measureJscadSolids(result: any): GeometryMeasurements | null {
  const solids = Array.isArray(result) ? result : [result];
  let minX = Infinity, minY = Infinity, minZ = Infinity;
  let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
  let polyCount = 0;
  let triangleCount = 0;
  let vertexCount = 0;
  let totalSignedVolume = 0;
  let totalSurfaceArea = 0;
  let hasValidPoly = false;
  let isFiniteCoords = true;
  let sumNx = 0;
  let sumNy = 0;
  let sumNz = 0;
  let totalArea = 0;

  const edgeMap = new Map<string, number>();

  for (const solid of solids) {
    if (!solid) continue;
    let polygons: any[] = [];
    if (solid.transforms && Array.isArray(solid.transforms) && jscadModeling.geometries?.geom3?.toPolygons) {
      try {
        polygons = jscadModeling.geometries.geom3.toPolygons(solid);
      } catch {
        polygons = (solid.toPolygons ? solid.toPolygons() : solid.polygons) || [];
      }
    } else {
      polygons = (solid.toPolygons ? solid.toPolygons() : solid.polygons) || [];
    }
    if (Array.isArray(polygons)) {
      polyCount += polygons.length;
      for (const poly of polygons) {
        const vertices = poly.vertices || poly;
        if (Array.isArray(vertices) && vertices.length >= 3) {
          hasValidPoly = true;
          vertexCount += vertices.length;

          // Fan triangulation of polygon: [v[0], v[i], v[i+1]]
          const v0 = vertices[0];
          const x0 = Number(v0?.[0]);
          const y0 = Number(v0?.[1]);
          const z0 = Number(v0?.[2]);

          if (!Number.isFinite(x0) || !Number.isFinite(y0) || !Number.isFinite(z0)) {
            isFiniteCoords = false;
            continue;
          }

          if (x0 < minX) minX = x0;
          if (x0 > maxX) maxX = x0;
          if (y0 < minY) minY = y0;
          if (y0 > maxY) maxY = y0;
          if (z0 < minZ) minZ = z0;
          if (z0 > maxZ) maxZ = z0;

          for (let i = 1; i < vertices.length - 1; i++) {
            const v1 = vertices[i];
            const v2 = vertices[i + 1];

            const x1 = Number(v1?.[0]);
            const y1 = Number(v1?.[1]);
            const z1 = Number(v1?.[2]);
            const x2 = Number(v2?.[0]);
            const y2 = Number(v2?.[1]);
            const z2 = Number(v2?.[2]);

            if (
              !Number.isFinite(x1) || !Number.isFinite(y1) || !Number.isFinite(z1) ||
              !Number.isFinite(x2) || !Number.isFinite(y2) || !Number.isFinite(z2)
            ) {
              isFiniteCoords = false;
              continue;
            }

            if (x1 < minX) minX = x1;
            if (x1 > maxX) maxX = x1;
            if (y1 < minY) minY = y1;
            if (y1 > maxY) maxY = y1;
            if (z1 < minZ) minZ = z1;
            if (z1 > maxZ) maxZ = z1;

            if (x2 < minX) minX = x2;
            if (x2 > maxX) maxX = x2;
            if (y2 < minY) minY = y2;
            if (y2 > maxY) maxY = y2;
            if (z2 < minZ) minZ = z2;
            if (z2 > maxZ) maxZ = z2;

            triangleCount++;

            // Signed tetrahedron volume calculation: (v0 . (v1 x v2)) / 6
            const signedTetraVolume =
              (x0 * (y1 * z2 - z1 * y2) +
                y0 * (z1 * x2 - x1 * z2) +
                z0 * (x1 * y2 - y1 * x2)) /
              6.0;
            totalSignedVolume += signedTetraVolume;

            // Surface Area from cross product
            const ax = x1 - x0;
            const ay = y1 - y0;
            const az = z1 - z0;
            const bx = x2 - x0;
            const by = y2 - y0;
            const bz = z2 - z0;

            const cx = ay * bz - az * by;
            const cy = az * bx - ax * bz;
            const cz = ax * by - ay * bx;
            const triArea = 0.5 * Math.hypot(cx, cy, cz);
            totalSurfaceArea += triArea;
            totalArea += triArea;

            sumNx += cx;
            sumNy += cy;
            sumNz += cz;

            // Undirected edge tracking for manifold verification (informational)
            const p0 = `${x0.toFixed(4)},${y0.toFixed(4)},${z0.toFixed(4)}`;
            const p1 = `${x1.toFixed(4)},${y1.toFixed(4)},${z1.toFixed(4)}`;
            const p2 = `${x2.toFixed(4)},${y2.toFixed(4)},${z2.toFixed(4)}`;

            const e1 = p0 < p1 ? `${p0}_${p1}` : `${p1}_${p0}`;
            const e2 = p1 < p2 ? `${p1}_${p2}` : `${p2}_${p1}`;
            const e3 = p2 < p0 ? `${p2}_${p0}` : `${p0}_${p2}`;

            edgeMap.set(e1, (edgeMap.get(e1) || 0) + 1);
            edgeMap.set(e2, (edgeMap.get(e2) || 0) + 1);
            edgeMap.set(e3, (edgeMap.get(e3) || 0) + 1);
          }
        }
      }
    }
  }

  if (!hasValidPoly || polyCount === 0 || !isFiniteCoords || minX === Infinity) {
    return null;
  }

  const dimX = Number(Math.max(0, maxX - minX).toFixed(2));
  const dimY = Number(Math.max(0, maxY - minY).toFixed(2));
  const dimZ = Number(Math.max(0, maxZ - minZ).toFixed(2));

  const actualVolumeMm3 = Number(Math.abs(totalSignedVolume).toFixed(2));
  const surfaceAreaMm2 = Number(totalSurfaceArea.toFixed(2));

  // In a closed triangular manifold mesh without boundary, every edge is shared by exactly 2 triangles
  let nonManifoldEdgeCount = 0;
  for (const count of edgeMap.values()) {
    if (count !== 2) {
      nonManifoldEdgeCount++;
    }
  }

  const sumNLen = Math.hypot(sumNx, sumNy, sumNz);
  const closureResidual = totalArea > 0 ? (sumNLen / 2) / totalArea : 1;
  const isClosed = closureResidual < 1e-6;

  const isManifold = isClosed && triangleCount >= 4 && actualVolumeMm3 > 0.001;
  const isNonEmpty = triangleCount > 0 && actualVolumeMm3 > 0.001 && (dimX > 0.1 || dimY > 0.1 || dimZ > 0.1);

  return {
    dimensions: { x: dimX, y: dimY, z: dimZ },
    boundingBox: [
      [Number(minX.toFixed(2)), Number(minY.toFixed(2)), Number(minZ.toFixed(2))],
      [Number(maxX.toFixed(2)), Number(maxY.toFixed(2)), Number(maxZ.toFixed(2))],
    ],
    polygonCount: polyCount,
    triangleCount,
    vertexCount,
    actualVolumeMm3,
    volumeMm3: actualVolumeMm3,
    surfaceAreaMm2,
    nonManifoldEdgeCount,
    closureResidual,
    isClosed,
    isManifold,
    isNonEmpty,
  };
}


export function measureIndividualJscadSolids(result: any): GeometryMeasurements[] {
  const solids = Array.isArray(result) ? result : [result];
  return solids.map((solid) => measureJscadSolids(solid)).filter((m): m is GeometryMeasurements => Boolean(m));
}

export function buildEnhancedJscadServerRuntime(modelingLib: any) {
  const rawJscad = (modelingLib as any)?.default?.primitives
    ? (modelingLib as any).default
    : (modelingLib as any)?.primitives
    ? (modelingLib as any)
    : ((modelingLib as any)?.default || (modelingLib as any) || {});

  const rawPrimitives = rawJscad.primitives || (modelingLib as any)?.primitives || {};
  const rawBooleans = rawJscad.booleans || (modelingLib as any)?.booleans || {};
  const rawTransforms = rawJscad.transforms || (modelingLib as any)?.transforms || {};
  const rawExtrusions = rawJscad.extrusions || (modelingLib as any)?.extrusions || {};
  const rawHulls = rawJscad.hulls || (modelingLib as any)?.hulls || {};
  const rawExpansions = rawJscad.expansions || (modelingLib as any)?.expansions || {};
  const rawGeometries = rawJscad.geometries || (modelingLib as any)?.geometries || {};
  const rawMeasurements = rawJscad.measurements || (modelingLib as any)?.measurements || {};
  const rawColors = rawJscad.colors || (modelingLib as any)?.colors || {};
  const rawMaths = rawJscad.maths || (modelingLib as any)?.maths || {};
  const rawUtils = rawJscad.utils || (modelingLib as any)?.utils || {};

  const normalizeVec3 = (arg0: any, arg1?: any, arg2?: any): [number, number, number] => {
    if (Array.isArray(arg0)) {
      return [Number(arg0[0]) || 0, Number(arg0[1]) || 0, Number(arg0[2]) || 0];
    }
    if (typeof arg0 === 'number') {
      return [arg0, Number(arg1) || 0, Number(arg2) || 0];
    }
    return [0, 0, 0];
  };

  const enhanceGeometry = (geom: any): any => {
    if (!geom || typeof geom !== 'object') return geom;
    if (Array.isArray(geom)) {
      for (let i = 0; i < geom.length; i++) {
        geom[i] = enhanceGeometry(geom[i]);
      }
      return geom;
    }
    if ((geom as any).__enhanced) return geom;

    try {
      Object.defineProperties(geom, {
        __enhanced: { value: true, writable: true, configurable: true },
        translate: {
          value: function (...args: any[]) {
            const offset = args.length === 1 && Array.isArray(args[0]) ? args[0] : normalizeVec3(args[0], args[1], args[2]);
            const res = rawTransforms.translate ? rawTransforms.translate(offset, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        rotate: {
          value: function (...args: any[]) {
            const angles = args.length === 1 && Array.isArray(args[0]) ? args[0] : normalizeVec3(args[0], args[1], args[2]);
            const res = rawTransforms.rotate ? rawTransforms.rotate(angles, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        rotateX: {
          value: function (rad: number) {
            const res = rawTransforms.rotateX ? rawTransforms.rotateX(rad, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        rotateY: {
          value: function (rad: number) {
            const res = rawTransforms.rotateY ? rawTransforms.rotateY(rad, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        rotateZ: {
          value: function (rad: number) {
            const res = rawTransforms.rotateZ ? rawTransforms.rotateZ(rad, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        scale: {
          value: function (...args: any[]) {
            let factors: any = args[0];
            if (typeof factors === 'number' && args.length === 1) {
              factors = [factors, factors, factors];
            } else if (typeof factors === 'number' && args.length >= 3) {
              factors = [factors, args[1], args[2]];
            }
            const res = rawTransforms.scale ? rawTransforms.scale(factors, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        center: {
          value: function (options: any = {}) {
            const res = rawTransforms.center ? rawTransforms.center(options, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        align: {
          value: function (options: any = {}) {
            const res = rawTransforms.align ? rawTransforms.align(options, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        mirror: {
          value: function (options: any = {}) {
            const res = rawTransforms.mirror ? rawTransforms.mirror(options, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        subtract: {
          value: function (...cuts: any[]) {
            return enhanceGeometry(safeSubtract(this, ...cuts));
          },
          writable: true,
          configurable: true,
        },
        union: {
          value: function (...others: any[]) {
            return enhanceGeometry(safeUnion(this, ...others));
          },
          writable: true,
          configurable: true,
        },
        intersect: {
          value: function (...others: any[]) {
            return enhanceGeometry(safeIntersect(this, ...others));
          },
          writable: true,
          configurable: true,
        },
        colorize: {
          value: function (color: any) {
            const res = rawColors.colorize ? rawColors.colorize(color, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
      });
    } catch {
      // Ignore if properties cannot be defined
    }
    return geom;
  };

  const safeCube = (options: any = {}) => {
    let opts = options;
    if (typeof opts === 'number') opts = { size: [opts, opts, opts] };
    else if (Array.isArray(opts)) opts = { size: opts };
    if (opts && Array.isArray(opts.size)) {
      if (typeof rawPrimitives.cuboid === 'function') return enhanceGeometry(rawPrimitives.cuboid(opts));
      if (typeof rawPrimitives.cube === 'function') return enhanceGeometry(rawPrimitives.cube(opts));
    }
    if (typeof rawPrimitives.cube === 'function') return enhanceGeometry(rawPrimitives.cube(opts));
    if (typeof rawPrimitives.cuboid === 'function') return enhanceGeometry(rawPrimitives.cuboid(opts));
    return null;
  };

  const safeRoundedCuboid = (options: any = {}) => {
    let opts = { ...options };
    if (opts.radius && !opts.roundRadius) opts.roundRadius = opts.radius;
    if (opts.round && !opts.roundRadius) opts.roundRadius = opts.round;
    if (!opts.roundRadius) opts.roundRadius = 1;
    if (typeof rawPrimitives.roundedCuboid === 'function') {
      try {
        return enhanceGeometry(rawPrimitives.roundedCuboid(opts));
      } catch {
        return safeCube(opts);
      }
    }
    return safeCube(opts);
  };

  const safeSubtract = (target: any, ...cuts: any[]) => {
    if (!target) return target;
    const flatCuts: any[] = [];
    for (const c of cuts) {
      if (Array.isArray(c)) flatCuts.push(...c);
      else if (c) flatCuts.push(c);
    }
    if (flatCuts.length === 0) return enhanceGeometry(target);
    if (typeof rawBooleans.subtract === 'function') {
      return enhanceGeometry(rawBooleans.subtract(target, ...flatCuts));
    }
    return enhanceGeometry(target);
  };

  const safeUnion = (...objects: any[]) => {
    const flat: any[] = [];
    for (const obj of objects) {
      if (Array.isArray(obj)) flat.push(...obj);
      else if (obj) flat.push(obj);
    }
    if (flat.length === 0) return safeCube({ size: 1 });
    if (flat.length === 1) return enhanceGeometry(flat[0]);
    if (typeof rawBooleans.union === 'function') {
      return enhanceGeometry(rawBooleans.union(...flat));
    }
    return enhanceGeometry(flat[0]);
  };

  const safeIntersect = (...objects: any[]) => {
    const flat: any[] = [];
    for (const obj of objects) {
      if (Array.isArray(obj)) flat.push(...obj);
      else if (obj) flat.push(obj);
    }
    if (typeof rawBooleans.intersect === 'function') {
      return enhanceGeometry(rawBooleans.intersect(...flat));
    }
    return enhanceGeometry(flat[0] || null);
  };

  const safeTranslate = (arg1: any, ...geoms: any[]) => {
    if (Array.isArray(arg1) || typeof arg1 === 'number') {
      const offset = normalizeVec3(arg1);
      const res = rawTransforms.translate ? rawTransforms.translate(offset, ...geoms) : geoms[0];
      return enhanceGeometry(res);
    }
    if (geoms.length > 0 && (Array.isArray(geoms[0]) || typeof geoms[0] === 'number')) {
      const offset = normalizeVec3(geoms[0]);
      const res = rawTransforms.translate ? rawTransforms.translate(offset, arg1) : arg1;
      return enhanceGeometry(res);
    }
    return enhanceGeometry(arg1);
  };

  const safeRotate = (arg1: any, ...geoms: any[]) => {
    if (Array.isArray(arg1) || typeof arg1 === 'number') {
      const angles = normalizeVec3(arg1);
      const res = rawTransforms.rotate ? rawTransforms.rotate(angles, ...geoms) : geoms[0];
      return enhanceGeometry(res);
    }
    if (geoms.length > 0 && (Array.isArray(geoms[0]) || typeof geoms[0] === 'number')) {
      const angles = normalizeVec3(geoms[0]);
      const res = rawTransforms.rotate ? rawTransforms.rotate(angles, arg1) : arg1;
      return enhanceGeometry(res);
    }
    return enhanceGeometry(arg1);
  };

  const safeRotateX = (rad: number, ...geoms: any[]) => {
    const res = rawTransforms.rotateX ? rawTransforms.rotateX(rad, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };
  const safeRotateY = (rad: number, ...geoms: any[]) => {
    const res = rawTransforms.rotateY ? rawTransforms.rotateY(rad, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };
  const safeCylinder = (...args: any[]) => {
    try {
      let opt: any = {};
      if (args.length === 1 && typeof args[0] === 'object' && args[0] !== null) {
        const o = args[0];
        const r = o.radius ?? o.r ?? (Array.isArray(o.startRadius) ? o.startRadius[0] : o.startRadius) ?? 5;
        const endR = o.endRadius ?? o.radius2 ?? o.r2 ?? o.topRadius;
        const h = o.height ?? o.h ?? o.length ?? 10;
        const segs = o.segments ?? o.fn ?? 32;

        if (endR !== undefined) {
          const r2 = Array.isArray(endR) ? endR[0] : endR;
          const res = rawPrimitives.cylinderElliptic
            ? rawPrimitives.cylinderElliptic({
                startRadius: [Math.max(0.001, Number(r) || 5), Math.max(0.001, Number(r) || 5)],
                endRadius: [Math.max(0.0001, Number(r2) || 0.0001), Math.max(0.0001, Number(r2) || 0.0001)],
                height: Math.max(0.001, Number(h) || 10),
                segments: segs,
                center: o.center ?? [0, 0, 0],
              })
            : rawPrimitives.cylinder({
                radius: Math.max(0.001, Number(r) || 5),
                height: Math.max(0.001, Number(h) || 10),
                segments: segs,
                center: o.center ?? [0, 0, 0],
              });
          return enhanceGeometry(res);
        }

        opt = {
          radius: Math.max(0.001, Number(r) || 5),
          height: Math.max(0.001, Number(h) || 10),
          segments: segs,
          center: o.center ?? [0, 0, 0],
        };
      } else if (args.length >= 2) {
        const r = typeof args[0] === 'number' ? args[0] : 5;
        const h = typeof args[1] === 'number' ? args[1] : 10;
        const segs = typeof args[2] === 'number' ? args[2] : 32;
        opt = { radius: Math.max(0.001, r), height: Math.max(0.001, h), segments: segs };
      } else {
        opt = args[0] || {};
      }

      const res = rawPrimitives.cylinder(opt);
      return enhanceGeometry(res);
    } catch {
      return enhanceGeometry(rawPrimitives.cylinder({ radius: 5, height: 10, segments: 16 }));
    }
  };

  const safeCone = (...args: any[]) => {
    try {
      let r1 = 10;
      let r2 = 0.001;
      let h = 20;
      let segs = 32;
      let center = [0, 0, 0];

      if (args.length === 1 && typeof args[0] === 'object' && args[0] !== null) {
        const opt = args[0];
        h = opt.height ?? opt.h ?? opt.length ?? 20;
        r1 =
          opt.bottomRadius ??
          opt.radius1 ??
          opt.r1 ??
          opt.radius ??
          opt.r ??
          (Array.isArray(opt.startRadius) ? opt.startRadius[0] : opt.startRadius) ??
          10;
        r2 =
          opt.topRadius ??
          opt.radius2 ??
          opt.r2 ??
          (Array.isArray(opt.endRadius) ? opt.endRadius[0] : opt.endRadius) ??
          0.001;
        segs = opt.segments ?? opt.fn ?? 32;
        if (opt.center) center = opt.center;
      } else if (args.length === 1 && typeof args[0] === 'number') {
        r1 = args[0];
        r2 = 0.001;
        h = 20;
      } else if (args.length >= 2) {
        if (args.length === 2) {
          r1 = typeof args[0] === 'number' ? args[0] : 10;
          r2 = 0.001;
          h = typeof args[1] === 'number' ? args[1] : 20;
        } else {
          r1 = typeof args[0] === 'number' ? args[0] : 10;
          r2 = typeof args[1] === 'number' ? Math.max(0.0001, args[1]) : 0.001;
          h = typeof args[2] === 'number' ? args[2] : 20;
          if (typeof args[3] === 'number') segs = args[3];
        }
      }

      const startR = Math.max(0.001, Number(r1) || 10);
      const endR = Math.max(0.0001, Number(r2) || 0.0001);
      const height = Math.max(0.001, Number(h) || 20);

      const res = rawPrimitives.cylinderElliptic
        ? rawPrimitives.cylinderElliptic({
            startRadius: [startR, startR],
            endRadius: [endR, endR],
            height: height,
            segments: segs,
            center: center,
          })
        : rawPrimitives.cylinder({
            radius: startR,
            height: height,
            segments: segs,
            center: center,
          });
      return enhanceGeometry(res);
    } catch {
      return enhanceGeometry(rawPrimitives.cylinder({ radius: 10, height: 20, segments: 16 }));
    }
  };

  const safeTube = (...args: any[]) => {
    try {
      let outerR = 10;
      let innerR = 8;
      let h = 20;
      let segs = 32;
      if (args.length === 1 && typeof args[0] === 'object' && args[0] !== null) {
        const o = args[0];
        outerR = o.outerRadius ?? o.radius ?? o.r ?? 10;
        innerR = o.innerRadius ?? (o.wallThickness ? outerR - o.wallThickness : outerR - 2);
        h = o.height ?? o.h ?? 20;
        segs = o.segments ?? o.fn ?? 32;
      } else if (args.length >= 2) {
        outerR = Number(args[0]) || 10;
        innerR = Number(args[1]) || 8;
        h = Number(args[2]) || 20;
        if (args[3]) segs = Number(args[3]);
      }
      const outer = safeCylinder({ radius: outerR, height: h, segments: segs });
      const inner = safeCylinder({ radius: Math.min(innerR, outerR - 0.1), height: h + 4, segments: segs });
      return safeSubtract(outer, inner);
    } catch {
      return enhanceGeometry(rawPrimitives.cylinder({ radius: 10, height: 20 }));
    }
  };

  const safeRotateZ = (rad: number, ...geoms: any[]) => {
    const res = rawTransforms.rotateZ ? rawTransforms.rotateZ(rad, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };

  const safeScale = (factors: any, ...geoms: any[]) => {
    // If no geometry provided, return curried function: scale(factors)(geom)
    if (geoms.length === 0) {
      return (...lateGeoms: any[]) => safeScale(factors, ...lateGeoms);
    }
    // If geometry passed first: scale(geom, factors)
    if (
      factors &&
      (factors.polygons || factors.sides || (typeof factors === 'object' && !Array.isArray(factors))) &&
      (typeof geoms[0] === 'number' || Array.isArray(geoms[0]))
    ) {
      const swappedGeom = factors;
      let f = geoms[0];
      if (typeof f === 'number') f = [f, f, f];
      const res = rawTransforms.scale ? rawTransforms.scale(f, swappedGeom) : swappedGeom;
      return enhanceGeometry(res);
    }
    let f = factors;
    if (typeof f === 'number') f = [f, f, f];
    const res = rawTransforms.scale ? rawTransforms.scale(f, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };

  const wrapPrimitive = (fn: any) => {
    if (typeof fn !== 'function') return () => null;
    return (...args: any[]) => {
      try {
        const res = fn(...args);
        return enhanceGeometry(res);
      } catch {
        return null;
      }
    };
  };

  const primitives = {
    ...rawPrimitives,
    cube: safeCube,
    cuboid: wrapPrimitive(rawPrimitives.cuboid) || safeCube,
    cylinder: safeCylinder,
    cone: safeCone,
    tube: safeTube,
    pipe: safeTube,
    cylinderElliptic: wrapPrimitive(rawPrimitives.cylinderElliptic),
    roundedCylinder: wrapPrimitive(rawPrimitives.roundedCylinder),
    sphere: wrapPrimitive(rawPrimitives.sphere),
    geodesicSphere: wrapPrimitive(rawPrimitives.geodesicSphere),
    ellipsoid: wrapPrimitive(rawPrimitives.ellipsoid),
    polyhedron: wrapPrimitive(rawPrimitives.polyhedron),
    roundedCuboid: safeRoundedCuboid,
    torus: wrapPrimitive(rawPrimitives.torus),
    polygon: wrapPrimitive(rawPrimitives.polygon),
    rectangle: wrapPrimitive(rawPrimitives.rectangle),
    roundedRectangle: wrapPrimitive(rawPrimitives.roundedRectangle),
    circle: wrapPrimitive(rawPrimitives.circle),
    ellipse: wrapPrimitive(rawPrimitives.ellipse),
    star: wrapPrimitive(rawPrimitives.star),
  };

  const transforms = {
    ...rawTransforms,
    translate: safeTranslate,
    rotate: safeRotate,
    rotateX: safeRotateX,
    rotateY: safeRotateY,
    rotateZ: safeRotateZ,
    scale: safeScale,
    center: (options: any, ...geoms: any[]) => enhanceGeometry(rawTransforms.center ? rawTransforms.center(options, ...geoms) : geoms[0]),
    align: (options: any, ...geoms: any[]) => enhanceGeometry(rawTransforms.align ? rawTransforms.align(options, ...geoms) : geoms[0]),
    mirror: (options: any, ...geoms: any[]) => enhanceGeometry(rawTransforms.mirror ? rawTransforms.mirror(options, ...geoms) : geoms[0]),
    transform: (matrix: any, ...geoms: any[]) => enhanceGeometry(rawTransforms.transform ? rawTransforms.transform(matrix, ...geoms) : geoms[0]),
  };

  const booleans = {
    ...rawBooleans,
    union: safeUnion,
    subtract: safeSubtract,
    intersect: safeIntersect,
  };

  const extrusions = {
    ...rawExtrusions,
    extrudeLinear: (options: any, ...geoms: any[]) => enhanceGeometry(rawExtrusions.extrudeLinear ? rawExtrusions.extrudeLinear(options, ...geoms) : geoms[0]),
    extrudeRotate: (options: any, ...geoms: any[]) => enhanceGeometry(rawExtrusions.extrudeRotate ? rawExtrusions.extrudeRotate(options, ...geoms) : geoms[0]),
    extrudeRectangular: (options: any, ...geoms: any[]) => enhanceGeometry(rawExtrusions.extrudeRectangular ? rawExtrusions.extrudeRectangular(options, ...geoms) : geoms[0]),
    slice: (options: any, ...geoms: any[]) => enhanceGeometry(rawExtrusions.slice ? rawExtrusions.slice(options, ...geoms) : geoms[0]),
  };

  const hulls = {
    ...rawHulls,
    hull: (...geoms: any[]) => enhanceGeometry(rawHulls.hull ? rawHulls.hull(...geoms) : geoms[0]),
    hullChain: (...geoms: any[]) => enhanceGeometry(rawHulls.hullChain ? rawHulls.hullChain(...geoms) : geoms[0]),
  };

  const expansions = {
    ...rawExpansions,
    expand: (options: any, ...geoms: any[]) => enhanceGeometry(rawExpansions.expand ? rawExpansions.expand(options, ...geoms) : geoms[0]),
    offset: (options: any, ...geoms: any[]) => enhanceGeometry(rawExpansions.offset ? rawExpansions.offset(options, ...geoms) : geoms[0]),
  };

  const colors = {
    ...rawColors,
    colorize: (color: any, ...geoms: any[]) => enhanceGeometry(rawColors.colorize ? rawColors.colorize(color, ...geoms) : geoms[0]),
  };

  const jscad = {
    ...rawJscad,
    primitives,
    booleans,
    transforms,
    extrusions,
    hulls,
    expansions,
    geometries: rawGeometries,
    measurements: rawMeasurements,
    colors,
    maths: rawMaths,
    utils: rawUtils,
    ...primitives,
    ...booleans,
    ...transforms,
    ...extrusions,
    ...hulls,
    ...expansions,
    ...colors,
    scale: safeScale,
    translate: safeTranslate,
    rotate: safeRotate,
    union: safeUnion,
    subtract: safeSubtract,
    intersect: safeIntersect,
  };

  const safeRequire = (moduleName: string) => {
    if (!moduleName || typeof moduleName !== 'string') return jscad;
    const clean = moduleName.trim().toLowerCase();
    if (clean.endsWith('/transforms') || clean.endsWith('.transforms')) return transforms;
    if (clean.endsWith('/primitives') || clean.endsWith('.primitives')) return primitives;
    if (clean.endsWith('/booleans') || clean.endsWith('.booleans')) return booleans;
    if (clean.endsWith('/extrusions') || clean.endsWith('.extrusions')) return extrusions;
    if (clean.endsWith('/hulls') || clean.endsWith('.hulls')) return hulls;
    if (clean.endsWith('/expansions') || clean.endsWith('.expansions')) return expansions;
    if (clean.endsWith('/measurements') || clean.endsWith('.measurements')) return rawMeasurements;
    if (clean.endsWith('/colors') || clean.endsWith('.colors')) return colors;
    if (
      clean === '@jscad/modeling' ||
      clean === 'jscad' ||
      clean === '@jscad/csg' ||
      clean === 'openjscad' ||
      clean.includes('jscad')
    ) {
      return jscad;
    }
    throw new Error(`Module '${moduleName}' is not allowed in CAD sandbox`);
  };

  return {
    jscad,
    primitives,
    booleans,
    transforms,
    extrusions,
    hulls,
    expansions,
    geometries: rawGeometries,
    measurements: rawMeasurements,
    colors,
    maths: rawMaths,
    utils: rawUtils,
    safeCube,
    safeRoundedCuboid,
    safeCylinder,
    safeCone,
    safeTube,
    safeSubtract,
    safeUnion,
    safeIntersect,
    safeTranslate,
    safeRotate,
    safeRotateX,
    safeRotateY,
    safeRotateZ,
    safeScale,
    safeRequire,
    enhanceGeometry,
  };
}

export const serverCadRuntime = buildEnhancedJscadServerRuntime(jscadModeling);

export function executeJscadServerSide(codeString: string): {
  success: boolean;
  error?: string;
  measurements?: GeometryMeasurements;
  polygonCount?: number;
  partMeasurements?: GeometryMeasurements[];
  parts?: any[] | null;
  solids?: any;
} {
  try {
    // 1. Strict Security Validation
    const security = validateCodeSecurity(codeString);
    if (!security.isSafe) {
      return { success: false, error: security.violation };
    }

    // 2. Syntax extract and normalize
    const cleanCode = extractAndValidateJscad(codeString);
    if (!cleanCode) {
      return { success: false, error: 'Code does not contain a valid main() function declaration' };
    }

    // Isolated sandbox scope: mask dangerous globals as undefined
    const scopeKeys = [
      'process',
      'global',
      'globalThis',
      'fetch',
      'XMLHttpRequest',
      'WebSocket',
      'localStorage',
      'sessionStorage',
      'window',
      'document',
      'require',
      'jscad',
      'jscadModeling',
      'jscad_modeling',
      'modeling',
      'JSCAD',
      'CSG',
      'primitives',
      'booleans',
      'transforms',
      'extrusions',
      'hulls',
      'expansions',
      'geometries',
      'measurements',
      'colors',
      'maths',
      'utils',
      'cube',
      'cuboid',
      'cylinder',
      'cone',
      'tube',
      'pipe',
      'cylinderElliptic',
      'roundedCylinder',
      'sphere',
      'geodesicSphere',
      'ellipsoid',
      'polyhedron',
      'roundedCuboid',
      'torus',
      'polygon',
      'rectangle',
      'roundedRectangle',
      'circle',
      'ellipse',
      'star',
      'union',
      'subtract',
      'intersect',
      'translate',
      'rotate',
      'rotateX',
      'rotateY',
      'rotateZ',
      'scale',
      'center',
      'align',
      'mirror',
      'transform',
      'extrudeLinear',
      'extrudeRotate',
      'extrudeRectangular',
      'slice',
      'hull',
      'hullChain',
      'expand',
      'offset',
      'colorize',
    ];

    const scopeValues = [
      undefined, // process
      undefined, // global
      undefined, // globalThis
      undefined, // fetch
      undefined, // XMLHttpRequest
      undefined, // WebSocket
      undefined, // localStorage
      undefined, // sessionStorage
      undefined, // window
      undefined, // document
      serverCadRuntime.safeRequire,
      serverCadRuntime.jscad,
      serverCadRuntime.jscad,
      serverCadRuntime.jscad,
      serverCadRuntime.jscad,
      serverCadRuntime.jscad,
      serverCadRuntime.jscad,
      serverCadRuntime.primitives,
      serverCadRuntime.booleans,
      serverCadRuntime.transforms,
      serverCadRuntime.extrusions,
      serverCadRuntime.hulls,
      serverCadRuntime.expansions,
      serverCadRuntime.geometries,
      serverCadRuntime.measurements,
      serverCadRuntime.colors,
      serverCadRuntime.maths,
      serverCadRuntime.utils,
      serverCadRuntime.safeCube,
      serverCadRuntime.primitives.cuboid || serverCadRuntime.safeCube,
      serverCadRuntime.safeCylinder,
      serverCadRuntime.safeCone,
      serverCadRuntime.safeTube,
      serverCadRuntime.safeTube,
      serverCadRuntime.primitives.cylinderElliptic,
      serverCadRuntime.primitives.roundedCylinder,
      serverCadRuntime.primitives.sphere,
      serverCadRuntime.primitives.geodesicSphere,
      serverCadRuntime.primitives.ellipsoid,
      serverCadRuntime.primitives.polyhedron,
      serverCadRuntime.safeRoundedCuboid,
      serverCadRuntime.primitives.torus,
      serverCadRuntime.primitives.polygon,
      serverCadRuntime.primitives.rectangle,
      serverCadRuntime.primitives.roundedRectangle,
      serverCadRuntime.primitives.circle,
      serverCadRuntime.primitives.ellipse,
      serverCadRuntime.primitives.star,
      serverCadRuntime.safeUnion,
      serverCadRuntime.safeSubtract,
      serverCadRuntime.safeIntersect,
      serverCadRuntime.safeTranslate,
      serverCadRuntime.safeRotate,
      serverCadRuntime.safeRotateX,
      serverCadRuntime.safeRotateY,
      serverCadRuntime.safeRotateZ,
      serverCadRuntime.safeScale,
      serverCadRuntime.transforms.center,
      serverCadRuntime.transforms.align,
      serverCadRuntime.transforms.mirror,
      serverCadRuntime.transforms.transform,
      serverCadRuntime.extrusions.extrudeLinear,
      serverCadRuntime.extrusions.extrudeRotate,
      serverCadRuntime.extrusions.extrudeRectangular,
      serverCadRuntime.extrusions.slice,
      serverCadRuntime.hulls.hull,
      serverCadRuntime.hulls.hullChain,
      serverCadRuntime.expansions.expand,
      serverCadRuntime.expansions.offset,
      serverCadRuntime.colors.colorize,
    ];

    const wrappedScript = `
      const exports = {};
      const module = { exports };
      ${JSCAD_FEATURE_BUILDER_LIB}
      ${cleanCode}
      let executedParts = null;
      if (typeof getParts === 'function') {
        try {
          executedParts = getParts();
        } catch (e) {}
      }
      let mainRes = null;
      if (typeof main === 'function') {
        mainRes = main();
      } else if (typeof exports !== 'undefined' && typeof exports.main === 'function') {
        mainRes = exports.main();
      } else if (typeof module !== 'undefined' && module.exports && typeof module.exports.main === 'function') {
        mainRes = module.exports.main();
      } else {
        throw new Error('main() function not declared or exported');
      }
      return { result: mainRes, parts: executedParts };
    `;

    const fn = new Function(...scopeKeys, wrappedScript);
    const execOut = fn(...scopeValues);
    const result = execOut?.result !== undefined ? execOut.result : execOut;
    const parts = execOut?.parts || null;
    if (!result) {
      return { success: false, error: 'main() returned undefined or null' };
    }

    const measured = measureJscadSolids(result);
    if (!measured || !measured.isNonEmpty) {
      return {
        success: false,
        error: 'main() returned geometry with zero valid polygons (empty or degenerate solid)',
      };
    }

    const partMeasurements = measureIndividualJscadSolids(result);
    if (Array.isArray(result) && result.length > 1) {
      if (partMeasurements.length !== result.length) {
        return { success: false, error: 'One or more returned parts could not be measured.' };
      }
      for (let i = 0; i < partMeasurements.length; i++) {
        const part = partMeasurements[i];
        if (!part.isNonEmpty || part.actualVolumeMm3 <= 0 || part.triangleCount <= 0 || !part.isManifold) {
          return {
            success: false,
            error: `Part ${i + 1} is not independently printable (${!part.isNonEmpty ? 'empty/degenerate' : !part.isManifold ? 'not closed (open surface)' : 'invalid geometry'}).`,
            partMeasurements,
          };
        }
      }
    }

    return {
      success: true,
      measurements: measured,
      partMeasurements,
      polygonCount: measured.polygonCount,
      parts,
      solids: result,
    };
  } catch (e: any) {
    return { success: false, error: e?.message || String(e) };
  }
}

// ---------------------------------------------------------------------------
// JSCAD String Sanitizer and Function Extractor (no silent removal of forbidden code)
// ---------------------------------------------------------------------------
export function extractAndValidateJscad(rawText: string): string | null {
  if (!rawText || typeof rawText !== 'string') return null;

  let code = rawText.trim();
  const fenceMatch = code.match(/```(?:javascript|js|typescript|ts)?\s*([\s\S]*?)```/i);
  if (fenceMatch && fenceMatch[1]) {
    code = fenceMatch[1].trim();
  } else {
    code = code
      .replace(/^```[a-z]*\s*/gim, '')
      .replace(/\s*```$/gim, '')
      .replace(/```javascript/gi, '')
      .replace(/```js/gi, '')
      .replace(/```/g, '')
      .trim();
  }

  code = code
    .replace(/^\s*import\s+.*?from\s+['"](?:@jscad\/modeling|jscad)['"];?/gm, '')
    .replace(/^\s*const\s+.*?=\s*require\(['"](?:@jscad\/modeling|jscad)[^'"]*['"]\);?/gm, '')
    .replace(/\b(?:const|let|var)\s*\{([^}]+)\}\s*=\s*require\(['"](?:@jscad\/modeling|jscad)[^'"]*['"]\);?/g, '')
    .replace(/^\s*(?:const|let|var)\s*\{[^}]+\}\s*=\s*(?:primitives|booleans|transforms|extrusions|hulls|expansions|colors|jscad)(?:\.[a-zA-Z0-9_$]+)?\s*;?/gm, '');

  // Handle variable declarations of 'scale' that shadow the JSCAD scale() transform function
  if (/\b(?:const|let|var)\s+scale\s*=/g.test(code)) {
    code = code.replace(/\b(const|let|var)\s+scale\s*=/g, '$1 scaleFactor =');
    code = code.replace(/(\b)(?<![\.\_])scale\b(?!\s*[\(\[])/g, '$1scaleFactor');
  }

  // Handle common dimension variable collisions like offset or slice
  if (/\b(?:const|let|var)\s+offset\s*=\s*[0-9]/g.test(code)) {
    code = code.replace(/\b(const|let|var)\s+offset\s*=/g, '$1 offsetDistance =');
    code = code.replace(/(\b)(?<![\.\_])offset\b(?!\s*[\(\[])/g, '$1offsetDistance');
  }
  if (/\b(?:const|let|var)\s+slice\s*=\s*[0-9]/g.test(code)) {
    code = code.replace(/\b(const|let|var)\s+slice\s*=/g, '$1 sliceThickness =');
    code = code.replace(/(\b)(?<![\.\_])slice\b(?!\s*[\(\[])/g, '$1sliceThickness');
  }

  code = code
    .replace(/\bexport\s+default\s+function\s+/g, 'function ')
    .replace(/\bexport\s+function\s+/g, 'function ')
    .replace(/\bexport\s+(?:const|let|var)\s+/g, 'const ');

  const hasMain =
    /\bfunction\s+main\s*\(/.test(code) ||
    /\b(?:const|let|var)\s+main\s*=\s*(?:function|\([^)]*\)\s*=>|\w+\s*=>)/.test(code) ||
    /\bmain\s*=\s*(?:function|\([^)]*\)\s*=>|\w+\s*=>)/.test(code) ||
    /\bfunction\s+main\b/.test(code) ||
    /\bexports\.main\s*=/.test(code) ||
    /\bmodule\.exports\s*=\s*\{\s*main/.test(code);

  if (hasMain) {
    return code.trim();
  }

  if (/\b(?:union|subtract|intersect|cube|cuboid|cylinder|sphere|roundedCuboid)\s*\(/.test(code)) {
    if (/^\s*return\s+/m.test(code)) {
      return `function main() {\n${code}\n}`;
    }
  }

  return null;
}
