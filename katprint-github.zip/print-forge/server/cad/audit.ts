import type { PrinterSpec } from '../../src/types';
import type { SemanticFeatureModel } from '../../src/features/featureTypes';
import { analyzePrintability } from '../../src/engine/printabilityAnalysis';
import type { GeometryMeasurements } from './sandbox';

export type AuditFindingSeverity = 'blocking' | 'warning' | 'info';

export type AuditFindingCategory =
  | 'DIMENSIONAL_CONFORMANCE'
  | 'BASE_PLANE'
  | 'BED_FIT'
  | 'FEATURE_PRESENCE'
  | 'CONSTANT_INTEGRITY'
  | 'REFERENCE_CLEARANCE'
  | 'PART_COUNT'
  | 'DEGENERATE_GEOMETRY'
  | 'REGRESSION'
  | 'PRINTABILITY';

export interface AuditFinding {
  id: string;
  severity: AuditFindingSeverity;
  category: AuditFindingCategory;
  message: string;
  expected: string;
  actual: string;
  suggestedFix: string;
}

export interface GeometryAuditResult {
  passed: boolean;
  findings: AuditFinding[];
  score: number; // 0 - 1
}

export interface AuditGeneratedGeometryOptions {
  isRevision?: boolean;
  priorAudit?: GeometryAuditResult;
  priorFeatures?: string[];
}

export function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function auditGeneratedGeometry(
  code: string,
  executionResult: {
    success: boolean;
    measurements?: GeometryMeasurements | null;
    partMeasurements?: GeometryMeasurements[];
    parts?: any[] | null;
    solids?: any;
    error?: string;
  },
  requirements: any,
  featureModel?: SemanticFeatureModel | null,
  printer?: PrinterSpec | null,
  options?: AuditGeneratedGeometryOptions
): GeometryAuditResult {
  const findings: AuditFinding[] = [];
  const measurements = executionResult.measurements;

  if (!executionResult.success || !measurements) {
    findings.push({
      id: 'audit_exec_failure',
      severity: 'blocking',
      category: 'DEGENERATE_GEOMETRY',
      message: `CAD execution failed: ${executionResult.error || 'Empty or invalid geometry'}`,
      expected: 'Runnable @jscad/modeling code returning valid 3D solid geometry',
      actual: executionResult.error || 'Execution failure',
      suggestedFix: 'Fix syntax and CSG operations so code compiles to valid 3D geometry.',
    });
    return { passed: false, findings, score: 0 };
  }

  // 1. DIMENSIONAL CONFORMANCE
  // Compare measured bounding box against requirements.overallDimensions
  const overallDims = requirements?.overallDimensions || requirements?.dimensions;
  if (overallDims && typeof overallDims === 'object') {
    const expectedX = overallDims.width ?? overallDims.x ?? overallDims.diameter ?? overallDims.length;
    const expectedY = overallDims.depth ?? overallDims.y ?? overallDims.diameter ?? overallDims.width;
    const expectedZ = overallDims.height ?? overallDims.z;

    const checkAxis = (axis: 'x' | 'y' | 'z', expected: any, actual: number) => {
      const numExpected = Number(expected);
      if (Number.isFinite(numExpected) && numExpected > 0) {
        // 5% or 2mm, whichever is larger
        const tolerance = Math.max(2.0, numExpected * 0.05);
        const diff = Math.abs(actual - numExpected);
        if (diff > tolerance) {
          findings.push({
            id: `audit_dim_${axis}`,
            severity: 'blocking',
            category: 'DIMENSIONAL_CONFORMANCE',
            message: `Axis ${axis.toUpperCase()} dimension (${actual.toFixed(1)}mm) differs from expected ${numExpected.toFixed(1)}mm by ${diff.toFixed(1)}mm (tolerance: ±${tolerance.toFixed(1)}mm).`,
            expected: `${numExpected.toFixed(1)} mm (±${tolerance.toFixed(1)} mm)`,
            actual: `${actual.toFixed(1)} mm`,
            suggestedFix: `Adjust the ${axis.toUpperCase()} dimensional constants to match expected ${numExpected.toFixed(1)}mm.`,
          });
        }
      }
    };

    if (expectedX !== undefined) checkAxis('x', expectedX, measurements.dimensions.x);
    if (expectedY !== undefined) checkAxis('y', expectedY, measurements.dimensions.y);
    if (expectedZ !== undefined) checkAxis('z', expectedZ, measurements.dimensions.z);
  }

  // 2. BASE PLANE
  // The model's minimum Z must be within 0.05mm of zero
  const minZ = measurements.boundingBox[0][2];
  if (Math.abs(minZ) > 0.05) {
    findings.push({
      id: 'audit_base_plane',
      severity: 'blocking',
      category: 'BASE_PLANE',
      message: `Model base plane minimum Z is ${minZ.toFixed(2)}mm (must be within 0.00mm ±0.05mm for print bed adhesion).`,
      expected: '0.00 mm (Z min)',
      actual: `${minZ.toFixed(2)} mm`,
      suggestedFix: 'translate the assembled solid so its minimum Z sits at 0',
    });
  }

  // 3. BED FIT
  // Measured footprint must fit the selected printer's build volume with 5mm margin on X/Y and full clearance on Z
  const defaultBedVolume = { x: 256, y: 256, z: 256 };
  const bedVol = printer?.buildVolume || defaultBedVolume;
  const printerName = printer?.name || 'Standard 3D Printer';

  const maxAllowedX = bedVol.x - 10; // 5mm margin on both sides
  const maxAllowedY = bedVol.y - 10;
  const maxAllowedZ = bedVol.z;

  if (measurements.dimensions.x > maxAllowedX) {
    findings.push({
      id: 'audit_bed_fit_x',
      severity: 'blocking',
      category: 'BED_FIT',
      message: `Model width (${measurements.dimensions.x.toFixed(1)}mm) exceeds ${printerName} printable bed X limit (${maxAllowedX.toFixed(1)}mm with 5mm margin) by ${(measurements.dimensions.x - maxAllowedX).toFixed(1)}mm.`,
      expected: `<= ${maxAllowedX.toFixed(1)} mm`,
      actual: `${measurements.dimensions.x.toFixed(1)} mm`,
      suggestedFix: `Scale down geometry or orient/split parts to fit inside ${bedVol.x}x${bedVol.y}x${bedVol.z}mm build volume.`,
    });
  }

  if (measurements.dimensions.y > maxAllowedY) {
    findings.push({
      id: 'audit_bed_fit_y',
      severity: 'blocking',
      category: 'BED_FIT',
      message: `Model depth (${measurements.dimensions.y.toFixed(1)}mm) exceeds ${printerName} printable bed Y limit (${maxAllowedY.toFixed(1)}mm with 5mm margin) by ${(measurements.dimensions.y - maxAllowedY).toFixed(1)}mm.`,
      expected: `<= ${maxAllowedY.toFixed(1)} mm`,
      actual: `${measurements.dimensions.y.toFixed(1)} mm`,
      suggestedFix: `Scale down geometry or orient/split parts to fit inside ${bedVol.x}x${bedVol.y}x${bedVol.z}mm build volume.`,
    });
  }

  if (measurements.dimensions.z > maxAllowedZ) {
    findings.push({
      id: 'audit_bed_fit_z',
      severity: 'blocking',
      category: 'BED_FIT',
      message: `Model height (${measurements.dimensions.z.toFixed(1)}mm) exceeds ${printerName} max build height (${maxAllowedZ.toFixed(1)}mm) by ${(measurements.dimensions.z - maxAllowedZ).toFixed(1)}mm.`,
      expected: `<= ${maxAllowedZ.toFixed(1)} mm`,
      actual: `${measurements.dimensions.z.toFixed(1)} mm`,
      suggestedFix: `Reduce height or split model into printable sections to fit within ${bedVol.z}mm build height.`,
    });
  }

  // 4. FEATURE PRESENCE
  // For every feature in the semantic feature model marked critical or important, check wrapper declaration and call in main()
  if (featureModel?.features && Array.isArray(featureModel.features)) {
    for (const feat of featureModel.features) {
      const isCriticalOrImportant =
        feat.criticality === 'critical' ||
        feat.criticality === 'important' ||
        (feat as any).isCritical === true;

      if (!isCriticalOrImportant) continue;

      const sanitizedId = feat.id.replace(/[^a-zA-Z0-9_]/g, '_');
      const wrapperName = `kpFeature_${sanitizedId}`;

      // Check declaration
      const declRegex = new RegExp(`\\bfunction\\s+${escapeRegex(wrapperName)}\\b|\\b(?:const|let|var)\\s+${escapeRegex(wrapperName)}\\s*=`);
      const isDeclared = declRegex.test(code);

      if (!isDeclared) {
        findings.push({
          id: `audit_feat_missing_${sanitizedId}`,
          severity: 'blocking',
          category: 'FEATURE_PRESENCE',
          message: `Required feature "${feat.label || feat.id}" (${wrapperName}) is completely missing from code.`,
          expected: `function ${wrapperName}() {...} declared and assembled in main()`,
          actual: 'Missing feature wrapper',
          suggestedFix: `Implement function ${wrapperName}() adhering to semantic feature model and combine it in main().`,
        });
      } else {
        // Check if called/referenced outside its declaration (e.g. in main() or getParts())
        const occurrences = (code.match(new RegExp(`\\b${escapeRegex(wrapperName)}\\b`, 'g')) || []).length;
        if (occurrences <= 1) {
          findings.push({
            id: `audit_feat_uncalled_${sanitizedId}`,
            severity: 'blocking',
            category: 'FEATURE_PRESENCE',
            message: `Feature wrapper ${wrapperName}() is declared in code but never called or assembled in main(). Silent feature omission defect.`,
            expected: `${wrapperName}() invoked and combined inside main()`,
            actual: 'Wrapper function declared but unreferenced in main()',
            suggestedFix: `Call ${wrapperName}() inside main() and boolean-combine its geometry into the final model.`,
          });
        }
      }
    }
  }

  // 5. CONSTANT INTEGRITY
  // Every parameter in the feature model with a jscadConstantName must exist as a top-level numeric literal const
  if (featureModel?.parameters && Array.isArray(featureModel.parameters)) {
    for (const param of featureModel.parameters) {
      if (param.jscadConstantName && typeof param.jscadConstantName === 'string') {
        const constName = param.jscadConstantName.trim();
        if (constName) {
          const constRegex = new RegExp(`(?:^|\\n)\\s*const\\s+${escapeRegex(constName)}\\s*=\\s*(-?\\d+(?:\\.\\d+)?)\\s*;`, 'm');
          const match = code.match(constRegex);
          if (!match) {
            findings.push({
              id: `audit_const_${constName}`,
              severity: 'blocking',
              category: 'CONSTANT_INTEGRITY',
              message: `Required parametric constant "const ${constName} = ...;" is missing or not a top-level numeric literal const in code.`,
              expected: `const ${constName} = ${param.value !== undefined ? param.value : 'number'};`,
              actual: 'Missing or non-literal top-level const declaration',
              suggestedFix: `Declare top-level "const ${constName} = ${param.value !== undefined ? param.value : 0};" for parametric UI editing.`,
            });
          }
        }
      }
    }
  }

  // 6. REFERENCE CLEARANCE
  // If requirements.referenceObject exists and has dimensions, check clearance
  const refObj = requirements?.referenceObject;
  if (refObj && typeof refObj === 'object' && refObj.dimensions) {
    const refW = Number(refObj.dimensions.width || refObj.dimensions.diameter || 0);
    const refD = Number(refObj.dimensions.depth || refObj.dimensions.diameter || 0);
    const clearance = typeof refObj.clearanceMm === 'number' ? refObj.clearanceMm : 1.5;

    if (refW > 0 || refD > 0) {
      const minRequiredW = refW > 0 ? refW + clearance : 0;
      const minRequiredD = refD > 0 ? refD + clearance : 0;

      if ((refW > 0 && measurements.dimensions.x < refW) || (refD > 0 && measurements.dimensions.y < refD)) {
        findings.push({
          id: 'audit_ref_clearance_blocking',
          severity: 'blocking',
          category: 'REFERENCE_CLEARANCE',
          message: `Model outer dimensions (${measurements.dimensions.x.toFixed(1)}x${measurements.dimensions.y.toFixed(1)}mm) are smaller than reference object "${refObj.name}" (${refW}x${refD}mm). Object cannot physically fit.`,
          expected: `Dimensions >= ${minRequiredW.toFixed(1)}x${minRequiredD.toFixed(1)} mm`,
          actual: `${measurements.dimensions.x.toFixed(1)}x${measurements.dimensions.y.toFixed(1)} mm`,
          suggestedFix: `Enlarge model geometry and cavity so "${refObj.name}" fits with at least ${clearance}mm clearance.`,
        });
      } else if ((refW > 0 && measurements.dimensions.x < minRequiredW) || (refD > 0 && measurements.dimensions.y < minRequiredD)) {
        findings.push({
          id: 'audit_ref_clearance_warning',
          severity: 'warning',
          category: 'REFERENCE_CLEARANCE',
          message: `Clearance around reference object "${refObj.name}" is tight (expected +${clearance}mm clearance).`,
          expected: `Clearance >= ${clearance} mm (Total dimensions >= ${minRequiredW.toFixed(1)}x${minRequiredD.toFixed(1)} mm)`,
          actual: `${measurements.dimensions.x.toFixed(1)}x${measurements.dimensions.y.toFixed(1)} mm`,
          suggestedFix: `Increase internal cavity to provide full ${clearance}mm clearance around "${refObj.name}".`,
        });
      }
    }
  }

  // 7. PART COUNT
  // If the spec calls for N pieces (e.g. expectedParts > 1), getParts() must exist and return N entries with unique IDs
  const expectedParts =
    requirements?.partCount ||
    requirements?.estimatedPartCount ||
    requirements?.designPlan?.partCount;

  if (typeof expectedParts === 'number' && expectedParts > 1) {
    const executedParts = executionResult.parts;
    const hasGetPartsInCode = /\bfunction\s+getParts\b|\bgetParts\s*=\s*/.test(code);

    if (!hasGetPartsInCode || !Array.isArray(executedParts)) {
      findings.push({
        id: 'audit_part_count_missing_getparts',
        severity: 'blocking',
        category: 'PART_COUNT',
        message: `Design requires ${expectedParts} separate printable parts, but getParts() function is missing or did not return an array.`,
        expected: `getParts() returning ${expectedParts} unique parts`,
        actual: 'getParts() missing or invalid',
        suggestedFix: `Implement function getParts() returning array of ${expectedParts} parts with unique id, name, quantity, and geometry.`,
      });
    } else {
      if (executedParts.length !== expectedParts) {
        findings.push({
          id: 'audit_part_count_mismatch',
          severity: 'blocking',
          category: 'PART_COUNT',
          message: `Expected ${expectedParts} separate printable parts, but getParts() returned ${executedParts.length} parts.`,
          expected: `${expectedParts} parts`,
          actual: `${executedParts.length} parts`,
          suggestedFix: `Update getParts() to return exactly ${expectedParts} part objects.`,
        });
      }

      const seenIds = new Set<string>();
      const duplicateIds: string[] = [];
      for (const p of executedParts) {
        if (!p?.id || typeof p.id !== 'string') {
          findings.push({
            id: 'audit_part_invalid_id',
            severity: 'blocking',
            category: 'PART_COUNT',
            message: `Part in getParts() is missing a valid non-empty "id" string.`,
            expected: 'Unique string id for each part',
            actual: String(p?.id),
            suggestedFix: 'Assign a clean string id (e.g. "base", "lid") to every part.',
          });
        } else if (seenIds.has(p.id)) {
          duplicateIds.push(p.id);
        } else {
          seenIds.add(p.id);
        }
      }

      if (duplicateIds.length > 0) {
        findings.push({
          id: 'audit_part_duplicate_ids',
          severity: 'blocking',
          category: 'PART_COUNT',
          message: `Duplicate part IDs in getParts(): ${duplicateIds.join(', ')}.`,
          expected: 'Unique ID per part',
          actual: `Duplicate IDs: ${duplicateIds.join(', ')}`,
          suggestedFix: 'Ensure all parts returned by getParts() have distinct IDs.',
        });
      }
    }
  }

  // 8. DEGENERATE GEOMETRY
  // Zero or near-zero volume (< 0.1mm³), polygon count under 12, or non-manifold edges
  const actualVol = measurements.actualVolumeMm3 ?? measurements.volumeMm3;
  if (actualVol < 0.1 || measurements.polygonCount < 12 || !measurements.isManifold || measurements.nonManifoldEdgeCount > 0) {
    findings.push({
      id: 'audit_degenerate_geometry',
      severity: 'blocking',
      category: 'DEGENERATE_GEOMETRY',
      message: `Model geometry is degenerate or unprintable (Volume: ${actualVol}mm³, Polygons: ${measurements.polygonCount}, Non-manifold edges: ${measurements.nonManifoldEdgeCount}).`,
      expected: 'Manifold watertight solid with volume > 0.1mm³ and >= 12 polygons',
      actual: `Volume: ${actualVol}mm³, Polygons: ${measurements.polygonCount}, Non-manifold edges: ${measurements.nonManifoldEdgeCount}`,
      suggestedFix: 'Fix CSG operations so all solid shapes are closed, watertight manifolds without zero-thickness or inverted geometry.',
    });
  }

  // 9. DETERMINISTIC PRINTABILITY ANALYSIS
  if (executionResult.solids) {
    try {
      const printReport = analyzePrintability(executionResult.solids, {
        nozzleMm: printer?.nozzleDiameter ?? 0.4,
        bedSize: printer?.buildVolume,
        minWallMm: (printer?.nozzleDiameter ?? 0.4) * 2.0,
      });

      // 9a. Unsupported Islands in mid-air
      const blockingIslands = printReport.islands.filter((i) => i.severity === 'blocking');
      if (blockingIslands.length > 0) {
        findings.push({
          id: 'audit_unsupported_islands',
          severity: 'blocking',
          category: 'PRINTABILITY',
          message: `Detected ${blockingIslands.length} unsupported floating island(s) starting in mid-air (lowest at Z=${blockingIslands[0].zHeightMm}mm, area: ${blockingIslands[0].areaMm2}mm²).`,
          expected: 'All solid features connected to base or self-supporting with <= 45° overhangs',
          actual: `${blockingIslands.length} mid-air floating islands`,
          suggestedFix: 'Connect floating features to the main base body or bridge with chamfers/angles <= 45° so layers have underlying support.',
        });
      }

      // 9b. Failing Bridge Spans (> 50mm)
      const failingBridges = printReport.bridges.filter((b) => b.status === 'failing');
      if (failingBridges.length > 0) {
        findings.push({
          id: 'audit_failing_bridge',
          severity: 'blocking',
          category: 'PRINTABILITY',
          message: `Unsupported horizontal bridge span is ${failingBridges[0].spanMm}mm (exceeds 50mm printability limit).`,
          expected: 'Bridge spans <= 25mm (or <= 50mm with active cooling)',
          actual: `${failingBridges[0].spanMm}mm unsupported bridge span`,
          suggestedFix: 'Add support ribs/gussets or chamfer the ceiling to shorten the horizontal span.',
        });
      }

      // 9c. Severe Thin Walls (< 50% minWall)
      if (printReport.thinWalls.hasThinWalls && printReport.thinWalls.minWallThicknessMm < printReport.thinWalls.thresholdMm * 0.5) {
        findings.push({
          id: 'audit_critical_thin_wall',
          severity: 'blocking',
          category: 'PRINTABILITY',
          message: `Critical thin wall detected: ${printReport.thinWalls.minWallThicknessMm}mm is thinner than 50% of minimum printable thickness (${printReport.thinWalls.thresholdMm}mm for ${printer?.nozzleDiameter ?? 0.4}mm nozzle).`,
          expected: `>= ${printReport.thinWalls.thresholdMm}mm wall thickness`,
          actual: `${printReport.thinWalls.minWallThicknessMm}mm`,
          suggestedFix: `Increase wall thickness dimension constants to at least ${printReport.thinWalls.thresholdMm}mm.`,
        });
      } else if (printReport.thinWalls.hasThinWalls) {
        findings.push({
          id: 'audit_warning_thin_wall',
          severity: 'warning',
          category: 'PRINTABILITY',
          message: `Thin wall detected: ${printReport.thinWalls.minWallThicknessMm}mm (recommended >= ${printReport.thinWalls.thresholdMm}mm).`,
          expected: `>= ${printReport.thinWalls.thresholdMm}mm wall thickness`,
          actual: `${printReport.thinWalls.minWallThicknessMm}mm`,
          suggestedFix: `Consider thickening walls to at least ${printReport.thinWalls.thresholdMm}mm for structural durability.`,
        });
      }

      // 9d. First Layer Insufficient Bed Adhesion
      if (printReport.firstLayer.status === 'insufficient') {
        findings.push({
          id: 'audit_insufficient_first_layer',
          severity: 'blocking',
          category: 'BASE_PLANE',
          message: `First layer contact area is only ${printReport.firstLayer.areaMm2}mm² (< 50mm²). The part will detach from the print bed during printing.`,
          expected: 'Flat base with adequate surface contact (>= 100mm²)',
          actual: `${printReport.firstLayer.areaMm2}mm² bed contact area`,
          suggestedFix: 'Position the widest flat face flat against Z=0 or expand the base footprint.',
        });
      }
    } catch (err: any) {
      console.warn('[Audit] Printability analysis exception:', err?.message);
    }
  }

  // REGRESSION CHECK (for revisions)
  if (options?.isRevision && options?.priorFeatures && Array.isArray(options.priorFeatures)) {
    for (const featId of options.priorFeatures) {
      const sanitizedId = featId.replace(/[^a-zA-Z0-9_]/g, '_');
      const wrapperName = `kpFeature_${sanitizedId}`;
      const isPresent = new RegExp(`\\b${escapeRegex(wrapperName)}\\b`).test(code);
      if (!isPresent) {
        findings.push({
          id: `audit_regression_${sanitizedId}`,
          severity: 'blocking',
          category: 'REGRESSION',
          message: `Regression: Feature "${featId}" (${wrapperName}) was present and verified in prior version but is now missing in revision.`,
          expected: `Feature ${wrapperName}() preserved from previous version`,
          actual: 'Feature missing in revision',
          suggestedFix: `Restore kpFeature_${sanitizedId}() and preserve it while applying requested revision changes.`,
        });
      }
    }
  }

  // Score Calculation (0 - 1)
  const blockingFindings = findings.filter((f) => f.severity === 'blocking');
  const warningFindings = findings.filter((f) => f.severity === 'warning');

  let score = 1.0;
  if (blockingFindings.length === 0 && warningFindings.length === 0) {
    score = 1.0;
  } else if (blockingFindings.length === 0) {
    score = Math.max(0.70, Number((1.0 - (warningFindings.length * 0.08)).toFixed(2)));
  } else {
    score = Math.max(0.0, Number((0.65 - (blockingFindings.length * 0.20) - (warningFindings.length * 0.05)).toFixed(2)));
  }

  const passed = blockingFindings.length === 0;

  return {
    passed,
    findings,
    score,
  };
}



export interface MeasuredFeedbackFlag {
  type: 'dimension' | 'part_count' | 'hollowness' | 'clearance';
  message: string;
  expected: string;
  actual: string;
}

export function auditPromptPhysicalMeasurements(
  prompt: string,
  measurements: GeometryMeasurements,
  executionResult: any,
  code: string,
  requirements?: any
): MeasuredFeedbackFlag[] {
  const flags: MeasuredFeedbackFlag[] = [];
  const dimX = measurements?.dimensions?.x || 0;
  const dimY = measurements?.dimensions?.y || 0;
  const dimZ = measurements?.dimensions?.z || 0;

  const parseNumWithUnit = (valStr: string, unitStr?: string): number => {
    const v = parseFloat(valStr);
    if (isNaN(v)) return 0;
    if (unitStr) {
      const u = unitStr.toLowerCase();
      if (u.startsWith('in') || u === '"') return v * 25.4;
      if (u === 'cm') return v * 10.0;
    }
    return v;
  };

  // 1. Dimensions Envelope check (e.g. "80 by 60 by 40", "80x60x40mm", "100mm x 50mm x 20mm")
  const multiDimRegex = /(\d+(?:\.\d+)?)\s*(mm|cm|in|inch|inches|")?\s*(?:x|by|\*)\s*(\d+(?:\.\d+)?)\s*(mm|cm|in|inch|inches|")?\s*(?:x|by|\*)\s*(\d+(?:\.\d+)?)\s*(mm|cm|in|inch|inches|")?/i;
  const multiMatch = prompt.match(multiDimRegex);
  if (multiMatch) {
    const trailingUnit = multiMatch[6] || multiMatch[4] || multiMatch[2];
    const d1 = parseNumWithUnit(multiMatch[1], multiMatch[2] || trailingUnit);
    const d2 = parseNumWithUnit(multiMatch[3], multiMatch[4] || trailingUnit);
    const d3 = parseNumWithUnit(multiMatch[5], multiMatch[6] || trailingUnit);

    const targetSorted = [d1, d2, d3].sort((a, b) => b - a);
    const measuredSorted = [dimX, dimY, dimZ].sort((a, b) => b - a);

    for (let i = 0; i < 3; i++) {
      const target = targetSorted[i];
      const measured = measuredSorted[i];
      const tolerance = Math.max(1.0, target * 0.02);
      if (Math.abs(measured - target) > tolerance) {
        flags.push({
          type: 'dimension',
          message: `Dimension mismatch: Target envelope [${d1}, ${d2}, ${d3}]mm, but measured bounding box is [${dimX.toFixed(1)}, ${dimY.toFixed(1)}, ${dimZ.toFixed(1)}]mm (delta ${(measured - target).toFixed(1)}mm on target ${target.toFixed(1)}mm).`,
          expected: `Envelope [${d1}, ${d2}, ${d3}] mm`,
          actual: `Measured [${dimX.toFixed(1)}, ${dimY.toFixed(1)}, ${dimZ.toFixed(1)}] mm`,
        });
        break;
      }
    }
  }

  // Target Height check (e.g. "150mm tall", "height of 40mm")
  const heightRegex = /(\d+(?:\.\d+)?)\s*(mm|cm|in|inch|inches|")?\s*(?:tall|height|high)\b|(?:height|tall|high)(?:\s*(?:of|is|:|=|at))?\s*(\d+(?:\.\d+)?)\s*(mm|cm|in|inch|inches|")?/i;
  const heightMatch = prompt.match(heightRegex);
  if (heightMatch && !multiMatch) {
    const valStr = heightMatch[1] || heightMatch[3];
    const unitStr = heightMatch[2] || heightMatch[4];
    const targetHeight = parseNumWithUnit(valStr, unitStr);
    if (targetHeight > 0) {
      const tolerance = Math.max(1.0, targetHeight * 0.02);
      if (Math.abs(dimZ - targetHeight) > tolerance) {
        flags.push({
          type: 'dimension',
          message: `Height mismatch: Target height is ${targetHeight.toFixed(1)}mm, but measured height is ${dimZ.toFixed(1)}mm (delta ${(dimZ - targetHeight).toFixed(1)}mm).`,
          expected: `Height ${targetHeight.toFixed(1)} mm (±${tolerance.toFixed(1)}mm)`,
          actual: `Measured height ${dimZ.toFixed(1)} mm`,
        });
      }
    }
  }

  // Target Diameter check (e.g. "120mm in diameter", "diameter of 80mm")
  const diameterRegex = /(\d+(?:\.\d+)?)\s*(mm|cm|in|inch|inches|")?\s*(?:in\s+)?diameter\b|diameter(?:\s*(?:of|is|:|=|at))?\s*(\d+(?:\.\d+)?)\s*(mm|cm|in|inch|inches|")?/i;
  const diameterMatch = prompt.match(diameterRegex);
  if (diameterMatch && !multiMatch) {
    const valStr = diameterMatch[1] || diameterMatch[3];
    const unitStr = diameterMatch[2] || diameterMatch[4];
    const targetDiameter = parseNumWithUnit(valStr, unitStr);
    if (targetDiameter > 0) {
      const maxHorizontal = Math.max(dimX, dimY);
      const tolerance = Math.max(1.0, targetDiameter * 0.02);
      if (Math.abs(maxHorizontal - targetDiameter) > tolerance) {
        flags.push({
          type: 'dimension',
          message: `Diameter mismatch: Target diameter is ${targetDiameter.toFixed(1)}mm, but measured outer diameter is ${maxHorizontal.toFixed(1)}mm (delta ${(maxHorizontal - targetDiameter).toFixed(1)}mm).`,
          expected: `Diameter ${targetDiameter.toFixed(1)} mm (±${tolerance.toFixed(1)}mm)`,
          actual: `Measured diameter ${maxHorizontal.toFixed(1)} mm`,
        });
      }
    }
  }

  // 2. Multi-Part Check
  const multiPartPromptRegex = /\b(box\s+with\s+(?:a\s+)?lid|box\s+and\s+lid|with\s+(?:a\s+)?(?:lid|cover|cap)|two[ -]piece|2[ -]piece|multi[ -]part|multi[ -]piece|assembly)\b/i;
  if (multiPartPromptRegex.test(prompt)) {
    const hasGetParts = /\bfunction\s+getParts\b|\bgetParts\s*=\s*/.test(code);
    const partCount = executionResult?.parts ? executionResult.parts.length : 1;
    if (!hasGetParts || partCount < 2) {
      flags.push({
        type: 'part_count',
        message: `Multi-part architecture defect: The prompt describes a multi-piece design, but the generated code returned a single solid without getParts() and kpPart_*() multi-part ABI.`,
        expected: `getParts() returning at least 2 distinct printable pieces (e.g. base and lid)`,
        actual: `Single solid returned (part count = ${partCount})`,
      });
    }
  }

  // 3. Hollowness Check
  const containerPromptRegex = /\b(planter|pot|cup|bowl|vase|box|bin|tray|dish|enclosure|container|holder|reservoir|basin|hollow)\b/i;
  if (containerPromptRegex.test(prompt)) {
    const bboxVolume = dimX * dimY * dimZ;
    const actualVolume = measurements?.actualVolumeMm3 ?? measurements?.volumeMm3 ?? 0;
    if (bboxVolume > 100 && actualVolume > 0) {
      const volumeRatio = actualVolume / bboxVolume;
      if (volumeRatio > 0.70) {
        flags.push({
          type: 'hollowness',
          message: `Hollowness defect: The object is a container/planter/box, but measured solid volume is ${(volumeRatio * 100).toFixed(1)}% of bounding box (expected < 70%). The model appears solid; subtract inner cavity/reservoir.`,
          expected: `Hollow interior with solid volume < 70% of bounding box`,
          actual: `Solid volume is ${(volumeRatio * 100).toFixed(1)}% of bounding box`,
        });
      }
    }
  }

  // 4. Mating Clearance Check (Verify clearance const against calibrated printer value)
  const targetClearance = requirements?.matingClearanceMm;
  if (typeof targetClearance === 'number') {
    const clearanceConstRegex = /\bconst\s+([a-zA-Z0-9_]*(?:clearance|Clearance)[a-zA-Z0-9_]*)\s*=\s*([0-9]+(?:\.[0-9]+)?)\s*;/gi;
    let match: RegExpExecArray | null;
    while ((match = clearanceConstRegex.exec(code)) !== null) {
      const constName = match[1];
      const declaredVal = parseFloat(match[2]);
      if (!isNaN(declaredVal) && Math.abs(declaredVal - targetClearance) > 0.05) {
        flags.push({
          type: 'clearance',
          message: `Clearance const is ${declaredVal.toFixed(2)}mm; this printer measured ${targetClearance.toFixed(2)}mm.`,
          expected: `Clearance ${targetClearance.toFixed(2)}mm (matching printer calibration)`,
          actual: `${constName} = ${declaredVal.toFixed(2)}mm`,
        });
      }
    }
  }

  return flags;
}

