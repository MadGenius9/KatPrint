// ---------------------------------------------------------------------------
// Offline / Explicit Template Generator (Only when explicitly invoked)
// ---------------------------------------------------------------------------

export function synthesizeOfflineJscad(prompt: string): string {
  const p = prompt.toLowerCase();
  const numbers = prompt.match(/\d+(\.\d+)?/g)?.map(Number) || [];
  const primaryDim = numbers[0] || 120;
  const secondaryDim = numbers[1] || 80;
  const tertiaryDim = numbers[2] || 35;

  if (p.includes('planter') || p.includes('pot') || p.includes('plant')) {
    return `// Parametric Planter & Reservoir (Template)
// Key dimensions in millimeters (live editable)
const totalHeight = ${primaryDim >= 20 ? primaryDim : 130}.0;
const outerDiameter = ${secondaryDim >= 20 ? secondaryDim : 110}.0;
const wallThickness = 3.2;
const reservoirHeight = ${tertiaryDim >= 10 ? tertiaryDim : 30}.0;
const innerPotDiameter = outerDiameter - 18.0;
const drainageHoleDiameter = 6.0;

function main() {
  const outerRadius = outerDiameter / 2;
  const innerRadius = outerRadius - wallThickness;
  const potInnerRadius = innerPotDiameter / 2;
  
  const outerPot = cylinder({ radius: outerRadius, height: totalHeight, segments: 48 });
  const outerHollow = cylinder({ radius: innerRadius, height: totalHeight, segments: 48 });
  const outerShell = subtract(outerPot, translate([0, 0, wallThickness * 2], outerHollow));

  const basketHeight = totalHeight - reservoirHeight;
  const innerBasket = cylinder({ radius: potInnerRadius, height: basketHeight, segments: 48 });
  const innerCavity = cylinder({ radius: potInnerRadius - wallThickness, height: basketHeight + 10, segments: 48 });
  const basketShell = subtract(innerBasket, translate([0, 0, wallThickness * 1.5], innerCavity));

  const drainage = cylinder({ radius: drainageHoleDiameter / 2, height: wallThickness * 4, segments: 16 });
  const basketWithHoles = subtract(basketShell, translate([0, 0, -2], drainage));

  const assembly = union(outerShell, translate([0, 0, reservoirHeight], basketWithHoles));
  return translate([0, 0, totalHeight / 2], assembly);
}`;
  }

  if (p.includes('bracket') || p.includes('mount') || p.includes('brace')) {
    return `// Parametric Reinforced Angle Bracket (Template)
// Key dimensions in millimeters (live editable)
const legLengthA = ${primaryDim >= 20 ? primaryDim : 60}.0;
const legLengthB = ${secondaryDim >= 20 ? secondaryDim : 60}.0;
const bracketWidth = ${tertiaryDim >= 10 ? tertiaryDim : 35}.0;
const plateThickness = 5.0;
const gussetThickness = 4.0;
const holeDiameter = 5.2;

function main() {
  const legA = cuboid({ size: [legLengthA, bracketWidth, plateThickness] });
  const legB = cuboid({ size: [plateThickness, bracketWidth, legLengthB] });
  const gussetSize = Math.min(legLengthA, legLengthB) - plateThickness - 5;
  const gusset = cuboid({ size: [gussetSize, gussetThickness, gussetSize] });

  const baseStructure = union(
    translate([legLengthA / 2, 0, plateThickness / 2], legA),
    translate([plateThickness / 2, 0, legLengthB / 2], legB),
    translate([gussetSize / 2 + plateThickness, 0, gussetSize / 2 + plateThickness], gusset)
  );

  const hole = cylinder({ radius: holeDiameter / 2, height: plateThickness * 3, segments: 24 });
  return subtract(
    baseStructure,
    translate([legLengthA * 0.7, 0, 0], hole),
    translate([0, 0, legLengthB * 0.7], rotateY(Math.PI / 2, hole))
  );
}`;
  }

  return `// Parametric Electronics Enclosure Box (Template)
// Key dimensions in millimeters (live editable)
const boxLength = ${primaryDim >= 20 ? primaryDim : 100}.0;
const boxWidth = ${secondaryDim >= 20 ? secondaryDim : 60}.0;
const boxHeight = ${tertiaryDim >= 10 ? tertiaryDim : 25}.0;
const wallThickness = 3.0;
const cornerRadius = 3.0;
const mountingHoleDiameter = 4.0;
const cornerInset = 8.0;

function main() {
  const outerBox = roundedCuboid({
    size: [boxLength, boxWidth, boxHeight],
    roundRadius: cornerRadius,
    segments: 24
  });

  const innerCavity = roundedCuboid({
    size: [boxLength - (wallThickness * 2), boxWidth - (wallThickness * 2), boxHeight + 5],
    roundRadius: Math.max(1, cornerRadius - 1),
    segments: 24
  });

  const hollow = subtract(outerBox, translate([0, 0, wallThickness], innerCavity));
  const hole = cylinder({ radius: mountingHoleDiameter / 2, height: wallThickness * 4, segments: 24 });

  const hX = (boxLength / 2) - cornerInset;
  const hY = (boxWidth / 2) - cornerInset;

  const withHoles = subtract(
    hollow,
    translate([hX, hY, 0], hole),
    translate([-hX, hY, 0], hole),
    translate([hX, -hY, 0], hole),
    translate([-hX, -hY, 0], hole)
  );

  return translate([0, 0, boxHeight / 2], withHoles);
}`;
}
