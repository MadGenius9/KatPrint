import type { ProjectReferenceImage, PrinterSpec, FilamentSpec } from "../../src/types";
export { getFeatureBuilderPromptDocs } from "../../src/features/featureGenerators";

// ---------------------------------------------------------------------------
// Reference Image Processing & Multi-Modal Content Ingestion
// ---------------------------------------------------------------------------
const ALLOWED_REFERENCE_IMAGE_MIME = new Set(['image/jpeg', 'image/png', 'image/webp']);

export function parseReferenceImageDataUrl(image: Pick<ProjectReferenceImage, 'dataUrl' | 'mimeType'>): { mimeType: string; base64: string } | null {
  if (!image?.dataUrl || typeof image.dataUrl !== 'string') return null;
  const match = image.dataUrl.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=\r\n]+)$/i);
  if (!match) return null;
  const mimeType = match[1].toLowerCase();
  if (!ALLOWED_REFERENCE_IMAGE_MIME.has(mimeType)) return null;
  return { mimeType, base64: match[2].replace(/\s+/g, '') };
}

export function appendReferenceImagesToContents(contents: any[], referenceImages: ProjectReferenceImage[] = []): any[] {
  referenceImages.slice(0, 6).forEach((image, index) => {
    const parsed = parseReferenceImageDataUrl(image);
    if (!parsed) return;
    contents.push({
      text: `REFERENCE IMAGE ${index + 1}\nRole: ${image.role || 'unknown'}\nNotes: ${image.notes || 'None'}\nFilename: ${image.fileName || image.filename || 'Reference photo'}`,
    });
    contents.push({ inlineData: { mimeType: parsed.mimeType, data: parsed.base64 } });
  });
  return contents;
}


// ---------------------------------------------------------------------------
// Step 1: Requirements Extraction Pass
// ---------------------------------------------------------------------------
const SERVER_KNOWN_REFERENCE_OBJECTS = [
  {
    name: 'Dr. Squatch Soap Bar',
    aliases: [
      'dr squatch',
      'squatch bar',
      'dr. squatch',
      'squatch soap',
      'dr.squatch',
      'dr squatch soap',
      'dr squatch bar',
      'dr. squatch bar',
      'dr. squatch soap',
      'squatch',
    ],
    dimensions: { width: 76.2, depth: 76.2, height: 25.4 },
    confidence: 'verified' as const,
    clearanceMm: 2.0,
    sourceNote: 'Standard 3" × 3" × 1" cold-process soap bar',
  },
  {
    name: 'Standard Bar Soap (Dove / Dial)',
    aliases: ['soap bar', 'bar soap', 'bath soap', 'dove bar', 'standard soap', 'hand soap bar'],
    dimensions: { width: 88.0, depth: 56.0, height: 26.0 },
    confidence: 'verified' as const,
    clearanceMm: 3.0,
    sourceNote: 'Standard rectangular rounded bar soap',
  },
  {
    name: 'Apple iPhone 17 / 16 / 15 Pro Max',
    aliases: [
      'iphone 17 pro max',
      'iphone 17',
      'iphone 16 pro max',
      'iphone 16',
      'iphone 15 pro max',
      'iphone max',
      'pro max',
      'iphone 17 pro',
      'iphone 16 pro',
    ],
    dimensions: { width: 77.6, depth: 8.25, height: 163.0 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: '6.7-inch to 6.9-inch flagship smartphone body',
  },
  {
    name: 'Apple iPhone Standard (15 / 14 / 13)',
    aliases: ['iphone 15', 'iphone 14', 'iphone 13', 'iphone', 'standard iphone', 'iphone 12', 'smartphone', 'phone'],
    dimensions: { width: 71.6, depth: 7.8, height: 147.6 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: '6.1-inch standard smartphone body',
  },
  {
    name: 'Apple AirPods / AirPods Pro Case',
    aliases: ['airpods', 'airpods pro', 'airpod case', 'earbuds case', 'airpods case'],
    dimensions: { width: 60.6, depth: 21.7, height: 45.2 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Apple wireless earbuds charging case',
  },
  {
    name: 'Xbox Wireless Controller',
    aliases: [
      'xbox controller',
      'xbox series x controller',
      'xbox one controller',
      'xbox wireless controller',
      'xbox gamepad',
      'xbox',
      'game controller',
      'controllers',
    ],
    dimensions: { width: 155.0, depth: 108.0, height: 63.0 },
    confidence: 'verified' as const,
    clearanceMm: 3.0,
    sourceNote: 'Xbox Series X/S standard gamepad',
  },
  {
    name: 'PlayStation 5 DualSense Controller',
    aliases: ['ps5 controller', 'dualsense', 'playstation 5 controller', 'ps5 gamepad', 'dualsense controller', 'ps5'],
    dimensions: { width: 160.0, depth: 106.0, height: 66.0 },
    confidence: 'verified' as const,
    clearanceMm: 3.0,
    sourceNote: 'Sony PlayStation 5 DualSense controller',
  },
  {
    name: 'Stanley Quencher 40 oz Tumbler',
    aliases: [
      'stanley tumbler',
      'stanley cup',
      'stanley 40 oz',
      'stanley 40oz',
      '40 oz stanley',
      '40oz stanley',
      'stanley quencher',
      'stanley',
      'tumbler',
    ],
    dimensions: { width: 100.0, depth: 100.0, height: 260.0, diameter: 78.0 },
    confidence: 'verified' as const,
    clearanceMm: 2.5,
    sourceNote: '40 oz insulated tumbler with 78mm base diameter',
  },
  {
    name: 'Milwaukee M18 RedLithium Battery',
    aliases: [
      'milwaukee m18',
      'm18 battery',
      'milwaukee battery',
      'milwaukee m18 battery',
      'm18 redlithium',
      'm18',
    ],
    dimensions: { width: 78.0, depth: 120.0, height: 68.0 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Milwaukee M18 tool slide battery pack',
  },
  {
    name: 'DeWalt 20V MAX Battery',
    aliases: ['dewalt battery', 'dewalt 20v', 'dewalt 20v max', 'dewalt'],
    dimensions: { width: 75.0, depth: 115.0, height: 65.0 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'DeWalt 20V slide tool battery pack',
  },
  {
    name: 'Makita 18V LXT Battery',
    aliases: ['makita battery', 'makita 18v', 'makita lxt', 'makita'],
    dimensions: { width: 72.0, depth: 114.0, height: 62.0 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Makita 18V LXT slide battery pack',
  },
  {
    name: 'Yeti Rambler Tumbler / Bottle',
    aliases: [
      'yeti bottle',
      'yeti tumbler',
      'yeti rambler',
      'yeti cup',
      'yeti 26 oz',
      'yeti 36 oz',
      'yeti',
    ],
    dimensions: { width: 86.0, depth: 86.0, height: 240.0, diameter: 86.0 },
    confidence: 'verified' as const,
    clearanceMm: 2.0,
    sourceNote: 'Yeti insulated drinkware (86mm base diameter)',
  },
  {
    name: 'Standard 12 oz Aluminum Soda Can',
    aliases: ['soda can', '12 oz can', 'beer can', 'aluminum can', 'can holder'],
    dimensions: { width: 66.0, depth: 66.0, height: 122.0, diameter: 66.0 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Standard 12 fl oz beverage can (Ø66.0 mm)',
  },
  {
    name: 'Slim 12 oz Beverage Can',
    aliases: ['slim can', 'skinny can', 'white claw can', 'red bull can', 'slim 12 oz'],
    dimensions: { width: 58.0, depth: 58.0, height: 155.0, diameter: 58.0 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Slim 12 fl oz beverage can (Ø58.0 mm)',
  },
  {
    name: 'Standard Coffee Mug',
    aliases: ['coffee mug', 'mug', 'tea cup', 'coffee cup'],
    dimensions: { width: 84.0, depth: 120.0, height: 95.0, diameter: 84.0 },
    confidence: 'verified' as const,
    clearanceMm: 2.5,
    sourceNote: 'Standard ceramic mug with 35mm handle clearance',
  },
  {
    name: 'Standard Pencils & Pens',
    aliases: ['pencil', 'pencils', 'pen', 'pens', 'marker', 'markers'],
    dimensions: { width: 8.5, depth: 8.5, height: 175.0, diameter: 8.5 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Standard hex or round writing instruments (Ø8.5 - 10.0 mm)',
  },
  {
    name: 'Credit Card / ID Badge',
    aliases: ['credit card', 'credit cards', 'business card', 'id card', 'wallet card'],
    dimensions: { width: 85.6, depth: 53.98, height: 0.8 },
    confidence: 'verified' as const,
    clearanceMm: 1.2,
    sourceNote: 'ISO/IEC 7810 ID-1 standard card format',
  },
  {
    name: 'USB-C Cable & Connector',
    aliases: ['usb-c', 'usb c', 'usbc', 'charging cable', 'type c', 'usb cable'],
    dimensions: { width: 12.5, depth: 6.5, height: 25.0, diameter: 4.5 },
    confidence: 'verified' as const,
    clearanceMm: 1.0,
    sourceNote: 'Standard USB-C molded connector head and 4.5mm cable relief',
  },
  {
    name: 'Standard Toothbrush',
    aliases: ['toothbrush', 'tooth brush', 'electric toothbrush', 'oral-b'],
    dimensions: { width: 16.0, depth: 16.0, height: 190.0, diameter: 16.0 },
    confidence: 'verified' as const,
    clearanceMm: 2.0,
    sourceNote: 'Standard manual/electric toothbrush handle',
  },
  {
    name: 'Nintendo Switch Game Cartridge',
    aliases: ['switch cartridge', 'switch game', 'nintendo switch game', 'switch card'],
    dimensions: { width: 31.0, depth: 3.0, height: 21.0 },
    confidence: 'verified' as const,
    clearanceMm: 0.8,
    sourceNote: 'Official Nintendo Switch media cartridge',
  },
  {
    name: 'GoPro Hero Action Camera',
    aliases: ['gopro camera', 'gopro hero', 'gopro mount', 'gopro 11', 'gopro 12', 'gopro 10', 'gopro'],
    dimensions: { width: 71.8, depth: 33.6, height: 50.8 },
    confidence: 'verified' as const,
    clearanceMm: 1.5,
    sourceNote: 'Standard GoPro Hero action camera body',
  },
  {
    name: '2-Inch Schedule 40 PVC Pipe',
    aliases: ['2 inch pvc', '2" pvc', '2in pvc', '2-inch pipe', '2" pipe', '2 inch pipe'],
    dimensions: { width: 60.3, depth: 60.3, height: 100.0, diameter: 60.3 },
    confidence: 'verified' as const,
    clearanceMm: 1.0,
    sourceNote: 'Standard 2" Sch 40 PVC (Outer Diameter: 60.3 mm)',
  },
  {
    name: '18650 Li-ion Battery Cell',
    aliases: ['18650', '18650 battery', '18650 cell', 'vape battery'],
    dimensions: { width: 18.4, depth: 18.4, height: 65.0, diameter: 18.4 },
    confidence: 'verified' as const,
    clearanceMm: 0.6,
    sourceNote: 'Standard 18.4mm × 65.0mm cylindrical rechargeable cell',
  },
  {
    name: 'AA Battery',
    aliases: ['aa battery', 'double a battery', 'aa batteries', 'aa cell'],
    dimensions: { width: 14.5, depth: 14.5, height: 50.5, diameter: 14.5 },
    confidence: 'verified' as const,
    clearanceMm: 0.5,
    sourceNote: 'Standard 14.5mm × 50.5mm cylindrical cell',
  },
  {
    name: 'AAA Battery',
    aliases: ['aaa battery', 'triple a battery', 'aaa batteries', 'aaa cell'],
    dimensions: { width: 10.5, depth: 10.5, height: 44.5, diameter: 10.5 },
    confidence: 'verified' as const,
    clearanceMm: 0.5,
    sourceNote: 'Standard 10.5mm × 44.5mm cylindrical cell',
  },
];

export function matchKnownReference(prompt: string) {
  const p = prompt.toLowerCase();
  for (const obj of SERVER_KNOWN_REFERENCE_OBJECTS) {
    if (obj.aliases.some((alias) => p.includes(alias))) {
      return {
        name: obj.name,
        dimensions: { ...obj.dimensions },
        confidence: obj.confidence,
        clearanceMm: obj.clearanceMm,
        sourceNote: obj.sourceNote,
      };
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// Intent-Based Prompt Classifier & Sanitizer
// ---------------------------------------------------------------------------
export function classifyPromptIntent(
  prompt: string,
  parsedObj?: any
): {
  classification: 'parametric' | 'organic' | 'hybrid';
  confidence: number;
  primaryObject: string;
  referenceObject: string | null;
  functionalRequirements: string[];
  decorativeRequirements: string[];
  sculpturalRequirements: string[];
  reason: string;
} {
  const p = prompt.toLowerCase();

  // 1. Identify primary manufactured functional object
  const functionalKeywords = [
    'soap dish',
    'soapdish',
    'dish',
    'tray',
    'holder',
    'stand',
    'mount',
    'bracket',
    'organizer',
    'enclosure',
    'box',
    'adapter',
    'spacer',
    'clamp',
    'shelf',
    'hook',
    'cup holder',
    'cupholder',
    'phone stand',
    'battery holder',
    'controller holder',
    'tool holder',
    'wall mount',
    'container',
    'drawer organizer',
    'cable guide',
    'pipe fitting',
    'fitting',
    'cover',
    'lid',
    'rack',
    'gear knob',
    'shift knob',
    'knob',
    'gear',
    'case',
    'bin',
    'jig',
    'fixture',
    'caddy',
    'dock',
    'coaster',
    'riser',
    'funnel',
    'clip',
    'handle',
    'spool',
    'wheel',
    'hinge',
    'latch',
    'catch',
    'washer',
    'bushing',
    'flange',
    'plug',
    'cap',
    'plate',
  ];

  let primaryObject = parsedObj?.primaryObject || '';
  if (!primaryObject) {
    for (const kw of functionalKeywords) {
      if (p.includes(kw)) {
        primaryObject = kw;
        break;
      }
    }
    if (!primaryObject) {
      if (/(?:figurine|statue|sculpture|bust|miniature)/i.test(p)) {
        primaryObject = 'sculpture / figurine';
      } else {
        primaryObject = prompt.slice(0, 30);
      }
    }
  }

  // 2. Identify reference object
  const knownRef = matchKnownReference(prompt);
  let referenceName = knownRef ? knownRef.name : null;
  if (!referenceName) {
    const forMatch = prompt.match(/(?:for|fitted for|fits?|holds?|holding|made for)\s+(?:a\s+|an\s+|the\s+)?([A-Za-z0-9\s\.\-]+?)(?:with|having|that|and|$|\.)/i);
    if (forMatch && forMatch[1]) {
      referenceName = forMatch[1].trim();
    }
  }

  // 3. Functional requirements extraction
  const functionalRequirements: string[] = [];
  if (/soap/i.test(p)) functionalRequirements.push('Hold soap bar securely');
  if (/drain|drainage|slot|hole/i.test(p)) functionalRequirements.push('Drainage slots/holes');
  if (/rib|airflow|raised/i.test(p)) functionalRequirements.push('Raised airflow drying ribs');
  if (/wall|mount|screw/i.test(p)) functionalRequirements.push('Wall mounting support');
  if (/cable|wire|pass/i.test(p)) functionalRequirements.push('Cable pass-through');
  if (/m\d|thread|insert|clamp/i.test(p)) functionalRequirements.push('Precision mechanical interface/thread');
  if (functionalRequirements.length === 0) functionalRequirements.push('Functional mechanical utility');

  // 4. Decorative requirements extraction
  const decorativeRequirements: string[] = [];
  if (/recess|emboss|text|name|word|font|dr\.?\s*squatch/i.test(p)) {
    decorativeRequirements.push('Recessed or embossed text/logo feature');
  }
  if (/footprint|silhouette|icon|pattern|hex|hexagon|ribs|curved|round/i.test(p)) {
    decorativeRequirements.push('Geometric or decorative surface styling');
  }
  if (decorativeRequirements.length === 0) decorativeRequirements.push('none');

  // 5. Sculptural requirements test
  // True sculptural request requires the body itself to be a realistic anatomical/organic sculpt
  const hasRealisticSculptBody =
    /(?:realistic|detailed|anatomical)\s+(?:dragon|sasquatch|skull|bust|statue|figurine|dog|animal|monster|hand|head|creature|face|body)/i.test(
      p
    ) ||
    /shaped\s+like\s+(?:a\s+)?(?:realistic|detailed)\s+(?:dragon|sasquatch|skull|hand|animal|monster)/i.test(
      p
    ) ||
    /(?:statue\s+of|sculpture\s+of|bust\s+of|figurine\s+of)\s+(?:a\s+)?(?:sasquatch|dragon|dog|animal|skull|monster|character|head|person)/i.test(
      p
    ) ||
    /make\s+a\s+(?:realistic\s+)?(?:dragon\s+figurine|sasquatch\s+figurine|dog\s+figurine|skull|statue\s+of|monster\s+miniature)/i.test(
      p
    );

  const isPureStatueOrFigurine =
    /(?:realistic\s+)?(?:dragon\s+figurine|sasquatch\s+figurine|dog\s+figurine|human\s+head\s+sculpture|anatomical\s+skull|monster\s+miniature|realistic\s+skull\b|statue\s+of\s+a\s+sasquatch)/i.test(
      p
    ) && !/(?:gear\s+knob|knob|dish|holder|mount|bracket|clamp|box|stand)/i.test(p);

  const hasPrecisionMechanicalInterface =
    /(?:m[3-8]|m12|thread|insert|mounting\s+hole|clamp\s+for|pipe\s+clamp|screw\s+hole|bolt\s+circle|flange)/i.test(
      p
    ) ||
    /(?:holding|holds)\s+(?:the\s+)?(?:soap|controller|battery|bottle|cup)/i.test(p);

  // Intent classification decision:
  // Condition 1: Pure sculpture / figurine -> ORGANIC
  if (isPureStatueOrFigurine) {
    return {
      classification: 'organic',
      confidence: 0.96,
      primaryObject: primaryObject || 'sculpture figurine',
      referenceObject: referenceName,
      functionalRequirements: ['Display / Aesthetic model'],
      decorativeRequirements,
      sculpturalRequirements: ['Freeform organic anatomical geometry'],
      reason: 'Primary requested object is a freeform sculpture/figurine with no precision mechanical assembly.',
    };
  }

  // Condition 2: Explicitly requires substantial realistic sculpture AND precision mechanical mounting -> HYBRID
  if (
    hasRealisticSculptBody &&
    hasPrecisionMechanicalInterface &&
    (p.includes('hand') ||
      p.includes('shaped like') ||
      p.includes('dragon-shaped') ||
      p.includes('skull-shaped') ||
      p.includes('eagle sculpture that mounts'))
  ) {
    return {
      classification: 'hybrid',
      confidence: 0.92,
      primaryObject: primaryObject || 'hybrid object',
      referenceObject: referenceName,
      functionalRequirements,
      decorativeRequirements,
      sculpturalRequirements: ['Substantial freeform anatomical sculpture feature'],
      reason: 'Model combines substantial freeform sculpture geometry with precision mechanical mounting/fit requirements.',
    };
  }

  // Condition 3: Default is PARAMETRIC for functional manufactured objects
  return {
    classification: 'parametric',
    confidence: 0.98,
    primaryObject: primaryObject || 'functional part',
    referenceObject: referenceName,
    functionalRequirements,
    decorativeRequirements,
    sculpturalRequirements: ['none'],
    reason: 'Functional manufactured part designed for fit and utility. No freeform sculpture required.',
  };
}

// ---------------------------------------------------------------------------
// Pure Text-Only Requirements Resolution (Deterministic, Non-AI)
//
// Expected test cases:
//   "A self-watering planter 150mm tall and 120mm in diameter"
//     -> height 150, diameter 120, width 120, depth 120, mustHoldLiquid true
//   "A hex pen cup 4 inches tall and 3 inches in diameter"
//     -> height 101.6, diameter 76.2
//   "A small box with a lid, 80 by 60 by 40"
//     -> length 80, width 60, height 40, isMultiPart true
//   "A storage crate 400mm long, 300mm wide and 200mm tall"
//     -> length 400, width 300, height 200, primaryObject "storage crate"
// ---------------------------------------------------------------------------
export function buildTextOnlyRequirements(
  prompt: string,
  printer?: PrinterSpec | null,
  filament?: FilamentSpec | null
): any {
  const p = prompt.toLowerCase();
  const intent = classifyPromptIntent(prompt);
  const knownRef = matchKnownReference(prompt);

  // 1. PRIMARY OBJECT — stop the noun-phrase match at the first digit.
  // Strip leading action verbs, leading article, and trailing whitespace/punctuation.
  let po = prompt.split(/\d/)[0];
  po = po.replace(/^(?:make|build|create|design|generate|3d\s+print(?:ing)?|model|please\s+(?:make|build|create)|print)\s+/i, '').trim();
  po = po.replace(/^(?:a|an|the)\s+/i, '').trim();
  po = po.replace(/[\s,;:\-]+$/, '').trim();
  po = po.replace(/\s+(?:with|for|that|having|in|to|of|and|sized|at|on)$/i, '').trim();
  po = po.replace(/[\s,;:\-]+$/, '').trim();
  const primaryObject = po || intent.primaryObject || 'functional part';

  function parseUnitValue(valStr: string, unitStr?: string): number {
    const val = parseFloat(valStr);
    if (isNaN(val)) return 0;
    const u = (unitStr || '').toLowerCase().trim();
    if (u === 'cm') return val * 10;
    if (u === 'in' || u === 'inch' || u === 'inches' || u === '"') return val * 25.4;
    return val; // default mm
  }

  let parsedLength: number | null = null;
  let parsedWidth: number | null = null;
  let parsedDepth: number | null = null;
  let parsedHeight: number | null = null;
  let parsedDiameter: number | null = null;
  let explicitWidthStated = false;
  let explicitDepthStated = false;

  // 2. "BY" TRIPLES / PAIRS
  // Handle "80 by 60 by 40" and "80 x 60 x 40" with no units (assume mm) and with units on any or all terms.
  // Map in order to length (x), width (y), height (z). Two-term "80 by 60" maps to x and y with height unset.
  // This must run before the per-axis keyword matches so a triple wins, but a later explicit "tall" still overrides z.
  const byMatch = prompt.match(
    /\b(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?\s*(?:[x×*]|\bby\b)\s*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?(?:\s*(?:[x×*]|\bby\b)\s*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?)?/i
  );
  if (byMatch) {
    const fallbackUnit = byMatch[6] || byMatch[4] || byMatch[2] || 'mm';
    const u1 = byMatch[2] || fallbackUnit;
    const u2 = byMatch[4] || fallbackUnit;
    const u3 = byMatch[6] || fallbackUnit;
    parsedLength = Number(parseUnitValue(byMatch[1], u1).toFixed(2));
    parsedWidth = Number(parseUnitValue(byMatch[3], u2).toFixed(2));
    explicitWidthStated = true;
    if (byMatch[5]) {
      parsedHeight = Number(parseUnitValue(byMatch[5], u3).toFixed(2));
    }
  }

  // 3. Per-axis keyword matches (explicit keywords override or populate)
  // Height/Z: tall, high, height, thickness, thick (an explicit "tall" overrides triple z)
  const heightMatch = prompt.match(
    /(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?\s*(?:tall|high|height|thickness|thick)\b|(?:tall|high|height|thickness|thick)[:\s]*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?/i
  );
  if (heightMatch) {
    const val = heightMatch[1] || heightMatch[3];
    const unit = heightMatch[2] || heightMatch[4];
    if (val) parsedHeight = Number(parseUnitValue(val, unit).toFixed(2));
  }

  // Width/X or Y: wide, width
  const widthMatch = prompt.match(
    /(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?\s*(?:wide|width)\b|(?:wide|width)[:\s]*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?/i
  );
  if (widthMatch) {
    const val = widthMatch[1] || widthMatch[3];
    const unit = widthMatch[2] || widthMatch[4];
    if (val) {
      parsedWidth = Number(parseUnitValue(val, unit).toFixed(2));
      explicitWidthStated = true;
    }
  }

  // Length: long, length
  const lengthMatch = prompt.match(
    /(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?\s*(?:long|length)\b|(?:long|length)[:\s]*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?/i
  );
  if (lengthMatch) {
    const val = lengthMatch[1] || lengthMatch[3];
    const unit = lengthMatch[2] || lengthMatch[4];
    if (val) parsedLength = Number(parseUnitValue(val, unit).toFixed(2));
  }

  // Depth: deep, depth
  const depthMatch = prompt.match(
    /(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?\s*(?:deep|depth)\b|(?:deep|depth)[:\s]*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?/i
  );
  if (depthMatch) {
    const val = depthMatch[1] || depthMatch[3];
    const unit = depthMatch[2] || depthMatch[4];
    if (val) {
      parsedDepth = Number(parseUnitValue(val, unit).toFixed(2));
      explicitDepthStated = true;
    }
  }

  // 4. DIAMETER — allow an optional "in" between the value and the keyword.
  // Must match all of:
  //   "120mm diameter", "120mm in diameter", "3 inches in diameter",
  //   "diameter 120mm", "120mm across", "120 mm dia", "4in OD"
  // When diameter is found, set width, depth, AND diameter to that value unless width/depth were stated explicitly.
  const diaValFirstMatch = prompt.match(
    /(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?\s*(?:in\s+|of\s+)?(?:diameter|dia|od|outer\s+diameter|across)\b/i
  );
  const diaKwFirstMatch = prompt.match(
    /\b(?:diameter|dia|od|outer\s+diameter)(?:\s+(?:of|is|in))?[:\s]*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?/i
  );
  const diaMatch = diaValFirstMatch || diaKwFirstMatch;
  if (diaMatch) {
    const val = diaMatch[1];
    const unit = diaMatch[2];
    if (val) {
      parsedDiameter = Number(parseUnitValue(val, unit).toFixed(2));
      if (!explicitWidthStated) parsedWidth = parsedDiameter;
      if (!explicitDepthStated) parsedDepth = parsedDiameter;
      if (parsedLength === null) parsedLength = parsedDiameter;
    }
  }

  // 5. mustHoldLiquid: true if mentions water, liquid, reservoir, planter, cup, vase, bowl
  const mustHoldLiquid = /(?:water|liquid|reservoir|planter|cup|vase|bowl)/i.test(p);

  // 6. MULTI-PART — isMultiPart must be true if ANY of these hold:
  // - the prompt contains "lid", "cap", "cover", or "insert" (these pieces imply a second part)
  // - or the prompt mentions multiple parts ("2 parts", "two-part", "multi-part", "assembly")
  // - or the prompt asks for a box/case/container with a lid/top/cover
  const singleMultiKeywords = ['lid', 'cap', 'cover', 'insert'];
  const hasSingleMulti = singleMultiKeywords.some((kw) => new RegExp(`\\b${kw}s?\\b`, 'i').test(p));

  const multiPartMention = /\b(?:(?:two|three|four|multi|2|3|4)[-\s]?(?:piece|pieces|part|parts|halves)|multi-?part|assembl(?:y|ies))\b|\bin\s+(?:two|2)\s+halves\b/i.test(p);

  const containerWithTop = /\b(?:box|case|container|enclosure|housing|bin)\b[\s\S]*?\b(?:with|having|includes?|including|plus|\+)?[\s\S]*?\b(?:lid|top|cover|cap)\b/i.test(p);

  const secondaryMultiConcepts = [
    /\bbases?\b/i,
    /\b(?:body|bodies)\b/i,
    /\b(?:half|halves)\b/i,
    /\bpieces?\b/i,
    /\bparts?\b/i,
    /\btops?\b/i,
    /\bbottoms?\b/i,
    /\bshells?\b/i,
    /\bplugs?\b/i,
  ];
  const secondaryCount = secondaryMultiConcepts.filter((regex) => regex.test(p)).length;
  const hasTwoSecondary = secondaryCount >= 2;

  const isMultiPart = hasSingleMulti || multiPartMention || containerWithTop || hasTwoSecondary;

  const isInches = /inch|in\b|"/i.test(prompt);

  const reqsObj = {
    objectName: primaryObject ? primaryObject.toUpperCase() : prompt.slice(0, 35),
    primaryObject,
    classification: intent.classification,
    classificationConfidence: intent.confidence,
    classificationReason: intent.reason,
    inferredCategory: intent.classification === 'organic' ? 'ORGANIC_DECORATIVE' : 'PARAMETRIC_FUNCTIONAL',
    mountingStyle: 'freestanding',
    functionalRequirements: [
      ...intent.functionalRequirements,
      ...(mustHoldLiquid ? ['Watertight container geometry to hold liquid'] : []),
      ...(isMultiPart ? ['Multi-part interlocking assembly'] : []),
    ],
    decorativeRequirements: intent.decorativeRequirements,
    sculpturalRequirements: intent.sculpturalRequirements,
    isOrganicOnly: intent.classification === 'organic',
    units: isInches ? 'inches' : 'mm',
    overallDimensions: {
      width: parsedWidth,
      depth: parsedDepth ?? parsedWidth,
      height: parsedHeight,
      diameter: parsedDiameter,
      length: parsedLength ?? parsedWidth,
      rawInput: prompt,
    },
    wallThicknessMm: 3.0,
    matingClearanceMm: typeof printer?.measuredClearanceMm === 'number' ? printer.measuredClearanceMm : 0.25,
    mustHoldLiquid,
    isMultiPart,
    referenceObject: knownRef || (intent.referenceObject ? {
      name: intent.referenceObject,
      dimensions: { width: 80, depth: 80, height: 25, diameter: null },
      confidence: 'estimated',
      clearanceMm: 2.0,
      sourceNote: 'Derived from user reference',
    } : null),
    designPlan: {
      primaryObject: primaryObject || 'functional part',
      function: mustHoldLiquid ? 'Liquid holding utility' : 'Functional manufactured 3D print model',
      targetUseCase: 'General everyday utility',
      inferredCategory: 'PARAMETRIC_FUNCTIONAL',
      referenceObject: knownRef || null,
      inferredDimensions: {
        width: parsedWidth || parsedDiameter || 80,
        depth: parsedDepth || parsedLength || parsedDiameter || 80,
        height: parsedHeight || 25,
      },
      criticalDimensions: knownRef ? [`Fit clearance around ${knownRef.name}`] : ['Wall thickness 3.0mm'],
      mountingStyle: 'freestanding',
      structuralRequirements: ['Flat base at Z=0 for bed adhesion', 'Wall thickness 3.0mm'],
      ergonomicRequirements: ['Rounded outer corners'],
      aestheticRequirements: ['Clean CAD styling'],
      printConstraints: ['No unsupported overhangs steeper than 45°'],
      confidenceScore: 0.95,
      assumptions: ['Standard 3.0 mm wall thickness', 'Flat base at Z=0 for bed adhesion'],
      missingCriticalInfo: [],
      generationStrategy: isMultiPart ? 'Multi-Part Assembly with getParts()' : 'Parametric CSG Construction',
      keyFeatures: ['Parametric mechanical model based on: ' + prompt],
    },
    assumptionLedger: [
      {
        parameter: 'wallThickness',
        value: 3.0,
        unit: 'mm',
        basis: 'engineering_default',
        reasoning: 'Standard default durable wall thickness for FDM printing',
        confidence: 0.9,
        userEditable: true,
      },
    ],
    openQuestions: [],
    printOrientation: {
      recommendedUpAxis: '+Z (base on print bed)',
      reasoning: 'Print flat at Z=0 to maximize bed adhesion without supports',
      supportsRequired: false,
      maxOverhangAngleDeg: 45,
    },
    specConfidence: 0.95,
    specReviewIssues: [],
    explicitRequirements: [prompt],
    designDecisions: [
      'Selected durable 3.0 mm wall thickness',
      'Optimized base geometry for flat build-plate adhesion at Z=0',
    ],
    suggestedImprovements: [
      'Round outer corners by 5mm',
      'Add drainage slots or ribs',
      'Add mounting holes',
    ],
    unspecifiedProperties: [
      ...(parsedWidth === null && parsedDiameter === null ? ['Width not specified'] : []),
      ...(parsedDepth === null && parsedLength === null && parsedDiameter === null ? ['Depth not specified'] : []),
      ...(parsedHeight === null ? ['Height not specified'] : []),
    ],
    features: ['Parametric mechanical model based on: ' + prompt],
    quantities: {},
    spatialArrangements: [],
    fastenersOrHardware: [],
    tolerancesOrClearances: [],
    printConsiderations: ['Ensure base is flat at Z=0 for bed adhesion'],
    warnings: [],
  };

  return reqsObj;
}

// AI Semantic Feature Planning, Revision Intent, & Design Intent Audits

export function formatMatingClearanceContext(printer?: any): string {
  if (printer && typeof printer.measuredClearanceMm === 'number') {
    const val = printer.measuredClearanceMm.toFixed(2);
    const dateStr = printer.clearanceMeasuredAt || new Date().toISOString().slice(0, 10);
    const filStr = printer.clearanceFilamentId ? ` with ${printer.clearanceFilamentId.toUpperCase()}` : '';
    return `MATING CLEARANCE for this printer: ${val}mm per side (measured ${dateStr}${filStr}). Use this value for every lidClearance / fitClearance / socket clearance const.`;
  }
  return `MATING CLEARANCE for this printer: not measured — default to 0.25mm per side and name the const so the user can adjust it.`;
}



/**
 * Extracts part names or IDs from JSCAD multi-part code (e.g. kpPart_<id> or getParts array).
 */
export function extractPartNamesFromJscad(code: string): string[] {
  const names: string[] = [];
  const kpRegex = /function\s+kpPart_([A-Za-z0-9_]+)/g;
  let match: RegExpExecArray | null;
  while ((match = kpRegex.exec(code)) !== null) {
    names.push(match[1]);
  }
  const namePropRegex = /name:\s*['"`]([^'"`]+)['"`]/g;
  while ((match = namePropRegex.exec(code)) !== null) {
    if (!names.includes(match[1])) {
      names.push(match[1]);
    }
  }
  return names;
}
