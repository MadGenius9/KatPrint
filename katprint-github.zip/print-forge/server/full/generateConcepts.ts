import type { Express } from 'express';
import type { GoogleGenAI } from '@google/genai';
import {
  PRIMARY_MODEL,
  callGeminiWithResilience,
  cleanErrorMessage,
  getErrorDiagnostics,
  getGeminiClient,
  getLastSuccessfulModel,
} from '../gemini/client';
import { appendReferenceImagesToContents } from '../cad/shared';

export function registerGenerateConcepts(app: Express, ai: GoogleGenAI) {
  app.post('/api/generate-concepts', async (req, res) => {
    const { prompt, requirements, referenceImages = [] } = req.body;
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({
        error: 'Prompt string is required',
        errorCategory: 'INVALID_REQUEST',
        statusCode: 400,
      });
    }

    const aiClient = ai || getGeminiClient();
    if (!aiClient) {
      return res.status(401).json({
        error: 'Invalid or missing Gemini API credential.',
        errorCategory: 'AUTH_ERROR',
        technicalDetails: 'GEMINI_API_KEY environment variable is not set.',
        statusCode: 401,
      });
    }

    try {
      const accumulatedRecords: any[] = [];
      const startTime = Date.now();

      const systemInstruction = `You are an industrial design studio presenting three distinct approaches to the same brief. The approaches must differ in STRATEGY, not decoration — different mounting methods, different part counts, different manufacturing approaches, different trade-offs. Never present the same design three times with cosmetic changes.`;

      const userPrompt = `Present 3 distinct strategic design concepts (id "a", "b", and "c") for this brief: "${prompt}".

BASE SPECIFICATION:
${JSON.stringify(requirements || {}, null, 2)}

STRATEGY DIVERSIFICATION RULES:
1. Concept A: Monolithic / High-Efficiency (e.g. single-piece print, support-free orientation, maximum structural simplicity).
2. Concept B: Modular / High-Accessibility (e.g. split assembly, snap-fit or trapped hardware, replaceable retention clip).
3. Concept C: Alternative Mechanical / Advanced Ergonomic (e.g. sliding wedge lock, spring-tab retention, magnetic/clamp-on interface).

Output strictly valid JSON with this exact schema:
{
  "concepts": [
    {
      "id": "a",
      "name": "short name, e.g. 'Single-piece drip tray'",
      "approach": "2-3 sentences on the strategy",
      "keyFeatures": ["3 to 6 key technical feature strings"],
      "partCount": 1,
      "estimatedPrintTimeMin": 90,
      "estimatedMaterialG": 55,
      "tradeoffs": {
        "pros": ["2 to 4 positive trade-off strings"],
        "cons": ["2 to 4 drawback/cost trade-off strings"]
      },
      "difficulty": "easy",
      "requiresSupports": false,
      "dimensionDeltas": "how this concept's overall dimensions differ from the base spec, if at all",
      "specPatch": {
        "designPlan": {
          "keyFeatures": ["..."],
          "mountingStyle": "...",
          "structuralRequirements": ["..."],
          "printConstraints": ["..."]
        },
        "mountingStyle": "...",
        "wallThicknessMm": 3.0
      }
    }
  ]
}`;

      const contents: any[] = [{ text: userPrompt }];
      appendReferenceImagesToContents(contents, referenceImages);

      const result = await callGeminiWithResilience(aiClient, {
        purpose: 'design_reasoning',
        contents,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
        },
        enableThinking: true,
      });

      if (result.requestRecords) {
        accumulatedRecords.push(...result.requestRecords);
      }

      let parsed: any;
      try {
        parsed = JSON.parse(result.text);
      } catch (parseErr) {
        const cleanedText = result.text.replace(/```(?:json)?\n?/g, '').trim();
        parsed = JSON.parse(cleanedText);
      }

      const rawConcepts = Array.isArray(parsed?.concepts) ? parsed.concepts : [];
      const normalizedConcepts = rawConcepts.slice(0, 3).map((c: any, idx: number) => {
        const id = c.id === 'a' || c.id === 'b' || c.id === 'c' ? c.id : (['a', 'b', 'c'][idx] || `c_${idx}`);
        return {
          id,
          name: String(c.name || `Concept ${id.toUpperCase()}`),
          approach: String(c.approach || 'Strategic design approach for the stated brief.'),
          keyFeatures: Array.isArray(c.keyFeatures) ? c.keyFeatures.map(String) : ['Functional geometric design'],
          partCount: typeof c.partCount === 'number' && c.partCount > 0 ? c.partCount : 1,
          estimatedPrintTimeMin: typeof c.estimatedPrintTimeMin === 'number' ? c.estimatedPrintTimeMin : 90,
          estimatedMaterialG: typeof c.estimatedMaterialG === 'number' ? c.estimatedMaterialG : 50,
          tradeoffs: {
            pros: Array.isArray(c.tradeoffs?.pros) ? c.tradeoffs.pros.map(String) : ['Direct manufacturing process'],
            cons: Array.isArray(c.tradeoffs?.cons) ? c.tradeoffs.cons.map(String) : ['Standard operational trade-offs'],
          },
          difficulty: c.difficulty === 'easy' || c.difficulty === 'moderate' || c.difficulty === 'advanced' ? c.difficulty : 'moderate',
          requiresSupports: Boolean(c.requiresSupports),
          dimensionDeltas: String(c.dimensionDeltas || 'Matches base specification dimensions'),
          specPatch: c.specPatch && typeof c.specPatch === 'object' ? c.specPatch : {},
        };
      });

      const modelsUsed = Array.from(new Set(accumulatedRecords.map((r: any) => r.model)));
      const actualModelUsed = getLastSuccessfulModel(accumulatedRecords) || PRIMARY_MODEL;

      return res.json({
        concepts: normalizedConcepts,
        diagnostics: {
          modelUsed: actualModelUsed,
          modelsUsed,
          aiCallsMade: accumulatedRecords.length,
          requestRecords: accumulatedRecords,
          durationMs: Date.now() - startTime,
        },
      });
    } catch (err: any) {
      console.error('Generate concepts error:', err);
      const cleaned = cleanErrorMessage(err);
      return res.status(cleaned.statusCode).json({
        error: cleaned.message,
        errorCategory: cleaned.errorCategory,
        technicalDetails: cleaned.technicalDetails,
        statusCode: cleaned.statusCode,
        diagnostics: getErrorDiagnostics(err),
      });
    }
  });
}
