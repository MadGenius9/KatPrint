import type { Express } from 'express';
import type { GoogleGenAI } from '@google/genai';
import { DesignIntentStateDeltaSchema } from '../../src/ai/schemas';
import type {
  ProjectDesignState,
  DesignIntentStateDelta,
  DesignSpecification,
} from '../../src/types';
import type { SemanticFeatureModel } from '../../src/features/featureTypes';
import {
  callGeminiWithResilience,
  cleanErrorMessage,
  getErrorDiagnostics,
  getGeminiClient,
  AIRequestRecord,
} from '../gemini/client';

export async function updateDesignIntentAI(
  ai: GoogleGenAI,
  options: {
    currentDesignState: ProjectDesignState;
    userMessage: string;
    currentFeatureModel?: SemanticFeatureModel;
    currentDesignSpecification?: DesignSpecification;
    selectedFeatureIds?: string[];
    recentConversation?: any[];
  }
): Promise<{
  delta: DesignIntentStateDelta;
  aiMetadata: {
    modelUsed: string;
    modelsUsed: string[];
    totalModelCalls: number;
    requestRecords: AIRequestRecord[];
    durationMs: number;
  };
}> {
  const { currentDesignState, userMessage, currentFeatureModel, currentDesignSpecification, selectedFeatureIds, recentConversation } = options;
  const startTime = Date.now();
  const requestRecords: AIRequestRecord[] = [];
  const modelsUsedSet = new Set<string>();

  const systemInstruction = `You are a Principal CAD Design Intent Architect.
Analyze the user's conversational message, revision request, or feedback against the current 3D CAD project state and produce a structured DELTA of changes to the Persistent Design Intent State.

DO NOT return the entire state. Return ONLY the changes (DesignIntentStateDelta).`;

  const promptText = `USER MESSAGE: "${userMessage}"

CURRENT PERSISTENT DESIGN STATE:
${JSON.stringify(currentDesignState || {}, null, 2)}

CURRENT FEATURE MODEL SUMMARY:
${JSON.stringify(currentFeatureModel ? {
  features: currentFeatureModel.features.map((f) => ({ id: f.id, type: f.type, label: f.label, purpose: f.purpose, parameters: f.parameters })),
  constraints: currentFeatureModel.constraints,
} : {}, null, 2)}

SELECTED FEATURES:
${JSON.stringify(selectedFeatureIds || [], null, 2)}

RECENT CONVERSATION:
${JSON.stringify((recentConversation || []).slice(-4), null, 2)}

Produce the structured DesignIntentStateDelta JSON.`;

  const result = await callGeminiWithResilience(ai, {
    purpose: 'design_intent_update',
    contents: [{ text: promptText }],
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: DesignIntentStateDeltaSchema,
    },
    enableThinking: true,
  });

  result.requestRecords.forEach((r) => {
    modelsUsedSet.add(r.model);
    requestRecords.push(r);
  });

  let delta: DesignIntentStateDelta;
  try {
    const text = result.text.trim().replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
    delta = JSON.parse(text);
  } catch (err) {
    delta = {
      summary: 'No intent delta could be parsed from message',
    };
  }

  return {
    delta,
    aiMetadata: {
      modelUsed: result.model,
      modelsUsed: Array.from(modelsUsedSet),
      totalModelCalls: result.attempts,
      requestRecords,
      durationMs: Date.now() - startTime,
    },
  };
}



export function registerUpdateDesignIntent(app: Express, ai: GoogleGenAI) {
  app.post('/api/update-design-intent', async (req, res) => {
    const {
      currentDesignState,
      userMessage,
      currentFeatureModel,
      currentDesignSpecification,
      selectedFeatureIds = [],
      recentConversation = [],
    } = req.body;
  
    if (!userMessage || !currentDesignState) {
      return res.status(400).json({
        error: 'currentDesignState and userMessage are required for design intent delta update',
        errorCategory: 'INVALID_REQUEST',
        statusCode: 400,
      });
    }
  
    const aiClient = ai || getGeminiClient();
    if (!aiClient) {
      return res.status(401).json({
        error: 'Invalid or missing Gemini API credential.',
        errorCategory: 'AUTH_ERROR',
        technicalDetails: 'GEMINI_API_KEY environment variable is not set.',
        statusCode: 401,
      });
    }
  
    try {
    const result = await updateDesignIntentAI(aiClient, {
        currentDesignState,
        userMessage,
        currentFeatureModel,
        currentDesignSpecification,
        selectedFeatureIds,
        recentConversation,
      });
  
      return res.json({
        delta: result.delta,
        diagnostics: {
          modelUsed: result.aiMetadata.modelUsed,
          modelsUsed: result.aiMetadata.modelsUsed,
          aiCallsMade: result.aiMetadata.totalModelCalls,
          requestRecords: result.aiMetadata.requestRecords,
          durationMs: result.aiMetadata.durationMs,
        },
      });
    } catch (err: any) {
      console.error('Update design intent error:', err);
      const cleaned = cleanErrorMessage(err);
      return res.status(cleaned.statusCode).json({
        error: cleaned.message,
        errorCategory: cleaned.errorCategory,
        technicalDetails: cleaned.technicalDetails,
        statusCode: cleaned.statusCode,
        diagnostics: getErrorDiagnostics(err),
      });
    }
  });

}
