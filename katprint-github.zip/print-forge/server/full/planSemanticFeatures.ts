import type { Express } from 'express';
import type { GoogleGenAI } from '@google/genai';
import {
  getFeatureRegistrySummary,
} from '../../src/features/featureRegistry';
import {
  planSemanticFeatureModelFromPlan,
  scoreSemanticFeaturePlan,
  planSemanticFeatureModelFallback,
  shouldGenerateMultipleSemanticPlans,
  normalizeSemanticPlan,
  normalizeSemanticPlanParameters,
  buildSemanticPlanTopologySignature,
} from '../../src/features/featurePlanner';
import {
  SemanticFeaturePlanSchema,
  MultiPlanSemanticFeaturePlanSchema,
} from '../../src/ai/schemas';
import type {
  DesignSpecification,
  DesignCheck,
  GenerationMode,
  ProjectReferenceImage,
  ProjectDesignState,
  SemanticFeaturePlan,
  ReferenceImageObservation,
} from '../../src/types';
import type { SemanticFeatureModel } from '../../src/features/featureTypes';
import {
  callGeminiWithResilience,
  cleanErrorMessage,
  getErrorDiagnostics,
  getGeminiClient,
  AIRequestRecord,
} from '../gemini/client';
import { appendReferenceImagesToContents } from '../cad/shared';

export async function planSemanticFeaturesAI(
  ai: GoogleGenAI,
  options: {
    prompt: string;
    spec?: DesignSpecification;
    checklist?: DesignCheck[];
    referenceImages?: ProjectReferenceImage[];
    projectDesignState?: ProjectDesignState;
    projectMemory?: any;
    printer?: any;
    mode?: GenerationMode | string;
    referenceImageObservations?: ReferenceImageObservation[];
  }
): Promise<{
  plan: SemanticFeaturePlan;
  featureModel: SemanticFeatureModel;
  score: number;
  scoreBreakdown: Record<string, number | null>;
  usedFallback?: boolean;
  fallbackReason?: string;
  plansRequested: 1 | 3;
  plansReceived: number;
  initialPlansReceived?: number;
  retryPlansReceived?: number;
  validPlansEvaluated?: number;
  distinctPlansEvaluated?: number;
  degradedMultiPlan?: boolean;
  degradedReason?: string;
  plansEvaluated: number;
  aiMetadata: {
    modelUsed: string;
    modelsUsed: string[];
    totalModelCalls: number;
    requestRecords: AIRequestRecord[];
    durationMs: number;
  };
}> {
  const {
    prompt,
    spec,
    checklist,
    referenceImages,
    projectDesignState,
    projectMemory,
    printer,
    mode,
    referenceImageObservations,
  } = options;

  const startTime = Date.now();
  const requestRecords: AIRequestRecord[] = [];
  const modelsUsedSet = new Set<string>();

  const registrySummary = getFeatureRegistrySummary();
  const generateMultiple = shouldGenerateMultipleSemanticPlans(prompt, mode, spec);
  const plansRequested: 1 | 3 = generateMultiple ? 3 : 1;

  const systemInstruction = `You are a Principal Mechanical CAD Architect and Precision Parametric Product Designer.
Your task is to analyze the user's design request, reference photos, dimensions, and specifications to produce a structured, mathematically coherent Semantic Feature Plan (in JSON) for 3D printing.

${registrySummary}

PLANNING RULES & INVARIANTS:
1. SEMANTIC FEATURE DECOMPOSITION:
   - Deconstruct the mechanical object into explicit, functional features with unique string IDs (e.g., "base_tray", "drainage_slot_array", "mounting_bosses", "cable_opening", "reinforcing_ribs", "lid_rebate").
   - Prefer registered feature types over generic ones.
   - For every feature, specify its geometry operation: 'base' (primary solid), 'add' (additive boss/rib/wall), 'subtract' (hole/slot/cavity/pocket), 'intersect', 'pattern', or 'finish' (fillet/chamfer).
2. EXPLICIT PARAMETERIZATION & UNITS:
   - Provide an array of parameters conforming to GeminiSemanticParameterSchema for every feature.
   - Every dimension mentioned in the prompt or spec must be mapped to an explicit parameter with locked: true if critical.
3. CONSTRAINTS & RELATIONSHIPS:
   - Enforce minimum wall thickness >= 2.4 mm (3.0 mm for structural walls).
   - Define relationships between features (e.g. "attached_to", "cut_from", "aligned_with", "pattern_of").
   - Define derived parameters (e.g. innerWidth = targetWidth - 2 * wallThickness).
4. MULTI-PART ACCURACY:
   - If the object has multiple printable parts (e.g. box + lid, bracket + clamp, body + dial), define parts array with unique part IDs and specify which features belong to which partId.
   - Specify clearance for mating interfaces (e.g. 0.3mm to 0.4mm for slide/snap fits).
${generateMultiple ? '5. MULTI-PLAN STRATEGY: Provide exactly 3 DISTINCT candidatePlans with meaningfully different structural or manufacturing approaches.' : '5. SINGLE-PLAN STRATEGY: Provide 1 complete, high-precision plan.'}`;

  let userContext = `USER PROMPT: "${prompt}"\n`;
  if (spec) {
    userContext += `\nDESIGN SPECIFICATION:\n${JSON.stringify(spec, null, 2)}\n`;
  }
  if (projectDesignState) {
    userContext += `\nPERSISTENT PROJECT DESIGN STATE:\n${JSON.stringify(projectDesignState, null, 2)}\n`;
  }
  if (referenceImageObservations && referenceImageObservations.length > 0) {
    userContext += `\nREFERENCE IMAGE OBSERVATIONS:\n${JSON.stringify(referenceImageObservations, null, 2)}\n`;
  }
  if (projectMemory) {
    const memorySummary: any = {};
    if (projectMemory.decisions || projectMemory.importantDecisions) {
      memorySummary.decisions = projectMemory.decisions || projectMemory.importantDecisions;
    }
    if (projectMemory.preferences || projectMemory.userPreferences) {
      memorySummary.preferences = projectMemory.preferences || projectMemory.userPreferences;
    }
    if (projectMemory.rejectedDirections || projectMemory.rejectedOptions) {
      memorySummary.rejectedDirections = projectMemory.rejectedDirections || projectMemory.rejectedOptions;
    }
    if (projectMemory.lockedParameters || projectMemory.rememberedConstraints) {
      memorySummary.rememberedConstraints = projectMemory.lockedParameters || projectMemory.rememberedConstraints;
    }
    if (Object.keys(memorySummary).length > 0) {
      userContext += `\nPROJECT MEMORY & PREFERENCES:\n${JSON.stringify(memorySummary, null, 2)}\n`;
    }
  }
  if (printer) {
    const printerInfo = {
      name: printer.name || 'FDM 3D Printer',
      buildVolume: printer.buildVolume || { x: 220, y: 220, z: 250 },
      nozzleDiameter: printer.nozzleDiameter || 0.4,
      note: 'Design accurately to requested dimensions. If model exceeds build volume, design correctly without shrinking; fit report will flag it.',
    };
    userContext += `\nTARGET PRINTER MANUFACTURING CONSTRAINTS:\n${JSON.stringify(printerInfo, null, 2)}\n`;
  }
  if (checklist && checklist.length > 0) {
    userContext += `\nCHECKLIST CHECKS:\n${checklist.map((c) => `- [${c.type}] ${c.description || (c as any).requirement || ''}`).join('\n')}\n`;
  }

  const contents: any[] = [{ text: userContext }];
  appendReferenceImagesToContents(contents, referenceImages || []);

  const result = await callGeminiWithResilience(ai, {
    purpose: 'semantic_feature_planning',
    contents,
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: generateMultiple ? MultiPlanSemanticFeaturePlanSchema : SemanticFeaturePlanSchema,
    },
    enableThinking: true,
  });

  result.requestRecords.forEach((r) => {
    modelsUsedSet.add(r.model);
    requestRecords.push(r);
  });

  let rawJson: any = null;
  try {
    const text = result.text.trim().replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
    rawJson = JSON.parse(text);
  } catch (parseErr) {
    console.warn('Failed to parse semantic feature plan JSON, using fallback planner:', parseErr);
  }

  const effectiveSpec = spec || ({ primaryObject: prompt, explicitDimensions: [], requiredFeatures: [] } as any);

  let plan: SemanticFeaturePlan | null = null;
  let usedFallback = false;
  let fallbackReason: string | undefined = undefined;
  let plansReceived = 0;
  let initialPlansReceived = 0;
  let retryPlansReceived = 0;
  let validPlansEvaluated = 0;
  let distinctPlansEvaluated = 0;
  let degradedMultiPlan = false;
  let degradedReason: string | undefined = undefined;
  let plansEvaluated = 0;

  // Helper to validate and score a plan candidate
  const evaluateCandidate = (candidate: any): { plan: SemanticFeaturePlan; score: number; breakdown: Record<string, number | null> } | null => {
    if (!candidate || typeof candidate !== 'object') return null;
    const normalized = normalizeSemanticPlan(candidate);
    if (!normalized || normalized.features.length === 0) return null;

    const scoreRes = scoreSemanticFeaturePlan(normalized, effectiveSpec, prompt, projectDesignState);
    normalized.score = scoreRes.score;
    normalized.scoreBreakdown = scoreRes.breakdown as any;
    return { plan: normalized, score: scoreRes.score, breakdown: scoreRes.breakdown };
  };

  if (rawJson) {
    let rawList: any[] = [];
    if (Array.isArray(rawJson.candidatePlans) && rawJson.candidatePlans.length > 0) {
      rawList = rawJson.candidatePlans;
    } else if (Array.isArray(rawJson.plans) && rawJson.plans.length > 0) {
      rawList = rawJson.plans;
    } else if (rawJson.features) {
      rawList = [rawJson];
    }

    initialPlansReceived = rawList.length;
    plansReceived = initialPlansReceived;

    const scoredCandidates = rawList
      .map(evaluateCandidate)
      .filter((c): c is NonNullable<typeof c> => c !== null);

    validPlansEvaluated = scoredCandidates.length;
    plansEvaluated = validPlansEvaluated;

    // If multi-plan was requested and fewer than 3 candidates were received, attempt structured retry
    if (generateMultiple && scoredCandidates.length < 3) {
      try {
        const retryResult = await callGeminiWithResilience(ai, {
          purpose: 'semantic_feature_planning_retry',
          contents: [
            ...contents,
            { text: `The previous response provided only ${scoredCandidates.length} valid plan(s). You MUST return EXACTLY 3 DISTINCT candidatePlans with meaningfully different structural or manufacturing approaches.` },
          ],
          config: {
            systemInstruction,
            responseMimeType: 'application/json',
            responseSchema: MultiPlanSemanticFeaturePlanSchema,
          },
          enableThinking: true,
        });

        retryResult.requestRecords.forEach((r) => {
          modelsUsedSet.add(r.model);
          requestRecords.push(r);
        });

        const retryText = retryResult.text.trim().replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
        const retryJson = JSON.parse(retryText);
        const retryList = Array.isArray(retryJson.candidatePlans)
          ? retryJson.candidatePlans
          : Array.isArray(retryJson.plans)
          ? retryJson.plans
          : [];

        retryPlansReceived = retryList.length;
        plansReceived = initialPlansReceived + retryPlansReceived;

        for (const cand of retryList) {
          const evaled = evaluateCandidate(cand);
          if (evaled) scoredCandidates.push(evaled);
        }
        validPlansEvaluated = scoredCandidates.length;
        plansEvaluated = scoredCandidates.length;
      } catch (retryErr) {
        console.warn('Retry for 3 candidate plans failed, proceeding with available candidates:', retryErr);
      }
    }

    if (scoredCandidates.length > 0) {
      // Deduplication check: remove structurally identical plans using topological signature
      const uniqueCandidates: typeof scoredCandidates = [];
      const seenSignatures = new Set<string>();

      for (const cand of scoredCandidates) {
        const sig = buildSemanticPlanTopologySignature(cand.plan);
        if (!seenSignatures.has(sig)) {
          seenSignatures.add(sig);
          uniqueCandidates.push(cand);
        }
      }

      distinctPlansEvaluated = uniqueCandidates.length;
      if (generateMultiple && distinctPlansEvaluated < 3) {
        degradedMultiPlan = true;
        degradedReason = `Received ${distinctPlansEvaluated} distinct plan(s) out of 3 requested.`;
      }

      const pool = uniqueCandidates.length > 0 ? uniqueCandidates : scoredCandidates;

      // Deterministic comparator: score, critical coverage, dimension coverage, part count appropriateness
      pool.sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score;
        const bCrit = (b.breakdown.criticalFeatureCoverage ?? 0);
        const aCrit = (a.breakdown.criticalFeatureCoverage ?? 0);
        if (bCrit !== aCrit) return bCrit - aCrit;
        const bDim = (b.breakdown.exactDimensionCoverage ?? 0);
        const aDim = (a.breakdown.exactDimensionCoverage ?? 0);
        if (bDim !== aDim) return bDim - aDim;
        return (b.breakdown.partCountAppropriateness ?? 0) - (a.breakdown.partCountAppropriateness ?? 0);
      });

      plan = pool[0].plan;
    }
  }

  if (!plan) {
    // Deterministic fallback if Gemini plan was empty or invalid
    usedFallback = true;
    fallbackReason = 'Semantic plan parsing or candidate validation returned no valid candidates.';
    const fallbackModel = planSemanticFeatureModelFallback(effectiveSpec, prompt, checklist);
    plan = {
      objectSummary: effectiveSpec.primaryObject || prompt,
      designIntent: {
        primaryFunction: effectiveSpec.intendedFunction || 'Functional CAD model',
        secondaryFunctions: [],
        environment: 'Workshop / Desktop',
        userPriorities: ['Printability', 'Dimensional Accuracy'],
      },
      parts: [{ id: 'main', name: 'Main Body', quantity: 1, purpose: 'Primary solid' }],
      features: fallbackModel.features.map((f) => ({
        id: f.id,
        partId: 'main',
        type: f.type,
        label: f.label,
        purpose: f.purpose,
        geometryOperation: f.geometryOperation,
        criticality: f.criticality,
        parameters: normalizeSemanticPlanParameters(f.parameters),
      })),
      constraints: fallbackModel.constraints.map((c) => ({
        name: c.name,
        constraintType: c.constraintType,
        affectedFeatureIds: c.affectedFeatureIds,
        value: c.value,
      })),
      generationStrategy: fallbackModel.generationStrategy,
      expectedPartCount: 1,
    };
    const fallbackScore = scoreSemanticFeaturePlan(plan, effectiveSpec, prompt);
    plan.score = fallbackScore.score;
    plan.scoreBreakdown = fallbackScore.breakdown as any;
  }

  const scoreResult = scoreSemanticFeaturePlan(plan, effectiveSpec, prompt);
  plan.score = scoreResult.score;
  plan.scoreBreakdown = scoreResult.breakdown as any;

  const featureModel = planSemanticFeatureModelFromPlan(plan, prompt, effectiveSpec);

  return {
    plan,
    featureModel,
    score: scoreResult.score,
    scoreBreakdown: scoreResult.breakdown,
    usedFallback,
    fallbackReason,
    plansRequested,
    plansReceived,
    initialPlansReceived,
    retryPlansReceived,
    validPlansEvaluated,
    distinctPlansEvaluated,
    degradedMultiPlan,
    degradedReason,
    plansEvaluated,
    aiMetadata: {
      modelUsed: result.model,
      modelsUsed: Array.from(modelsUsedSet),
      totalModelCalls: result.attempts,
      requestRecords,
      durationMs: Date.now() - startTime,
    },
  };
}



export function registerPlanSemanticFeatures(app: Express, ai: GoogleGenAI) {
  app.post('/api/plan-semantic-features', async (req, res) => {
    const {
      prompt,
      spec,
      checklist = [],
      referenceImages = [],
      referenceImageObservations = [],
      projectDesignState,
      projectMemory,
      printer,
      mode = 'precision',
    } = req.body;
  
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({
        error: 'Prompt string is required',
        errorCategory: 'INVALID_REQUEST',
        statusCode: 400,
      });
    }
  
    const aiClient = ai || getGeminiClient();
    if (!aiClient) {
      return res.status(401).json({
        error: 'Invalid or missing Gemini API credential.',
        errorCategory: 'AUTH_ERROR',
        technicalDetails: 'GEMINI_API_KEY environment variable is not set.',
        statusCode: 401,
      });
    }
  
    try {
      const result = await planSemanticFeaturesAI(aiClient, {
        prompt,
        spec,
        checklist,
        referenceImages,
        projectDesignState,
        projectMemory,
        printer,
        mode,
        referenceImageObservations,
      });
  
      return res.json({
        plan: result.plan,
        featureModel: result.featureModel,
        score: result.score,
        scoreBreakdown: result.scoreBreakdown,
        usedFallback: result.usedFallback,
        fallbackReason: result.fallbackReason,
        plansRequested: result.plansRequested,
        plansReceived: result.plansReceived,
        initialPlansReceived: result.initialPlansReceived,
        retryPlansReceived: result.retryPlansReceived,
        validPlansEvaluated: result.validPlansEvaluated,
        distinctPlansEvaluated: result.distinctPlansEvaluated,
        degradedMultiPlan: result.degradedMultiPlan,
        degradedReason: result.degradedReason,
        plansEvaluated: result.plansEvaluated,
        diagnostics: {
          modelUsed: result.aiMetadata.modelUsed,
          modelsUsed: result.aiMetadata.modelsUsed,
          aiCallsMade: result.aiMetadata.totalModelCalls,
          requestRecords: result.aiMetadata.requestRecords,
          durationMs: result.aiMetadata.durationMs,
          usedFallback: result.usedFallback,
          fallbackReason: result.fallbackReason,
          plansRequested: result.plansRequested,
          plansReceived: result.plansReceived,
          initialPlansReceived: result.initialPlansReceived,
          retryPlansReceived: result.retryPlansReceived,
          validPlansEvaluated: result.validPlansEvaluated,
          distinctPlansEvaluated: result.distinctPlansEvaluated,
          degradedMultiPlan: result.degradedMultiPlan,
          degradedReason: result.degradedReason,
          plansEvaluated: result.plansEvaluated,
        },
      });
    } catch (err: any) {
      console.error('Plan semantic features error:', err);
      const cleaned = cleanErrorMessage(err);
      return res.status(cleaned.statusCode).json({
        error: cleaned.message,
        errorCategory: cleaned.errorCategory,
        technicalDetails: cleaned.technicalDetails,
        statusCode: cleaned.statusCode,
        diagnostics: getErrorDiagnostics(err),
      });
    }
  });

}
