import type { Express } from 'express';
import type { GoogleGenAI } from '@google/genai';
import type { ProjectReferenceImage } from '../../src/types';
import {
  PRIMARY_MODEL,
  callGeminiWithResilience,
  getLastSuccessfulModel,
  cleanErrorMessage,
  getErrorDiagnostics,
  getGeminiClient,
  AIRequestRecord,
} from '../gemini/client';
import {
  appendReferenceImagesToContents,
  matchKnownReference,
  classifyPromptIntent,
} from '../cad/shared';

export async function extractRequirements(prompt: string, ai: GoogleGenAI, referenceImages: ProjectReferenceImage[] = []): Promise<any> {
  const startTime = Date.now();
  const knownRef = matchKnownReference(prompt);
  const baselineClassification = classifyPromptIntent(prompt);
  const accumulatedRecords: AIRequestRecord[] = [];

  // ---------------------------------------------------------------------------
  // PASS 1: DESIGN BRIEF (No numbers yet, intent only)
  // ---------------------------------------------------------------------------
  const pass1SystemInstruction = `You are a senior industrial designer conducting a design intake interview. Do NOT produce dimensions. Produce only intent.

Output ONLY valid JSON matching this schema:
{
  "primaryObject": "string",
  "userGoal": "what the person is actually trying to accomplish, in one sentence",
  "useEnvironment": "where it lives and what it endures (wet, outdoor, load-bearing, handled daily, static display)",
  "loadCase": {
    "type": "none" | "static" | "repeated_handling" | "cantilever" | "impact" | "clamping",
    "estimatedLoadN": number | null,
    "loadDirection": "describe relative to the part"
  },
  "referenceObject": { "name": "string", "needsMeasurement": boolean } | null,
  "fitCriticality": "cosmetic" | "loose_fit" | "functional_fit" | "precision_fit",
  "openQuestions": [
    {
      "id": "string",
      "question": "plain-English question for the user",
      "whyItMatters": "string",
      "assumedAnswer": "the answer you will proceed with if unanswered",
      "confidence": number
    }
  ],
  "conceptSummary": "2-3 sentences describing the part you intend to design"
}

Rules for openQuestions:
Emit 0 to 4 questions, ONLY where a wrong guess would make the part unusable (a missing reference dimension, an unspecified mount type, an unstated load).
Never ask about things you can safely default (fillet radius, color, infill, standard clearance).
Every question MUST carry an assumedAnswer with confidence (0-1) so generation can proceed without the user.`;

  let pass1Json: any = null;
  try {
    const pass1Contents: any[] = [{
      text: `Conduct a design intake interview and extract the user's core intent for: "${prompt}".
${knownRef ? `[HINT: Matched known verified reference item: ${JSON.stringify(knownRef)}]` : ''}
Do NOT produce dimensions. Produce only intent as structured JSON according to your system instruction.`,
    }];
    appendReferenceImagesToContents(pass1Contents, referenceImages);

    const pass1Res = await callGeminiWithResilience(ai, {
      purpose: 'design_brief',
      contents: pass1Contents,
      config: {
        systemInstruction: pass1SystemInstruction,
        responseMimeType: 'application/json',
      },
    });

    if (pass1Res.requestRecords) {
      accumulatedRecords.push(...pass1Res.requestRecords);
    }
    pass1Json = JSON.parse(pass1Res.text);
  } catch (p1Err: any) {
    console.warn('[extractRequirements] Pass 1 (Design Brief) failed, degrading gracefully to synthesized brief:', p1Err?.message || p1Err);
    if (p1Err?.requestRecords && Array.isArray(p1Err.requestRecords)) {
      accumulatedRecords.push(...p1Err.requestRecords);
    }
    pass1Json = {
      primaryObject: baselineClassification.primaryObject || 'functional part',
      userGoal: `Fabricate ${prompt}`,
      useEnvironment: 'standard indoor utility',
      loadCase: { type: 'static', estimatedLoadN: null, loadDirection: 'downward gravity' },
      referenceObject: knownRef ? { name: knownRef.name, needsMeasurement: false } : null,
      fitCriticality: 'functional_fit',
      openQuestions: [],
      conceptSummary: `3D printable parametric model designed for ${prompt}.`,
    };
  }

  // ---------------------------------------------------------------------------
  // PASS 2: ENGINEERING SPEC (Convert intent into numbers & assumption ledger)
  // ---------------------------------------------------------------------------
  const pass2SystemInstruction = `You are a world-class industrial product designer, mechanical specification engineer, and CAD analyst.
The design brief above is authoritative for intent. Your job is to convert it into numbers.
Every numeric value you produce must be traceable. Populate \`assumptionLedger\`.
Wall thickness must be justified by the loadCase, not chosen by habit.

# CRITICAL CLASSIFICATION & INTENT ARCHITECTURE:
Before deciding the classification engine, YOU MUST EXTRACT:
1. "primaryObject": The actual physical item being manufactured (e.g. "soap dish", "tray", "holder", "stand", "mount", "bracket", "organizer", "enclosure", "box", "adapter", "spacer", "clamp", "shelf", "hook", "cup holder", "phone stand", "battery holder", "controller holder", "tool holder", "wall mount", "container", "drawer organizer", "cable guide", "pipe fitting", "cover", "lid", "rack", "knob", "statue", "figurine").
2. "referenceObject": Name and dimensions of any reference product being fitted or held (e.g. "Dr. Squatch soap bar", "Xbox controller", "Milwaukee M18 battery", "Stanley 40 oz tumbler", "iPhone 17 Pro Max", "Yeti bottle", "GoPro", "AA battery", "soda can", "toothbrush").
3. "inferredCategory": One of ["PARAMETRIC_FUNCTIONAL", "PARAMETRIC_DECORATIVE", "HYBRID_FUNCTIONAL", "ORGANIC_DECORATIVE", "ENCLOSURE", "HOLDER_OR_MOUNT", "CONTAINER_OR_TRAY", "THREAD_OR_MECHANICAL_PART"].
4. "mountingStyle": One of ["freestanding", "desktop / tabletop", "wall mount", "under-desk mount", "snap-fit / clip", "drop-in insert", "DIN rail"].
5. "designPlan": A comprehensive design strategy including:
   - "function": Specific physical and practical purpose.
   - "targetUseCase": Where and how it is used.
   - "keyFeatures": 3-6 explicit and inferred geometric features.
   - "assumptions": Inferred engineering assumptions.
   - "generationStrategy": Detailed step-by-step CSG modeling approach.

# CLASSIFICATION RULES:
1. PARAMETRIC (DEFAULT FOR FUNCTIONAL OBJECTS):
   - A PRODUCT NAME, BRAND NAME, REFERENCE OBJECT, OR OBJECT BEING FITTED DOES NOT MAKE A DESIGN ORGANIC OR HYBRID.
   - Whenever the primary requested object is a functional manufactured part, it MUST be PARAMETRIC.
2. ORGANIC (SCULPTURES ONLY):
   - Classify as ORGANIC ONLY when the primary requested object itself requires true freeform/sculptural geometry with NO precision mechanical interfaces.
3. HYBRID (EXTREMELY RARE):
   - Classify as HYBRID ONLY when the design explicitly combines substantial anatomical sculpt with precision mechanical mounting.

CORE INDUSTRIAL DESIGN PRINCIPLES:
1. DESIGN FOR FIT & CLEARANCE:
   - If user names a physical object being fitted, identify it under "referenceObject" with appropriate clearance (+1.5 mm to +3.0 mm).
2. UNIT CONVERSION MANDATE:
   - All measurements strictly in millimeters (1 inch = 25.4 mm).
3. SUGGESTED IMPROVEMENTS:
   - Provide 2-4 concrete, clickable improvement suggestions tailored to this specific object.

REFERENCE IMAGE EVIDENCE RULES:
- When reference images are provided, inspect the actual pixels as visual design evidence.
- Evidence priority: explicit user text dimensions > explicit measured notes on reference images > visible image geometry > engineering inference/defaults.

Output ONLY valid JSON with this schema:
{
  "objectName": "Short descriptive title (e.g. Dr. Squatch Raised Soap Dish)",
  "primaryObject": "soap dish",
  "classification": "parametric" | "organic" | "hybrid",
  "classificationConfidence": number,
  "classificationReason": "Functional manufactured soap dish designed to fit reference product.",
  "inferredCategory": "CONTAINER_OR_TRAY" | "HOLDER_OR_MOUNT" | "PARAMETRIC_FUNCTIONAL" | "ENCLOSURE" | "THREAD_OR_MECHANICAL_PART",
  "mountingStyle": "desktop / tabletop" | "wall mount" | "under-desk mount" | "freestanding",
  "isOrganicOnly": boolean,
  "functionalRequirements": ["hold Dr. Squatch soap bar", "drainage slots", "raised airflow drying ribs", "stable base"],
  "decorativeRequirements": ["none"],
  "sculpturalRequirements": ["none"],
  "units": "mm" | "cm" | "inches" | "feet" | "mixed",
  "overallDimensions": {
    "width": number | null,
    "depth": number | null,
    "height": number | null,
    "diameter": number | null,
    "length": number | null,
    "rawInput": "Original raw dimensional text"
  },
  "wallThicknessMm": number | null,
  "referenceObject": {
    "name": "Name of object being fitted",
    "dimensions": { "width": number, "depth": number, "height": number, "diameter": number | null },
    "confidence": "verified" | "estimated",
    "clearanceMm": number,
    "sourceNote": "Source or reasoning for dimensions"
  } | null,
  "designPlan": {
    "primaryObject": "Soap Dish",
    "function": "Elevate soap bar, allow water drainage, and facilitate airflow drying",
    "targetUseCase": "Bathroom vanity / shower counter",
    "inferredCategory": "CONTAINER_OR_TRAY",
    "inferredDimensions": { "width": 88, "depth": 88, "height": 22 },
    "criticalDimensions": ["Inner cavity clearance +2.0mm around Dr. Squatch Soap Bar"],
    "mountingStyle": "desktop / tabletop",
    "structuralRequirements": ["3.2mm wall thickness", "Flat base at Z=0"],
    "ergonomicRequirements": ["Rounded outer corners with 6mm radius"],
    "aestheticRequirements": ["Clean geometric lines"],
    "printConstraints": ["Orient flat on build plate at Z=0"],
    "confidenceScore": 0.96,
    "assumptions": ["Assumed 3.2 mm wall thickness for rigidity", "Added 5 drainage slots (4 mm wide)", "Raised drying ribs by 3.5 mm"],
    "missingCriticalInfo": [],
    "generationStrategy": "Parametric Tray with Drainage Grate & Ribs",
    "keyFeatures": ["Raised drainage ribs", "Water drain slots", "Perimeter drip catch tray", "Filleted ergonomic rim"]
  },
  "assumptionLedger": [
    {
      "parameter": "wallThickness",
      "value": 3.2,
      "unit": "mm",
      "basis": "user_stated" | "reference_library" | "measured_from_image" | "engineering_default" | "inferred_from_load",
      "reasoning": "Standard rigid shell for soap tray under static load",
      "confidence": 0.95,
      "userEditable": true
    }
  ],
  "openQuestions": [
    {
      "id": "q1",
      "question": "plain-English question",
      "whyItMatters": "reasoning",
      "assumedAnswer": "assumed answer",
      "confidence": 0.85
    }
  ],
  "printOrientation": {
    "recommendedUpAxis": "+Z face description",
    "reasoning": "description of print stability and overhang mitigation",
    "supportsRequired": boolean,
    "maxOverhangAngleDeg": number
  },
  "specConfidence": number,
  "explicitRequirements": ["User explicitly asked for ..."],
  "designDecisions": ["Assumed 3.2 mm wall thickness for rigidity", "Added 5 drainage slots (4 mm wide)"],
  "suggestedImprovements": ["Add counterbore mounting holes", "Add drip tray catch basin", "Round top rim"],
  "features": ["Feature 1", "Feature 2"],
  "quantities": {},
  "spatialArrangements": [],
  "fastenersOrHardware": [],
  "tolerancesOrClearances": [],
  "printConsiderations": ["Print flat on base at Z=0"],
  "warnings": []
}`;

  try {
    const pass2Contents: any[] = [{
      text: `Convert the following authoritative Design Brief into hard numeric mechanical specifications and CAD design plan for: "${prompt}".

AUTHORITATIVE DESIGN BRIEF:
${JSON.stringify(pass1Json, null, 2)}
${knownRef ? `\n[KNOWN REFERENCE ITEM EVIDENCE: ${JSON.stringify(knownRef)}]` : ''}

Populate all dimensional fields, the full designPlan, the assumptionLedger with traceable rationale for every numeric decision, printOrientation, and carry through openQuestions.`,
    }];
    appendReferenceImagesToContents(pass2Contents, referenceImages);

    const pass2Res = await callGeminiWithResilience(ai, {
      purpose: 'design_spec',
      contents: pass2Contents,
      config: {
        systemInstruction: pass2SystemInstruction,
        responseMimeType: 'application/json',
      },
      enableThinking: true,
    });

    if (pass2Res.requestRecords) {
      accumulatedRecords.push(...pass2Res.requestRecords);
    }
    const pass2Json = JSON.parse(pass2Res.text);

    // ---------------------------------------------------------------------------
    // PASS 3: SELF-CRITIQUE (Consistency and geometric sanity review)
    // ---------------------------------------------------------------------------
    const pass3SystemInstruction = `You are a design review engineer. Find internal contradictions in this specification: cavities larger than their enclosing shell, wall thickness exceeding half the smallest outer dimension, features that cannot coexist, dimensions that contradict the stated reference object, unprintable geometry implied by the plan. Return the corrected spec. If nothing is wrong, return the spec unchanged with an empty issues array.

Output ONLY valid JSON with this schema:
{
  "issues": [
    {
      "severity": "blocking" | "warning",
      "field": "string",
      "problem": "string",
      "correctedValue": "any"
    }
  ],
  "revisedSpec": { /* full spec matching engineering spec schema with corrections applied */ }
}`;

    let finalSpec = pass2Json;
    let specIssues: any[] = [];

    try {
      const pass3Contents: any[] = [{
        text: `Perform a design review and consistency audit on this engineering specification for: "${prompt}".

ENGINEERING SPECIFICATION TO AUDIT:
${JSON.stringify(pass2Json, null, 2)}

Audit for internal contradictions, geometric impossibilities, cavity/shell dimension inversions, and printability flaws. Return { "issues": [...], "revisedSpec": {...} }.`,
      }];

      const pass3Res = await callGeminiWithResilience(ai, {
        purpose: 'spec_review',
        contents: pass3Contents,
        config: {
          systemInstruction: pass3SystemInstruction,
          responseMimeType: 'application/json',
        },
      });

      if (pass3Res.requestRecords) {
        accumulatedRecords.push(...pass3Res.requestRecords);
      }

      const pass3Json = JSON.parse(pass3Res.text);
      if (pass3Json?.revisedSpec && typeof pass3Json.revisedSpec === 'object' && Object.keys(pass3Json.revisedSpec).length > 0) {
        finalSpec = pass3Json.revisedSpec;
      }
      specIssues = Array.isArray(pass3Json?.issues) ? pass3Json.issues : [];
    } catch (p3Err: any) {
      console.warn('[extractRequirements] Pass 3 (Spec Review) failed, proceeding with Pass 2 spec:', p3Err?.message || p3Err);
      if (p3Err?.requestRecords && Array.isArray(p3Err.requestRecords)) {
        accumulatedRecords.push(...p3Err.requestRecords);
      }
      specIssues = [];
    }

    finalSpec.specReviewIssues = specIssues;

    // Carry through openQuestions from Pass 1 if Pass 2/Pass 3 dropped them
    if ((!finalSpec.openQuestions || finalSpec.openQuestions.length === 0) && pass1Json?.openQuestions && pass1Json.openQuestions.length > 0) {
      finalSpec.openQuestions = pass1Json.openQuestions;
    }

    // Carry through assumptionLedger from Pass 2 if revisedSpec dropped it
    if ((!finalSpec.assumptionLedger || finalSpec.assumptionLedger.length === 0) && pass2Json?.assumptionLedger && pass2Json.assumptionLedger.length > 0) {
      finalSpec.assumptionLedger = pass2Json.assumptionLedger;
    }

    // Carry through printOrientation from Pass 2 if revisedSpec dropped it
    if (!finalSpec.printOrientation && pass2Json?.printOrientation) {
      finalSpec.printOrientation = pass2Json.printOrientation;
    }

    // Apply deterministic classifier sanity validation
    const verifiedIntent = classifyPromptIntent(prompt, finalSpec);

    // Guard against false positive organic/hybrid classifications for functional objects
    if (verifiedIntent.classification === 'parametric' && finalSpec.classification !== 'parametric') {
      finalSpec.classification = 'parametric';
      finalSpec.isOrganicOnly = false;
      finalSpec.classificationReason = verifiedIntent.reason;
      finalSpec.classificationConfidence = verifiedIntent.confidence;
    } else {
      finalSpec.classification = finalSpec.classification || verifiedIntent.classification;
      finalSpec.classificationConfidence = finalSpec.classificationConfidence || verifiedIntent.confidence;
      finalSpec.classificationReason = finalSpec.classificationReason || verifiedIntent.reason;
    }

    finalSpec.primaryObject = finalSpec.primaryObject || verifiedIntent.primaryObject;
    finalSpec.functionalRequirements = finalSpec.functionalRequirements || verifiedIntent.functionalRequirements;
    finalSpec.decorativeRequirements = finalSpec.decorativeRequirements || verifiedIntent.decorativeRequirements;
    finalSpec.sculpturalRequirements = finalSpec.sculpturalRequirements || verifiedIntent.sculpturalRequirements;

    if (!finalSpec.referenceObject && knownRef) {
      finalSpec.referenceObject = knownRef;
    }
    if (finalSpec.referenceObject && knownRef && knownRef.name.toLowerCase() === finalSpec.referenceObject.name?.toLowerCase()) {
      finalSpec.referenceObject.confidence = 'verified';
    }

    // Ensure designPlan is populated
    if (!finalSpec.designPlan) {
      finalSpec.designPlan = {
        primaryObject: finalSpec.primaryObject || 'functional part',
        function: pass1Json?.userGoal || 'Functional manufactured 3D print model',
        targetUseCase: pass1Json?.useEnvironment || 'General everyday utility',
        inferredCategory: finalSpec.inferredCategory || 'PARAMETRIC_FUNCTIONAL',
        referenceObject: finalSpec.referenceObject || null,
        inferredDimensions: {
          width: finalSpec.overallDimensions?.width || 80,
          depth: finalSpec.overallDimensions?.depth || 80,
          height: finalSpec.overallDimensions?.height || 25,
        },
        criticalDimensions: finalSpec.referenceObject ? [`Fit clearance around ${finalSpec.referenceObject.name}`] : ['Wall thickness 3.0mm'],
        mountingStyle: finalSpec.mountingStyle || 'freestanding',
        structuralRequirements: ['Flat base at Z=0 for bed adhesion', 'Wall thickness 3.0mm'],
        ergonomicRequirements: ['Rounded outer corners'],
        aestheticRequirements: ['Clean CAD styling'],
        printConstraints: ['No unsupported overhangs steeper than 45°'],
        confidenceScore: finalSpec.specConfidence || 0.95,
        assumptions: finalSpec.designDecisions || ['Assumed standard 3.0mm wall thickness'],
        missingCriticalInfo: [],
        generationStrategy: 'Parametric CSG Construction',
        keyFeatures: finalSpec.features || ['Parametric functional geometry'],
      };
    }

    const modelsUsed = Array.from(new Set(accumulatedRecords.map((r: any) => r.model)));
    const actualModelUsed = getLastSuccessfulModel(accumulatedRecords) || PRIMARY_MODEL;
    const aiMetadata = {
      modelUsed: actualModelUsed,
      modelsUsed,
      totalModelCalls: accumulatedRecords.length,
      durationMs: Date.now() - startTime,
      requestRecords: accumulatedRecords,
    };

    return { requirements: finalSpec, aiMetadata };
  } catch (err: any) {
    console.warn('Requirements extraction parse error, using conservative fallback extractor:', err);
    if (err?.requestRecords && Array.isArray(err.requestRecords)) {
      accumulatedRecords.push(...err.requestRecords);
    }

    const isInches = /inch|in\b|"/i.test(prompt);
    const unitScale = isInches ? 25.4 : 1;

    const widthMatch = prompt.match(/(?:width|wide|w|length|long|l)[:\s]*(\d+(?:\.\d+)?)\s*(?:mm|cm|in|inch|")?/i);
    const heightMatch = prompt.match(/(?:height|tall|h|thickness|thick)[:\s]*(\d+(?:\.\d+)?)\s*(?:mm|cm|in|inch|")?/i);
    const depthMatch = prompt.match(/(?:depth|deep|d)[:\s]*(\d+(?:\.\d+)?)\s*(?:mm|cm|in|inch|")?/i);
    const dim3Match = prompt.match(/(\d+(?:\.\d+)?)\s*(?:mm|cm|in|inch|")?\s*[x×*]\s*(\d+(?:\.\d+)?)\s*(?:mm|cm|in|inch|")?\s*(?:[x×*]\s*(\d+(?:\.\d+)?))?/i);

    let w: number | null = null;
    let d: number | null = null;
    let h: number | null = null;

    if (dim3Match) {
      w = Number((parseFloat(dim3Match[1]) * unitScale).toFixed(2));
      d = Number((parseFloat(dim3Match[2]) * unitScale).toFixed(2));
      if (dim3Match[3]) {
        h = Number((parseFloat(dim3Match[3]) * unitScale).toFixed(2));
      }
    } else {
      if (widthMatch) w = Number((parseFloat(widthMatch[1]) * unitScale).toFixed(2));
      if (depthMatch) d = Number((parseFloat(depthMatch[1]) * unitScale).toFixed(2));
      if (heightMatch) h = Number((parseFloat(heightMatch[1]) * unitScale).toFixed(2));
    }

    const intent = baselineClassification;

    const fallbackReqs = {
      objectName: intent.primaryObject ? `${intent.primaryObject.toUpperCase()}` : prompt.slice(0, 35),
      primaryObject: intent.primaryObject,
      classification: intent.classification,
      classificationConfidence: intent.confidence,
      classificationReason: intent.reason,
      inferredCategory: 'PARAMETRIC_FUNCTIONAL',
      mountingStyle: 'freestanding',
      functionalRequirements: intent.functionalRequirements,
      decorativeRequirements: intent.decorativeRequirements,
      sculpturalRequirements: intent.sculpturalRequirements,
      isOrganicOnly: intent.classification === 'organic',
      units: isInches ? 'inches' : 'mm',
      overallDimensions: {
        width: w,
        depth: d,
        height: h,
        rawInput: prompt,
      },
      wallThicknessMm: 3.0,
      referenceObject: knownRef || (intent.referenceObject ? {
        name: intent.referenceObject,
        dimensions: { width: 80, depth: 80, height: 25 },
        confidence: 'estimated',
        clearanceMm: 2.0,
        sourceNote: 'Derived from user reference',
      } : null),
      designPlan: {
        primaryObject: intent.primaryObject || 'functional part',
        function: 'Functional manufactured 3D print model',
        targetUseCase: 'General everyday utility',
        inferredCategory: 'PARAMETRIC_FUNCTIONAL',
        referenceObject: knownRef || null,
        inferredDimensions: { width: w || 80, depth: d || 80, height: h || 25 },
        criticalDimensions: knownRef ? [`Fit clearance around ${knownRef.name}`] : ['Wall thickness 3.0mm'],
        mountingStyle: 'freestanding',
        structuralRequirements: ['Flat base at Z=0 for bed adhesion', 'Wall thickness 3.0mm'],
        ergonomicRequirements: ['Rounded outer corners'],
        aestheticRequirements: ['Clean CAD styling'],
        printConstraints: ['No unsupported overhangs steeper than 45°'],
        confidenceScore: 0.92,
        assumptions: ['Selected durable 3.0 mm wall thickness', 'Standard 2.0 mm fit clearance around reference boundaries'],
        missingCriticalInfo: [],
        generationStrategy: 'Parametric CSG Construction',
        keyFeatures: ['Parametric mechanical model based on: ' + prompt],
      },
      assumptionLedger: [
        {
          parameter: 'wallThickness',
          value: 3.0,
          unit: 'mm',
          basis: 'engineering_default',
          reasoning: 'Standard default durable wall thickness for FDM printing',
          confidence: 0.9,
          userEditable: true,
        },
      ],
      openQuestions: pass1Json?.openQuestions || [],
      printOrientation: {
        recommendedUpAxis: '+Z (base on print bed)',
        reasoning: 'Print flat at Z=0 to maximize bed adhesion without supports',
        supportsRequired: false,
        maxOverhangAngleDeg: 45,
      },
      specConfidence: 0.85,
      specReviewIssues: [],
      explicitRequirements: [prompt],
      designDecisions: [
        'Selected durable 3.0 mm wall thickness',
        'Standard 2.0 mm fit clearance around reference boundaries',
        'Optimized base geometry for flat build-plate adhesion at Z=0',
      ],
      suggestedImprovements: [
        'Round outer corners by 5mm',
        'Add drainage slots',
        'Add screw mounting holes',
      ],
      unspecifiedProperties: [
        ...(w === null ? ['Width not specified'] : []),
        ...(d === null ? ['Depth not specified'] : []),
        ...(h === null ? ['Height not specified'] : []),
      ],
      features: ['Parametric mechanical model based on: ' + prompt],
      quantities: {},
      spatialArrangements: [],
      fastenersOrHardware: [],
      tolerancesOrClearances: [],
      printConsiderations: ['Ensure base is flat at Z=0 for bed adhesion'],
      warnings: [],
    };

    const finalRecords = accumulatedRecords.length > 0 ? accumulatedRecords : (err?.requestRecords || []);
    const modelsUsed = Array.from(new Set(finalRecords.map((r: any) => r.model)));

    return {
      requirements: fallbackReqs,
      fallbackUsed: 'deterministic',
      aiMetadata: {
        modelUsed: getLastSuccessfulModel(finalRecords) || undefined,
        modelsUsed,
        totalModelCalls: finalRecords.length,
        durationMs: Date.now() - startTime,
        requestRecords: finalRecords,
      },
    };
  }
}


export function registerExtractRequirements(app: Express, ai: GoogleGenAI) {
  app.post('/api/extract-requirements', async (req, res) => {
    const { prompt, referenceImages = [] } = req.body;
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({
        error: 'Prompt string is required',
        errorCategory: 'INVALID_REQUEST',
        statusCode: 400,
      });
    }
  
    const aiClient = ai || getGeminiClient();
    if (!aiClient) {
      return res.status(401).json({
        error: 'Invalid or missing Gemini API credential.',
        errorCategory: 'AUTH_ERROR',
        technicalDetails: 'GEMINI_API_KEY environment variable is not set.',
        statusCode: 401,
      });
    }
  
    try {
      const extraction = await extractRequirements(prompt, aiClient, referenceImages);
      return res.json({
        requirements: extraction.requirements,
        diagnostics: {
          modelUsed: extraction.aiMetadata.modelUsed,
          modelsUsed: extraction.aiMetadata.modelsUsed,
          aiCallsMade: extraction.aiMetadata.totalModelCalls,
          requestRecords: extraction.aiMetadata.requestRecords,
          durationMs: extraction.aiMetadata.durationMs,
        },
      });
    } catch (err: any) {
      console.error('Extract requirements error:', err);
      const cleaned = cleanErrorMessage(err);
      return res.status(cleaned.statusCode).json({
        error: cleaned.message,
        errorCategory: cleaned.errorCategory,
        technicalDetails: cleaned.technicalDetails,
        statusCode: cleaned.statusCode,
        diagnostics: getErrorDiagnostics(err),
      });
    }
  });

}
