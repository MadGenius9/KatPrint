import type { Express } from 'express';
import type { GoogleGenAI } from '@google/genai';
import { summarizeCadSemanticStructure } from '../../src/features/featurePlanner';
import { DesignIntentAuditSchema } from '../../src/ai/schemas';
import type {
  DesignSpecification,
  ProjectDesignState,
  ProjectReferenceImage,
  SemanticFeaturePlan,
  ReferenceImageObservation,
  DesignIntentAudit,
  RequirementCoverageReport,
} from '../../src/types';
import type { SemanticFeatureModel } from '../../src/features/featureTypes';
import type { GeometryMeasurements } from '../cad/sandbox';
import {
  callGeminiWithResilience,
  cleanErrorMessage,
  getErrorDiagnostics,
  getGeminiClient,
  AIRequestRecord,
} from '../gemini/client';
import { appendReferenceImagesToContents } from '../cad/shared';

export async function auditDesignIntentAI(
  ai: GoogleGenAI,
  options: {
    prompt: string;
    code: string;
    measurements: GeometryMeasurements;
    spec?: DesignSpecification;
    featureModel?: SemanticFeatureModel;
    designState?: ProjectDesignState;
    referenceImages?: ProjectReferenceImage[];
    semanticFeaturePlan?: SemanticFeaturePlan;
    referenceImageObservations?: ReferenceImageObservation[];
  }
): Promise<{
  audit: DesignIntentAudit;
  coverageReport: RequirementCoverageReport;
  aiMetadata: {
    modelUsed: string;
    modelsUsed: string[];
    totalModelCalls: number;
    requestRecords: AIRequestRecord[];
    durationMs: number;
  };
}> {
  const { prompt, code, measurements, spec, featureModel, designState, referenceImages, semanticFeaturePlan, referenceImageObservations } = options;
  const startTime = Date.now();
  const requestRecords: AIRequestRecord[] = [];
  const modelsUsedSet = new Set<string>();

  const systemInstruction = `You are a Senior Metrology and Quality Assurance Engineer for Functional 3D CAD models.
Your task is to audit the generated 3D geometry and JSCAD structure against the user's design requirements, exact dimensions, semantic feature plan, and reference photos.

EVALUATION RULES:
1. Dimensional adherence: Compare requested width/depth/height against actual measurements (${measurements.dimensions.x.toFixed(1)} x ${measurements.dimensions.y.toFixed(1)} x ${measurements.dimensions.z.toFixed(1)} mm).
2. Requirement coverage: Check if all requested features (mounting holes, slots, drainage, cavities, ribs, fillets) are present in the code structure and geometry.
3. Printability & Integrity: Flat bottom, wall thickness, watertight manifoldness.
4. EVIDENCE-BASED SCORING: Do not fabricate success or guess passes without evidence. If a requirement cannot be verified, status is 'unknown'.
5. Return JSON conforming to the DesignIntentAudit schema.`;

  const codeSummary = summarizeCadSemanticStructure(code);

  const promptText = `DESIGN REQUEST: "${prompt}"

MEASURED GEOMETRY STATS:
- Dimensions (X x Y x Z): ${measurements.dimensions.x.toFixed(2)} x ${measurements.dimensions.y.toFixed(2)} x ${measurements.dimensions.z.toFixed(2)} mm
- Volume: ${(measurements.actualVolumeMm3 ?? measurements.volumeMm3 ?? 0).toFixed(1)} mm³
- Is Manifold: ${measurements.isManifold}
- Non-Manifold Edges: ${measurements.nonManifoldEdgeCount || 0}
- Min Z: ${measurements.boundingBox ? measurements.boundingBox[0][2] : 0} mm

DESIGN SPEC & INTENT STATE:
${JSON.stringify({
  spec,
  designState,
  semanticFeaturePlan: semanticFeaturePlan ? { objectSummary: semanticFeaturePlan.objectSummary, features: semanticFeaturePlan.features.map((f) => ({ id: f.id, type: f.type, label: f.label, purpose: f.purpose, parameters: f.parameters })) } : undefined,
  featureModelSummary: featureModel?.features.map((f) => ({ id: f.id, type: f.type, label: f.label })),
  referenceImageObservations,
}, null, 2)}

STRUCTURED JSCAD CODE SEMANTIC SUMMARY:
${codeSummary}

Perform the evidence-based metrology audit and return the structured JSON report.`;

  const contents: any[] = [{ text: promptText }];
  appendReferenceImagesToContents(contents, referenceImages || []);

  const result = await callGeminiWithResilience(ai, {
    purpose: 'design_intent_audit',
    contents,
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: DesignIntentAuditSchema,
    },
    enableThinking: true,
  });

  result.requestRecords.forEach((r) => {
    modelsUsedSet.add(r.model);
    requestRecords.push(r);
  });

  let parsed: any = null;
  try {
    const text = result.text.trim().replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
    parsed = JSON.parse(text);
  } catch (err) {
    parsed = null;
  }

  let audit: DesignIntentAudit;
  if (parsed?.audit && typeof parsed.audit === 'object') {
    const rawAudit = parsed.audit;
    const rawVerdict = String(rawAudit.verdict || '').toLowerCase();
    const verdict: 'pass' | 'needs_repair' | 'fail' | 'unknown' =
      rawVerdict === 'pass' || rawVerdict === 'needs_repair' || rawVerdict === 'fail'
        ? rawVerdict
        : 'unknown';

    audit = {
      overallScore: typeof rawAudit.overallScore === 'number' && !isNaN(rawAudit.overallScore) ? rawAudit.overallScore : null,
      verdict,
      summary: typeof rawAudit.summary === 'string' ? rawAudit.summary : 'Design intent audit evaluated.',
      evaluatedRequirements: Array.isArray(rawAudit.evaluatedRequirements) ? rawAudit.evaluatedRequirements : [],
      defects: Array.isArray(rawAudit.defects) ? rawAudit.defects : [],
      missingFeatures: Array.isArray(rawAudit.missingFeatures) ? rawAudit.missingFeatures : [],
      dimensionalDrift: Array.isArray(rawAudit.dimensionalDrift) ? rawAudit.dimensionalDrift : [],
      aestheticCritique: typeof rawAudit.aestheticCritique === 'string' ? rawAudit.aestheticCritique : 'No aesthetic critique provided.',
    };
  } else {
    audit = {
      overallScore: null,
      verdict: 'unknown',
      summary: 'Design intent audit could not be evaluated.',
      evaluatedRequirements: [],
      defects: [],
      missingFeatures: [],
      dimensionalDrift: [],
      aestheticCritique: 'Audit unavailable',
    };
  }

  let coverageReport: RequirementCoverageReport;
  if (parsed?.coverageReport && typeof parsed.coverageReport === 'object') {
    const rawCov = parsed.coverageReport;
    coverageReport = {
      items: Array.isArray(rawCov.items) ? rawCov.items : [],
      coveragePercent: typeof rawCov.coveragePercent === 'number' && !isNaN(rawCov.coveragePercent) ? rawCov.coveragePercent : null,
      unmetCriticalRequirements: Array.isArray(rawCov.unmetCriticalRequirements) ? rawCov.unmetCriticalRequirements : [],
      summary: typeof rawCov.summary === 'string' ? rawCov.summary : 'Requirement coverage report generated.',
    };
  } else {
    coverageReport = {
      items: [],
      coveragePercent: null,
      unmetCriticalRequirements: [],
      summary: 'Requirement coverage could not be evaluated.',
    };
  }

  return {
    audit,
    coverageReport,
    aiMetadata: {
      modelUsed: result.model,
      modelsUsed: Array.from(modelsUsedSet),
      totalModelCalls: result.attempts,
      requestRecords,
      durationMs: Date.now() - startTime,
    },
  };
}



export function registerAuditDesignIntent(app: Express, ai: GoogleGenAI) {
  app.post('/api/audit-design-intent', async (req, res) => {
    const {
      prompt,
      code,
      measurements,
      spec,
      featureModel,
      designState,
      referenceImages = [],
    } = req.body;
  
    if (!code || !measurements) {
      return res.status(400).json({
        error: 'Code and measurements are required for design intent audit',
        errorCategory: 'INVALID_REQUEST',
        statusCode: 400,
      });
    }
  
    const aiClient = ai || getGeminiClient();
    if (!aiClient) {
      return res.status(401).json({
        error: 'Invalid or missing Gemini API credential.',
        errorCategory: 'AUTH_ERROR',
        technicalDetails: 'GEMINI_API_KEY environment variable is not set.',
        statusCode: 401,
      });
    }
  
    try {
    const result = await auditDesignIntentAI(aiClient, {
        prompt: prompt || '3D Model',
        code,
        measurements,
        spec,
        featureModel,
        designState,
        referenceImages,
      });
  
      return res.json({
        audit: result.audit,
        coverageReport: result.coverageReport,
        diagnostics: {
          modelUsed: result.aiMetadata.modelUsed,
          modelsUsed: result.aiMetadata.modelsUsed,
          aiCallsMade: result.aiMetadata.totalModelCalls,
          requestRecords: result.aiMetadata.requestRecords,
          durationMs: result.aiMetadata.durationMs,
        },
      });
    } catch (err: any) {
      console.error('Audit design intent error:', err);
      const cleaned = cleanErrorMessage(err);
      return res.status(cleaned.statusCode).json({
        error: cleaned.message,
        errorCategory: cleaned.errorCategory,
        technicalDetails: cleaned.technicalDetails,
        statusCode: cleaned.statusCode,
        diagnostics: getErrorDiagnostics(err),
      });
    }
  });

}
