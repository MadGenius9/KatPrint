import type { Express } from 'express';
import type { GoogleGenAI } from '@google/genai';
import {
  getFeatureRegistrySummary,
} from '../../src/features/featureRegistry';
import {
  normalizeSemanticPlan,
  scoreSemanticFeaturePlan,
} from '../../src/features/featurePlanner';
import {
  SemanticPlanRepairSchema,
} from '../../src/ai/schemas';
import type {
  SemanticFeaturePlan,
  DesignSpecification,
  ProjectDesignState,
  ReferenceImageObservation,
} from '../../src/types';
import {
  callGeminiWithResilience,
  cleanErrorMessage,
  getErrorDiagnostics,
  getGeminiClient,
  AIRequestRecord,
} from '../gemini/client';

export async function repairSemanticPlanAI(
  ai: GoogleGenAI,
  options: {
    prompt: string;
    currentPlan: SemanticFeaturePlan;
    unresolvedCriticalRequirements: string[];
    spec?: DesignSpecification;
    projectDesignState?: ProjectDesignState;
    referenceImageObservations?: ReferenceImageObservation[];
  }
): Promise<{
  repairedPlan: SemanticFeaturePlan;
  modificationsMade: string[];
  resolvedCriticalRequirements: string[];
  unresolvableCriticalRequirements: string[];
  clarificationNeeded?: string;
  aiMetadata: {
    modelUsed: string;
    modelsUsed: string[];
    totalModelCalls: number;
    requestRecords: AIRequestRecord[];
    durationMs: number;
  };
}> {
  const { prompt, currentPlan, unresolvedCriticalRequirements, spec, projectDesignState, referenceImageObservations } = options;
  const startTime = Date.now();
  const requestRecords: AIRequestRecord[] = [];
  const modelsUsedSet = new Set<string>();

  const registrySummary = getFeatureRegistrySummary();

  const systemInstruction = `You are a Principal Mechanical CAD Architect specializing in Semantic Feature Plan Repair.
Your job is to targetedly repair an existing Semantic Feature Plan to satisfy all unresolved critical requirements, without rewriting the entire plan from scratch.

${registrySummary}

REPAIR OBJECTIVES:
1. Review the UNRESOLVED CRITICAL REQUIREMENTS and CURRENT PLAN.
2. Add missing functional features (holes, slots, bosses, clearances, ribs, etc.) or adjust existing parameter values/types to directly satisfy the requirements.
3. Keep existing valid features and their IDs intact where possible.
4. List the exact modifications made and which critical requirements were resolved.
5. Return JSON conforming to the SemanticPlanRepair schema.`;

  const promptText = `USER DESIGN REQUEST: "${prompt}"

CURRENT SEMANTIC FEATURE PLAN:
${JSON.stringify(currentPlan, null, 2)}

UNRESOLVED CRITICAL REQUIREMENTS TO FIX:
${JSON.stringify(unresolvedCriticalRequirements, null, 2)}

DESIGN SPECIFICATION & CONSTRAINTS:
${JSON.stringify({ spec, projectDesignState, referenceImageObservations }, null, 2)}

Repair the semantic plan and output the structured JSON response.`;

  const result = await callGeminiWithResilience(ai, {
    purpose: 'semantic_plan_repair',
    contents: [{ text: promptText }],
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: SemanticPlanRepairSchema,
    },
    enableThinking: true,
  });

  result.requestRecords.forEach((r) => {
    modelsUsedSet.add(r.model);
    requestRecords.push(r);
  });

  let rawJson: any = null;
  try {
    const text = result.text.trim().replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
    rawJson = JSON.parse(text);
  } catch (err) {
    console.warn('Failed to parse semantic plan repair JSON:', err);
  }

  let repairedPlan: SemanticFeaturePlan = currentPlan;
  let modificationsMade: string[] = [];
  let resolvedCriticalRequirements: string[] = [];
  let unresolvableCriticalRequirements: string[] = [];
  let clarificationNeeded: string | undefined = undefined;

  if (rawJson?.repairedPlan && Array.isArray(rawJson.repairedPlan.features) && rawJson.repairedPlan.features.length > 0) {
    const normalized = normalizeSemanticPlan(rawJson.repairedPlan);
    if (normalized && normalized.features.length > 0) {
      repairedPlan = normalized;
      const effectiveSpec = spec || ({ primaryObject: prompt, explicitDimensions: [], requiredFeatures: [] } as any);
      const scoreRes = scoreSemanticFeaturePlan(repairedPlan, effectiveSpec, prompt, projectDesignState);
      repairedPlan.score = scoreRes.score;
      repairedPlan.scoreBreakdown = scoreRes.breakdown as any;

      modificationsMade = Array.isArray(rawJson.modificationsMade) ? rawJson.modificationsMade : ['Repaired semantic plan features'];
      resolvedCriticalRequirements = Array.isArray(rawJson.resolvedCriticalRequirements) ? rawJson.resolvedCriticalRequirements : unresolvedCriticalRequirements;
      unresolvableCriticalRequirements = Array.isArray(rawJson.unresolvableCriticalRequirements) ? rawJson.unresolvableCriticalRequirements : [];
      clarificationNeeded = typeof rawJson.clarificationNeeded === 'string' ? rawJson.clarificationNeeded : undefined;
    } else {
      modificationsMade = ['Repaired plan normalization failed; original plan retained.'];
      unresolvableCriticalRequirements = unresolvedCriticalRequirements;
    }
  } else {
    modificationsMade = ['No automated repair could be synthesized; original plan retained.'];
    unresolvableCriticalRequirements = unresolvedCriticalRequirements;
  }

  return {
    repairedPlan,
    modificationsMade,
    resolvedCriticalRequirements,
    unresolvableCriticalRequirements,
    clarificationNeeded,
    aiMetadata: {
      modelUsed: result.model,
      modelsUsed: Array.from(modelsUsedSet),
      totalModelCalls: result.attempts,
      requestRecords,
      durationMs: Date.now() - startTime,
    },
  };
}


export function registerRepairSemanticPlan(app: Express, ai: GoogleGenAI) {
  app.post('/api/repair-semantic-plan', async (req, res) => {
    const {
      prompt,
      currentPlan,
      unresolvedCriticalRequirements = [],
      spec,
      projectDesignState,
      referenceImageObservations = [],
    } = req.body;
  
    if (!currentPlan || !Array.isArray(unresolvedCriticalRequirements)) {
      return res.status(400).json({
        error: 'currentPlan and unresolvedCriticalRequirements are required for semantic plan repair',
        errorCategory: 'INVALID_REQUEST',
        statusCode: 400,
      });
    }
  
    const aiClient = ai || getGeminiClient();
    if (!aiClient) {
      return res.status(401).json({
        error: 'Invalid or missing Gemini API credential.',
        errorCategory: 'AUTH_ERROR',
        technicalDetails: 'GEMINI_API_KEY environment variable is not set.',
        statusCode: 401,
      });
    }
  
    try {
    const result = await repairSemanticPlanAI(aiClient, {
        prompt: prompt || '3D Model',
        currentPlan,
        unresolvedCriticalRequirements,
        spec,
        projectDesignState,
        referenceImageObservations,
      });
  
      return res.json({
        repairedPlan: result.repairedPlan,
        modificationsMade: result.modificationsMade,
        resolvedCriticalRequirements: result.resolvedCriticalRequirements,
        unresolvableCriticalRequirements: result.unresolvableCriticalRequirements,
        clarificationNeeded: result.clarificationNeeded,
        diagnostics: {
          modelUsed: result.aiMetadata.modelUsed,
          modelsUsed: result.aiMetadata.modelsUsed,
          aiCallsMade: result.aiMetadata.totalModelCalls,
          requestRecords: result.aiMetadata.requestRecords,
          durationMs: result.aiMetadata.durationMs,
        },
      });
    } catch (err: any) {
      console.error('Repair semantic plan error:', err);
      const cleaned = cleanErrorMessage(err);
      return res.status(cleaned.statusCode).json({
        error: cleaned.message,
        errorCategory: cleaned.errorCategory,
        technicalDetails: cleaned.technicalDetails,
        statusCode: cleaned.statusCode,
        diagnostics: getErrorDiagnostics(err),
      });
    }
  });

}
