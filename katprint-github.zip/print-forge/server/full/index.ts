import type { Express } from 'express';
import type { GoogleGenAI } from '@google/genai';
import { registerExtractRequirements } from './extractRequirements';
import { registerAnalyzeReferenceImages } from './analyzeReferenceImages';
import { registerPlanSemanticFeatures } from './planSemanticFeatures';
import { registerRepairSemanticPlan } from './repairSemanticPlan';
import { registerReviewFidelity } from './reviewFidelity';
import { registerAuditDesignIntent } from './auditDesignIntent';
import { registerUpdateDesignIntent } from './updateDesignIntent';
import { registerGenerateConcepts } from './generateConcepts';

export function registerFullPipeline(app: Express, ai?: GoogleGenAI) {
  registerExtractRequirements(app, ai);
  registerAnalyzeReferenceImages(app, ai);
  registerPlanSemanticFeatures(app, ai);
  registerRepairSemanticPlan(app, ai);
  registerReviewFidelity(app, ai);
  registerAuditDesignIntent(app, ai);
  registerUpdateDesignIntent(app, ai);
  registerGenerateConcepts(app, ai);
}
