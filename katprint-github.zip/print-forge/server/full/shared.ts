import type { Express } from 'express';
import type { GoogleGenAI } from '@google/genai';

export type PipelineRegisterFn = (app: Express, ai: GoogleGenAI) => void;
