import type { Express } from 'express';
import type { GoogleGenAI } from '@google/genai';
import {
  callGeminiWithResilience,
  getLastSuccessfulModel,
  cleanErrorMessage,
  getErrorDiagnostics,
  getGeminiClient,
} from '../gemini/client';

export function registerReviewFidelity(app: Express, ai: GoogleGenAI) {
  app.post('/api/review-fidelity', async (req, res) => {
    const { specification, code, geometryStats, deterministicChecks, views, purpose } = req.body;
    if (!code) {
      return res.status(400).json({ error: 'JSCAD code is required for fidelity review' });
    }

    const validPurpose = (purpose === 'final_visual_review' || purpose === 'visual_fidelity_review')
      ? purpose
      : 'visual_fidelity_review';

    const aiClient = ai || getGeminiClient();
    if (!aiClient) {
      return res.status(401).json({
        error: 'Invalid or missing Gemini API credential.',
        errorCategory: 'AUTH_ERROR',
        statusCode: 401,
      });
    }

    try {
      const spec = specification || {
        primaryObject: 'Mechanical Component',
        intendedFunction: 'Functional printed part',
        requiredFeatures: [],
      };

      const systemInstruction = `You are a Lead Mechanical & Industrial Design Quality Inspector evaluating 3D printable CAD models.
You compare the structured Design Specification, geometry stats, and multi-view rendered images against the generated JSCAD source script.

REVIEW MANDATES:
1. Object Integrity: Does the model actually function as the requested "${spec.primaryObject}"?
2. Feature Verification: Are all required functional features (drainage slots, mounting holes, retaining lips, cable slots, ribs) present and properly dimensioned?
3. Usability & Ergonomics: Does the part allow easy physical access/insertion without catching or jamming?
4. Manufacturing & FDM Printability: Is the base flat at Z=0? Are overhangs reasonable without requiring destructive supports?
5. Honest Scoring: If critical features or dimensions are missing or flawed, score low and set requiresRepair: true.

Output strictly valid JSON matching this schema:
{
  "overallScore": number (0-100),
  "verdict": "PASS" | "NEEDS_MINOR_CORRECTION" | "NEEDS_MAJOR_CORRECTION" | "INVALID_DESIGN",
  "scoreBreakdown": {
    "intentMatch": number (0-100),
    "dimensions": number (0-100),
    "requiredFeatures": number (0-100),
    "printability": number (0-100),
    "visualMatch": number (0-100)
  },
  "verifiedRequirements": ["Feature or requirement 1 that succeeded", "Feature 2"],
  "missingFeatures": ["Missing feature 1"],
  "visualMismatch": ["Visual defect description 1"],
  "problems": [
    {
      "requirement": "Name of requirement or feature",
      "issue": "Specific failure or omission description",
      "severity": "critical" | "important" | "minor",
      "affectedFeatureId": "feat_xxx",
      "recommendedCorrection": "Specific CAD fix (e.g. increase clearance to 3mm, add 4mm wide slot)"
    }
  ],
  "requiresRepair": boolean,
  "summary": "Concise factual 2-sentence review summary"
}`;

      const textPrompt = `DESIGN SPECIFICATION:
${JSON.stringify(spec, null, 2)}

MEASURED GEOMETRY STATS:
${JSON.stringify(geometryStats || {}, null, 2)}

DETERMINISTIC CHECKS:
${JSON.stringify(deterministicChecks || [], null, 2)}

GENERATED JSCAD SOURCE CODE:
\`\`\`js
${code}
\`\`\`

Perform the visual and mechanical fidelity review.`;

      const contents: any[] = [{ text: textPrompt }];

      // Attach rendered snapshot views if provided
      if (views) {
        for (const [viewKey, dataUrl] of Object.entries(views)) {
          if (typeof dataUrl === 'string' && dataUrl.startsWith('data:image/')) {
            const match = dataUrl.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
            if (match) {
              contents.push({
                inlineData: {
                  mimeType: match[1],
                  data: match[2],
                },
              });
            }
          }
        }
      }

      const geminiRes = await callGeminiWithResilience(aiClient, {
        purpose: validPurpose,
        contents,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
        },
      });

      const parsed = JSON.parse(geminiRes.text);
      parsed.designSpecification = spec;
      if (typeof parsed.requiresRepair === 'undefined') {
        parsed.requiresRepair = parsed.correctionNeeded ?? (parsed.verdict === 'NEEDS_MINOR_CORRECTION' || parsed.verdict === 'NEEDS_MAJOR_CORRECTION');
      }
      if (!Array.isArray(parsed.verifiedRequirements)) {
        parsed.verifiedRequirements = parsed.verifiedChecks || [];
      }
      if (!Array.isArray(parsed.missingFeatures)) {
        parsed.missingFeatures = [];
      }
      if (!Array.isArray(parsed.visualMismatch)) {
        parsed.visualMismatch = [];
      }
      if (!Array.isArray(parsed.problems)) {
        parsed.problems = [];
      }

      const actualModelUsed = getLastSuccessfulModel(geminiRes.requestRecords) || geminiRes.model;
      const modelsUsed = Array.from(new Set(geminiRes.requestRecords.map((r: any) => r.model)));

      return res.json({
        review: parsed,
        modelUsed: actualModelUsed,
        durationMs: geminiRes.durationMs,
        diagnostics: {
          modelUsed: actualModelUsed,
          modelsUsed,
          aiCallsMade: geminiRes.attempts,
          requestRecords: geminiRes.requestRecords,
          durationMs: geminiRes.durationMs,
        },
      });
    } catch (err: any) {
      console.error('Fidelity review error:', err);
      const cleaned = cleanErrorMessage(err);
      return res.status(cleaned.statusCode).json({
        error: cleaned.message,
        errorCategory: cleaned.errorCategory,
        statusCode: cleaned.statusCode,
        diagnostics: getErrorDiagnostics(err),
      });
    }
  });
}
