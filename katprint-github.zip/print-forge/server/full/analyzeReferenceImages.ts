import type { Express } from 'express';
import type { GoogleGenAI } from '@google/genai';
import type { ProjectReferenceImage } from '../../src/types';
import type { ReferenceImageObservation } from '../../src/types';
import { ReferenceImageObservationsSchema } from '../../src/ai/schemas';
import {
  PRIMARY_MODEL,
  callGeminiWithResilience,
  cleanErrorMessage,
  getErrorDiagnostics,
  getGeminiClient,
  AIRequestRecord,
} from '../gemini/client';
import { appendReferenceImagesToContents } from '../cad/shared';

export async function analyzeReferenceImagesAI(
  ai: GoogleGenAI,
  images: ProjectReferenceImage[],
  prompt = ''
): Promise<{
  observations: ReferenceImageObservation[];
  aiMetadata: {
    modelUsed: string;
    modelsUsed: string[];
    totalModelCalls: number;
    requestRecords: AIRequestRecord[];
    durationMs: number;
  };
}> {
  const startTime = Date.now();
  const requestRecords: AIRequestRecord[] = [];
  const modelsUsedSet = new Set<string>();

  if (!images || images.length === 0) {
    return {
      observations: [],
      aiMetadata: {
        modelUsed: PRIMARY_MODEL,
        modelsUsed: [],
        totalModelCalls: 0,
        requestRecords: [],
        durationMs: 0,
      },
    };
  }

  const systemInstruction = `You are a Senior Computer Vision & Reverse Engineering Metrologist.
Examine the user's reference photos to extract physical and geometric engineering observations for 3D modeling.

Extract for each image:
- observedFeatures (e.g. "curved bottom scoop", "4 screw holes on 60mm pitch", "ribbed side grip")
- relativeProportions (e.g. "width to height ratio approximately 2.5:1", "wall thickness is ~5% of outer width")
- visibleInterfaces (e.g. "countersunk screw holes", "USB-C port cutout")
- knownMeasurements (with estimated or confirmed valueMm)
- unknownMeasurements
- confidence (0.0 to 1.0)

Return JSON conforming to ReferenceImageObservations schema.`;

  const contents: any[] = [{ text: `Analyze the following reference images for 3D CAD design request: "${prompt}"` }];
  appendReferenceImagesToContents(contents, images);

  const result = await callGeminiWithResilience(ai, {
    purpose: 'reference_image_analysis',
    contents,
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: ReferenceImageObservationsSchema,
    },
    enableThinking: true,
  });

  result.requestRecords.forEach((r) => {
    modelsUsedSet.add(r.model);
    requestRecords.push(r);
  });

  let observations: ReferenceImageObservation[] = [];
  try {
    const text = result.text.trim().replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
    const parsed = JSON.parse(text);
    if (Array.isArray(parsed)) {
      observations = parsed;
    } else if (parsed && Array.isArray(parsed.observations)) {
      observations = parsed.observations;
    }
  } catch (e) {
    observations = [];
  }

  return {
    observations,
    aiMetadata: {
      modelUsed: result.model,
      modelsUsed: Array.from(modelsUsedSet),
      totalModelCalls: result.attempts,
      requestRecords,
      durationMs: Date.now() - startTime,
    },
  };
}

export function registerAnalyzeReferenceImages(app: Express, ai: GoogleGenAI) {
  app.post('/api/analyze-reference-images', async (req, res) => {
    const { referenceImages = [], prompt = '' } = req.body;

    const aiClient = ai || getGeminiClient();
    if (!aiClient) {
      return res.status(401).json({
        error: 'Invalid or missing Gemini API credential.',
        errorCategory: 'AUTH_ERROR',
        technicalDetails: 'GEMINI_API_KEY environment variable is not set.',
        statusCode: 401,
      });
    }

    try {
      const result = await analyzeReferenceImagesAI(aiClient, referenceImages, prompt);
      return res.json({
        observations: result.observations,
        diagnostics: {
          modelUsed: result.aiMetadata.modelUsed,
          modelsUsed: result.aiMetadata.modelsUsed,
          aiCallsMade: result.aiMetadata.totalModelCalls,
          requestRecords: result.aiMetadata.requestRecords,
          durationMs: result.aiMetadata.durationMs,
        },
      });
    } catch (err: any) {
      console.error('Analyze reference images error:', err);
      const cleaned = cleanErrorMessage(err);
      return res.status(cleaned.statusCode).json({
        error: cleaned.message,
        errorCategory: cleaned.errorCategory,
        technicalDetails: cleaned.technicalDetails,
        statusCode: cleaned.statusCode,
        diagnostics: getErrorDiagnostics(err),
      });
    }
  });
}
