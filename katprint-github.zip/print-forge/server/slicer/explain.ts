import type { Express } from 'express';
import { getGeminiClient, callGeminiWithResilience } from '../gemini/client';

export function registerExplain(app: Express) {
  // -------------------------------------------------------------
  // POST /api/explain-slicer
  // -------------------------------------------------------------
  app.post('/api/explain-slicer', async (req, res) => {
    try {
      const { settings, geometry, printer, filament, mustHoldLiquid, printabilityReport } = req.body;
      const ai = getGeminiClient();

      if (ai) {
        try {
          const printabilitySection = printabilityReport
            ? `
Deterministic Printability Analysis:
- Printability Score: ${printabilityReport.score}/100 (${printabilityReport.verdict})
- Overhangs: ${printabilityReport.overhangs.totalAreaMm2} mm² (${(printabilityReport.overhangs.ratio * 100).toFixed(1)}% of surface), worst angle ${printabilityReport.overhangs.worstAngleDeg}°, classification: ${printabilityReport.overhangs.classification}
- Unsupported Mid-Air Islands: ${printabilityReport.islands.length}
- Thin Walls: min thickness ${printabilityReport.thinWalls.minWallThicknessMm} mm (threshold ${printabilityReport.thinWalls.thresholdMm} mm, hasThinWalls: ${printabilityReport.thinWalls.hasThinWalls})
- Bridge Spans: ${printabilityReport.bridges.length > 0 ? `${printabilityReport.bridges[0].spanMm} mm (${printabilityReport.bridges[0].status})` : 'None'}
- First Layer Bed Contact: ${printabilityReport.firstLayer.areaMm2} mm² (status: ${printabilityReport.firstLayer.status}, needsBrim: ${printabilityReport.firstLayer.needsBrim}, needsRaft: ${printabilityReport.firstLayer.needsRaft})
- Key Recommendations: ${printabilityReport.recommendations?.map((r: any) => r.message).join(' | ') || 'None'}
`
            : '';

          const promptText = `
Model Geometry:
- Dimensions (XYZ): ${geometry.dimensions.x} x ${geometry.dimensions.y} x ${geometry.dimensions.z} mm
- Volume: ${geometry.volumeCm3} cm³ (${geometry.volumeMm3} mm³)
- Surface Area: ${geometry.surfaceAreaMm2} mm²
- Estimated Weight: ${geometry.estimatedWeightGrams} g
- Height-to-Width Aspect Ratio: ${geometry.heightToWidthRatio}
- Overhang Ratio: ${(geometry.overhangRatio * 100).toFixed(1)}% (Steep overhangs present: ${geometry.hasSteepOverhangs})
- Manifold: ${geometry.isManifold}
- Must Hold Liquid / Watertight Mode: ${mustHoldLiquid ? 'YES' : 'NO'}
${printabilitySection}
Target Printer:
- Model: ${printer.name}
- Build Volume: ${printer.buildVolume.x}x${printer.buildVolume.y}x${printer.buildVolume.z} mm
- Extruder Kinematics: ${printer.driveType.toUpperCase()} Drive
- Nozzle: ${printer.nozzleDiameter} mm
- Max Volumetric Flow: ${printer.maxVolumetricFlow} mm³/s
- Enclosed: ${printer.isEnclosed ? 'Yes' : 'No'}

Selected Filament:
- Material: ${filament.name}
- Recommended Temps: Nozzle ${filament.nozzleTempRange[0]}-${filament.nozzleTempRange[1]}°C, Bed ${filament.bedTempRange[0]}-${filament.bedTempRange[1]}°C
- Warp Risk: ${filament.warpRisk}
- Shrinkage: ${filament.shrinkagePercent}%

Calculated Slicer Overrides:
- Nozzle Temp: ${settings.nozzleTempFirstLayer}°C (Layer 1), ${settings.nozzleTempOtherLayers}°C (Other)
- Bed Temp: ${settings.bedTemp}°C
- Layer Height: ${settings.layerHeight} mm (First: ${settings.firstLayerHeight} mm)
- Perimeters / Wall Loops: ${settings.wallLoops}
- Infill: ${settings.infillPercent}% ${settings.infillPattern}
- Outer Wall Speed: ${settings.outerWallSpeed} mm/s | Inner Wall: ${settings.innerWallSpeed} mm/s | Infill: ${settings.infillSpeed} mm/s
- Cooling Fan: ${settings.fanPercent}%
- Retraction: ${settings.retractionDistance} mm @ ${settings.retractionSpeed} mm/s
- Supports: ${settings.supportsEnabled ? `Enabled (${settings.supportType})` : 'None'}
- Brim: ${settings.brimEnabled ? `Enabled (${settings.brimWidthMm} mm)` : 'None'}
- Flow Compensation: ${settings.flowCompensation}x
- Estimated Print Time: ${settings.estimatedPrintTimeMinutes} mins
`;

          const systemInstruction = `You are a world-class additive manufacturing engineer. Explain concisely in plain, professional engineering language WHY these specific slicer parameters were derived for this geometry, material, kinematics, and measured printability characteristics.
Keep the explanation focused on:
1. Thermal bonding, layer heights, wall perimeters (especially if thin walls or liquid tightness are detected).
2. Kinematics, speed scaling, volumetric flow limits, and vibration dampening.
3. Bed adhesion (brims/rafts based on measured first layer area) and overhang support strategy.
Do NOT output greetings or fluff. Use 2 to 3 concise, highly informative paragraphs or bullet points with bold sub-headers.`;

          const geminiRes = await callGeminiWithResilience(ai, {
            purpose: 'explain-slicer',
            contents: promptText,
            config: {
              systemInstruction,
            },
          });

          if (geminiRes?.text) {
            return res.json({ explanation: geminiRes.text });
          }
        } catch (geminiErr: any) {
          console.warn('Gemini explanation fallback:', geminiErr?.message || geminiErr);
        }
      }

      const firstLayerDesc = printabilityReport?.firstLayer?.areaMm2
        ? `Measured bed contact area is ${printabilityReport.firstLayer.areaMm2}mm². `
        : '';
      const overhangDesc = printabilityReport?.overhangs?.totalAreaMm2
        ? `Measured overhang area is ${printabilityReport.overhangs.totalAreaMm2}mm² (${printabilityReport.overhangs.classification} overhang classification). `
        : '';

      const explanation = `**Thermal & Interlayer Fusion:**
Extruder is locked to ${settings.nozzleTempFirstLayer}°C on the initial layer and ${settings.nozzleTempOtherLayers}°C for continuous extrusion, mated with a ${settings.bedTemp}°C heated bed. With ${settings.wallLoops} perimeters and a ${settings.layerHeight} mm layer step (${settings.firstLayerHeight} mm initial), this guarantees superior layer-to-layer weld strength and hydrostatic integrity${mustHoldLiquid ? ' (watertight liquid containment mode fully active)' : ''}.

**Kinematics & Volumetric Flow Limits:**
Speed is balanced with outer perimeters at ${settings.outerWallSpeed} mm/s and infill at ${settings.infillSpeed} mm/s to adhere strictly beneath the ${printer.name}'s max volumetric threshold of ${printer.maxVolumetricFlow} mm³/s. Extrusion retraction is optimized for ${printer.driveType.toUpperCase()} kinematics at ${settings.retractionDistance} mm @ ${settings.retractionSpeed} mm/s to eliminate stringing and nozzle pressure buildup.

**Adhesion & Overhang Mitigation:**
${firstLayerDesc}${settings.brimEnabled ? `A ${settings.brimWidthMm} mm brim has been dynamically engaged to counteract the ${filament.shrinkagePercent}% thermal shrinkage rate of ${filament.name} and secure bed adhesion.` : 'Direct build-plate adhesion is sufficient for this geometry footprint.'} ${overhangDesc}${settings.supportsEnabled ? `Snug ${settings.supportType} supports are enabled to scaffold steep overhang angles without marring surface finish.` : 'Geometry contains self-supporting angles within the safe printable envelope.'}`;

      return res.json({ explanation });
    } catch (err: any) {
      console.error('Error in slicer explanation:', err);
      return res.status(500).json({ error: err?.message || 'Failed to explain slicer settings' });
    }
  });
}
