import type { Express } from 'express';
import type http from 'http';
import { WebSocketServer, WebSocket } from 'ws';

export interface SimulationState {
  active: boolean;
  status: 'idle' | 'preheating' | 'calibrating' | 'printing' | 'completed' | 'paused';
  progressPercent: number;
  currentLayer: number;
  totalLayers: number;
  nozzleTemp: number;
  targetNozzleTemp: number;
  bedTemp: number;
  targetBedTemp: number;
  fanSpeedPercent: number;
  printTimeElapsedSec: number;
  printTimeRemainingSec: number;
  currentSpeedMmS: number;
  flowRateMm3S: number;
  printerName: string;
  message: string;
}

export function registerTelemetry(app: Express, server: http.Server) {
  const wss = new WebSocketServer({ server, path: '/ws' });

  let activeSim: SimulationState = {
    active: false,
    status: 'idle',
    progressPercent: 0,
    currentLayer: 0,
    totalLayers: 320,
    nozzleTemp: 24,
    targetNozzleTemp: 0,
    bedTemp: 22,
    targetBedTemp: 0,
    fanSpeedPercent: 0,
    printTimeElapsedSec: 0,
    printTimeRemainingSec: 0,
    currentSpeedMmS: 0,
    flowRateMm3S: 0,
    printerName: 'Bambu Lab X1-Carbon',
    message: 'Printer standby. Ready for G-code transmission.',
  };

  let simInterval: NodeJS.Timeout | null = null;

  function broadcastTelemetry() {
    const payload = JSON.stringify({ type: 'telemetry', data: activeSim });
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
      }
    });
  }

  function startPrintSimulation(config: any) {
    if (simInterval) clearInterval(simInterval);

    activeSim = {
      active: true,
      status: 'preheating',
      progressPercent: 0,
      currentLayer: 0,
      totalLayers: Math.max(50, Math.round((config?.dimensions?.z || 100) / (config?.layerHeight || 0.2))),
      nozzleTemp: 24,
      targetNozzleTemp: config?.nozzleTemp || 220,
      bedTemp: 23,
      targetBedTemp: config?.bedTemp || 60,
      fanSpeedPercent: 0,
      printTimeElapsedSec: 0,
      printTimeRemainingSec: (config?.printTimeMinutes || 45) * 60,
      currentSpeedMmS: 0,
      flowRateMm3S: 0,
      printerName: config?.printerName || 'Bambu Lab X1-Carbon',
      message: 'Heating nozzle and heated bed to target extrusion temperatures...',
    };

    let tickCount = 0;
    simInterval = setInterval(() => {
      tickCount++;
      activeSim.printTimeElapsedSec += 2;

      if (activeSim.status === 'preheating') {
        activeSim.nozzleTemp = Math.min(
          activeSim.targetNozzleTemp,
          Math.round(activeSim.nozzleTemp + (activeSim.targetNozzleTemp - 24) * 0.08 + Math.random() * 4)
        );
        activeSim.bedTemp = Math.min(
          activeSim.targetBedTemp,
          Math.round(activeSim.bedTemp + (activeSim.targetBedTemp - 22) * 0.06 + Math.random() * 2)
        );

        if (activeSim.nozzleTemp >= activeSim.targetNozzleTemp - 1 && activeSim.bedTemp >= activeSim.targetBedTemp - 1) {
          activeSim.status = 'calibrating';
          activeSim.message = 'Performing auto bed leveling mesh and vibration resonance compensation...';
        }
      } else if (activeSim.status === 'calibrating') {
        if (tickCount > 10) {
          activeSim.status = 'printing';
          activeSim.fanSpeedPercent = config?.fanPercent || 100;
          activeSim.message = 'Printing First Layer with flow compensation active.';
        }
      } else if (activeSim.status === 'printing') {
        const increment = 100 / Math.max(30, activeSim.totalLayers * 0.4);
        activeSim.progressPercent = Math.min(100, Number((activeSim.progressPercent + increment).toFixed(1)));
        activeSim.currentLayer = Math.min(
          activeSim.totalLayers,
          Math.max(1, Math.floor((activeSim.progressPercent / 100) * activeSim.totalLayers))
        );
        activeSim.printTimeRemainingSec = Math.max(0, Math.round(activeSim.printTimeRemainingSec - 2.5));
        activeSim.currentSpeedMmS = Math.round((config?.outerWallSpeed || 150) + (Math.random() * 40 - 20));
        activeSim.flowRateMm3S = Number((12.5 + Math.sin(tickCount) * 3.2).toFixed(1));

        activeSim.nozzleTemp = activeSim.targetNozzleTemp + Math.round(Math.random() * 2 - 1);
        activeSim.bedTemp = activeSim.targetBedTemp + Math.round(Math.random() * 1 - 0.5);

        if (activeSim.progressPercent >= 100) {
          activeSim.status = 'completed';
          activeSim.progressPercent = 100;
          activeSim.currentSpeedMmS = 0;
          activeSim.flowRateMm3S = 0;
          activeSim.fanSpeedPercent = 0;
          activeSim.targetNozzleTemp = 0;
          activeSim.targetBedTemp = 0;
          activeSim.message = 'Print completed successfully. Cooling hotend and presenting build plate.';
          if (simInterval) clearInterval(simInterval);
        } else {
          activeSim.message = `Printing Layer ${activeSim.currentLayer} / ${activeSim.totalLayers} (${activeSim.progressPercent}%)`;
        }
      }

      broadcastTelemetry();
    }, 1000);
  }

  wss.on('connection', (ws) => {
    ws.send(JSON.stringify({ type: 'telemetry', data: activeSim }));

    ws.on('message', (messageRaw) => {
      try {
        const msg = JSON.parse(messageRaw.toString());
        if (msg.type === 'start_sim') {
          startPrintSimulation(msg.config);
        } else if (msg.type === 'cancel_sim') {
          if (simInterval) clearInterval(simInterval);
          activeSim.status = 'idle';
          activeSim.active = false;
          activeSim.progressPercent = 0;
          activeSim.targetNozzleTemp = 0;
          activeSim.targetBedTemp = 0;
          activeSim.currentSpeedMmS = 0;
          activeSim.flowRateMm3S = 0;
          activeSim.message = 'Print job cancelled. Extruder parked.';
          broadcastTelemetry();
        }
      } catch (e) {
        console.error('WS Error:', e);
      }
    });
  });
}
