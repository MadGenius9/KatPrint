import React from 'react';
import type * as THREE from 'three';
import {
  MessageSquare,
  Printer,
  History,
  Droplets,
} from 'lucide-react';
import { FILAMENTS } from '../../data/filaments';
import { hasMultiplePhysicalPieces, getPhysicalPieceCount } from '../../engine/stlExporter';
import { ProjectConversationPanel } from '../projects/ProjectConversationPanel';
import { FeatureInspector } from '../features/FeatureInspector';
import { MultiPartManager } from '../assembly/MultiPartManager';
import { PrintSettingsPanel } from '../PrintSettingsPanel';
import { VersionHistoryPanel } from '../projects/VersionHistoryPanel';
import { PrintCheckStage } from './PrintCheckStage';
import type {
  PrinterSpec,
  FilamentSpec,
  PrinterFitResult,
  ModelGeometryStats,
  SlicerSettings,
  ExecutedModelPart,
  ExtractedRequirements,
  PrintabilityReport,
  PrintResult,
  GenerationRecord,
} from '../../types';
import type { KatPrintProject, ModelVersion } from '../../projects/projectTypes';

export interface RightPanelProps {
  mobileTab: 'create' | 'viewer' | 'assistant' | 'print' | 'projects';
  setMobileTab: (tab: 'create' | 'viewer' | 'assistant' | 'print' | 'projects') => void;
  rightPanelTab: 'design' | 'print' | 'versions';
  setRightPanelTab: (tab: 'design' | 'print' | 'versions') => void;
  isRevisingCad: boolean;
  currentParts: ExecutedModelPart[];
  designPanelMode: 'assistant' | 'feature';
  setDesignPanelMode: (mode: 'assistant' | 'feature') => void;
  selectedFeatureId: string | null;
  selectedFeatureIds: string[];
  activeProject: KatPrintProject | null;
  currentActiveVersion: ModelVersion | null;
  viewingVersionId: string | null;
  handleSelectFeature: (featureId: string | null) => void;
  handleConversationalRevision: (instruction: string) => Promise<void>;
  handleRollbackLastRevision: () => Promise<void>;
  handleSelectVersionForViewing: (version: ModelVersion) => void;
  handleRestoreVersion: (version: ModelVersion) => Promise<void>;
  handleBranchVersion: (version: ModelVersion) => Promise<void>;
  handleReturnToHead: () => void;
  persistActiveProject: (project: KatPrintProject) => Promise<void>;
  currentJscadCode: string;
  handleFocusFeature: (featureId: string) => void;
  handleUpdateFeatureParameter: (parameterId: string, newValue: number | string | boolean) => void;
  handleToggleLockParameter: (parameterId: string, currentLocked: boolean) => void;
  handleReconstructFeatureModel: () => void;
  isApplyingParameter: boolean;
  setIsCustomPrinterOpen: (open: boolean) => void;
  selectedPrinterId: string;
  handlePrinterChange: (printerId: string) => Promise<void> | void;
  printerGroups: [string, PrinterSpec[]][];
  selectedFilamentId: string;
  handleFilamentChange: (filamentId: string) => void;
  mustHoldLiquid: boolean;
  handleMustHoldLiquidChange: (val: boolean) => void;
  selectedPartId: string | null;
  setSelectedPartId: (id: string | null) => void;
  partVisibility: Record<string, boolean>;
  setPartVisibility: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
  explodedOffset: number;
  setExplodedOffset: (offset: number) => void;
  scaleFactor: number;
  selectedPrinter: PrinterSpec;
  selectedFilament: FilamentSpec;
  setIsPlateLayoutOpen: (open: boolean) => void;
  setCurrentParts: React.Dispatch<React.SetStateAction<ExecutedModelPart[]>>;
  activeGeometry: THREE.BufferGeometry | null;
  geometryStats: ModelGeometryStats;
  printerFitResult: PrinterFitResult;
  slicerSettings: SlicerSettings;
  handleScaleFactorChange: (scale: number) => void;
  handleExplainSlicerSettings: () => Promise<void>;
  slicerExplanation: string | null;
  isExplainingSlicer: boolean;
  setIsLiveMonitorOpen: (open: boolean) => void;
  modelName: string;
  extractedRequirements: ExtractedRequirements | null;
  exportValidation: { allowed: boolean; reason: string };
  printabilityReport: PrintabilityReport | null;
  isAnalyzingPrintability: boolean;
  handleApplySuggestedOrientation: (rotationDeg: [number, number, number]) => void;
  hasExportedStl: boolean;
  currentGenerationRecord: GenerationRecord | null;
  setSelectedRecordForModal: (record: GenerationRecord) => void;
  setIsPrintResultModalOpen: (open: boolean) => void;
  handleCompareVersions: (versionA: ModelVersion, versionB: ModelVersion) => void;
  handleRenameVersionLabel: (versionId: string, newLabel: string) => void;
  handleExportVersionStl: (version: ModelVersion) => void;
  handleViewVersionDiagnostics: (version: ModelVersion) => void;
}

export const RightPanel: React.FC<RightPanelProps> = ({
  mobileTab,
  setMobileTab,
  rightPanelTab,
  setRightPanelTab,
  isRevisingCad,
  currentParts,
  designPanelMode,
  setDesignPanelMode,
  selectedFeatureId,
  selectedFeatureIds,
  activeProject,
  currentActiveVersion,
  viewingVersionId,
  handleSelectFeature,
  handleConversationalRevision,
  handleRollbackLastRevision,
  handleSelectVersionForViewing,
  handleRestoreVersion,
  handleBranchVersion,
  handleReturnToHead,
  persistActiveProject,
  currentJscadCode,
  handleFocusFeature,
  handleUpdateFeatureParameter,
  handleToggleLockParameter,
  handleReconstructFeatureModel,
  isApplyingParameter,
  setIsCustomPrinterOpen,
  selectedPrinterId,
  handlePrinterChange,
  printerGroups,
  selectedFilamentId,
  handleFilamentChange,
  mustHoldLiquid,
  handleMustHoldLiquidChange,
  selectedPartId,
  setSelectedPartId,
  partVisibility,
  setPartVisibility,
  explodedOffset,
  setExplodedOffset,
  scaleFactor,
  selectedPrinter,
  selectedFilament,
  setIsPlateLayoutOpen,
  setCurrentParts,
  activeGeometry,
  geometryStats,
  printerFitResult,
  slicerSettings,
  handleScaleFactorChange,
  handleExplainSlicerSettings,
  slicerExplanation,
  isExplainingSlicer,
  setIsLiveMonitorOpen,
  modelName,
  extractedRequirements,
  exportValidation,
  printabilityReport,
  isAnalyzingPrintability,
  handleApplySuggestedOrientation,
  hasExportedStl,
  currentGenerationRecord,
  setSelectedRecordForModal,
  setIsPrintResultModalOpen,
  handleCompareVersions,
  handleRenameVersionLabel,
  handleExportVersionStl,
  handleViewVersionDiagnostics,
}) => {
  return (
    <section
      className={`${
        mobileTab === 'assistant' || mobileTab === 'print' ? 'flex w-full h-full pb-16 lg:pb-0' : 'hidden'
      } lg:flex lg:w-[360px] bg-kf-panel lg:border-l border-kf-border flex-col shrink-0 ${isRevisingCad ? 'trace-active' : ''}`}
    >
      <div className="h-11 flex items-end border-b border-kf-border bg-kf-panel-2 px-2 font-mono text-[11px]">
        <button
          type="button"
          onClick={() => {
            setRightPanelTab('design');
            if (mobileTab === 'print') setMobileTab('assistant');
          }}
          className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-3 border-b-2 uppercase tracking-wider transition cursor-pointer ${rightPanelTab === 'design' ? 'border-kf-pink text-kf-pink font-bold' : 'border-transparent text-kf-muted hover:text-kf-text'}`}
        >
          <MessageSquare className="w-3.5 h-3.5" /> Design
        </button>
        <button
          type="button"
          onClick={() => {
            setRightPanelTab('print');
            if (mobileTab === 'assistant') setMobileTab('print');
          }}
          className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-3 border-b-2 uppercase tracking-wider transition cursor-pointer ${rightPanelTab === 'print' ? 'border-kf-pink text-kf-pink font-bold' : 'border-transparent text-kf-muted hover:text-kf-text'}`}
        >
          <Printer className="w-3.5 h-3.5" /> Print
          {hasMultiplePhysicalPieces(currentParts) && <span className="text-[9px] text-kf-pink">{getPhysicalPieceCount(currentParts)}</span>}
        </button>
        <button
          type="button"
          onClick={() => setRightPanelTab('versions')}
          className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-3 border-b-2 uppercase tracking-wider transition cursor-pointer ${rightPanelTab === 'versions' ? 'border-kf-pink text-kf-pink font-bold' : 'border-transparent text-kf-muted hover:text-kf-text'}`}
        >
          <History className="w-3.5 h-3.5" /> History
        </button>
      </div>

      <div className="flex-1 min-h-0 overflow-hidden">
        {rightPanelTab === 'design' && (
          <div className="h-full flex flex-col">
            <div className="h-10 shrink-0 flex items-center gap-1 border-b border-kf-border px-2 bg-kf-panel">
              <button
                type="button"
                onClick={() => setDesignPanelMode('assistant')}
                className={`flex-1 px-2 py-1.5 font-mono text-[10px] uppercase tracking-wider transition cursor-pointer ${designPanelMode === 'assistant' ? 'bg-kf-pink text-kf-bg font-bold' : 'text-kf-muted hover:text-kf-text'}`}
              >
                Assistant
              </button>
              <button
                type="button"
                onClick={() => setDesignPanelMode('feature')}
                className={`flex-1 px-2 py-1.5 font-mono text-[10px] uppercase tracking-wider transition cursor-pointer ${designPanelMode === 'feature' ? 'bg-kf-pink text-kf-bg font-bold' : 'text-kf-muted hover:text-kf-text'}`}
              >
                Feature {selectedFeatureIds.length > 0 ? `(${selectedFeatureIds.length})` : ''}
              </button>
            </div>

            <div className="flex-1 min-h-0 overflow-y-auto kf-scroll pb-12">
              {designPanelMode === 'assistant' && activeProject && (
                <ProjectConversationPanel
                  project={activeProject}
                  activeVersion={currentActiveVersion}
                  viewingVersionId={viewingVersionId}
                  selectedFeatureId={selectedFeatureId}
                  selectedFeatureIds={selectedFeatureIds}
                  onDeselectFeature={() => handleSelectFeature(null)}
                  autoApply={activeProject.projectSettings?.autoApplyProposedChanges ?? false}
                  onSendInstruction={handleConversationalRevision}
                  onUndo={handleRollbackLastRevision}
                  onSelectVersion={(vId) => {
                    const v = activeProject.versions.find((item) => item.id === vId);
                    if (v) handleSelectVersionForViewing(v);
                  }}
                  onRestoreVersion={handleRestoreVersion}
                  onBranchVersion={handleBranchVersion}
                  onReturnToCurrent={handleReturnToHead}
                  isProcessing={isRevisingCad}
                  onToggleAutoApply={async (enabled) => {
                    const updated: KatPrintProject = {
                      ...activeProject,
                      projectSettings: { ...activeProject.projectSettings, autoApplyProposedChanges: enabled },
                    };
                    await persistActiveProject(updated);
                  }}
                />
              )}

              {designPanelMode === 'feature' && (
                <div className="p-3 pb-12">
                  <FeatureInspector
                    featureModel={currentActiveVersion?.featureModel}
                    cadCode={currentActiveVersion?.cadCode || currentJscadCode}
                    selectedFeatureId={selectedFeatureId}
                    selectedFeatureIds={selectedFeatureIds}
                    onSelectFeature={handleSelectFeature}
                    onFocusFeature={handleFocusFeature}
                    onUpdateParameter={handleUpdateFeatureParameter}
                    onToggleLock={handleToggleLockParameter}
                    onReconstructFeatureModel={handleReconstructFeatureModel}
                    isApplying={isApplyingParameter}
                    isReadOnly={Boolean(viewingVersionId && viewingVersionId !== activeProject?.currentVersionId)}
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {rightPanelTab === 'print' && (
          <div className="h-full overflow-y-auto kf-scroll p-3 pb-12 space-y-3">
            <div className="trace clip-corner p-[1px]">
              <div className="bg-kf-panel p-3 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="section-label">Printer & Material</span>
                  <button type="button" onClick={() => setIsCustomPrinterOpen(true)} className="font-mono text-[10px] text-kf-pink hover:text-kf-pink-hi cursor-pointer">Configure</button>
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="select-printer" className="text-[10px] font-mono uppercase tracking-wider text-kf-muted">Printer</label>
                  <select
                    id="select-printer"
                    value={selectedPrinterId}
                    onChange={(e) => handlePrinterChange(e.target.value)}
                    className="w-full bg-kf-panel-2 border border-kf-border px-3 py-2 text-xs font-mono text-kf-text focus:outline-none focus:border-kf-pink clip-corner"
                  >
                    {printerGroups.map(([groupName, groupPrinters]) => (
                      <optgroup key={groupName} label={groupName} className="bg-kf-panel font-bold text-kf-muted">
                        {groupPrinters.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.buildVolume.x}×{p.buildVolume.y}×{p.buildVolume.z}mm)</option>)}
                      </optgroup>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="select-filament" className="text-[10px] font-mono uppercase tracking-wider text-kf-muted">Material</label>
                  <select
                    id="select-filament"
                    value={selectedFilamentId}
                    onChange={(e) => handleFilamentChange(e.target.value)}
                    className="w-full bg-kf-panel-2 border border-kf-border px-3 py-2 text-xs font-mono text-kf-text focus:outline-none focus:border-kf-pink clip-corner"
                  >
                    {FILAMENTS.map((f) => <option key={f.id} value={f.id}>{f.name} · {f.densityGcm3} g/cm³</option>)}
                  </select>
                </div>

                <button
                  type="button"
                  onClick={() => handleMustHoldLiquidChange(!mustHoldLiquid)}
                  className={`w-full flex items-center justify-between px-3 py-2 border font-mono text-[10px] uppercase tracking-wider transition cursor-pointer ${mustHoldLiquid ? 'border-kf-pink bg-kf-pink/10 text-kf-pink' : 'border-kf-border bg-kf-panel-2 text-kf-muted hover:text-kf-text'}`}
                >
                  <span className="flex items-center gap-2"><Droplets className="w-3.5 h-3.5" /> Watertight Mode</span>
                  <span>{mustHoldLiquid ? 'On' : 'Off'}</span>
                </button>
              </div>
            </div>

            {hasMultiplePhysicalPieces(currentParts) && (
              <div className="trace clip-corner p-[1px]">
                <div className="bg-kf-panel p-3">
                  <MultiPartManager
                    parts={currentParts}
                    assemblyDef={currentActiveVersion?.assembly}
                    projectName={activeProject?.name || 'Assembly'}
                    versionLabel={currentActiveVersion?.label}
                    selectedPartId={selectedPartId}
                    onSelectPart={setSelectedPartId}
                    partVisibility={partVisibility}
                    onTogglePartVisibility={(pId) => setPartVisibility((prev) => ({ ...prev, [pId]: prev[pId] === false ? true : false }))}
                    explodedOffset={explodedOffset}
                    onExplodedOffsetChange={setExplodedOffset}
                    scaleFactor={scaleFactor}
                    printer={selectedPrinter}
                    filament={selectedFilament}
                    onOpenPlateLayoutModal={() => setIsPlateLayoutOpen(true)}
                    onUpdatePartQuantity={(pId, qty) => setCurrentParts((prev) => prev.map((p) => (p.id === pId ? { ...p, quantity: Math.max(1, qty) } : p)))}
                  />
                </div>
              </div>
            )}

            {/* Print Check Pre-Flight Validation Stage */}
            <div className="trace clip-corner p-[1px]">
              <div className="bg-kf-panel p-3">
                <PrintCheckStage
                  geometry={activeGeometry}
                  printer={selectedPrinter}
                  stats={geometryStats}
                  parts={currentParts}
                  printabilityReport={printabilityReport}
                  onProceedToExport={() => {
                    const exportBtn = document.getElementById('btn-export-binary-stl');
                    if (exportBtn) {
                      exportBtn.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  onRotateModel={() => {
                    if (printabilityReport?.suggestedOrientation) {
                      handleApplySuggestedOrientation(printabilityReport.suggestedOrientation);
                    }
                  }}
                />
              </div>
            </div>

            <div className="trace clip-corner p-[1px]">
              <div className="bg-kf-panel p-3">
                <PrintSettingsPanel
                  geometry={activeGeometry}
                  parts={currentParts}
                  stats={geometryStats}
                  fitResult={printerFitResult}
                  settings={slicerSettings}
                  printer={selectedPrinter}
                  filament={selectedFilament}
                  scaleFactor={scaleFactor}
                  onScaleChange={handleScaleFactorChange}
                  mustHoldLiquid={mustHoldLiquid}
                  onToggleMustHoldLiquid={() => handleMustHoldLiquidChange(!mustHoldLiquid)}
                  onExplainSettings={handleExplainSlicerSettings}
                  explanation={slicerExplanation}
                  isExplaining={isExplainingSlicer}
                  onOpenMonitor={() => setIsLiveMonitorOpen(true)}
                  modelName={modelName}
                  referenceObject={extractedRequirements?.referenceObject}
                  exportValidation={exportValidation}
                  printabilityReport={printabilityReport}
                  isAnalyzingPrintability={isAnalyzingPrintability}
                  onApplyOrientation={handleApplySuggestedOrientation}
                  hasExported={hasExportedStl}
                  currentPrintResult={currentGenerationRecord?.printResult || null}
                  onOpenPrintResultModal={() => {
                    if (currentGenerationRecord) {
                      setSelectedRecordForModal(currentGenerationRecord);
                      setIsPrintResultModalOpen(true);
                    }
                  }}
                />
              </div>
            </div>
          </div>
        )}

        {rightPanelTab === 'versions' && activeProject && (
          <div className="h-full overflow-y-auto kf-scroll p-3 pb-12">
            <VersionHistoryPanel
              project={activeProject}
              activeVersionId={activeProject.currentVersionId}
              viewingVersionId={viewingVersionId}
              onSelectVersionToView={handleSelectVersionForViewing}
              onRestoreVersion={handleRestoreVersion}
              onBranchVersion={handleBranchVersion}
              onCompareVersions={handleCompareVersions}
              onRenameVersionLabel={handleRenameVersionLabel}
              onExportVersionStl={handleExportVersionStl}
              onViewDiagnostics={handleViewVersionDiagnostics}
            />
          </div>
        )}
      </div>
    </section>
  );
};
