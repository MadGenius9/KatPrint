import React, { useMemo } from 'react';
import * as THREE from 'three';
import {
  ShieldCheck,
  AlertTriangle,
  XCircle,
  CheckCircle2,
  Layers,
  Ruler,
  Maximize2,
  Box,
  RotateCw,
  Download,
  Printer,
  ChevronRight,
  Info,
} from 'lucide-react';
import {
  PrinterSpec,
  ModelGeometryStats,
  ExecutedModelPart,
  PrintabilityReport,
} from '../../types';

export interface PrintCheckStageProps {
  geometry: THREE.BufferGeometry | null;
  printer: PrinterSpec;
  stats: ModelGeometryStats | null;
  parts?: ExecutedModelPart[];
  printabilityReport?: PrintabilityReport | null;
  onProceedToExport: () => void;
  onRotateModel?: () => void;
}

export type CheckStatus = 'READY' | 'WARNING' | 'ERROR';

export interface PrintCheckItem {
  id: string;
  name: string;
  category: CheckStatus;
  detail: string;
  recommendation?: string;
  value?: string;
}

export const PrintCheckStage: React.FC<PrintCheckStageProps> = ({
  geometry,
  printer,
  stats,
  parts = [],
  printabilityReport,
  onProceedToExport,
  onRotateModel,
}) => {
  // Comprehensive printability evaluation
  const evaluation = useMemo(() => {
    if (!geometry || !stats) {
      return {
        overall: 'WARNING' as CheckStatus,
        items: [] as PrintCheckItem[],
      };
    }

    const items: PrintCheckItem[] = [];
    let hasError = false;
    let hasWarning = false;

    // 1. Manifold / Watertight Geometry
    const isManifold = stats.isWatertight ?? true;
    if (isManifold) {
      items.push({
        id: 'manifold',
        name: 'Manifold / Watertight Shell',
        category: 'READY',
        detail: 'Mesh is fully closed with solid interior. Ready for slicer slicing.',
        value: 'Watertight Solid',
      });
    } else {
      hasError = true;
      items.push({
        id: 'manifold',
        name: 'Manifold / Watertight Shell',
        category: 'ERROR',
        detail: 'Mesh contains open boundaries or self-intersections that may cause slicing voids.',
        recommendation: 'Run automatic mesh repair or regenerate with parametric precision mode.',
        value: 'Open Boundaries Detected',
      });
    }

    // 2. Build Volume Fit
    const fitsVolume = stats.fitsInBuildVolume ?? true;
    const modelDimStr = `${stats.boundingBox.x.toFixed(1)} × ${stats.boundingBox.y.toFixed(1)} × ${stats.boundingBox.z.toFixed(1)} mm`;
    const printerDimStr = `${printer.buildVolume.x} × ${printer.buildVolume.y} × ${printer.buildVolume.z} mm`;

    if (fitsVolume) {
      items.push({
        id: 'fit',
        name: 'Build Volume & Bed Fit',
        category: 'READY',
        detail: `Fits inside ${printer.name} build envelope (${printerDimStr}).`,
        value: modelDimStr,
      });
    } else {
      hasError = true;
      items.push({
        id: 'fit',
        name: 'Build Volume & Bed Fit',
        category: 'ERROR',
        detail: `Model dimensions (${modelDimStr}) exceed ${printer.name} build volume (${printerDimStr}).`,
        recommendation: 'Scale down by 10-20% or select a larger 3D printer format.',
        value: 'Exceeds Envelope',
      });
    }

    // 3. Wall Thickness & Shell Strength
    const minDim = Math.min(stats.boundingBox.x, stats.boundingBox.y, stats.boundingBox.z);
    if (minDim < 1.6) {
      hasWarning = true;
      items.push({
        id: 'walls',
        name: 'Minimum Wall Thickness',
        category: 'WARNING',
        detail: 'Minimum feature dimension is under 1.6 mm. Thin areas may be brittle on FDM printers.',
        recommendation: 'Use at least 3 perimeters / wall loops in slicer, or thicken in Advanced settings.',
        value: `< ${minDim.toFixed(1)} mm`,
      });
    } else {
      items.push({
        id: 'walls',
        name: 'Minimum Wall Thickness',
        category: 'READY',
        detail: 'Structural walls exceed minimum 1.6 mm threshold for sturdy FDM layer deposition.',
        value: '≥ 2.0 mm',
      });
    }

    // 4. Overhangs & Support Requirements
    const overhangCount = stats.overhangTrianglesCount || 0;
    const overhangRatio = stats.overhangRatio || 0;

    if (overhangRatio > 0.15) {
      hasWarning = true;
      items.push({
        id: 'overhangs',
        name: 'Steep Overhangs (>45°)',
        category: 'WARNING',
        detail: `${Math.round(overhangRatio * 100)}% of downward faces exceed 45° overhang angle.`,
        recommendation: 'Enable tree / organic supports in your slicer, or rotate the part on bed.',
        value: `${Math.round(overhangRatio * 100)}% steep faces`,
      });
    } else if (overhangRatio > 0) {
      items.push({
        id: 'overhangs',
        name: 'Overhangs & Bridges',
        category: 'READY',
        detail: 'Minor overhangs detected within bridging tolerance of standard 3D printer cooling.',
        value: 'Gentle angles',
      });
    } else {
      items.push({
        id: 'overhangs',
        name: 'Overhangs & Supports',
        category: 'READY',
        detail: 'No steep downward overhangs detected. Self-supporting geometry.',
        value: 'No supports needed',
      });
    }

    // 5. Multi-Part Assembly
    if (parts.length > 1) {
      items.push({
        id: 'parts',
        name: 'Component Separation',
        category: 'READY',
        detail: `Model consists of ${parts.length} distinct components that can be printed individually.`,
        value: `${parts.length} separate parts`,
      });
    } else {
      items.push({
        id: 'parts',
        name: 'Single Contiguous Part',
        category: 'READY',
        detail: 'Model is a single unified printable object.',
        value: '1 solid part',
      });
    }

    // 6. Tiny details below nozzle resolution (0.4mm standard nozzle)
    const polyCount = stats.polygonCount || 0;
    if (polyCount > 80000) {
      items.push({
        id: 'resolution',
        name: 'Mesh Detail & Resolution',
        category: 'READY',
        detail: `High fidelity triangular mesh (${polyCount.toLocaleString()} triangles). Clean curves and fillets.`,
        value: `${polyCount.toLocaleString()} triangles`,
      });
    } else {
      items.push({
        id: 'resolution',
        name: 'Mesh Detail & Resolution',
        category: 'READY',
        detail: `Optimized polygon count (${polyCount.toLocaleString()} triangles). Fast export and slicing.`,
        value: `${polyCount.toLocaleString()} triangles`,
      });
    }

    const overall: CheckStatus = hasError ? 'ERROR' : hasWarning ? 'WARNING' : 'READY';

    return { overall, items };
  }, [geometry, stats, printer, parts]);

  if (!geometry || !stats) {
    return (
      <div className="p-4 bg-kf-panel border border-kf-border rounded-lg text-center flex flex-col items-center gap-2">
        <Box className="w-8 h-8 text-kf-muted" />
        <span className="text-xs text-kf-muted font-mono">
          Generate or select a 3D model first to perform printability verification.
        </span>
      </div>
    );
  }

  const { overall, items } = evaluation;

  return (
    <div className="flex flex-col gap-3 text-kf-text">
      {/* Overall Status Banner */}
      <div
        className={`p-3.5 rounded-lg border flex items-start justify-between gap-3 ${
          overall === 'READY'
            ? 'bg-kf-ok/15 border-kf-ok/40 text-kf-ok'
            : overall === 'WARNING'
            ? 'bg-kf-warn/15 border-kf-warn/40 text-kf-warn'
            : 'bg-kf-error/15 border-kf-error/40 text-kf-error'
        }`}
      >
        <div className="flex items-start gap-2.5">
          {overall === 'READY' ? (
            <ShieldCheck className="w-5 h-5 shrink-0 mt-0.5 text-kf-ok" />
          ) : overall === 'WARNING' ? (
            <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5 text-kf-warn" />
          ) : (
            <XCircle className="w-5 h-5 shrink-0 mt-0.5 text-kf-error" />
          )}
          <div className="flex flex-col">
            <span className="text-xs font-mono font-bold uppercase tracking-wider">
              {overall === 'READY'
                ? 'READY TO PRINT'
                : overall === 'WARNING'
                ? 'PRINT WARNINGS DETECTED'
                : 'PRINTABILITY ISSUES FOUND'}
            </span>
            <span className="text-[11px] text-kf-text/80 mt-0.5">
              {overall === 'READY'
                ? 'Your model geometry satisfies all key 3D printing requirements. It is ready for export and slicing.'
                : overall === 'WARNING'
                ? 'The model can be printed, but review the warnings below (supports or slicer settings may be needed).'
                : 'Review the errors below before printing. The model may exceed printer bounds or require repair.'}
            </span>
          </div>
        </div>
      </div>

      {/* Itemized Checks */}
      <div className="flex flex-col gap-2">
        {items.map((item) => (
          <div
            key={item.id}
            className="p-3 bg-kf-panel-2 border border-kf-border rounded-lg flex flex-col gap-1.5"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-kf-text flex items-center gap-1.5">
                {item.category === 'READY' ? (
                  <CheckCircle2 className="w-4 h-4 text-kf-ok shrink-0" />
                ) : item.category === 'WARNING' ? (
                  <AlertTriangle className="w-4 h-4 text-kf-warn shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-kf-error shrink-0" />
                )}
                <span>{item.name}</span>
              </span>
              {item.value && (
                <span className="text-[10px] font-mono bg-kf-panel px-1.5 py-0.5 rounded border border-kf-border text-kf-muted">
                  {item.value}
                </span>
              )}
            </div>

            <p className="text-[11px] text-kf-muted leading-relaxed pl-5.5">
              {item.detail}
            </p>

            {item.recommendation && (
              <div className="ml-5.5 mt-1 p-2 bg-kf-panel border border-kf-border/80 rounded text-[11px] text-kf-pink flex items-start gap-1.5">
                <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                <span>Fix: {item.recommendation}</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row items-center gap-2 pt-1">
        {onRotateModel && (
          <button
            type="button"
            onClick={onRotateModel}
            className="w-full sm:w-auto flex-1 py-2.5 px-3 rounded-lg border border-kf-border bg-kf-panel-2 hover:bg-kf-panel text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <RotateCw className="w-3.5 h-3.5" /> Rotate on Bed (90°)
          </button>
        )}
        <button
          type="button"
          id="btn-proceed-to-export"
          onClick={onProceedToExport}
          className="w-full sm:w-auto flex-1 py-2.5 px-4 rounded-lg bg-kf-pink text-kf-bg hover:brightness-110 text-xs font-mono font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-md"
        >
          <Download className="w-4 h-4" />
          <span>Proceed to Export</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
