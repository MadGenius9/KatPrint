import React from 'react';

interface KatCatProps {
  side: 'left' | 'right';
}

export const KatCat: React.FC<KatCatProps> = ({ side }) => (
  <svg
    className={`kat-cat kat-cat--${side}`}
    viewBox="0 0 26 26"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.5"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    {/* tail */}
    <path className="kat-cat__tail" d="M19.5 19.5c2.6 0 3.6-2 3-3.8" />
    {/* ears */}
    <path d="M6.2 9.6 6.6 3.2l5.2 3.1" />
    <path d="M17.8 9.6 17.4 3.2l-5.2 3.1" />
    {/* head */}
    <path d="M6.2 9.6a6.9 6.9 0 0 0-1.1 3.7c0 4 3.5 6.9 7.9 6.9s7.9-2.9 7.9-6.9a6.9 6.9 0 0 0-1.1-3.7" />
    {/* eyes */}
    <circle cx="9.6" cy="12.6" r="0.95" fill="currentColor" stroke="none" />
    <circle cx="16.4" cy="12.6" r="0.95" fill="currentColor" stroke="none" />
    {/* nose + mouth */}
    <path d="M13 15.1l-0.85-0.9h1.7z" fill="currentColor" stroke="none" />
    <path d="M13 15.3v0.9M13 16.2c-0.6 0.7-1.7 0.7-2.3 0M13 16.2c0.6 0.7 1.7 0.7 2.3 0" />
    {/* whiskers */}
    <path d="M4.4 13.4l3.1 0.3M4.6 15.9l3-0.8" />
    <path d="M21.6 13.4l-3.1 0.3M21.4 15.9l-3-0.8" />
  </svg>
);
