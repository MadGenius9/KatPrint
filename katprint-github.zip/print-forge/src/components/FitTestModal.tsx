import React, { useState } from 'react';
import { PrinterSpec, FilamentSpec } from '../types';
import { FIT_COUPON_CLEARANCES } from '../engine/fitCoupon';
import { X, Check, ArrowRight, Printer, Sliders, Info, Download } from 'lucide-react';

export interface FitTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  printer: PrinterSpec;
  filament: FilamentSpec;
  onLoadCouponIntoViewer: () => void;
  onExportStl?: () => void;
  onSaveClearance: (printerId: string, clearanceMm: number, filamentId: string) => void;
}

export const FitTestModal: React.FC<FitTestModalProps> = ({
  isOpen,
  onClose,
  printer,
  filament,
  onLoadCouponIntoViewer,
  onExportStl,
  onSaveClearance,
}) => {
  const [couponLoaded, setCouponLoaded] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | string | null>(
    printer.measuredClearanceMm ?? null
  );
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleLoadCoupon = () => {
    onLoadCouponIntoViewer();
    setCouponLoaded(true);
  };

  const handleSelectClearance = (value: number, label: string) => {
    setSelectedOption(label);
    onSaveClearance(printer.id, value, filament.id);

    if (label === 'None fit') {
      setSaveMessage('Saved 0.50mm clearance. Note: Re-test after checking extrusion multiplier.');
    } else if (label === 'All loose') {
      setSaveMessage('Saved 0.10mm clearance.');
    } else {
      setSaveMessage(`Saved ${value.toFixed(2)}mm clearance for ${printer.name} with ${filament.name}.`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-kf-bg/60 backdrop-blur-xs pointer-events-none">
      <div className="bg-kf-panel border border-kf-border shadow-2xl w-full max-w-lg p-5 pointer-events-auto clip-corner font-mono space-y-4 max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="flex items-start justify-between pb-3 border-b border-kf-border/60">
          <div>
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-kf-pink" />
              <h2 className="text-sm font-bold tracking-wider text-kf-text uppercase">
                Fit Test Coupon Calibration
              </h2>
            </div>
            <p className="text-[11px] text-kf-muted mt-1">
              Printer: <span className="text-kf-text font-medium">{printer.name}</span> · Material:{' '}
              <span className="text-kf-pink font-medium">{filament.name}</span>
            </p>
          </div>
          <button
            type="button"
            id="btn-close-fit-test"
            onClick={onClose}
            className="text-kf-muted hover:text-kf-text transition cursor-pointer p-1"
            title="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* STEP 1 */}
        <div className="bg-kf-panel-2 border border-kf-border/60 p-3.5 space-y-3 clip-corner">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-kf-text flex items-center gap-1.5">
              <span className="px-1.5 py-0.5 bg-kf-pink text-kf-bg font-bold text-[10px]">1</span>
              <span>Step 1 — &quot;Print this&quot;</span>
            </span>
            {couponLoaded && (
              <span className="text-[10px] text-kf-ok flex items-center gap-1">
                <Check className="w-3 h-3" /> Ready in viewer
              </span>
            )}
          </div>

          <p className="text-xs text-kf-text leading-relaxed bg-kf-panel p-2.5 border border-kf-border/40 text-kf-muted">
            &quot;Print both parts. Press the peg into each socket, starting at the first (1 notch).
            Pick the first socket the peg enters with light thumb pressure and holds without wobbling.&quot;
          </p>

          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              type="button"
              id="btn-load-fit-coupon"
              onClick={handleLoadCoupon}
              className="px-3 py-1.5 bg-kf-pink hover:bg-kf-pink-hi text-kf-bg font-bold text-xs uppercase tracking-wider transition cursor-pointer flex items-center gap-1.5 clip-corner"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{couponLoaded ? 'Reload Coupon in Viewer' : 'Print this (Load Coupon)'}</span>
            </button>

            {onExportStl && (
              <button
                type="button"
                id="btn-modal-export-stl"
                onClick={onExportStl}
                className="px-3 py-1.5 border border-kf-border hover:border-kf-pink text-kf-text hover:text-kf-pink text-xs transition cursor-pointer flex items-center gap-1.5 clip-corner"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export STL</span>
              </button>
            )}
          </div>

          <div className="text-[10px] text-kf-muted flex items-center gap-1.5">
            <Info className="w-3 h-3 text-kf-muted shrink-0" />
            <span>Export uses the normal STL/3MF buttons; this modal stays open.</span>
          </div>
        </div>

        {/* STEP 2 */}
        <div className="bg-kf-panel-2 border border-kf-border/60 p-3.5 space-y-3 clip-corner">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-kf-text flex items-center gap-1.5">
              <span className="px-1.5 py-0.5 bg-kf-pink text-kf-bg font-bold text-[10px]">2</span>
              <span>Step 2 — &quot;Which one fit?&quot;</span>
            </span>
          </div>

          <p className="text-[11px] text-kf-muted">
            Select the first socket notch that gave a snug, solid mating fit:
          </p>

          {/* Notch Buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {FIT_COUPON_CLEARANCES.map((clearance, idx) => {
              const notches = idx + 1;
              const label = `${notches} notch${notches > 1 ? 'es' : ''} — ${clearance.toFixed(2)}mm`;
              const isSelected = selectedOption === label || selectedOption === clearance;

              return (
                <button
                  key={clearance}
                  type="button"
                  id={`btn-clearance-notch-${notches}`}
                  onClick={() => handleSelectClearance(clearance, label)}
                  className={`p-2 text-left text-xs border transition cursor-pointer clip-corner flex flex-col justify-between gap-1 ${
                    isSelected
                      ? 'bg-kf-pink/15 border-kf-pink text-kf-text font-bold'
                      : 'bg-kf-panel border-kf-border hover:border-kf-pink/60 text-kf-muted hover:text-kf-text'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] opacity-75">{notches} {notches === 1 ? 'notch' : 'notches'}</span>
                    {isSelected && <Check className="w-3 h-3 text-kf-pink" />}
                  </div>
                  <span className="text-sm font-semibold tracking-tight">{clearance.toFixed(2)}mm</span>
                </button>
              );
            })}
          </div>

          {/* Fallback Options: None fit / All loose */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              id="btn-clearance-all-loose"
              onClick={() => handleSelectClearance(0.10, 'All loose')}
              className={`p-2 text-center text-xs border transition cursor-pointer clip-corner ${
                selectedOption === 'All loose'
                  ? 'bg-kf-pink/15 border-kf-pink text-kf-text font-bold'
                  : 'bg-kf-panel border-kf-border hover:border-kf-pink/60 text-kf-muted hover:text-kf-text'
              }`}
            >
              All loose (0.10mm)
            </button>
            <button
              type="button"
              id="btn-clearance-none-fit"
              onClick={() => handleSelectClearance(0.50, 'None fit')}
              className={`p-2 text-center text-xs border transition cursor-pointer clip-corner ${
                selectedOption === 'None fit'
                  ? 'bg-kf-pink/15 border-kf-pink text-kf-text font-bold'
                  : 'bg-kf-panel border-kf-border hover:border-kf-pink/60 text-kf-muted hover:text-kf-text'
              }`}
            >
              None fit (0.50mm)
            </button>
          </div>

          {/* Feedback / Save Confirmation Note */}
          {saveMessage && (
            <div className="bg-kf-panel border border-kf-pink/50 p-2.5 text-xs text-kf-text space-y-1">
              <div className="flex items-center gap-1.5 text-kf-pink font-semibold">
                <Check className="w-3.5 h-3.5" />
                <span>Clearance Recorded</span>
              </div>
              <p className="text-[11px] text-kf-muted">{saveMessage}</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end pt-2 border-t border-kf-border/40">
          <button
            type="button"
            id="btn-done-fit-test"
            onClick={onClose}
            className="px-4 py-1.5 bg-kf-panel-2 border border-kf-border hover:border-kf-pink text-kf-text text-xs uppercase tracking-wider transition cursor-pointer clip-corner flex items-center gap-1"
          >
            <span>Done</span>
            <ArrowRight className="w-3.5 h-3.5 text-kf-pink" />
          </button>
        </div>
      </div>
    </div>
  );
};
