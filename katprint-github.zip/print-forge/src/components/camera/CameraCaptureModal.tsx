import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Camera,
  RotateCw,
  RotateCcw,
  X,
  Sparkles,
  Upload,
  CheckCircle2,
  Maximize2,
  Minimize2,
  RefreshCw,
  Sun,
  ShieldAlert,
  ChevronDown,
  Image as ImageIcon,
} from 'lucide-react';
import { processUploadedImage } from '../../utils/imageProcessing';

export interface CapturedPhotoData {
  dataUrl: string;
  width: number;
  height: number;
  fileName: string;
  mimeType: string;
}

export interface CameraCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCaptureAndConvert: (
    photo: CapturedPhotoData,
    prompt: string,
    mode?: 'ai_cad' | 'heightmap'
  ) => void;
  onAddAsReference?: (photo: CapturedPhotoData) => void;
  onAddAsReferenceOnly?: (photo: CapturedPhotoData) => void;
  hasActiveProject?: boolean;
  initialPrompt?: string;
}

const QUICK_INTENTS = [
  {
    label: 'Convert Object to 3D',
    prompt: 'Create a 3D printable model matching the geometry and shape of this photographed object with solid walls and accurate functional proportions.',
  },
  {
    label: 'Desk Stand / Cradle',
    prompt: 'Design a sturdy 3D printable desk stand/cradle tailored to hold and display this photographed item securely.',
  },
  {
    label: 'Mounting Bracket',
    prompt: 'Design a functional mounting bracket with screw holes to mount this photographed object to a wall or desk.',
  },
  {
    label: 'Protective Case',
    prompt: 'Design a snug 3D printable protective enclosure/case for this photographed object with proper clearances.',
  },
  {
    label: 'Replacement Part',
    prompt: 'Design a durable replacement 3D printable part replicating the functional mounting tabs and dimensions of this item.',
  },
];

export const CameraCaptureModal: React.FC<CameraCaptureModalProps> = ({
  isOpen,
  onClose,
  onCaptureAndConvert,
  onAddAsReference,
  onAddAsReferenceOnly,
  hasActiveProject,
  initialPrompt,
}) => {
  const [cameraStatus, setCameraStatus] = useState<
    'initializing' | 'streaming' | 'denied' | 'unavailable' | 'captured'
  >('initializing');
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [hasMultipleCameras, setHasMultipleCameras] = useState(false);
  const [capturedPhoto, setCapturedPhoto] = useState<CapturedPhotoData | null>(null);
  const [conversionPrompt, setConversionPrompt] = useState(
    initialPrompt || 'Create a 3D printable model matching this photographed object with solid walls and clean functional dimensions.'
  );
  const [selectedIntentIndex, setSelectedIntentIndex] = useState<number>(0);
  const [flashActive, setFlashActive] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isZoomed, setIsZoomed] = useState(false);

  // Swipe-down gesture state for mobile
  const [dragOffsetY, setDragOffsetY] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const touchStartYRef = useRef<number | null>(null);
  const touchStartTimeRef = useRef<number>(0);

  // Non-state stream and session tracking to prevent React render loops
  const streamRef = useRef<MediaStream | null>(null);
  const currentSessionIdRef = useRef<number>(0);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const galleryFileInputRef = useRef<HTMLInputElement | null>(null);
  const nativeCameraInputRef = useRef<HTMLInputElement | null>(null);
  const modalScrollRef = useRef<HTMLDivElement | null>(null);

  // Safely stop all hardware media stream tracks without triggering state cascades
  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      try {
        streamRef.current.getTracks().forEach((track) => {
          track.stop();
        });
      } catch (e) {
        console.warn('Error stopping track:', e);
      }
      streamRef.current = null;
    }
    if (videoRef.current) {
      try {
        videoRef.current.pause();
        videoRef.current.srcObject = null;
      } catch (e) {
        // ignore
      }
    }
  }, []);

  // Check available video devices once when opened
  useEffect(() => {
    if (!isOpen) return;
    if (typeof navigator !== 'undefined' && navigator.mediaDevices?.enumerateDevices) {
      navigator.mediaDevices.enumerateDevices().then((devices) => {
        const videoInputs = devices.filter((d) => d.kind === 'videoinput');
        setHasMultipleCameras(videoInputs.length > 1);
      }).catch(() => {
        setHasMultipleCameras(false);
      });
    }
  }, [isOpen]);

  // Robust live camera startup with fallback resolution & timeout guard
  const startCamera = useCallback(async (facing: 'environment' | 'user') => {
    const sessionId = ++currentSessionIdRef.current;
    stopCamera();
    setCameraStatus('initializing');
    setCameraError(null);

    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      if (sessionId === currentSessionIdRef.current) {
        setCameraStatus('unavailable');
        setCameraError(
          'Live camera streaming is not directly available in this browser context. You can take a photo with your device camera or select a picture from your library.'
        );
      }
      return;
    }

    // Safety timeout in case browser permissions prompt stalls or never returns
    const timeoutTimer = setTimeout(() => {
      if (sessionId === currentSessionIdRef.current) {
        setCameraStatus((prev) => {
          if (prev === 'initializing') {
            setCameraError(
              'Camera startup timed out. You can snap using your native device camera or choose a photo from your gallery below.'
            );
            return 'unavailable';
          }
          return prev;
        });
      }
    }, 7000);

    try {
      let mediaStream: MediaStream | null = null;
      try {
        // Preferred high-resolution constraints
        mediaStream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: facing },
            width: { ideal: 1920 },
            height: { ideal: 1080 },
          },
          audio: false,
        });
      } catch (firstErr: any) {
        // Graceful fallback for devices that reject strict constraints
        if (
          firstErr.name === 'OverconstrainedError' ||
          firstErr.name === 'ConstraintNotSatisfiedError' ||
          firstErr.name === 'TypeError'
        ) {
          mediaStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: facing },
            audio: false,
          });
        } else {
          throw firstErr;
        }
      }

      clearTimeout(timeoutTimer);

      // Verify request is still the active session (not superseded or aborted)
      if (sessionId !== currentSessionIdRef.current) {
        mediaStream?.getTracks().forEach((t) => t.stop());
        return;
      }

      streamRef.current = mediaStream;

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        try {
          await videoRef.current.play();
        } catch (playErr) {
          console.warn('Video play() call handled:', playErr);
        }
      }

      setCameraStatus('streaming');
    } catch (err: any) {
      clearTimeout(timeoutTimer);
      if (sessionId !== currentSessionIdRef.current) return;

      console.warn('getUserMedia encountered error:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setCameraStatus('denied');
        setCameraError(
          'Camera access was not permitted. You can snap a photo directly using your system camera or choose an image file from your device.'
        );
      } else {
        setCameraStatus('unavailable');
        setCameraError(
          err.message || 'Unable to access camera device. Please use native photo capture or file upload below.'
        );
      }
    }
  }, [stopCamera]);

  // Modal lifecycle: start camera when opened, cleanly stop when closed
  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      setCapturedPhoto(null);
      setIsZoomed(false);
      setDragOffsetY(0);
      return;
    }

    // Modal just opened
    setCapturedPhoto(null);
    setIsZoomed(false);
    setDragOffsetY(0);
    void startCamera(facingMode);

    return () => {
      stopCamera();
    };
  }, [isOpen, stopCamera]); // Note: facingMode and startCamera are not in deps to prevent re-render loops

  // Explicit front/rear camera toggle
  const handleToggleFacingMode = () => {
    const next = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(next);
    if (isOpen && !capturedPhoto) {
      void startCamera(next);
    }
  };

  // Capture current frame from live video viewfinder
  const handleSnapPhoto = () => {
    const video = videoRef.current;
    if (!video || cameraStatus !== 'streaming') return;

    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(40);
      } catch (e) {
        // ignore
      }
    }

    // Flash animation
    setFlashActive(true);
    setTimeout(() => setFlashActive(false), 200);

    const videoWidth = video.videoWidth || 1280;
    const videoHeight = video.videoHeight || 720;

    const maxEdge = 1600;
    const longest = Math.max(videoWidth, videoHeight);
    const scale = Math.min(1, maxEdge / longest);
    const width = Math.max(1, Math.round(videoWidth * scale));
    const height = Math.max(1, Math.round(videoHeight * scale));

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, width, height);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.86);
    const photoData: CapturedPhotoData = {
      dataUrl,
      width,
      height,
      fileName: `capture_${Date.now()}.jpg`,
      mimeType: 'image/jpeg',
    };

    stopCamera();
    setCapturedPhoto(photoData);
    setCameraStatus('captured');
  };

  // Process chosen/native-camera files through the same validated pipeline as PhotoInput.
  // This keeps iPhone HEIC/HEIF, resizing, validation, and MIME handling consistent.
  const handleProcessImageFile = async (file?: File) => {
    if (!file) return;

    setIsProcessing(true);
    setCameraError(null);
    stopCamera();

    try {
      const processed = await processUploadedImage(file);
      setCapturedPhoto({
        dataUrl: processed.dataUrlForAi,
        width: processed.width,
        height: processed.height,
        fileName: file.name || `photo_${Date.now()}.jpg`,
        mimeType: processed.aiMimeType,
      });
      setCameraStatus('captured');
    } catch (err: any) {
      setCameraError(err?.message || "Couldn't process image file. Please try another photo.");
      setCameraStatus('unavailable');
    } finally {
      setIsProcessing(false);
    }
  };

  // Retake photo: clear buffer and restart live camera stream
  const handleRetake = () => {
    setCapturedPhoto(null);
    setIsZoomed(false);
    setCameraError(null);
    void startCamera(facingMode);
  };

  // Confirm conversion to 3D CAD
  const handleConfirmConversion = (mode: 'ai_cad' | 'heightmap' = 'ai_cad') => {
    if (!capturedPhoto) return;
    stopCamera();
    onCaptureAndConvert(capturedPhoto, conversionPrompt.trim(), mode);
    onClose();
  };

  // Add photo as reference without immediate generation
  const handleAddReferenceOnly = () => {
    if (!capturedPhoto) return;
    stopCamera();
    const addFn = onAddAsReferenceOnly || onAddAsReference;
    if (addFn) {
      addFn(capturedPhoto);
    }
    onClose();
  };

  // Mobile swipe-down to close gesture
  const handleTouchStart = (e: React.TouchEvent) => {
    if (modalScrollRef.current && modalScrollRef.current.scrollTop > 5) {
      return;
    }
    touchStartYRef.current = e.touches[0].clientY;
    touchStartTimeRef.current = Date.now();
    setIsDragging(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchStartYRef.current === null) return;
    const currentY = e.touches[0].clientY;
    const deltaY = currentY - touchStartYRef.current;

    if (deltaY > 0) {
      const damped = deltaY < 140 ? deltaY : 140 + (deltaY - 140) * 0.35;
      setDragOffsetY(damped);
    } else {
      setDragOffsetY(0);
    }
  };

  const handleTouchEnd = () => {
    if (touchStartYRef.current === null) return;
    const deltaY = dragOffsetY;
    const elapsed = Date.now() - touchStartTimeRef.current;
    touchStartYRef.current = null;
    setIsDragging(false);

    if (deltaY > 85 || (deltaY > 45 && elapsed < 260)) {
      setDragOffsetY(260);
      setTimeout(() => {
        setDragOffsetY(0);
        stopCamera();
        onClose();
      }, 140);
    } else {
      setDragOffsetY(0);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      id="modal-camera-capture"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/90 backdrop-blur-md p-0 sm:p-4 overflow-hidden transition-opacity duration-200"
      style={{
        opacity: dragOffsetY > 0 ? Math.max(0.35, 1 - dragOffsetY / 300) : 1,
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          stopCamera();
          onClose();
        }
      }}
    >
      <div
        ref={modalScrollRef}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        style={{
          transform: dragOffsetY > 0 ? `translateY(${dragOffsetY}px)` : undefined,
          transition: isDragging ? 'none' : 'transform 0.22s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
        className="bg-[#0D0C0F] border-t sm:border border-kf-border rounded-t-3xl sm:rounded-2xl w-full max-w-2xl max-h-[94vh] sm:max-h-[96vh] flex flex-col shadow-2xl overflow-y-auto sm:overflow-hidden select-none"
      >
        {/* Mobile Swipe-Down Drag Handle */}
        <div
          className="w-full flex flex-col items-center pt-2.5 pb-1 sm:hidden touch-none cursor-grab active:cursor-grabbing shrink-0"
          title="Swipe down to close"
        >
          <div className="w-12 h-1.5 rounded-full bg-kf-border hover:bg-kf-pink/50 transition-colors" />
          <span className="text-[9px] font-mono text-kf-muted mt-1 uppercase tracking-widest flex items-center gap-1">
            <ChevronDown className="w-3 h-3 text-kf-pink animate-bounce" />
            Swipe down to close
          </span>
        </div>

        {/* Modal Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-kf-border bg-[#131217] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-kf-pink/15 border border-kf-pink/30 flex items-center justify-center text-kf-pink">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-bold text-kf-text font-forge tracking-wide">
                  {capturedPhoto ? 'Review Photo & Convert' : 'Capture Object to 3D CAD'}
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase font-bold bg-kf-pink/20 text-kf-pink border border-kf-pink/40">
                  {capturedPhoto ? 'Photo Ready' : cameraStatus === 'streaming' ? 'Live Camera' : 'Camera Ready'}
                </span>
              </div>
              <p className="text-[11px] text-kf-muted hidden sm:block">
                {capturedPhoto
                  ? 'Verify captured image clarity before converting into 3D CAD'
                  : 'Snap or upload a physical object to generate verified, printable 3D CAD geometry.'}
              </p>
            </div>
          </div>
          <button
            type="button"
            id="btn-close-camera-modal"
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-2.5 rounded-lg text-kf-muted hover:text-kf-text hover:bg-kf-panel-2 transition cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
            title="Close camera"
            aria-label="Close camera modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewfinder / Real-time Captured Preview Area */}
        <div className="relative flex-1 bg-black min-h-[300px] sm:min-h-[400px] flex items-center justify-center overflow-hidden">
          {/* Shutter Flash Animation */}
          {flashActive && (
            <div className="absolute inset-0 bg-white z-40 pointer-events-none animate-out fade-out duration-200" />
          )}

          {/* REAL-TIME PREVIEW OF CAPTURED PHOTO */}
          {capturedPhoto ? (
            <div className="relative w-full h-full flex flex-col items-center justify-center bg-[#070709] p-3 sm:p-4 overflow-hidden">
              <div
                className={`relative max-w-full flex items-center justify-center transition-transform duration-200 ${
                  isZoomed ? 'scale-125 cursor-zoom-out' : 'cursor-zoom-in'
                }`}
                onClick={() => setIsZoomed((prev) => !prev)}
              >
                <img
                  src={capturedPhoto.dataUrl}
                  alt="Captured Object Preview"
                  className="max-h-[290px] sm:max-h-[370px] w-auto max-w-full object-contain rounded-xl border border-kf-border shadow-2xl"
                />
              </div>

              {/* On-screen Retake Button Overlay (Top-Left) */}
              <button
                type="button"
                id="btn-retake-photo-overlay"
                onClick={handleRetake}
                className="absolute top-3 left-3 z-30 flex items-center gap-1.5 px-3.5 py-2 bg-black/85 hover:bg-black text-kf-pink border border-kf-pink/50 rounded-lg text-xs font-mono font-bold shadow-lg transition active:scale-95 cursor-pointer min-h-[40px]"
                title="Clear buffer and retake photo"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retake</span>
              </button>

              {/* Status and Zoom Controls Overlay (Top-Right) */}
              <div className="absolute top-3 right-3 z-30 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsZoomed((prev) => !prev)}
                  className="px-2.5 py-1.5 rounded-lg bg-black/85 hover:bg-black text-kf-text border border-kf-border text-xs font-mono flex items-center gap-1 shadow-md transition active:scale-95 cursor-pointer min-h-[40px]"
                  title={isZoomed ? 'Zoom fit' : 'Zoom 100%'}
                >
                  {isZoomed ? (
                    <Minimize2 className="w-3.5 h-3.5 text-kf-pink" />
                  ) : (
                    <Maximize2 className="w-3.5 h-3.5 text-kf-pink" />
                  )}
                  <span className="hidden sm:inline">{isZoomed ? 'Fit' : 'Zoom'}</span>
                </button>

                <div className="bg-kf-panel/95 backdrop-blur-md px-2.5 py-1.5 rounded-lg text-[11px] font-mono text-kf-pink border border-kf-pink/40 shadow-md flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-kf-pink" />
                  <span className="font-semibold">Ready for 3D CAD</span>
                </div>
              </div>

              {/* Metadata Ribbon */}
              <div className="absolute bottom-3 inset-x-3 flex items-center justify-between pointer-events-none">
                <div className="bg-black/80 backdrop-blur-md px-2.5 py-1 rounded-md text-[10px] font-mono text-kf-muted border border-kf-border">
                  {capturedPhoto.width} × {capturedPhoto.height} px • Clean edge buffer
                </div>
                <div className="bg-black/80 backdrop-blur-md px-2 py-1 rounded-md text-[10px] font-mono text-kf-muted border border-kf-border hidden sm:block">
                  Tap image to zoom details
                </div>
              </div>
            </div>
          ) : cameraStatus === 'streaming' ? (
            /* Live Camera Stream Viewfinder */
            <div className="relative w-full h-full flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-contain max-h-[420px] bg-black"
              />

              {/* Viewfinder Reticle & Framing Guide */}
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center p-8">
                <div className="relative w-64 h-64 sm:w-72 sm:h-72 border border-kf-pink/30 rounded-2xl flex items-center justify-center">
                  <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-kf-pink -translate-x-0.5 -translate-y-0.5" />
                  <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-kf-pink translate-x-0.5 -translate-y-0.5" />
                  <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-kf-pink -translate-x-0.5 translate-y-0.5" />
                  <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-kf-pink translate-x-0.5 translate-y-0.5" />

                  <div className="w-4 h-4 relative opacity-60">
                    <div className="absolute top-2 left-0 right-0 h-px bg-kf-pink" />
                    <div className="absolute left-2 top-0 bottom-0 w-px bg-kf-pink" />
                  </div>

                  <span className="absolute -bottom-7 px-2.5 py-0.5 rounded-full bg-black/80 text-[10px] font-mono text-kf-text border border-kf-border whitespace-nowrap">
                    Align physical object inside frame
                  </span>
                </div>
              </div>

              {/* Camera Switch Button (Top Right) */}
              {hasMultipleCameras && (
                <button
                  type="button"
                  id="btn-flip-camera"
                  onClick={handleToggleFacingMode}
                  className="absolute top-3 right-3 z-30 p-3 rounded-full bg-black/75 hover:bg-black text-kf-text border border-kf-border backdrop-blur-md transition active:scale-95 cursor-pointer shadow-lg min-h-[44px] min-w-[44px] flex items-center justify-center"
                  title="Switch Camera (Front / Back)"
                  aria-label="Switch Camera"
                >
                  <RotateCw className="w-4 h-4 text-kf-pink" />
                </button>
              )}

              {/* Lighting Tip (Top Left) */}
              <div className="absolute top-3 left-3 z-30 bg-black/75 backdrop-blur-md px-2.5 py-1.5 rounded-md text-[10px] font-mono text-kf-muted border border-kf-border flex items-center gap-1.5">
                <Sun className="w-3.5 h-3.5 text-kf-pink" />
                <span>Good contrast = cleaner CAD</span>
              </div>
            </div>
          ) : cameraStatus === 'initializing' ? (
            /* Starting Camera State */
            <div className="flex flex-col items-center justify-center p-8 text-center gap-3">
              <RefreshCw className="w-8 h-8 text-kf-pink animate-spin" />
              <p className="text-xs font-mono text-kf-text font-semibold">Starting Camera Device...</p>
              <p className="text-[11px] text-kf-muted max-w-xs leading-relaxed">
                Initializing video feed. If camera prompt does not appear, use the upload or native camera buttons below.
              </p>
              <div className="flex items-center gap-2 mt-2">
                <button
                  type="button"
                  onClick={() => galleryFileInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-lg bg-kf-panel-2 border border-kf-border text-kf-text text-xs font-mono hover:border-kf-pink/50 transition cursor-pointer"
                >
                  Choose Saved Photo
                </button>
                <button
                  type="button"
                  onClick={() => nativeCameraInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-lg bg-kf-panel-2 border border-kf-border text-kf-pink text-xs font-mono hover:border-kf-pink/50 transition cursor-pointer"
                >
                  System Camera
                </button>
              </div>
            </div>
          ) : (
            /* Unavailable or Permission Blocked State */
            <div className="flex flex-col items-center justify-center p-6 text-center gap-3 max-w-md">
              <div className="w-12 h-12 rounded-full bg-kf-warn/15 border border-kf-warn/30 flex items-center justify-center text-kf-warn">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-bold text-kf-text font-forge">
                {cameraStatus === 'denied' ? 'Camera Access Blocked' : 'Camera Unavailable in Browser'}
              </h3>
              <p className="text-xs text-kf-muted leading-relaxed">
                {cameraError ||
                  'You can still convert any physical object into 3D CAD by taking a photo with your device camera or uploading an existing photo.'}
              </p>
              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                <button
                  type="button"
                  id="btn-native-camera-fallback"
                  onClick={() => nativeCameraInputRef.current?.click()}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-kf-pink text-[#0A0004] font-mono font-bold text-xs shadow-md transition hover:bg-kf-pink-hi active:scale-95 cursor-pointer min-h-[44px]"
                >
                  <Camera className="w-4 h-4" />
                  <span>Snap with System Camera</span>
                </button>
                <button
                  type="button"
                  id="btn-gallery-fallback"
                  onClick={() => galleryFileInputRef.current?.click()}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-kf-panel-2 border border-kf-border hover:border-kf-pink/50 text-kf-text font-mono text-xs shadow-sm transition active:scale-95 cursor-pointer min-h-[44px]"
                >
                  <ImageIcon className="w-4 h-4 text-kf-pink" />
                  <span>Choose from Gallery</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* 1. SEPARATE HIDDEN INPUT FOR PHOTO GALLERY / DISK UPLOAD (NO capture attribute!) */}
        <input
          ref={galleryFileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/heic,image/heif,.jpg,.jpeg,.png,.webp,.heic,.heif"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void handleProcessImageFile(file);
            e.target.value = '';
          }}
          className="hidden"
          id="input-photo-gallery"
        />

        {/* 2. SEPARATE HIDDEN INPUT FOR NATIVE DEVICE CAMERA APP (WITH capture="environment") */}
        <input
          ref={nativeCameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void handleProcessImageFile(file);
            e.target.value = '';
          }}
          className="hidden"
          id="input-native-camera"
        />

        {/* Bottom Controls Section */}
        <div className="p-3 sm:p-4 bg-[#131217] border-t border-kf-border space-y-3 shrink-0">
          {!capturedPhoto ? (
            /* Live Capture Controls */
            <div className="flex items-center justify-between gap-2 sm:gap-3">
              {/* Photo Gallery / File Upload (guaranteed NO camera trigger) */}
              <button
                type="button"
                id="btn-use-device-file"
                onClick={() => galleryFileInputRef.current?.click()}
                disabled={isProcessing}
                className="flex items-center gap-2 px-3 py-2.5 min-h-[48px] rounded-xl bg-kf-panel-2 hover:bg-kf-panel border border-kf-border hover:border-kf-pink/40 text-kf-muted hover:text-kf-text text-xs font-mono transition cursor-pointer shrink-0 active:scale-95"
                title="Select photo from photo gallery or disk"
              >
                <ImageIcon className="w-4 h-4 text-kf-pink" />
                <span className="hidden sm:inline">Photo Gallery</span>
                <span className="sm:hidden">Gallery</span>
              </button>

              {/* Large Touch-Friendly Shutter Button */}
              <div className="flex-1 flex flex-col items-center justify-center">
                <button
                  type="button"
                  id="btn-shutter-snap"
                  onClick={handleSnapPhoto}
                  disabled={cameraStatus !== 'streaming'}
                  className="relative group w-20 h-20 sm:w-22 sm:h-22 rounded-full border-4 border-kf-pink/80 ring-4 ring-kf-pink/20 hover:ring-kf-pink/40 p-1.5 flex items-center justify-center transition-all duration-150 active:scale-90 hover:scale-105 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-xl shadow-kf-pink/30"
                  title={cameraStatus === 'streaming' ? 'Capture photo' : 'Waiting for camera stream'}
                  aria-label="Capture photo of physical object"
                >
                  <div className="w-full h-full rounded-full bg-kf-pink group-hover:bg-kf-pink-hi transition-colors flex items-center justify-center shadow-inner">
                    <Camera className="w-8 h-8 sm:w-9 sm:h-9 text-[#0A0004]" />
                  </div>
                </button>
              </div>

              {/* Native Device Camera Quick Action */}
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  id="btn-use-native-camera"
                  onClick={() => nativeCameraInputRef.current?.click()}
                  className="flex items-center gap-1.5 px-3 py-2.5 min-h-[48px] rounded-xl bg-kf-panel-2 hover:bg-kf-panel border border-kf-border hover:border-kf-pink/40 text-kf-muted hover:text-kf-text text-xs font-mono transition cursor-pointer active:scale-95"
                  title="Open system native camera app"
                >
                  <Camera className="w-4 h-4 text-kf-pink" />
                  <span className="hidden sm:inline">Device Cam</span>
                  <span className="sm:hidden">Cam</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    stopCamera();
                    onClose();
                  }}
                  className="min-h-[48px] px-3 py-2.5 text-xs font-mono text-kf-muted hover:text-kf-text hover:bg-kf-panel rounded-xl transition cursor-pointer flex items-center justify-center"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            /* Photo Captured: Review, Retake & Convert Section */
            <div className="space-y-3">
              {/* Quick Intent Chips */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono uppercase tracking-wider text-kf-muted flex items-center justify-between">
                  <span>3D Conversion Intent</span>
                  <span className="text-kf-pink">Tap to customize generation</span>
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {QUICK_INTENTS.map((intent, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setSelectedIntentIndex(idx);
                        setConversionPrompt(intent.prompt);
                      }}
                      className={`px-3 py-1.5 min-h-[36px] rounded-lg text-[10px] sm:text-[11px] font-mono transition cursor-pointer flex items-center ${
                        selectedIntentIndex === idx
                          ? 'bg-kf-pink text-[#0A0004] font-bold shadow-xs'
                          : 'bg-kf-panel-2 hover:bg-kf-panel border border-kf-border text-kf-muted hover:text-kf-text'
                      }`}
                    >
                      {intent.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Editable Prompt */}
              <div className="relative">
                <textarea
                  rows={2}
                  value={conversionPrompt}
                  onChange={(e) => setConversionPrompt(e.target.value)}
                  placeholder="Describe your design specifications or functional intent..."
                  className="w-full bg-kf-panel-2 border border-kf-border rounded-lg p-2.5 text-xs text-kf-text placeholder-kf-muted focus:outline-none focus:border-kf-pink focus:ring-1 focus:ring-kf-pink/20 font-sans resize-none leading-relaxed"
                />
              </div>

              {/* Action Buttons: Retake Button, Attach As Context, and Convert to 3D CAD */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                {/* Prominent Retake Button to Clear Buffer and Restart Camera */}
                <button
                  type="button"
                  id="btn-retake-photo"
                  onClick={handleRetake}
                  className="min-h-[44px] px-4 py-2.5 rounded-xl bg-kf-panel-2 hover:bg-kf-panel border border-kf-border hover:border-kf-pink/50 text-kf-text hover:text-kf-pink text-xs font-mono font-bold transition cursor-pointer flex items-center gap-2 active:scale-95 shadow-sm shrink-0"
                  title="Clear photo buffer and retake another picture"
                >
                  <RotateCcw className="w-4 h-4 text-kf-pink" />
                  <span>Retake</span>
                </button>

                {(onAddAsReference || onAddAsReferenceOnly) && (
                  <button
                    type="button"
                    id="btn-save-as-ref-only"
                    onClick={handleAddReferenceOnly}
                    className="min-h-[44px] px-3.5 py-2.5 rounded-xl bg-kf-panel-2 hover:bg-kf-panel border border-kf-border text-kf-muted hover:text-kf-text text-xs font-mono font-medium transition cursor-pointer hidden sm:flex items-center gap-1.5 shrink-0"
                    title="Attach photo as a project reference without generating immediately"
                  >
                    <span>Attach As Context</span>
                  </button>
                )}

                <button
                  type="button"
                  id="btn-convert-to-cad"
                  onClick={() => handleConfirmConversion('ai_cad')}
                  className="flex-1 min-h-[44px] flex items-center justify-center gap-2 bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-mono font-bold uppercase tracking-wider py-2.5 px-4 rounded-xl text-xs transition shadow-md shadow-kf-pink/25 cursor-pointer active:scale-98"
                >
                  <Sparkles className="w-4 h-4 text-[#0A0004]" />
                  <span>Convert to 3D CAD</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
