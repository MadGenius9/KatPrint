import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Camera,
  Upload,
  Sparkles,
  RefreshCw,
  X,
  Check,
  RotateCcw,
  Sliders,
  Image as ImageIcon,
  AlertTriangle,
  ChevronDown,
  Layers,
  Eye,
  Plus,
  Trash2,
  Maximize2,
  Ruler,
  Info,
  Loader2,
  Wand2,
} from 'lucide-react';
import { ProjectReferenceImage } from '../../types';
import {
  processUploadedImage,
  ProcessedImageResult,
  revokeTrackedObjectURL,
  SUPPORTED_IMAGE_EXTENSIONS,
} from '../../utils/imageProcessing';
import { requestPhotoAnalysis, PhotoAnalysisResult } from '../../services/photoAnalysisService';

export interface PhotoInputProps {
  referenceImages: ProjectReferenceImage[];
  onUpdateReferenceImages: (images: ProjectReferenceImage[]) => void;
  onSelectPromptMode?: () => void;
  onPhotoAnalyzed?: (analysis: PhotoAnalysisResult, suggestedPrompt: string) => void;
  isGenerating?: boolean;
}

const VIEW_ANGLES: Array<{ id: ProjectReferenceImage['role']; label: string; icon: string }> = [
  { id: 'front', label: 'Front View', icon: '🔲' },
  { id: 'top', label: 'Top View', icon: '🔝' },
  { id: 'right', label: 'Right Side', icon: '▶️' },
  { id: 'left', label: 'Left Side', icon: '◀️' },
  { id: 'rear', label: 'Rear View', icon: '🔙' },
  { id: 'bottom', label: 'Bottom View', icon: '⏬' },
  { id: 'detail', label: 'Close-up Detail', icon: '🔍' },
  { id: 'scale_reference', label: 'With Calipers/Ruler', icon: '📏' },
];

export const PhotoInput: React.FC<PhotoInputProps> = ({
  referenceImages = [],
  onUpdateReferenceImages,
  onSelectPromptMode,
  onPhotoAnalyzed,
  isGenerating = false,
}) => {
  // Input View: 'choices' | 'camera' | 'preview'
  const [activeView, setActiveView] = useState<'choices' | 'camera' | 'preview'>(() => {
    return referenceImages.length > 0 ? 'preview' : 'choices';
  });

  // Selected angle for next upload/capture
  const [targetAngle, setTargetAngle] = useState<ProjectReferenceImage['role']>('front');

  // Camera hardware state
  const [cameraStreaming, setCameraStreaming] = useState(false);
  const [hasMultipleCameras, setHasMultipleCameras] = useState(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [capturedBlobUrl, setCapturedBlobUrl] = useState<string | null>(null);
  const [capturedDataUrl, setCapturedDataUrl] = useState<string | null>(null);

  // Upload state
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const [processingStatus, setProcessingStatus] = useState<string>('');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Analysis state
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [lastAnalysis, setLastAnalysis] = useState<PhotoAnalysisResult | null>(null);

  // User manual dimensions override
  const [showDimensionInputs, setShowDimensionInputs] = useState(false);
  const [userWidthMm, setUserWidthMm] = useState<string>('');
  const [userHeightMm, setUserHeightMm] = useState<string>('');
  const [userDepthMm, setUserDepthMm] = useState<string>('');
  const [userReferenceNote, setUserReferenceNote] = useState<string>('');

  // DOM Refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const filePickerRef = useRef<HTMLInputElement | null>(null);
  const replaceFilePickerRef = useRef<HTMLInputElement | null>(null);
  const replacingImageIdRef = useRef<string | null>(null);

  // Track if current images changed to switch to preview
  useEffect(() => {
    if (referenceImages.length > 0 && activeView === 'choices') {
      setActiveView('preview');
    }
  }, [referenceImages.length, activeView]);

  // Cleanly stop camera streams
  const stopCameraStream = useCallback(() => {
    if (streamRef.current) {
      try {
        streamRef.current.getTracks().forEach((t) => t.stop());
      } catch (err) {
        console.warn('Error stopping track:', err);
      }
      streamRef.current = null;
    }
    if (videoRef.current) {
      try {
        videoRef.current.pause();
        videoRef.current.srcObject = null;
      } catch {
        // ignore
      }
    }
    setCameraStreaming(false);
  }, []);

  // Cleanup camera stream on unmount
  useEffect(() => {
    return () => {
      stopCameraStream();
      if (capturedBlobUrl) {
        revokeTrackedObjectURL(capturedBlobUrl);
      }
    };
  }, [stopCameraStream, capturedBlobUrl]);

  // Start live camera
  const startCamera = useCallback(async (facing: 'environment' | 'user') => {
    stopCameraStream();
    setCameraError(null);
    setCapturedBlobUrl(null);
    setCapturedDataUrl(null);

    if (!navigator?.mediaDevices?.getUserMedia) {
      setCameraError('Camera access is not supported by your browser or environment.');
      return;
    }

    try {
      // Check multiple cameras
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const videoDevices = devices.filter((d) => d.kind === 'videoinput');
        setHasMultipleCameras(videoDevices.length > 1);
      } catch {
        // ignore
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facing },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.playsInline = true;
        videoRef.current.muted = true;
        await videoRef.current.play();
      }
      setCameraStreaming(true);
    } catch (err: any) {
      console.error('Failed to start camera:', err);
      let msg = 'Could not access device camera.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        msg = 'Camera permission was denied. Please allow camera permissions in browser settings.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        msg = 'No camera device found on this system.';
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
        msg = 'Camera is already in use by another application or tab.';
      }
      setCameraError(msg);
      stopCameraStream();
    }
  }, [stopCameraStream]);

  // Switch camera front/rear
  const handleSwitchCamera = () => {
    const nextFacing = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextFacing);
    startCamera(nextFacing);
  };

  // Trigger snapshot from video element
  const handleTakeSnapshot = () => {
    const video = videoRef.current;
    if (!video || !cameraStreaming) return;

    try {
      const vw = video.videoWidth || 1280;
      const vh = video.videoHeight || 720;
      const canvas = document.createElement('canvas');
      canvas.width = vw;
      canvas.height = vh;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Canvas 2D context unavailable');

      ctx.drawImage(video, 0, 0, vw, vh);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.88);

      canvas.toBlob(
        (blob) => {
          if (blob) {
            const blobUrl = URL.createObjectURL(blob);
            setCapturedBlobUrl(blobUrl);
            setCapturedDataUrl(dataUrl);
            stopCameraStream();
          }
        },
        'image/jpeg',
        0.88
      );
    } catch (err: any) {
      console.error('Snapshot failed:', err);
      setCameraError('Failed to capture photo frame from camera.');
    }
  };

  // Retake photo
  const handleRetakePhoto = () => {
    if (capturedBlobUrl) {
      revokeTrackedObjectURL(capturedBlobUrl);
      setCapturedBlobUrl(null);
    }
    setCapturedDataUrl(null);
    startCamera(facingMode);
  };

  // Accept captured photo into project reference images
  const handleAcceptCapturedPhoto = () => {
    if (!capturedDataUrl) return;

    const newImage: ProjectReferenceImage = {
      id: `img_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      fileName: `capture_${targetAngle}_${Date.now()}.jpg`,
      mimeType: 'image/jpeg',
      dataUrl: capturedDataUrl,
      thumbnailDataUrl: capturedDataUrl,
      role: targetAngle,
      createdAt: new Date().toISOString(),
    };

    onUpdateReferenceImages([...referenceImages, newImage]);
    setCapturedBlobUrl(null);
    setCapturedDataUrl(null);
    stopCameraStream();
    setActiveView('preview');
  };

  // Cancel and close camera
  const handleCancelCamera = () => {
    stopCameraStream();
    if (capturedBlobUrl) {
      revokeTrackedObjectURL(capturedBlobUrl);
      setCapturedBlobUrl(null);
    }
    setCapturedDataUrl(null);
    setActiveView(referenceImages.length > 0 ? 'preview' : 'choices');
  };

  // Process selected or dropped file(s)
  const handleProcessFiles = async (files: FileList | File[], replaceImageId?: string) => {
    setUploadError(null);
    if (!files || files.length === 0) return;

    setIsProcessingFile(true);
    setProcessingStatus('Processing file...');

    try {
      const file = files[0];
      const result: ProcessedImageResult = await processUploadedImage(file, (status) => {
        setProcessingStatus(status);
      });

      const newRef: ProjectReferenceImage = {
        id: replaceImageId || `img_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        fileName: file.name,
        filename: file.name,
        mimeType: result.aiMimeType,
        dataUrl: result.dataUrlForAi,
        thumbnailDataUrl: result.thumbnailUrl || result.dataUrlForAi,
        width: result.width,
        height: result.height,
        role: targetAngle,
        createdAt: new Date().toISOString(),
      };

      if (replaceImageId) {
        const updated = referenceImages.map((img) => (img.id === replaceImageId ? newRef : img));
        onUpdateReferenceImages(updated);
      } else {
        onUpdateReferenceImages([...referenceImages, newRef]);
      }

      setActiveView('preview');
    } catch (err: any) {
      console.error('File processing error:', err);
      setUploadError(err.message || 'Failed to process image file.');
    } finally {
      setIsProcessingFile(false);
      setProcessingStatus('');
    }
  };

  // Replace image handler
  const handleTriggerReplaceImage = (imageId: string) => {
    replacingImageIdRef.current = imageId;
    replaceFilePickerRef.current?.click();
  };

  // Delete reference image
  const handleDeleteImage = (imageId: string) => {
    const updated = referenceImages.filter((img) => img.id !== imageId);
    onUpdateReferenceImages(updated);
    if (updated.length === 0) {
      setActiveView('choices');
      setLastAnalysis(null);
    }
  };

  // Analyze primary photo with Gemini Multimodal AI
  const handleAnalyzePhoto = async () => {
    if (referenceImages.length === 0) return;
    const primary = referenceImages[0];

    setIsAnalyzing(true);
    setAnalysisError(null);

    try {
      const knownDimensions =
        userWidthMm || userHeightMm || userDepthMm || userReferenceNote
          ? {
              widthMm: userWidthMm ? parseFloat(userWidthMm) : undefined,
              heightMm: userHeightMm ? parseFloat(userHeightMm) : undefined,
              depthMm: userDepthMm ? parseFloat(userDepthMm) : undefined,
              referenceNote: userReferenceNote || undefined,
            }
          : undefined;

      const result = await requestPhotoAnalysis({
        imageDataUrl: primary.dataUrl,
        mimeType: primary.mimeType,
        userPromptHint: `Angle: ${primary.role}`,
        userKnownDimensions: knownDimensions,
      });

      setLastAnalysis(result.analysis);
      if (onPhotoAnalyzed) {
        onPhotoAnalyzed(result.analysis, result.analysis.suggestedPrompt);
      }
    } catch (err: any) {
      console.error('Photo analysis error:', err);
      setAnalysisError(err.message || 'Failed to analyze photo with AI.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // -------------------------------------------------------------
  // VIEW: 1. THREE CHOICES WORKSPACE
  // -------------------------------------------------------------
  if (activeView === 'choices') {
    return (
      <div className="flex flex-col gap-3 text-kf-text">
        <div className="flex items-center justify-between pb-1 border-b border-kf-border">
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-kf-pink flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" /> Start Designing
          </span>
          <span className="text-[10px] text-kf-muted font-mono">Select Input</span>
        </div>

        {uploadError && (
          <div className="p-2.5 bg-kf-error/15 border border-kf-error/40 rounded text-xs text-kf-error flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{uploadError}</span>
          </div>
        )}

        <div className="grid grid-cols-1 gap-2.5">
          {/* Choice 1: Take Photo */}
          <button
            type="button"
            id="btn-choice-take-photo"
            onClick={() => {
              setActiveView('camera');
              startCamera(facingMode);
            }}
            disabled={isGenerating || isProcessingFile}
            className="group relative flex items-center gap-3.5 p-3.5 rounded-lg border border-kf-border bg-kf-panel-2 hover:border-kf-pink hover:bg-kf-pink/10 transition text-left cursor-pointer active:scale-[0.99] disabled:opacity-50"
          >
            <div className="w-11 h-11 rounded-lg bg-kf-pink/20 border border-kf-pink/40 flex items-center justify-center text-kf-pink shrink-0 group-hover:scale-105 transition">
              <Camera className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-bold text-kf-text group-hover:text-kf-pink transition">
                Take Photo
              </span>
              <span className="text-[11px] text-kf-muted">
                Use your device camera with live preview to snap an object or part
              </span>
            </div>
          </button>

          {/* Choice 2: Upload Photo */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              if (e.dataTransfer.files) {
                handleProcessFiles(e.dataTransfer.files);
              }
            }}
            onClick={() => filePickerRef.current?.click()}
            className={`group relative flex items-center gap-3.5 p-3.5 rounded-lg border-2 border-dashed transition text-left cursor-pointer active:scale-[0.99] ${
              isDragging
                ? 'border-kf-pink bg-kf-pink/15'
                : 'border-kf-border bg-kf-panel hover:border-kf-pink hover:bg-kf-pink/5'
            }`}
          >
            <input
              ref={filePickerRef}
              type="file"
              id="file-input-direct"
              accept="image/jpeg,image/png,image/webp,image/heic,image/heif,.jpg,.jpeg,.png,.webp,.heic,.heif"
              onChange={(e) => {
                if (e.target.files) void handleProcessFiles(e.target.files);
                e.target.value = '';
              }}
              className="hidden"
            />
            <div className="w-11 h-11 rounded-lg bg-kf-panel-2 border border-kf-border flex items-center justify-center text-kf-muted group-hover:text-kf-pink group-hover:border-kf-pink/40 shrink-0 transition">
              <Upload className="w-5 h-5" />
            </div>
            <div className="flex flex-col flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-kf-text group-hover:text-kf-pink transition">
                  Upload Photo
                </span>
                <span className="text-[9px] font-mono uppercase bg-kf-panel-2 px-1.5 py-0.5 rounded border border-kf-border text-kf-muted">
                  JPEG, PNG, HEIC
                </span>
              </div>
              <span className="text-[11px] text-kf-muted">
                Drag and drop or select photo from iPhone, Android, or PC
              </span>
            </div>
          </div>

          {/* Choice 3: Start From Prompt */}
          {onSelectPromptMode && (
            <button
              type="button"
              id="btn-choice-start-prompt"
              onClick={onSelectPromptMode}
              disabled={isGenerating || isProcessingFile}
              className="group relative flex items-center gap-3.5 p-3.5 rounded-lg border border-kf-border bg-kf-panel-2 hover:border-kf-pink hover:bg-kf-pink/10 transition text-left cursor-pointer active:scale-[0.99] disabled:opacity-50"
            >
              <div className="w-11 h-11 rounded-lg bg-kf-panel border border-kf-border flex items-center justify-center text-kf-muted group-hover:text-kf-pink shrink-0 transition">
                <Wand2 className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-bold text-kf-text group-hover:text-kf-pink transition">
                  Start From Prompt
                </span>
                <span className="text-[11px] text-kf-muted">
                  Type a description directly without using reference photos
                </span>
              </div>
            </button>
          )}
        </div>

        {isProcessingFile && (
          <div className="p-3 bg-kf-panel-2 border border-kf-border rounded-lg flex items-center gap-2.5 text-xs text-kf-pink">
            <Loader2 className="w-4 h-4 animate-spin shrink-0" />
            <span>{processingStatus || 'Processing image file...'}</span>
          </div>
        )}
      </div>
    );
  }

  // -------------------------------------------------------------
  // VIEW: 2. LIVE CAMERA WORKSPACE
  // -------------------------------------------------------------
  if (activeView === 'camera') {
    return (
      <div className="flex flex-col gap-3 text-kf-text">
        <div className="flex items-center justify-between pb-1 border-b border-kf-border">
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-kf-pink flex items-center gap-1.5">
            <Camera className="w-3.5 h-3.5" /> Camera Capture
          </span>
          <div className="flex items-center gap-1.5">
            <select
              value={targetAngle}
              onChange={(e) => setTargetAngle(e.target.value as any)}
              className="bg-kf-panel-2 border border-kf-border rounded px-2 py-0.5 text-[10px] font-mono text-kf-text"
            >
              {VIEW_ANGLES.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.icon} {a.label}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={handleCancelCamera}
              className="p-1 text-kf-muted hover:text-kf-text rounded transition cursor-pointer"
              title="Close camera"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {cameraError ? (
          <div className="p-3.5 bg-kf-error/15 border border-kf-error/40 rounded-lg flex flex-col gap-2">
            <div className="flex items-start gap-2 text-xs text-kf-error">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{cameraError}</span>
            </div>
            <div className="flex items-center gap-2 mt-1">
              <button
                type="button"
                onClick={() => startCamera(facingMode)}
                className="px-3 py-1.5 bg-kf-panel-2 border border-kf-border hover:border-kf-pink rounded text-xs font-mono transition cursor-pointer"
              >
                Try Again
              </button>
              <button
                type="button"
                onClick={handleCancelCamera}
                className="px-3 py-1.5 text-xs text-kf-muted hover:text-kf-text font-mono transition cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <div className="relative w-full aspect-[4/3] bg-black rounded-lg overflow-hidden border border-kf-border flex items-center justify-center">
            {capturedBlobUrl ? (
              <img
                src={capturedBlobUrl}
                alt="Captured frame"
                className="w-full h-full object-contain"
              />
            ) : (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            )}

            {/* Target Reticle Overlay */}
            {!capturedBlobUrl && (
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div className="w-48 h-48 border border-white/30 rounded-lg relative">
                  <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-kf-pink" />
                  <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-kf-pink" />
                  <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-kf-pink" />
                  <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-kf-pink" />
                </div>
              </div>
            )}

            {/* Top Bar on camera: Switch camera button */}
            {!capturedBlobUrl && hasMultipleCameras && (
              <button
                type="button"
                onClick={handleSwitchCamera}
                className="absolute top-2.5 right-2.5 p-2 rounded-full bg-black/60 border border-white/20 text-white hover:text-kf-pink transition active:scale-95 cursor-pointer"
                title="Switch Camera (Front/Rear)"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

        {/* Action Controls for Camera */}
        {!cameraError && (
          <div className="flex items-center justify-between gap-2 pt-1">
            {capturedBlobUrl ? (
              <>
                <button
                  type="button"
                  id="btn-camera-retake"
                  onClick={handleRetakePhoto}
                  className="flex-1 py-2.5 px-3 rounded-lg border border-kf-border bg-kf-panel-2 hover:bg-kf-panel text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Retake
                </button>
                <button
                  type="button"
                  id="btn-camera-use-photo"
                  onClick={handleAcceptCapturedPhoto}
                  className="flex-1 py-2.5 px-3 rounded-lg bg-kf-pink text-kf-bg hover:brightness-110 text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition cursor-pointer shadow"
                >
                  <Check className="w-4 h-4 stroke-[3]" /> Use Photo
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={handleCancelCamera}
                  className="py-2.5 px-4 rounded-lg border border-kf-border bg-kf-panel-2 text-xs font-mono text-kf-muted hover:text-kf-text transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  id="btn-camera-capture"
                  onClick={handleTakeSnapshot}
                  disabled={!cameraStreaming}
                  className="flex-1 py-3 px-4 rounded-lg bg-kf-pink text-kf-bg hover:brightness-110 text-sm font-mono font-bold flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50 shadow-md min-h-[44px]"
                >
                  <Camera className="w-4 h-4" /> Capture Photo
                </button>
              </>
            )}
          </div>
        )}
      </div>
    );
  }

  // -------------------------------------------------------------
  // VIEW: 3. REFERENCE PHOTOS & ANALYSIS PREVIEW
  // -------------------------------------------------------------
  const primaryImage = referenceImages[0];

  return (
    <div className="flex flex-col gap-3 text-kf-text">
      {/* Header with Add More button */}
      <div className="flex items-center justify-between pb-1 border-b border-kf-border">
        <span className="text-xs font-mono font-bold uppercase tracking-wider text-kf-pink flex items-center gap-1.5">
          <ImageIcon className="w-3.5 h-3.5" /> Reference Photos ({referenceImages.length})
        </span>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => {
              setActiveView('camera');
              startCamera(facingMode);
            }}
            className="p-1.5 rounded bg-kf-panel-2 border border-kf-border text-kf-muted hover:text-kf-pink transition cursor-pointer"
            title="Snap another photo angle with camera"
          >
            <Camera className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => filePickerRef.current?.click()}
            className="p-1.5 rounded bg-kf-panel-2 border border-kf-border text-kf-muted hover:text-kf-pink transition cursor-pointer"
            title="Upload additional reference image"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <input
        ref={filePickerRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/heic,image/heif,.jpg,.jpeg,.png,.webp,.heic,.heif"
        onChange={(e) => {
          if (e.target.files) handleProcessFiles(e.target.files);
        }}
        className="hidden"
      />

      <input
        ref={replaceFilePickerRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/heic,image/heif,.jpg,.jpeg,.png,.webp,.heic,.heif"
        onChange={(e) => {
          if (e.target.files && replacingImageIdRef.current) {
            void handleProcessFiles(e.target.files, replacingImageIdRef.current);
            replacingImageIdRef.current = null;
            e.target.value = '';
          }
        }}
        className="hidden"
      />

      {/* Primary Image Preview Box */}
      {primaryImage && (
        <div className="relative rounded-lg overflow-hidden border border-kf-border bg-kf-panel-2 flex flex-col">
          <div className="relative w-full aspect-[16/10] bg-black/40 flex items-center justify-center overflow-hidden">
            <img
              src={primaryImage.thumbnailDataUrl || primaryImage.dataUrl}
              alt={primaryImage.fileName || 'Reference photo'}
              className="w-full h-full object-contain"
            />
            <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/70 backdrop-blur-sm border border-white/20 text-[10px] font-mono font-bold text-white flex items-center gap-1">
              <span>Primary View</span>
              <span className="text-kf-pink uppercase">({primaryImage.role})</span>
            </div>
            <div className="absolute top-2 right-2 flex items-center gap-1">
              <button
                type="button"
                onClick={() => handleTriggerReplaceImage(primaryImage.id)}
                className="p-1.5 rounded bg-black/70 border border-white/20 text-white hover:text-kf-pink transition cursor-pointer"
                title="Replace this image"
              >
                <RefreshCw className="w-3 h-3" />
              </button>
              <button
                type="button"
                onClick={() => handleDeleteImage(primaryImage.id)}
                className="p-1.5 rounded bg-black/70 border border-white/20 text-white hover:text-kf-error transition cursor-pointer"
                title="Delete image"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Multiple Angles Thumbnails Strip (if > 1 image) */}
          {referenceImages.length > 1 && (
            <div className="p-2 border-t border-kf-border flex items-center gap-2 overflow-x-auto">
              {referenceImages.map((img, idx) => (
                <div
                  key={img.id}
                  className={`relative w-12 h-12 rounded border shrink-0 overflow-hidden ${
                    idx === 0 ? 'border-kf-pink ring-1 ring-kf-pink' : 'border-kf-border'
                  }`}
                >
                  <img
                    src={img.thumbnailDataUrl || img.dataUrl}
                    alt={img.fileName || `Angle ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute bottom-0 inset-x-0 bg-black/80 text-[8px] font-mono text-center text-white truncate px-0.5">
                    {img.role}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Manual Dimension Calibration Collapsible */}
      <div className="p-2.5 rounded-lg border border-kf-border bg-kf-panel flex flex-col gap-2">
        <button
          type="button"
          onClick={() => setShowDimensionInputs((v) => !v)}
          className="flex items-center justify-between text-xs font-mono text-kf-muted hover:text-kf-text transition cursor-pointer"
        >
          <span className="flex items-center gap-1.5 text-kf-text font-bold">
            <Ruler className="w-3.5 h-3.5 text-kf-pink" />
            <span>Provide Known Dimensions (Optional)</span>
          </span>
          <ChevronDown
            className={`w-3.5 h-3.5 transition-transform ${showDimensionInputs ? 'rotate-180' : ''}`}
          />
        </button>

        {showDimensionInputs && (
          <div className="flex flex-col gap-2 pt-1 border-t border-kf-border/60">
            <p className="text-[11px] text-kf-muted leading-relaxed">
              Photographs alone do not possess absolute physical scale. If you know the dimensions or
              have a measured reference (e.g. caliper reading), enter them here:
            </p>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[10px] font-mono text-kf-muted">Width (mm)</label>
                <input
                  type="number"
                  placeholder="e.g. 80"
                  value={userWidthMm}
                  onChange={(e) => setUserWidthMm(e.target.value)}
                  className="w-full bg-kf-panel-2 border border-kf-border rounded p-1.5 text-xs text-kf-text font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] font-mono text-kf-muted">Height (mm)</label>
                <input
                  type="number"
                  placeholder="e.g. 45"
                  value={userHeightMm}
                  onChange={(e) => setUserHeightMm(e.target.value)}
                  className="w-full bg-kf-panel-2 border border-kf-border rounded p-1.5 text-xs text-kf-text font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] font-mono text-kf-muted">Depth (mm)</label>
                <input
                  type="number"
                  placeholder="e.g. 25"
                  value={userDepthMm}
                  onChange={(e) => setUserDepthMm(e.target.value)}
                  className="w-full bg-kf-panel-2 border border-kf-border rounded p-1.5 text-xs text-kf-text font-mono"
                />
              </div>
            </div>
            <div>
              <label className="text-[10px] font-mono text-kf-muted">Reference Feature Note</label>
              <input
                type="text"
                placeholder="e.g. Standard 608 bearing 22mm OD, M4 bolt hole, coin size"
                value={userReferenceNote}
                onChange={(e) => setUserReferenceNote(e.target.value)}
                className="w-full bg-kf-panel-2 border border-kf-border rounded p-1.5 text-xs text-kf-text"
              />
            </div>
          </div>
        )}
      </div>

      {/* Analysis Action Button */}
      <button
        type="button"
        id="btn-analyze-photo-gemini"
        onClick={handleAnalyzePhoto}
        disabled={isAnalyzing || isGenerating}
        className="w-full py-2.5 px-3 rounded-lg bg-kf-pink/15 hover:bg-kf-pink/25 border border-kf-pink/50 text-kf-pink text-xs font-mono font-bold flex items-center justify-center gap-2 transition cursor-pointer active:scale-[0.99] disabled:opacity-50 shadow-sm"
      >
        {isAnalyzing ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Analyzing Object with Gemini Vision...</span>
          </>
        ) : (
          <>
            <Sparkles className="w-4 h-4" />
            <span>{lastAnalysis ? 'Re-Analyze Photo with AI' : 'Analyze Photo with AI'}</span>
          </>
        )}
      </button>

      {analysisError && (
        <div className="p-2.5 bg-kf-error/15 border border-kf-error/40 rounded text-xs text-kf-error flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{analysisError}</span>
        </div>
      )}

      {/* Structured Analysis Results Panel */}
      {lastAnalysis && (
        <div className="p-3 bg-kf-panel-2 border border-kf-pink/30 rounded-lg flex flex-col gap-2.5 text-xs">
          <div className="flex items-center justify-between pb-1.5 border-b border-kf-border">
            <span className="font-bold text-kf-text flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-kf-pink" />
              <span>{lastAnalysis.primaryObject}</span>
            </span>
            <span className="text-[10px] font-mono text-kf-muted bg-kf-panel px-1.5 py-0.5 rounded border border-kf-border">
              {lastAnalysis.probableObjectType}
            </span>
          </div>

          {/* Scale Notice */}
          <div className="p-2 bg-kf-warn/10 border border-kf-warn/30 rounded text-[11px] text-kf-warn leading-relaxed flex items-start gap-1.5">
            <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
            <span>
              {lastAnalysis.estimatedDimensions.known
                ? 'Scale calibrated using provided reference.'
                : lastAnalysis.estimatedDimensions.reason}
            </span>
          </div>

          {/* Components & Parts */}
          <div className="flex flex-col gap-1">
            <span className="text-[10px] font-mono uppercase text-kf-muted font-bold">
              Detected Components ({lastAnalysis.numberOfComponents})
            </span>
            <div className="flex flex-wrap gap-1.5">
              {lastAnalysis.likelySeparateParts.map((p, i) => (
                <span
                  key={i}
                  className="px-2 py-0.5 rounded bg-kf-panel border border-kf-border text-[11px] text-kf-text font-medium flex items-center gap-1"
                >
                  <Check className="w-3 h-3 text-kf-pink" /> {p.name}
                </span>
              ))}
            </div>
          </div>

          {/* Geometry & Symmetry */}
          <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
            <div>
              <span className="text-[10px] font-mono text-kf-muted">Symmetry:</span>
              <span className="font-medium text-kf-text ml-1 capitalize">{lastAnalysis.symmetry}</span>
            </div>
            <div>
              <span className="text-[10px] font-mono text-kf-muted">Image Quality:</span>
              <span className="font-medium text-kf-text ml-1 capitalize">{lastAnalysis.imageQuality}</span>
            </div>
          </div>

          {/* Features recognized */}
          {lastAnalysis.recognizableGeometry.length > 0 && (
            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-mono uppercase text-kf-muted">Recognized Geometry:</span>
              <ul className="list-disc list-inside text-[11px] text-kf-muted leading-tight space-y-0.5">
                {lastAnalysis.recognizableGeometry.slice(0, 3).map((g, i) => (
                  <li key={i}>{g}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Printability notes */}
          {lastAnalysis.likelyPrintabilityProblems.length > 0 && (
            <div className="p-2 bg-kf-panel border border-kf-border rounded text-[11px] text-kf-muted flex flex-col gap-1">
              <span className="font-mono text-[10px] text-kf-warn font-bold flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> Print Considerations:
              </span>
              <span>{lastAnalysis.likelyPrintabilityProblems.join(' • ')}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
