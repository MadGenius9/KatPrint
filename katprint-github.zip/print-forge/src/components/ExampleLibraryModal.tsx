import React, { useState, useRef } from 'react';
import { CadExample } from '../types';
import {
  Bookmark,
  Star,
  Trash2,
  Download,
  Upload,
  X,
  Check,
  AlertCircle,
  Code2,
} from 'lucide-react';
import {
  loadAllExamples,
  toggleStarExample,
  deleteUserExample,
  exportLibraryToJson,
  importLibraryFromJson,
} from '../examples/exampleLibrary';

interface ExampleLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectExample?: (example: CadExample) => void;
}

export const ExampleLibraryModal: React.FC<ExampleLibraryModalProps> = ({
  isOpen,
  onClose,
  onSelectExample,
}) => {
  const [examples, setExamples] = useState<CadExample[]>(() => loadAllExamples());
  const [feedbackMsg, setFeedbackMsg] = useState<{ text: string; isError?: boolean } | null>(null);
  const [viewingCodeId, setViewingCodeId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const refreshList = () => {
    setExamples(loadAllExamples());
  };

  const handleToggleStar = (id: string, isSeed: boolean) => {
    if (isSeed) return; // Seeds are already permanent
    toggleStarExample(id);
    refreshList();
  };

  const handleDelete = (id: string, isSeed: boolean) => {
    if (isSeed) return;
    deleteUserExample(id);
    refreshList();
    setFeedbackMsg({ text: 'Example deleted from library.' });
    setTimeout(() => setFeedbackMsg(null), 3000);
  };

  const handleExport = () => {
    try {
      const json = exportLibraryToJson(true);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `katprint_example_library_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setFeedbackMsg({ text: 'Library exported to JSON.' });
      setTimeout(() => setFeedbackMsg(null), 3000);
    } catch (err: any) {
      setFeedbackMsg({ text: 'Export failed: ' + err.message, isError: true });
    }
  };

  const handleImportClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const res = importLibraryFromJson(text);
        if (res.success) {
          refreshList();
          setFeedbackMsg({
            text: `Import complete: ${res.added} added, ${res.updated} updated.`,
          });
        } else {
          setFeedbackMsg({
            text: res.error || 'Failed to import JSON.',
            isError: true,
          });
        }
      } catch (err: any) {
        setFeedbackMsg({ text: 'Read error: ' + err.message, isError: true });
      }
      setTimeout(() => setFeedbackMsg(null), 4000);
    };
    reader.readAsText(file);
  };

  const userCount = examples.filter((e) => e.source === 'user').length;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl max-h-[85vh] bg-kf-panel border border-kf-border rounded-xl p-5 shadow-2xl flex flex-col gap-4 text-kf-text"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-kf-border/80 pb-3">
          <div className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-kf-pink" />
            <h2 className="text-base font-bold font-mono text-kf-text">
              Example Library
            </h2>
            <span className="text-xs font-mono text-kf-muted bg-kf-panel-2 px-2 py-0.5 rounded border border-kf-border">
              {examples.length} total ({userCount}/50 user examples)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="btn-export-library-json"
              onClick={handleExport}
              className="flex items-center gap-1.5 text-xs font-mono px-2.5 py-1.5 rounded border bg-kf-panel-2 hover:bg-kf-border text-kf-text border-kf-border transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-kf-pink" />
              <span>Export</span>
            </button>

            <button
              type="button"
              id="btn-import-library-json"
              onClick={handleImportClick}
              className="flex items-center gap-1.5 text-xs font-mono px-2.5 py-1.5 rounded border bg-kf-panel-2 hover:bg-kf-border text-kf-text border-kf-border transition cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-kf-pink" />
              <span>Import</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              className="hidden"
              onChange={handleFileChange}
            />

            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded-md text-kf-muted hover:text-kf-text hover:bg-kf-panel-2 transition cursor-pointer ml-1"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Feedback message banner */}
        {feedbackMsg && (
          <div
            className={`text-xs font-mono px-3 py-2 rounded flex items-center gap-2 border ${
              feedbackMsg.isError
                ? 'bg-kf-fail/10 border-kf-fail/30 text-kf-fail'
                : 'bg-kf-ok/10 border-kf-ok/30 text-kf-ok'
            }`}
          >
            {feedbackMsg.isError ? (
              <AlertCircle className="w-4 h-4" />
            ) : (
              <Check className="w-4 h-4" />
            )}
            <span>{feedbackMsg.text}</span>
          </div>
        )}

        {/* Examples List */}
        <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-2.5">
          {examples.map((ex) => {
            const isSeed = ex.source === 'seed';
            const dateStr = new Date(ex.createdAt).toLocaleDateString(undefined, {
              month: 'short',
              day: 'numeric',
              year: 'numeric',
            });
            const isViewingCode = viewingCodeId === ex.id;

            return (
              <div
                key={ex.id}
                className="bg-kf-panel-2/50 border border-kf-border/70 hover:border-kf-border rounded-lg p-3 flex flex-col gap-2 transition"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold font-mono text-kf-text">
                        {ex.title}
                      </span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-kf-panel text-kf-muted border border-kf-border uppercase">
                        {ex.shapeClass}
                      </span>
                      <span
                        className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                          isSeed
                            ? 'bg-kf-pink/10 border-kf-pink/30 text-kf-pink'
                            : 'bg-kf-ok/10 border-kf-ok/30 text-kf-ok'
                        }`}
                      >
                        {isSeed ? 'seed' : 'user'}
                      </span>
                    </div>

                    <p className="text-[11px] font-mono text-kf-muted mt-1 line-clamp-2">
                      {ex.prompt}
                    </p>

                    <div className="flex items-center gap-2 text-[11px] font-mono text-kf-muted mt-1 flex-wrap">
                      <span>
                        {ex.dimsMm.x}×{ex.dimsMm.y}×{ex.dimsMm.z}mm
                      </span>
                      {ex.isMultiPart && (
                        <>
                          <span>·</span>
                          <span className="text-kf-pink">multi-part</span>
                        </>
                      )}
                      {ex.holdsLiquid && (
                        <>
                          <span>·</span>
                          <span className="text-kf-ok">holds liquid</span>
                        </>
                      )}
                      <span>·</span>
                      <span>{dateStr}</span>
                    </div>
                  </div>

                  {/* Right side buttons */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      title={ex.starred ? 'Starred (favorite)' : 'Star (favorite)'}
                      onClick={() => handleToggleStar(ex.id, isSeed)}
                      disabled={isSeed}
                      className={`p-1.5 rounded transition cursor-pointer ${
                        ex.starred
                          ? 'text-yellow-400 hover:text-yellow-300'
                          : 'text-kf-muted hover:text-kf-text'
                      } ${isSeed ? 'opacity-40 cursor-default' : ''}`}
                    >
                      <Star
                        className="w-4 h-4"
                        fill={ex.starred ? 'currentColor' : 'none'}
                      />
                    </button>

                    <button
                      type="button"
                      title="View JSCAD code"
                      onClick={() => setViewingCodeId(isViewingCode ? null : ex.id)}
                      className="p-1.5 rounded text-kf-muted hover:text-kf-text hover:bg-kf-panel transition cursor-pointer"
                    >
                      <Code2 className="w-4 h-4" />
                    </button>

                    {!isSeed && (
                      <button
                        type="button"
                        title="Delete user example"
                        onClick={() => handleDelete(ex.id, isSeed)}
                        className="p-1.5 rounded text-kf-muted hover:text-kf-fail hover:bg-kf-fail/10 transition cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}

                    {onSelectExample && (
                      <button
                        type="button"
                        onClick={() => {
                          onSelectExample(ex);
                          onClose();
                        }}
                        className="text-xs font-mono px-2 py-1 rounded bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-semibold transition cursor-pointer ml-1"
                      >
                        Load
                      </button>
                    )}
                  </div>
                </div>

                {/* Code Drawer */}
                {isViewingCode && (
                  <div className="mt-2 p-2.5 bg-black/60 border border-kf-border rounded text-[11px] font-mono text-kf-text overflow-x-auto max-h-56 select-text whitespace-pre">
                    {ex.code}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
