import React from 'react';
import {
  Camera,
  Search,
  Sparkles,
  Box,
  ShieldCheck,
  Download,
  CheckCircle2,
  ChevronRight,
  Sliders,
  Zap,
} from 'lucide-react';

export type PipelineStageName =
  | 'REFERENCE'
  | 'ANALYSIS'
  | 'DESIGN'
  | '3D_MODEL'
  | 'PRINT_CHECK'
  | 'EXPORT';

export interface ProjectPipelineStepperProps {
  currentStage: PipelineStageName;
  onSelectStage: (stage: PipelineStageName) => void;
  experienceMode: 'quick' | 'advanced';
  onToggleExperienceMode: (mode: 'quick' | 'advanced') => void;
  hasGeometry: boolean;
  hasReferenceImages: boolean;
  hasRequirements: boolean;
}

const STAGES: Array<{
  id: PipelineStageName;
  label: string;
  shortLabel: string;
  icon: React.FC<{ className?: string }>;
}> = [
  { id: 'REFERENCE', label: 'Reference', shortLabel: 'Ref', icon: Camera },
  { id: 'ANALYSIS', label: 'Analysis', shortLabel: 'Analyze', icon: Search },
  { id: 'DESIGN', label: 'Design', shortLabel: 'Design', icon: Sparkles },
  { id: '3D_MODEL', label: '3D Model', shortLabel: '3D', icon: Box },
  { id: 'PRINT_CHECK', label: 'Print Check', shortLabel: 'Check', icon: ShieldCheck },
  { id: 'EXPORT', label: 'Export', shortLabel: 'Export', icon: Download },
];

export const ProjectPipelineStepper: React.FC<ProjectPipelineStepperProps> = ({
  currentStage,
  onSelectStage,
  experienceMode,
  onToggleExperienceMode,
  hasGeometry,
  hasReferenceImages,
  hasRequirements,
}) => {
  const currentIdx = STAGES.findIndex((s) => s.id === currentStage);

  return (
    <div className="w-full bg-kf-panel border-b border-kf-border px-3 py-2 flex items-center justify-between gap-2 overflow-x-auto select-none">
      {/* Stages Stepper */}
      <div className="flex items-center gap-1 sm:gap-1.5 min-w-max">
        {STAGES.map((stage, idx) => {
          const Icon = stage.icon;
          const isActive = stage.id === currentStage;
          const isPassed = idx < currentIdx;

          // Check if this stage can be clicked
          const isEnabled =
            stage.id === 'REFERENCE' ||
            (stage.id === 'ANALYSIS' && (hasReferenceImages || hasRequirements)) ||
            (stage.id === 'DESIGN') ||
            (stage.id === '3D_MODEL' && hasGeometry) ||
            (stage.id === 'PRINT_CHECK' && hasGeometry) ||
            (stage.id === 'EXPORT' && hasGeometry);

          return (
            <React.Fragment key={stage.id}>
              {idx > 0 && (
                <ChevronRight className="w-3 h-3 text-kf-muted/40 shrink-0 -mx-0.5" />
              )}
              <button
                type="button"
                id={`btn-pipeline-stage-${stage.id.toLowerCase()}`}
                onClick={() => {
                  if (isEnabled) onSelectStage(stage.id);
                }}
                disabled={!isEnabled}
                className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1 rounded text-xs font-mono transition cursor-pointer disabled:cursor-not-allowed ${
                  isActive
                    ? 'bg-kf-pink text-kf-bg font-bold shadow-sm'
                    : isPassed
                    ? 'text-kf-text hover:bg-kf-panel-2 font-medium'
                    : isEnabled
                    ? 'text-kf-muted hover:text-kf-text'
                    : 'text-kf-muted/40 opacity-40'
                }`}
                title={`Pipeline Stage: ${stage.label}`}
              >
                {isPassed && !isActive ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-kf-pink shrink-0" />
                ) : (
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                )}
                <span className="hidden sm:inline">{stage.label}</span>
                <span className="sm:hidden">{stage.shortLabel}</span>
              </button>
            </React.Fragment>
          );
        })}
      </div>

      {/* Experience Mode Toggle (Quick Create vs Advanced) */}
      <div className="flex items-center border border-kf-border bg-kf-panel-2 p-0.5 rounded shrink-0">
        <button
          type="button"
          id="btn-mode-quick-create"
          onClick={() => onToggleExperienceMode('quick')}
          className={`flex items-center gap-1 px-2 py-1 text-[10px] font-mono font-bold uppercase transition cursor-pointer rounded ${
            experienceMode === 'quick'
              ? 'bg-kf-pink text-kf-bg shadow-sm'
              : 'text-kf-muted hover:text-kf-text'
          }`}
          title="Quick Create: Streamlined experience for everyday printing"
        >
          <Zap className="w-3 h-3" />
          <span>Quick</span>
        </button>
        <button
          type="button"
          id="btn-mode-advanced"
          onClick={() => onToggleExperienceMode('advanced')}
          className={`flex items-center gap-1 px-2 py-1 text-[10px] font-mono font-bold uppercase transition cursor-pointer rounded ${
            experienceMode === 'advanced'
              ? 'bg-kf-pink text-kf-bg shadow-sm'
              : 'text-kf-muted hover:text-kf-text'
          }`}
          title="Advanced: Full parametric engineering tolerances, wall thickness & clearances"
        >
          <Sliders className="w-3 h-3" />
          <span>Advanced</span>
        </button>
      </div>
    </div>
  );
};
