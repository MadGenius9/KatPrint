import React from 'react';
import type * as THREE from 'three';
import {
  Flower2,
  Box,
  FolderKanban,
  Check,
  X,
  Edit2,
  History,
  Bookmark,
  RotateCcw,
  Loader2,
  Download,
  MoreHorizontal,
  FlaskConical,
  HardDrive,
  Package,
  Boxes,
  Camera,
} from 'lucide-react';
import { KatCat } from '../KatCat';
import {
  getPhysicalPieceCount,
  hasMultiplePhysicalPieces,
  downloadExportSTL,
} from '../../engine/stlExporter';
import type {
  FilamentSpec,
  ExecutedModelPart,
  ModelGeometryStats,
} from '../../types';
import type {
  KatPrintProject,
  ModelVersion,
} from '../../projects/projectTypes';

export interface HeaderProps {
  navView: 'workspace' | 'projects';
  setNavView: (view: 'workspace' | 'projects') => void;
  setMobileTab: (tab: 'create' | 'viewer' | 'assistant' | 'print' | 'projects') => void;
  projects: KatPrintProject[];
  activeProject: KatPrintProject | null;
  isEditingTitle: boolean;
  editableTitle: string;
  setEditableTitle: (title: string) => void;
  handleSaveTitle: () => void;
  setIsEditingTitle: (val: boolean) => void;
  currentActiveVersion: ModelVersion | null | undefined;
  saveStatus: 'idle' | 'saving' | 'saved' | 'error';
  isBusy: boolean;
  setIsHistoryModalOpen: (val: boolean) => void;
  setIsLibraryModalOpen: (val: boolean) => void;
  handleClearJob: () => void;
  exportValidation: { allowed: boolean; reason?: string };
  stlExportProgress: number | null;
  activeGeometry: THREE.BufferGeometry | null;
  currentParts: ExecutedModelPart[];
  modelName: string;
  geometryStats: ModelGeometryStats;
  scaleFactor: number;
  selectedFilament: FilamentSpec;
  setStlExportProgress: (val: number | null) => void;
  setHasExportedStl: (val: boolean) => void;
  isHeaderMenuOpen: boolean;
  setIsHeaderMenuOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setIsTestSuiteOpen: (val: boolean) => void;
  setIsStorageModalOpen: (val: boolean) => void;
  handleExportKatPrint: (proj?: KatPrintProject) => void;
  setRightPanelTab: (tab: 'design' | 'print' | 'versions') => void;
  onOpenCamera?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  navView,
  setNavView,
  setMobileTab,
  projects,
  activeProject,
  isEditingTitle,
  editableTitle,
  setEditableTitle,
  handleSaveTitle,
  setIsEditingTitle,
  currentActiveVersion,
  saveStatus,
  isBusy,
  setIsHistoryModalOpen,
  setIsLibraryModalOpen,
  handleClearJob,
  exportValidation,
  stlExportProgress,
  activeGeometry,
  currentParts,
  modelName,
  geometryStats,
  scaleFactor,
  selectedFilament,
  setStlExportProgress,
  setHasExportedStl,
  isHeaderMenuOpen,
  setIsHeaderMenuOpen,
  setIsTestSuiteOpen,
  setIsStorageModalOpen,
  handleExportKatPrint,
  setRightPanelTab,
  onOpenCamera,
}) => {
  return (
    <header className="h-14 bg-kf-panel border-b border-kf-border px-3 sm:px-4 flex items-center justify-between shrink-0 z-40 font-sans relative">
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        <button
          type="button"
          onClick={() => {
            setNavView(navView === 'projects' ? 'workspace' : 'projects');
            setMobileTab(navView === 'projects' ? 'viewer' : 'projects');
          }}
          className="flex items-center gap-2 text-left cursor-pointer group shrink-0"
          title={navView === 'projects' ? 'Back to Design Studio' : 'Open Projects'}
        >
          <Flower2 className="w-5 h-5 text-kf-pink shrink-0" />
          <span className="font-display font-bold text-sm tracking-[0.14em] uppercase text-kf-text">KatPrint</span>
        </button>

        <div className="h-5 w-px bg-kf-border hidden md:block" />

        <button
          type="button"
          onClick={() => {
            setNavView(navView === 'projects' ? 'workspace' : 'projects');
            setMobileTab(navView === 'projects' ? 'viewer' : 'projects');
          }}
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 border border-kf-border bg-kf-panel-2 text-kf-muted hover:text-kf-text hover:border-kf-pink/50 font-mono text-[11px] transition cursor-pointer clip-corner"
        >
          {navView === 'projects' ? <Box className="w-3.5 h-3.5" /> : <FolderKanban className="w-3.5 h-3.5" />}
          <span>{navView === 'projects' ? 'Design Studio' : `Projects (${projects.length})`}</span>
        </button>

        {navView === 'workspace' && activeProject && (
          <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
            <div className="h-5 w-px bg-kf-border" />
            {isEditingTitle ? (
              <div className="flex items-center gap-1 min-w-0">
                <input
                  type="text"
                  value={editableTitle}
                  onChange={(e) => setEditableTitle(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSaveTitle()}
                  className="bg-kf-bg border border-kf-pink px-2 py-1 text-xs font-mono text-kf-text focus:outline-none clip-corner max-w-[120px] sm:max-w-[200px]"
                  autoFocus
                />
                <button type="button" onClick={handleSaveTitle} className="text-kf-ok p-1"><Check className="w-3.5 h-3.5" /></button>
                <button
                  type="button"
                  onClick={() => { setEditableTitle(activeProject.name); setIsEditingTitle(false); }}
                  className="text-kf-muted hover:text-kf-text p-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setIsEditingTitle(true)}
                className="flex items-center gap-1.5 min-w-0 group cursor-pointer"
                title="Rename project"
              >
                <span className="font-semibold text-xs text-kf-text max-w-[100px] sm:max-w-[200px] truncate">{activeProject.name}</span>
                <Edit2 className="w-3 h-3 text-kf-muted group-hover:text-kf-pink transition opacity-0 group-hover:opacity-100 hidden sm:inline" />
              </button>
            )}

            {currentActiveVersion && (
              <span className="px-1.5 py-0.5 bg-kf-pink/10 text-kf-pink border border-kf-pink/30 font-mono text-[9px] font-bold shrink-0">
                V{currentActiveVersion.versionNumber}
              </span>
            )}

            <span className="text-[10px] font-mono text-kf-muted flex items-center gap-1 shrink-0">
              <span className={`w-1.5 h-1.5 rounded-full ${saveStatus === 'saved' ? 'bg-kf-ok' : saveStatus === 'saving' ? 'bg-kf-warn animate-pulse' : 'bg-kf-fail'}`} />
              <span className="hidden sm:inline">{saveStatus === 'saved' ? 'Saved' : saveStatus === 'saving' ? 'Saving' : 'Sync Error'}</span>
            </span>
          </div>
        )}
      </div>

      {/* Centered KAT brand mark, flanked by cats, lit by the pink chaser */}
      <div className={`kat-mark-wrap hidden xl:flex ${isBusy ? 'kat-mark-wrap--busy' : ''}`} aria-hidden="true">
        <KatCat side="left" />
        <div className={`trace clip-corner ${isBusy ? 'trace-active' : ''}`}>
          <div className={`kat-mark ${isBusy ? 'kat-mark--busy' : ''}`} style={{ ['--trace-fill' as string]: 'var(--color-kf-panel)' }}>
            <span className="kat-mark__text">Kat</span>
          </div>
        </div>
        <KatCat side="right" />
      </div>

      {navView === 'workspace' && (
        <div className="flex items-center gap-1.5 sm:gap-2">
          {onOpenCamera && (
            <button
              type="button"
              id="btn-header-camera"
              onClick={onOpenCamera}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 border border-kf-pink/50 bg-kf-pink/10 hover:bg-kf-pink/20 text-kf-pink font-mono text-[10px] sm:text-[11px] font-bold uppercase tracking-wider transition cursor-pointer clip-corner shrink-0 active:scale-95"
              title="Snap photo of physical object with camera"
            >
              <Camera className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Camera</span>
            </button>
          )}

          <button
            type="button"
            id="btn-header-history"
            onClick={() => setIsHistoryModalOpen(true)}
            className="hidden md:flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 border border-kf-border bg-kf-panel-2 hover:bg-kf-panel text-kf-muted hover:text-kf-pink hover:border-kf-pink/50 font-mono text-[10px] sm:text-[11px] font-bold uppercase tracking-wider transition cursor-pointer clip-corner shrink-0"
            title="View generation history and print success stats"
          >
            <History className="w-3.5 h-3.5 text-kf-pink" />
            <span className="hidden md:inline">History</span>
          </button>
          <button
            type="button"
            id="btn-header-library"
            onClick={() => setIsLibraryModalOpen(true)}
            className="hidden md:flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 border border-kf-border bg-kf-panel-2 hover:bg-kf-panel text-kf-muted hover:text-kf-pink hover:border-kf-pink/50 font-mono text-[10px] sm:text-[11px] font-bold uppercase tracking-wider transition cursor-pointer clip-corner shrink-0"
            title="View and manage verified CAD example library"
          >
            <Bookmark className="w-3.5 h-3.5 text-kf-pink" />
            <span className="hidden md:inline">Library</span>
          </button>

          <button
            type="button"
            id="btn-header-clear-job"
            onClick={handleClearJob}
            className="hidden md:flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 border border-kf-border bg-kf-panel-2 hover:bg-kf-panel text-kf-muted hover:text-kf-pink hover:border-kf-pink/50 font-mono text-[10px] sm:text-[11px] font-bold uppercase tracking-wider transition cursor-pointer clip-corner shrink-0"
            title="Clear current job and start fresh"
          >
            <RotateCcw className="w-3.5 h-3.5 text-kf-pink" />
            <span className="hidden md:inline">Clear Job</span>
          </button>

          <button
            type="button"
            id="btn-header-export-stl"
            disabled={!exportValidation.allowed || stlExportProgress !== null}
            title={stlExportProgress !== null ? `Generating STL (${stlExportProgress}%)` : exportValidation.allowed ? 'Download printable STL' : exportValidation.reason}
            onClick={async () => {
              if (stlExportProgress !== null || !exportValidation.allowed || (!activeGeometry && (!currentParts || currentParts.length === 0))) return;
              const cleanName = (modelName || activeProject?.name || 'model').replace(/^TEMPLATE-/i, '').toLowerCase().replace(/[^a-z0-9_]/g, '_').slice(0, 32);
              const heightMm = ((geometryStats?.dimensions?.z || 10) * scaleFactor).toFixed(0);
              const filename = `katprint_${cleanName}_${heightMm}mm_${selectedFilament.id}`;
              setStlExportProgress(0);
              try {
                await downloadExportSTL(activeGeometry, currentParts, filename, scaleFactor, 10, (percent) => setStlExportProgress(percent));
                setHasExportedStl(true);
              } catch (err) {
                console.error('Failed to download STL:', err);
              } finally {
                setTimeout(() => setStlExportProgress(null), 750);
              }
            }}
            className={`sweep ${stlExportProgress !== null ? '' : 'sweep-idle'} clip-corner flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-1.5 sm:py-2 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-40 text-kf-bg font-mono text-[10px] sm:text-[11px] font-bold uppercase tracking-wider transition cursor-pointer`}
          >
            {stlExportProgress !== null ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
            <span>{stlExportProgress !== null ? `${stlExportProgress}%` : <><span className="hidden sm:inline">Download </span>STL</>}</span>
          </button>

          <div className="relative">
            <button
              type="button"
              onClick={() => setIsHeaderMenuOpen((v) => !v)}
              className="w-8 h-8 sm:w-9 sm:h-9 border border-kf-border bg-kf-panel-2 text-kf-muted hover:text-kf-pink hover:border-kf-pink/50 flex items-center justify-center transition cursor-pointer clip-corner"
              title="More tools"
            >
              <MoreHorizontal className="w-4 h-4" />
            </button>
            {isHeaderMenuOpen && (
              <div className="absolute right-0 top-11 w-52 trace clip-corner p-[1px] shadow-2xl z-50">
                <div className="bg-kf-panel p-1.5 space-y-1">
                  <button type="button" onClick={() => { setIsHistoryModalOpen(true); setIsHeaderMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-mono text-kf-muted hover:text-kf-pink hover:bg-kf-panel-2"><History className="w-3.5 h-3.5 text-kf-pink" />Generation History</button>
                  <button type="button" onClick={() => { setIsLibraryModalOpen(true); setIsHeaderMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-mono text-kf-muted hover:text-kf-pink hover:bg-kf-panel-2"><Bookmark className="w-3.5 h-3.5 text-kf-pink" />Example Library</button>
                  <button type="button" onClick={() => { handleClearJob(); setIsHeaderMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-mono text-kf-muted hover:text-kf-pink hover:bg-kf-panel-2"><RotateCcw className="w-3.5 h-3.5 text-kf-pink" />Clear Current Job</button>
                  <button type="button" onClick={() => { setIsTestSuiteOpen(true); setIsHeaderMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-mono text-kf-muted hover:text-kf-text hover:bg-kf-panel-2"><FlaskConical className="w-3.5 h-3.5 text-kf-pink" />Test Suite</button>
                  <button type="button" onClick={() => { setIsStorageModalOpen(true); setIsHeaderMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-mono text-kf-muted hover:text-kf-text hover:bg-kf-panel-2"><HardDrive className="w-3.5 h-3.5" />Storage & Backup</button>
                  {activeProject && <button type="button" onClick={() => { handleExportKatPrint(); setIsHeaderMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-mono text-kf-muted hover:text-kf-text hover:bg-kf-panel-2"><Package className="w-3.5 h-3.5 text-kf-pink" />Export .katprint</button>}
                  {hasMultiplePhysicalPieces(currentParts) && <button type="button" onClick={() => { setRightPanelTab('print'); setMobileTab('print'); setIsHeaderMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-mono text-kf-muted hover:text-kf-text hover:bg-kf-panel-2"><Boxes className="w-3.5 h-3.5 text-kf-pink" />Printable Pieces ({getPhysicalPieceCount(currentParts)})</button>}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
