import React, { useState, useRef } from 'react';
import {
  Camera,
  Upload,
  AlertTriangle,
  Info,
  Image as ImageIcon,
  ExternalLink,
  X,
} from 'lucide-react';
import { photoToMesh, PhotoToMeshResult } from '../services/photoToMesh';
import * as THREE from 'three';

interface PhotoToMeshEditorProps {
  onGeometryGenerated: (geom: THREE.BufferGeometry) => void;
}

/**
 * Honest photo / neural reconstruction panel.
 * Does not pretend to generate geometry when no provider is configured.
 */
export const PhotoToMeshEditor: React.FC<PhotoToMeshEditorProps> = ({
  onGeometryGenerated: _onGeometryGenerated,
}) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [diagnostics, setDiagnostics] = useState<PhotoToMeshResult | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const clearPreview = () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setFileName(null);
    setDiagnostics(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(URL.createObjectURL(file));
    setFileName(file.name);
    setIsChecking(true);
    try {
      const result = await photoToMesh(file);
      setDiagnostics(result);
    } catch (err: any) {
      setDiagnostics({
        isConfigured: false,
        isManifold: false,
        warnings: [
          'Photo-to-Mesh provider not configured.',
          err?.message || 'Unable to reach reconstruction service.',
        ],
        providerNote:
          'No neural or photogrammetry backend is connected. Uploaded images are not converted to 3D.',
        errorMessage: err?.message || 'Photo-to-Mesh provider not configured.',
      });
    } finally {
      setIsChecking(false);
    }
  };

  return (
    <div className="flex flex-col gap-4 text-kf-text">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <Camera className="w-3.5 h-3.5 text-kf-muted" />
          <span className="text-xs font-semibold uppercase tracking-wider text-kf-muted font-mono">
            Photo Reconstruction
          </span>
        </div>
        <span className="text-[11px] text-kf-warn font-mono bg-kf-warn/10 border border-kf-warn/30 px-2 py-0.5 rounded-md shrink-0">
          Not Available
        </span>
      </div>

      <div className="border border-kf-warn/50 bg-kf-warn/10 rounded-lg p-3.5 flex flex-col gap-2.5">
        <div className="flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-kf-warn shrink-0 mt-0.5" />
          <div className="flex flex-col gap-1">
            <span className="text-xs font-semibold text-kf-warn">
              Neural / photogrammetry provider is not configured
            </span>
            <p className="text-[11px] text-kf-muted leading-relaxed font-mono">
              True photo-to-3D needs Tripo3D, Meshy, CSM, Instant-Mesh, or a local Meshroom worker.
              No backend is connected, so uploads will not produce printable geometry.
            </p>
          </div>
        </div>
        <div className="bg-kf-panel/60 border border-kf-border rounded-md p-2.5 flex items-start gap-2">
          <ImageIcon className="w-3.5 h-3.5 text-kf-pink shrink-0 mt-0.5" />
          <p className="text-[11px] text-kf-text leading-relaxed">
            <span className="font-semibold text-kf-pink">Working today:</span>{' '}
            Use <strong>Image-to-3D</strong> (heightmap / silhouette) or Describe &amp; Design
            with a photo as a reference for parametric CAD.
          </p>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-kf-muted font-mono">
            Preview upload (optional)
          </span>
          {previewUrl && (
            <button type="button" onClick={clearPreview} className="text-[11px] text-kf-muted hover:text-kf-text flex items-center gap-1 font-mono">
              <X className="w-3 h-3" /> Clear
            </button>
          )}
        </div>
        <div className="relative border-2 border-dashed border-kf-border bg-kf-panel rounded-lg p-4 text-center">
          <input
            ref={fileInputRef}
            type="file"
            id="file-upload-photo"
            accept="image/*"
            onChange={handleFileUpload}
            disabled={isChecking}
            className="absolute inset-0 opacity-0 cursor-pointer w-full h-full disabled:cursor-not-allowed"
          />
          <div className="flex flex-col items-center justify-center gap-2 pointer-events-none">
            {previewUrl ? (
              <img src={previewUrl} alt="Upload preview" className="w-20 h-20 object-cover rounded-md border border-kf-border" />
            ) : (
              <div className="w-12 h-12 rounded-full bg-kf-panel-2 border border-kf-border flex items-center justify-center text-kf-muted">
                <Upload className="w-5 h-5" />
              </div>
            )}
            <span className="text-xs font-medium text-kf-text">{fileName || 'Drop or click to preview'}</span>
            <span className="text-[11px] text-kf-muted">Preview only — no mesh will be generated</span>
          </div>
        </div>
      </div>

      {(diagnostics || isChecking) && (
        <div className="border border-kf-border bg-kf-panel rounded-lg p-3.5 flex flex-col gap-2.5">
          <div className="flex items-center justify-between border-b border-kf-border pb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-kf-text font-mono">Provider Status</span>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded-md border bg-kf-fail/10 border-kf-fail/40 text-kf-fail flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" /> Not Configured
            </span>
          </div>
          {isChecking ? (
            <p className="text-[11px] text-kf-muted font-mono">Checking provider…</p>
          ) : (
            <>
              {diagnostics?.warnings?.map((warn, i) => (
                <div key={i} className="bg-kf-warn/10 border border-kf-warn/40 p-2.5 rounded-md text-[11px] text-kf-warn flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span>{warn}</span>
                </div>
              ))}
              {diagnostics?.providerNote && (
                <div className="bg-kf-panel-2 border border-kf-border p-2.5 rounded-md text-[11px] text-kf-muted flex items-start gap-2">
                  <Info className="w-4 h-4 text-kf-pink shrink-0 mt-0.5" />
                  <span className="font-mono text-[10px] leading-relaxed">{diagnostics.providerNote}</span>
                </div>
              )}
            </>
          )}
        </div>
      )}

      <div className="text-[10px] text-kf-muted font-mono leading-relaxed border-t border-kf-border pt-3 flex items-start gap-1.5">
        <ExternalLink className="w-3 h-3 shrink-0 mt-0.5 opacity-60" />
        <span>
          When a provider is connected (API key + endpoint), this panel will return a watertight mesh.
        </span>
      </div>
    </div>
  );
};
