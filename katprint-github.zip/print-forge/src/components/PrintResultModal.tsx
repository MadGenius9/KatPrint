import React, { useState, useEffect } from 'react';
import {
  PrintResult,
  PrintOutcome,
  PrintFailureTag,
  GenerationRecord,
} from '../types';
import {
  CheckCircle2,
  AlertTriangle,
  X,
  BookmarkPlus,
  Save,
} from 'lucide-react';

interface PrintResultModalProps {
  isOpen: boolean;
  onClose: () => void;
  record: GenerationRecord | null;
  onSave: (result: PrintResult, addToLibraryTitle?: string) => void;
}

const FAILURE_TAGS: Array<{ tag: PrintFailureTag; label: string }> = [
  { tag: 'leaked', label: 'Leaked' },
  { tag: 'lid_too_tight', label: 'Lid too tight' },
  { tag: 'lid_too_loose', label: 'Lid too loose' },
  { tag: 'warped', label: 'Warped' },
  { tag: 'wrong_size', label: 'Wrong size' },
  { tag: 'layer_split', label: 'Layer split' },
  { tag: 'supports_failed', label: 'Supports failed' },
  { tag: 'thin_walls', label: 'Thin walls' },
  { tag: 'other', label: 'Other' },
];

export const PrintResultModal: React.FC<PrintResultModalProps> = ({
  isOpen,
  onClose,
  record,
  onSave,
}) => {
  const [outcome, setOutcome] = useState<PrintOutcome>('printed_ok');
  const [failureTags, setFailureTags] = useState<string[]>([]);
  const [note, setNote] = useState('');
  const [addToLibrary, setAddToLibrary] = useState(false);
  const [exampleTitle, setExampleTitle] = useState('');

  // Prepopulate when opening with existing result
  useEffect(() => {
    if (record) {
      if (record.printResult) {
        setOutcome(record.printResult.outcome);
        setFailureTags(record.printResult.failureTags || []);
        setNote(record.printResult.note || '');
      } else {
        setOutcome('printed_ok');
        setFailureTags([]);
        setNote('');
      }

      // Default title for example library
      const defaultTitle = record.prompt
        ? record.prompt.slice(0, 50).replace(/[^\w\s-]/g, '').trim()
        : 'User CAD Model';
      setExampleTitle(defaultTitle);
      setAddToLibrary(false);
    }
  }, [record, isOpen]);

  if (!isOpen || !record) return null;

  const eligibleForLibrary =
    outcome === 'printed_ok' &&
    record.source === 'ai' &&
    !record.hasMeasuredDeltaFlags;

  const toggleTag = (tag: string) => {
    setFailureTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSave = () => {
    const result: PrintResult = {
      generationId: record.id,
      recordedAt: new Date().toISOString(),
      outcome,
      failureTags: outcome === 'failed' ? failureTags : [],
      note: note.trim() ? note.trim() : undefined,
    };

    const titleToSave =
      eligibleForLibrary && addToLibrary && exampleTitle.trim()
        ? exampleTitle.trim()
        : undefined;

    onSave(result, titleToSave);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-kf-panel border border-kf-border rounded-xl p-5 shadow-2xl flex flex-col gap-4 text-kf-text"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-kf-border/80 pb-3">
          <div>
            <h2 className="text-base font-bold font-mono text-kf-text flex items-center gap-2">
              <span>Log Print Result</span>
            </h2>
            <p className="text-xs text-kf-muted font-mono mt-0.5 line-clamp-1">
              {record.prompt || 'Generated CAD Model'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-md text-kf-muted hover:text-kf-text hover:bg-kf-panel-2 transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Two Big Outcome Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            id="btn-outcome-printed-ok"
            onClick={() => setOutcome('printed_ok')}
            className={`flex flex-col items-center justify-center p-4 rounded-lg border-2 transition cursor-pointer ${
              outcome === 'printed_ok'
                ? 'border-kf-ok bg-kf-ok/15 text-kf-ok shadow-md shadow-kf-ok/20'
                : 'border-kf-border bg-kf-panel-2 text-kf-muted hover:border-kf-border/80 hover:text-kf-text'
            }`}
          >
            <CheckCircle2 className="w-8 h-8 mb-2" />
            <span className="font-mono font-bold text-sm">Printed fine</span>
            <span className="text-[11px] opacity-80 mt-0.5 font-mono">Good fit & quality</span>
          </button>

          <button
            type="button"
            id="btn-outcome-failed"
            onClick={() => setOutcome('failed')}
            className={`flex flex-col items-center justify-center p-4 rounded-lg border-2 transition cursor-pointer ${
              outcome === 'failed'
                ? 'border-kf-fail bg-kf-fail/15 text-kf-fail shadow-md shadow-kf-fail/20'
                : 'border-kf-border bg-kf-panel-2 text-kf-muted hover:border-kf-border/80 hover:text-kf-text'
            }`}
          >
            <AlertTriangle className="w-8 h-8 mb-2" />
            <span className="font-mono font-bold text-sm">Failed</span>
            <span className="text-[11px] opacity-80 mt-0.5 font-mono">Defect or fit issue</span>
          </button>
        </div>

        {/* Failure Details: Tags + 1-line note */}
        {outcome === 'failed' && (
          <div className="flex flex-col gap-3 p-3 bg-kf-panel-2/60 border border-kf-fail/30 rounded-lg">
            <div>
              <label className="text-xs font-mono font-semibold text-kf-text block mb-1.5">
                Failure issues (select all that apply):
              </label>
              <div className="flex flex-wrap gap-1.5">
                {FAILURE_TAGS.map(({ tag, label }) => {
                  const isSelected = failureTags.includes(tag);
                  return (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => toggleTag(tag)}
                      className={`text-xs font-mono px-2.5 py-1 rounded border transition cursor-pointer ${
                        isSelected
                          ? 'bg-kf-fail text-black border-kf-fail font-semibold'
                          : 'bg-kf-panel text-kf-muted border-kf-border hover:text-kf-text'
                      }`}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="text-xs font-mono text-kf-muted block mb-1">
                Note (optional, 1 line):
              </label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="e.g. Lid lip was ~0.2mm too tight for easy snap fit"
                maxLength={140}
                className="w-full bg-kf-panel border border-kf-border rounded px-3 py-1.5 text-xs text-kf-text font-mono focus:outline-none focus:border-kf-pink"
              />
            </div>
          </div>
        )}

        {/* Prompt: Add to example library? (Only when printed_ok, AI-generated, and no measured delta flags) */}
        {eligibleForLibrary && (
          <div className="flex flex-col gap-2 p-3 bg-kf-ok/5 border border-kf-ok/30 rounded-lg">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={addToLibrary}
                onChange={(e) => setAddToLibrary(e.target.checked)}
                className="rounded border-kf-border text-kf-pink focus:ring-kf-pink h-4 w-4 cursor-pointer"
              />
              <span className="text-xs font-mono font-semibold text-kf-text flex items-center gap-1.5">
                <BookmarkPlus className="w-4 h-4 text-kf-pink" />
                <span>Add to example library?</span>
              </span>
            </label>

            {addToLibrary && (
              <div className="mt-1 flex flex-col gap-1">
                <span className="text-[11px] font-mono text-kf-muted">
                  Library Title for this verified design:
                </span>
                <input
                  type="text"
                  value={exampleTitle}
                  onChange={(e) => setExampleTitle(e.target.value)}
                  placeholder="e.g. Snap-fit battery enclosure"
                  maxLength={60}
                  className="w-full bg-kf-panel border border-kf-border rounded px-3 py-1.5 text-xs text-kf-text font-mono focus:outline-none focus:border-kf-pink"
                />
              </div>
            )}
          </div>
        )}

        {/* Save & Cancel */}
        <div className="flex justify-end items-center gap-2 pt-2 border-t border-kf-border/80">
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-2 rounded text-xs font-mono text-kf-muted hover:text-kf-text bg-transparent hover:bg-kf-panel-2 transition cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            id="btn-save-print-result"
            onClick={handleSave}
            className="flex items-center gap-1.5 bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-mono font-bold px-4 py-2 rounded text-xs transition cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Result</span>
          </button>
        </div>
      </div>
    </div>
  );
};
