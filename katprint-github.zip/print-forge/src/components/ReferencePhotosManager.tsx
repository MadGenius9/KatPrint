import React, { useState, useRef } from 'react';
import {
  Camera,
  Upload,
  Trash2,
  Maximize2,
  X,
  Plus,
  Info,
  CheckCircle2,
  Ruler,
  HelpCircle,
  Eye,
} from 'lucide-react';
import { ProjectReferenceImage } from '../types';
import { processUploadedImage } from '../utils/imageProcessing';

export interface ReferencePhotosManagerProps {
  referenceImages: ProjectReferenceImage[];
  onUpdateReferenceImages: (images: ProjectReferenceImage[]) => void;
  isOpen?: boolean;
  onClose?: () => void;
  onOpenCamera?: () => void;
}

const CAMERA_ROLES: Array<{ id: ProjectReferenceImage['role']; label: string; icon: string }> = [
  { id: 'front', label: 'Front View', icon: '🔲' },
  { id: 'top', label: 'Top View', icon: '🔝' },
  { id: 'right', label: 'Right Side', icon: '▶️' },
  { id: 'left', label: 'Left Side', icon: '◀️' },
  { id: 'rear', label: 'Rear View', icon: '🔙' },
  { id: 'bottom', label: 'Bottom View', icon: '⏬' },
  { id: 'detail', label: 'Close-up Detail', icon: '🔍' },
  { id: 'scale_reference', label: 'With Calipers/Ruler', icon: '📏' },
  { id: 'installation', label: 'Mating Fit / In-situ', icon: '⚙️' },
  { id: 'unknown', label: 'General Reference', icon: '📷' },

];

const MAX_REFERENCE_PHOTOS = 6;

export const ReferencePhotosManager: React.FC<ReferencePhotosManagerProps> = ({
  referenceImages = [],
  onUpdateReferenceImages,
  isOpen = true,
  onClose,
  onOpenCamera,
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedEnlargedImage, setSelectedEnlargedImage] = useState<ProjectReferenceImage | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFiles = async (files: FileList | File[]) => {
    setErrorMessage(null);
    setIsProcessing(true);

    const availableSlots = Math.max(0, MAX_REFERENCE_PHOTOS - referenceImages.length);
    const incoming = Array.from(files);
    if (availableSlots === 0) {
      setErrorMessage('KatPrint supports up to 6 reference photos per project.');
      setIsProcessing(false);
      return;
    }
    const accepted = incoming.slice(0, availableSlots);
    if (incoming.length > availableSlots) {
      setErrorMessage('KatPrint supports up to 6 reference photos per project. Extra photos were not added.');
    }

    const newImages: ProjectReferenceImage[] = [];
    for (const file of accepted) {
      try {
        const normalized = await processUploadedImage(file);
        let defaultRole: ProjectReferenceImage['role'] = 'unknown';
        const totalCount = referenceImages.length + newImages.length;
        if (totalCount === 0) defaultRole = 'front';
        else if (totalCount === 1) defaultRole = 'top';
        else if (totalCount === 2) defaultRole = 'right';

        newImages.push({
          id: `ref_img_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          fileName: file.name,
          filename: file.name,
          dataUrl: normalized.dataUrlForAi,
          thumbnailDataUrl: normalized.thumbnailUrl || normalized.dataUrlForAi,
          mimeType: normalized.aiMimeType,
          width: normalized.width,
          height: normalized.height,
          role: defaultRole,
          notes: '',
          createdAt: new Date().toISOString(),
        });
      } catch (err: any) {
        console.error('Error reading image file:', err);
        setErrorMessage(err?.message || `Couldn't read ${file.name}. Try a PNG, JPG, or WebP image.`);
      }
    }

    setIsProcessing(false);
    if (newImages.length > 0) onUpdateReferenceImages([...referenceImages, ...newImages]);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      void processFiles(e.target.files);
    }
    e.target.value = '';
  };

  const handleRoleChange = (id: string, role: ProjectReferenceImage['role']) => {
    const updated = referenceImages.map((img) => (img.id === id ? { ...img, role } : img));
    onUpdateReferenceImages(updated);
  };

  const handleNotesChange = (id: string, notes: string) => {
    const updated = referenceImages.map((img) => (img.id === id ? { ...img, notes } : img));
    onUpdateReferenceImages(updated);
  };

  const handleDelete = (id: string) => {
    const updated = referenceImages.filter((img) => img.id !== id);
    onUpdateReferenceImages(updated);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-[#121114] border border-[#26242a] rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#26242a] bg-[#161519]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-pink-500/10 border border-pink-500/20 flex items-center justify-center text-pink-400">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">Project Reference Photos</h2>
                <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-pink-500/20 text-pink-400 border border-pink-500/30">
                  {referenceImages.length} {referenceImages.length === 1 ? 'Photo' : 'Photos'}
                </span>
              </div>
              <p className="text-xs text-[#9d98a0]">
                Attach real-world photos as visual design context. Explicit text dimensions and measured notes override visual estimates.
              </p>
            </div>
          </div>
          {onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-[#9d98a0] hover:text-white hover:bg-[#201e24] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Body Content */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6">
          {errorMessage && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs flex items-center gap-2">
              <Info className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Camera Quick Action */}
          {onOpenCamera && (
            <div className="flex items-center justify-between gap-3 bg-[#18171f] border border-pink-500/30 p-3 rounded-xl shadow-xs">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-pink-500/10 border border-pink-500/30 flex items-center justify-center text-pink-400 shrink-0">
                  <Camera className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-white">Have a physical object?</div>
                  <div className="text-[11px] text-[#8c8694] truncate">Snap photos directly with your device camera</div>
                </div>
              </div>
              <button
                type="button"
                id="btn-ref-photos-open-camera"
                onClick={() => {
                  if (onClose) onClose();
                  onOpenCamera();
                }}
                className="px-3 py-1.5 bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-mono text-xs font-bold rounded-lg transition active:scale-95 cursor-pointer shrink-0 shadow-sm"
              >
                Open Camera
              </button>
            </div>
          )}

          {/* Upload Dropzone */}
          <div
            onDragEnter={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setDragActive(true);
            }}
            onDragOver={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setDragActive(true);
            }}
            onDragLeave={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setDragActive(false);
            }}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center gap-2 ${
              dragActive
                ? 'border-pink-500 bg-pink-500/10 scale-[0.99]'
                : 'border-[#2c2a32] hover:border-pink-500/40 bg-[#16151a]/60 hover:bg-[#191820]'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/jpeg,image/png,image/webp,image/heic,image/heif,.jpg,.jpeg,.png,.webp,.heic,.heif"
              onChange={handleFileInput}
              className="hidden"
            />
            <div className="w-12 h-12 rounded-full bg-[#201e26] border border-[#2f2d38] flex items-center justify-center text-pink-400">
              <Upload className="w-6 h-6" />
            </div>
            <div className="text-sm font-semibold text-white">
              {isProcessing ? 'Processing image files...' : 'Click or Drag & Drop Photos Here'}
            </div>
            <div className="text-xs text-[#8c8694]">
              PNG, JPG, WebP, HEIC/HEIF · up to 25MB each · maximum 6 photos. Images are optimized before AI use.
            </div>
          </div>

          {/* Photos Grid */}
          {referenceImages.length === 0 ? (
            <div className="text-center py-10 px-4 bg-[#141317] border border-[#232128] rounded-2xl">
              <Ruler className="w-10 h-10 text-[#54505c] mx-auto mb-3" />
              <h3 className="text-sm font-semibold text-white mb-1">No reference photos attached yet</h3>
              <p className="text-xs text-[#8c8694] max-w-md mx-auto">
                Tip: Photograph the physical object with calipers or a ruler next to it, or take front, side, and top angle photos to get high-accuracy parametric CAD.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {referenceImages.map((img, idx) => (
                <div
                  key={img.id}
                  className="bg-[#17161b] border border-[#292730] rounded-xl overflow-hidden flex flex-col group hover:border-[#3d3a48] transition-all"
                >
                  {/* Photo Preview Top */}
                  <div className="relative h-44 bg-black/60 overflow-hidden flex items-center justify-center">
                    <img
                      src={img.thumbnailDataUrl || img.dataUrl}
                      alt={img.filename || `Reference Photo ${idx + 1}`}
                      className="w-full h-full object-contain cursor-pointer"
                      onClick={() => setSelectedEnlargedImage(img)}
                    />
                    <div className="absolute top-2 left-2 flex items-center gap-1.5 px-2 py-1 rounded-md bg-black/80 backdrop-blur-md text-[11px] font-medium text-white border border-white/10">
                      <span>{CAMERA_ROLES.find((r) => r.id === img.role)?.icon || '📷'}</span>
                      <span>{CAMERA_ROLES.find((r) => r.id === img.role)?.label || 'General'}</span>
                    </div>
                    <div className="absolute top-2 right-2 flex items-center gap-1">
                      <button
                        onClick={() => setSelectedEnlargedImage(img)}
                        className="p-1.5 rounded-lg bg-black/80 text-white hover:bg-pink-600 transition-colors"
                        title="Enlarge Photo"
                      >
                        <Maximize2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(img.id)}
                        className="p-1.5 rounded-lg bg-black/80 text-red-400 hover:bg-red-600 hover:text-white transition-colors"
                        title="Remove Photo"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Metadata & Role Controls */}
                  <div className="p-3.5 space-y-3 flex-1 flex flex-col justify-between">
                    <div>
                      <label className="block text-[11px] font-semibold text-[#a8a3ad] uppercase tracking-wider mb-1">
                        Camera Angle / View Role
                      </label>
                      <select
                        value={img.role || 'unknown'}
                        onChange={(e) => handleRoleChange(img.id, e.target.value as any)}
                        className="w-full bg-[#1e1c24] border border-[#312e3b] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-pink-500"
                      >
                        {CAMERA_ROLES.map((r) => (
                          <option key={r.id} value={r.id}>
                            {r.icon} {r.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-[#a8a3ad] uppercase tracking-wider mb-1">
                        Caliper Dimensions & Key Features Notes
                      </label>
                      <input
                        type="text"
                        value={img.notes || ''}
                        onChange={(e) => handleNotesChange(img.id, e.target.value)}
                        placeholder="e.g. Outer width: 52mm, center hole: 6.2mm, screw pitch: 30mm"
                        className="w-full bg-[#1e1c24] border border-[#312e3b] rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-[#5e5a66] focus:outline-none focus:border-pink-500"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Caliper Reference Tips Box */}
          <div className="bg-[#151419] border border-[#24222b] rounded-xl p-4 flex items-start gap-3">
            <div className="w-7 h-7 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center shrink-0 mt-0.5">
              <Ruler className="w-4 h-4" />
            </div>
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-white">How Gemini Vision uses your reference photos:</h4>
              <p className="text-xs text-[#9d98a5] leading-relaxed">
                Attached reference photos are sent to Gemini as visual design context during AI generation and relevant AI revisions. Explicit dimensions and measured notes override visual estimates; unmeasured dimensions remain inferred rather than treated as exact.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#26242a] bg-[#161519] flex items-center justify-between">
          <div className="text-xs text-[#8c8694]">
            {referenceImages.length > 0 ? (
              <span className="text-emerald-400 font-medium flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                {referenceImages.length} reference {referenceImages.length === 1 ? 'photo' : 'photos'} ready for AI generation
              </span>
            ) : (
              'Photos will remain saved with this project.'
            )}
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-pink-500 hover:bg-pink-600 text-white font-semibold text-xs transition-all shadow-lg shadow-pink-500/20"
          >
            Done
          </button>
        </div>
      </div>

      {/* Enlarged Photo Modal */}
      {selectedEnlargedImage && (
        <div
          className="fixed inset-0 z-60 flex items-center justify-center bg-black/90 p-4"
          onClick={() => setSelectedEnlargedImage(null)}
        >
          <div className="relative max-w-5xl max-h-[90vh] flex flex-col items-center">
            <img
              src={selectedEnlargedImage.dataUrl}
              alt="Enlarged Reference"
              className="max-h-[80vh] max-w-full rounded-xl object-contain border border-[#33303d]"
            />
            <div className="mt-3 text-center text-sm font-medium text-white bg-black/80 px-4 py-2 rounded-xl border border-white/10">
              <span className="text-pink-400 font-bold">
                {CAMERA_ROLES.find((r) => r.id === selectedEnlargedImage.role)?.label}
              </span>
              {selectedEnlargedImage.notes && ` — "${selectedEnlargedImage.notes}"`}
            </div>
            <button
              onClick={() => setSelectedEnlargedImage(null)}
              className="absolute -top-3 -right-3 p-2 rounded-full bg-black text-white hover:text-pink-400 border border-white/20"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
