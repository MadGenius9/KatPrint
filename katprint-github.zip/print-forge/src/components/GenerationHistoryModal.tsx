import React from 'react';
import {
  GenerationRecord,
  PrinterSpec,
  FilamentSpec,
} from '../types';
import {
  History,
  X,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface GenerationHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: GenerationRecord[];
  currentPrinter: PrinterSpec;
  currentFilament: FilamentSpec;
  onReopenRecord: (record: GenerationRecord) => void;
  onLogResultForRecord: (record: GenerationRecord) => void;
}

export const GenerationHistoryModal: React.FC<GenerationHistoryModalProps> = ({
  isOpen,
  onClose,
  records,
  currentPrinter,
  currentFilament,
  onReopenRecord,
  onLogResultForRecord,
}) => {
  if (!isOpen) return null;

  // Calculate text-only stats
  const printedRecords = records.filter((r) => r.printResult !== undefined);
  const totalPrints = printedRecords.length;
  const successfulPrints = printedRecords.filter(
    (r) => r.printResult?.outcome === 'printed_ok'
  ).length;
  const overallSuccessRate =
    totalPrints > 0 ? Math.round((successfulPrints / totalPrints) * 100) : null;

  const currentPfRecords = printedRecords.filter(
    (r) =>
      (r.printer?.id === currentPrinter.id || r.printer?.name === currentPrinter.name) &&
      (r.filament?.id === currentFilament.id || r.filament?.name === currentFilament.name)
  );
  const currentPfTotal = currentPfRecords.length;
  const currentPfSuccess = currentPfRecords.filter(
    (r) => r.printResult?.outcome === 'printed_ok'
  ).length;
  const currentPfRate =
    currentPfTotal > 0 ? Math.round((currentPfSuccess / currentPfTotal) * 100) : null;

  const statsSummaryText = `Total prints: ${totalPrints} · Success rate: ${
    overallSuccessRate !== null ? `${overallSuccessRate}% (${successfulPrints}/${totalPrints})` : 'N/A'
  } · ${currentPrinter.name} + ${currentFilament.name}: ${
    currentPfRate !== null ? `${currentPfRate}% (${currentPfSuccess}/${currentPfTotal})` : 'N/A'
  }`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl max-h-[85vh] bg-kf-panel border border-kf-border rounded-xl p-5 shadow-2xl flex flex-col gap-4 text-kf-text"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-kf-border/80 pb-3">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-kf-pink" />
            <h2 className="text-base font-bold font-mono text-kf-text">
              Generation & Print History
            </h2>
            <span className="text-xs font-mono text-kf-muted bg-kf-panel-2 px-2 py-0.5 rounded border border-kf-border">
              {records.length} saved
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-md text-kf-muted hover:text-kf-text hover:bg-kf-panel-2 transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Section 6: Text-only Stats Summary */}
        <div className="bg-kf-panel-2 border border-kf-border/80 rounded-md px-3.5 py-2 font-mono text-xs text-kf-text select-text">
          {statsSummaryText}
        </div>

        {/* List of Generations */}
        <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-2.5">
          {records.length === 0 ? (
            <div className="text-center py-12 text-kf-muted font-mono text-xs">
              No generations recorded yet. Create a 3D model to begin logging history.
            </div>
          ) : (
            records.map((rec) => {
              const dateStr = new Date(rec.createdAt).toLocaleDateString(undefined, {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              });
              const outcome = rec.printResult?.outcome;

              return (
                <div
                  key={rec.id}
                  className="bg-kf-panel-2/50 border border-kf-border/70 hover:border-kf-border rounded-lg p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition"
                >
                  <div className="flex-1 min-w-0 flex flex-col gap-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold font-mono text-kf-text truncate max-w-[320px]">
                        {rec.prompt || 'CAD Model'}
                      </span>
                      {rec.source === 'template' && (
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-kf-border/40 text-kf-muted border border-kf-border/60">
                          template
                        </span>
                      )}
                      <span className="text-[11px] font-mono text-kf-muted">
                        {dateStr}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-[11px] font-mono text-kf-muted flex-wrap">
                      <span>{rec.printer?.name}</span>
                      <span>·</span>
                      <span>{rec.filament?.name}</span>
                      <span>·</span>
                      <span>
                        {rec.measuredDimensions.x.toFixed(0)}×
                        {rec.measuredDimensions.y.toFixed(0)}×
                        {rec.measuredDimensions.z.toFixed(0)}mm
                      </span>
                      {rec.parts && rec.parts.length > 1 && (
                        <>
                          <span>·</span>
                          <span className="text-kf-pink">{rec.parts.length} parts</span>
                        </>
                      )}
                      {rec.matingClearanceMm !== undefined && (
                        <>
                          <span>·</span>
                          <span>clearance: {rec.matingClearanceMm}mm</span>
                        </>
                      )}
                    </div>

                    {/* Print result status info if recorded */}
                    {rec.printResult && (
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        {outcome === 'printed_ok' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-mono font-semibold text-kf-ok bg-kf-ok/10 border border-kf-ok/30 px-2 py-0.5 rounded">
                            <CheckCircle2 className="w-3 h-3" />
                            Printed fine
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-mono font-semibold text-kf-fail bg-kf-fail/10 border border-kf-fail/30 px-2 py-0.5 rounded">
                            <AlertTriangle className="w-3 h-3" />
                            Failed
                            {rec.printResult.failureTags?.length > 0 &&
                              ` (${rec.printResult.failureTags.join(', ')})`}
                          </span>
                        )}
                        {rec.printResult.note && (
                          <span className="text-[11px] font-mono text-kf-muted italic truncate max-w-[280px]">
                            &quot;{rec.printResult.note}&quot;
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onLogResultForRecord(rec)}
                      className={`text-xs font-mono px-2.5 py-1.5 rounded border transition cursor-pointer flex items-center gap-1 ${
                        rec.printResult
                          ? 'bg-kf-panel hover:bg-kf-border text-kf-text border-kf-border'
                          : 'bg-kf-pink/10 hover:bg-kf-pink/20 text-kf-pink border-kf-pink/40'
                      }`}
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>{rec.printResult ? 'Edit Result' : 'Log Result'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onReopenRecord(rec);
                        onClose();
                      }}
                      className="text-xs font-mono px-2.5 py-1.5 rounded border bg-kf-panel hover:bg-kf-border text-kf-text border-kf-border transition cursor-pointer flex items-center gap-1"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Reopen</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
