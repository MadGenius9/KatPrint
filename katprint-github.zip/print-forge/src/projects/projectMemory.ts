import {
  ProjectMemory,
  DesignSpecification,
  ModelVersion,
  ProjectDesignState,
  DesignIntentStateDelta,
  ProjectReferenceImage,
  ReferenceImageObservation,
} from './projectTypes';
import type {
  DimensionRequirement,
  DesignFeature,
  PrintRequirement,
} from '../types';

export function createDefaultProjectDesignState(
  prompt: string,
  spec?: DesignSpecification
): ProjectDesignState {
  const explicitDims: DimensionRequirement[] = spec?.explicitDimensions ? [...spec.explicitDimensions] : [];
  const reqFeatures: DesignFeature[] = spec?.requiredFeatures ? [...spec.requiredFeatures] : [];
  const printReqs: PrintRequirement[] = spec?.printRequirements ? [...spec.printRequirements] : [];

  return {
    primaryGoal: prompt.trim(),
    intendedFunction: spec?.intendedFunction || 'Precision functional 3D CAD component',
    environment: spec?.targetUseCase || 'General indoor / desktop / workshop mechanical use',
    exactDimensions: explicitDims,
    lockedDimensions: explicitDims.filter((d) => d.isCritical || d.source === 'explicit'),
    requiredFeatures: reqFeatures,
    optionalFeatures: spec?.optionalFeatures ? [...spec.optionalFeatures] : [],
    forbiddenFeatures: [],
    partDefinitions: [],
    hardwareInterfaces: spec?.mountingRequirements ? [...spec.mountingRequirements] : [],
    matingInterfaces: spec?.fitRequirements ? spec.fitRequirements.map((f) => `${f.target} (${f.fitType} fit, ${f.clearanceMm}mm clearance)`) : [],
    aestheticIntent: spec?.aestheticRequirements ? [...spec.aestheticRequirements] : ['Clean precision engineering geometry with smooth fillets'],
    printConstraints: printReqs,
    referenceObjects: spec?.compatibilityTargets ? [...spec.compatibilityTargets] : [],
    userPreferences: [],
    importantDecisions: [],
    rejectedDirections: [],
    assumptions: spec?.assumptions ? [...spec.assumptions] : [],
    unresolvedQuestions: spec?.unresolvedQuestions ? [...spec.unresolvedQuestions] : [],
  };
}

export const initializeProjectDesignState = (prompt: string, spec?: DesignSpecification): ProjectDesignState => {
  return createDefaultProjectDesignState(prompt, spec);
};

export function mergeDesignStateWithSpecification(
  currentState: ProjectDesignState,
  spec: DesignSpecification
): ProjectDesignState {
  if (!currentState) {
    return createDefaultProjectDesignState(spec?.primaryObject || 'CAD Component', spec);
  }

  const merged: ProjectDesignState = {
    ...currentState,
    primaryGoal: currentState.primaryGoal || spec?.primaryObject || 'CAD Component',
    intendedFunction: spec?.intendedFunction || currentState.intendedFunction,
    environment: spec?.targetUseCase || currentState.environment,
    exactDimensions: [...currentState.exactDimensions],
    lockedDimensions: [...currentState.lockedDimensions],
    requiredFeatures: [...currentState.requiredFeatures],
    optionalFeatures: [...currentState.optionalFeatures],
    forbiddenFeatures: [...currentState.forbiddenFeatures],
    partDefinitions: [...currentState.partDefinitions],
    hardwareInterfaces: [...currentState.hardwareInterfaces],
    matingInterfaces: [...currentState.matingInterfaces],
    aestheticIntent: [...currentState.aestheticIntent],
    printConstraints: [...currentState.printConstraints],
    referenceObjects: [...currentState.referenceObjects],
    userPreferences: [...currentState.userPreferences],
    importantDecisions: [...currentState.importantDecisions],
    rejectedDirections: [...currentState.rejectedDirections],
    assumptions: [...currentState.assumptions],
    unresolvedQuestions: [...currentState.unresolvedQuestions],
  };

  // Merge explicit dimensions from spec without overriding locked dimensions unless explicitly critical
  if (Array.isArray(spec?.explicitDimensions)) {
    for (const d of spec.explicitDimensions) {
      const existingIdx = merged.exactDimensions.findIndex(
        (ed) => ed.axis === d.axis || (ed.name && d.name && ed.name.toLowerCase() === d.name.toLowerCase())
      );
      if (existingIdx >= 0) {
        const isLocked = merged.lockedDimensions.some(
          (ld) => ld.axis === d.axis || (ld.name && d.name && ld.name.toLowerCase() === d.name.toLowerCase())
        );
        if (!isLocked || d.isCritical) {
          merged.exactDimensions[existingIdx] = { ...merged.exactDimensions[existingIdx], ...d };
        }
      } else {
        merged.exactDimensions.push(d);
        if (d.isCritical) {
          merged.lockedDimensions.push(d);
        }
      }
    }
  }

  // Merge required features without duplicates or adding forbidden items
  if (Array.isArray(spec?.requiredFeatures)) {
    for (const f of spec.requiredFeatures) {
      if (!merged.requiredFeatures.some((rf) => rf.id === f.id || rf.name.toLowerCase() === f.name.toLowerCase())) {
        if (!merged.forbiddenFeatures.some((ff) => ff.toLowerCase() === f.name.toLowerCase())) {
          merged.requiredFeatures.push(f);
        }
      }
    }
  }

  // Merge optional features
  if (Array.isArray(spec?.optionalFeatures)) {
    for (const of of spec.optionalFeatures) {
      if (!merged.optionalFeatures.some((item) => item.id === of.id || item.name.toLowerCase() === of.name.toLowerCase())) {
        merged.optionalFeatures.push(of);
      }
    }
  }

  // Merge mounting requirements
  if (Array.isArray(spec?.mountingRequirements)) {
    for (const mr of spec.mountingRequirements) {
      if (!merged.hardwareInterfaces.includes(mr)) {
        merged.hardwareInterfaces.push(mr);
      }
    }
  }

  return merged;
}

export function updateDesignIntentState(
  currentState: ProjectDesignState,
  delta: DesignIntentStateDelta
): ProjectDesignState {
  const next: ProjectDesignState = {
    ...currentState,
    exactDimensions: [...currentState.exactDimensions],
    lockedDimensions: [...currentState.lockedDimensions],
    requiredFeatures: [...currentState.requiredFeatures],
    optionalFeatures: [...currentState.optionalFeatures],
    forbiddenFeatures: [...currentState.forbiddenFeatures],
    partDefinitions: [...currentState.partDefinitions],
    hardwareInterfaces: [...currentState.hardwareInterfaces],
    matingInterfaces: [...currentState.matingInterfaces],
    aestheticIntent: [...currentState.aestheticIntent],
    printConstraints: [...currentState.printConstraints],
    referenceObjects: [...currentState.referenceObjects],
    userPreferences: [...currentState.userPreferences],
    importantDecisions: [...currentState.importantDecisions],
    rejectedDirections: [...currentState.rejectedDirections],
    assumptions: [...currentState.assumptions],
    unresolvedQuestions: [...currentState.unresolvedQuestions],
  };

  if (delta.addConstraints && delta.addConstraints.length > 0) {
    for (const c of delta.addConstraints) {
      if (!next.importantDecisions.includes(c)) {
        next.importantDecisions.push(c);
      }
    }
  }

  if (delta.removeConstraints && delta.removeConstraints.length > 0) {
    next.importantDecisions = next.importantDecisions.filter(
      (c) => !delta.removeConstraints!.some((rc) => c.toLowerCase().includes(rc.toLowerCase()))
    );
  }

  if (delta.updateDimensions && delta.updateDimensions.length > 0) {
    for (const d of delta.updateDimensions) {
      const existingIdx = next.exactDimensions.findIndex(
        (ed) => ed.axis === d.axis || (ed.name && d.name && ed.name.toLowerCase() === d.name.toLowerCase())
      );
      if (existingIdx >= 0) {
        next.exactDimensions[existingIdx] = { ...next.exactDimensions[existingIdx], ...d };
      } else {
        next.exactDimensions.push(d);
      }

      const lockedIdx = next.lockedDimensions.findIndex(
        (ld) => ld.axis === d.axis || (ld.name && d.name && ld.name.toLowerCase() === d.name.toLowerCase())
      );
      if (lockedIdx >= 0) {
        next.lockedDimensions[lockedIdx] = { ...next.lockedDimensions[lockedIdx], ...d };
      } else if (d.isCritical) {
        next.lockedDimensions.push(d);
      }
    }
  }

  if (delta.addRequiredFeatures && delta.addRequiredFeatures.length > 0) {
    for (const f of delta.addRequiredFeatures) {
      if (!next.requiredFeatures.some((rf) => rf.id === f.id || rf.name.toLowerCase() === f.name.toLowerCase())) {
        next.requiredFeatures.push(f);
      }
    }
  }

  if (delta.removeFeatures && delta.removeFeatures.length > 0) {
    next.requiredFeatures = next.requiredFeatures.filter(
      (rf) => !delta.removeFeatures!.some((rem) => rf.id === rem || rf.name.toLowerCase().includes(rem.toLowerCase()))
    );
    for (const rem of delta.removeFeatures) {
      if (!next.forbiddenFeatures.includes(rem)) {
        next.forbiddenFeatures.push(rem);
      }
    }
  }

  if (delta.addRejectedDirections && delta.addRejectedDirections.length > 0) {
    for (const rej of delta.addRejectedDirections) {
      if (!next.rejectedDirections.includes(rej)) {
        next.rejectedDirections.push(rej);
      }
    }
  }

  if (delta.newAestheticIntent && delta.newAestheticIntent.length > 0) {
    for (const aes of delta.newAestheticIntent) {
      if (!next.aestheticIntent.includes(aes)) {
        next.aestheticIntent.push(aes);
      }
    }
  }

  if (delta.newAssumptions && delta.newAssumptions.length > 0) {
    for (const ass of delta.newAssumptions) {
      if (!next.assumptions.some((a) => a.assumption === ass.assumption)) {
        next.assumptions.push(ass);
      }
    }
  }

  return next;
}

export const applyStateDeltaToProjectDesignState = (
  currentState: ProjectDesignState,
  delta: any
): ProjectDesignState => {
  // Supports both raw DesignIntentStateDelta or test case structured delta
  const adaptedDelta: DesignIntentStateDelta = {
    addRequiredFeatures: delta.addedFeatures || delta.addRequiredFeatures || [],
    removeFeatures: delta.removedFeatures || delta.removeFeatures || [],
    updateDimensions: (delta.updatedDimensions || []).map((d: any) => ({
      name: d.name,
      value: d.currentValue ?? d.value ?? 0,
      unit: d.unit || 'mm',
      toleranceMm: d.toleranceMm || 0.2,
      source: d.source || 'explicit',
      critical: d.critical ?? true,
      category: d.category || 'outer',
    })),
    addConstraints: (delta.addedConstraints || delta.addConstraints || []).map((c: any) => typeof c === 'string' ? c : c.description || c.id || ''),
    removeConstraints: delta.removedConstraints || delta.removeConstraints || [],
    addRejectedDirections: delta.rejectedDirections || delta.addRejectedDirections || [],
    newAestheticIntent: delta.newAestheticIntent || [],
    newAssumptions: delta.newAssumptions || [],
    newOpenQuestions: delta.newOpenQuestions || [],
    summary: delta.summary || 'Applied delta update',
  };
  return updateDesignIntentState(currentState, adaptedDelta);
};

export function initializeProjectMemory(prompt: string, spec?: DesignSpecification): ProjectMemory {
  let width: number | undefined;
  let depth: number | undefined;
  let height: number | undefined;

  if (spec) {
    const explicit = Array.isArray(spec.explicitDimensions) ? spec.explicitDimensions : [];
    const critical = Array.isArray(spec.criticalDimensions) ? spec.criticalDimensions : [];
    const inferred = Array.isArray(spec.inferredDimensions) ? spec.inferredDimensions : [];
    const allDims = [...explicit, ...critical, ...inferred];
    for (const d of allDims) {
      if (!d) continue;
      const name = (typeof d === 'string' ? d : d.name || '').toLowerCase();
      const val = typeof d === 'object' && d !== null ? d.value : undefined;
      const axis = typeof d === 'object' && d !== null ? d.axis : undefined;
      if (typeof val === 'number') {
        if (axis === 'x' || name.includes('width') || name.includes('length')) width = val;
        if (axis === 'y' || name.includes('depth')) depth = val;
        if (axis === 'z' || name.includes('height')) height = val;
      }
    }
  }

  const memory: ProjectMemory = {
    objectPurpose: spec?.primaryObject || inferObjectPurposeFromPrompt(prompt),
    currentDimensions: width || depth || height ? { width, depth, height } : undefined,
    currentFeatures: spec?.requiredFeatures ? spec.requiredFeatures.map((f) => f.name) : [],
    compatibilityTargets: spec?.compatibilityTargets
      ? spec.compatibilityTargets.map((c) => (typeof c === 'string' ? c : c.name))
      : [],
    mountingInterfaces: spec?.mountingRequirements || [],
    importantDecisions: [],
    userRejectedOptions: [],
    unresolvedRequirements: [],
  };

  extractInitialDecisionsFromPrompt(prompt, memory);
  return memory;
}

export function updateProjectMemoryFromVersion(
  currentMemory: ProjectMemory = {},
  version: ModelVersion,
  userInstruction?: string
): ProjectMemory {
  const updated: ProjectMemory = { ...currentMemory };

  const spec = version.designSpecification;
  if (spec) {
    if (spec.primaryObject) updated.objectPurpose = spec.primaryObject;
    const explicit = Array.isArray(spec.explicitDimensions) ? spec.explicitDimensions : [];
    const critical = Array.isArray(spec.criticalDimensions) ? spec.criticalDimensions : [];
    const inferred = Array.isArray(spec.inferredDimensions) ? spec.inferredDimensions : [];
    const allDims = [...explicit, ...critical, ...inferred];
    let width = updated.currentDimensions?.width;
    let depth = updated.currentDimensions?.depth;
    let height = updated.currentDimensions?.height;

    for (const d of allDims) {
      if (!d) continue;
      const name = (typeof d === 'string' ? d : d.name || '').toLowerCase();
      const val = typeof d === 'object' && d !== null ? d.value : undefined;
      const axis = typeof d === 'object' && d !== null ? d.axis : undefined;
      if (typeof val === 'number') {
        if (axis === 'x' || name.includes('width') || name.includes('length')) width = val;
        if (axis === 'y' || name.includes('depth')) depth = val;
        if (axis === 'z' || name.includes('height')) height = val;
      }
    }

    if (width || depth || height) {
      updated.currentDimensions = { width, depth, height };
    }

    if (spec.requiredFeatures) {
      updated.currentFeatures = spec.requiredFeatures.map((f) => f.name);
    }
    if (spec.compatibilityTargets) {
      const targets = spec.compatibilityTargets.map((c) => (typeof c === 'string' ? c : c.name));
      updated.compatibilityTargets = Array.from(new Set([...(updated.compatibilityTargets || []), ...targets]));
    }
  }

  if (userInstruction) {
    extractUserConstraintsAndRejections(userInstruction, updated);
  }

  return updated;
}

export function extractUserConstraintsAndRejections(instruction: string, memory: ProjectMemory): void {
  const lower = instruction.toLowerCase();

  // Detect negative constraints (rejected options)
  const negativePatterns = [
    { pattern: /(?:don't|do not|no|never|without)\s+(?:use\s+)?(?:adhesive|tape|stickers?|glue)/i, item: 'No adhesive mounting (use screws/mechanical fasteners only)' },
    { pattern: /(?:don't|do not|no|never|without)\s+(?:supports?|overhangs?)/i, item: 'Strictly support-free 3D printing design' },
    { pattern: /(?:don't|do not|no|never)\s+(?:change|move|alter)\s+(?:the\s+)?(?:hole|spacing|holes)/i, item: 'Preserve exact mounting hole spacing' },
    { pattern: /(?:don't|do not|no|never|without)\s+(?:a\s+)?(?:lid|cover|top)/i, item: 'Open top design (no lid)' },
    { pattern: /(?:don't|do not|no|never|without)\s+(?:a\s+)?(?:bottom|floor)/i, item: 'Open bottom/pass-through design' },
    { pattern: /(?:keep|make)\s+(?:the\s+)?front\s+open/i, item: 'Keep front face unobstructed' },
    { pattern: /(?:don't|do not|no)\s+(?:sharp|square)\s+corners/i, item: 'All external corners must be filleted/rounded' },
  ];

  if (!memory.userRejectedOptions) memory.userRejectedOptions = [];
  if (!memory.importantDecisions) memory.importantDecisions = [];

  for (const { pattern, item } of negativePatterns) {
    if (pattern.test(lower) && !memory.userRejectedOptions.includes(item)) {
      memory.userRejectedOptions.push(item);
    }
  }

  // Detect positive permanent decisions
  if (lower.includes('countersunk') || lower.includes('countersink')) {
    if (!memory.importantDecisions.includes('Fastener holes must be countersunk')) {
      memory.importantDecisions.push('Fastener holes must be countersunk');
    }
  }
  if (lower.includes('waterproof') || lower.includes('hold liquid') || lower.includes('watertight')) {
    if (!memory.importantDecisions.includes('Solid watertight enclosure without bottom drainage')) {
      memory.importantDecisions.push('Solid watertight enclosure without bottom drainage');
    }
  }
  if (lower.includes('snap fit') || lower.includes('snap-fit')) {
    if (!memory.importantDecisions.includes('Snap-fit mechanical retention clips')) {
      memory.importantDecisions.push('Snap-fit mechanical retention clips');
    }
  }
}

function extractInitialDecisionsFromPrompt(prompt: string, memory: ProjectMemory): void {
  extractUserConstraintsAndRejections(prompt, memory);
}

function inferObjectPurposeFromPrompt(prompt: string): string {
  const p = prompt.trim();
  if (p.length < 50) return p;
  const words = p.split(/\s+/).slice(0, 8).join(' ');
  return `${words}...`;
}

// Re-export canonical hash-aware reference image caching utilities
export {
  getReferenceImageAnalysisHash,
  partitionCachedReferenceImages,
  mergeReferenceImageObservations,
  attachObservationsToReferenceImages,
} from '../utils/referenceImageHash';
