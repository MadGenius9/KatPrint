import { GenerationDiagnostics, GenerationMode, AIRequestRecord, GeometryInspectionStats, ModelGeometryStats } from '../types';

export interface CreateDiagnosticsParams {
  generationId: string;
  mode: GenerationMode;
  timestamp?: string | number;
  status?: 'idle' | 'generating' | 'success' | 'error';
  requestRecords?: AIRequestRecord[];
  modelsUsed?: string[];
  modelUsed?: string;
  repairAttempts?: number;
  totalDurationMs?: number;
  latencyMs?: number;
  intentClassification?: string;
  geometryMeasurements?: GeometryInspectionStats | ModelGeometryStats;
  measuredDimensions?: { x: number; y: number; z: number };
  measuredVolumeMm3?: number;
  polygonCount?: number;
  triangleCount?: number;
  vertexCount?: number;
  isManifold?: boolean;
  nonManifoldEdgeCount?: number;
  validationVerdict?: string;
  precisionScore?: number;
  securityCheckPassed?: boolean;
  semanticFeatureCount?: number;
  verifiedFeatureCount?: number;
  failedFeatureCount?: number;
  unknownFeatureCount?: number;
  bindingCount?: number;
  boundFeatureCount?: number;
  builderBoundFeatureCount?: number;
  criticalUnboundParameterCount?: number;
  missingBuilderFeatureCount?: number;
  unusedFeatureWrapperCount?: number;
  parameterEditCount?: number;
  featureAdditions?: number;
  featureRemovals?: number;
  featureModelVersion?: number;
  usedFallback?: boolean;
  fallbackReason?: string;
  plansRequested?: 1 | 3;
  plansReceived?: number;
  initialPlansReceived?: number;
  retryPlansReceived?: number;
  validPlansEvaluated?: number;
  distinctPlansEvaluated?: number;
  degradedMultiPlan?: boolean;
  degradedReason?: string;
  plansEvaluated?: number;
}

/**
 * Authoritative factory & aggregator for GenerationDiagnostics
 */
export function buildGenerationDiagnostics(params: CreateDiagnosticsParams): GenerationDiagnostics {
  const records = params.requestRecords || [];
  const requestsByPurpose: Record<string, number> = {};
  const discoveredModels = new Set<string>();

  for (const rec of records) {
    requestsByPurpose[rec.purpose] = (requestsByPurpose[rec.purpose] || 0) + 1;
    if (rec.model) {
      discoveredModels.add(rec.model);
    }
  }

  if (params.modelsUsed) {
    params.modelsUsed.forEach((m) => {
      if (m) discoveredModels.add(m);
    });
  }
  if (params.modelUsed) {
    discoveredModels.add(params.modelUsed);
  }

  const finalModels = Array.from(discoveredModels);
  const totalAIRequests = records.length;

  const successfulRecords = records.filter((record) => record.status === 'success');
  const lastSuccessfulRecord = successfulRecords.length > 0
    ? successfulRecords[successfulRecords.length - 1]
    : undefined;

  const modelUsed = params.modelUsed
    ?? lastSuccessfulRecord?.model
    ?? (records.length === 0 && finalModels.length > 0 ? finalModels[finalModels.length - 1] : undefined);

  return {
    generationId: params.generationId,
    timestamp: params.timestamp || Date.now(),
    status: params.status || 'success',
    mode: params.mode,
    totalAIRequests,
    requestsByPurpose,
    modelsUsed: finalModels,
    modelUsed,
    requestRecords: records,
    totalDurationMs: params.totalDurationMs || params.latencyMs,
    latencyMs: params.latencyMs || params.totalDurationMs,
    aiCallsMade: totalAIRequests,
    repairAttempts: params.repairAttempts ?? 0,
    intentClassification: params.intentClassification,
    geometryMeasurements: params.geometryMeasurements,
    measuredDimensions: params.measuredDimensions || params.geometryMeasurements?.dimensions,
    measuredVolumeMm3: params.measuredVolumeMm3 ?? (params.geometryMeasurements as any)?.actualVolumeMm3 ?? (params.geometryMeasurements as any)?.volumeMm3,
    polygonCount: params.polygonCount ?? (params.geometryMeasurements as any)?.polygonCount ?? params.geometryMeasurements?.triangleCount,
    triangleCount: params.triangleCount ?? params.geometryMeasurements?.triangleCount,
    vertexCount: params.vertexCount ?? params.geometryMeasurements?.vertexCount,
    isManifold: params.isManifold ?? params.geometryMeasurements?.isManifold,
    nonManifoldEdgeCount: params.nonManifoldEdgeCount ?? params.geometryMeasurements?.nonManifoldEdgeCount,
    validationVerdict: params.validationVerdict,
    precisionScore: params.precisionScore,
    securityCheckPassed: params.securityCheckPassed ?? true,
    semanticFeatureCount: params.semanticFeatureCount,
    verifiedFeatureCount: params.verifiedFeatureCount,
    failedFeatureCount: params.failedFeatureCount,
    unknownFeatureCount: params.unknownFeatureCount,
    bindingCount: params.bindingCount,
    boundFeatureCount: params.boundFeatureCount,
    builderBoundFeatureCount: params.builderBoundFeatureCount,
    criticalUnboundParameterCount: params.criticalUnboundParameterCount,
    missingBuilderFeatureCount: params.missingBuilderFeatureCount,
    unusedFeatureWrapperCount: params.unusedFeatureWrapperCount,
    parameterEditCount: params.parameterEditCount,
    featureAdditions: params.featureAdditions,
    featureRemovals: params.featureRemovals,
    featureModelVersion: params.featureModelVersion,
    usedFallback: params.usedFallback,
    fallbackReason: params.fallbackReason,
    plansRequested: params.plansRequested,
    plansReceived: params.plansReceived,
    initialPlansReceived: params.initialPlansReceived,
    retryPlansReceived: params.retryPlansReceived,
    validPlansEvaluated: params.validPlansEvaluated,
    distinctPlansEvaluated: params.distinctPlansEvaluated,
    degradedMultiPlan: params.degradedMultiPlan,
    degradedReason: params.degradedReason,
    plansEvaluated: params.plansEvaluated,
  };
}
