import { CadExample, CadExampleShapeClass } from '../types';
import { CAD_EXAMPLES } from '../prompts/cadExamples';

export const EXAMPLES_STORAGE_KEY = 'kf:examples';
export const MAX_USER_EXAMPLES = 50;

/**
 * Parses seed examples directly from cadExamples.ts
 */
function parseSeedPrograms(): { planterCode: string; trayCode: string; boxCode: string } {
  const rawParts = CAD_EXAMPLES.split(/(?=\/\/\s*EXAMPLE)/i);
  const parts = rawParts.map((p) => p.trim()).filter((p) => p.length > 0);

  return {
    planterCode: parts[0] || '',
    trayCode: parts[1] || '',
    boxCode: parts[2] || '',
  };
}

/**
 * Returns the 3 immutable seed examples derived from cadExamples.ts
 */
export function getSeedExamples(): CadExample[] {
  const { planterCode, trayCode, boxCode } = parseSeedPrograms();

  return [
    {
      id: 'seed_planter',
      title: 'Self-watering planter (single piece, subtract-based cavities)',
      prompt: 'A self watering planter with soil cavity, water reservoir, wicking channel, and side fill port',
      code: planterCode,
      shapeClass: 'container',
      keywords: [
        'planter',
        'pot',
        'reservoir',
        'soil',
        'cavity',
        'wick',
        'channel',
        'fill',
        'port',
        'self',
        'watering',
        'shelf',
        'container',
        'water',
      ],
      dimsMm: { x: 120, y: 120, z: 150 },
      isMultiPart: false,
      holdsLiquid: true,
      source: 'seed',
      createdAt: '2025-01-01T00:00:00.000Z',
      starred: true,
    },
    {
      id: 'seed_tray',
      title: 'Divided parts tray with finger notch (single piece)',
      prompt: 'A divided parts sorting tray with 3 compartments and finger notch for small hardware',
      code: trayCode,
      shapeClass: 'tray',
      keywords: [
        'tray',
        'compartment',
        'notch',
        'finger',
        'divider',
        'parts',
        'organizer',
        'sorting',
        'screw',
        'hardware',
      ],
      dimsMm: { x: 120, y: 80, z: 25 },
      isMultiPart: false,
      holdsLiquid: false,
      source: 'seed',
      createdAt: '2025-01-01T00:00:00.000Z',
      starred: true,
    },
    {
      id: 'seed_box',
      title: 'Two-piece box with stepped lid (multi-part ABI with mating clearance)',
      prompt: 'A two-piece storage box with stepped interlocking lid and calibrated mating clearance',
      code: boxCode,
      shapeClass: 'multi_part',
      keywords: [
        'box',
        'lid',
        'stepped',
        'lip',
        'clearance',
        'two',
        'piece',
        'case',
        'container',
        'multi',
        'part',
        'assembly',
        'base',
      ],
      dimsMm: { x: 80, y: 60, z: 50 },
      isMultiPart: true,
      holdsLiquid: false,
      source: 'seed',
      createdAt: '2025-01-01T00:00:00.000Z',
      starred: true,
    },
  ];
}

/**
 * Pure function: adds a user example to an existing list, enforcing cap at 50
 * by dropping the oldest un-favorited (starred !== true) item when full.
 */
export function addUserExampleWithCap(
  existingUserExamples: CadExample[],
  newExample: CadExample,
  maxCap: number = MAX_USER_EXAMPLES
): CadExample[] {
  const existingIdx = existingUserExamples.findIndex((e) => e.id === newExample.id);
  if (existingIdx >= 0) {
    const updated = [...existingUserExamples];
    updated[existingIdx] = newExample;
    return updated;
  }

  let list = [...existingUserExamples];
  if (list.length >= maxCap) {
    let oldestUnstarredIdx = -1;
    let oldestTimestamp = Infinity;

    for (let i = 0; i < list.length; i++) {
      if (!list[i].starred) {
        const time = new Date(list[i].createdAt).getTime();
        if (time < oldestTimestamp) {
          oldestTimestamp = time;
          oldestUnstarredIdx = i;
        }
      }
    }

    if (oldestUnstarredIdx >= 0) {
      list.splice(oldestUnstarredIdx, 1);
    } else {
      // If all are starred, drop oldest overall
      let oldestOverallIdx = 0;
      let oldestOverallTime = new Date(list[0].createdAt).getTime();
      for (let i = 1; i < list.length; i++) {
        const time = new Date(list[i].createdAt).getTime();
        if (time < oldestOverallTime) {
          oldestOverallTime = time;
          oldestOverallIdx = i;
        }
      }
      list.splice(oldestOverallIdx, 1);
    }
  }

  list.push(newExample);
  return list;
}

/**
 * Pure function: merges incoming examples with existing ones by ID without duplicates.
 */
export function mergeExamplesById(
  existingList: CadExample[],
  incomingList: CadExample[]
): { merged: CadExample[]; added: number; updated: number } {
  const map = new Map<string, CadExample>();
  for (const ex of existingList) {
    map.set(ex.id, ex);
  }

  let added = 0;
  let updated = 0;

  for (const inc of incomingList) {
    if (!inc || !inc.id || !inc.title || !inc.code) continue;
    if (map.has(inc.id)) {
      map.set(inc.id, { ...map.get(inc.id)!, ...inc });
      updated++;
    } else {
      map.set(inc.id, inc);
      added++;
    }
  }

  return {
    merged: Array.from(map.values()),
    added,
    updated,
  };
}

/**
 * Loads user examples from localStorage ('kf:examples').
 */
export function loadUserExamples(): CadExample[] {
  if (typeof window === 'undefined' || !window.localStorage) return [];
  try {
    const raw = window.localStorage.getItem(EXAMPLES_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.warn('Failed to read examples from localStorage:', err);
    return [];
  }
}

/**
 * Loads all examples (seeds + user examples).
 */
export function loadAllExamples(): CadExample[] {
  const seeds = getSeedExamples();
  const userExamples = loadUserExamples();
  return [...seeds, ...userExamples];
}

/**
 * Persists a user example to localStorage ('kf:examples'), capped at 50.
 */
export function saveUserExample(example: CadExample): CadExample[] {
  if (typeof window === 'undefined' || !window.localStorage) return [];
  try {
    const current = loadUserExamples();
    const updated = addUserExampleWithCap(current, {
      ...example,
      source: 'user',
      createdAt: example.createdAt || new Date().toISOString(),
    });
    window.localStorage.setItem(EXAMPLES_STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (err) {
    console.warn('Failed to save user example to localStorage:', err);
    return [];
  }
}

/**
 * Deletes a user example by ID from localStorage.
 */
export function deleteUserExample(id: string): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    const current = loadUserExamples();
    const updated = current.filter((e) => e.id !== id);
    window.localStorage.setItem(EXAMPLES_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn('Failed to delete user example from localStorage:', err);
  }
}

/**
 * Toggles the starred status of an example.
 */
export function toggleStarExample(id: string): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    const current = loadUserExamples();
    const updated = current.map((e) => {
      if (e.id === id) {
        return { ...e, starred: !e.starred };
      }
      return e;
    });
    window.localStorage.setItem(EXAMPLES_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn('Failed to toggle star for example in localStorage:', err);
  }
}

/**
 * Exports the library to a formatted JSON string.
 */
export function exportLibraryToJson(includeSeeds = true): string {
  const list = includeSeeds ? loadAllExamples() : loadUserExamples();
  return JSON.stringify(list, null, 2);
}

/**
 * Validates and imports examples from a JSON string, merging by ID into user storage.
 */
export function importLibraryFromJson(jsonStr: string): { success: boolean; added: number; updated: number; error?: string } {
  try {
    const parsed = JSON.parse(jsonStr);
    if (!Array.isArray(parsed)) {
      return { success: false, added: 0, updated: 0, error: 'JSON root must be an array of examples.' };
    }

    const validIncoming: CadExample[] = [];
    const validShapeClasses: Set<CadExampleShapeClass> = new Set([
      'container',
      'tray',
      'bracket',
      'multi_part',
      'flat',
      'organic',
      'other',
    ]);

    for (const item of parsed) {
      if (!item || typeof item !== 'object') continue;
      if (!item.id || typeof item.id !== 'string') continue;
      if (!item.title || typeof item.title !== 'string') continue;
      if (!item.code || typeof item.code !== 'string') continue;

      const shapeClass: CadExampleShapeClass = validShapeClasses.has(item.shapeClass)
        ? item.shapeClass
        : 'other';

      validIncoming.push({
        id: item.id,
        title: item.title,
        prompt: typeof item.prompt === 'string' ? item.prompt : item.title,
        code: item.code,
        shapeClass,
        keywords: Array.isArray(item.keywords) ? item.keywords.map(String) : [],
        dimsMm: item.dimsMm && typeof item.dimsMm === 'object'
          ? { x: Number(item.dimsMm.x) || 50, y: Number(item.dimsMm.y) || 50, z: Number(item.dimsMm.z) || 20 }
          : { x: 50, y: 50, z: 20 },
        isMultiPart: Boolean(item.isMultiPart),
        holdsLiquid: Boolean(item.holdsLiquid),
        source: item.source === 'seed' ? 'seed' : 'user',
        createdAt: item.createdAt || new Date().toISOString(),
        starred: Boolean(item.starred),
      });
    }

    if (validIncoming.length === 0) {
      return { success: false, added: 0, updated: 0, error: 'No valid CAD examples found in import.' };
    }

    // Merge incoming into current user examples
    // Filter out items that match seed ids so seeds are not modified in user storage
    const userIncoming = validIncoming.filter((e) => !e.id.startsWith('seed_'));
    const currentUser = loadUserExamples();
    const { merged, added, updated } = mergeExamplesById(currentUser, userIncoming);

    // Enforce cap if needed
    let capped = merged;
    if (capped.length > MAX_USER_EXAMPLES) {
      // Sort so starred are kept and oldest unstarred dropped
      while (capped.length > MAX_USER_EXAMPLES) {
        let oldestUnstarredIdx = -1;
        let oldestTimestamp = Infinity;
        for (let i = 0; i < capped.length; i++) {
          if (!capped[i].starred) {
            const time = new Date(capped[i].createdAt).getTime();
            if (time < oldestTimestamp) {
              oldestTimestamp = time;
              oldestUnstarredIdx = i;
            }
          }
        }
        if (oldestUnstarredIdx >= 0) {
          capped.splice(oldestUnstarredIdx, 1);
        } else {
          capped.shift();
        }
      }
    }

    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(EXAMPLES_STORAGE_KEY, JSON.stringify(capped));
    }

    return { success: true, added, updated };
  } catch (err: any) {
    return { success: false, added: 0, updated: 0, error: err.message || 'Malformed JSON' };
  }
}
