import { CadExample, CadExampleShapeClass } from '../types';
import { getSeedExamples } from './exampleLibrary';

const STOPWORDS = new Set([
  'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and', 'any', 'are', 'as', 'at',
  'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by',
  'can', 'could', 'did', 'do', 'does', 'doing', 'down', 'during',
  'each', 'few', 'for', 'from', 'further',
  'had', 'has', 'have', 'having', 'he', 'her', 'here', 'hers', 'herself', 'him', 'himself', 'his', 'how',
  'i', 'if', 'in', 'into', 'is', 'it', 'its', 'itself',
  'just', 'me', 'more', 'most', 'my', 'myself',
  'no', 'nor', 'not', 'now', 'of', 'off', 'on', 'once', 'only', 'or', 'other', 'our', 'ours', 'ourselves', 'out', 'over', 'own',
  'same', 'she', 'should', 'so', 'some', 'such',
  'than', 'that', 'the', 'their', 'theirs', 'them', 'themselves', 'then', 'there', 'these', 'they', 'this', 'those', 'through', 'to', 'too',
  'under', 'until', 'up', 'very',
  'was', 'we', 'were', 'what', 'when', 'where', 'which', 'while', 'who', 'whom', 'why', 'with', 'would',
  'you', 'your', 'yours', 'yourself', 'yourselves',
  // CAD common verbs and filler tokens
  'make', 'build', 'create', 'design', 'generate', 'model', 'print', 'printing', '3d', 'please', 'sized', 'having',
]);

/**
 * Crude stemmer: strips trailing s, es, ing, ed
 */
export function crudeStem(word: string): string {
  let w = word.toLowerCase();
  if (w.endsWith('ing') && w.length > 5) {
    return w.slice(0, -3);
  }
  if (w.endsWith('es') && w.length > 4) {
    return w.slice(0, -2);
  }
  if (w.endsWith('ed') && w.length > 4) {
    return w.slice(0, -2);
  }
  if (w.endsWith('s') && !w.endsWith('ss') && w.length > 3) {
    return w.slice(0, -1);
  }
  return w;
}

/**
 * Tokenizes text: lowercase, strip punctuation, drop stopwords, crude stem
 */
export function tokenizeAndStem(text: string | string[]): string[] {
  const str = Array.isArray(text) ? text.join(' ') : text;
  if (!str) return [];
  const cleaned = str.toLowerCase().replace(/[^a-z0-9]/g, ' ');
  const rawWords = cleaned.split(/\s+/).filter(Boolean);
  const result: string[] = [];

  for (const w of rawWords) {
    if (STOPWORDS.has(w)) continue;
    const stemmed = crudeStem(w);
    if (stemmed.length > 1 && !STOPWORDS.has(stemmed)) {
      result.push(stemmed);
    }
  }

  return Array.from(new Set(result));
}

/**
 * Computes Jaccard similarity: |A ∩ B| / |A ∪ B|
 */
export function computeJaccard(tokensA: string[], tokensB: string[]): number {
  if (tokensA.length === 0 || tokensB.length === 0) return 0;
  const setA = new Set(tokensA);
  const setB = new Set(tokensB);
  let intersection = 0;

  for (const t of setA) {
    if (setB.has(t)) intersection++;
  }

  const unionSize = new Set([...tokensA, ...tokensB]).size;
  return unionSize > 0 ? intersection / unionSize : 0;
}

/**
 * Classifies the prompt's shapeClass using the same keyword rules buildTextOnlyRequirements uses.
 */
export function classifyPromptShapeClass(prompt: string, requirements?: any): CadExampleShapeClass {
  const p = (prompt || '').toLowerCase();

  // Lid / cap -> multi_part
  const isMulti =
    Boolean(requirements?.isMultiPart) ||
    /\b(?:lid|cap|cover|insert)s?\b/i.test(p) ||
    /\b(?:(?:two|three|four|multi|2|3|4)[-\s]?(?:piece|pieces|part|parts|halves)|multi-?part|assembl(?:y|ies))\b/i.test(p) ||
    /\b(?:box|case|container|enclosure|housing|bin)\b[\s\S]*?\b(?:with|having|includes?|including|plus|\+)?[\s\S]*?\b(?:lid|top|cover|cap)\b/i.test(p);

  if (isMulti) {
    return 'multi_part';
  }

  // Tray / organizer
  if (/\b(?:tray|organizer|sorting\s+tray|divided\s+tray|caddy|drawer\s+organizer|compartment|dish)\b/i.test(p)) {
    return 'tray';
  }

  // Bracket / mount / hook
  if (/\b(?:bracket|mount|hook|hanger|holder|clamp|clip|stand|brace|hinge|adapter|guide)\b/i.test(p)) {
    return 'bracket';
  }

  // Flat: coaster, plate, badge
  if (/\b(?:coaster|plate|badge|plaque|sign|tag|disc|tile|stencil|ruler|keychain)\b/i.test(p)) {
    return 'flat';
  }

  // Container words
  if (/\b(?:container|planter|pot|vase|cup|bowl|mug|bottle|canister|jar|bucket|box|bin|reservoir|jug|hollow\s+cylinder)\b/i.test(p)) {
    return 'container';
  }

  // Organic
  if (/\b(?:sculpture|figurine|bust|animal|statue|character|face|skull|organic)\b/i.test(p)) {
    return 'organic';
  }

  return 'other';
}

/**
 * Deterministic similarity-based example selection.
 * No AI calls.
 */
export function selectExamples(
  prompt: string,
  requirements?: any,
  library?: CadExample[],
  k: number = 3
): CadExample[] {
  const seeds = getSeedExamples();
  const pool = library && library.length > 0 ? library : seeds;
  const p = (prompt || '').toLowerCase();

  const promptShapeClass = classifyPromptShapeClass(prompt, requirements);

  const promptIsMultiPart =
    requirements?.isMultiPart !== undefined
      ? Boolean(requirements.isMultiPart)
      : promptShapeClass === 'multi_part' ||
        /\b(?:lid|cap|cover|insert)s?\b/i.test(p) ||
        /\b(?:(?:two|three|four|multi|2|3|4)[-\s]?(?:piece|pieces|part|parts|halves)|multi-?part|assembl(?:y|ies))\b/i.test(p) ||
        /\b(?:box|case|container|enclosure|housing|bin)\b[\s\S]*?\b(?:with|having|includes?|including|plus|\+)?[\s\S]*?\b(?:lid|top|cover|cap)\b/i.test(p);

  const promptHoldsLiquid =
    requirements?.mustHoldLiquid !== undefined
      ? Boolean(requirements.mustHoldLiquid)
      : /(?:water|liquid|reservoir|planter|cup|vase|bowl)/i.test(p);

  const promptKeywords = tokenizeAndStem(prompt);

  // Score each candidate in the pool
  const scored = pool.map((example) => {
    const shapeClassMatch = promptShapeClass === example.shapeClass ? 1 : 0;
    const multiPartMatch = promptIsMultiPart === example.isMultiPart ? 1 : 0;
    const liquidMatch = promptHoldsLiquid === example.holdsLiquid ? 1 : 0;

    const exampleTokens = tokenizeAndStem(example.keywords);
    const jaccard = computeJaccard(promptKeywords, exampleTokens);
    const userBonus = example.source === 'user' ? 0.5 : 0;

    const score =
      3 * shapeClassMatch +
      2 * multiPartMatch +
      1 * liquidMatch +
      jaccard * 4 +
      userBonus;

    return {
      example,
      score,
      createdAtTime: new Date(example.createdAt).getTime() || 0,
    };
  });

  // Sort by score desc, ties broken by newest first
  scored.sort((a, b) => {
    if (Math.abs(b.score - a.score) > 0.0001) {
      return b.score - a.score;
    }
    return b.createdAtTime - a.createdAtTime;
  });

  const selected: CadExample[] = [];
  const seenCodes = new Set<string>();

  // Take top items with score > 0 and unique code
  for (const item of scored) {
    if (item.score <= 0) continue;
    const codeKey = item.example.code.trim();
    if (!seenCodes.has(codeKey)) {
      seenCodes.add(codeKey);
      selected.push(item.example);
      if (selected.length >= k) break;
    }
  }

  // If fewer than k score above 0, fill from seeds so there are always exactly k
  if (selected.length < k) {
    for (const seed of seeds) {
      const codeKey = seed.code.trim();
      if (!seenCodes.has(codeKey)) {
        seenCodes.add(codeKey);
        selected.push(seed);
        if (selected.length >= k) break;
      }
    }
  }

  return selected.slice(0, k);
}
