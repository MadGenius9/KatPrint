import { ProjectReferenceImage, ReferenceImageObservation } from '../types';

/**
 * Computes a fast, deterministic fingerprint hash for a reference image.
 * The hash will change whenever dataUrl, role, notes, or filename change.
 */
export function getReferenceImageAnalysisHash(image: ProjectReferenceImage): string {
  const data = image.dataUrl || '';
  const role = image.role || 'unknown';
  const notes = (image.notes || '').trim();
  const name = image.fileName || image.filename || '';

  // Sample data points to keep hashing instantaneous even for large 4MB base64 images
  const sampleLength = data.length;
  const sampleStart = data.slice(0, 128);
  const sampleMid = data.slice(Math.floor(sampleLength / 2), Math.floor(sampleLength / 2) + 128);
  const sampleEnd = data.slice(Math.max(0, sampleLength - 128));

  const composite = `${name}|${role}|${notes}|${sampleLength}|${sampleStart}|${sampleMid}|${sampleEnd}`;

  // 32-bit FNV-1a hash
  let hash = 0x811c9dc5;
  for (let i = 0; i < composite.length; i++) {
    hash ^= composite.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }

  return `obs_${(hash >>> 0).toString(16)}_${sampleLength}`;
}

/**
 * Checks which reference images already have valid cached analysis observations
 * and which need fresh analysis from Gemini.
 */
export function partitionCachedReferenceImages(images: ProjectReferenceImage[]): {
  cachedImages: Array<{ image: ProjectReferenceImage; observation: ReferenceImageObservation }>;
  uncachedImages: ProjectReferenceImage[];
} {
  const cachedImages: Array<{ image: ProjectReferenceImage; observation: ReferenceImageObservation }> = [];
  const uncachedImages: ProjectReferenceImage[] = [];

  images.forEach((img) => {
    const currentHash = getReferenceImageAnalysisHash(img);
    if (img.analysisObservation && img.analysisHash === currentHash) {
      cachedImages.push({ image: img, observation: img.analysisObservation });
    } else {
      uncachedImages.push(img);
    }
  });

  return { cachedImages, uncachedImages };
}

/**
 * Merges fresh analysis observations into the project's reference images
 * with updated hashes and timestamps.
 */
export function mergeReferenceImageObservations(
  originalImages: ProjectReferenceImage[],
  freshObservations: ReferenceImageObservation[]
): {
  updatedImages: ProjectReferenceImage[];
  allObservations: ReferenceImageObservation[];
} {
  const now = new Date().toISOString();
  const allObservations: ReferenceImageObservation[] = [];

  const updatedImages = originalImages.map((img, idx) => {
    const currentHash = getReferenceImageAnalysisHash(img);
    if (img.analysisObservation && img.analysisHash === currentHash) {
      allObservations.push(img.analysisObservation);
      return img;
    }

    // Find fresh observation corresponding to this image index or role
    const fresh = freshObservations.find(
      (obs) => obs.imageIndex === idx || (obs.role && obs.role.toLowerCase() === (img.role || '').toLowerCase())
    ) || freshObservations[idx];

    if (fresh) {
      allObservations.push(fresh);
      return {
        ...img,
        analysisObservation: fresh,
        analysisHash: currentHash,
        analyzedAt: now,
      };
    }

    return img;
  });

  return { updatedImages, allObservations };
}

/**
 * Attaches fresh observations to uncached images, calculating and setting analysisHash and analyzedAt.
 */
export function attachObservationsToReferenceImages(
  images: ProjectReferenceImage[] = [],
  uncachedImages: ProjectReferenceImage[] = [],
  newObservations: ReferenceImageObservation[] = []
): ProjectReferenceImage[] {
  const obsMap = new Map<string, ReferenceImageObservation>();
  uncachedImages.forEach((img, idx) => {
    if (newObservations[idx]) {
      obsMap.set(img.id, newObservations[idx]);
    }
  });

  const now = new Date().toISOString();
  return images.map((img) => {
    const obs = obsMap.get(img.id);
    if (obs) {
      const currentHash = getReferenceImageAnalysisHash(img);
      return {
        ...img,
        analysisObservation: obs,
        analysisHash: currentHash,
        analyzedAt: now,
      };
    }
    return img;
  });
}
