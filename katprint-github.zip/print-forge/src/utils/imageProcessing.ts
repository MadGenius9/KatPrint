/**
 * High-performance image processing, validation, resizing, and Object URL tracking
 * Supporting JPEG, PNG, WEBP, HEIC, and HEIF.
 */

export const SUPPORTED_IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.webp', '.heic', '.heif'];
export const SUPPORTED_MIME_TYPES = new Set([
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'image/heic',
  'image/heif',
]);

export const MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024; // 25 MB
export const AI_OPTIMAL_MAX_DIMENSION = 1800; // Optimal balance for vision quality vs upload speed
export const THUMBNAIL_MAX_DIMENSION = 320;

// Track active Object URLs to guarantee memory cleanup
const activeObjectUrls = new Set<string>();

export function createTrackedObjectURL(blob: Blob | File): string {
  const url = URL.createObjectURL(blob);
  activeObjectUrls.add(url);
  return url;
}

export function revokeTrackedObjectURL(url: string | null | undefined): void {
  if (url && activeObjectUrls.has(url)) {
    try {
      URL.revokeObjectURL(url);
    } catch {
      // ignore
    }
    activeObjectUrls.delete(url);
  }
}

export function revokeAllTrackedObjectURLs(): void {
  for (const url of activeObjectUrls) {
    try {
      URL.revokeObjectURL(url);
    } catch {
      // ignore
    }
  }
  activeObjectUrls.clear();
}

export interface ProcessedImageResult {
  originalFile: File;
  previewUrl: string; // Tracked Object URL for UI rendering
  dataUrlForAi: string; // Optimized resized data URL for Gemini API
  thumbnailUrl: string; // Lightweight thumbnail for lists
  width: number;
  height: number;
  format: string;
  aiMimeType: string; // MIME type that exactly matches dataUrlForAi
  sizeBytes: number;
  isHeic: boolean;
}

/**
 * Validates file size, format, and extension
 */
export function validateImageFile(file: File): { valid: boolean; error?: string } {
  if (!file) {
    return { valid: false, error: 'No file selected.' };
  }

  const nameLower = file.name.toLowerCase();
  const hasSupportedExt = SUPPORTED_IMAGE_EXTENSIONS.some((ext) => nameLower.endsWith(ext));
  const isSupportedMime = file.type ? SUPPORTED_MIME_TYPES.has(file.type.toLowerCase()) : false;

  if (!hasSupportedExt && !isSupportedMime) {
    return {
      valid: false,
      error: `Unsupported file format for "${file.name}". KatPrint supports JPEG, PNG, WEBP, and iPhone HEIC/HEIF photos.`,
    };
  }

  if (file.size <= 0) {
    return { valid: false, error: `File "${file.name}" appears to be empty (0 bytes).` };
  }

  if (file.size > MAX_FILE_SIZE_BYTES) {
    const sizeMb = (file.size / (1024 * 1024)).toFixed(1);
    return {
      valid: false,
      error: `File "${file.name}" is ${sizeMb} MB, which exceeds the 25 MB maximum limit.`,
    };
  }

  return { valid: true };
}

/**
 * Reads a File into a temporary data URL or ArrayBuffer
 */
function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error(`Failed to read file "${file.name}". It may be corrupt.`));
    reader.readAsDataURL(file);
  });
}

/**
 * Attempts to decode image via HTML Image element
 */
function decodeImage(sourceUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Browser could not decode image.'));
    img.src = sourceUrl;
  });
}

/**
 * Resizes an HTMLImageElement using an offscreen canvas
 */
function resizeImageToDataUrl(
  img: HTMLImageElement,
  maxDimension: number,
  format: 'image/jpeg' | 'image/png' = 'image/jpeg',
  quality = 0.85
): { dataUrl: string; width: number; height: number } {
  const naturalW = img.naturalWidth || img.width || 1;
  const naturalH = img.naturalHeight || img.height || 1;
  const scale = Math.min(1, maxDimension / Math.max(naturalW, naturalH));
  const width = Math.max(1, Math.round(naturalW * scale));
  const height = Math.max(1, Math.round(naturalH * scale));

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Could not obtain canvas 2D rendering context.');
  }

  // Draw smooth scaled image
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, width, height);

  return {
    dataUrl: canvas.toDataURL(format, format === 'image/jpeg' ? quality : undefined),
    width,
    height,
  };
}

/**
 * Generates an informative placeholder preview canvas for formats (like HEIC on older browsers)
 * that cannot be natively rendered in an <img> tag, but can still be sent to Gemini.
 */
function createHeicBadgePreview(fileName: string, sizeBytes: number): string {
  const canvas = document.createElement('canvas');
  canvas.width = 600;
  canvas.height = 400;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Background
  ctx.fillStyle = '#1A1418';
  ctx.fillRect(0, 0, 600, 400);

  // Border
  ctx.strokeStyle = '#FF3388';
  ctx.lineWidth = 4;
  ctx.strokeRect(10, 10, 580, 380);

  // Icon / Badge
  ctx.fillStyle = '#FF3388';
  ctx.font = 'bold 36px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('HEIC PHOTO', 300, 160);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = '20px sans-serif';
  ctx.fillText(fileName, 300, 210);

  const sizeMb = (sizeBytes / (1024 * 1024)).toFixed(1);
  ctx.fillStyle = '#A0A0A0';
  ctx.font = '16px monospace';
  ctx.fillText(`Size: ${sizeMb} MB • Ready for AI Analysis`, 300, 250);

  return canvas.toDataURL('image/png');
}

/**
 * Complete processing pipeline for uploaded files
 */
export async function processUploadedImage(
  file: File,
  onProgress?: (progressText: string) => void
): Promise<ProcessedImageResult> {
  const validation = validateImageFile(file);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  const nameLower = file.name.toLowerCase();
  const isHeic =
    nameLower.endsWith('.heic') ||
    nameLower.endsWith('.heif') ||
    file.type === 'image/heic' ||
    file.type === 'image/heif';

  onProgress?.('Reading photo file...');

  // Use a data URL during decoding so failed decodes cannot leak Object URLs.
  // Project state stores optimized image data, not temporary blob URLs.
  const previewObjectUrl = await readFileAsDataUrl(file);

  let dataUrlForAi = '';
  let thumbnailUrl = '';
  let width = 1200;
  let height = 900;

  if (isHeic) {
    // Check if current browser (e.g. Safari on iOS/Mac) can natively decode HEIC
    try {
      const decoded = await decodeImage(previewObjectUrl);
      width = decoded.naturalWidth;
      height = decoded.naturalHeight;
      const optimized = resizeImageToDataUrl(decoded, AI_OPTIMAL_MAX_DIMENSION, 'image/jpeg', 0.86);
      const thumb = resizeImageToDataUrl(decoded, THUMBNAIL_MAX_DIMENSION, 'image/jpeg', 0.78);
      dataUrlForAi = optimized.dataUrl;
      thumbnailUrl = thumb.dataUrl;
    } catch {
      // Browser does not decode HEIC in <img> tag, but Gemini supports HEIC natively!
      // Read original raw file as data URL to preserve full quality for Gemini
      onProgress?.('Preparing HEIC file for Gemini vision...');
      dataUrlForAi = await readFileAsDataUrl(file);
      thumbnailUrl = createHeicBadgePreview(file.name, file.size);
    }
  } else {
    // Standard formats (JPEG, PNG, WEBP)
    onProgress?.('Optimizing resolution for AI analysis...');
    const decoded = await decodeImage(previewObjectUrl);
    width = decoded.naturalWidth;
    height = decoded.naturalHeight;

    const optimized = resizeImageToDataUrl(decoded, AI_OPTIMAL_MAX_DIMENSION, 'image/jpeg', 0.86);
    const thumb = resizeImageToDataUrl(decoded, THUMBNAIL_MAX_DIMENSION, 'image/jpeg', 0.80);

    dataUrlForAi = optimized.dataUrl;
    thumbnailUrl = thumb.dataUrl;
  }

  const aiMimeMatch = dataUrlForAi.match(/^data:([^;]+);base64,/);
  const aiMimeType = aiMimeMatch?.[1] || file.type || 'image/jpeg';

  return {
    originalFile: file,
    previewUrl: thumbnailUrl || dataUrlForAi,
    dataUrlForAi,
    thumbnailUrl,
    width,
    height,
    format: isHeic ? 'heic' : file.type.replace('image/', '') || 'jpeg',
    aiMimeType,
    sizeBytes: file.size,
    isHeic,
  };
}
