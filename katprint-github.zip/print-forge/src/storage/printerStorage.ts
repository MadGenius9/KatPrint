import { PrinterSpec } from '../types';
import { INITIAL_PRINTERS } from '../data/printers';

const PRINTERS_STORAGE_KEY = 'katprint_printer_overrides_v1';

/**
 * Loads stored per-printer overrides (including measured clearance and custom specs)
 */
export function loadStoredPrinterOverrides(): Record<string, Partial<PrinterSpec>> {
  if (typeof window === 'undefined' || !window.localStorage) return {};
  try {
    const raw = window.localStorage.getItem(PRINTERS_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return typeof parsed === 'object' && parsed !== null ? parsed : {};
  } catch (err) {
    console.warn('Failed to read printer overrides from localStorage:', err);
    return {};
  }
}

/**
 * Persists an override for a given printer ID (e.g. clearance results or custom specs)
 */
export function saveStoredPrinterOverride(printerId: string, override: Partial<PrinterSpec>): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    const all = loadStoredPrinterOverrides();
    all[printerId] = { ...(all[printerId] || {}), ...override };
    window.localStorage.setItem(PRINTERS_STORAGE_KEY, JSON.stringify(all));
  } catch (err) {
    console.warn('Failed to save printer override to localStorage:', err);
  }
}

/**
 * Merges stored overrides over the static printer specifications
 */
export function getMergedPrinters(basePrinters: PrinterSpec[] = INITIAL_PRINTERS): PrinterSpec[] {
  const overrides = loadStoredPrinterOverrides();
  return basePrinters.map((printer) => {
    const override = overrides[printer.id];
    if (!override) return printer;
    return {
      ...printer,
      ...override,
      buildVolume: override.buildVolume ? { ...printer.buildVolume, ...override.buildVolume } : printer.buildVolume,
    };
  });
}
