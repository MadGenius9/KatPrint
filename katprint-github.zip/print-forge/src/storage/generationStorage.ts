import { GenerationRecord, PrintResult } from '../types';

export const GENERATIONS_STORAGE_KEY = 'kf:generations';
const MAX_GENERATIONS = 100;

/**
 * Loads stored generation records from localStorage ('kf:generations').
 */
export function loadGenerationRecords(): GenerationRecord[] {
  if (typeof window === 'undefined' || !window.localStorage) return [];
  try {
    const raw = window.localStorage.getItem(GENERATIONS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.warn('Failed to read generation records from localStorage:', err);
    return [];
  }
}

/**
 * Persists a new or updated generation record under 'kf:generations'.
 * Caps the history to the most recent 100 records.
 */
export function saveGenerationRecord(record: GenerationRecord): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    const current = loadGenerationRecords();
    const existingIndex = current.findIndex((r) => r.id === record.id);
    let updated: GenerationRecord[];
    if (existingIndex >= 0) {
      updated = [...current];
      updated[existingIndex] = { ...updated[existingIndex], ...record };
    } else {
      updated = [record, ...current];
    }
    // Cap at the most recent MAX_GENERATIONS
    if (updated.length > MAX_GENERATIONS) {
      updated = updated.slice(0, MAX_GENERATIONS);
    }
    window.localStorage.setItem(GENERATIONS_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn('Failed to save generation record to localStorage:', err);
  }
}

/**
 * Updates the printResult of a specific generation record by ID.
 */
export function updateGenerationPrintResult(generationId: string, result: PrintResult): GenerationRecord | null {
  if (typeof window === 'undefined' || !window.localStorage) return null;
  try {
    const current = loadGenerationRecords();
    const existingIndex = current.findIndex((r) => r.id === generationId);
    if (existingIndex < 0) return null;

    current[existingIndex] = {
      ...current[existingIndex],
      printResult: result,
    };
    window.localStorage.setItem(GENERATIONS_STORAGE_KEY, JSON.stringify(current));
    return current[existingIndex];
  } catch (err) {
    console.warn('Failed to update generation print result in localStorage:', err);
    return null;
  }
}

/**
 * Retrieves a single generation record by ID.
 */
export function getGenerationRecord(generationId: string): GenerationRecord | undefined {
  const all = loadGenerationRecords();
  return all.find((r) => r.id === generationId);
}
