import { PrinterSpec, FilamentSpec } from '../types';
import { classifyPromptIntent, matchKnownReference } from './promptClassifier';

// ---------------------------------------------------------------------------
// Text-Only Deterministic Requirements Extraction (Zero-Token Ingestion)
//
// Extracts primaryObject, overallDimensions, mustHoldLiquid, isMultiPart,
// and referenceObject without requiring an LLM call.
// ---------------------------------------------------------------------------
export function buildTextOnlyRequirements(
  prompt: string,
  printer?: PrinterSpec | null,
  filament?: FilamentSpec | null
): any {
  const p = prompt.toLowerCase();
  const intent = classifyPromptIntent(prompt);
  const knownRef = matchKnownReference(prompt);

  // 1. PRIMARY OBJECT — stop the noun-phrase match at the first digit.
  // Strip leading action verbs, leading article, and trailing whitespace/punctuation.
  let po = prompt.split(/\d/)[0];
  po = po.replace(/^(?:make|build|create|design|generate|3d\s+print(?:ing)?|model|please\s+(?:make|build|create)|print)\s+/i, '').trim();
  po = po.replace(/^(?:a|an|the)\s+/i, '').trim();
  po = po.replace(/[\s,;:\-]+$/, '').trim();
  po = po.replace(/\s+(?:with|for|that|having|in|to|of|and|sized|at|on)$/i, '').trim();
  po = po.replace(/[\s,;:\-]+$/, '').trim();
  const primaryObject = po || intent.primaryObject || 'functional part';

  function parseUnitValue(valStr: string, unitStr?: string): number {
    const val = parseFloat(valStr);
    if (isNaN(val)) return 0;
    const u = (unitStr || '').toLowerCase().trim();
    if (u === 'cm') return val * 10;
    if (u === 'in' || u === 'inch' || u === 'inches' || u === '"') return val * 25.4;
    return val; // default mm
  }

  let parsedLength: number | null = null;
  let parsedWidth: number | null = null;
  let parsedDepth: number | null = null;
  let parsedHeight: number | null = null;
  let parsedDiameter: number | null = null;
  let explicitWidthStated = false;
  let explicitDepthStated = false;

  // 2. "BY" TRIPLES / PAIRS
  // Handle "80 by 60 by 40" and "80 x 60 x 40" with no units (assume mm) and with units on any or all terms.
  // Map in order to length (x), width (y), height (z). Two-term "80 by 60" maps to x and y with height unset.
  // This must run before the per-axis keyword matches so a triple wins, but a later explicit "tall" still overrides z.
  const byMatch = prompt.match(
    /\b(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?\s*(?:[x×*]|\bby\b)\s*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?(?:\s*(?:[x×*]|\bby\b)\s*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?)?/i
  );
  if (byMatch) {
    const fallbackUnit = byMatch[6] || byMatch[4] || byMatch[2] || 'mm';
    const u1 = byMatch[2] || fallbackUnit;
    const u2 = byMatch[4] || fallbackUnit;
    const u3 = byMatch[6] || fallbackUnit;
    parsedLength = Number(parseUnitValue(byMatch[1], u1).toFixed(2));
    parsedWidth = Number(parseUnitValue(byMatch[3], u2).toFixed(2));
    explicitWidthStated = true;
    if (byMatch[5]) {
      parsedHeight = Number(parseUnitValue(byMatch[5], u3).toFixed(2));
    }
  }

  // 3. Per-axis keyword matches (explicit keywords override or populate)
  // Height/Z: tall, high, height, thickness, thick (an explicit "tall" overrides triple z)
  const heightMatch = prompt.match(
    /(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?\s*(?:tall|high|height|thickness|thick)\b|(?:tall|high|height|thickness|thick)[:\s]*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?/i
  );
  if (heightMatch) {
    const val = heightMatch[1] || heightMatch[3];
    const unit = heightMatch[2] || heightMatch[4];
    if (val) parsedHeight = Number(parseUnitValue(val, unit).toFixed(2));
  }

  // Width/X or Y: wide, width
  const widthMatch = prompt.match(
    /(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?\s*(?:wide|width)\b|(?:wide|width)[:\s]*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?/i
  );
  if (widthMatch) {
    const val = widthMatch[1] || widthMatch[3];
    const unit = widthMatch[2] || widthMatch[4];
    if (val) {
      parsedWidth = Number(parseUnitValue(val, unit).toFixed(2));
      explicitWidthStated = true;
    }
  }

  // Length: long, length
  const lengthMatch = prompt.match(
    /(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?\s*(?:long|length)\b|(?:long|length)[:\s]*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?/i
  );
  if (lengthMatch) {
    const val = lengthMatch[1] || lengthMatch[3];
    const unit = lengthMatch[2] || lengthMatch[4];
    if (val) parsedLength = Number(parseUnitValue(val, unit).toFixed(2));
  }

  // Depth: deep, depth
  const depthMatch = prompt.match(
    /(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?\s*(?:deep|depth)\b|(?:deep|depth)[:\s]*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?/i
  );
  if (depthMatch) {
    const val = depthMatch[1] || depthMatch[3];
    const unit = depthMatch[2] || depthMatch[4];
    if (val) {
      parsedDepth = Number(parseUnitValue(val, unit).toFixed(2));
      explicitDepthStated = true;
    }
  }

  // 4. DIAMETER — allow an optional "in" between the value and the keyword.
  // Must match all of:
  //   "120mm diameter", "120mm in diameter", "3 inches in diameter",
  //   "diameter 120mm", "120mm across", "120 mm dia", "4in OD"
  // When diameter is found, set width, depth, AND diameter to that value unless width/depth were stated explicitly.
  const diaValFirstMatch = prompt.match(
    /(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?\s*(?:in\s+|of\s+)?(?:diameter|dia|od|outer\s+diameter|across)\b/i
  );
  const diaKwFirstMatch = prompt.match(
    /\b(?:diameter|dia|od|outer\s+diameter)(?:\s+(?:of|is|in))?[:\s]*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in\b|")?/i
  );
  const diaMatch = diaValFirstMatch || diaKwFirstMatch;
  if (diaMatch) {
    const val = diaMatch[1];
    const unit = diaMatch[2];
    if (val) {
      parsedDiameter = Number(parseUnitValue(val, unit).toFixed(2));
      if (!explicitWidthStated) parsedWidth = parsedDiameter;
      if (!explicitDepthStated) parsedDepth = parsedDiameter;
      if (parsedLength === null) parsedLength = parsedDiameter;
    }
  }

  // 5. mustHoldLiquid: true if mentions water, liquid, reservoir, planter, cup, vase, bowl
  const mustHoldLiquid = /(?:water|liquid|reservoir|planter|cup|vase|bowl)/i.test(p);

  // 6. MULTI-PART — isMultiPart must be true if ANY of these hold:
  // - the prompt contains "lid", "cap", "cover", or "insert" (these pieces imply a second part)
  // - or the prompt mentions multiple parts ("2 parts", "two-part", "multi-part", "assembly")
  // - or the prompt asks for a box/case/container with a lid/top/cover
  const singleMultiKeywords = ['lid', 'cap', 'cover', 'insert'];
  const hasSingleMulti = singleMultiKeywords.some((kw) => new RegExp(`\\b${kw}s?\\b`, 'i').test(p));

  const multiPartMention = /\b(?:(?:two|three|four|multi|2|3|4)[-\s]?(?:piece|pieces|part|parts|halves)|multi-?part|assembl(?:y|ies))\b|\bin\s+(?:two|2)\s+halves\b/i.test(p);

  const containerWithTop = /\b(?:box|case|container|enclosure|housing|bin)\b[\s\S]*?\b(?:with|having|includes?|including|plus|\+)?[\s\S]*?\b(?:lid|top|cover|cap)\b/i.test(p);

  const secondaryMultiConcepts = [
    /\bbases?\b/i,
    /\b(?:body|bodies)\b/i,
    /\b(?:half|halves)\b/i,
    /\bpieces?\b/i,
    /\bparts?\b/i,
    /\btops?\b/i,
    /\bbottoms?\b/i,
    /\bshells?\b/i,
    /\bplugs?\b/i,
  ];
  const secondaryCount = secondaryMultiConcepts.filter((regex) => regex.test(p)).length;
  const hasTwoSecondary = secondaryCount >= 2;

  const isMultiPart = hasSingleMulti || multiPartMention || containerWithTop || hasTwoSecondary;

  const isInches = /inch|in\b|"/i.test(prompt);

  const reqsObj = {
    objectName: primaryObject ? primaryObject.toUpperCase() : prompt.slice(0, 35),
    primaryObject,
    classification: intent.classification,
    classificationConfidence: intent.confidence,
    classificationReason: intent.reason,
    inferredCategory: intent.classification === 'ORGANIC' ? 'ORGANIC_DECORATIVE' : 'PARAMETRIC_FUNCTIONAL',
    mountingStyle: 'freestanding',
    functionalRequirements: [
      ...intent.functionalRequirements,
      ...(mustHoldLiquid ? ['Watertight container geometry to hold liquid'] : []),
      ...(isMultiPart ? ['Multi-part interlocking assembly'] : []),
    ],
    decorativeRequirements: intent.decorativeRequirements,
    sculpturalRequirements: intent.sculpturalRequirements,
    isOrganicOnly: intent.classification === 'ORGANIC',
    units: isInches ? 'inches' : 'mm',
    overallDimensions: {
      width: parsedWidth,
      depth: parsedDepth ?? parsedWidth,
      height: parsedHeight,
      diameter: parsedDiameter,
      length: parsedLength ?? parsedWidth,
      rawInput: prompt,
    },
    wallThicknessMm: 3.0,
    matingClearanceMm: typeof printer?.measuredClearanceMm === 'number' ? printer.measuredClearanceMm : 0.25,
    mustHoldLiquid,
    isMultiPart,
    referenceObject: knownRef || (intent.referenceObject ? {
      name: intent.referenceObject,
      dimensions: { width: 80, depth: 80, height: 25, diameter: null },
      confidence: 'estimated',
      clearanceMm: 2.0,
      sourceNote: 'Derived from user reference',
    } : null),
    designPlan: {
      primaryObject: primaryObject || 'functional part',
      function: mustHoldLiquid ? 'Liquid holding utility' : 'Functional manufactured 3D print model',
      targetUseCase: 'General everyday utility',
      inferredCategory: 'PARAMETRIC_FUNCTIONAL',
      referenceObject: knownRef || null,
      inferredDimensions: {
        width: parsedWidth || parsedDiameter || 80,
        depth: parsedDepth || parsedLength || parsedDiameter || 80,
        height: parsedHeight || 25,
      },
      criticalDimensions: knownRef ? [`Fit clearance around ${knownRef.name}`] : ['Wall thickness 3.0mm'],
      mountingStyle: 'freestanding',
      structuralRequirements: ['Flat base at Z=0 for bed adhesion', 'Wall thickness 3.0mm'],
      ergonomicRequirements: ['Rounded outer corners'],
      aestheticRequirements: ['Clean CAD styling'],
      printConstraints: ['No unsupported overhangs steeper than 45°'],
      confidenceScore: 0.95,
      assumptions: ['Standard 3.0 mm wall thickness', 'Flat base at Z=0 for bed adhesion'],
      missingCriticalInfo: [],
      generationStrategy: isMultiPart ? 'Multi-Part Assembly with getParts()' : 'Parametric CSG Construction',
      keyFeatures: ['Parametric mechanical model based on: ' + prompt],
    },
    assumptionLedger: [
      {
        parameter: 'wallThickness',
        value: 3.0,
        unit: 'mm',
        basis: 'engineering_default',
        reasoning: 'Standard default durable wall thickness for FDM printing',
        confidence: 0.9,
        userEditable: true,
      },
    ],
    openQuestions: [],
    printOrientation: {
      recommendedUpAxis: '+Z (base on print bed)',
      reasoning: 'Print flat at Z=0 to maximize bed adhesion without supports',
      supportsRequired: false,
      maxOverhangAngleDeg: 45,
    },
    specConfidence: 0.95,
    specReviewIssues: [],
    explicitRequirements: [prompt],
    designDecisions: [
      'Selected durable 3.0 mm wall thickness',
      'Optimized base geometry for flat build-plate adhesion at Z=0',
    ],
    suggestedImprovements: [
      'Round outer corners by 5mm',
      'Add drainage slots or ribs',
      'Add mounting holes',
    ],
    unspecifiedProperties: [
      ...(parsedWidth === null && parsedDiameter === null ? ['Width not specified'] : []),
      ...(parsedDepth === null && parsedLength === null && parsedDiameter === null ? ['Depth not specified'] : []),
      ...(parsedHeight === null ? ['Height not specified'] : []),
    ],
    features: ['Parametric mechanical model based on: ' + prompt],
    quantities: {},
    spatialArrangements: [],
    fastenersOrHardware: [],
    tolerancesOrClearances: [],
    printConsiderations: ['Ensure base is flat at Z=0 for bed adhesion'],
    warnings: [],
  };

  return reqsObj;
}
