import { ExtractedRequirements, OpenQuestion } from '../types';

export interface ClarificationAssessment {
  needsClarification: boolean;
  isBlocking: boolean;
  reasons: string[];
  criticalQuestions: OpenQuestion[];
  riskyAssumptions: string[];
  confidence: number;
}

const CRITICAL_PARAM_HINTS = [
  'width', 'depth', 'height', 'length', 'diameter',
  'clearance', 'wall', 'thickness', 'mount', 'hole',
  'thread', 'fit', 'inner', 'cavity',
];

function isCriticalParamName(name: string): boolean {
  const n = name.toLowerCase();
  return CRITICAL_PARAM_HINTS.some((h) => n.includes(h));
}

export function assessClarificationNeeds(
  reqs: ExtractedRequirements | null | undefined
): ClarificationAssessment {
  if (!reqs) {
    return {
      needsClarification: true,
      isBlocking: true,
      reasons: ['No design requirements were extracted yet.'],
      criticalQuestions: [],
      riskyAssumptions: [],
      confidence: 0,
    };
  }

  const reasons: string[] = [];
  const criticalQuestions: OpenQuestion[] = [];
  const riskyAssumptions: string[] = [];

  const planConfidence =
    typeof reqs.designPlan?.confidenceScore === 'number'
      ? reqs.designPlan.confidenceScore > 1
        ? reqs.designPlan.confidenceScore / 100
        : reqs.designPlan.confidenceScore
      : null;

  const confidence =
    typeof reqs.specConfidence === 'number'
      ? reqs.specConfidence > 1
        ? reqs.specConfidence / 100
        : reqs.specConfidence
      : typeof reqs.classificationConfidence === 'number'
        ? reqs.classificationConfidence
        : planConfidence ?? 0.75;

  for (const q of reqs.openQuestions || []) {
    const conf = typeof q.confidence === 'number' ? q.confidence : 0.5;
    if (conf < 0.72) criticalQuestions.push(q);
  }

  const dims = reqs.overallDimensions || {};
  const hasAnyDim =
    dims.width != null ||
    dims.depth != null ||
    dims.height != null ||
    dims.diameter != null ||
    dims.length != null;

  if (!reqs.isOrganicOnly && !hasAnyDim && !reqs.referenceObject) {
    reasons.push('No overall dimensions or reference object were specified.');
  }

  const missing = reqs.designPlan?.missingCriticalInfo;
  if (Array.isArray(missing) && missing.length > 0) {
    reasons.push(`Missing critical info: ${missing.slice(0, 3).join('; ')}`);
  }

  if (confidence < 0.65) {
    reasons.push(`Design confidence is low (${Math.round(confidence * 100)}%).`);
  }

  for (const entry of reqs.assumptionLedger || []) {
    const conf =
      typeof entry.confidence === 'number'
        ? entry.confidence
        : entry.basis === 'engineering_default' || entry.basis === 'inferred_from_load'
          ? 0.35
          : entry.basis === 'measured_from_image'
            ? 0.6
            : 0.9;
    if (conf < 0.55 && isCriticalParamName(entry.parameter)) {
      riskyAssumptions.push(
        `${entry.parameter} (${entry.value}${entry.unit ? ' ' + entry.unit : ''}, ${entry.basis})`
      );
    }
  }

  if (criticalQuestions.length > 0) {
    reasons.push(
      `${criticalQuestions.length} open question${criticalQuestions.length === 1 ? '' : 's'} need your input.`
    );
  }
  if (riskyAssumptions.length > 0) {
    reasons.push(
      `${riskyAssumptions.length} low-confidence dimension${riskyAssumptions.length === 1 ? '' : 's'} were inferred.`
    );
  }

  const needsClarification =
    criticalQuestions.length > 0 ||
    reasons.length > 0 ||
    (riskyAssumptions.length >= 2 && confidence < 0.8);

  const isBlocking =
    criticalQuestions.length > 0 ||
    (!reqs.isOrganicOnly && !hasAnyDim && !reqs.referenceObject) ||
    confidence < 0.5;

  return {
    needsClarification,
    isBlocking,
    reasons,
    criticalQuestions,
    riskyAssumptions,
    confidence,
  };
}

export function ensureCriticalOpenQuestions(
  reqs: ExtractedRequirements
): ExtractedRequirements {
  const questions = [...(reqs.openQuestions || [])];
  const existingText = questions.map((q) => q.question.toLowerCase()).join(' | ');

  const dims = reqs.overallDimensions || {};
  const hasAnyDim =
    dims.width != null ||
    dims.depth != null ||
    dims.height != null ||
    dims.diameter != null ||
    dims.length != null;

  if (!reqs.isOrganicOnly && !hasAnyDim && !reqs.referenceObject) {
    if (!existingText.includes('size') && !existingText.includes('dimension')) {
      questions.push({
        id: 'synth_overall_size',
        question: 'What overall size should this part be (width × depth × height in mm)?',
        whyItMatters:
          'Without a target size the model may be unusable or too large for your printer.',
        assumedAnswer: 'Approximately 80 × 80 × 25 mm (compact desktop part)',
        confidence: 0.35,
      });
    }
  }

  if (
    reqs.referenceObject &&
    (reqs.referenceObject.confidence === 'estimated' || reqs.referenceObject.clearanceMm == null)
  ) {
    if (!existingText.includes('clearance') && !existingText.includes('fit')) {
      questions.push({
        id: 'synth_fit_clearance',
        question: `How snug should the fit be around the ${reqs.referenceObject.name}? (loose / snug / press-fit)`,
        whyItMatters: 'Fit tolerance determines whether the object drops in freely or locks in place.',
        assumedAnswer: `Loose fit with ~${reqs.referenceObject.clearanceMm ?? 2} mm clearance`,
        confidence: 0.45,
      });
    }
  }

  const missing = reqs.designPlan?.missingCriticalInfo;
  if (Array.isArray(missing)) {
    missing.slice(0, 2).forEach((info, i) => {
      const snippet = String(info).slice(0, 80);
      if (!existingText.includes(snippet.toLowerCase().slice(0, 20))) {
        questions.push({
          id: `synth_missing_${i}`,
          question: `Please clarify: ${snippet}`,
          whyItMatters: 'This was flagged as missing critical design information.',
          assumedAnswer: 'Use standard engineering defaults for this detail',
          confidence: 0.3,
        });
      }
    });
  }

  return { ...reqs, openQuestions: questions };
}
