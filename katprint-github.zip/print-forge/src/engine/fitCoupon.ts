/**
 * Deterministic Fit-Test Coupon Geometry & Mating Clearance Constants.
 * No AI calls anywhere in this module — the coupon is pure deterministic geometry.
 */

export const FIT_COUPON_CLEARANCES = [0.10, 0.15, 0.20, 0.25, 0.30, 0.40];

export const FIT_COUPON_JSCAD = `const pegDiameter = 10.0;
const clearances = [0.10, 0.15, 0.20, 0.25, 0.30, 0.40]; // per-side, mm
const socketDepth = 8.0;
const barThickness = 10.0;
const pitch = 18.0;
const barMargin = 6.0;
const notchSize = 1.2;
const pegLength = 14.0;
const gripDiameter = 16.0;
const gripHeight = 3.0;

function kpPart_bar() {
  const n = clearances.length;
  const barLength = pitch * n + barMargin * 2;
  const barWidth = pegDiameter + barMargin * 2 + 4;
  let bar = translate([0, 0, barThickness / 2], cuboid({ size: [barLength, barWidth, barThickness] }));
  const cuts = [];
  for (let i = 0; i < n; i++) {
    const x = -barLength / 2 + barMargin + pitch * i + pitch / 2;
    const d = pegDiameter + 2 * clearances[i];
    cuts.push(translate([x, 0, barThickness - socketDepth / 2 + 0.5],
      cylinder({ radius: d / 2, height: socketDepth + 1, segments: 96 })));
    for (let k = 0; k <= i; k++) {
      const nx = x - (i * notchSize) + k * notchSize * 2;
      cuts.push(translate([nx, barWidth / 2, barThickness - notchSize / 2 + 0.5],
        cuboid({ size: [notchSize, notchSize * 2, notchSize + 1] })));
    }
  }
  return subtract(bar, union(...cuts));
}

function kpPart_peg() {
  const grip = translate([0, 0, gripHeight / 2], cylinder({ radius: gripDiameter / 2, height: gripHeight, segments: 96 }));
  const shaft = translate([0, 0, gripHeight + pegLength / 2], cylinder({ radius: pegDiameter / 2, height: pegLength, segments: 96 }));
  return union(grip, shaft);
}

function getParts() {
  return [
    { id: 'bar', name: 'Socket Bar', quantity: 1, geometry: kpPart_bar() },
    { id: 'peg', name: 'Reference Peg', quantity: 1, geometry: kpPart_peg() },
  ];
}
function main() { return getParts().map((p) => p.geometry); }
`;

/**
 * Checks whether a generated program declares a clearance const that differs
 * from the printer's measured mating clearance by more than 0.05mm.
 */
export function checkClearanceConstMismatch(
  code: string,
  printer?: { measuredClearanceMm?: number } | null,
  requirements?: { matingClearanceMm?: number } | null
): { flag: boolean; message?: string; constName?: string; constValue?: number; expectedValue?: number } {
  const targetClearance = typeof printer?.measuredClearanceMm === 'number'
    ? printer.measuredClearanceMm
    : typeof requirements?.matingClearanceMm === 'number'
    ? requirements.matingClearanceMm
    : 0.25;

  const matches = [
    ...code.matchAll(/(?:^|\n)\s*const\s+([a-zA-Z0-9_]*(?:clearance|Clearance)[a-zA-Z0-9_]*)\s*=\s*(-?\d+(?:\.\d+)?)\s*;?/g),
  ];

  for (const match of matches) {
    const constName = match[1];
    const constVal = parseFloat(match[2]);
    if (Number.isFinite(constVal)) {
      const delta = Math.abs(constVal - targetClearance);
      if (delta > 0.05) {
        return {
          flag: true,
          message: `Clearance const is ${constVal.toFixed(2)}mm; this printer measured ${targetClearance.toFixed(2)}mm.`,
          constName,
          constValue: constVal,
          expectedValue: targetClearance,
        };
      }
    }
  }

  return { flag: false };
}
