import { ExecutedModelPart, PrinterSpec, PrintPlatePlan, PrintPlate, PlacedPartInstance } from '../types';

export interface PackingOptions {
  partSpacingMm?: number;
  bedMarginMm?: number;
  layerHeightMm?: number;
  printSpeedMmS?: number;
  infillPercent?: number;
}

interface PartInstanceToPack {
  instanceId: string;
  partId: string;
  partName: string;
  width: number;
  depth: number;
  height: number;
  volumeCm3: number;
  weightGrams: number;
  requiresSupports: boolean;
}

/**
 * Computes an optimal 2D guillotine/shelf nesting layout for multi-part 3D prints across one or more print beds.
 */
export function computePrintPlatePlan(
  parts: ExecutedModelPart[],
  printer: PrinterSpec,
  options: PackingOptions = {}
): PrintPlatePlan {
  const partSpacing = options.partSpacingMm ?? 10;
  const bedMargin = options.bedMarginMm ?? 10;
  const layerHeight = options.layerHeightMm ?? 0.2;
  const printSpeed = options.printSpeedMmS ?? 60;
  const infillFactor = ((options.infillPercent ?? 20) / 100) * 0.4 + 0.6; // Infill scaling factor

  const bedWidth = Math.max(50, printer.buildVolume.x - bedMargin * 2);
  const bedDepth = Math.max(50, printer.buildVolume.y - bedMargin * 2);
  const bedHeight = printer.buildVolume.z;

  const maxVolumetricFlow = printer.maxVolumetricFlow || 12;
  const nozzleDiameter = printer.nozzleDiameter || 0.4;

  // Flatten all part instances based on their required quantities
  const instancesToPlace: PartInstanceToPack[] = [];

  parts.forEach((part) => {
    const qty = Math.max(1, part.quantity || 1);
    const dims = part.stats?.dimensions || { x: 20, y: 20, z: 20 };
    const w = Math.max(1, dims.x);
    const d = Math.max(1, dims.y);
    const h = Math.max(1, dims.z);
    const vol = part.stats?.volumeCm3 || (w * d * h) / 1000;
    const weight = part.stats?.estimatedWeightGrams || vol * 1.24;

    for (let q = 1; q <= qty; q++) {
      instancesToPlace.push({
        instanceId: `${part.id}_inst_${q}`,
        partId: part.id,
        partName: qty > 1 ? `${part.name} (#${q})` : part.name,
        width: w,
        depth: d,
        height: h,
        volumeCm3: vol,
        weightGrams: weight,
        requiresSupports: !!part.requiresSupports,
      });
    }
  });

  // Split instances into oversized and packable before packing
  const packable: PartInstanceToPack[] = [];
  const oversized: PartInstanceToPack[] = [];

  for (const item of instancesToPlace) {
    const fitsZ = item.height <= bedHeight;
    const fitsBedNormal = item.width <= bedWidth && item.depth <= bedDepth;
    const fitsBedRotated = item.depth <= bedWidth && item.width <= bedDepth;

    if (fitsZ && (fitsBedNormal || fitsBedRotated)) {
      packable.push(item);
    } else {
      oversized.push(item);
    }
  }

  // Sort packable largest footprint first for efficient shelf packing
  packable.sort((a, b) => (b.width * b.depth) - (a.width * a.depth));

  const plates: PrintPlate[] = [];
  let plateCounter = 0;
  let unplaced = [...packable];

  while (unplaced.length > 0) {
    const currentPlateItems: PlacedPartInstance[] = [];
    const remainingForNextPlate: PartInstanceToPack[] = [];

    let currentX = -bedWidth / 2;
    let currentY = -bedDepth / 2;
    let rowMaxDepth = 0;
    let plateVol = 0;
    let plateWeight = 0;
    let plateAreaOccupied = 0;

    for (const item of unplaced) {
      let placedThisItem = false;

      // 1. Try fitting in current row (orientation 0 deg then 90 deg)
      const orientations = [
        { w: item.width, d: item.depth, rotZ: 0, rotDeg: 0 },
        { w: item.depth, d: item.width, rotZ: Math.PI / 2, rotDeg: 90 },
      ];

      for (const orient of orientations) {
        if (currentX + orient.w <= bedWidth / 2 && currentY + orient.d <= bedDepth / 2) {
          const posX = currentX + orient.w / 2;
          const posY = currentY + orient.d / 2;
          const posZ = 0;

          const placedInstance: PlacedPartInstance = {
            instanceId: item.instanceId,
            partId: item.partId,
            partName: item.partName,
            position: { x: posX, y: posY, z: posZ },
            rotationZ: orient.rotZ,
            rotationDeg: orient.rotDeg,
            dimensions: { x: orient.w, y: orient.d, z: item.height },
            width: orient.w,
            depth: orient.d,
            height: item.height,
            plateIndex: plateCounter,
            requiresSupports: item.requiresSupports,
            x: posX,
            y: posY,
            volumeCm3: item.volumeCm3,
            weightGrams: item.weightGrams,
          };

          currentPlateItems.push(placedInstance);
          plateVol += item.volumeCm3;
          plateWeight += item.weightGrams;
          plateAreaOccupied += (orient.w + partSpacing) * (orient.d + partSpacing);

          currentX += orient.w + partSpacing;
          rowMaxDepth = Math.max(rowMaxDepth, orient.d);
          placedThisItem = true;
          break;
        }
      }

      if (placedThisItem) continue;

      // 2. Try fitting on a new row (orientation 0 deg then 90 deg)
      for (const orient of orientations) {
        if (
          -bedWidth / 2 + orient.w <= bedWidth / 2 &&
          currentY + rowMaxDepth + partSpacing + orient.d <= bedDepth / 2
        ) {
          currentY += rowMaxDepth + partSpacing;
          currentX = -bedWidth / 2;
          rowMaxDepth = orient.d;

          const posX = currentX + orient.w / 2;
          const posY = currentY + orient.d / 2;
          const posZ = 0;

          const placedInstance: PlacedPartInstance = {
            instanceId: item.instanceId,
            partId: item.partId,
            partName: item.partName,
            position: { x: posX, y: posY, z: posZ },
            rotationZ: orient.rotZ,
            rotationDeg: orient.rotDeg,
            dimensions: { x: orient.w, y: orient.d, z: item.height },
            width: orient.w,
            depth: orient.d,
            height: item.height,
            plateIndex: plateCounter,
            requiresSupports: item.requiresSupports,
            x: posX,
            y: posY,
            volumeCm3: item.volumeCm3,
            weightGrams: item.weightGrams,
          };

          currentPlateItems.push(placedInstance);
          plateVol += item.volumeCm3;
          plateWeight += item.weightGrams;
          plateAreaOccupied += (orient.w + partSpacing) * (orient.d + partSpacing);

          currentX += orient.w + partSpacing;
          placedThisItem = true;
          break;
        }
      }

      if (!placedThisItem) {
        // Defer to next plate
        remainingForNextPlate.push(item);
      }
    }

    if (currentPlateItems.length > 0) {
      const totalVolumeMm3 = plateVol * 1000;
      const volumetricFlowMm3s = Math.min(maxVolumetricFlow, printSpeed * nozzleDiameter * layerHeight * 1.5);
      const printTimeSeconds = (totalVolumeMm3 / (volumetricFlowMm3s || 10)) * infillFactor + (currentPlateItems.length * 90);
      const printTimeMinutes = Math.max(12, Math.round(printTimeSeconds / 60));
      const occupiedPercent = Math.min(100, Math.round((plateAreaOccupied / (bedWidth * bedDepth)) * 100));

      plates.push({
        plateIndex: plateCounter,
        plateName: `Plate ${plateCounter + 1}`,
        items: currentPlateItems,
        instances: currentPlateItems,
        occupiedAreaPercent: occupiedPercent,
        totalVolumeCm3: plateVol,
        estimatedWeightGrams: plateWeight,
        estimatedPrintTimeMinutes: printTimeMinutes,
        fitsOnBed: true,
      });

      plateCounter++;
    }

    // Advance to next plate
    unplaced = remainingForNextPlate;
  }

  // Handle oversized parts on dedicated plates
  for (const item of oversized) {
    const totalVolumeMm3 = item.volumeCm3 * 1000;
    const volumetricFlowMm3s = Math.min(maxVolumetricFlow, printSpeed * nozzleDiameter * layerHeight * 1.5);
    const printTimeSeconds = (totalVolumeMm3 / (volumetricFlowMm3s || 10)) * infillFactor + 90;
    const printTimeMinutes = Math.max(12, Math.round(printTimeSeconds / 60));

    const placedInstance: PlacedPartInstance = {
      instanceId: item.instanceId,
      partId: item.partId,
      partName: `${item.partName} (Exceeds Bed Limits)`,
      position: { x: 0, y: 0, z: 0 },
      rotationZ: 0,
      rotationDeg: 0,
      dimensions: { x: item.width, y: item.depth, z: item.height },
      width: item.width,
      depth: item.depth,
      height: item.height,
      plateIndex: plateCounter,
      requiresSupports: item.requiresSupports,
      x: 0,
      y: 0,
      volumeCm3: item.volumeCm3,
      weightGrams: item.weightGrams,
    };

    plates.push({
      plateIndex: plateCounter,
      plateName: `Plate ${plateCounter + 1} (Oversized)`,
      items: [placedInstance],
      instances: [placedInstance],
      occupiedAreaPercent: 100,
      totalVolumeCm3: item.volumeCm3,
      estimatedWeightGrams: item.weightGrams,
      estimatedPrintTimeMinutes: printTimeMinutes,
      fitsOnBed: false,
    });

    plateCounter++;
  }

  const totalVol = plates.reduce((acc, p) => acc + p.totalVolumeCm3, 0);
  const totalWeight = plates.reduce((acc, p) => acc + p.estimatedWeightGrams, 0);
  const totalTime = plates.reduce((acc, p) => acc + p.estimatedPrintTimeMinutes, 0);
  const fitsAllOnOnePlate = plates.length === 1 && plates[0].fitsOnBed;

  return {
    plates,
    totalPlates: plates.length,
    fitsAllOnOnePlate,
    totalVolumeCm3: totalVol,
    totalEstimatedWeightGrams: totalWeight,
    totalEstimatedPrintTimeMinutes: totalTime,
    printerBedDimensions: {
      x: printer.buildVolume.x,
      y: printer.buildVolume.y,
      z: printer.buildVolume.z,
    },
  };
}
