import * as jscadModelingLib from '@jscad/modeling';
import { jscadGeomToThree, analyzeBufferGeometry } from './geometryUtils';
import { validateCadCodeSecurity } from './codeSecurity';
import { JSCAD_FEATURE_BUILDER_LIB, validateReservedBuilderUsage } from '../features/featureGenerators';
import { ModelAssemblyDefinition, ExecutedModel, ExecutedModelPart, ModelPartDefinition } from '../types';
import * as THREE from 'three';

// ---------------------------------------------------------------------------
// Helper to build enhanced JSCAD runtime scope with geometry chaining
// ---------------------------------------------------------------------------
function buildEnhancedJscadRuntime(modelingLib: any) {
  const rawJscad = (modelingLib as any)?.default?.primitives
    ? (modelingLib as any).default
    : (modelingLib as any)?.primitives
    ? (modelingLib as any)
    : ((modelingLib as any)?.default || (modelingLib as any) || {});

  const rawPrimitives = rawJscad.primitives || (modelingLib as any)?.primitives || {};
  const rawBooleans = rawJscad.booleans || (modelingLib as any)?.booleans || {};
  const rawTransforms = rawJscad.transforms || (modelingLib as any)?.transforms || {};
  const rawExtrusions = rawJscad.extrusions || (modelingLib as any)?.extrusions || {};
  const rawHulls = rawJscad.hulls || (modelingLib as any)?.hulls || {};
  const rawExpansions = rawJscad.expansions || (modelingLib as any)?.expansions || {};
  const rawGeometries = rawJscad.geometries || (modelingLib as any)?.geometries || {};
  const rawMeasurements = rawJscad.measurements || (modelingLib as any)?.measurements || {};
  const rawColors = rawJscad.colors || (modelingLib as any)?.colors || {};
  const rawMaths = rawJscad.maths || (modelingLib as any)?.maths || {};
  const rawUtils = rawJscad.utils || (modelingLib as any)?.utils || {};

  const normalizeVec3 = (arg0: any, arg1?: any, arg2?: any): [number, number, number] => {
    if (Array.isArray(arg0)) {
      return [Number(arg0[0]) || 0, Number(arg0[1]) || 0, Number(arg0[2]) || 0];
    }
    if (typeof arg0 === 'number') {
      return [arg0, Number(arg1) || 0, Number(arg2) || 0];
    }
    return [0, 0, 0];
  };

  const enhanceGeometry = (geom: any): any => {
    if (!geom || typeof geom !== 'object') return geom;
    if (Array.isArray(geom)) {
      for (let i = 0; i < geom.length; i++) {
        geom[i] = enhanceGeometry(geom[i]);
      }
      return geom;
    }
    if ((geom as any).__enhanced) return geom;

    try {
      Object.defineProperties(geom, {
        __enhanced: { value: true, writable: true, configurable: true },
        translate: {
          value: function (...args: any[]) {
            const offset = args.length === 1 && Array.isArray(args[0]) ? args[0] : normalizeVec3(args[0], args[1], args[2]);
            const res = rawTransforms.translate ? rawTransforms.translate(offset, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        rotate: {
          value: function (...args: any[]) {
            const angles = args.length === 1 && Array.isArray(args[0]) ? args[0] : normalizeVec3(args[0], args[1], args[2]);
            const res = rawTransforms.rotate ? rawTransforms.rotate(angles, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        rotateX: {
          value: function (rad: number) {
            const res = rawTransforms.rotateX ? rawTransforms.rotateX(rad, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        rotateY: {
          value: function (rad: number) {
            const res = rawTransforms.rotateY ? rawTransforms.rotateY(rad, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        rotateZ: {
          value: function (rad: number) {
            const res = rawTransforms.rotateZ ? rawTransforms.rotateZ(rad, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        scale: {
          value: function (...args: any[]) {
            let factors: any = args[0];
            if (typeof factors === 'number' && args.length === 1) {
              factors = [factors, factors, factors];
            } else if (typeof factors === 'number' && args.length >= 3) {
              factors = [factors, args[1], args[2]];
            }
            const res = rawTransforms.scale ? rawTransforms.scale(factors, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        center: {
          value: function (options: any = {}) {
            const res = rawTransforms.center ? rawTransforms.center(options, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        align: {
          value: function (options: any = {}) {
            const res = rawTransforms.align ? rawTransforms.align(options, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        mirror: {
          value: function (options: any = {}) {
            const res = rawTransforms.mirror ? rawTransforms.mirror(options, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
        subtract: {
          value: function (...cuts: any[]) {
            return enhanceGeometry(safeSubtract(this, ...cuts));
          },
          writable: true,
          configurable: true,
        },
        union: {
          value: function (...others: any[]) {
            return enhanceGeometry(safeUnion(this, ...others));
          },
          writable: true,
          configurable: true,
        },
        intersect: {
          value: function (...others: any[]) {
            return enhanceGeometry(safeIntersect(this, ...others));
          },
          writable: true,
          configurable: true,
        },
        colorize: {
          value: function (color: any) {
            const res = rawColors.colorize ? rawColors.colorize(color, this) : this;
            return enhanceGeometry(res);
          },
          writable: true,
          configurable: true,
        },
      });
    } catch {
      // Ignore if properties cannot be defined
    }
    return geom;
  };

  const safeCube = (options: any = {}) => {
    let opts = options;
    if (typeof opts === 'number') opts = { size: [opts, opts, opts] };
    else if (Array.isArray(opts)) opts = { size: opts };
    if (opts && Array.isArray(opts.size)) {
      if (typeof rawPrimitives.cuboid === 'function') return enhanceGeometry(rawPrimitives.cuboid(opts));
      if (typeof rawPrimitives.cube === 'function') return enhanceGeometry(rawPrimitives.cube(opts));
    }
    if (typeof rawPrimitives.cube === 'function') return enhanceGeometry(rawPrimitives.cube(opts));
    if (typeof rawPrimitives.cuboid === 'function') return enhanceGeometry(rawPrimitives.cuboid(opts));
    return null;
  };

  const safeRoundedCuboid = (options: any = {}) => {
    let opts = { ...options };
    if (opts.radius && !opts.roundRadius) opts.roundRadius = opts.radius;
    if (opts.round && !opts.roundRadius) opts.roundRadius = opts.round;
    if (!opts.roundRadius) opts.roundRadius = 1;
    if (typeof rawPrimitives.roundedCuboid === 'function') {
      try {
        return enhanceGeometry(rawPrimitives.roundedCuboid(opts));
      } catch {
        return safeCube(opts);
      }
    }
    return safeCube(opts);
  };

  const safeSubtract = (target: any, ...cuts: any[]) => {
    if (!target) return target;
    const flatCuts: any[] = [];
    for (const c of cuts) {
      if (Array.isArray(c)) flatCuts.push(...c);
      else if (c) flatCuts.push(c);
    }
    if (flatCuts.length === 0) return enhanceGeometry(target);
    if (typeof rawBooleans.subtract === 'function') {
      return enhanceGeometry(rawBooleans.subtract(target, ...flatCuts));
    }
    return enhanceGeometry(target);
  };

  const safeUnion = (...objects: any[]) => {
    const flat: any[] = [];
    for (const obj of objects) {
      if (Array.isArray(obj)) flat.push(...obj);
      else if (obj) flat.push(obj);
    }
    if (flat.length === 0) return null;
    if (flat.length === 1) return enhanceGeometry(flat[0]);
    if (typeof rawBooleans.union === 'function') {
      return enhanceGeometry(rawBooleans.union(...flat));
    }
    return enhanceGeometry(flat[0]);
  };

  const safeIntersect = (...objects: any[]) => {
    const flat: any[] = [];
    for (const obj of objects) {
      if (Array.isArray(obj)) flat.push(...obj);
      else if (obj) flat.push(obj);
    }
    if (typeof rawBooleans.intersect === 'function') {
      return enhanceGeometry(rawBooleans.intersect(...flat));
    }
    return enhanceGeometry(flat[0] || null);
  };

  const safeTranslate = (arg1: any, ...geoms: any[]) => {
    if (Array.isArray(arg1) || typeof arg1 === 'number') {
      const offset = normalizeVec3(arg1);
      const res = rawTransforms.translate ? rawTransforms.translate(offset, ...geoms) : geoms[0];
      return enhanceGeometry(res);
    }
    if (geoms.length > 0 && (Array.isArray(geoms[0]) || typeof geoms[0] === 'number')) {
      const offset = normalizeVec3(geoms[0]);
      const res = rawTransforms.translate ? rawTransforms.translate(offset, arg1) : arg1;
      return enhanceGeometry(res);
    }
    return enhanceGeometry(arg1);
  };

  const safeRotate = (arg1: any, ...geoms: any[]) => {
    if (Array.isArray(arg1) || typeof arg1 === 'number') {
      const angles = normalizeVec3(arg1);
      const res = rawTransforms.rotate ? rawTransforms.rotate(angles, ...geoms) : geoms[0];
      return enhanceGeometry(res);
    }
    if (geoms.length > 0 && (Array.isArray(geoms[0]) || typeof geoms[0] === 'number')) {
      const angles = normalizeVec3(geoms[0]);
      const res = rawTransforms.rotate ? rawTransforms.rotate(angles, arg1) : arg1;
      return enhanceGeometry(res);
    }
    return enhanceGeometry(arg1);
  };

  const safeRotateX = (rad: number, ...geoms: any[]) => {
    const res = rawTransforms.rotateX ? rawTransforms.rotateX(rad, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };

  const safeRotateY = (rad: number, ...geoms: any[]) => {
    const res = rawTransforms.rotateY ? rawTransforms.rotateY(rad, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };

  const safeRotateZ = (rad: number, ...geoms: any[]) => {
    const res = rawTransforms.rotateZ ? rawTransforms.rotateZ(rad, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };

  const safeScale = (factors: any, ...geoms: any[]) => {
    // If no geometry provided, return curried function: scale(factors)(geom)
    if (geoms.length === 0) {
      return (...lateGeoms: any[]) => safeScale(factors, ...lateGeoms);
    }
    // If geometry passed first: scale(geom, factors)
    if (
      factors &&
      (factors.polygons || factors.sides || (typeof factors === 'object' && !Array.isArray(factors))) &&
      (typeof geoms[0] === 'number' || Array.isArray(geoms[0]))
    ) {
      const swappedGeom = factors;
      let f = geoms[0];
      if (typeof f === 'number') f = [f, f, f];
      const res = rawTransforms.scale ? rawTransforms.scale(f, swappedGeom) : swappedGeom;
      return enhanceGeometry(res);
    }
    let f = factors;
    if (typeof f === 'number') f = [f, f, f];
    const res = rawTransforms.scale ? rawTransforms.scale(f, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };

  const safeCenter = (options: any, ...geoms: any[]) => {
    const res = rawTransforms.center ? rawTransforms.center(options || {}, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };

  const safeAlign = (options: any, ...geoms: any[]) => {
    const res = rawTransforms.align ? rawTransforms.align(options || {}, ...geoms) : geoms[0];
    return enhanceGeometry(res);
  };

  const safeCylinder = (options: any = {}) => {
    let opts = { ...options };
    if (opts.r && !opts.radius) opts.radius = opts.r;
    if (opts.h && !opts.height) opts.height = opts.h;
    if (opts.d && !opts.radius) opts.radius = opts.d / 2;
    if (typeof rawPrimitives.cylinder === 'function') {
      return enhanceGeometry(rawPrimitives.cylinder(opts));
    }
    return null;
  };

  const safeCone = (options: any = {}) => {
    let opts = { ...options };
    if (typeof rawPrimitives.cone === 'function') {
      return enhanceGeometry(rawPrimitives.cone(opts));
    }
    if (typeof rawPrimitives.cylinderElliptic === 'function') {
      return enhanceGeometry(
        rawPrimitives.cylinderElliptic({
          ...opts,
          startRadius: [opts.radius || opts.bottomRadius || 10, opts.radius || opts.bottomRadius || 10],
          endRadius: [opts.topRadius || 0, opts.topRadius || 0],
        })
      );
    }
    return safeCylinder(opts);
  };

  const safeSphere = (options: any = {}) => {
    let opts = typeof options === 'number' ? { radius: options } : { ...options };
    if (opts.r && !opts.radius) opts.radius = opts.r;
    if (opts.d && !opts.radius) opts.radius = opts.d / 2;
    if (typeof rawPrimitives.sphere === 'function') {
      return enhanceGeometry(rawPrimitives.sphere(opts));
    }
    return null;
  };

  const safeTorus = (options: any = {}) => {
    let opts = { ...options };
    if (typeof rawPrimitives.torus === 'function') {
      return enhanceGeometry(rawPrimitives.torus(opts));
    }
    return null;
  };

  const safeExtrudeLinear = (options: any, ...geoms: any[]) => {
    if (typeof rawExtrusions.extrudeLinear === 'function') {
      return enhanceGeometry(rawExtrusions.extrudeLinear(options, ...geoms));
    }
    return geoms[0];
  };

  const safeExtrudeRotate = (options: any, ...geoms: any[]) => {
    if (typeof rawExtrusions.extrudeRotate === 'function') {
      return enhanceGeometry(rawExtrusions.extrudeRotate(options, ...geoms));
    }
    return geoms[0];
  };

  const safeExtrudeRectangular = (options: any, ...geoms: any[]) => {
    if (typeof rawExtrusions.extrudeRectangular === 'function') {
      return enhanceGeometry(rawExtrusions.extrudeRectangular(options, ...geoms));
    }
    return geoms[0];
  };

  const safeHull = (...geoms: any[]) => {
    const flat: any[] = [];
    for (const g of geoms) {
      if (Array.isArray(g)) flat.push(...g);
      else if (g) flat.push(g);
    }
    if (typeof rawHulls.hull === 'function') {
      return enhanceGeometry(rawHulls.hull(...flat));
    }
    return flat[0] || null;
  };

  const safeHullChain = (...geoms: any[]) => {
    const flat: any[] = [];
    for (const g of geoms) {
      if (Array.isArray(g)) flat.push(...g);
      else if (g) flat.push(g);
    }
    if (typeof rawHulls.hullChain === 'function') {
      return enhanceGeometry(rawHulls.hullChain(...flat));
    }
    return flat[0] || null;
  };

  const safeColorize = (color: any, ...geoms: any[]) => {
    if (typeof rawColors.colorize === 'function') {
      return enhanceGeometry(rawColors.colorize(color, ...geoms));
    }
    return geoms[0];
  };

  const safeExpand = (options: any, ...geoms: any[]) => {
    if (typeof rawExpansions.expand === 'function') {
      return enhanceGeometry(rawExpansions.expand(options, ...geoms));
    }
    return geoms[0];
  };

  const safeOffset = (options: any, ...geoms: any[]) => {
    if (typeof rawExpansions.offset === 'function') {
      return enhanceGeometry(rawExpansions.offset(options, ...geoms));
    }
    return geoms[0];
  };

  // Build Sandbox Execution Context
  const sandboxContext = {
    // Top-level namespaced modules
    primitives: {
      cube: safeCube,
      cuboid: safeCube,
      roundedCuboid: safeRoundedCuboid,
      cylinder: safeCylinder,
      cylinderElliptic: rawPrimitives.cylinderElliptic || safeCylinder,
      cone: safeCone,
      sphere: safeSphere,
      torus: safeTorus,
      polygon: rawPrimitives.polygon || ((o: any) => o),
      rectangle: rawPrimitives.rectangle || ((o: any) => o),
      roundedRectangle: rawPrimitives.roundedRectangle || ((o: any) => o),
      circle: rawPrimitives.circle || ((o: any) => o),
      ellipse: rawPrimitives.ellipse || ((o: any) => o),
      star: rawPrimitives.star || ((o: any) => o),
      polyhedron: rawPrimitives.polyhedron || ((o: any) => o),
      line: rawPrimitives.line || ((o: any) => o),
      arc: rawPrimitives.arc || ((o: any) => o),
    },
    booleans: {
      subtract: safeSubtract,
      union: safeUnion,
      intersect: safeIntersect,
      scission: rawBooleans.scission || ((...g: any[]) => g),
    },
    transforms: {
      translate: safeTranslate,
      rotate: safeRotate,
      rotateX: safeRotateX,
      rotateY: safeRotateY,
      rotateZ: safeRotateZ,
      scale: safeScale,
      center: safeCenter,
      align: safeAlign,
      mirror: rawTransforms.mirror ? (...a: any[]) => enhanceGeometry(rawTransforms.mirror(...a)) : (o: any) => o,
      transform: rawTransforms.transform ? (...a: any[]) => enhanceGeometry(rawTransforms.transform(...a)) : (o: any) => o,
    },
    extrusions: {
      extrudeLinear: safeExtrudeLinear,
      extrudeRotate: safeExtrudeRotate,
      extrudeRectangular: safeExtrudeRectangular,
      slice: rawExtrusions.slice || ((o: any) => o),
    },
    hulls: {
      hull: safeHull,
      hullChain: safeHullChain,
    },
    expansions: {
      expand: safeExpand,
      offset: safeOffset,
    },
    measurements: rawMeasurements,
    colors: {
      colorize: safeColorize,
      colorNameToRgb: rawColors.colorNameToRgb || ((n: any) => [0.5, 0.5, 0.5, 1]),
      hexToRgb: rawColors.hexToRgb || ((h: any) => [0.5, 0.5, 0.5, 1]),
      rgbToHex: rawColors.rgbToHex || (() => '#888888'),
    },
    maths: rawMaths,
    utils: rawUtils,
    geometries: rawGeometries,

    // Direct global scope CAD functions for AI script convenience
    cube: safeCube,
    cuboid: safeCube,
    roundedCuboid: safeRoundedCuboid,
    cylinder: safeCylinder,
    cylinderElliptic: rawPrimitives.cylinderElliptic || safeCylinder,
    cone: safeCone,
    sphere: safeSphere,
    torus: safeTorus,
    polygon: rawPrimitives.polygon || ((o: any) => o),
    rectangle: rawPrimitives.rectangle || ((o: any) => o),
    roundedRectangle: rawPrimitives.roundedRectangle || ((o: any) => o),
    circle: rawPrimitives.circle || ((o: any) => o),
    ellipse: rawPrimitives.ellipse || ((o: any) => o),
    star: rawPrimitives.star || ((o: any) => o),
    polyhedron: rawPrimitives.polyhedron || ((o: any) => o),

    subtract: safeSubtract,
    union: safeUnion,
    intersect: safeIntersect,

    translate: safeTranslate,
    rotate: safeRotate,
    rotateX: safeRotateX,
    rotateY: safeRotateY,
    rotateZ: safeRotateZ,
    scale: safeScale,
    center: safeCenter,
    align: safeAlign,

    extrudeLinear: safeExtrudeLinear,
    extrudeRotate: safeExtrudeRotate,
    extrudeRectangular: safeExtrudeRectangular,

    hull: safeHull,
    hullChain: safeHullChain,
    expand: safeExpand,
    offset: safeOffset,
    colorize: safeColorize,

    // Math standard library
    Math: Math,
    degToRad: (deg: number) => (deg * Math.PI) / 180,
    radToDeg: (rad: number) => (rad * 180) / Math.PI,
  };

  const jscadObj: any = {
    primitives: sandboxContext.primitives,
    booleans: sandboxContext.booleans,
    transforms: sandboxContext.transforms,
    extrusions: sandboxContext.extrusions,
    hulls: sandboxContext.hulls,
    expansions: sandboxContext.expansions,
    measurements: sandboxContext.measurements,
    colors: sandboxContext.colors,
    maths: sandboxContext.maths,
    utils: sandboxContext.utils,
    geometries: sandboxContext.geometries,
    ...sandboxContext.primitives,
    ...sandboxContext.booleans,
    ...sandboxContext.transforms,
    ...sandboxContext.extrusions,
    ...sandboxContext.hulls,
    ...sandboxContext.expansions,
    ...sandboxContext.colors,
    scale: safeScale,
    translate: safeTranslate,
    rotate: safeRotate,
    union: safeUnion,
    subtract: safeSubtract,
    intersect: safeIntersect,
  };

  const safeRequire = (moduleName: string) => {
    const clean = (moduleName || '').trim().toLowerCase();
    if (clean.endsWith('/transforms') || clean.endsWith('.transforms')) return sandboxContext.transforms;
    if (clean.endsWith('/primitives') || clean.endsWith('.primitives')) return sandboxContext.primitives;
    if (clean.endsWith('/booleans') || clean.endsWith('.booleans')) return sandboxContext.booleans;
    if (clean.endsWith('/extrusions') || clean.endsWith('.extrusions')) return sandboxContext.extrusions;
    if (clean.endsWith('/hulls') || clean.endsWith('.hulls')) return sandboxContext.hulls;
    if (clean.endsWith('/expansions') || clean.endsWith('.expansions')) return sandboxContext.expansions;
    if (clean.endsWith('/measurements') || clean.endsWith('.measurements')) return sandboxContext.measurements;
    if (clean.endsWith('/colors') || clean.endsWith('.colors')) return sandboxContext.colors;
    return jscadObj;
  };

  Object.assign(sandboxContext, {
    jscad: jscadObj,
    jscadModeling: jscadObj,
    jscad_modeling: jscadObj,
    modeling: jscadObj,
    JSCAD: jscadObj,
    CSG: jscadObj,
    require: safeRequire,
  });

  return sandboxContext;
}

function combinePartGeometries(parts: ExecutedModelPart[]): THREE.BufferGeometry {
  const positions: number[] = [];
  const normals: number[] = [];
  for (const part of parts) {
    const geom = part.geometry;
    const pos = geom?.getAttribute?.('position');
    const norm = geom?.getAttribute?.('normal');
    if (!pos) continue;
    for (let i = 0; i < pos.count; i++) {
      positions.push(pos.getX(i), pos.getY(i), pos.getZ(i));
      if (norm) normals.push(norm.getX(i), norm.getY(i), norm.getZ(i));
      else normals.push(0, 0, 1);
    }
  }
  const combined = new THREE.BufferGeometry();
  if (positions.length > 0) {
    combined.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    combined.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
    combined.computeBoundingBox();
    combined.computeBoundingSphere();
  }
  return combined;
}

/**
 * Executes JSCAD JavaScript code in a client-side sandbox and resolves both single and multi-part geometries
 */
export function executeJscadModel(
  code: string,
  assemblyDef?: ModelAssemblyDefinition | null
): ExecutedModel {
  if (!code || typeof code !== 'string' || !code.trim()) {
    throw new Error('JSCAD_EXECUTION_ERROR: Empty script provided.');
  }

  // 1. Security scan
  const sec = validateCadCodeSecurity(code);
  if (!sec.isSafe) {
    throw new Error(`SECURITY_REJECTION: ${sec.violations.join('; ')}`);
  }

  // 2. Clean imports or require lines that might linger from raw code blocks
  let cleanCode = code
    .replace(/^\s*import\s+.*?from\s+['"].*?['"];?/gm, '')
    .replace(/^\s*const\s+.*?=\s*require\(.*?\);?/gm, '')
    .replace(/\b(?:const|let|var)\s*\{([^}]+)\}\s*=\s*require\(.*?\);?/g, '')
    .replace(/^\s*(?:const|let|var)\s*\{[^}]+\}\s*=\s*(?:primitives|booleans|transforms|extrusions|hulls|expansions|colors|jscad)(?:\.[a-zA-Z0-9_$]+)?\s*;?/gm, '');

  // Handle variable declarations of 'scale' that shadow the JSCAD scale() transform function
  if (/\b(?:const|let|var)\s+scale\s*=/g.test(cleanCode)) {
    cleanCode = cleanCode.replace(/\b(const|let|var)\s+scale\s*=/g, '$1 scaleFactor =');
    cleanCode = cleanCode.replace(/(\b)(?<![\.\_])scale\b(?!\s*[\(\[])/g, '$1scaleFactor');
  }

  // Handle common dimension variable collisions like offset or slice
  if (/\b(?:const|let|var)\s+offset\s*=\s*[0-9]/g.test(cleanCode)) {
    cleanCode = cleanCode.replace(/\b(const|let|var)\s+offset\s*=/g, '$1 offsetDistance =');
    cleanCode = cleanCode.replace(/(\b)(?<![\.\_])offset\b(?!\s*[\(\[])/g, '$1offsetDistance');
  }
  if (/\b(?:const|let|var)\s+slice\s*=\s*[0-9]/g.test(cleanCode)) {
    cleanCode = cleanCode.replace(/\b(const|let|var)\s+slice\s*=/g, '$1 sliceThickness =');
    cleanCode = cleanCode.replace(/(\b)(?<![\.\_])slice\b(?!\s*[\(\[])/g, '$1sliceThickness');
  }

  cleanCode = cleanCode.trim();

  // 3. Reject reserved builder redefinitions
  const reservedErr = validateReservedBuilderUsage(cleanCode);
  if (reservedErr) {
    const err: any = new Error(`RESERVED_BUILDER_REDEFINITION: ${reservedErr.message}`);
    err.code = 'RESERVED_BUILDER_REDEFINITION';
    throw err;
  }

  // 4. Prepare sandbox execution scope
  const sandbox = buildEnhancedJscadRuntime(jscadModelingLib);
  const sandboxKeys = Object.keys(sandbox);
  const sandboxValues = Object.values(sandbox);

  let compiledFn: Function;
  try {
    const wrapped = `
      ${JSCAD_FEATURE_BUILDER_LIB}

      ${cleanCode}

      return {
        main: typeof main === 'function' ? main : null,
        getParts: typeof getParts === 'function' ? getParts : null,
        getAssembly: typeof getAssembly === 'function' ? getAssembly : null,
        callFunction: function(name) {
          try {
            return eval('typeof ' + name + ' === "function" ? ' + name + '() : null');
          } catch(e) {
            return null;
          }
        },
        hasFunction: function(name) {
          try {
            return eval('typeof ' + name + ' === "function"');
          } catch(e) {
            return false;
          }
        }
      };
    `;
    // eslint-disable-next-line @typescript-eslint/no-implied-eval
    compiledFn = new Function(...sandboxKeys, wrapped);
  } catch (parseErr: any) {
    throw new Error(`JSCAD_EXECUTION_ERROR: Syntax error in script: ${parseErr.message}`);
  }

  let executionEnv: any;
  try {
    executionEnv = compiledFn(...sandboxValues);
  } catch (runtimeErr: any) {
    throw new Error(`JSCAD_EXECUTION_ERROR: Runtime failure: ${runtimeErr.message}`);
  }

  // 5. Part Discovery & Execution
  const discoveredParts: ExecutedModelPart[] = [];

  // A. Check if explicit assemblyDef is provided
  if (assemblyDef && Array.isArray(assemblyDef.parts) && assemblyDef.parts.length > 0) {
    for (const partDef of assemblyDef.parts) {
      let partSolids: any = null;
      if (partDef.cadFunctionName && executionEnv.hasFunction(partDef.cadFunctionName)) {
        partSolids = executionEnv.callFunction(partDef.cadFunctionName);
      } else if (executionEnv.hasFunction(`kpPart_${partDef.id}`)) {
        partSolids = executionEnv.callFunction(`kpPart_${partDef.id}`);
      } else if (executionEnv.hasFunction(`part_${partDef.id}`)) {
        partSolids = executionEnv.callFunction(`part_${partDef.id}`);
      }

      if (partSolids) {
        try {
          const geom = jscadGeomToThree(partSolids);
          const stats = analyzeBufferGeometry(geom);
          discoveredParts.push({
            id: partDef.id,
            name: partDef.name || partDef.id,
            quantity: partDef.quantity || 1,
            geometry: geom,
            featureIds: partDef.featureIds || [],
            stats,
            boundingBox: {
              x: stats.dimensions.x,
              y: stats.dimensions.y,
              z: stats.dimensions.z,
            },
            requiresSupports: stats.hasSteepOverhangs || stats.overhangRatio > 0.1,
          });
        } catch (convErr: any) {
          console.warn(`Failed to convert part ${partDef.id}:`, convErr);
        }
      }
    }
  }

  // B. If no parts resolved from assemblyDef, check getParts() ABI
  if (discoveredParts.length === 0 && executionEnv.getParts) {
    try {
      const partsResult = executionEnv.getParts();
      if (!Array.isArray(partsResult)) {
        throw new Error('getParts() must return an array of part metadata objects.');
      }
      {
        for (let i = 0; i < partsResult.length; i++) {
          const p = partsResult[i];
          const rawSolids = p?.solid || p?.geometry || p;
          if (rawSolids) {
            const geom = jscadGeomToThree(rawSolids);
            const stats = analyzeBufferGeometry(geom);
            const id = p?.id || `part_${i + 1}`;
            discoveredParts.push({
              id,
              name: p?.name || `Part ${i + 1}`,
              quantity: typeof p?.quantity === 'number' ? p.quantity : 1,
              geometry: geom,
              featureIds: p?.featureIds || [],
              stats,
              boundingBox: {
                x: stats.dimensions.x,
                y: stats.dimensions.y,
                z: stats.dimensions.z,
              },
              requiresSupports: stats.hasSteepOverhangs || stats.overhangRatio > 0.1,
            });
          }
        }
      }
    } catch (gpErr: any) {
      const err: any = new Error(`MULTIPART_METADATA_ERROR: getParts() failed: ${gpErr?.message || String(gpErr)}`);
      err.code = 'MULTIPART_METADATA_ERROR';
      throw err;
    }
  }

  // C. Execute main() to get primary / combined geometry
  let mainSolids: any = null;
  if (executionEnv.main) {
    try {
      mainSolids = executionEnv.main();
    } catch (mainErr: any) {
      throw new Error(`JSCAD_EXECUTION_ERROR: main() runtime failure: ${mainErr.message}`);
    }
  }

  if (!mainSolids && discoveredParts.length === 0) {
    throw new Error('INVALID_GEOMETRY: main() returned null, undefined, or empty geometry.');
  }

  // Handle case where main() returns an object map of parts { lid: ..., base: ... }
  if (
    mainSolids &&
    typeof mainSolids === 'object' &&
    !mainSolids.polygons &&
    !mainSolids.toPolygons &&
    !Array.isArray(mainSolids)
  ) {
    const keys = Object.keys(mainSolids);
    if (keys.length > 0 && discoveredParts.length === 0) {
      for (const k of keys) {
        const item = mainSolids[k];
        if (item && (item.polygons || item.toPolygons || Array.isArray(item))) {
          const geom = jscadGeomToThree(item);
          const stats = analyzeBufferGeometry(geom);
          discoveredParts.push({
            id: k,
            name: k.charAt(0).toUpperCase() + k.slice(1).replace(/_/g, ' '),
            quantity: 1,
            geometry: geom,
            featureIds: [],
            stats,
            boundingBox: {
              x: stats.dimensions.x,
              y: stats.dimensions.y,
              z: stats.dimensions.z,
            },
            requiresSupports: stats.hasSteepOverhangs || stats.overhangRatio > 0.1,
          });
        }
      }
    }
  }

  // Handle case where main() returns an array of multiple distinct solids [partA, partB, ...]
  if (discoveredParts.length === 0 && Array.isArray(mainSolids) && mainSolids.length > 1) {
    for (let i = 0; i < mainSolids.length; i++) {
      const item = mainSolids[i];
      if (item && (item.polygons || item.toPolygons || Array.isArray(item))) {
        try {
          const geom = jscadGeomToThree(item);
          const stats = analyzeBufferGeometry(geom);
          const partName = `Part ${i + 1}`;
          discoveredParts.push({
            id: `part_${i + 1}`,
            name: partName,
            quantity: 1,
            geometry: geom,
            featureIds: [],
            stats,
            boundingBox: {
              x: stats.dimensions.x,
              y: stats.dimensions.y,
              z: stats.dimensions.z,
            },
            requiresSupports: stats.hasSteepOverhangs || stats.overhangRatio > 0.1,
          });
        } catch (convErr) {
          console.warn(`Could not convert array solid at index ${i}:`, convErr);
        }
      }
    }
  }

  // Build combined geometry
  let combinedGeometry: THREE.BufferGeometry;
  if (mainSolids && (mainSolids.polygons || mainSolids.toPolygons || Array.isArray(mainSolids))) {
    try {
      combinedGeometry = jscadGeomToThree(mainSolids);
    } catch (convErr: any) {
      if (discoveredParts.length > 0) {
        combinedGeometry = combinePartGeometries(discoveredParts);
      } else {
        throw new Error(`INVALID_GEOMETRY: Failed converting main() JSCAD solid: ${convErr.message}`);
      }
    }
  } else if (discoveredParts.length > 0) {
    // Merge part geometries for combined visual representation
    combinedGeometry = combinePartGeometries(discoveredParts);
  } else {
    throw new Error('INVALID_GEOMETRY: Could not generate valid 3D geometry.');
  }

  // If only 1 or 0 explicit parts were found, create the default single part representation
  if (discoveredParts.length === 0) {
    const stats = analyzeBufferGeometry(combinedGeometry);
    discoveredParts.push({
      id: 'main',
      name: 'Main Body',
      quantity: 1,
      geometry: combinedGeometry,
      featureIds: [],
      stats,
      boundingBox: {
        x: stats.dimensions.x,
        y: stats.dimensions.y,
        z: stats.dimensions.z,
      },
      requiresSupports: stats.hasSteepOverhangs || stats.overhangRatio > 0.1,
    });
  }

  return {
    combinedGeometry,
    parts: discoveredParts,
    isMultiPart: discoveredParts.reduce((sum, p) => sum + Math.max(1, p.quantity || 1), 0) > 1,
  };
}

/**
 * Executes JSCAD JavaScript code in a client-side sandbox
 * Returns a Three.js BufferGeometry or throws a clear error.
 */
export function executeJscadCode(code: string): THREE.BufferGeometry {
  const result = executeJscadModel(code);
  return result.combinedGeometry;
}

export const DEFAULT_PLANTER_JSCAD = `// Self-Watering Planter with Integrated Reservoir
const height = 120; // Overall height (mm)
const diameter = 100; // Outer diameter (mm)
const wall = 3.2; // Wall thickness (mm)
const reservoir_height = 35; // Reservoir depth (mm)
const wick_hole_dia = 12; // Center wicking hole diameter (mm)

function main() {
  // Outer Planter Shell
  const outerPot = cylinder({
    radius: diameter / 2,
    height: height,
    segments: 48
  });

  // Inner Planting Cavity
  const innerCavity = cylinder({
    radius: (diameter / 2) - wall,
    height: height - wall,
    segments: 48
  });

  // Sub-base Reservoir Chamber
  const potShell = subtract(
    outerPot,
    translate([0, 0, wall + reservoir_height], innerCavity)
  );

  // Center Wicking Conduit Channel
  const wickHole = cylinder({
    radius: wick_hole_dia / 2,
    height: reservoir_height + wall * 2,
    segments: 24
  });

  // Overflow / Aeration Slots
  const slot1 = cuboid({ size: [diameter + 10, 4, 6] });
  const slot2 = cuboid({ size: [4, diameter + 10, 6] });

  const finalPlanter = subtract(
    potShell,
    translate([0, 0, wall], wickHole),
    translate([0, 0, reservoir_height], slot1),
    translate([0, 0, reservoir_height], slot2)
  );

  // Position flat base on build plate Z=0
  return translate([0, 0, height / 2], finalPlanter);
}`;
