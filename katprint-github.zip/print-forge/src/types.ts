import type { SemanticFeatureModel } from './features/featureTypes';

export type CreationMode = 'describe' | 'image' | 'photo' | 'templates';
export type GenerationMode = 'fast' | 'precision';
export type ImageSubMode = 'heightmap' | 'silhouette';
export type PromptClassification = 'parametric' | 'organic' | 'hybrid';

export type ObjectCategory =
  | 'PARAMETRIC_FUNCTIONAL'
  | 'PARAMETRIC_DECORATIVE'
  | 'HYBRID_FUNCTIONAL'
  | 'ORGANIC_DECORATIVE'
  | 'IMAGE_RELIEF'
  | 'IMAGE_SILHOUETTE'
  | 'REFERENCE_FIT_OBJECT'
  | 'ENCLOSURE'
  | 'HOLDER_OR_MOUNT'
  | 'CONTAINER_OR_TRAY'
  | 'BRACKET_OR_MECHANICAL'
  | 'THREAD_OR_MECHANICAL_PART';

export type RequirementSource =
  | 'explicit'
  | 'inferred'
  | 'reference_database'
  | 'template'
  | 'user_preference'
  | 'image_reference';

export interface DimensionRequirement {
  name: string;
  value: number; // in mm
  toleranceMm?: number;
  axis?: 'x' | 'y' | 'z' | 'diameter' | 'any';
  source: RequirementSource;
  isCritical?: boolean;
  description?: string;
}

export interface CompatibilityTarget {
  name: string;
  relationship: string; // e.g. "holds", "mounts under", "clips onto", "fits inside", "interfaces between"
  dimensions?: {
    width?: number | null;
    depth?: number | null;
    height?: number | null;
    diameter?: number | null;
  };
  clearanceMm: number;
  source: RequirementSource;
  notes?: string;
}

export interface DesignFeature {
  id: string;
  name: string;
  description: string;
  source: RequirementSource;
  confidence: number; // 0 - 1
  reason?: string;
  isVerified?: boolean;
  verificationMethod?: 'deterministic' | 'visual' | 'code' | 'unverified';
}

export interface FitRequirement {
  target: string;
  clearanceMm: number;
  fitType: 'loose' | 'snug' | 'snap-fit' | 'press-fit' | 'slide-in' | 'clearance';
  source: RequirementSource;
}

export interface PrintRequirement {
  orientation: string;
  flatBaseRequired: boolean;
  minWallThicknessMm: number;
  supportFreeGoal: boolean;
  maxOverhangAngleDeg: number;
}

export interface DesignAssumption {
  category: 'dimension' | 'feature' | 'material' | 'use_case' | 'mounting' | 'printer';
  assumption: string;
  source: RequirementSource;
  confidence: number; // 0 - 1
  reason: string;
}

export interface DesignSpecification {
  originalPrompt: string;
  primaryObject: string;
  category: string;
  intendedFunction: string;
  targetUseCase?: string;
  mountingStyle: string;

  compatibilityTargets: CompatibilityTarget[];

  explicitDimensions: DimensionRequirement[];
  inferredDimensions: DimensionRequirement[];
  criticalDimensions: DimensionRequirement[];

  requiredFeatures: DesignFeature[];
  optionalFeatures: DesignFeature[];

  mountingRequirements: string[];
  fitRequirements: FitRequirement[];
  ergonomicRequirements: string[];
  structuralRequirements: string[];
  aestheticRequirements: string[];

  printRequirements: PrintRequirement[];

  assumptions: DesignAssumption[];
  unresolvedQuestions: string[];

  generationStrategy: string;
  confidence: number; // 0 - 100
}

export type DesignCheckType =
  | 'DIMENSION'
  | 'FEATURE'
  | 'RELATIONSHIP'
  | 'FIT'
  | 'STRUCTURE'
  | 'VISUAL'
  | 'PRINTABILITY';

export type DesignCheckImportance = 'CRITICAL' | 'IMPORTANT' | 'OPTIONAL';
export type DesignCheckStatus = 'PASS' | 'FAIL' | 'UNKNOWN';

export interface DesignCheck {
  id: string;
  description: string;
  type: DesignCheckType;
  importance: DesignCheckImportance;
  axis?: 'x' | 'y' | 'z' | 'diameter' | 'any';
  verificationMethod: 'deterministic_geom' | 'source_code' | 'ai_vision' | 'user_assumption';
  expected: string | number | boolean;
  tolerance?: number;
  actual?: string | number | boolean;
  status: DesignCheckStatus;
  notes?: string;
}

export interface PrecisionReviewProblem {
  requirement: string;
  issue: string;
  severity: 'critical' | 'important' | 'minor';
  affectedFeatureId?: string;
  recommendedCorrection?: string;
}

export interface ScoreBreakdown {
  intentMatch: number; // 0 - 100
  dimensions: number; // 0 - 100
  requiredFeatures: number; // 0 - 100
  printability: number; // 0 - 100
  visualMatch: number; // 0 - 100
}

export interface FidelityReviewResult {
  overallScore: number | null; // 0 - 100 or null if not evaluated
  verdict: 'PASS' | 'NEEDS_MINOR_CORRECTION' | 'NEEDS_MAJOR_CORRECTION' | 'INVALID_DESIGN';
  verifiedRequirements: string[];
  problems: PrecisionReviewProblem[];
  missingFeatures: string[];
  visualMismatch: string[];
  requiresRepair: boolean;
  scoreBreakdown: ScoreBreakdown;
  summary: string;
}

export interface DesignConcept {
  id: 'a' | 'b' | 'c' | string;
  name: string;
  approach: string;
  keyFeatures: string[];
  partCount: number;
  estimatedPrintTimeMin: number;
  estimatedMaterialG: number;
  tradeoffs: {
    pros: string[];
    cons: string[];
  };
  difficulty: 'easy' | 'moderate' | 'advanced';
  requiresSupports: boolean;
  dimensionDeltas?: string;
  specPatch?: Partial<ExtractedRequirements>;
}

export type GenerationPipelineStage =
  | 'idle'
  | 'understanding_design'
  | 'review_spec'
  | 'choose_approach'
  | 'planning_geometry'
  | 'generating_cad'
  | 'building_model'
  | 'checking_dimensions'
  | 'rendering_views'
  | 'inspecting_design'
  | 'correcting_model'
  | 'final_verification'
  | 'completed'
  | 'error';

export type VerificationVerdict = 'VERIFIED' | 'PARTIALLY VERIFIED' | 'UNVERIFIED' | 'FAILED';

export interface ReferenceObject {
  name: string;
  dimensions: {
    width?: number | null; // mm
    depth?: number | null; // mm
    height?: number | null; // mm
    diameter?: number | null; // mm
  };
  confidence: 'verified' | 'estimated';
  clearanceMm?: number;
  sourceNote?: string;
}

export interface AssumptionLedgerEntry {
  parameter: string;
  value: number | string | boolean;
  unit?: string;
  basis: 'user_stated' | 'reference_library' | 'measured_from_image' | 'engineering_default' | 'inferred_from_load';
  reasoning: string;
  confidence: number; // 0 - 1
  userEditable: boolean;
}

export interface OpenQuestion {
  id: string;
  question: string;
  whyItMatters: string;
  assumedAnswer: string;
  confidence: number; // 0 - 1
}

export interface PrintOrientationPlan {
  recommendedUpAxis: string;
  reasoning: string;
  supportsRequired: boolean;
  maxOverhangAngleDeg: number;
}

export interface SpecReviewIssue {
  severity: 'blocking' | 'warning';
  field: string;
  problem: string;
  correctedValue: any;
}

export interface ExtractedRequirements {
  objectName: string;
  primaryObject?: string;
  classification: PromptClassification;
  classificationConfidence?: number;
  classificationReason?: string;
  inferredCategory?: ObjectCategory | string;
  designSpecification?: DesignSpecification;
  designPlan?: any;
  functionalRequirements?: string[];
  decorativeRequirements?: string[];
  sculpturalRequirements?: string[];
  mountingStyle?: string;
  aestheticCues?: string[];
  units: 'mm' | 'cm' | 'inches' | 'feet' | 'mixed';
  overallDimensions: {
    width?: number | null; // in mm
    depth?: number | null; // in mm
    height?: number | null; // in mm
    diameter?: number | null; // in mm
    length?: number | null; // in mm
    rawInput?: string;
  };
  wallThicknessMm?: number | null;
  referenceObject?: ReferenceObject | null;
  features: string[];
  explicitRequirements?: string[];
  designDecisions?: string[];
  suggestedImprovements?: string[];
  assumptions?: string[];
  unspecifiedProperties?: string[];
  quantities: Record<string, number>;
  spatialArrangements: string[];
  fastenersOrHardware?: string[];
  tolerancesOrClearances?: string[];
  printConsiderations: string[];
  warnings: string[];
  isOrganicOnly?: boolean;
  assumptionLedger?: AssumptionLedgerEntry[];
  openQuestions?: OpenQuestion[];
  printOrientation?: PrintOrientationPlan;
  specConfidence?: number;
  specReviewIssues?: SpecReviewIssue[];
  userOverrides?: string[];
}

export type VerificationSource =
  | 'geometry'
  | 'source-code'
  | 'ai-review'
  | 'user-assumption'
  | 'unverified';

export interface DesignValidationItem {
  id: string;
  label: string;
  status: 'verified' | 'uncertain' | 'missing' | 'warning';
  detail?: string;
  requirementText: string;
  verificationSource?: VerificationSource;
  measuredValue?: string | number;
  expectedValue?: string | number;
  isHardRequirement?: boolean;
}

export interface DesignValidationReport {
  items: DesignValidationItem[];
  overallScore: number | null; // 0 - 100 or null if not evaluated
  passed: boolean;
  verdict: VerificationVerdict;
  summary: string;
  missingFeatures: string[];
  warnings: string[];
  scoreBreakdown?: ScoreBreakdown;
  designChecks?: DesignCheck[];
  fidelityReview?: FidelityReviewResult;
  geometryMeasurements?: {
    x: number;
    y: number;
    z: number;
    volumeMm3: number;
    isManifold: boolean;
    polygonCount?: number;
  };
}

export interface ProjectReferenceImage {
  id: string;
  fileName?: string;
  filename?: string;
  mimeType: 'image/jpeg' | 'image/png' | 'image/webp' | string;
  dataUrl: string;
  thumbnailDataUrl?: string;
  width?: number;
  height?: number;
  role:
    | 'front'
    | 'rear'
    | 'left'
    | 'right'
    | 'top'
    | 'bottom'
    | 'detail'
    | 'installation'
    | 'scale_reference'
    | 'unknown';
  notes?: string;
  createdAt: string;
  analysisObservation?: ReferenceImageObservation;
  analysisHash?: string;
  analyzedAt?: string;
}

export interface ModelPartDefinition {
  id: string;
  name: string;
  role?: string;
  quantity: number;
  featureIds: string[];
  cadFunctionName: string;
  required: boolean;
  assemblyOrder?: number;
  notes?: string;
}

export interface PartRelationship {
  id: string;
  partAId?: string;
  partBId?: string;
  sourcePartId?: string;
  targetPartId?: string;
  type:
    | 'mates_with'
    | 'fits_inside'
    | 'slides_into'
    | 'snaps_into'
    | 'screws_to'
    | 'hinges_to'
    | 'aligns_with'
    | 'rests_on'
    | 'press_fits'
    | 'clearance_fit'
    | string;
  clearanceMm?: number;
  notes?: string;
  description?: string;
}

export interface ModelAssemblyDefinition {
  id: string;
  name: string;
  isMultiPart: boolean;
  parts: ModelPartDefinition[];
  relationships: PartRelationship[];
}

export interface ExecutedModelPart {
  id: string;
  name: string;
  quantity: number;
  geometry: any; // THREE.BufferGeometry
  featureIds: string[];
  stats: ModelGeometryStats;
  boundingBox: {
    x: number;
    y: number;
    z: number;
  };
  requiresSupports?: boolean;
}

export interface ExecutedModel {
  combinedGeometry: any; // THREE.BufferGeometry
  parts: ExecutedModelPart[];
  isMultiPart: boolean;
}

export interface PlacedPartInstance {
  instanceId: string;
  partId: string;
  partName: string;
  position: { x: number; y: number; z: number };
  rotationZ: number;
  dimensions: { x: number; y: number; z: number };
  plateIndex: number;
  requiresSupports: boolean;
  x?: number;
  y?: number;
  width?: number;
  depth?: number;
  height?: number;
  rotationDeg?: number;
  volumeCm3?: number;
  weightGrams?: number;
}

export interface PrintPlate {
  plateIndex: number;
  plateName: string;
  items: PlacedPartInstance[];
  instances?: PlacedPartInstance[];
  occupiedAreaPercent: number;
  totalVolumeCm3: number;
  estimatedWeightGrams: number;
  estimatedPrintTimeMinutes: number;
  fitsOnBed: boolean;
}

export interface PrintPlatePlan {
  id?: string;
  plateNumber?: number;
  plates: PrintPlate[];
  totalPlates: number;
  fitsAllOnOnePlate: boolean;
  totalVolumeCm3: number;
  totalEstimatedWeightGrams: number;
  totalEstimatedPrintTimeMinutes: number;
  printerBedDimensions: {
    x: number;
    y: number;
    z: number;
  };
  placements?: Array<{
    partId: string;
    instanceIndex: number;
    translation: [number, number, number];
    rotation: [number, number, number];
  }>;
  dimensions?: {
    x: number;
    y: number;
    z: number;
  };
  fitsPrinter?: boolean;
}

export interface ModelVersion {
  version: number;
  id: string;
  title: string;
  timestamp: string;
  prompt: string;
  code: string;
  requirements: ExtractedRequirements | null;
  validationReport: DesignValidationReport | null;
  featureModel?: SemanticFeatureModel | null;
  assembly?: ModelAssemblyDefinition | null;
  source: 'ai' | 'template';
  modelName: string;
}

export interface GenerationHistoryItem {
  id: string;
  timestamp: string;
  originalPrompt: string;
  revisionHistory: string[];
  requirements: ExtractedRequirements | null;
  validationReport: DesignValidationReport | null;
  code: string;
  source: 'ai' | 'template';
  modelName: string;
}

export interface PrinterSpec {
  id: string;
  name: string;
  buildVolume: {
    x: number; // mm
    y: number; // mm
    z: number; // mm
  };
  nozzleDiameter: number; // mm (e.g. 0.4)
  driveType: 'direct' | 'bowden';
  isEnclosed: boolean;
  maxVolumetricFlow: number; // mm3/s
  isCustom?: boolean;
  measuredClearanceMm?: number; // per-side, from the fit test
  clearanceMeasuredAt?: string; // ISO date
  clearanceFilamentId?: string; // filament used for the test
}

export interface FilamentSpec {
  id: string;
  name: string;
  nozzleTempRange: [number, number]; // [min, max] C
  bedTempRange: [number, number]; // [min, max] C
  fanPercent: number; // 0-100
  maxVolumetricFlow: number; // mm3/s
  shrinkagePercent: number; // %
  warpRisk: 'Low' | 'Medium-Low' | 'Medium' | 'High' | 'Extreme';
  enclosureRequired: boolean;
  watertightSuitability: 'Poor' | 'Moderate' | 'Good' | 'High' | 'Excellent';
  uvOutdoorRating: 'Poor' | 'Moderate' | 'Good' | 'Very Good' | 'Excellent';
  densityGcm3: number; // g/cm3 (PLA: 1.24, PETG: 1.27, ABS: 1.04, etc.)
  colorHex: string;
}

export interface ModelGeometryStats {
  dimensions: { x: number; y: number; z: number }; // mm
  volumeMm3: number;
  volumeCm3: number;
  surfaceAreaMm2: number;
  estimatedWeightGrams: number;
  triangleCount: number;
  vertexCount: number;
  nonManifoldEdgeCount?: number;
  closureResidual?: number;
  isClosed?: boolean;
  overhangRatio: number; // fraction of faces > 45 deg
  minWallThicknessMm: number;
  isManifold: boolean;
  hasFiniteVertices?: boolean;
  footprintAreaMm2: number;
  heightToWidthRatio: number;
  hasSteepOverhangs: boolean;
}

export type FitStatusLevel = 'green' | 'yellow' | 'red';

export interface PrinterFitResult {
  status: FitStatusLevel;
  message: string;
  details: string[];
  fitsStandard: boolean;
  fitsRotated45: boolean;
  axisOverflow: {
    x: number;
    y: number;
    z: number;
  };
  thinFeatureWarning: boolean;
  minWallSizeMm: number;
}

export interface PrintabilityChecklist {
  validGeometry: boolean;
  stlReady: boolean;
  dimensionsMm: { x: number; y: number; z: number };
  flatPrintableBase: boolean;
  reasonableWallThickness: boolean;
  fitsSelectedPrinter: boolean;
  warnings: string[];
  details: string[];
}

export interface SlicerSettings {
  nozzleTempFirstLayer: number;
  nozzleTempOtherLayers: number;
  bedTemp: number;
  layerHeight: number;
  firstLayerHeight: number;
  wallLoops: number;
  topLayers: number;
  bottomLayers: number;
  infillPercent: number;
  infillPattern: 'Gyroid' | 'Grid' | 'Honeycomb' | 'Adaptive Cubic';
  outerWallSpeed: number; // mm/s
  innerWallSpeed: number; // mm/s
  infillSpeed: number; // mm/s
  firstLayerSpeed: number; // mm/s
  fanPercent: number;
  retractionDistance: number; // mm
  retractionSpeed: number; // mm/s
  supportsEnabled: boolean;
  supportType: 'Tree / Organic' | 'Standard Grid' | 'None';
  supportAngleThreshold: number; // degrees
  brimEnabled: boolean;
  brimWidthMm: number;
  flowCompensation: number; // 0.95 - 1.05
  estimatedPrintTimeMinutes: number;
  estimatedMaterialGrams: number;
  estimatedMaterialMeters: number;
}

export interface ParsedParametricVariable {
  name: string;
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit: string;
}

export interface WebSocketTelemetry {
  status: 'idle' | 'preheating' | 'calibrating' | 'printing' | 'completed' | 'paused' | 'error';
  progressPercent: number;
  currentLayer: number;
  totalLayers: number;
  nozzleTemp: number;
  targetNozzleTemp: number;
  bedTemp: number;
  targetBedTemp: number;
  fanSpeedPercent: number;
  printTimeElapsedSec: number;
  printTimeRemainingSec: number;
  currentSpeedMmS: number;
  flowRateMm3S: number;
  printerName: string;
  message: string;
}

export type ErrorCategory =
  | 'AUTH_ERROR'
  | 'PERMISSION_ERROR'
  | 'MODEL_UNAVAILABLE'
  | 'INVALID_REQUEST'
  | 'RATE_LIMIT'
  | 'GEMINI_UNAVAILABLE'
  | 'REQUEST_TIMEOUT'
  | 'SECURITY_REJECTION'
  | 'JSCAD_EXECUTION_ERROR'
  | 'INVALID_GEOMETRY'
  | 'ORGANIC_UNCONFIGURED'
  | 'HYBRID_UNCONFIGURED'
  | 'NETWORK_ERROR'
  | 'UNKNOWN_ERROR';

export interface GenerationError {
  error: string;
  errorCategory: ErrorCategory;
  technicalDetails?: string;
  statusCode?: number;
  canSimplifyToParametric?: boolean;
  requirements?: ExtractedRequirements;
}

export interface GeometryInspectionStats {
  dimensions: { x: number; y: number; z: number };
  actualVolumeMm3: number;
  surfaceAreaMm2: number;
  polygonCount: number;
  triangleCount: number;
  vertexCount: number;
  nonManifoldEdgeCount: number;
  closureResidual?: number;
  isClosed?: boolean;
  isManifold: boolean;
  isNonEmpty: boolean;
}

export type AIRequestPurpose =
  | 'design_reasoning'
  | 'design_brief'
  | 'design_spec'
  | 'spec_review'
  | 'cad_generation'
  | 'cad_execution_repair'
  | 'visual_fidelity_review'
  | 'precision_correction'
  | 'final_visual_review';

export interface AIRequestRecord {
  id?: string;
  purpose: AIRequestPurpose;
  model: string;
  attemptNumber?: number;
  durationMs: number;
  timestamp: number;
  status: 'success' | 'failure';
  statusCode?: number;
  errorCategory?: string;
}

export interface GenerationDiagnostics {
  generationId: string;
  timestamp: string | number;
  status?: 'idle' | 'generating' | 'success' | 'error';
  mode: GenerationMode;
  totalAIRequests: number;
  requestsByPurpose?: {
    design_reasoning?: number;
    design_brief?: number;
    design_spec?: number;
    spec_review?: number;
    cad_generation?: number;
    cad_execution_repair?: number;
    visual_fidelity_review?: number;
    precision_correction?: number;
    final_visual_review?: number;
  };
  modelsUsed?: string[];
  modelUsed?: string;
  requestRecords?: AIRequestRecord[];
  totalDurationMs?: number;
  latencyMs?: number;
  aiCallsMade?: number;
  repairAttempts: number;
  intentClassification?: string;
  geometryMeasurements?: GeometryInspectionStats | ModelGeometryStats;
  measuredDimensions?: { x: number; y: number; z: number };
  measuredVolumeMm3?: number;
  polygonCount?: number;
  triangleCount?: number;
  vertexCount?: number;
  isManifold?: boolean;
  nonManifoldEdgeCount?: number;
  validationVerdict?: string;
  precisionScore?: number;
  securityCheckPassed?: boolean;
  semanticFeatureCount?: number;
  verifiedFeatureCount?: number;
  failedFeatureCount?: number;
  unknownFeatureCount?: number;
  bindingCount?: number;
  boundFeatureCount?: number;
  builderBoundFeatureCount?: number;
  criticalUnboundParameterCount?: number;
  missingBuilderFeatureCount?: number;
  unusedFeatureWrapperCount?: number;
  parameterEditCount?: number;
  featureAdditions?: number;
  featureRemovals?: number;
  featureModelVersion?: number;
  auditScore?: number;
  auditCycles?: number;
  auditDurationMs?: number;
  auditFindingsCount?: number;
  auditPassed?: boolean;
  usedFallback?: boolean;
  fallbackReason?: string;
  plansRequested?: 1 | 3;
  plansReceived?: number;
  initialPlansReceived?: number;
  retryPlansReceived?: number;
  validPlansEvaluated?: number;
  distinctPlansEvaluated?: number;
  degradedMultiPlan?: boolean;
  degradedReason?: string;
  plansEvaluated?: number;
}

export type AuditFindingSeverity = 'blocking' | 'warning' | 'info';

export type AuditFindingCategory =
  | 'DIMENSIONAL_CONFORMANCE'
  | 'BASE_PLANE'
  | 'BED_FIT'
  | 'FEATURE_PRESENCE'
  | 'CONSTANT_INTEGRITY'
  | 'REFERENCE_CLEARANCE'
  | 'PART_COUNT'
  | 'DEGENERATE_GEOMETRY'
  | 'PRINTABILITY'
  | 'REGRESSION';

export interface AuditFinding {
  id: string;
  severity: AuditFindingSeverity;
  category: AuditFindingCategory;
  message: string;
  expected: string;
  actual: string;
  suggestedFix: string;
}

export interface GeometryAuditResult {
  passed: boolean;
  findings: AuditFinding[];
  score: number; // 0 - 1
}

export interface OverhangAnalysis {
  totalAreaMm2: number;
  ratio: number;
  worstAngleDeg: number;
  worstLocation: { x: number; y: number; z: number } | null;
  classification: 'none' | 'minor' | 'significant' | 'severe';
  requiresSupports: boolean;
  regionsCount: number;
}

export interface UnsupportedIsland {
  zHeightMm: number;
  areaMm2: number;
  centroid: { x: number; y: number };
  severity: 'blocking' | 'warning';
}

export interface ThinWallAnalysis {
  minWallThicknessMm: number;
  thinRegionCount: number;
  totalSamples: number;
  thinSampleRatio: number;
  thresholdMm: number;
  hasThinWalls: boolean;
}

export interface BridgeFeature {
  spanMm: number;
  status: 'safe' | 'risky' | 'failing';
  location: { x: number; y: number; z: number };
}

export interface FirstLayerAnalysis {
  areaMm2: number;
  contactRatio: number;
  needsBrim: boolean;
  needsRaft: boolean;
  status: 'optimal' | 'brim_recommended' | 'raft_recommended' | 'insufficient';
}

export interface SmallFeature {
  sizeMm: number;
  location: { x: number; y: number; z: number };
  description: string;
}

export interface PrintabilityRecommendation {
  severity: 'blocking' | 'warning' | 'info';
  message: string;
  action: 'add_supports' | 'reorient' | 'thicken_wall' | 'add_brim' | 'add_fillet' | 'redesign';
  autoFixable: boolean;
}

export interface SuggestedOrientation {
  rotationDeg: [number, number, number];
  reasoning: string;
  projectedScore: number;
}

export interface PrintabilityReport {
  score: number; // 0 - 100
  verdict: 'excellent' | 'good' | 'needs_attention' | 'problematic';
  overhangs: OverhangAnalysis;
  islands: UnsupportedIsland[];
  thinWalls: ThinWallAnalysis;
  bridges: BridgeFeature[];
  firstLayer: FirstLayerAnalysis;
  smallFeatures: SmallFeature[];
  recommendations: PrintabilityRecommendation[];
  suggestedOrientation: SuggestedOrientation | null;
}

// ============================================================================
// AI Architecture Upgrade: Semantic Planning, Persistent Intent, & Audits
// ============================================================================

export interface ProjectDesignState {
  primaryGoal: string;
  intendedFunction: string;
  environment: string;
  exactDimensions: DimensionRequirement[];
  lockedDimensions: DimensionRequirement[];
  requiredFeatures: DesignFeature[];
  optionalFeatures: DesignFeature[];
  forbiddenFeatures: string[];
  partDefinitions: ModelPartDefinition[];
  hardwareInterfaces: string[];
  matingInterfaces: string[];
  aestheticIntent: string[];
  printConstraints: PrintRequirement[];
  referenceObjects: CompatibilityTarget[];
  userPreferences: string[];
  importantDecisions: string[];
  rejectedDirections: string[];
  assumptions: DesignAssumption[];
  unresolvedQuestions: string[];
}
export type DesignIntentState = ProjectDesignState;

export interface SemanticFeaturePlanParam {
  value: number | string | boolean;
  unit?: string;
  source?: string;
  confidence?: number;
  locked?: boolean;
  min?: number;
  max?: number;
  description?: string;
}

export interface SemanticFeaturePlanFeature {
  id: string;
  partId?: string;
  type: string;
  label: string;
  purpose: string;
  geometryOperation: 'base' | 'add' | 'subtract' | 'intersect' | 'pattern' | 'finish';
  criticality: 'critical' | 'important' | 'optional';
  parameters: Record<string, SemanticFeaturePlanParam | number | string | boolean>;
  parentFeatureId?: string;
  childFeatureIds?: string[];
  verificationStrategy?: string;
  aliases?: string[];
}

export interface SemanticFeaturePlan {
  id?: string;
  objectSummary: string;
  designIntent: {
    primaryFunction: string;
    secondaryFunctions: string[];
    environment: string;
    userPriorities: string[];
  };
  parts: Array<{
    id: string;
    name: string;
    quantity: number;
    purpose: string;
  }>;
  features: SemanticFeaturePlanFeature[];
  relationships?: Array<{
    id?: string;
    sourceFeatureId: string;
    targetFeatureId: string;
    relationshipType: string;
    description?: string;
  }>;
  constraints?: Array<{
    id?: string;
    name: string;
    description?: string;
    constraintType: string;
    affectedFeatureIds: string[];
    parameterKeys?: string[];
    value?: number | string | boolean;
  }>;
  derivedParameters?: Array<{
    name: string;
    expression: string;
    description: string;
  }>;
  matingInterfaces?: Array<{
    partA: string;
    partB: string;
    type: string;
    clearanceMm: number;
  }>;
  unknowns?: string[];
  assumptions?: DesignAssumption[];
  generationStrategy: string;
  expectedPartCount: number;
  score?: number;
  scoreBreakdown?: {
    requiredFeatureCoverage: number;
    criticalFeatureCoverage: number;
    exactDimensionCoverage: number;
    fitInterfaceCompleteness: number;
    registeredFeatureRatio: number;
    printabilityFeasibility: number;
    editability: number;
    partCountAppropriateness: number;
  };
}

export interface SemanticPlanCoverageItem {
  requirement: string;
  importance: 'critical' | 'important' | 'optional';
  matchedFeatureIds: string[];
  status: 'matched' | 'partial' | 'unresolved';
  reason?: string;
}

export interface SemanticPlanCoverageReport {
  items: SemanticPlanCoverageItem[];
  coveragePercent: number | null;
  allCriticalPassed: boolean;
  unresolvedCriticalCount: number;
  clarificationNeeded?: string;
}

export interface RequirementCoverageItem {
  id: string;
  requirement: string;
  category: string;
  importance: 'critical' | 'important' | 'optional';
  status: 'verified' | 'partially_verified' | 'unknown' | 'failed';
  evidence: string;
  measuredValue?: any;
  targetValue?: any;
}

export interface RequirementCoverageReport {
  items: RequirementCoverageItem[];
  coveragePercent: number | null;
  unmetCriticalRequirements: string[];
  summary: string;
}

export interface DesignIntentAuditDefect {
  severity: 'critical' | 'major' | 'minor';
  featureId?: string;
  issue: string;
  recommendation: string;
}

export interface DesignIntentAudit {
  overallScore: number | null;
  verdict: 'pass' | 'needs_repair' | 'fail' | 'unknown';
  summary: string;
  evaluatedRequirements: Array<{
    name: string;
    passed: boolean;
    observation: string;
  }>;
  defects: DesignIntentAuditDefect[];
  missingFeatures: string[];
  dimensionalDrift: Array<{
    axis: string;
    expected: number;
    measured: number;
    driftPercent: number;
  }>;
  aestheticCritique: string;
}

export interface ReferenceImageObservation {
  imageIndex: number;
  role: string;
  observedFeatures: string[];
  relativeProportions: string[];
  visibleInterfaces: string[];
  knownMeasurements: Array<{
    feature: string;
    valueMm: number;
  }>;
  unknownMeasurements: string[];
  confidence: number;
}

export interface RevisionIntent {
  intentType:
    | 'parameter_edit'
    | 'feature_add'
    | 'feature_remove'
    | 'feature_move'
    | 'feature_replace'
    | 'style_change'
    | 'structural_redesign'
    | 'part_structure_change';
  targetFeatureIds: string[];
  requestedChanges: Array<{
    feature: string;
    change: string;
    fromValue?: string | number;
    toValue?: string | number;
    category?: 'dimension' | 'feature' | 'interface' | 'material' | 'aesthetic';
  }>;
  preserveFeatureIds: string[];
  preserveConstraints: string[];
  newFeatures?: any[];
  dimensionChanges?: Array<{
    name: string;
    from?: number;
    to: number;
    axis?: string;
  }>;
  partChanges?: string[];
  aestheticChanges?: string[];
  requiresCadRegeneration: boolean;
  confidence: number;
  interpretation: string;
  clarificationNeeded?: string;
}

export interface DesignIntentStateDelta {
  addConstraints?: string[];
  removeConstraints?: string[];
  updateDimensions?: DimensionRequirement[];
  addRequiredFeatures?: DesignFeature[];
  removeFeatures?: string[];
  addRejectedDirections?: string[];
  newAestheticIntent?: string[];
  newOpenQuestions?: string[];
  newAssumptions?: DesignAssumption[];
  summary?: string;
}

// ============================================================================
// Print Result Feedback & Generation Records
// ============================================================================

export type PrintOutcome = 'printed_ok' | 'failed';

export type PrintFailureTag =
  | 'leaked'
  | 'lid_too_tight'
  | 'lid_too_loose'
  | 'warped'
  | 'wrong_size'
  | 'layer_split'
  | 'supports_failed'
  | 'thin_walls'
  | 'other';

export interface PrintResult {
  generationId: string;
  recordedAt: string;
  outcome: PrintOutcome;
  failureTags: string[];
  note?: string;
}

export interface GenerationRecordPartSummary {
  id: string;
  name: string;
  quantity: number;
  dimensions?: { x: number; y: number; z: number };
}

export interface GenerationRecord {
  id: string;
  createdAt: string;
  prompt: string;
  finalCode: string;
  measuredDimensions: { x: number; y: number; z: number };
  parts?: GenerationRecordPartSummary[];
  printer: PrinterSpec;
  filament: FilamentSpec;
  computedSettings: SlicerSettings;
  source: 'ai' | 'template';
  matingClearanceMm?: number;
  printResult?: PrintResult;
  hasMeasuredDeltaFlags?: boolean;
  measuredDeltaFlags?: string[];
}

// ============================================================================
// Example Library Types
// ============================================================================

export type CadExampleShapeClass =
  | 'container'
  | 'tray'
  | 'bracket'
  | 'multi_part'
  | 'flat'
  | 'organic'
  | 'other';

export interface CadExample {
  id: string;
  title: string;
  prompt: string;
  code: string;
  shapeClass: CadExampleShapeClass;
  keywords: string[];
  dimsMm: { x: number; y: number; z: number };
  isMultiPart: boolean;
  holdsLiquid: boolean;
  source: 'seed' | 'user';
  createdAt: string;
  starred?: boolean;
}



