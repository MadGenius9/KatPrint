import {
  SemanticFeatureModel,
  SemanticFeature,
  FeatureParameter,
  FeatureRelationship,
  FeatureConstraint,
  FeatureType,
  GeometryOperation,
  FeatureCriticality,
  ParameterSource,
  ParameterUnit,
} from './featureTypes';
import { createFeatureParameter } from './featureParameters';
import { createFeatureRelationship } from './featureRelationships';
import { createFeatureConstraint } from './featureConstraints';
import {
  DesignSpecification,
  DesignCheck,
  SemanticFeaturePlan,
  SemanticFeaturePlanParam,
  SemanticFeaturePlanFeature,
  SemanticPlanCoverageItem,
  SemanticPlanCoverageReport,
  ProjectDesignState,
} from '../types';
import { FEATURE_REGISTRY } from './featureRegistry';

/**
 * Normalizes parameter definitions from Gemini (Array of GeminiSemanticParameterSchema
 * or raw object) into the KatPrint runtime Record<string, SemanticFeaturePlanParam>.
 * Preserves all metadata: unit, source, confidence, locked, min, max, description.
 */
export function normalizeSemanticPlanParameters(rawParams: any): Record<string, SemanticFeaturePlanParam> {
  const result: Record<string, SemanticFeaturePlanParam> = {};
  if (!rawParams) return result;

  if (Array.isArray(rawParams)) {
    for (const item of rawParams) {
      if (!item || typeof item !== 'object') continue;
      const name = String(item.name || item.paramName || item.key || '').trim();
      if (!name) continue;

      let val: number | string | boolean = 0;
      if (item.valueNumber !== undefined && item.valueNumber !== null) {
        val = Number(item.valueNumber);
      } else if (item.valueString !== undefined && item.valueString !== null) {
        val = String(item.valueString);
      } else if (item.valueBoolean !== undefined && item.valueBoolean !== null) {
        val = Boolean(item.valueBoolean);
      } else if (item.value !== undefined && item.value !== null) {
        val = item.value;
      }

      result[name] = {
        value: val,
        unit: item.unit || 'mm',
        source: item.source || 'explicit',
        confidence: typeof item.confidence === 'number' ? item.confidence : 1.0,
        locked: item.locked !== undefined ? Boolean(item.locked) : false,
        min: typeof item.min === 'number' ? item.min : undefined,
        max: typeof item.max === 'number' ? item.max : undefined,
        description: item.description || '',
      };
    }
  } else if (typeof rawParams === 'object') {
    for (const [k, v] of Object.entries(rawParams)) {
      if (!k) continue;
      if (typeof v === 'object' && v !== null) {
        const obj = v as any;
        let val: number | string | boolean = 0;
        if (obj.valueNumber !== undefined) val = obj.valueNumber;
        else if (obj.valueString !== undefined) val = obj.valueString;
        else if (obj.valueBoolean !== undefined) val = obj.valueBoolean;
        else if (obj.value !== undefined) val = obj.value;

        result[k] = {
          value: val,
          unit: obj.unit || 'mm',
          source: obj.source || 'explicit',
          confidence: typeof obj.confidence === 'number' ? obj.confidence : 1.0,
          locked: obj.locked !== undefined ? Boolean(obj.locked) : false,
          min: typeof obj.min === 'number' ? obj.min : undefined,
          max: typeof obj.max === 'number' ? obj.max : undefined,
          description: obj.description || '',
        };
      } else {
        result[k] = {
          value: v as number | string | boolean,
          unit: 'mm',
          source: 'explicit',
          confidence: 1.0,
          locked: false,
        };
      }
    }
  }

  return result;
}

/**
 * Normalizes and validates a complete SemanticFeaturePlan from Gemini structured output.
 */
export function normalizeSemanticPlan(rawPlan: any): SemanticFeaturePlan | null {
  if (!rawPlan || typeof rawPlan !== 'object') return null;

  const rawFeatures = Array.isArray(rawPlan.features) ? rawPlan.features : [];
  if (rawFeatures.length === 0) return null;

  const parts = Array.isArray(rawPlan.parts) && rawPlan.parts.length > 0
    ? rawPlan.parts.map((p: any, idx: number) => ({
        id: String(p.id || `part_${idx + 1}`),
        name: String(p.name || `Part ${idx + 1}`),
        quantity: Math.max(1, typeof p.quantity === 'number' ? Math.round(p.quantity) : 1),
        purpose: String(p.purpose || 'Solid printed component'),
      }))
    : [{ id: 'main', name: 'Main Body', quantity: 1, purpose: 'Primary solid structure' }];

  const validPartIds = new Set(parts.map((p: any) => p.id));
  const validFeatureIds = new Set<string>();

  const normalizedFeatures: SemanticFeaturePlanFeature[] = [];

  for (let idx = 0; idx < rawFeatures.length; idx++) {
    const f = rawFeatures[idx];
    if (!f || typeof f !== 'object') continue;

    const id = String(f.id || `feat_${idx + 1}_${String(f.type || 'feat').toLowerCase()}`).trim();
    validFeatureIds.add(id);

    const partId = f.partId && validPartIds.has(f.partId) ? f.partId : parts[0].id;
    const type = String(f.type || 'CUSTOM_PARAMETRIC').toUpperCase();
    const label = String(f.label || id);
    const purpose = String(f.purpose || 'Mechanical functional geometry');
    const geometryOperation = f.geometryOperation || (idx === 0 ? 'base' : 'add');
    const criticality = f.criticality || 'important';

    const parameters = normalizeSemanticPlanParameters(f.parameters);

    normalizedFeatures.push({
      id,
      partId,
      type,
      label,
      purpose,
      geometryOperation,
      criticality,
      parentFeatureId: f.parentFeatureId,
      parameters,
      verificationStrategy: f.verificationStrategy,
      aliases: Array.isArray(f.aliases) ? f.aliases : undefined,
    });
  }

  if (normalizedFeatures.length === 0) return null;

  // Validate relationships and constraints
  const relationships = Array.isArray(rawPlan.relationships)
    ? rawPlan.relationships
        .filter((r: any) => r && validFeatureIds.has(r.sourceFeatureId) && validFeatureIds.has(r.targetFeatureId))
        .map((r: any) => ({
          sourceFeatureId: r.sourceFeatureId,
          targetFeatureId: r.targetFeatureId,
          relationshipType: r.relationshipType || 'attached_to',
          description: r.description,
        }))
    : [];

  const constraints = Array.isArray(rawPlan.constraints)
    ? rawPlan.constraints.map((c: any) => ({
        name: c.name || 'Geometric Constraint',
        constraintType: c.constraintType || 'min_value',
        affectedFeatureIds: Array.isArray(c.affectedFeatureIds)
          ? c.affectedFeatureIds.filter((fid: string) => validFeatureIds.has(fid))
          : Array.from(validFeatureIds),
        value: c.value,
        description: c.description,
      }))
    : [];

  const matingInterfaces = Array.isArray(rawPlan.matingInterfaces)
    ? rawPlan.matingInterfaces
        .filter((m: any) => m && validPartIds.has(m.partA) && validPartIds.has(m.partB))
        .map((m: any) => ({
          partA: m.partA,
          partB: m.partB,
          type: m.type || 'slide_fit',
          clearanceMm: typeof m.clearanceMm === 'number' ? m.clearanceMm : 0.35,
        }))
    : [];

  const derivedParameters = Array.isArray(rawPlan.derivedParameters)
    ? rawPlan.derivedParameters.map((d: any) => ({
        name: d.name || 'derived_param',
        expression: d.expression || '',
        description: d.description || '',
      }))
    : [];

  const expectedPartCount = typeof rawPlan.expectedPartCount === 'number'
    ? Math.max(1, rawPlan.expectedPartCount)
    : parts.reduce((sum: number, p: any) => sum + p.quantity, 0);

  return {
    objectSummary: rawPlan.objectSummary || 'Functional 3D CAD Component',
    designIntent: rawPlan.designIntent || {
      primaryFunction: 'Mechanical functional part',
      secondaryFunctions: [],
      environment: 'Desktop / Workshop',
      userPriorities: ['Printability', 'Dimensional Accuracy'],
    },
    parts,
    features: normalizedFeatures,
    relationships,
    constraints,
    derivedParameters,
    matingInterfaces,
    generationStrategy: rawPlan.generationStrategy || 'Parametric CSG construction',
    expectedPartCount,
  };
}

export function shouldGenerateMultipleSemanticPlans(
  prompt: string,
  mode?: string,
  spec?: DesignSpecification
): boolean {
  if (mode === 'fast') return false;

  const normalizedPrompt = prompt.toLowerCase().trim();
  const explicitDims = spec?.explicitDimensions || [];
  const criticalDims = spec?.criticalDimensions || [];

  // If prompt has 2+ explicit dimensions and specific geometric shape commands, 1 high-precision plan is best
  const hasSpecificDims = (explicitDims.length + criticalDims.length) >= 2;
  const isDirectParametricFormula =
    hasSpecificDims &&
    (normalizedPrompt.includes('cylinder') ||
      normalizedPrompt.includes('cube') ||
      normalizedPrompt.includes('box') ||
      normalizedPrompt.includes('bracket') ||
      normalizedPrompt.includes('plate') ||
      normalizedPrompt.includes('screw') ||
      normalizedPrompt.includes('bolt') ||
      normalizedPrompt.includes('adapter')) &&
    /\d+\s*(mm|cm)/i.test(normalizedPrompt);

  if (isDirectParametricFormula) {
    return false;
  }

  // Explicit user requests for concepts / options / alternatives using word boundaries
  const hasAlternativeWord = /\b(options?|concepts?|alternatives?|variations?|explore)\b/i.test(normalizedPrompt);
  if (hasAlternativeWord) {
    return true;
  }

  // Check for structural ambiguity: functional goal is known, but topology is open-ended
  const hasFunctionalArchetype =
    /\b(holder|stand|organizer|mount|caddy|bracket|clip|case|housing|enclosure|tray|rack|dock)\b/i.test(normalizedPrompt);

  const isStructuralAmbiguity =
    hasFunctionalArchetype &&
    explicitDims.length < 2 &&
    !/\d+\s*x\s*\d+\s*x\s*\d+/i.test(normalizedPrompt);

  return isStructuralAmbiguity;
}

/**
 * Shared helper to determine whether a requirement represents a critical design/manufacturing constraint.
 * Critical includes: mounting requirements, hardware interfaces, mating interfaces, fit requirements,
 * required openings, fastener features, locked dimensions, exact compatibility dimensions,
 * required physical part count, explicit functional features, and high-confidence requirements.
 */
export function isCriticalDesignRequirement(
  req: {
    name?: string;
    description?: string;
    importance?: string;
    isCritical?: boolean;
    confidence?: number;
    category?: string;
  } | string,
  designState?: ProjectDesignState
): boolean {
  const text = typeof req === 'string'
    ? req
    : `${req.name || ''} ${req.description || ''} ${req.category || ''} ${req.importance || ''}`;
  const lower = text.toLowerCase().trim();

  if (typeof req === 'object' && req !== null) {
    if (req.isCritical === true || req.importance === 'critical' || req.category === 'critical') {
      return true;
    }
  }

  // Check explicit keywords for critical functional and physical interfaces
  const criticalPatterns = [
    /\b(mounting|mount|bracket|screw|bolt|fastener|standoff|boss|hole|countersink|counterbore)\b/i,
    /\b(hardware|insert|threaded|m[1-8]|v-slot|t-slot|rail|rod|bearing|motor|servo|pcb)\b/i,
    /\b(mating|snap|latch|slide|joint|hinge|interlock|dovetail|tab|slot|clearance|tolerance)\b/i,
    /\b(fit|fits|needs to fit|press fit|loose fit|tight fit|slip fit|socket|recess|cavity)\b/i,
    /\b(opening|port|cable|wire|usb|connector|switch|vent|ventilation|cutout|drainage)\b/i,
    /\b(must|exact|exactly|locked|do not change|critical|essential|required|mandatory)\b/i,
    /\b(dimension|dia|diameter|bore|shaft|width|height|depth|thickness|wall|spacing)\b/i,
    /\b(part count|piece count|quantity|pieces|parts)\b/i,
  ];

  for (const pattern of criticalPatterns) {
    if (pattern.test(lower)) return true;
  }

  // Check against ProjectDesignState locked / hardware / mating items
  if (designState) {
    if (designState.hardwareInterfaces?.some((hw) => lower.includes(hw.toLowerCase()) || hw.toLowerCase().includes(lower))) return true;
    if (designState.matingInterfaces?.some((mi) => lower.includes(mi.toLowerCase()) || mi.toLowerCase().includes(lower))) return true;
    if (designState.lockedDimensions?.some((ld) => lower.includes((ld.name || '').toLowerCase()))) return true;
    if (designState.requiredFeatures?.some((rf) => ((rf as any).isCritical || (rf.confidence ?? 0) >= 0.85) && lower.includes((rf.name || '').toLowerCase()))) return true;
  }

  if (typeof req === 'object' && req !== null && typeof req.confidence === 'number' && req.confidence >= 0.85) {
    return true;
  }

  return false;
}

/**
 * Derives expected physical pieces count and unique part types from prompt, spec, and design state.
 * Correctly distinguishes e.g. "one bracket and four spacers" (5 physical pieces, 2 unique part types).
 */
export function deriveExpectedPartCounts(
  prompt: string,
  spec?: DesignSpecification,
  designState?: ProjectDesignState
): {
  expectedPhysicalPieces: number;
  expectedUniquePartTypes: number;
  partDescriptions: string[];
} {
  const lowerPrompt = prompt.toLowerCase();

  const wordMap: Record<string, number> = {
    one: 1, a: 1, an: 1, two: 2, three: 3, four: 4, five: 5,
    six: 6, seven: 7, eight: 8, nine: 9, ten: 10, pair: 2,
  };

  const multiPartRegex = /(?:(\d+|one|two|three|four|five|six|seven|eight|nine|ten|a|an|pair)\s+([a-z0-9_-]+))/gi;
  const matches: Array<{ count: number; name: string }> = [];
  const nonPartTerms = new Set(['mm', 'cm', 'in', 'inch', 'inches', 'deg', 'degree', 'degrees', 'percent', '%', 'x', 'times']);

  let match: RegExpExecArray | null;
  while ((match = multiPartRegex.exec(lowerPrompt)) !== null) {
    const rawCount = match[1].toLowerCase();
    const rawName = match[2].toLowerCase();
    if (nonPartTerms.has(rawName)) continue;

    const count = typeof wordMap[rawCount] === 'number' ? wordMap[rawCount] : parseInt(rawCount, 10);
    if (!isNaN(count) && count > 0 && count <= 50) {
      const partLikelihood = /\b(bracket|spacer|pin|lid|cover|base|cap|body|slider|lever|knob|arm|hinge|clamp|plate|tray|housing|enclosure|caddy|mount|stand|adapter|insert|plug|foot|feet|wheel|gear|link)\b/i.test(rawName);
      if (partLikelihood) {
        matches.push({ count, name: rawName });
      }
    }
  }

  if (matches.length > 0) {
    const totalPieces = matches.reduce((sum, m) => sum + m.count, 0);
    const uniqueTypes = new Set(matches.map((m) => m.name)).size;
    return {
      expectedPhysicalPieces: totalPieces,
      expectedUniquePartTypes: uniqueTypes,
      partDescriptions: matches.map((m) => `${m.count}x ${m.name}`),
    };
  }

  // Standard multi-part idioms
  if (/\b(body,?\s+lid\s+and\s+hinge\s+pin|base,?\s+lid\s+and\s+pin)\b/i.test(lowerPrompt)) {
    return { expectedPhysicalPieces: 3, expectedUniquePartTypes: 3, partDescriptions: ['body', 'lid', 'hinge pin'] };
  }
  if (/\b(base\s+and\s+removable\s+lid|box\s+and\s+lid|body\s+and\s+lid|enclosure\s+and\s+cover|2-piece|two piece|two-piece|split)\b/i.test(lowerPrompt)) {
    return { expectedPhysicalPieces: 2, expectedUniquePartTypes: 2, partDescriptions: ['base', 'lid'] };
  }
  if (/\b(clamp|hinge\s+assembly|assembled\s+joint)\b/i.test(lowerPrompt)) {
    return { expectedPhysicalPieces: 2, expectedUniquePartTypes: 2, partDescriptions: ['part 1', 'part 2'] };
  }

  return {
    expectedPhysicalPieces: 1,
    expectedUniquePartTypes: 1,
    partDescriptions: ['main body'],
  };
}

/**
 * Canonical matcher to verify if a dimension requirement corresponds semantically
 * and numerically to a planned feature parameter.
 * Enforces meaning-first matching (geometry context, purpose, axis, parameter name)
 * before comparing numeric values.
 */
export function matchDimensionRequirementToPlanParameter(
  dimension: {
    name?: string;
    axis?: string;
    value: number;
    tolerance?: number;
    isCritical?: boolean;
    type?: string;
    targetFeature?: string;
    purpose?: string;
    relationship?: string;
  },
  feature: SemanticFeaturePlanFeature,
  parameterName: string,
  parameter: any
): {
  matched: boolean;
  semanticScore: number;
  reason: string;
} {
  const targetVal = dimension.value;
  if (typeof targetVal !== 'number' || isNaN(targetVal)) {
    return { matched: false, semanticScore: 0, reason: 'Invalid target dimension value' };
  }

  const actualVal = typeof parameter === 'object' && parameter !== null ? parameter.value : parameter;
  if (typeof actualVal !== 'number' || isNaN(actualVal)) {
    return { matched: false, semanticScore: 0, reason: 'Parameter value is non-numeric' };
  }

  const dName = (dimension.name || '').toLowerCase().trim();
  const dAxis = (dimension.axis || '').toLowerCase().trim();
  const pName = parameterName.toLowerCase().trim();
  const pDesc = (typeof parameter === 'object' && parameter !== null && parameter.description ? String(parameter.description) : '').toLowerCase();
  
  const fType = String(feature.type || '').toUpperCase();
  const fLabel = (feature.label || feature.id || '').toLowerCase();
  const fPurpose = (feature.purpose || '').toLowerCase();
  const fOp = (feature.geometryOperation || '').toLowerCase();

  // 1. Spacing & Pitch vs Body Dimensions
  const isDimSpacing = dName.includes('spacing') || dName.includes('pitch') || dName.includes('center_distance') || dName.includes('mountspacing') || dName.includes('holespacing');
  const isParamSpacing = pName.includes('spacing') || pName.includes('pitch') || pName.includes('center_distance') || pName.includes('mountspacing') || pName.includes('holespacing') || pName.includes('c2c') || pName.includes('span');
  const isFeatureSpacingOrPattern = fType.includes('PATTERN') || fType.includes('ARRAY') || fLabel.includes('spacing') || fLabel.includes('pattern') || fLabel.includes('mount') || fPurpose.includes('spacing') || fPurpose.includes('pattern');

  if (isDimSpacing) {
    if (!isParamSpacing && !isFeatureSpacingOrPattern) {
      return {
        matched: false,
        semanticScore: 0,
        reason: `Dimension '${dimension.name}' is a spacing requirement, but parameter '${parameterName}' on ${fLabel} is not a spacing parameter.`,
      };
    }
  } else {
    // If dimension is NOT spacing, but parameter IS a spacing parameter (e.g. holeSpacing)
    if (isParamSpacing && (dName.includes('width') || dName.includes('length') || dName.includes('height') || dName.includes('depth') || dAxis === 'x' || dAxis === 'y' || dAxis === 'z')) {
      return {
        matched: false,
        semanticScore: 0,
        reason: `Parameter '${parameterName}' represents a pattern/hole spacing, not overall '${dimension.name}'.`,
      };
    }
  }

  // 2. Hole / Bore Dimensions
  const isDimHole = (dName.includes('hole') || dName.includes('bore') || dName.includes('screw') || dName.includes('bolt') || dName.includes('countersink') || dName.includes('counterbore') || (dName.includes('dia') && !dName.includes('outer') && !dName.includes('body')));
  const isFeatureHole = fType.includes('HOLE') || fType.includes('BORE') || fType.includes('COUNTERSINK') || fType.includes('COUNTERBORE') || fOp === 'subtract' || fLabel.includes('hole') || fLabel.includes('bore') || fPurpose.includes('hole') || fPurpose.includes('bore') || fPurpose.includes('fastener');
  const isParamHole = pName.includes('hole') || pName.includes('bore') || pName.includes('dia') || pName.includes('radius') || pName === 'd' || pName === 'r';

  if (isDimHole && !isDimSpacing) {
    if (!isFeatureHole || !isParamHole) {
      return {
        matched: false,
        semanticScore: 0,
        reason: `Dimension '${dimension.name}' requires a hole/bore feature, but '${fLabel}' (${fType}) is not a hole geometry.`,
      };
    }
  }

  // 3. Clearance & Fit
  const isDimClearance = dName.includes('clearance') || dName.includes('gap') || dName.includes('tolerance') || dName.includes('allowance');
  const isParamClearance = pName.includes('clearance') || pName.includes('gap') || pName.includes('tolerance') || pName.includes('fit') || pName.includes('offset');
  if (isDimClearance) {
    if (!isParamClearance) {
      return {
        matched: false,
        semanticScore: 0,
        reason: `Dimension '${dimension.name}' is a clearance/fit specification, but '${parameterName}' is not a clearance parameter.`,
      };
    }
    // Specific check: device clearance vs lid clearance
    if (dName.includes('device') || dName.includes('cavity') || dName.includes('object') || dName.includes('phone') || dName.includes('controller')) {
      if (fLabel.includes('lid') || fPurpose.includes('lid') || pName.includes('lid')) {
        return {
          matched: false,
          semanticScore: 0,
          reason: `Device clearance cannot be satisfied by lid clearance '${parameterName}'.`,
        };
      }
    }
  }

  // 4. Wall & Shell Thickness
  const isDimWall = dName.includes('wall') || dName.includes('thickness') || dName.includes('bottomthickness');
  const isParamWall = pName.includes('wall') || pName.includes('thickness') || pName.includes('shell');
  if (isDimWall && !dName.includes('overall') && !dName.includes('plate') && !dName.includes('body')) {
    if (!isParamWall) {
      return {
        matched: false,
        semanticScore: 0,
        reason: `Wall thickness '${dimension.name}' cannot match general outer dimension '${parameterName}'.`,
      };
    }
  }

  // 5. Overall Body / Plate Dimensions (Width, Length, Height, Depth, Axis X/Y/Z)
  const isDimOverall = dName.includes('overall') || dName.includes('body') || dName.includes('plate') || dName.includes('enclosure') || dName === 'width' || dName === 'length' || dName === 'depth' || dName === 'height' || dAxis === 'x' || dAxis === 'y' || dAxis === 'z';
  const isFeatureBody = fOp === 'base' || fType === 'BASE_BODY' || fType === 'PLATE' || fType === 'SOLID_BODY' || fType === 'ENCLOSURE' || fType === 'BOX' || fType === 'SHELL' || fLabel.includes('base') || fLabel.includes('body') || fLabel.includes('plate') || fLabel.includes('enclosure') || fPurpose.includes('primary') || fPurpose.includes('base') || fPurpose.includes('plate') || fPurpose.includes('solid');

  if (isDimOverall && !isDimHole && !isDimSpacing && !isDimClearance && !isDimWall) {
    // Must be on base / body / plate feature context
    if (!isFeatureBody && !fLabel.includes('bracket') && !fLabel.includes('mount') && !fLabel.includes('tray') && !fLabel.includes('caddy')) {
      return {
        matched: false,
        semanticScore: 0,
        reason: `Overall dimension '${dimension.name}' must be matched on the main body/plate feature, not '${fLabel}'.`,
      };
    }
  }

  // 6. Semantic Axis & Parameter Name Match Scoring
  let semanticScore = 0;
  if (dName && (pName.includes(dName) || dName.includes(pName))) {
    semanticScore += 0.8;
  }
  if (dAxis === 'x' && (pName.includes('width') || pName.includes('length') || pName.includes('dim_x') || pName.includes('dimx') || pName.includes('size_x') || pName === 'x' || pName === 'w')) {
    semanticScore += 0.7;
  }
  if (dAxis === 'y' && (pName.includes('depth') || pName.includes('width') || pName.includes('length') || pName.includes('dim_y') || pName.includes('dimy') || pName.includes('size_y') || pName === 'y' || pName === 'l' || pName === 'd')) {
    semanticScore += 0.7;
  }
  if (dAxis === 'z' && (pName.includes('height') || pName.includes('thickness') || pName.includes('dim_z') || pName.includes('dimz') || pName.includes('size_z') || pName === 'z' || pName === 'h' || pName === 't')) {
    semanticScore += 0.7;
  }
  if (isDimHole && isFeatureHole && isParamHole) {
    semanticScore += 0.9;
  }
  if (isDimSpacing && (isParamSpacing || isFeatureSpacingOrPattern)) {
    semanticScore += 0.9;
  }
  if (isDimClearance && isParamClearance) {
    semanticScore += 0.9;
  }
  if (isDimWall && isParamWall) {
    semanticScore += 0.9;
  }
  if (pDesc && dName && pDesc.includes(dName)) {
    semanticScore += 0.3;
  }

  if (semanticScore < 0.5) {
    return {
      matched: false,
      semanticScore,
      reason: `Parameter '${parameterName}' on '${fLabel}' does not semantically correspond to '${dimension.name}'.`,
    };
  }

  // 7. Numeric Value & Tolerance Verification
  const tolerance = dimension.tolerance !== undefined && typeof dimension.tolerance === 'number'
    ? dimension.tolerance
    : Math.max(0.8, Math.abs(targetVal) * 0.05);

  const diff = Math.abs(actualVal - targetVal);
  if (diff <= tolerance) {
    return {
      matched: true,
      semanticScore: Math.min(1.0, semanticScore),
      reason: `Matched '${parameterName}' (${actualVal}mm) in feature '${fLabel}' to '${dimension.name}' (${targetVal}mm, diff: ${diff.toFixed(2)}mm).`,
    };
  }

  return {
    matched: false,
    semanticScore: Math.min(1.0, semanticScore),
    reason: `Semantic match on '${parameterName}' in '${fLabel}', but value ${actualVal}mm is outside tolerance (target: ${targetVal}mm, diff: ${diff.toFixed(2)}mm > tol: ${tolerance.toFixed(2)}mm).`,
  };
}

/**
 * Builds normalized topological signature for a SemanticFeaturePlan.
 * Used for deep structural deduplication rather than relying on generationStrategy text.
 */
export function buildSemanticPlanTopologySignature(plan: SemanticFeaturePlan): string {
  if (!plan) return 'empty_plan';

  const parts = Array.isArray(plan.parts) && plan.parts.length > 0 ? plan.parts : [];
  const uniquePartCount = parts.length > 0 ? parts.length : 1;
  const physicalPieces = parts.length > 0
    ? parts.reduce((sum, p) => sum + (typeof p.quantity === 'number' ? p.quantity : 1), 0)
    : (plan.expectedPartCount || 1);

  const features = Array.isArray(plan.features) ? plan.features : [];
  const featureTypes = features.map((f) => String(f.type || 'CUSTOM_PARAMETRIC')).sort().join(',');
  const featureArchitecture = features
    .map((f) => `${f.geometryOperation || 'base'}:${f.type}:${f.partId || 'main'}`)
    .sort()
    .join('|');

  const relationships = Array.isArray(plan.relationships)
    ? plan.relationships
        .map((r) => `${r.relationshipType || 'rel'}:${r.sourceFeatureId || ''}->${r.targetFeatureId || ''}`)
        .sort()
        .join(';')
    : '';

  const matingInterfaces = Array.isArray(plan.matingInterfaces)
    ? plan.matingInterfaces.map((m) => (typeof m === 'string' ? m : (m as any).type || '')).sort().join(',')
    : '';

  return `P${uniquePartCount}_Q${physicalPieces}_F[${featureTypes}]_ARCH[${featureArchitecture}]_REL[${relationships}]_MATE[${matingInterfaces}]`;
}

/**
 * Shared, canonical coverage builder for a SemanticFeaturePlan against requirements.
 * Used by BOTH evaluateSemanticPlanCoverage and scoreSemanticFeaturePlan to avoid split logic.
 */
export function buildSemanticPlanCoverageItems(
  plan: SemanticFeaturePlan,
  spec?: DesignSpecification,
  designState?: ProjectDesignState
): SemanticPlanCoverageItem[] {
  const items: SemanticPlanCoverageItem[] = [];
  const planFeatures = Array.isArray(plan?.features) ? plan.features : [];

  // 1. Required Features from Spec & DesignState
  const reqFeatures = [
    ...(spec?.requiredFeatures || []),
    ...(designState?.requiredFeatures || []),
  ];
  const seenReqs = new Set<string>();

  reqFeatures.forEach((rf) => {
    const name = rf.name || rf.description || 'Feature';
    if (seenReqs.has(name.toLowerCase())) return;
    seenReqs.add(name.toLowerCase());

    const isFunctionallyCritical = isCriticalDesignRequirement(rf, designState);

    const matchingFeats = planFeatures.filter((pf) => {
      const pLabel = (pf.label || pf.id || '').toLowerCase();
      const pPurpose = (pf.purpose || '').toLowerCase();
      const nLower = name.toLowerCase();
      return pLabel.includes(nLower) || nLower.includes(pLabel) || pPurpose.includes(nLower);
    });

    if (matchingFeats.length > 0) {
      items.push({
        requirement: name,
        importance: isFunctionallyCritical ? 'critical' : 'important',
        matchedFeatureIds: matchingFeats.map((m) => m.id),
        status: 'matched',
        reason: `Matched with ${matchingFeats.map((m) => m.label || m.id).join(', ')}`,
      });
    } else {
      items.push({
        requirement: name,
        importance: isFunctionallyCritical ? 'critical' : 'important',
        matchedFeatureIds: [],
        status: 'unresolved',
        reason: `No corresponding geometry feature in semantic plan`,
      });
    }
  });

  // 2. Hardware & Mating Interfaces from Design State
  if (designState?.hardwareInterfaces) {
    designState.hardwareInterfaces.forEach((hw) => {
      if (seenReqs.has(hw.toLowerCase())) return;
      seenReqs.add(hw.toLowerCase());
      const matchingFeats = planFeatures.filter((pf) => {
        const text = `${pf.label} ${pf.purpose} ${pf.id}`.toLowerCase();
        return text.includes(hw.toLowerCase()) || hw.toLowerCase().includes(pf.label.toLowerCase());
      });
      items.push({
        requirement: `Hardware: ${hw}`,
        importance: 'critical',
        matchedFeatureIds: matchingFeats.map((m) => m.id),
        status: matchingFeats.length > 0 ? 'matched' : 'unresolved',
        reason: matchingFeats.length > 0 ? `Satisfied by ${matchingFeats.map((m) => m.label).join(', ')}` : 'Hardware interface missing in semantic plan',
      });
    });
  }

  if (designState?.matingInterfaces) {
    designState.matingInterfaces.forEach((mi) => {
      if (seenReqs.has(mi.toLowerCase())) return;
      seenReqs.add(mi.toLowerCase());
      const hasMating = Array.isArray(plan.matingInterfaces) && plan.matingInterfaces.length > 0;
      items.push({
        requirement: `Mating Interface: ${mi}`,
        importance: 'critical',
        matchedFeatureIds: [],
        status: hasMating ? 'matched' : 'unresolved',
        reason: hasMating ? 'Mating interface registered in plan' : 'Mating interface definition missing in plan',
      });
    });
  }

  // 3. Exact and Critical Dimensions with Canonical Semantic Matching
  const allDims = [
    ...(spec?.criticalDimensions || []),
    ...(spec?.explicitDimensions || []),
    ...(designState?.lockedDimensions || []),
    ...(designState?.exactDimensions || []),
  ];

  const seenDims = new Set<string>();
  allDims.forEach((cd) => {
    const dimName = cd.name || `Dim_${cd.axis || 'val'}_${cd.value}`;
    const dimKey = `${dimName.toLowerCase()}_${cd.value}_${cd.axis || ''}`;
    if (seenDims.has(dimKey)) return;
    seenDims.add(dimKey);

    const isCrit = isCriticalDesignRequirement(cd, designState) || Boolean(cd.isCritical) || cd.source === 'explicit';

    // Search features using canonical matchDimensionRequirementToPlanParameter
    let bestMatch: { feature: SemanticFeaturePlanFeature; paramName: string; reason: string; semanticScore: number } | null = null;
    let semanticallyCompatibleUnmatched: { feature: SemanticFeaturePlanFeature; paramName: string; reason: string } | null = null;

    for (const feat of planFeatures) {
      if (!feat.parameters) continue;
      for (const [pName, pVal] of Object.entries(feat.parameters)) {
        const res = matchDimensionRequirementToPlanParameter(cd, feat, pName, pVal);
        if (res.matched) {
          if (!bestMatch || res.semanticScore > bestMatch.semanticScore) {
            bestMatch = { feature: feat, paramName: pName, reason: res.reason, semanticScore: res.semanticScore };
          }
        } else if (res.semanticScore >= 0.5 && !semanticallyCompatibleUnmatched) {
          semanticallyCompatibleUnmatched = { feature: feat, paramName: pName, reason: res.reason };
        }
      }
    }

    if (bestMatch) {
      items.push({
        requirement: `${dimName} (${cd.value}mm)`,
        importance: isCrit ? 'critical' : 'important',
        matchedFeatureIds: [bestMatch.feature.id],
        status: 'matched',
        reason: bestMatch.reason,
      });
    } else if (semanticallyCompatibleUnmatched) {
      items.push({
        requirement: `${dimName} (${cd.value}mm)`,
        importance: isCrit ? 'critical' : 'important',
        matchedFeatureIds: [semanticallyCompatibleUnmatched.feature.id],
        status: 'unresolved',
        reason: semanticallyCompatibleUnmatched.reason,
      });
    } else {
      items.push({
        requirement: `${dimName} (${cd.value}mm)`,
        importance: isCrit ? 'critical' : 'important',
        matchedFeatureIds: [],
        status: 'unresolved',
        reason: `Critical dimension ${cd.value}mm not found in corresponding semantic feature parameters`,
      });
    }
  });

  return items;
}

export function scoreSemanticFeaturePlan(
  plan: SemanticFeaturePlan,
  spec: DesignSpecification,
  prompt: string,
  designState?: ProjectDesignState
): { score: number; breakdown: Record<string, number | null> } {
  const planFeatures = Array.isArray(plan?.features) ? plan.features : [];
  let totalWeightedScore = 0;
  let totalActiveWeight = 0;

  // Build unified canonical coverage items
  const coverageItems = buildSemanticPlanCoverageItems(plan, spec, designState);

  // 1. Required features coverage
  const reqItems = coverageItems.filter((i) => !i.requirement.startsWith('Hardware:') && !i.requirement.startsWith('Mating Interface:') && !i.requirement.includes('('));
  let reqCoverage: number | null = null;
  if (reqItems.length > 0) {
    const matched = reqItems.filter((i) => i.status === 'matched').length;
    reqCoverage = Math.round((matched / reqItems.length) * 100);
    totalWeightedScore += reqCoverage * 0.20;
    totalActiveWeight += 0.20;
  }

  // 2. Critical features & requirements coverage
  const critItems = coverageItems.filter((i) => i.importance === 'critical');
  let criticalCoverage: number | null = null;
  if (critItems.length > 0) {
    const critMatched = critItems.filter((i) => i.status === 'matched').length;
    criticalCoverage = Math.round((critMatched / critItems.length) * 100);
    totalWeightedScore += criticalCoverage * 0.20;
    totalActiveWeight += 0.20;
  }

  // 3. Exact dimension coverage strictly from dimension items
  const dimItems = coverageItems.filter((i) => i.requirement.includes('(') && i.requirement.includes('mm)'));
  let dimCoverage: number | null = null;
  if (dimItems.length > 0) {
    const dimsMatched = dimItems.filter((i) => i.status === 'matched').length;
    dimCoverage = Math.round((dimsMatched / dimItems.length) * 100);
    totalWeightedScore += dimCoverage * 0.20;
    totalActiveWeight += 0.20;
  }
  let registryScore = 0;
  if (planFeatures.length > 0) {
    const registeredCount = planFeatures.filter(
      (f) => f.type !== 'CUSTOM_PARAMETRIC' && Boolean(FEATURE_REGISTRY[f.type as FeatureType])
    ).length;
    registryScore = Math.round((registeredCount / planFeatures.length) * 100);
    totalWeightedScore += registryScore * 0.10;
    totalActiveWeight += 0.10;
  }

  // 5. Printability Feasibility: EVIDENCE-BASED (starts at 0, NO free baseline)
  let printabilityScore = 0;
  const hasBase = planFeatures.some(
    (f) =>
      f.geometryOperation === 'base' ||
      f.type === 'BASE_BODY' ||
      f.type === 'PLATE' ||
      (f.label || '').toLowerCase().includes('base') ||
      (f.purpose || '').toLowerCase().includes('base')
  );
  if (hasBase) {
    printabilityScore += 35;
  }

  const hasReasonableWallThickness = planFeatures.some((f) => {
    if (!f.parameters) return false;
    return Object.entries(f.parameters).some(([k, v]) => {
      const paramKey = k.toLowerCase();
      const val = typeof v === 'object' && v !== null ? (v as any).value : v;
      return (
        (paramKey.includes('wall') || paramKey.includes('thickness')) &&
        typeof val === 'number' &&
        val >= 1.6
      );
    });
  });
  if (hasReasonableWallThickness) {
    printabilityScore += 35;
  }

  if (plan.expectedPartCount >= 1 && plan.expectedPartCount <= 4) {
    printabilityScore += 15;
  }

  const hasCoherentOps = planFeatures.some((f) => f.geometryOperation === 'add' || f.geometryOperation === 'subtract');
  if (hasCoherentOps) {
    printabilityScore += 15;
  }

  printabilityScore = Math.min(100, printabilityScore);
  totalWeightedScore += printabilityScore * 0.10;
  totalActiveWeight += 0.10;

  // 6. Editability: EVIDENCE-BASED (starts at 0, NO free 20)
  let editability = 0;
  if (planFeatures.length > 0) {
    const parameterizedFeatures = planFeatures.filter(
      (f) => f.parameters && Object.keys(f.parameters).length > 0
    ).length;
    editability += Math.round((parameterizedFeatures / planFeatures.length) * 35);
  }
  if (Array.isArray(plan.derivedParameters) && plan.derivedParameters.length > 0) {
    editability += 20;
  }
  if (Array.isArray(plan.constraints) && plan.constraints.length > 0) {
    editability += 20;
  }
  const hasRichMetadata = planFeatures.some((f) => {
    if (!f.parameters) return false;
    return Object.values(f.parameters).some((p: any) => typeof p === 'object' && p !== null && (p.locked || p.min !== undefined || p.unit));
  });
  if (hasRichMetadata) {
    editability += 25;
  }
  editability = Math.min(100, editability);
  totalWeightedScore += editability * 0.10;
  totalActiveWeight += 0.10;

  // 7. Fit Interfaces
  const fitReqs = spec?.fitRequirements || [];
  let interfaceScore: number | null = null;
  if (fitReqs.length > 0) {
    if (Array.isArray(plan.matingInterfaces) && plan.matingInterfaces.length > 0) {
      interfaceScore = Math.min(100, Math.round((plan.matingInterfaces.length / fitReqs.length) * 100));
    } else {
      interfaceScore = 0;
    }
    totalWeightedScore += interfaceScore * 0.10;
    totalActiveWeight += 0.10;
  }

  // 8. Part Count Appropriateness: EVIDENCE-BASED (uses deriveExpectedPartCounts)
  let partAppropriateness = 0;
  const actualPartsSum = Array.isArray(plan.parts)
    ? plan.parts.reduce((sum, p) => sum + (typeof p.quantity === 'number' ? p.quantity : 1), 0)
    : plan.expectedPartCount || 1;

  const expectedCounts = deriveExpectedPartCounts(prompt, spec, designState);
  const expectedPieces = expectedCounts.expectedPhysicalPieces;

  if (actualPartsSum === expectedPieces) {
    partAppropriateness = 100;
  } else if (Math.abs(actualPartsSum - expectedPieces) === 1) {
    partAppropriateness = 75;
  } else if (Math.abs(actualPartsSum - expectedPieces) === 2) {
    partAppropriateness = 50;
  } else if (actualPartsSum >= 1 && actualPartsSum <= 6) {
    partAppropriateness = 35;
  } else {
    partAppropriateness = 10;
  }

  totalWeightedScore += partAppropriateness * 0.10;
  totalActiveWeight += 0.10;

  const normalizedScore = totalActiveWeight > 0 ? Math.round(totalWeightedScore / totalActiveWeight) : 50;

  return {
    score: Math.min(100, Math.max(0, normalizedScore)),
    breakdown: {
      requiredFeatureCoverage: reqCoverage,
      criticalFeatureCoverage: criticalCoverage,
      exactDimensionCoverage: dimCoverage,
      fitInterfaceCompleteness: interfaceScore,
      registeredFeatureRatio: registryScore,
      printabilityFeasibility: printabilityScore,
      editability,
      partCountAppropriateness: partAppropriateness,
    },
  };
}

export function evaluateSemanticPlanCoverage(
  plan: SemanticFeaturePlan,
  spec: DesignSpecification,
  designState?: ProjectDesignState
): SemanticPlanCoverageReport {
  const items = buildSemanticPlanCoverageItems(plan, spec, designState);

  const criticalItems = items.filter((i) => i.importance === 'critical');
  const unresolvedCritical = criticalItems.filter((i) => i.status === 'unresolved');
  const matchedCount = items.filter((i) => i.status === 'matched').length;
  const coveragePercent = items.length > 0 ? Math.round((matchedCount / items.length) * 100) : null;

  let clarificationNeeded: string | undefined = undefined;
  if (unresolvedCritical.length > 0) {
    clarificationNeeded = `Unresolved critical requirements: ${unresolvedCritical.map((u) => u.requirement).join('; ')}`;
  }

  return {
    items,
    coveragePercent,
    allCriticalPassed: unresolvedCritical.length === 0,
    unresolvedCriticalCount: unresolvedCritical.length,
    clarificationNeeded,
  };
}

export function summarizeCadSemanticStructure(code: string): string {
  if (!code || typeof code !== 'string') return 'Empty CAD code';

  const lines = code.split('\n');
  const topLevelParams: string[] = [];
  const derivedParams: string[] = [];
  const featureFunctions: string[] = [];
  const partFunctions: string[] = [];
  const builderInvocations: string[] = [];
  let mainReturnSection = '';
  let inMain = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    // Top-level constants / parameters
    if (/^const\s+[A-Z0-9_]+\s*=\s*[^;]+;/.test(line)) {
      topLevelParams.push(line);
    } else if (line.includes('KP_DERIVED') || line.includes('derived')) {
      derivedParams.push(line);
    }

    // Feature functions
    if (/function\s+kpFeature_[a-zA-Z0-9_]+/.test(line) || /const\s+kpFeature_[a-zA-Z0-9_]+\s*=/.test(line)) {
      featureFunctions.push(line.replace(/\{.*/, '{ ... }'));
    }

    // Part functions
    if (/function\s+kpPart_[a-zA-Z0-9_]+/.test(line) || /const\s+kpPart_[a-zA-Z0-9_]+\s*=/.test(line)) {
      partFunctions.push(line.replace(/\{.*/, '{ ... }'));
    }

    // Builder invocations
    if (
      line.includes('createThroughHole') ||
      line.includes('createSnapJoint') ||
      line.includes('createMountingTab') ||
      line.includes('createFilletedBox') ||
      line.includes('createBasePlate') ||
      line.includes('createLipJoint')
    ) {
      builderInvocations.push(line);
    }

    // Main return structure
    if (line.includes('function main(') || line.includes('const main =')) {
      inMain = true;
    }
    if (inMain && (line.startsWith('return') || line.includes('getParts()'))) {
      mainReturnSection += line + '\n';
    }
  }

  const summaryParts: string[] = [
    `=== CAD SEMANTIC STRUCTURE SUMMARY ===`,
    `Total Code Length: ${code.length} chars, ${lines.length} lines`,
    `\n--- Top-Level Parameters (${topLevelParams.length}) ---`,
    topLevelParams.slice(0, 30).join('\n') || 'None declared',
    `\n--- Derived Parameters (${derivedParams.length}) ---`,
    derivedParams.slice(0, 15).join('\n') || 'None declared',
    `\n--- Feature Functions (${featureFunctions.length}) ---`,
    featureFunctions.join('\n') || 'None declared',
    `\n--- Part Functions (${partFunctions.length}) ---`,
    partFunctions.join('\n') || 'None declared',
    `\n--- Standard Builder Invocations (${builderInvocations.length}) ---`,
    builderInvocations.slice(0, 20).join('\n') || 'None detected',
    `\n--- Main Assembly Return ---`,
    mainReturnSection || 'Standard return [ ... ]',
  ];

  if (code.length <= 25000) {
    summaryParts.push(`\n=== COMPLETE JSCAD SOURCE CODE ===\n${code}`);
  } else {
    summaryParts.push(`\n=== JSCAD SOURCE CODE SAMPLE (First 10,000 + Last 5,000 chars) ===\n${code.slice(0, 10000)}\n\n/* ... [middle section omitted for length] ... */\n\n${code.slice(-5000)}`);
  }

  return summaryParts.join('\n');
}

export function scoreAndSelectBestPlan(
  candidatePlans: any[],
  spec: DesignSpecification,
  checklist?: DesignCheck[],
  designState?: ProjectDesignState
): any {
  if (!Array.isArray(candidatePlans) || candidatePlans.length === 0) {
    throw new Error('No candidate plans provided');
  }

  const scored = candidatePlans.map((plan) => {
    let score = 50;
    if (plan.features) {
      const s = scoreSemanticFeaturePlan(plan, spec, spec.primaryObject || '', designState);
      score = s.score;
    } else if (plan.feasibilityScore !== undefined && plan.printabilityScore !== undefined) {
      const pScore = typeof plan.preservationScore === 'number' ? plan.preservationScore : 50;
      score = plan.feasibilityScore * 0.5 + plan.printabilityScore * 0.3 + pScore * 0.2;
    }

    return {
      ...plan,
      totalScore: Math.round(score),
    };
  });

  scored.sort((a, b) => b.totalScore - a.totalScore);
  return scored[0];
}

export function planSemanticFeatureModelFromPlan(
  plan: SemanticFeaturePlan,
  prompt: string,
  spec: DesignSpecification
): SemanticFeatureModel {
  const modelId = plan.id || `sfm_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const rawFeatures = Array.isArray(plan.features) ? plan.features : [];

  const features: SemanticFeature[] = [];
  const parameters: FeatureParameter[] = [];
  const relationships: FeatureRelationship[] = [];
  const constraints: FeatureConstraint[] = [];

  let baseFeatureId = '';

  rawFeatures.forEach((rf, fIdx) => {
    const featId = rf.id || `feat_${fIdx + 1}_${(rf.type || 'feature').toLowerCase()}`;
    const rawType = String(rf.type || 'CUSTOM_PARAMETRIC').toUpperCase() as FeatureType;
    const type: FeatureType = FEATURE_REGISTRY[rawType] ? rawType : 'CUSTOM_PARAMETRIC';
    const geomOp: GeometryOperation = rf.geometryOperation || (fIdx === 0 ? 'base' : 'add');
    if (geomOp === 'base' && !baseFeatureId) {
      baseFeatureId = featId;
    }

    const paramMap: Record<string, number | string | boolean> = {};
    const paramIds: string[] = [];

    if (rf.parameters && typeof rf.parameters === 'object') {
      Object.entries(rf.parameters).forEach(([pKey, pVal]) => {
        let val: number | string | boolean;
        let unit: ParameterUnit = 'mm';
        let source: ParameterSource = 'explicit';
        let isLocked = false;
        let isCritical = false;
        let desc = '';
        let minVal: number | undefined = undefined;
        let maxVal: number | undefined = undefined;

        if (typeof pVal === 'object' && pVal !== null) {
          const obj = pVal as any;
          val = obj.value !== undefined ? obj.value : 0;
          unit = (obj.unit as ParameterUnit) || 'mm';
          source = (obj.source as ParameterSource) || 'explicit';
          isLocked = Boolean(obj.locked);
          isCritical = Boolean(obj.confidence && obj.confidence > 0.9);
          desc = obj.description || '';
          minVal = typeof obj.min === 'number' ? obj.min : undefined;
          maxVal = typeof obj.max === 'number' ? obj.max : undefined;
        } else {
          val = pVal as number | string | boolean;
        }

        const paramId = `${featId}_${pKey}`;
        paramMap[pKey] = val;
        paramIds.push(paramId);

        parameters.push(
          createFeatureParameter({
            id: paramId,
            featureId: featId,
            name: pKey,
            semanticName: paramId,
            value: val,
            unit,
            source,
            locked: isLocked,
            critical: isCritical,
            description: desc,
            min: minVal,
            max: maxVal,
          })
        );
      });
    }

    const feature: SemanticFeature = {
      id: featId,
      partId: rf.partId,
      type,
      label: rf.label || featId,
      purpose: rf.purpose || 'Functional mechanical geometric feature',
      parameters: paramMap,
      parameterIds: paramIds,
      parentFeatureId: rf.parentFeatureId,
      childFeatureIds: rf.childFeatureIds,
      source: 'explicit',
      criticality: rf.criticality || 'important',
      geometryOperation: geomOp,
      verificationStrategy: rf.verificationStrategy,
      aliases: rf.aliases,
      status: 'planned',
    };

    features.push(feature);
  });

  if (!baseFeatureId && features.length > 0) {
    baseFeatureId = features[0].id;
    features[0].geometryOperation = 'base';
  }

  // Process relationships
  if (Array.isArray(plan.relationships)) {
    plan.relationships.forEach((rel, rIdx) => {
      relationships.push(
        createFeatureRelationship({
          id: rel.id || `rel_${rIdx + 1}`,
          sourceFeatureId: rel.sourceFeatureId,
          targetFeatureId: rel.targetFeatureId,
          relationshipType: (rel.relationshipType as any) || 'attached_to',
          description: rel.description,
        })
      );
    });
  }

  // Process constraints
  if (Array.isArray(plan.constraints)) {
    plan.constraints.forEach((c, cIdx) => {
      constraints.push(
        createFeatureConstraint({
          id: c.id || `c_${cIdx + 1}`,
          name: c.name || `Constraint ${cIdx + 1}`,
          description: c.description || 'Geometric alignment and sizing constraint',
          constraintType: (c.constraintType as any) || 'min_value',
          affectedFeatureIds: Array.isArray(c.affectedFeatureIds) ? c.affectedFeatureIds : features.map((f) => f.id),
          parameterKeys: c.parameterKeys,
          value: c.value,
        })
      );
    });
  }

  // Add default minimum wall thickness constraint if none present
  if (!constraints.some((c) => c.name.toLowerCase().includes('wall thickness'))) {
    constraints.push(
      createFeatureConstraint({
        name: 'Minimum Wall Thickness',
        description: 'Ensures all printable walls remain at least 2.4 mm thick for rigidity',
        constraintType: 'min_value',
        affectedFeatureIds: features.map((f) => f.id),
        parameterKeys: ['wall_thickness', 'thickness', 'plate_thickness'],
        value: 2.4,
      })
    );
  }

  return {
    modelId,
    objectType: plan.objectSummary || spec.primaryObject || 'Mechanical Part',
    baseFeatureId: baseFeatureId || 'base_body',
    features,
    relationships,
    parameters,
    constraints,
    generationStrategy: plan.generationStrategy || spec.generationStrategy || 'Feature-based CSG construction',
    schemaVersion: 3,
  };
}

export function planSemanticFeatureModel(
  spec: DesignSpecification,
  prompt: string,
  checklist?: DesignCheck[],
  plan?: SemanticFeaturePlan
): SemanticFeatureModel {
  if (plan && Array.isArray(plan.features) && plan.features.length > 0) {
    return planSemanticFeatureModelFromPlan(plan, prompt, spec);
  }
  return planSemanticFeatureModelFallback(spec, prompt, checklist);
}

export function planSemanticFeatureModelFallback(
  spec: DesignSpecification,
  prompt: string,
  _checklist?: DesignCheck[]
): SemanticFeatureModel {
  const lowerPrompt = prompt.toLowerCase();
  const lowerObject = (spec.primaryObject || '').toLowerCase();
  const modelId = `sfm_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

  const features: SemanticFeature[] = [];
  const parameters: FeatureParameter[] = [];
  const relationships: FeatureRelationship[] = [];
  const constraints: FeatureConstraint[] = [];

  // Determine Primary Archetype
  const isSoapDish =
    lowerPrompt.includes('soap') ||
    lowerObject.includes('soap') ||
    lowerPrompt.includes('dr. squatch') ||
    lowerPrompt.includes('squatch');
  const isControllerMount =
    lowerPrompt.includes('controller') ||
    lowerPrompt.includes('xbox') ||
    lowerPrompt.includes('playstation') ||
    lowerPrompt.includes('gamepad');
  const isPhoneStand =
    lowerPrompt.includes('phone') ||
    lowerPrompt.includes('smartphone') ||
    lowerPrompt.includes('tablet stand') ||
    lowerPrompt.includes('desk stand');
  const isWallPlate =
    lowerPrompt.includes('wall plate') ||
    lowerPrompt.includes('faceplate') ||
    lowerPrompt.includes('mounting plate') ||
    lowerPrompt.includes('switch plate');

  // Base dimensions extracted or inferred
  const explicitDims = Array.isArray(spec?.explicitDimensions) ? spec.explicitDimensions : [];
  const inferredDims = Array.isArray(spec?.inferredDimensions) ? spec.inferredDimensions : [];

  const widthDim =
    explicitDims.find((d) => d.axis === 'x' || (d.name && d.name.toLowerCase().includes('width')))?.value ||
    inferredDims.find((d) => d.axis === 'x' || (d.name && d.name.toLowerCase().includes('width')))?.value ||
    (isSoapDish ? 120 : isControllerMount ? 140 : isPhoneStand ? 85 : isWallPlate ? 115 : 100);

  const depthDim =
    explicitDims.find((d) => d.axis === 'y' || (d.name && (d.name.toLowerCase().includes('depth') || d.name.toLowerCase().includes('length'))))?.value ||
    inferredDims.find((d) => d.axis === 'y' || (d.name && (d.name.toLowerCase().includes('depth') || d.name.toLowerCase().includes('length'))))?.value ||
    (isSoapDish ? 85 : isControllerMount ? 90 : isPhoneStand ? 80 : isWallPlate ? 70 : 80);

  const heightDim =
    explicitDims.find((d) => d.axis === 'z' || (d.name && (d.name.toLowerCase().includes('height') || d.name.toLowerCase().includes('thickness'))))?.value ||
    inferredDims.find((d) => d.axis === 'z' || (d.name && (d.name.toLowerCase().includes('height') || d.name.toLowerCase().includes('thickness'))))?.value ||
    (isSoapDish ? 20 : isControllerMount ? 65 : isPhoneStand ? 95 : isWallPlate ? 4 : 25);

  const baseFeatureId = isWallPlate || isControllerMount ? 'mounting_plate' : 'base_body';

  // 1. PRIMARY BASE FEATURE
  if (isWallPlate || isControllerMount) {
    const plateThickness = isWallPlate ? heightDim : 5;
    const feat: SemanticFeature = {
      id: baseFeatureId,
      type: 'PLATE',
      label: 'Mounting Plate',
      purpose: 'Primary structural base and mounting surface.',
      parameters: {
        width: widthDim,
        depth: depthDim,
        thickness: plateThickness,
      },
      parameterIds: ['plate_width', 'plate_depth', 'plate_thickness'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'base',
      aliases: ['base plate', 'mounting plate', 'flange plate', 'main plate'],
      status: 'planned',
    };
    features.push(feat);

    parameters.push(
      createFeatureParameter({
        id: 'plate_width',
        featureId: feat.id,
        name: 'width',
        semanticName: 'plate_width',
        value: widthDim,
        unit: 'mm',
        source: 'explicit',
        critical: true,
      }),
      createFeatureParameter({
        id: 'plate_depth',
        featureId: feat.id,
        name: 'depth',
        semanticName: 'plate_depth',
        value: depthDim,
        unit: 'mm',
        source: 'explicit',
        critical: true,
      }),
      createFeatureParameter({
        id: 'plate_thickness',
        featureId: feat.id,
        name: 'thickness',
        semanticName: 'plate_thickness',
        value: plateThickness,
        unit: 'mm',
        source: 'inferred',
        min: 2,
        max: 20,
      })
    );
  } else {
    const feat: SemanticFeature = {
      id: baseFeatureId,
      type: 'BASE_BODY',
      label: 'Base Body',
      purpose: 'Foundational solid body of the print.',
      parameters: {
        width: widthDim,
        depth: depthDim,
        height: heightDim,
      },
      parameterIds: ['base_width', 'base_depth', 'base_height'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'base',
      aliases: ['main body', 'base', 'chassis', 'tray'],
      status: 'planned',
    };
    features.push(feat);

    parameters.push(
      createFeatureParameter({
        id: 'base_width',
        featureId: feat.id,
        name: 'width',
        semanticName: 'base_width',
        value: widthDim,
        unit: 'mm',
        source: 'explicit',
        critical: true,
      }),
      createFeatureParameter({
        id: 'base_depth',
        featureId: feat.id,
        name: 'depth',
        semanticName: 'base_depth',
        value: depthDim,
        unit: 'mm',
        source: 'explicit',
        critical: true,
      }),
      createFeatureParameter({
        id: 'base_height',
        featureId: feat.id,
        name: 'height',
        semanticName: 'base_height',
        value: heightDim,
        unit: 'mm',
        source: 'explicit',
        critical: true,
      })
    );
  }

  // 2. ARCHETYPE-SPECIFIC MECHANICAL FEATURES

  // Archetype A: Soap Dish (Dr. Squatch or general)
  if (isSoapDish) {
    const soapBarRef = spec.compatibilityTargets.find((t) => t.name.toLowerCase().includes('soap')) || {
      name: 'Dr. Squatch Soap Bar',
      clearanceMm: 4,
    };

    // Soap Cavity / Resting Tray
    const cavity: SemanticFeature = {
      id: 'soap_cavity',
      type: 'CAVITY',
      label: 'Soap Bar Cavity',
      purpose: 'Internal recessed pocket sized to securely rest a standard soap bar with clearance.',
      parameters: {
        width: 85,
        depth: 85,
        depthRecess: 10,
        clearance: soapBarRef.clearanceMm || 4,
      },
      parameterIds: ['soap_cavity_width', 'soap_cavity_depth', 'soap_cavity_clearance'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'subtract',
      aliases: ['soap pocket', 'recess', 'soap tray cavity'],
      status: 'planned',
    };
    features.push(cavity);
    parameters.push(
      createFeatureParameter({ id: 'soap_cavity_width', featureId: cavity.id, name: 'width', semanticName: 'soap_cavity_width', value: 85, unit: 'mm', source: 'reference', critical: true }),
      createFeatureParameter({ id: 'soap_cavity_depth', featureId: cavity.id, name: 'depth', semanticName: 'soap_cavity_depth', value: 85, unit: 'mm', source: 'reference', critical: true }),
      createFeatureParameter({ id: 'soap_cavity_clearance', featureId: cavity.id, name: 'clearance', semanticName: 'soap_cavity_clearance', value: soapBarRef.clearanceMm || 4, unit: 'mm', source: 'reference' })
    );
    relationships.push(createFeatureRelationship({ sourceFeatureId: cavity.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Cavity cuts into base body' }));

    // Drainage Slot Pattern
    const drainage: SemanticFeature = {
      id: 'drainage_slot_pattern',
      type: 'DRAINAGE_SLOT',
      label: 'Drainage Slot Pattern',
      purpose: 'Series of through-slots allowing water egress so soap stays dry.',
      parameters: {
        slotWidth: 4,
        slotLength: 50,
        count: 5,
        spacing: 12,
      },
      parameterIds: ['drain_slot_width', 'drain_slot_length', 'drain_slot_count', 'drain_slot_spacing'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'subtract',
      aliases: ['drainage slots', 'weep slots', 'water drainage', 'drain holes'],
      status: 'planned',
    };
    features.push(drainage);
    parameters.push(
      createFeatureParameter({ id: 'drain_slot_width', featureId: drainage.id, name: 'slotWidth', semanticName: 'drain_slot_width', value: 4, unit: 'mm', source: 'default' }),
      createFeatureParameter({ id: 'drain_slot_length', featureId: drainage.id, name: 'slotLength', semanticName: 'drain_slot_length', value: 50, unit: 'mm', source: 'default' }),
      createFeatureParameter({ id: 'drain_slot_count', featureId: drainage.id, name: 'count', semanticName: 'drain_slot_count', value: 5, unit: 'count', source: 'default' }),
      createFeatureParameter({ id: 'drain_slot_spacing', featureId: drainage.id, name: 'spacing', semanticName: 'drain_slot_spacing', value: 12, unit: 'mm', source: 'default' })
    );
    relationships.push(createFeatureRelationship({ sourceFeatureId: drainage.id, targetFeatureId: cavity.id, relationshipType: 'subtracts_from', description: 'Slots pass through soap floor' }));

    // Raised Support Ridges
    const ridges: SemanticFeature = {
      id: 'raised_support_ridges',
      type: 'SUPPORT',
      label: 'Raised Soap Support Ridges',
      purpose: 'Elevates the soap bar above the floor for maximum airflow and drainage.',
      parameters: {
        ridgeHeight: 3,
        ridgeThickness: 2.5,
        count: 4,
      },
      parameterIds: ['ridge_height', 'ridge_thickness'],
      source: 'inferred',
      criticality: 'important',
      geometryOperation: 'add',
      aliases: ['support ribs', 'soap ridges', 'drying ribs'],
      status: 'planned',
    };
    features.push(ridges);
    parameters.push(
      createFeatureParameter({ id: 'ridge_height', featureId: ridges.id, name: 'ridgeHeight', semanticName: 'ridge_height', value: 3, unit: 'mm', source: 'inferred' }),
      createFeatureParameter({ id: 'ridge_thickness', featureId: ridges.id, name: 'ridgeThickness', semanticName: 'ridge_thickness', value: 2.5, unit: 'mm', source: 'inferred' })
    );
    relationships.push(createFeatureRelationship({ sourceFeatureId: ridges.id, targetFeatureId: cavity.id, relationshipType: 'attached_to', description: 'Ridges sit on cavity floor' }));

    // Retaining Rim
    const rim: SemanticFeature = {
      id: 'retaining_rim',
      type: 'LIP',
      label: 'Retaining Perimeter Rim',
      purpose: 'Perimeter lip keeping soap bar from sliding off.',
      parameters: {
        rimHeight: 6,
        rimThickness: 3.5,
      },
      parameterIds: ['rim_height', 'rim_thickness'],
      source: 'inferred',
      criticality: 'important',
      geometryOperation: 'add',
      aliases: ['retaining lip', 'soap rim', 'outer lip'],
      status: 'planned',
    };
    features.push(rim);
    parameters.push(
      createFeatureParameter({ id: 'rim_height', featureId: rim.id, name: 'rimHeight', semanticName: 'rim_height', value: 6, unit: 'mm', source: 'inferred' }),
      createFeatureParameter({ id: 'rim_thickness', featureId: rim.id, name: 'rimThickness', semanticName: 'rim_thickness', value: 3.5, unit: 'mm', source: 'inferred' })
    );
  }

  // Archetype B: Controller Mount (Under desk / wall)
  else if (isControllerMount) {
    const isUnderDesk = lowerPrompt.includes('under') || lowerPrompt.includes('desk');

    // Mounting Holes (Left and Right)
    const holeLeft: SemanticFeature = {
      id: 'mounting_hole_left',
      type: 'COUNTERSINK',
      label: 'Mounting Hole Left',
      purpose: 'Countersunk screw hole for secure under-desk or wall fastening.',
      parameters: {
        diameter: 4.5,
        headDiameter: 9.0,
        positionX: -35,
        positionY: 0,
      },
      parameterIds: ['mounting_hole_diameter', 'mounting_hole_left_x'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'subtract',
      aliases: ['left hole', 'left screw hole', 'first mounting hole', 'that left hole'],
      status: 'planned',
    };
    const holeRight: SemanticFeature = {
      id: 'mounting_hole_right',
      type: 'COUNTERSINK',
      label: 'Mounting Hole Right',
      purpose: 'Countersunk screw hole symmetric to left mounting hole.',
      parameters: {
        diameter: 4.5,
        headDiameter: 9.0,
        positionX: 35,
        positionY: 0,
      },
      parameterIds: ['mounting_hole_diameter', 'mounting_hole_right_x'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'subtract',
      aliases: ['right hole', 'right screw hole', 'second mounting hole', 'that right hole'],
      status: 'planned',
    };
    features.push(holeLeft, holeRight);

    parameters.push(
      createFeatureParameter({ id: 'mounting_hole_diameter', featureId: holeLeft.id, name: 'diameter', semanticName: 'mounting_hole_diameter', value: 4.5, unit: 'mm', source: 'explicit', critical: true }),
      createFeatureParameter({ id: 'mounting_hole_left_x', featureId: holeLeft.id, name: 'positionX', semanticName: 'mounting_hole_left_x', value: -35, unit: 'mm', source: 'explicit' }),
      createFeatureParameter({ id: 'mounting_hole_right_x', featureId: holeRight.id, name: 'positionX', semanticName: 'mounting_hole_right_x', value: 35, unit: 'mm', source: 'explicit' }),
      createFeatureParameter({ id: 'mounting_hole_spacing', featureId: baseFeatureId, name: 'spacing', semanticName: 'mounting_hole_spacing', value: 70, unit: 'mm', source: 'explicit', critical: true })
    );

    relationships.push(
      createFeatureRelationship({ sourceFeatureId: holeLeft.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Left hole passes through plate' }),
      createFeatureRelationship({ sourceFeatureId: holeRight.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Right hole passes through plate' }),
      createFeatureRelationship({ sourceFeatureId: holeRight.id, targetFeatureId: holeLeft.id, relationshipType: 'mirrored_from', description: 'Right hole mirrored across X=0' })
    );

    constraints.push(
      createFeatureConstraint({
        name: 'Mounting Hole Spacing',
        description: 'Center-to-center spacing between left and right mounting holes',
        constraintType: 'distance',
        affectedFeatureIds: [holeLeft.id, holeRight.id],
        value: 70,
        tolerance: 1.0,
      })
    );

    // Controller Cradle Arms
    const cradleLeft: SemanticFeature = {
      id: 'controller_cradle_left',
      type: 'CRADLE',
      label: 'Controller Cradle Arm Left',
      purpose: 'Contoured resting arm cradling the left controller grip.',
      parameters: {
        width: 30,
        dropHeight: 45,
        thickness: 5,
      },
      parameterIds: ['cradle_arm_thickness', 'cradle_drop_height'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'add',
      aliases: ['left cradle', 'left arm', 'left grip holder'],
      status: 'planned',
    };
    const cradleRight: SemanticFeature = {
      id: 'controller_cradle_right',
      type: 'CRADLE',
      label: 'Controller Cradle Arm Right',
      purpose: 'Contoured resting arm cradling the right controller grip.',
      parameters: {
        width: 30,
        dropHeight: 45,
        thickness: 5,
      },
      parameterIds: ['cradle_arm_thickness', 'cradle_drop_height'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'add',
      aliases: ['right cradle', 'right arm', 'right grip holder'],
      status: 'planned',
    };
    features.push(cradleLeft, cradleRight);

    parameters.push(
      createFeatureParameter({ id: 'cradle_arm_thickness', featureId: cradleLeft.id, name: 'thickness', semanticName: 'cradle_arm_thickness', value: 5, unit: 'mm', source: 'inferred' }),
      createFeatureParameter({ id: 'cradle_drop_height', featureId: cradleLeft.id, name: 'dropHeight', semanticName: 'cradle_drop_height', value: 45, unit: 'mm', source: 'inferred' })
    );

    relationships.push(
      createFeatureRelationship({ sourceFeatureId: cradleLeft.id, targetFeatureId: baseFeatureId, relationshipType: isUnderDesk ? 'below' : 'attached_to', description: 'Cradle hangs from mounting plate' }),
      createFeatureRelationship({ sourceFeatureId: cradleRight.id, targetFeatureId: baseFeatureId, relationshipType: isUnderDesk ? 'below' : 'attached_to', description: 'Cradle hangs from mounting plate' }),
      createFeatureRelationship({ sourceFeatureId: cradleRight.id, targetFeatureId: cradleLeft.id, relationshipType: 'mirrored_from', description: 'Symmetric cradle arms' })
    );

    // Reinforcing Support Ribs
    const ribLeft: SemanticFeature = {
      id: 'support_rib_left',
      type: 'RIB',
      label: 'Support Rib Left',
      purpose: 'Reinforces the left cradle arm against flex and load bending.',
      parameters: {
        thickness: 3.5,
        height: 25,
      },
      parameterIds: ['support_rib_thickness'],
      source: 'inferred',
      criticality: 'important',
      geometryOperation: 'add',
      aliases: ['left rib', 'left support gusset', 'left brace'],
      status: 'planned',
    };
    const ribRight: SemanticFeature = {
      id: 'support_rib_right',
      type: 'RIB',
      label: 'Support Rib Right',
      purpose: 'Reinforces the right cradle arm against flex and load bending.',
      parameters: {
        thickness: 3.5,
        height: 25,
      },
      parameterIds: ['support_rib_thickness'],
      source: 'inferred',
      criticality: 'important',
      geometryOperation: 'add',
      aliases: ['right rib', 'right support gusset', 'right brace'],
      status: 'planned',
    };
    features.push(ribLeft, ribRight);
    parameters.push(
      createFeatureParameter({ id: 'support_rib_thickness', featureId: ribLeft.id, name: 'thickness', semanticName: 'support_rib_thickness', value: 3.5, unit: 'mm', source: 'inferred' })
    );
    relationships.push(
      createFeatureRelationship({ sourceFeatureId: ribLeft.id, targetFeatureId: cradleLeft.id, relationshipType: 'reinforces', description: 'Rib reinforces left cradle' }),
      createFeatureRelationship({ sourceFeatureId: ribRight.id, targetFeatureId: cradleRight.id, relationshipType: 'reinforces', description: 'Rib reinforces right cradle' })
    );
  }

  // Archetype C: Phone Stand
  else if (isPhoneStand) {
    // Back Support Wall / Rest
    const backSupport: SemanticFeature = {
      id: 'back_support',
      type: 'WALL',
      label: 'Back Support Angle',
      purpose: 'Inclined back plane supporting phone or tablet at comfortable viewing angle.',
      parameters: {
        angleDeg: 70,
        height: 85,
        thickness: 3.5,
      },
      parameterIds: ['stand_angle_deg', 'back_support_height', 'wall_thickness'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'add',
      aliases: ['back rest', 'support wall', 'inclined support', 'phone back'],
      status: 'planned',
    };
    features.push(backSupport);
    parameters.push(
      createFeatureParameter({ id: 'stand_angle_deg', featureId: backSupport.id, name: 'angleDeg', semanticName: 'stand_angle_deg', value: 70, unit: 'deg', source: 'inferred' }),
      createFeatureParameter({ id: 'back_support_height', featureId: backSupport.id, name: 'height', semanticName: 'back_support_height', value: 85, unit: 'mm', source: 'inferred' }),
      createFeatureParameter({ id: 'wall_thickness', featureId: backSupport.id, name: 'thickness', semanticName: 'wall_thickness', value: 3.5, unit: 'mm', source: 'inferred', min: 2.0 })
    );
    relationships.push(createFeatureRelationship({ sourceFeatureId: backSupport.id, targetFeatureId: baseFeatureId, relationshipType: 'attached_to', description: 'Back support rises from base' }));

    // Retaining Lip
    const retainingLip: SemanticFeature = {
      id: 'retaining_lip',
      type: 'LIP',
      label: 'Retaining Lip',
      purpose: 'Forward hooked shelf preventing device from sliding off the stand.',
      parameters: {
        lipHeight: 14,
        shelfDepth: 16,
        thickness: 3.5,
      },
      parameterIds: ['retaining_lip_height', 'shelf_depth'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'add',
      aliases: ['phone shelf', 'front lip', 'holder lip', 'retaining hook'],
      status: 'planned',
    };
    features.push(retainingLip);
    parameters.push(
      createFeatureParameter({ id: 'retaining_lip_height', featureId: retainingLip.id, name: 'lipHeight', semanticName: 'retaining_lip_height', value: 14, unit: 'mm', source: 'inferred' }),
      createFeatureParameter({ id: 'shelf_depth', featureId: retainingLip.id, name: 'shelfDepth', semanticName: 'shelf_depth', value: 16, unit: 'mm', source: 'inferred' })
    );
    relationships.push(createFeatureRelationship({ sourceFeatureId: retainingLip.id, targetFeatureId: baseFeatureId, relationshipType: 'attached_to', description: 'Shelf is attached to base' }));

    // Cable Pass-Through Opening
    const cableSlot: SemanticFeature = {
      id: 'charging_cable_slot',
      type: 'CABLE_OPENING',
      label: 'Charging Cable Opening',
      purpose: 'Pass-through opening allowing Lightning/USB-C charging cables to connect while docked.',
      parameters: {
        slotWidth: 16,
        slotDepth: 12,
      },
      parameterIds: ['cable_slot_width', 'cable_slot_depth'],
      source: 'explicit',
      criticality: 'critical',
      geometryOperation: 'subtract',
      aliases: ['cable opening', 'charger opening', 'bottom slot', 'charging slot', 'cable slot'],
      status: 'planned',
    };
    features.push(cableSlot);
    parameters.push(
      createFeatureParameter({ id: 'cable_slot_width', featureId: cableSlot.id, name: 'slotWidth', semanticName: 'cable_slot_width', value: 16, unit: 'mm', source: 'explicit', critical: true }),
      createFeatureParameter({ id: 'cable_slot_depth', featureId: cableSlot.id, name: 'slotDepth', semanticName: 'cable_slot_depth', value: 12, unit: 'mm', source: 'inferred' })
    );
    relationships.push(createFeatureRelationship({ sourceFeatureId: cableSlot.id, targetFeatureId: retainingLip.id, relationshipType: 'subtracts_from', description: 'Cable slot cuts through shelf and base' }));
  }

  // Archetype D: Wall Plate / Faceplate / Holes & Cutouts
  else if (isWallPlate || lowerPrompt.includes('hole') || lowerPrompt.includes('screw') || lowerPrompt.includes('slot')) {
    // Parse hole quantity explicitly
    let holeCount = 0;
    if (lowerPrompt.includes('one hole') || lowerPrompt.includes('1 hole') || lowerPrompt.includes('single hole') || lowerPrompt.includes('through hole in the center') || lowerPrompt.includes('center hole') || lowerPrompt.includes('one 8 mm hole')) {
      holeCount = 1;
    } else if (lowerPrompt.includes('two hole') || lowerPrompt.includes('2 hole') || lowerPrompt.includes('two screw') || lowerPrompt.includes('2 screw')) {
      holeCount = 2;
    } else if (lowerPrompt.includes('three hole') || lowerPrompt.includes('3 hole')) {
      holeCount = 3;
    } else if (lowerPrompt.includes('four hole') || lowerPrompt.includes('4 hole') || lowerPrompt.includes('four screw') || lowerPrompt.includes('4 screw') || isWallPlate) {
      holeCount = 4;
    } else if (lowerPrompt.includes('six hole') || lowerPrompt.includes('6 hole')) {
      holeCount = 6;
    } else if (lowerPrompt.includes('hole') || lowerPrompt.includes('screw')) {
      holeCount = 1; // Default to 1 hole if unspecified, NOT 4
    }

    const holeDiameter = spec.explicitDimensions.find((d) => d.name.toLowerCase().includes('hole'))?.value || 5.0;

    if (holeCount === 1) {
      const isCenter = lowerPrompt.includes('center') || !lowerPrompt.includes('offset');
      const hole: SemanticFeature = {
        id: 'center_hole',
        type: 'HOLE',
        label: 'Center Through Hole',
        purpose: 'Center cylindrical through hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: 0, posY: 0 },
        parameterIds: ['hole_diameter', 'hole_pos_x', 'hole_pos_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['center hole', 'through hole', 'hole 1'],
        status: 'planned',
      };
      features.push(hole);
      parameters.push(
        createFeatureParameter({ id: 'hole_diameter', featureId: hole.id, name: 'diameter', semanticName: 'hole_diameter', value: holeDiameter, unit: 'mm', source: 'explicit', critical: true }),
        createFeatureParameter({ id: 'hole_pos_x', featureId: hole.id, name: 'posX', semanticName: 'hole_pos_x', value: 0, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'hole_pos_y', featureId: hole.id, name: 'posY', semanticName: 'hole_pos_y', value: 0, unit: 'mm', source: 'explicit' })
      );
      relationships.push(createFeatureRelationship({ sourceFeatureId: hole.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Hole cuts through base body' }));
    } else if (holeCount === 2) {
      const spacing = Math.max(20, widthDim - 30);
      const hole1: SemanticFeature = {
        id: 'mounting_hole_left',
        type: 'HOLE',
        label: 'Mounting Hole Left',
        purpose: 'Left mounting through hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: -spacing / 2, posY: 0 },
        parameterIds: ['mounting_hole_diameter', 'mounting_hole_left_x', 'mounting_hole_left_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['left hole', 'hole 1'],
        status: 'planned',
      };
      const hole2: SemanticFeature = {
        id: 'mounting_hole_right',
        type: 'HOLE',
        label: 'Mounting Hole Right',
        purpose: 'Right mounting through hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: spacing / 2, posY: 0 },
        parameterIds: ['mounting_hole_diameter', 'mounting_hole_right_x', 'mounting_hole_right_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['right hole', 'hole 2'],
        status: 'planned',
      };
      features.push(hole1, hole2);
      parameters.push(
        createFeatureParameter({ id: 'mounting_hole_diameter', featureId: hole1.id, name: 'diameter', semanticName: 'mounting_hole_diameter', value: holeDiameter, unit: 'mm', source: 'explicit', critical: true }),
        createFeatureParameter({ id: 'mounting_hole_left_x', featureId: hole1.id, name: 'posX', semanticName: 'mounting_hole_left_x', value: -spacing / 2, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_left_y', featureId: hole1.id, name: 'posY', semanticName: 'mounting_hole_left_y', value: 0, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_right_x', featureId: hole2.id, name: 'posX', semanticName: 'mounting_hole_right_x', value: spacing / 2, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_right_y', featureId: hole2.id, name: 'posY', semanticName: 'mounting_hole_right_y', value: 0, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_spacing', featureId: baseFeatureId, name: 'spacing', semanticName: 'mounting_hole_spacing', value: spacing, unit: 'mm', source: 'explicit', critical: true })
      );
      relationships.push(
        createFeatureRelationship({ sourceFeatureId: hole1.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Hole cuts through base body' }),
        createFeatureRelationship({ sourceFeatureId: hole2.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Hole cuts through base body' })
      );
    } else if (holeCount === 4) {
      const offsetX = Math.max(8, widthDim / 2 - 12);
      const offsetY = Math.max(8, depthDim / 2 - 12);
      const isCountersink = lowerPrompt.includes('countersink') || lowerPrompt.includes('countersunk');
      const holeType = isCountersink ? 'COUNTERSINK' : 'HOLE';

      const hole1: SemanticFeature = {
        id: 'mounting_hole_top_left',
        type: holeType,
        label: 'Mounting Hole Top-Left',
        purpose: 'Corner fastener hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: -offsetX, posY: offsetY },
        parameterIds: ['mounting_hole_diameter', 'mounting_hole_tl_x', 'mounting_hole_tl_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['top left hole', 'hole 1'],
        status: 'planned',
      };
      const hole2: SemanticFeature = {
        id: 'mounting_hole_top_right',
        type: holeType,
        label: 'Mounting Hole Top-Right',
        purpose: 'Corner fastener hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: offsetX, posY: offsetY },
        parameterIds: ['mounting_hole_diameter', 'mounting_hole_tr_x', 'mounting_hole_tr_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['top right hole', 'hole 2'],
        status: 'planned',
      };
      const hole3: SemanticFeature = {
        id: 'mounting_hole_bottom_left',
        type: holeType,
        label: 'Mounting Hole Bottom-Left',
        purpose: 'Corner fastener hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: -offsetX, posY: -offsetY },
        parameterIds: ['mounting_hole_diameter', 'mounting_hole_bl_x', 'mounting_hole_bl_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['bottom left hole', 'hole 3'],
        status: 'planned',
      };
      const hole4: SemanticFeature = {
        id: 'mounting_hole_bottom_right',
        type: holeType,
        label: 'Mounting Hole Bottom-Right',
        purpose: 'Corner fastener hole.',
        parameters: { diameter: holeDiameter, depth: heightDim + 4, posX: offsetX, posY: -offsetY },
        parameterIds: ['mounting_hole_diameter', 'mounting_hole_br_x', 'mounting_hole_br_y'],
        source: 'explicit',
        criticality: 'critical',
        geometryOperation: 'subtract',
        aliases: ['bottom right hole', 'hole 4'],
        status: 'planned',
      };

      features.push(hole1, hole2, hole3, hole4);
      parameters.push(
        createFeatureParameter({ id: 'mounting_hole_diameter', featureId: hole1.id, name: 'diameter', semanticName: 'mounting_hole_diameter', value: holeDiameter, unit: 'mm', source: 'explicit', critical: true }),
        createFeatureParameter({ id: 'mounting_hole_tl_x', featureId: hole1.id, name: 'posX', semanticName: 'mounting_hole_tl_x', value: -offsetX, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_tl_y', featureId: hole1.id, name: 'posY', semanticName: 'mounting_hole_tl_y', value: offsetY, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_tr_x', featureId: hole2.id, name: 'posX', semanticName: 'mounting_hole_tr_x', value: offsetX, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_tr_y', featureId: hole2.id, name: 'posY', semanticName: 'mounting_hole_tr_y', value: offsetY, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_bl_x', featureId: hole3.id, name: 'posX', semanticName: 'mounting_hole_bl_x', value: -offsetX, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_bl_y', featureId: hole3.id, name: 'posY', semanticName: 'mounting_hole_bl_y', value: -offsetY, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_br_x', featureId: hole4.id, name: 'posX', semanticName: 'mounting_hole_br_x', value: offsetX, unit: 'mm', source: 'explicit' }),
        createFeatureParameter({ id: 'mounting_hole_br_y', featureId: hole4.id, name: 'posY', semanticName: 'mounting_hole_br_y', value: -offsetY, unit: 'mm', source: 'explicit' })
      );

      [hole1, hole2, hole3, hole4].forEach((h) => {
        relationships.push(createFeatureRelationship({ sourceFeatureId: h.id, targetFeatureId: baseFeatureId, relationshipType: 'subtracts_from', description: 'Hole cuts through plate' }));
      });
    }
  }

  // 3. Ergonomic Finishing Features (Rounding / Fillet)
  const rounding: SemanticFeature = {
    id: 'corner_rounding',
    type: 'ROUNDING',
    label: 'Corner Rounding',
    purpose: 'Smooth exterior corner radius for comfortable handling and printability.',
    parameters: {
      radius: 4,
    },
    parameterIds: ['corner_radius'],
    source: 'inferred',
    criticality: 'optional',
    geometryOperation: 'finish',
    aliases: ['edge fillets', 'rounded corners', 'smooth edges'],
    status: 'planned',
  };
  features.push(rounding);
  parameters.push(
    createFeatureParameter({ id: 'corner_radius', featureId: rounding.id, name: 'radius', semanticName: 'corner_radius', value: 4, unit: 'mm', source: 'inferred' })
  );
  relationships.push(createFeatureRelationship({ sourceFeatureId: rounding.id, targetFeatureId: baseFeatureId, relationshipType: 'attached_to', description: 'Rounds base corners' }));

  // Global Minimum Wall Thickness Constraint
  constraints.push(
    createFeatureConstraint({
      name: 'Minimum Wall Thickness',
      description: 'Ensures all printable walls remain at least 2.4 mm thick for rigidity',
      constraintType: 'min_value',
      affectedFeatureIds: features.map((f) => f.id),
      parameterKeys: ['wall_thickness', 'thickness', 'plate_thickness'],
      value: 2.4,
    })
  );

  return {
    modelId,
    objectType: spec.primaryObject || 'Mechanical Part',
    baseFeatureId,
    features,
    relationships,
    parameters,
    constraints,
    generationStrategy: spec.generationStrategy || 'Feature-based CSG construction',
    schemaVersion: 3,
  };
}
