export const CAD_EXAMPLES = `// EXAMPLE 1 — Self-watering planter (single piece, subtract-based cavities)
const potDiameter = 120.0;     // Outer diameter in mm
const potHeight = 150.0;       // Total height in mm
const wallThickness = 2.4;     // Wall thickness in mm
const reservoirHeight = 25.0;  // Water reservoir depth at the base in mm
const shelfThickness = 3.0;    // Divider shelf between reservoir and soil in mm
const wickDiameter = 12.0;     // Wicking channel through the shelf in mm
const fillPortDiameter = 8.0;  // Side fill port into the reservoir in mm
const innerDiameter = 115.2;   // Inner cavity diameter in mm

/* KP_DERIVED
[
  { "derived": "innerDiameter", "expression": "potDiameter - 2 * wallThickness", "inputs": ["potDiameter", "wallThickness"] }
]
*/

function kpFeature_soil_cavity() {
  const soilTop = potHeight;
  const soilBottom = reservoirHeight + shelfThickness;
  const h = soilTop - soilBottom + 1;
  return translate([0, 0, soilBottom + h / 2], cylinder({ radius: innerDiameter / 2, height: h, segments: 96 }));
}

function kpFeature_reservoir() {
  return translate([0, 0, wallThickness + reservoirHeight / 2],
    cylinder({ radius: innerDiameter / 2, height: reservoirHeight, segments: 96 }));
}

function kpFeature_wick_channel() {
  const zMid = reservoirHeight + shelfThickness / 2;
  return translate([0, 0, zMid], cylinder({ radius: wickDiameter / 2, height: shelfThickness + 2, segments: 48 }));
}

function kpFeature_fill_port() {
  const zMid = wallThickness + reservoirHeight / 2;
  return translate([potDiameter / 2 - wallThickness / 2, 0, zMid],
    rotate([0, Math.PI / 2, 0], cylinder({ radius: fillPortDiameter / 2, height: wallThickness * 3, segments: 48 })));
}

function main() {
  const body = translate([0, 0, potHeight / 2], cylinder({ radius: potDiameter / 2, height: potHeight, segments: 96 }));
  return subtract(body, kpFeature_soil_cavity(), kpFeature_reservoir(), kpFeature_wick_channel(), kpFeature_fill_port());
}

// EXAMPLE 2 — Divided parts tray with finger notch (single piece)
const trayLength = 120.0;     // Overall length (X) in mm
const trayWidth = 80.0;       // Overall width (Y) in mm
const trayHeight = 25.0;      // Overall height in mm
const wallThickness = 3.0;    // Outer wall and divider thickness in mm
const floorThickness = 3.0;   // Floor thickness in mm
const compartments = 3;       // Number of compartments along X
const notchWidth = 15.0;      // Finger notch width in mm
const notchDepth = 8.0;       // Finger notch depth down from the rim in mm
const compartmentLength = 36.0; // Inner length of each compartment in mm

/* KP_DERIVED
[
  { "derived": "compartmentLength", "expression": "(trayLength - (compartments + 1) * wallThickness) / compartments", "inputs": ["trayLength", "compartments", "wallThickness"] }
]
*/

function kpFeature_compartments() {
  const innerW = trayWidth - 2 * wallThickness;
  const h = trayHeight - floorThickness + 1;
  const cuts = [];
  for (let i = 0; i < compartments; i++) {
    const x0 = -trayLength / 2 + wallThickness + i * (compartmentLength + wallThickness);
    const cx = x0 + compartmentLength / 2;
    cuts.push(translate([cx, 0, floorThickness + h / 2], cuboid({ size: [compartmentLength, innerW, h] })));
  }
  return union(...cuts);
}

function kpFeature_finger_notch() {
  return translate([0, trayWidth / 2, trayHeight - notchDepth / 2 + 0.5],
    cuboid({ size: [notchWidth, wallThickness * 3, notchDepth + 1] }));
}

function main() {
  const shell = translate([0, 0, trayHeight / 2], cuboid({ size: [trayLength, trayWidth, trayHeight] }));
  return subtract(shell, kpFeature_compartments(), kpFeature_finger_notch());
}

// EXAMPLE 3 — Two-piece box with stepped lid (multi-part ABI with mating clearance)
const boxLength = 80.0;       // Outer length (X) in mm
const boxWidth = 60.0;        // Outer width (Y) in mm
const boxHeight = 40.0;       // Base height in mm
const wallThickness = 2.4;    // Wall thickness in mm
const floorThickness = 2.4;   // Floor and lid top thickness in mm
const lidHeight = 10.0;       // Lid outer height in mm
const lipHeight = 4.0;        // Lid lip that drops into the base in mm
const lidClearance = 0.3;     // Radial clearance between lip and base inner wall in mm
const innerLength = 75.2;     // Base inner length in mm
const innerWidth = 55.2;      // Base inner width in mm
const lipLength = 74.6;       // Lid lip outer length in mm
const lipWidth = 54.6;        // Lid lip outer width in mm

/* KP_DERIVED
[
  { "derived": "innerLength", "expression": "boxLength - 2 * wallThickness", "inputs": ["boxLength", "wallThickness"] },
  { "derived": "innerWidth",  "expression": "boxWidth - 2 * wallThickness",  "inputs": ["boxWidth", "wallThickness"] },
  { "derived": "lipLength",   "expression": "innerLength - 2 * lidClearance", "inputs": ["innerLength", "lidClearance"] },
  { "derived": "lipWidth",    "expression": "innerWidth - 2 * lidClearance",  "inputs": ["innerWidth", "lidClearance"] }
]
*/

function kpFeature_base_cavity() {
  const h = boxHeight - floorThickness + 1;
  return translate([0, 0, floorThickness + h / 2], cuboid({ size: [innerLength, innerWidth, h] }));
}

function kpPart_base() {
  const outer = translate([0, 0, boxHeight / 2], cuboid({ size: [boxLength, boxWidth, boxHeight] }));
  return subtract(outer, kpFeature_base_cavity());
}

function kpPart_lid() {
  // Printed upside down: flat top on the bed at Z=0, lip pointing up.
  const cap = translate([0, 0, floorThickness / 2], cuboid({ size: [boxLength, boxWidth, floorThickness] }));
  const lipOuter = translate([0, 0, floorThickness + lipHeight / 2], cuboid({ size: [lipLength, lipWidth, lipHeight] }));
  const lipInner = translate([0, 0, floorThickness + lipHeight / 2 + 0.5],
    cuboid({ size: [lipLength - 2 * wallThickness, lipWidth - 2 * wallThickness, lipHeight + 1] }));
  return union(cap, subtract(lipOuter, lipInner));
}

function getParts() {
  return [
    { id: 'base', name: 'Base', quantity: 1, geometry: kpPart_base() },
    { id: 'lid',  name: 'Lid',  quantity: 1, geometry: kpPart_lid() },
  ];
}

function main() { return getParts().map((p) => p.geometry); }`;
