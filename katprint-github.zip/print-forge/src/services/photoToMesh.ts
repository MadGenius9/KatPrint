import * as THREE from 'three';

export interface PhotoToMeshResult {
  geometry?: THREE.BufferGeometry;
  isConfigured: boolean;
  isManifold: boolean;
  warnings: string[];
  providerNote: string;
  errorMessage?: string;
}

/**
 * Service module for Neural / Photogrammetry Mesh Reconstruction.
 * Explicitly reports provider status and avoids pretending synthetic test primitives are real scans.
 */
export async function photoToMesh(imageBlob: Blob | File | string): Promise<PhotoToMeshResult> {
  // Check if real provider endpoint is configured
  const hasConfiguredProvider = false;

  if (!hasConfiguredProvider) {
    return {
      isConfigured: false,
      isManifold: false,
      warnings: [
        'Photo-to-Mesh provider not configured.',
        'To enable real photogrammetry or neural image-to-3D, configure an external photogrammetry service (e.g., Tripo3D, CSM, Instant-Mesh, or local Meshroom worker).',
      ],
      providerNote:
        'Photo-to-Mesh provider is currently unconfigured. Uploaded images will not be silently replaced with fake geometry.',
      errorMessage: 'Photo-to-Mesh provider not configured.',
    };
  }

  throw new Error('Photo-to-Mesh provider not configured.');
}
