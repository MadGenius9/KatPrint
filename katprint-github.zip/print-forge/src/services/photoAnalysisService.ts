import { ProjectReferenceImage } from '../types';

export interface PhotoAnalysisResult {
  primaryObject: string;
  probableObjectType: string;
  numberOfComponents: number;
  likelySeparateParts: Array<{
    name: string;
    description: string;
    printableSeparately: boolean;
  }>;
  symmetry: 'bilateral' | 'radial' | 'asymmetrical' | string;
  recognizableGeometry: string[];
  openingsHoles: string[];
  thinAreas: string[];
  proportions: string;
  estimatedDimensions: {
    known: boolean;
    reason: string;
    suggestedWidthMm?: number | null;
    suggestedHeightMm?: number | null;
    suggestedDepthMm?: number | null;
  };
  backgroundInterference: 'none' | 'low' | 'moderate' | 'high';
  imageQuality: 'excellent' | 'good' | 'fair' | 'poor';
  visibilityProblems: string[];
  additionalAnglesRecommended: boolean;
  recommendedAdditionalAngles: string[];
  likelyPrintabilityProblems: string[];
  suggestedPrompt: string;
  reconstructionPlan?: {
    modelingStrategy: string;
    primaryPrimitives: string[];
    booleanOperations: string[];
    criticalFeatures: string[];
    uncertainFeatures: string[];
    recommendedPrintOrientation: string;
    confidence: number;
  };
}

export interface AnalyzePhotoParams {
  imageDataUrl?: string;
  imageBase64?: string;
  mimeType?: string;
  userPromptHint?: string;
  userKnownDimensions?: {
    widthMm?: number;
    heightMm?: number;
    depthMm?: number;
    referenceNote?: string;
  };
}

export async function requestPhotoAnalysis(
  params: AnalyzePhotoParams,
  timeoutMs = 60000
): Promise<{
  analysis: PhotoAnalysisResult;
  aiMetadata?: {
    modelUsed: string;
    durationMs: number;
  };
}> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch('/api/analyze-photo', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
      signal: controller.signal,
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || `Server responded with ${res.status}`);
    }

    return {
      analysis: data.analysis,
      aiMetadata: data.aiMetadata,
    };
  } catch (err: any) {
    if (err.name === 'AbortError') {
      throw new Error('Photo analysis timed out. The image might be very large or the service is temporarily busy.');
    }
    throw err;
  } finally {
    clearTimeout(timeoutId);
  }
}
