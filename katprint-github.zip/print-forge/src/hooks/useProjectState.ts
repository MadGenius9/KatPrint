import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import * as THREE from 'three';
import {
  DesignSpecification,
  DesignCheck,
  FidelityReviewResult,
  GenerationMode,
  ProjectReferenceImage,
  ProjectDesignState,
  SemanticFeaturePlan,
  RequirementCoverageReport,
  DesignIntentAudit,
  ModelGeometryStats,
} from '../types';
import {
  KatPrintProject,
  ModelVersion,
  DesignConversationMessage,
  DesignChangeSet,
} from '../projects/projectTypes';
import { projectRepository } from '../projects/projectRepository';
import {
  createDefaultProject,
  createBlankProject,
  buildModelVersion,
  createVersionLabel,
  getNextVersionNumber,
  duplicateProjectGraph,
} from '../projects/projectService';
import { updateProjectMemoryFromVersion } from '../projects/projectMemory';
import { exportProjectPackage } from '../projects/projectSerializer';
import {
  applyDirectParameterUpdateToProject,
  applyBoundParameterChangesToProject,
  restoreVersionAsNewHead,
  branchNewVersion,
} from '../projects/revisionEngine';
import { sanitizeStlFilename } from '../versions/versionService';
import {
  SemanticFeatureModel,
  ManipulatorType,
  SemanticRevisionOpType,
  finalizeFeatureModelForCode,
  reconstructLegacyFeatureModel,
  verifySemanticFeatureModel,
  toggleParameterLock,
} from '../features';
import { analyzeBufferGeometry } from '../engine/geometryUtils';
import { generateCadThumbnail } from '../engine/designVerification/renderInspectionViews';
import { downloadExportSTL } from '../engine/stlExporter';
import { executeJscadCode, executeJscadModel, DEFAULT_PLANTER_JSCAD } from '../engine/jscadRunner';

export interface UseProjectStateDeps {
  selectedFilamentDensity?: number;
  selectedPrinterId?: string;
  selectedFilamentId?: string;
  scaleFactor?: number;
  mustHoldLiquid?: boolean;
  onActivateVersionGeometry?: (version: ModelVersion, options?: { head?: boolean }) => void;
  onProjectActivated?: (project: KatPrintProject) => void;
  onPrinterSettingsChange?: (settings: {
    printerId?: string;
    filamentId?: string;
    scaleFactor?: number;
    mustHoldLiquid?: boolean;
  }) => void;
}

export function useProjectState(deps?: UseProjectStateDeps) {
  const density = deps?.selectedFilamentDensity ?? 1.24;
  const onActivateVersionGeometryRef = useRef(deps?.onActivateVersionGeometry);
  onActivateVersionGeometryRef.current = deps?.onActivateVersionGeometry;

  const onPrinterSettingsChangeRef = useRef(deps?.onPrinterSettingsChange);
  onPrinterSettingsChangeRef.current = deps?.onPrinterSettingsChange;

  const onProjectActivatedRef = useRef(deps?.onProjectActivated);
  onProjectActivatedRef.current = deps?.onProjectActivated;

  // Projects State & Persistence
  const [projects, setProjects] = useState<KatPrintProject[]>([]);
  const [activeProject, setActiveProject] = useState<KatPrintProject | null>(null);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('saved');
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [editableTitle, setEditableTitle] = useState('');

  // Version Viewing / Comparison State
  const [viewingVersionId, setViewingVersionId] = useState<string | null>(null);
  const [compareVersionA, setCompareVersionA] = useState<ModelVersion | undefined>(undefined);
  const [compareVersionB, setCompareVersionB] = useState<ModelVersion | undefined>(undefined);

  // Direct Semantic Parameter Update Flag
  const [isApplyingParameter, setIsApplyingParameter] = useState(false);

  // Active Project ID shorthand
  const activeProjectId = activeProject?.id || null;

  // Active Project Reference Images
  const referenceImages = useMemo(() => {
    return activeProject?.referenceImages || [];
  }, [activeProject?.referenceImages]);

  // Active Project Versions
  const versions = useMemo(() => {
    return activeProject?.versions || [];
  }, [activeProject?.versions]);

  // Active Project Design State
  const projectDesignState = activeProject?.projectDesignState || null;

  // Active Version calculation
  const currentActiveVersion = useMemo(() => {
    if (!activeProject || !activeProject.versions) return null;
    if (viewingVersionId) {
      return activeProject.versions.find((v) => v.id === viewingVersionId) || null;
    }
    return (
      activeProject.versions.find((v) => v.id === activeProject.currentVersionId) ||
      activeProject.versions[activeProject.versions.length - 1] ||
      null
    );
  }, [activeProject, viewingVersionId]);

  // Save active project to IndexedDB when changed
  const persistActiveProject = useCallback(async (updated: KatPrintProject) => {
    setSaveStatus('saving');
    try {
      await projectRepository.saveProject(updated);
      setProjects((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
      setActiveProject(updated);
      setSaveStatus('saved');
    } catch (err) {
      console.error('Failed to persist project:', err);
      setSaveStatus('error');
    }
  }, []);

  // Helper to commit a new version to active project
  const recordNewVersion = useCallback(
    async (
      code: string,
      geom: THREE.BufferGeometry,
      prompt: string,
      changeSummary: string,
      changeType: 'INITIAL_GENERATION' | 'REVISION' | 'RESTORED' | 'BRANCH' | 'MANUAL_EDIT' = 'REVISION',
      score: number | null = null,
      spec?: DesignSpecification,
      checklist?: DesignCheck[],
      review?: FidelityReviewResult,
      diffExplanation?: string,
      targetProject?: KatPrintProject,
      featureModel?: SemanticFeatureModel | null,
      customProjectDesignState?: ProjectDesignState | null,
      semanticFeaturePlan?: SemanticFeaturePlan | null,
      requirementCoverageReport?: RequirementCoverageReport | null,
      designIntentAudit?: DesignIntentAudit | null,
      statusOverride?: 'verified' | 'unverified' | 'failed'
    ) => {
      const projectToUpdate = targetProject || activeProject;
      if (!projectToUpdate) return;

      const stats = analyzeBufferGeometry(geom, density);
      const nextNum = getNextVersionNumber(projectToUpdate.versions);
      const newVerId = `ver_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      const now = new Date().toISOString();

      const thumbnail = generateCadThumbnail(geom);
      const finalScore = score !== undefined ? score : null;

      // Feature Verification & Code Binding Finalization if model provided
      let verifiedFeatureModel = featureModel;
      if (verifiedFeatureModel) {
        verifiedFeatureModel = finalizeFeatureModelForCode(
          verifiedFeatureModel,
          code,
          stats,
          verifiedFeatureModel.generationStrategy === 'legacy-reconstructed' ? 'legacy' : 'strict'
        );
      }

      // Strict status calculation matching AI Brain verification gates
      const isGeomValid = stats.isManifold && stats.volumeMm3 > 0 && Number.isFinite(stats.volumeMm3);
      const isReviewPassed = !review || review.verdict === 'PASS';
      const isAuditPassed = designIntentAudit ? designIntentAudit.verdict === 'pass' : false;
      const isCoveragePassed =
        !requirementCoverageReport || requirementCoverageReport.unmetCriticalRequirements.length === 0;
      const isBindingsPassed =
        !verifiedFeatureModel?.bindingValidation ||
        verifiedFeatureModel.bindingValidation.criticalUnboundParameters.length === 0;

      const isStrictlyVerified =
        isGeomValid &&
        isReviewPassed &&
        isAuditPassed &&
        isCoveragePassed &&
        isBindingsPassed;

      const isHardFailed =
        !isGeomValid ||
        (review && review.verdict === 'INVALID_DESIGN') ||
        (designIntentAudit && designIntentAudit.verdict === 'fail');

      const derivedStatus: 'verified' | 'unverified' | 'failed' = isHardFailed
        ? 'failed'
        : isStrictlyVerified
        ? 'verified'
        : 'unverified';

      const status: 'verified' | 'unverified' | 'failed' = statusOverride || derivedStatus;
      const activeDesignState = customProjectDesignState || projectToUpdate.projectDesignState || null;

      const newVersion = buildModelVersion({
        id: newVerId,
        projectId: projectToUpdate.id,
        versionNumber: nextNum,
        parentVersionId: projectToUpdate.currentVersionId,
        label: createVersionLabel(nextNum, prompt, changeType),
        prompt,
        userInstruction: prompt,
        cadCode: code,
        geometryMetadata: stats,
        changeSummary,
        changeType,
        isCurrentHead: true,
        status,
        designMatchScore: finalScore,
        designSpecification: spec,
        designChecklist: checklist,
        featureModel: verifiedFeatureModel,
        projectDesignState: activeDesignState,
        semanticFeaturePlan: semanticFeaturePlan || null,
        requirementCoverageReport: requirementCoverageReport || null,
        designIntentAudit: designIntentAudit || null,
        fidelityReview: review,
        diffExplanation,
        thumbnail: thumbnail || undefined,
      });

      const updatedVersions = (projectToUpdate.versions || []).map((v) => ({ ...v, isCurrentHead: false }));
      updatedVersions.push(newVersion);

      const updatedProject: KatPrintProject = {
        ...projectToUpdate,
        currentVersionId: newVerId,
        versions: updatedVersions,
        projectDesignState: activeDesignState,
        thumbnail: thumbnail || projectToUpdate.thumbnail,
        projectMemory: updateProjectMemoryFromVersion(projectToUpdate.projectMemory, newVersion, prompt),
        updatedAt: now,
      };

      await persistActiveProject(updatedProject);
      setViewingVersionId(null);
    },
    [activeProject, density, persistActiveProject]
  );

  // Centralized project activation & geometry validation
  const activateProject = useCallback(
    (project: KatPrintProject) => {
      if (!project) return;
      setActiveProject(project);
      setEditableTitle(project.name);
      setViewingVersionId(null);

      // Restore hardware configuration
      if (project.projectSettings && onPrinterSettingsChangeRef.current) {
        onPrinterSettingsChangeRef.current({
          printerId: project.projectSettings.printerId,
          filamentId: project.projectSettings.filamentId,
          scaleFactor: project.projectSettings.scaleFactor,
          mustHoldLiquid: project.projectSettings.mustHoldLiquid,
        });
      }

      onProjectActivatedRef.current?.(project);

      const vers = project.versions || [];
      const currentVer =
        vers.find((v) => v.id === project.currentVersionId) || vers[vers.length - 1];
      if (currentVer && onActivateVersionGeometryRef.current) {
        onActivateVersionGeometryRef.current(currentVer, { head: true });
      }
    },
    []
  );

  // Update active project's generation mode and persist
  const handleGenerationModeChange = async (newMode: GenerationMode) => {
    if (!activeProject) return;
    const updated: KatPrintProject = {
      ...activeProject,
      projectSettings: {
        ...activeProject.projectSettings,
        generationMode: newMode,
      },
      updatedAt: new Date().toISOString(),
    };
    await persistActiveProject(updated);
  };

  // Load projects from IndexedDB on startup
  useEffect(() => {
    let isMounted = true;
    async function initProjects() {
      try {
        const loaded = await projectRepository.listProjects();
        if (!isMounted) return;
        if (loaded && loaded.length > 0) {
          setProjects(loaded);
          activateProject(loaded[0]);
        } else {
          // Initialize first default project
          const defaultProj = createDefaultProject('Self-Watering Planter with internal reservoir and wicking channel');
          defaultProj.name = 'Self-Watering Planter';

          let initialGeom: THREE.BufferGeometry | null = null;
          try {
            initialGeom = executeJscadCode(DEFAULT_PLANTER_JSCAD);
          } catch (e) {
            console.warn('Initial default geometry evaluation failed, fallback to empty:', e);
          }
          const stats = initialGeom
            ? analyzeBufferGeometry(initialGeom, density)
            : {
                dimensions: { x: 90, y: 90, z: 80 },
                volumeMm3: 45000,
                volumeCm3: 45,
                surfaceAreaMm2: 12000,
                estimatedWeightGrams: 55.8,
                triangleCount: 1200,
                vertexCount: 3600,
                nonManifoldEdgeCount: 0,
                overhangRatio: 0.12,
                minWallThicknessMm: 2.0,
                isManifold: true,
                footprintAreaMm2: 3600,
                heightToWidthRatio: 0.88,
                hasSteepOverhangs: false,
              };

          let verifiedInitialModel: SemanticFeatureModel | null = null;
          try {
            const reconstructed = reconstructLegacyFeatureModel(
              DEFAULT_PLANTER_JSCAD,
              'Self-watering planter with reservoir and wicking channel',
              null,
              stats
            );
            if (reconstructed && reconstructed.model) {
              verifiedInitialModel = finalizeFeatureModelForCode(
                reconstructed.model,
                DEFAULT_PLANTER_JSCAD,
                stats,
                'strict'
              );
            }
          } catch (featErr) {
            console.warn('Failed to parse initial semantic feature model:', featErr);
          }

          const v1 = buildModelVersion({
            id: 'ver_init_1',
            projectId: defaultProj.id,
            versionNumber: 1,
            label: 'V1: Initial Planter',
            prompt: 'Self-watering planter with reservoir and wicking channel',
            cadCode: DEFAULT_PLANTER_JSCAD,
            geometryMetadata: stats,
            changeSummary: 'Initial parametric planter design with live sliders and wicking channels.',
            changeType: 'INITIAL_GENERATION',
            isCurrentHead: true,
            status: 'unverified',
            designMatchScore: null,
            featureModel: verifiedInitialModel,
          });
          defaultProj.versions = [v1];
          defaultProj.currentVersionId = v1.id;
          await projectRepository.saveProject(defaultProj);
          setProjects([defaultProj]);
          activateProject(defaultProj);
        }
      } catch (err) {
        console.error('Failed to initialize projects database:', err);
      }
    }

    initProjects();
    return () => {
      isMounted = false;
    };
  }, [activateProject, density]);

  // Restore previous version (Non-destructive new head)
  const handleRestoreVersion = async (version: ModelVersion): Promise<ModelVersion | null> => {
    if (!activeProject || !activeProject.versions) return null;
    try {
      const updatedVersions = restoreVersionAsNewHead(activeProject.versions, version.id);
      const newHead = updatedVersions.find((v) => v.isCurrentHead)!;

      onActivateVersionGeometryRef.current?.(newHead, { head: true });

      const restoreMsg: DesignConversationMessage = {
        id: `msg_restore_${Date.now()}`,
        projectId: activeProject.id,
        role: 'system',
        content: `Restored to **V${version.versionNumber}** (${version.label}) as new head version **V${newHead.versionNumber}**.`,
        timestamp: new Date().toISOString(),
        relatedVersionId: newHead.id,
        versionId: newHead.id,
      };

      const updatedProj: KatPrintProject = {
        ...activeProject,
        currentVersionId: newHead.id,
        versions: updatedVersions,
        conversation: [...(activeProject.conversation || []), restoreMsg],
        thumbnail: newHead.thumbnail || activeProject.thumbnail,
        projectMemory: updateProjectMemoryFromVersion(activeProject.projectMemory, newHead, `Restore V${newHead.versionNumber}`),
        updatedAt: new Date().toISOString(),
      };

      await persistActiveProject(updatedProj);
      setViewingVersionId(null);
      return newHead;
    } catch (err: any) {
      console.error('Failed to restore version:', err);
      return null;
    }
  };

  // Branch new version from an existing version
  const handleBranchVersion = async (version: ModelVersion): Promise<ModelVersion | null> => {
    if (!activeProject || !activeProject.versions) return null;
    try {
      const updatedVersions = branchNewVersion(activeProject.versions, version.id, `Branch from V${version.versionNumber}`);
      const newBranch = updatedVersions.find((v) => v.isCurrentHead)!;

      onActivateVersionGeometryRef.current?.(newBranch, { head: true });

      const branchMsg: DesignConversationMessage = {
        id: `msg_branch_${Date.now()}`,
        projectId: activeProject.id,
        role: 'system',
        content: `Branched new active lineage from **V${version.versionNumber}** as **V${newBranch.versionNumber}**.`,
        timestamp: new Date().toISOString(),
        relatedVersionId: newBranch.id,
        versionId: newBranch.id,
      };

      const updatedProj: KatPrintProject = {
        ...activeProject,
        currentVersionId: newBranch.id,
        versions: updatedVersions,
        conversation: [...(activeProject.conversation || []), branchMsg],
        thumbnail: newBranch.thumbnail || activeProject.thumbnail,
        projectMemory: updateProjectMemoryFromVersion(activeProject.projectMemory, newBranch, `Branch V${newBranch.versionNumber}`),
        updatedAt: new Date().toISOString(),
      };

      await persistActiveProject(updatedProj);
      setViewingVersionId(null);
      return newBranch;
    } catch (err: any) {
      console.error('Failed to branch version:', err);
      return null;
    }
  };

  // Return to Head version
  const handleReturnToHead = useCallback((): ModelVersion | null => {
    setViewingVersionId(null);
    if (!activeProject || !activeProject.versions) return null;
    const head =
      activeProject.versions.find((v) => v.id === activeProject.currentVersionId) ||
      activeProject.versions[activeProject.versions.length - 1] ||
      null;
    if (head && onActivateVersionGeometryRef.current) {
      onActivateVersionGeometryRef.current(head, { head: true });
    }
    return head;
  }, [activeProject]);

  // Inspect previous version in 3D viewer without changing head
  const handleSelectVersionForViewing = useCallback((version: ModelVersion) => {
    setViewingVersionId(version.id);
    if (onActivateVersionGeometryRef.current) {
      onActivateVersionGeometryRef.current(version, { head: false });
    }
  }, []);

  // Version Comparison modal preparation
  const handleCompareVersions = useCallback((versionA: ModelVersion, versionB: ModelVersion) => {
    setCompareVersionA(versionA);
    setCompareVersionB(versionB);
  }, []);

  // Rename a specific version's label
  const handleRenameVersionLabel = async (versionId: string, newLabel: string) => {
    if (!activeProject || !activeProject.versions) return;
    const updatedVersions = activeProject.versions.map((v) =>
      v.id === versionId ? { ...v, label: newLabel.trim() || v.label } : v
    );
    const updatedProj: KatPrintProject = {
      ...activeProject,
      versions: updatedVersions,
      updatedAt: new Date().toISOString(),
    };
    await persistActiveProject(updatedProj);
  };

  // Export STL for a specific version in timeline
  const handleExportVersionStl = useCallback(
    (version: ModelVersion, customScaleFactor: number = 1.0) => {
      if (!activeProject) return;
      const script = version.cadCode;
      if (!script) {
        alert('No CAD script available for this version.');
        return;
      }
      try {
        const executed = executeJscadModel(script);
        const geom = executed.combinedGeometry;
        const stats = analyzeBufferGeometry(geom, density);
        if (stats.triangleCount <= 0 && (!executed.parts || executed.parts.length === 0)) {
          alert(`Cannot export V${version.versionNumber}: Model geometry has no mesh triangles.`);
          return;
        }
        const filename = sanitizeStlFilename(activeProject.name, version.versionNumber);
        downloadExportSTL(geom, executed.parts, filename, customScaleFactor);
      } catch (err: any) {
        alert(`Failed to export version STL: ${err?.message || 'Geometry error'}`);
      }
    },
    [activeProject, density]
  );

  // Handle Natural Language Undo / Rollback
  const handleRollbackLastRevision = async (): Promise<ModelVersion | null> => {
    if (!activeProject || !activeProject.versions || activeProject.versions.length <= 1) return null;
    const prevVersion = activeProject.versions[activeProject.versions.length - 2];
    if (!prevVersion) return null;
    return await handleRestoreVersion(prevVersion);
  };

  // Create empty / blank project without initial AI generation
  const handleCreateBlankProject = async (customName?: string): Promise<KatPrintProject> => {
    const blank = createBlankProject(customName || 'Untitled Project', {
      printerId: deps?.selectedPrinterId,
      filamentId: deps?.selectedFilamentId,
      scaleFactor: deps?.scaleFactor,
      mustHoldLiquid: deps?.mustHoldLiquid,
    });

    await projectRepository.saveProject(blank);
    const all = await projectRepository.listProjects();
    setProjects(all);
    activateProject(blank);
    return blank;
  };

  // Select project from library
  const handleSelectProject = useCallback(
    (project: KatPrintProject) => {
      if (!project) return;
      activateProject(project);
    },
    [activateProject]
  );

  // Update printer and persist to project settings
  const handlePrinterChange = async (printerId: string) => {
    if (activeProject) {
      const updated: KatPrintProject = {
        ...activeProject,
        projectSettings: {
          ...activeProject.projectSettings,
          printerId,
        },
        updatedAt: new Date().toISOString(),
      };
      await persistActiveProject(updated);
    }
  };

  // Update filament and persist to project settings
  const handleFilamentChange = async (filamentId: string) => {
    if (activeProject) {
      const updated: KatPrintProject = {
        ...activeProject,
        projectSettings: {
          ...activeProject.projectSettings,
          filamentId,
        },
        updatedAt: new Date().toISOString(),
      };
      await persistActiveProject(updated);
    }
  };

  // Update scale factor and persist to project settings
  const handleScaleFactorChange = async (scale: number) => {
    if (activeProject) {
      const updated: KatPrintProject = {
        ...activeProject,
        projectSettings: {
          ...activeProject.projectSettings,
          scaleFactor: scale,
        },
        updatedAt: new Date().toISOString(),
      };
      await persistActiveProject(updated);
    }
  };

  // Update watertight mode and persist to project settings
  const handleMustHoldLiquidChange = async (enabled: boolean) => {
    if (activeProject) {
      const updated: KatPrintProject = {
        ...activeProject,
        projectSettings: {
          ...activeProject.projectSettings,
          mustHoldLiquid: enabled,
        },
        updatedAt: new Date().toISOString(),
      };
      await persistActiveProject(updated);
    }
  };

  // Delete project
  const handleDeleteProject = async (target: string | KatPrintProject) => {
    const projectId = typeof target === 'string' ? target : target?.id;
    if (!projectId) return;
    await projectRepository.deleteProject(projectId);
    const remaining = await projectRepository.listProjects();
    setProjects(remaining);
    if (activeProject?.id === projectId) {
      if (remaining.length > 0) {
        activateProject(remaining[0]);
      } else {
        await handleCreateBlankProject('Untitled Project');
      }
    }
  };

  // Duplicate project
  const handleDuplicateProject = async (project: KatPrintProject) => {
    const cloned = duplicateProjectGraph(project);
    await projectRepository.createProject(cloned);
    const all = await projectRepository.listProjects();
    setProjects(all);
    return cloned;
  };

  // Project rename action
  const handleRenameProject = async (project: KatPrintProject, newName: string) => {
    const updated: KatPrintProject = {
      ...project,
      name: newName.trim() || project.name,
      updatedAt: new Date().toISOString(),
    };
    await projectRepository.updateProject(updated);
    const all = await projectRepository.listProjects();
    setProjects(all);
    if (activeProject?.id === project.id) {
      setActiveProject(updated);
      setEditableTitle(updated.name);
    }
  };

  // Favorite toggle (project bookmarking)
  const handleToggleFavorite = async (target: string | KatPrintProject) => {
    const projectId = typeof target === 'string' ? target : target?.id;
    if (!projectId) return;
    const proj = projects.find((p) => p.id === projectId);
    if (!proj) return;
    const isFav = !proj.isFavorite;
    const updated: KatPrintProject = {
      ...proj,
      isFavorite: isFav,
      updatedAt: new Date().toISOString(),
    };
    await projectRepository.updateProject(updated);
    const all = await projectRepository.listProjects();
    setProjects(all);
    if (activeProject?.id === projectId) {
      setActiveProject(updated);
    }
  };

  // Export project package archive (.katprint)
  const handleExportKatPrint = (proj?: KatPrintProject) => {
    const target = proj || activeProject;
    if (!target) return;
    exportProjectPackage(target);
  };

  // Import .katprint project package
  const handleImportKatPrint = async (fileContent: string): Promise<KatPrintProject | null> => {
    try {
      const imported = await projectRepository.importProjectFile(fileContent);
      const all = await projectRepository.listProjects();
      setProjects(all);
      activateProject(imported);
      return imported;
    } catch (err: any) {
      alert(`Could not import project package: ${err?.message || 'Invalid format'}`);
      return null;
    }
  };

  // Save renamed title
  const handleSaveTitle = async () => {
    if (!activeProject || !editableTitle.trim()) {
      setIsEditingTitle(false);
      return;
    }
    const updated: KatPrintProject = {
      ...activeProject,
      name: editableTitle.trim(),
      updatedAt: new Date().toISOString(),
    };
    await persistActiveProject(updated);
    setIsEditingTitle(false);
  };

  // Direct Semantic Parameter Update
  const handleUpdateFeatureParameter = async (
    parameterId: string,
    newValue: number | string | boolean,
    customDensity?: number
  ): Promise<ModelVersion | null> => {
    if (!activeProject) return null;
    setIsApplyingParameter(true);
    try {
      const outcome = await applyDirectParameterUpdateToProject({
        project: activeProject,
        parameterId,
        newValue,
        selectedFilamentDensity: customDensity ?? density,
      });

      await persistActiveProject(outcome.updatedProject);
      const newHead = outcome.newVersion;
      if (onActivateVersionGeometryRef.current) {
        onActivateVersionGeometryRef.current(newHead, { head: true });
      }
      return newHead;
    } catch (err: any) {
      console.error('Failed to apply direct parameter update:', err);
      return null;
    } finally {
      setIsApplyingParameter(false);
    }
  };

  // Direct 3D Manipulation Commit
  const handleManipulationCommit = async (params: {
    featureId: string;
    featureIds?: string[];
    manipulatorId: string;
    manipulatorType: ManipulatorType;
    parameterChanges: Array<{
      parameterId: string;
      newValue: number | string | boolean;
      oldValue?: number | string | boolean;
      unit?: string;
    }>;
    instructionSummary?: string;
    selectedFilamentDensity?: number;
  }) => {
    if (!activeProject) return null;
    if (viewingVersionId && viewingVersionId !== activeProject.currentVersionId) {
      alert('Cannot modify historical versions directly. Please return to head or restore this version first.');
      return null;
    }

    try {
      let opType: SemanticRevisionOpType = 'SET_PARAMETER';
      if (params.manipulatorType === 'POSITION') opType = 'MOVE_FEATURE';
      else if (['RADIUS', 'DIAMETER', 'WIDTH', 'LENGTH', 'HEIGHT', 'DEPTH', 'THICKNESS'].includes(params.manipulatorType)) {
        opType = 'RESIZE_FEATURE';
      }

      const outcome = await applyBoundParameterChangesToProject({
        project: activeProject,
        updates: params.parameterChanges.map((pc) => ({
          parameterId: pc.parameterId,
          newValue: pc.newValue,
        })),
        selectedFilamentDensity: params.selectedFilamentDensity ?? density,
        operationType: opType,
        customSummary: params.instructionSummary || `Direct manipulation of ${params.featureId}`,
        featureIds: params.featureIds || [params.featureId],
        manipulatorType: params.manipulatorType,
      });

      if (onActivateVersionGeometryRef.current) {
        onActivateVersionGeometryRef.current(outcome.newVersion, { head: true });
      }

      await persistActiveProject(outcome.updatedProject);
      setViewingVersionId(null);
      return outcome;
    } catch (err: any) {
      console.error('Manipulation commit error:', err);
      alert(`Direct manipulation failed: ${err.message || err}`);
      return null;
    }
  };

  // Reconstruct Feature Model for Legacy Versions
  const handleReconstructFeatureModel = async (
    currentCode: string,
    geometryStats: ModelGeometryStats
  ) => {
    if (!activeProject || !currentActiveVersion) return;
    const { model } = reconstructLegacyFeatureModel(
      currentActiveVersion.cadCode || currentCode,
      currentActiveVersion.prompt || activeProject.originalPrompt || '',
      currentActiveVersion.designSpecification,
      currentActiveVersion.geometryMetadata
    );

    const verified = verifySemanticFeatureModel(
      model,
      geometryStats,
      currentActiveVersion.cadCode || currentCode
    ).updatedModel;

    const updatedVersions = activeProject.versions.map((v) =>
      v.id === currentActiveVersion.id ? { ...v, featureModel: verified } : v
    );

    const updatedProj: KatPrintProject = {
      ...activeProject,
      versions: updatedVersions,
      updatedAt: new Date().toISOString(),
    };

    await persistActiveProject(updatedProj);
  };

  // Toggle Parameter Lock
  const handleToggleLockParameter = async (parameterId: string, currentLocked: boolean) => {
    if (!activeProject || !currentActiveVersion || !currentActiveVersion.featureModel) return;
    const updatedModel = toggleParameterLock(currentActiveVersion.featureModel, parameterId, !currentLocked);

    const updatedVersions = activeProject.versions.map((v) =>
      v.id === currentActiveVersion.id ? { ...v, featureModel: updatedModel } : v
    );

    const updatedProj: KatPrintProject = {
      ...activeProject,
      versions: updatedVersions,
      updatedAt: new Date().toISOString(),
    };

    await persistActiveProject(updatedProj);
  };

  // Update Reference Images for Active Project
  const handleUpdateReferenceImages = async (images: ProjectReferenceImage[]) => {
    if (!activeProject) return;
    const updated: KatPrintProject = {
      ...activeProject,
      referenceImages: images,
      updatedAt: new Date().toISOString(),
    };
    await persistActiveProject(updated);
  };

  return {
    // State
    projects,
    setProjects,
    activeProject,
    setActiveProject,
    activeProjectId,
    saveStatus,
    setSaveStatus,
    isEditingTitle,
    setIsEditingTitle,
    editableTitle,
    setEditableTitle,
    viewingVersionId,
    setViewingVersionId,
    compareVersionA,
    setCompareVersionA,
    compareVersionB,
    setCompareVersionB,
    currentActiveVersion,
    versions,
    projectDesignState,
    referenceImages,
    isApplyingParameter,
    setIsApplyingParameter,

    // Project & Version Handlers
    persistActiveProject,
    recordNewVersion,
    activateProject,
    handleCreateBlankProject,
    handleDeleteProject,
    handleDuplicateProject,
    handleRenameProject,
    handleSelectProject,
    handleToggleFavorite,
    handleExportKatPrint,
    handleImportKatPrint,
    handleSaveTitle,
    handleGenerationModeChange,
    handlePrinterChange,
    handleFilamentChange,
    handleScaleFactorChange,
    handleMustHoldLiquidChange,
    handleRestoreVersion,
    handleBranchVersion,
    handleReturnToHead,
    handleSelectVersionForViewing,
    handleCompareVersions,
    handleRenameVersionLabel,
    handleExportVersionStl,
    handleRollbackLastRevision,
    handleUpdateReferenceImages,
    handleToggleLockParameter,
    handleReconstructFeatureModel,
    handleManipulationCommit,
    handleUpdateFeatureParameter,
  };
}
export type ProjectState = ReturnType<typeof useProjectState>;
