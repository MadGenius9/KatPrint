import { useState, useCallback } from 'react';

export type ModalId =
  | 'comparison'
  | 'plateLayout'
  | 'referencePhotos'
  | 'storage'
  | 'testSuite'
  | 'customPrinter'
  | 'liveMonitor'
  | 'fitTest'
  | 'history'
  | 'library'
  | 'printResult'
  | null;

export function useModals() {
  const [activeModal, setActiveModal] = useState<ModalId>(null);
  const openModal = useCallback((id: ModalId) => setActiveModal(id), []);
  const closeModal = useCallback(() => setActiveModal(null), []);

  return {
    activeModal,
    openModal,
    closeModal,
  };
}
