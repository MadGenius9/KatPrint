/**
 * Gemini SDK JSON Schemas for Structured Model Outputs
 */

export const GeminiSemanticParameterSchema = {
  type: 'OBJECT',
  properties: {
    name: { type: 'STRING' },
    valueNumber: { type: 'NUMBER' },
    valueString: { type: 'STRING' },
    valueBoolean: { type: 'BOOLEAN' },
    unit: { type: 'STRING' },
    source: { type: 'STRING' },
    confidence: { type: 'NUMBER' },
    locked: { type: 'BOOLEAN' },
    min: { type: 'NUMBER' },
    max: { type: 'NUMBER' },
    description: { type: 'STRING' },
  },
  required: ['name'],
};

export const SemanticFeaturePlanSchema = {
  type: 'OBJECT',
  properties: {
    objectSummary: { type: 'STRING' },
    designIntent: {
      type: 'OBJECT',
      properties: {
        primaryFunction: { type: 'STRING' },
        secondaryFunctions: { type: 'ARRAY', items: { type: 'STRING' } },
        environment: { type: 'STRING' },
        userPriorities: { type: 'ARRAY', items: { type: 'STRING' } },
      },
      required: ['primaryFunction'],
    },
    parts: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          id: { type: 'STRING' },
          name: { type: 'STRING' },
          quantity: { type: 'INTEGER' },
          purpose: { type: 'STRING' },
        },
        required: ['id', 'name', 'quantity', 'purpose'],
      },
    },
    features: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          id: { type: 'STRING' },
          partId: { type: 'STRING' },
          type: { type: 'STRING' },
          label: { type: 'STRING' },
          purpose: { type: 'STRING' },
          geometryOperation: { type: 'STRING' },
          criticality: { type: 'STRING' },
          parentFeatureId: { type: 'STRING' },
          parameters: {
            type: 'ARRAY',
            items: GeminiSemanticParameterSchema,
          },
        },
        required: ['id', 'type', 'label', 'purpose', 'geometryOperation', 'criticality', 'parameters'],
      },
    },
    relationships: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          sourceFeatureId: { type: 'STRING' },
          targetFeatureId: { type: 'STRING' },
          relationshipType: { type: 'STRING' },
          description: { type: 'STRING' },
        },
        required: ['sourceFeatureId', 'targetFeatureId', 'relationshipType'],
      },
    },
    constraints: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          name: { type: 'STRING' },
          constraintType: { type: 'STRING' },
          affectedFeatureIds: { type: 'ARRAY', items: { type: 'STRING' } },
          value: { type: 'NUMBER' },
          description: { type: 'STRING' },
        },
        required: ['name', 'constraintType', 'affectedFeatureIds'],
      },
    },
    derivedParameters: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          name: { type: 'STRING' },
          expression: { type: 'STRING' },
          description: { type: 'STRING' },
        },
        required: ['name', 'expression'],
      },
    },
    matingInterfaces: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          partA: { type: 'STRING' },
          partB: { type: 'STRING' },
          type: { type: 'STRING' },
          clearanceMm: { type: 'NUMBER' },
        },
        required: ['partA', 'partB', 'type', 'clearanceMm'],
      },
    },
    generationStrategy: { type: 'STRING' },
    expectedPartCount: { type: 'INTEGER' },
  },
  required: ['objectSummary', 'parts', 'features', 'generationStrategy', 'expectedPartCount'],
};

export const MultiPlanSemanticFeaturePlanSchema = {
  type: 'OBJECT',
  properties: {
    candidatePlans: {
      type: 'ARRAY',
      items: SemanticFeaturePlanSchema,
    },
  },
  required: ['candidatePlans'],
};

export const SemanticPlanRepairSchema = {
  type: 'OBJECT',
  properties: {
    repairedPlan: SemanticFeaturePlanSchema,
    modificationsMade: { type: 'ARRAY', items: { type: 'STRING' } },
    resolvedCriticalRequirements: { type: 'ARRAY', items: { type: 'STRING' } },
    unresolvableCriticalRequirements: { type: 'ARRAY', items: { type: 'STRING' } },
    clarificationNeeded: { type: 'STRING' },
  },
  required: ['repairedPlan', 'modificationsMade', 'resolvedCriticalRequirements'],
};

export const RevisionIntentSchema = {
  type: 'OBJECT',
  properties: {
    intentType: { type: 'STRING' },
    targetFeatureIds: { type: 'ARRAY', items: { type: 'STRING' } },
    requestedChanges: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          feature: { type: 'STRING' },
          change: { type: 'STRING' },
          fromValue: { type: 'STRING' },
          toValue: { type: 'STRING' },
          category: { type: 'STRING' },
        },
        required: ['feature', 'change'],
      },
    },
    preserveFeatureIds: { type: 'ARRAY', items: { type: 'STRING' } },
    preserveConstraints: { type: 'ARRAY', items: { type: 'STRING' } },
    dimensionChanges: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          name: { type: 'STRING' },
          from: { type: 'NUMBER' },
          to: { type: 'NUMBER' },
          axis: { type: 'STRING' },
        },
        required: ['name', 'to'],
      },
    },
    requiresCadRegeneration: { type: 'BOOLEAN' },
    confidence: { type: 'NUMBER' },
    interpretation: { type: 'STRING' },
  },
  required: ['intentType', 'targetFeatureIds', 'requiresCadRegeneration', 'confidence', 'interpretation'],
};

export const DesignIntentStateDeltaSchema = {
  type: 'OBJECT',
  properties: {
    addConstraints: { type: 'ARRAY', items: { type: 'STRING' } },
    removeConstraints: { type: 'ARRAY', items: { type: 'STRING' } },
    updateDimensions: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          name: { type: 'STRING' },
          value: { type: 'NUMBER' },
          unit: { type: 'STRING' },
          toleranceMm: { type: 'NUMBER' },
          source: { type: 'STRING' },
          critical: { type: 'BOOLEAN' },
          category: { type: 'STRING' },
        },
        required: ['name', 'value'],
      },
    },
    addRequiredFeatures: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          id: { type: 'STRING' },
          name: { type: 'STRING' },
          description: { type: 'STRING' },
          source: { type: 'STRING' },
          confidence: { type: 'NUMBER' },
        },
        required: ['name'],
      },
    },
    removeFeatures: { type: 'ARRAY', items: { type: 'STRING' } },
    addRejectedDirections: { type: 'ARRAY', items: { type: 'STRING' } },
    newAestheticIntent: { type: 'ARRAY', items: { type: 'STRING' } },
    newOpenQuestions: { type: 'ARRAY', items: { type: 'STRING' } },
    newAssumptions: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          category: { type: 'STRING' },
          assumption: { type: 'STRING' },
          source: { type: 'STRING' },
          confidence: { type: 'NUMBER' },
          reason: { type: 'STRING' },
        },
        required: ['assumption'],
      },
    },
    summary: { type: 'STRING' },
  },
};

export const DesignIntentAuditSchema = {
  type: 'OBJECT',
  properties: {
    audit: {
      type: 'OBJECT',
      properties: {
        overallScore: { type: 'NUMBER' },
        verdict: { type: 'STRING' },
        summary: { type: 'STRING' },
        evaluatedRequirements: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              name: { type: 'STRING' },
              passed: { type: 'BOOLEAN' },
              observation: { type: 'STRING' },
            },
            required: ['name', 'passed', 'observation'],
          },
        },
        defects: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              severity: { type: 'STRING' },
              featureId: { type: 'STRING' },
              issue: { type: 'STRING' },
              recommendation: { type: 'STRING' },
            },
            required: ['severity', 'issue', 'recommendation'],
          },
        },
        missingFeatures: { type: 'ARRAY', items: { type: 'STRING' } },
        dimensionalDrift: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              axis: { type: 'STRING' },
              expected: { type: 'NUMBER' },
              measured: { type: 'NUMBER' },
              driftPercent: { type: 'NUMBER' },
            },
            required: ['axis', 'expected', 'measured'],
          },
        },
        aestheticCritique: { type: 'STRING' },
      },
      required: ['verdict', 'summary', 'evaluatedRequirements', 'defects'],
    },
    coverageReport: {
      type: 'OBJECT',
      properties: {
        items: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              id: { type: 'STRING' },
              requirement: { type: 'STRING' },
              category: { type: 'STRING' },
              importance: { type: 'STRING' },
              status: { type: 'STRING' },
              evidence: { type: 'STRING' },
            },
            required: ['requirement', 'importance', 'status', 'evidence'],
          },
        },
        coveragePercent: { type: 'NUMBER' },
        unmetCriticalRequirements: { type: 'ARRAY', items: { type: 'STRING' } },
        summary: { type: 'STRING' },
      },
      required: ['items', 'summary'],
    },
  },
  required: ['audit', 'coverageReport'],
};

export const ReferenceImageObservationsSchema = {
  type: 'ARRAY',
  items: {
    type: 'OBJECT',
    properties: {
      imageIndex: { type: 'INTEGER' },
      role: { type: 'STRING' },
      observedFeatures: { type: 'ARRAY', items: { type: 'STRING' } },
      relativeProportions: { type: 'ARRAY', items: { type: 'STRING' } },
      visibleInterfaces: { type: 'ARRAY', items: { type: 'STRING' } },
      knownMeasurements: {
        type: 'ARRAY',
        items: {
          type: 'OBJECT',
          properties: {
            feature: { type: 'STRING' },
            valueMm: { type: 'NUMBER' },
          },
          required: ['feature', 'valueMm'],
        },
      },
      unknownMeasurements: { type: 'ARRAY', items: { type: 'STRING' } },
      confidence: { type: 'NUMBER' },
    },
    required: ['imageIndex', 'role', 'observedFeatures', 'confidence'],
  },
};
