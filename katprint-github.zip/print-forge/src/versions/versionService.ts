import {
  KatPrintProject,
  ModelVersion,
  VersionChangeType,
  DesignSpecification,
  ModelGeometryStats,
  FidelityReviewResult,
  GenerationDiagnostics,
  InspectionViewSet,
} from '../projects/projectTypes';
import {
  getNextVersionNumber,
  createVersionLabel,
  buildModelVersion,
} from '../projects/projectService';
import { updateProjectMemoryFromVersion } from '../projects/projectMemory';

export { buildModelVersion };

export function restoreVersionInProject(
  project: KatPrintProject,
  targetVersionId: string
): { updatedProject: KatPrintProject; newVersion: ModelVersion } {
  const target = project.versions.find((v) => v.id === targetVersionId);
  if (!target) {
    throw new Error(`Target version ${targetVersionId} not found in project ${project.name}`);
  }

  const nextVerNum = getNextVersionNumber(project.versions);
  const newVersion = buildModelVersion({
    projectId: project.id,
    versionNumber: nextVerNum,
    label: `V${nextVerNum} — Restored from V${target.versionNumber}`,
    changeType: 'RESTORED',
    changeSummary: `Restored exact geometry and specifications from V${target.versionNumber} (${target.label}).`,
    userInstruction: `Restore V${target.versionNumber}`,
    sourceVersionId: target.id,
    parentVersionId: target.id,
    designSpecification: target.designSpecification ? JSON.parse(JSON.stringify(target.designSpecification)) : undefined,
    designChecklist: target.designChecklist ? JSON.parse(JSON.stringify(target.designChecklist)) : undefined,
    cadCode: target.cadCode,
    geometryMetadata: target.geometryMetadata ? JSON.parse(JSON.stringify(target.geometryMetadata)) : undefined,
    fidelityReview: target.fidelityReview ? JSON.parse(JSON.stringify(target.fidelityReview)) : undefined,
    featureModel: target.featureModel ? JSON.parse(JSON.stringify(target.featureModel)) : null,
    assembly: target.assembly ? JSON.parse(JSON.stringify(target.assembly)) : null,
    projectDesignState: target.projectDesignState ? JSON.parse(JSON.stringify(target.projectDesignState)) : null,
    semanticFeaturePlan: target.semanticFeaturePlan ? JSON.parse(JSON.stringify(target.semanticFeaturePlan)) : null,
    requirementCoverageReport: target.requirementCoverageReport ? JSON.parse(JSON.stringify(target.requirementCoverageReport)) : null,
    designIntentAudit: target.designIntentAudit ? JSON.parse(JSON.stringify(target.designIntentAudit)) : null,
    designMatchScore: target.designMatchScore,
    inspectionImages: target.inspectionImages,
    generationDiagnostics: target.generationDiagnostics,
    thumbnail: target.thumbnail,
    isCurrentHead: true,
  });

  const previousVersions = project.versions.map((v) => ({ ...v, isCurrentHead: false }));

  const updatedProject: KatPrintProject = {
    ...project,
    versions: [...previousVersions, newVersion],
    currentVersionId: newVersion.id,
    updatedAt: new Date().toISOString(),
    thumbnail: newVersion.thumbnail || project.thumbnail,
    projectMemory: updateProjectMemoryFromVersion(project.projectMemory, newVersion, `Restored from V${target.versionNumber}`),
    conversation: [
      ...project.conversation,
      {
        id: `msg_${Date.now()}`,
        projectId: project.id,
        role: 'katprint',
        content: `Restored design state from V${target.versionNumber} ("${target.label}"). Created V${nextVerNum}.`,
        timestamp: new Date().toISOString(),
        relatedVersionId: newVersion.id,
        actionType: 'restore',
      },
    ],
  };

  return { updatedProject, newVersion };
}

export function branchVersionInProject(
  project: KatPrintProject,
  targetVersionId: string,
  branchLabel?: string
): { updatedProject: KatPrintProject; newVersion: ModelVersion } {
  const target = project.versions.find((v) => v.id === targetVersionId);
  if (!target) {
    throw new Error(`Target version ${targetVersionId} not found in project ${project.name}`);
  }

  const nextVerNum = getNextVersionNumber(project.versions);
  const label = `V${nextVerNum} — ${branchLabel || `Branch from V${target.versionNumber}`}`;

  const newVersion = buildModelVersion({
    projectId: project.id,
    versionNumber: nextVerNum,
    label,
    changeType: 'BRANCH',
    changeSummary: `Branched alternate design from V${target.versionNumber}.`,
    userInstruction: `Branch from V${target.versionNumber}`,
    sourceVersionId: target.id,
    parentVersionId: target.id,
    designSpecification: target.designSpecification ? JSON.parse(JSON.stringify(target.designSpecification)) : undefined,
    designChecklist: target.designChecklist ? JSON.parse(JSON.stringify(target.designChecklist)) : undefined,
    cadCode: target.cadCode,
    geometryMetadata: target.geometryMetadata ? JSON.parse(JSON.stringify(target.geometryMetadata)) : undefined,
    fidelityReview: target.fidelityReview ? JSON.parse(JSON.stringify(target.fidelityReview)) : undefined,
    featureModel: target.featureModel ? JSON.parse(JSON.stringify(target.featureModel)) : null,
    assembly: target.assembly ? JSON.parse(JSON.stringify(target.assembly)) : null,
    projectDesignState: target.projectDesignState ? JSON.parse(JSON.stringify(target.projectDesignState)) : null,
    semanticFeaturePlan: target.semanticFeaturePlan ? JSON.parse(JSON.stringify(target.semanticFeaturePlan)) : null,
    requirementCoverageReport: target.requirementCoverageReport ? JSON.parse(JSON.stringify(target.requirementCoverageReport)) : null,
    designIntentAudit: target.designIntentAudit ? JSON.parse(JSON.stringify(target.designIntentAudit)) : null,
    designMatchScore: target.designMatchScore,
    inspectionImages: target.inspectionImages,
    generationDiagnostics: target.generationDiagnostics,
    thumbnail: target.thumbnail,
    isCurrentHead: true,
  });

  const previousVersions = project.versions.map((v) => ({ ...v, isCurrentHead: false }));

  const updatedProject: KatPrintProject = {
    ...project,
    versions: [...previousVersions, newVersion],
    currentVersionId: newVersion.id,
    updatedAt: new Date().toISOString(),
    thumbnail: newVersion.thumbnail || project.thumbnail,
    projectMemory: updateProjectMemoryFromVersion(project.projectMemory, newVersion, `Branch from V${target.versionNumber}`),
    conversation: [
      ...project.conversation,
      {
        id: `msg_${Date.now()}`,
        projectId: project.id,
        role: 'katprint',
        content: `Created new design branch V${nextVerNum} starting from V${target.versionNumber}.`,
        timestamp: new Date().toISOString(),
        relatedVersionId: newVersion.id,
        actionType: 'branch',
      },
    ],
  };

  return { updatedProject, newVersion };
}

export function sanitizeStlFilename(projectName: string, versionNumber: number): string {
  const safeName = projectName
    .trim()
    .replace(/[^a-zA-Z0-9_\-\s]/g, '')
    .replace(/\s+/g, '_')
    .slice(0, 40);
  return `${safeName || 'KatPrint_Model'}_V${versionNumber}.stl`;
}

export function branchNewVersion(
  versions: ModelVersion[],
  targetVersionId: string,
  label?: string
): ModelVersion[] {
  const target = versions.find((v) => v.id === targetVersionId);
  if (!target) throw new Error(`Target version ${targetVersionId} not found`);
  const nextNum = getNextVersionNumber(versions);

  const newVer = buildModelVersion({
    projectId: target.projectId,
    versionNumber: nextNum,
    label: `V${nextNum} — ${label || `Branch from V${target.versionNumber}`}`,
    changeType: 'BRANCH',
    changeSummary: `Branched alternate design path from V${target.versionNumber}`,
    userInstruction: `Branch from V${target.versionNumber}`,
    sourceVersionId: target.id,
    parentVersionId: target.id,
    designSpecification: target.designSpecification,
    designChecklist: target.designChecklist,
    cadCode: target.cadCode,
    geometryMetadata: target.geometryMetadata,
    fidelityReview: target.fidelityReview,
    designMatchScore: target.designMatchScore,
    inspectionImages: target.inspectionImages,
    generationDiagnostics: target.generationDiagnostics,
    thumbnail: target.thumbnail,
    isCurrentHead: true,
  });

  return [...versions.map((v) => ({ ...v, isCurrentHead: false })), newVer];
}

export function restoreVersionAsNewHead(
  versions: ModelVersion[],
  targetVersionId: string
): ModelVersion[] {
  const target = versions.find((v) => v.id === targetVersionId);
  if (!target) throw new Error(`Target version ${targetVersionId} not found`);
  const nextNum = getNextVersionNumber(versions);

  const newVer = buildModelVersion({
    projectId: target.projectId,
    versionNumber: nextNum,
    label: `V${nextNum} — Restored from V${target.versionNumber}`,
    changeType: 'RESTORED',
    changeSummary: `Restored exact geometry and specifications from V${target.versionNumber} (${target.label}).`,
    userInstruction: `Restore V${target.versionNumber}`,
    sourceVersionId: target.id,
    parentVersionId: target.id,
    designSpecification: target.designSpecification,
    designChecklist: target.designChecklist,
    cadCode: target.cadCode,
    geometryMetadata: target.geometryMetadata,
    fidelityReview: target.fidelityReview,
    designMatchScore: target.designMatchScore,
    inspectionImages: target.inspectionImages,
    generationDiagnostics: target.generationDiagnostics,
    thumbnail: target.thumbnail,
    isCurrentHead: true,
  });

  return [...versions.map((v) => ({ ...v, isCurrentHead: false })), newVer];
}
