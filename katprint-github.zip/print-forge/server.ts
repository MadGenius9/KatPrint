import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

import { handleGenerationStatus } from './server/gemini/client';
import { registerGenerate } from './server/cad/generate';
import { registerRevise } from './server/cad/revise';
import { registerExplain } from './server/slicer/explain';
import { registerFullPipeline } from './server/full';
import { registerTelemetry } from './server/telemetry/simulation';
import { registerPhotoAnalysis } from './server/cad/photoAnalysis';

// Load .env.local first if it exists, without overriding existing environment variables
const envLocalPath = path.resolve(process.cwd(), '.env.local');
if (fs.existsSync(envLocalPath)) {
  dotenv.config({ path: envLocalPath });
}
dotenv.config();

const app = express();
const server = http.createServer(app);
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '25mb' }));

// -------------------------------------------------------------
// GET /api/health
// -------------------------------------------------------------
app.get('/api/health', (req, res) => {
  const rawKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
  const key = rawKey?.trim();
  const hasGeminiKey = Boolean(key && key !== '' && key !== 'MY_GEMINI_API_KEY');
  res.json({
    status: 'ok',
    hasGeminiKey,
    timestamp: new Date().toISOString(),
    service: 'KatPrint',
  });
});

// -------------------------------------------------------------
// GET /api/generation-status/:requestId
// -------------------------------------------------------------
app.get('/api/generation-status/:requestId', handleGenerationStatus);

// -------------------------------------------------------------
// Domain API Route Modules
// -------------------------------------------------------------
registerGenerate(app);
registerRevise(app);
registerExplain(app);
registerFullPipeline(app);
registerTelemetry(app, server);
registerPhotoAnalysis(app);

// Catch-all for API endpoints to prevent falling through to Vite HTML SPA middleware
app.use('/api', (req, res) => {
  res.status(404).json({ error: `API endpoint not found: ${req.method} ${req.originalUrl || req.url}` });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  // Only listen when executed directly, not when imported by test harnesses
  if (process.env.NODE_ENV !== 'test') {
    server.listen(PORT, '0.0.0.0', () => {
      console.log(`Server listening on http://0.0.0.0:${PORT}`);
    });
  }
}

startServer();

export { app, server };
