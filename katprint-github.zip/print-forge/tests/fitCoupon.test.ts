import { describe, it, expect } from 'vitest';
import { executeJscadModel } from '../src/engine/jscadRunner';
import { FIT_COUPON_JSCAD, FIT_COUPON_CLEARANCES } from '../src/engine/fitCoupon';

describe('FIT_COUPON_JSCAD verification', () => {
  it('exports valid clearances list', () => {
    expect(FIT_COUPON_CLEARANCES).toEqual([0.10, 0.15, 0.20, 0.25, 0.30, 0.40]);
  });

  it('executes through jscadRunner and returns Socket Bar and Reference Peg with correct dimensions at Z=0', () => {
    const executed = executeJscadModel(FIT_COUPON_JSCAD);

    // 1. Returns two parts: "Socket Bar" and "Reference Peg"
    expect(executed.parts).toBeDefined();
    expect(executed.parts.length).toBe(2);

    const socketBarPart = executed.parts.find((p) => p.name === 'Socket Bar');
    const referencePegPart = executed.parts.find((p) => p.name === 'Reference Peg');

    expect(socketBarPart).toBeDefined();
    expect(referencePegPart).toBeDefined();

    // 2. Socket bar bounding box is within 1mm of 120 x 26 x 10 mm
    const barBox = socketBarPart!.boundingBox;
    expect(Math.abs(barBox.x - 120)).toBeLessThanOrEqual(1.0);
    expect(Math.abs(barBox.y - 26)).toBeLessThanOrEqual(1.0);
    expect(Math.abs(barBox.z - 10)).toBeLessThanOrEqual(1.0);

    // 3. Peg bounding box is within 1mm of 16 x 16 x 17 mm
    const pegBox = referencePegPart!.boundingBox;
    expect(Math.abs(pegBox.x - 16)).toBeLessThanOrEqual(1.0);
    expect(Math.abs(pegBox.y - 16)).toBeLessThanOrEqual(1.0);
    expect(Math.abs(pegBox.z - 17)).toBeLessThanOrEqual(1.0);

    // 4. Both parts have min Z == 0
    socketBarPart!.geometry.computeBoundingBox();
    referencePegPart!.geometry.computeBoundingBox();
    expect(Math.abs(socketBarPart!.geometry.boundingBox.min.z)).toBeLessThanOrEqual(0.01);
    expect(Math.abs(referencePegPart!.geometry.boundingBox.min.z)).toBeLessThanOrEqual(0.01);
  });
});
