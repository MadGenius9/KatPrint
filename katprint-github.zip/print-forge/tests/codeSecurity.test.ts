import { describe, it, expect } from 'vitest';
import { validateCadCodeSecurity } from '../src/engine/codeSecurity';

describe('validateCadCodeSecurity', () => {
  describe('MUST PASS', () => {
    const allowedSnippets = [
      'const pts = raw.map(function (p) { return [p[0]*2, p[1]]; });',
      'const path = [[0,0],[10,0]]; const prof = expand({delta:2}, path);',
      'const location = wickOffset;',
      'const globalWall = 2.4;',
    ];

    allowedSnippets.forEach((code) => {
      it(`allows safe code: "${code}"`, () => {
        const result = validateCadCodeSecurity(code);
        expect(result.isSafe).toBe(true);
        expect(result.violations).toHaveLength(0);
      });
    });
  });

  describe('MUST BE BLOCKED', () => {
    const blockedSnippets = [
      "eval('bad()');",
      "new Function('return 1');",
      "window.location.href = 'x';",
      "fetch('http://example.com');",
    ];

    blockedSnippets.forEach((code) => {
      it(`blocks unsafe code: "${code}"`, () => {
        const result = validateCadCodeSecurity(code);
        expect(result.isSafe).toBe(false);
        expect(result.violations.length).toBeGreaterThan(0);
      });
    });
  });
});
