import { describe, it, expect } from 'vitest';
import { buildTextOnlyRequirements } from '../src/engine/textRequirements';

describe('buildTextOnlyRequirements', () => {
  it('parses self-watering planter: height 150, diameter 120, width 120, depth 120, mustHoldLiquid true', () => {
    const res = buildTextOnlyRequirements('A self-watering planter 150mm tall and 120mm in diameter');
    expect(res.overallDimensions.height).toBe(150);
    expect(res.overallDimensions.diameter).toBe(120);
    expect(res.overallDimensions.width).toBe(120);
    expect(res.overallDimensions.depth).toBe(120);
    expect(res.mustHoldLiquid).toBe(true);
  });

  it('parses hex pen cup in inches: height 101.6, diameter 76.2', () => {
    const res = buildTextOnlyRequirements('A hex pen cup 4 inches tall and 3 inches in diameter');
    expect(res.overallDimensions.height).toBe(101.6);
    expect(res.overallDimensions.diameter).toBe(76.2);
  });

  it('parses small box with lid by triples: length 80, width 60, height 40, isMultiPart true', () => {
    const res = buildTextOnlyRequirements('A small box with a lid, 80 by 60 by 40');
    expect(res.overallDimensions.length).toBe(80);
    expect(res.overallDimensions.width).toBe(60);
    expect(res.overallDimensions.height).toBe(40);
    expect(res.isMultiPart).toBe(true);
  });

  it('parses storage crate: length 400, width 300, height 200, primaryObject "storage crate"', () => {
    const res = buildTextOnlyRequirements('A storage crate 400mm long, 300mm wide and 200mm tall');
    expect(res.overallDimensions.length).toBe(400);
    expect(res.overallDimensions.width).toBe(300);
    expect(res.overallDimensions.height).toBe(200);
    expect(res.primaryObject).toBe('storage crate');
  });

  it('parses phone stand 80 x 70 x 90 mm: length 80, width 70, height 90', () => {
    const res = buildTextOnlyRequirements('A phone stand 80 x 70 x 90 mm');
    expect(res.overallDimensions.length).toBe(80);
    expect(res.overallDimensions.width).toBe(70);
    expect(res.overallDimensions.height).toBe(90);
  });

  it('parses two-piece mold for 50mm sphere: isMultiPart true', () => {
    const res = buildTextOnlyRequirements('A two-piece mold for a 50mm sphere');
    expect(res.isMultiPart).toBe(true);
  });

  it('parses cup 3in tall with a handle: height 76.2, mustHoldLiquid true', () => {
    const res = buildTextOnlyRequirements('A cup 3in tall with a handle');
    expect(res.overallDimensions.height).toBe(76.2);
    expect(res.mustHoldLiquid).toBe(true);
  });
});
