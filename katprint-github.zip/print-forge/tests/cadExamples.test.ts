import { describe, it, expect } from 'vitest';
import * as jscadModeling from '@jscad/modeling';
import { CAD_EXAMPLES } from '../src/prompts/cadExamples';

const { primitives, booleans, transforms, measurements } = jscadModeling as any;
const { measureBoundingBox, measureVolume } = measurements;

describe('CAD_EXAMPLES verification', () => {
  // Split CAD_EXAMPLES on "// EXAMPLE" markers, keeping the marker line as comment
  const rawParts = CAD_EXAMPLES.split(/(?=\/\/\s*EXAMPLE)/i);
  const examples = rawParts.map((p) => p.trim()).filter((p) => p.length > 0);

  it('contains 3 examples', () => {
    expect(examples).toHaveLength(3);
  });

  examples.forEach((exampleCode, index) => {
    const exampleNumber = index + 1;
    it(`executes Example ${exampleNumber} and validates geometry`, () => {
      const runner = new Function(
        'primitives',
        'booleans',
        'transforms',
        'measurements',
        `
        const { cuboid, cylinder, cube, sphere } = primitives;
        const { union, subtract, intersect } = booleans;
        const { translate, rotate, scale } = transforms;
        ${exampleCode}
        return main();
        `
      );

      const returned = runner(primitives, booleans, transforms, measurements);
      const solids = Array.isArray(returned) ? returned : [returned];

      expect(solids.length).toBeGreaterThan(0);

      if (exampleNumber === 3) {
        expect(solids).toHaveLength(2);
      }

      for (const solid of solids) {
        const bbox = measureBoundingBox(solid);
        // bbox is [[minX, minY, minZ], [maxX, maxY, maxZ]]
        const minZ = bbox[0][2];
        expect(Math.abs(minZ)).toBeLessThanOrEqual(0.01);

        const bboxWidth = bbox[1][0] - bbox[0][0];
        const bboxDepth = bbox[1][1] - bbox[0][1];
        const bboxHeight = bbox[1][2] - bbox[0][2];
        const bboxVolume = bboxWidth * bboxDepth * bboxHeight;

        const solidVolume = measureVolume(solid);
        expect(solidVolume).toBeLessThan(0.8 * bboxVolume);
      }
    });
  });
});
