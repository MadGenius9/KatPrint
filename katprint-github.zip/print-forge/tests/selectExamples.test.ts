import { describe, it, expect } from 'vitest';
import { selectExamples } from '../src/examples/selectExamples';
import { getSeedExamples } from '../src/examples/exampleLibrary';
import { CadExample } from '../src/types';

describe('Similarity Example Selection (selectExamples)', () => {
  const seeds = getSeedExamples();

  it('selects box (multi_part) first for "a cup with a lid"', () => {
    const selected = selectExamples('a cup with a lid', undefined, seeds, 3);
    expect(selected).toHaveLength(3);
    expect(selected[0].shapeClass).toBe('multi_part');
    expect(selected[0].id).toBe('seed_box');
  });

  it('selects planter first for "a self watering pot"', () => {
    const selected = selectExamples('a self watering pot', undefined, seeds, 3);
    expect(selected).toHaveLength(3);
    expect(selected[0].shapeClass).toBe('container');
    expect(selected[0].id).toBe('seed_planter');
  });

  it('selects tray first for "sorting tray for screws"', () => {
    const selected = selectExamples('sorting tray for screws', undefined, seeds, 3);
    expect(selected).toHaveLength(3);
    expect(selected[0].shapeClass).toBe('tray');
    expect(selected[0].id).toBe('seed_tray');
  });

  it('selects user example first when matching container and vase keyword', () => {
    const userExample: CadExample = {
      id: 'user_tall_vase',
      title: 'Minimalist Tall Vase',
      prompt: 'A tall cylindrical flower vase',
      code: `const vaseHeight = 180; const vaseDia = 70; function main() { return cylinder({ radius: vaseDia/2, height: vaseHeight }); }`,
      shapeClass: 'container',
      keywords: ['vase'],
      dimsMm: { x: 70, y: 70, z: 180 },
      isMultiPart: false,
      holdsLiquid: true,
      source: 'user',
      createdAt: '2026-09-01T12:00:00.000Z',
    };

    const libraryWithUser = [userExample, ...seeds];
    const selected = selectExamples('tall vase', undefined, libraryWithUser, 3);

    expect(selected).toHaveLength(3);
    expect(selected[0].id).toBe('user_tall_vase');
    expect(selected[0].source).toBe('user');
  });

  it('always returns exactly 3 examples and never duplicates code', () => {
    // Test with various prompts
    const prompts = [
      'a cup with a lid',
      'a self watering pot',
      'sorting tray for screws',
      'random gizmo widget',
      '',
    ];

    for (const p of prompts) {
      const result = selectExamples(p, undefined, seeds, 3);
      expect(result).toHaveLength(3);

      const codes = result.map((r) => r.code.trim());
      const uniqueCodes = new Set(codes);
      expect(uniqueCodes.size).toBe(3);
    }

    // Test with duplicate code in library
    const duplicateExample: CadExample = {
      ...seeds[0],
      id: 'duplicate_planter',
      title: 'Duplicate Planter',
      createdAt: '2026-09-02T12:00:00.000Z',
    };
    const libraryWithDuplicate = [duplicateExample, ...seeds];
    const resultDup = selectExamples('planter for succulents', undefined, libraryWithDuplicate, 3);
    expect(resultDup).toHaveLength(3);
    const codes = resultDup.map((r) => r.code.trim());
    expect(new Set(codes).size).toBe(3);
  });
});
