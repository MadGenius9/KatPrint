import { describe, it, expect } from 'vitest';
import {
  getSeedExamples,
  addUserExampleWithCap,
  mergeExamplesById,
  MAX_USER_EXAMPLES,
} from '../src/examples/exampleLibrary';
import { CadExample } from '../src/types';

describe('Example Library (exampleLibrary)', () => {
  it('seed load yields 3 examples with the expected shape classes', () => {
    const seeds = getSeedExamples();
    expect(seeds).toHaveLength(3);

    const planter = seeds.find((s) => s.id === 'seed_planter');
    const tray = seeds.find((s) => s.id === 'seed_tray');
    const box = seeds.find((s) => s.id === 'seed_box');

    expect(planter).toBeDefined();
    expect(planter?.shapeClass).toBe('container');
    expect(planter?.holdsLiquid).toBe(true);

    expect(tray).toBeDefined();
    expect(tray?.shapeClass).toBe('tray');
    expect(tray?.isMultiPart).toBe(false);

    expect(box).toBeDefined();
    expect(box?.shapeClass).toBe('multi_part');
    expect(box?.isMultiPart).toBe(true);
  });

  it('adding a 51st user example drops the oldest un-starred one', () => {
    // Generate 50 user examples
    let userList: CadExample[] = [];
    for (let i = 1; i <= 50; i++) {
      userList.push({
        id: `user_ex_${i}`,
        title: `User Example ${i}`,
        prompt: `Prompt ${i}`,
        code: `// code ${i}\nfunction main() { return cube({ size: [${i}, 10, 10] }); }`,
        shapeClass: 'other',
        keywords: [`tag_${i}`],
        dimsMm: { x: i, y: 10, z: 10 },
        isMultiPart: false,
        holdsLiquid: false,
        source: 'user',
        // Dates from 2026-01-01 upwards
        createdAt: new Date(2026, 0, i, 12, 0, 0).toISOString(),
        // Star example 1 so it should NOT be dropped even though it's oldest!
        starred: i === 1,
      });
    }

    expect(userList).toHaveLength(50);
    // User example 1 is starred; user example 2 is the oldest un-starred (Jan 2).
    const example51: CadExample = {
      id: 'user_ex_51',
      title: 'User Example 51',
      prompt: 'Prompt 51',
      code: '// code 51\nfunction main() { return cylinder({ radius: 10, height: 20 }); }',
      shapeClass: 'container',
      keywords: ['new_item'],
      dimsMm: { x: 20, y: 20, z: 20 },
      isMultiPart: false,
      holdsLiquid: true,
      source: 'user',
      createdAt: new Date(2026, 2, 1, 12, 0, 0).toISOString(),
      starred: false,
    };

    const cappedList = addUserExampleWithCap(userList, example51, MAX_USER_EXAMPLES);
    expect(cappedList).toHaveLength(50);

    // user_ex_1 was starred, so it must still be in cappedList!
    expect(cappedList.some((e) => e.id === 'user_ex_1')).toBe(true);

    // user_ex_2 was the oldest un-starred, so it should have been dropped!
    expect(cappedList.some((e) => e.id === 'user_ex_2')).toBe(false);

    // user_ex_51 should be in the list!
    expect(cappedList.some((e) => e.id === 'user_ex_51')).toBe(true);
  });

  it('import merges by id without duplicating', () => {
    const initialList: CadExample[] = [
      {
        id: 'ex_alpha',
        title: 'Original Alpha',
        prompt: 'Alpha prompt',
        code: '// Alpha original code',
        shapeClass: 'tray',
        keywords: ['alpha'],
        dimsMm: { x: 10, y: 10, z: 10 },
        isMultiPart: false,
        holdsLiquid: false,
        source: 'user',
        createdAt: '2026-01-01T00:00:00.000Z',
      },
      {
        id: 'ex_beta',
        title: 'Original Beta',
        prompt: 'Beta prompt',
        code: '// Beta code',
        shapeClass: 'bracket',
        keywords: ['beta'],
        dimsMm: { x: 20, y: 20, z: 20 },
        isMultiPart: false,
        holdsLiquid: false,
        source: 'user',
        createdAt: '2026-01-02T00:00:00.000Z',
      },
    ];

    const incomingList: CadExample[] = [
      {
        id: 'ex_alpha',
        title: 'Updated Alpha Title',
        prompt: 'Alpha prompt updated',
        code: '// Alpha updated code',
        shapeClass: 'tray',
        keywords: ['alpha', 'updated'],
        dimsMm: { x: 15, y: 15, z: 15 },
        isMultiPart: false,
        holdsLiquid: false,
        source: 'user',
        createdAt: '2026-01-01T00:00:00.000Z',
      },
      {
        id: 'ex_gamma',
        title: 'New Gamma',
        prompt: 'Gamma prompt',
        code: '// Gamma code',
        shapeClass: 'flat',
        keywords: ['gamma'],
        dimsMm: { x: 30, y: 30, z: 5 },
        isMultiPart: false,
        holdsLiquid: false,
        source: 'user',
        createdAt: '2026-01-03T00:00:00.000Z',
      },
    ];

    const { merged, added, updated } = mergeExamplesById(initialList, incomingList);

    expect(merged).toHaveLength(3); // ex_alpha, ex_beta, ex_gamma
    expect(added).toBe(1); // ex_gamma added
    expect(updated).toBe(1); // ex_alpha updated

    const mergedAlpha = merged.find((e) => e.id === 'ex_alpha');
    expect(mergedAlpha?.title).toBe('Updated Alpha Title');
    expect(mergedAlpha?.code).toBe('// Alpha updated code');

    const mergedBeta = merged.find((e) => e.id === 'ex_beta');
    expect(mergedBeta?.title).toBe('Original Beta');

    const mergedGamma = merged.find((e) => e.id === 'ex_gamma');
    expect(mergedGamma?.title).toBe('New Gamma');
  });
});
