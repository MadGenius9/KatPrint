import { describe, it, expect } from 'vitest';
import * as jscadModeling from '@jscad/modeling';
import { CAD_EXAMPLES } from '../src/prompts/cadExamples';
import { FIT_COUPON_JSCAD } from '../src/engine/fitCoupon';
import { measureJscadSolids } from '../server/cad/sandbox';

const { primitives, booleans, transforms, measurements } = jscadModeling as any;

describe('Manifold and closure verification', () => {
  it('validates closure on all CAD_EXAMPLES and FIT_COUPON_JSCAD parts', () => {
    // 1. Validate the three CAD_EXAMPLES
    const rawParts = CAD_EXAMPLES.split(/(?=\/\/\s*EXAMPLE)/i);
    const examples = rawParts.map((p) => p.trim()).filter((p) => p.length > 0);
    expect(examples).toHaveLength(3);

    for (const [index, exampleCode] of examples.entries()) {
      const runner = new Function(
        'primitives',
        'booleans',
        'transforms',
        'measurements',
        `
        const { cuboid, cylinder, cube, sphere } = primitives;
        const { union, subtract, intersect } = booleans;
        const { translate, rotate, scale } = transforms;
        ${exampleCode}
        let executedParts = null;
        if (typeof getParts === 'function') {
          try { executedParts = getParts(); } catch (e) {}
        }
        let mainRes = null;
        if (typeof main === 'function') {
          mainRes = main();
        }
        return { mainRes, executedParts };
        `
      );

      const res = runner(primitives, booleans, transforms, measurements);
      const parts = res.executedParts
        ? res.executedParts.map((p: any) => p.geometry)
        : (Array.isArray(res.mainRes) ? res.mainRes : [res.mainRes]);

      expect(parts.length).toBeGreaterThan(0);
      if (index === 2) {
        expect(parts).toHaveLength(2);
      }

      for (const part of parts) {
        const measured = measureJscadSolids(part);
        expect(measured).not.toBeNull();
        expect(measured!.isClosed).toBe(true);
        expect(measured!.closureResidual).toBeLessThan(1e-6);
        expect(measured!.isManifold).toBe(true);
      }
    }

    // 2. Validate FIT_COUPON_JSCAD
    const couponRunner = new Function(
      'primitives',
      'booleans',
      'transforms',
      'measurements',
      `
      const { cuboid, cylinder, cube, sphere } = primitives;
      const { union, subtract, intersect } = booleans;
      const { translate, rotate, scale } = transforms;
      ${FIT_COUPON_JSCAD}
      let executedParts = null;
      if (typeof getParts === 'function') {
        try { executedParts = getParts(); } catch (e) {}
      }
      let mainRes = null;
      if (typeof main === 'function') {
        mainRes = main();
      }
      return { mainRes, executedParts };
      `
    );

    const couponRes = couponRunner(primitives, booleans, transforms, measurements);
    const couponParts = couponRes.executedParts
      ? couponRes.executedParts.map((p: any) => p.geometry)
      : (Array.isArray(couponRes.mainRes) ? couponRes.mainRes : [couponRes.mainRes]);

    expect(couponParts).toHaveLength(2);
    for (const part of couponParts) {
      const measured = measureJscadSolids(part);
      expect(measured).not.toBeNull();
      expect(measured!.isClosed).toBe(true);
      expect(measured!.closureResidual).toBeLessThan(1e-6);
      expect(measured!.isManifold).toBe(true);
    }
  });

  it('rejects open solid missing top polygon with isClosed === false and closureResidual > 0.05', () => {
    const { cuboid } = primitives;
    const solid = cuboid({ size: [20, 20, 20] });
    const polygons = solid.polygons || (solid.toPolygons ? solid.toPolygons() : []);

    let maxZ = -Infinity;
    for (const poly of polygons) {
      for (const v of poly.vertices) {
        if (v[2] > maxZ) maxZ = v[2];
      }
    }

    // Filter out top polygon (all vertices have z at maxZ)
    const filteredPolygons = polygons.filter((poly: any) => {
      const allAtMaxZ = poly.vertices.every((v: any) => Math.abs(v[2] - maxZ) < 1e-4);
      return !allAtMaxZ;
    });

    // 5 faces remain out of 6
    expect(filteredPolygons.length).toBeLessThan(polygons.length);

    const openSolid = { polygons: filteredPolygons };
    const measured = measureJscadSolids(openSolid);

    expect(measured).not.toBeNull();
    expect(measured!.isClosed).toBe(false);
    expect(measured!.closureResidual).toBeGreaterThan(0.05);
    expect(measured!.isManifold).toBe(false);
  });
});
