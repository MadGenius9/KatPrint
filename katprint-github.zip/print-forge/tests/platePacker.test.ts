import { describe, it, expect } from 'vitest';
import { computePrintPlatePlan } from '../src/engine/printPlatePacker';
import { PrinterSpec, ExecutedModelPart } from '../src/types';

const printer: PrinterSpec = {
  id: 'ender3v3se',
  name: 'Creality Ender-3 V3 SE',
  buildVolume: { x: 220, y: 220, z: 250 },
  nozzleDiameter: 0.4,
  maxVolumetricFlow: 12,
  driveType: 'direct',
  isEnclosed: false,
};

function createPart(id: string, name: string, x: number, y: number, z: number, quantity = 1): ExecutedModelPart {
  return {
    id,
    name,
    quantity,
    geometry: null,
    featureIds: [],
    stats: {
      volumeMm3: x * y * z,
      volumeCm3: (x * y * z) / 1000,
      surfaceAreaMm2: 2 * (x * y + y * z + x * z),
      dimensions: { x, y, z },
      estimatedWeightGrams: ((x * y * z) / 1000) * 1.24,
      triangleCount: 12,
      vertexCount: 8,
      overhangRatio: 0,
      minWallThicknessMm: 3.0,
      isManifold: true,
      footprintAreaMm2: x * y,
      heightToWidthRatio: z / Math.max(1, x),
      hasSteepOverhangs: false,
    },
    boundingBox: { x, y, z },
  };
}

describe('computePrintPlatePlan', () => {
  it('handles one 50x50x300 part -> 1 plate, fitsOnBed false, name contains "Oversized"', () => {
    const parts = [createPart('p1', 'Tall Part', 50, 50, 300, 1)];
    const plan = computePrintPlatePlan(parts, printer);

    expect(plan.plates).toHaveLength(1);
    expect(plan.plates[0].fitsOnBed).toBe(false);
    expect(plan.plates[0].plateName).toContain('Oversized');
    expect(plan.plates[0].items.length).toBeGreaterThan(0);
  });

  it('handles three 200x40x10 parts -> 1 plate with 3 items', () => {
    const parts = [
      createPart('p1', 'Bar 1', 200, 40, 10, 1),
      createPart('p2', 'Bar 2', 200, 40, 10, 1),
      createPart('p3', 'Bar 3', 200, 40, 10, 1),
    ];
    const plan = computePrintPlatePlan(parts, printer);

    expect(plan.plates).toHaveLength(1);
    expect(plan.plates[0].items).toHaveLength(3);
    expect(plan.plates[0].fitsOnBed).toBe(true);
  });

  it('handles 120x120x150 + 110x110x15 -> 2 plates', () => {
    const parts = [
      createPart('p1', 'Pot', 120, 120, 150, 1),
      createPart('p2', 'Saucer', 110, 110, 15, 1),
    ];
    const plan = computePrintPlatePlan(parts, printer);

    expect(plan.plates).toHaveLength(2);
    expect(plan.plates[0].items.length).toBeGreaterThan(0);
    expect(plan.plates[1].items.length).toBeGreaterThan(0);
  });

  it('handles one 40x30x12 part with quantity 6 -> 1 plate with 6 items', () => {
    const parts = [createPart('p1', 'Bracket', 40, 30, 12, 6)];
    const plan = computePrintPlatePlan(parts, printer);

    expect(plan.plates).toHaveLength(1);
    expect(plan.plates[0].items).toHaveLength(6);
    expect(plan.plates[0].fitsOnBed).toBe(true);
  });

  it('handles 80x80x20 + 400x400x50 -> exactly 2 plates, none with 0 items', () => {
    const parts = [
      createPart('p1', 'Small Base', 80, 80, 20, 1),
      createPart('p2', 'Huge Crate', 400, 400, 50, 1),
    ];
    const plan = computePrintPlatePlan(parts, printer);

    expect(plan.plates).toHaveLength(2);
    expect(plan.plates.every((p) => p.items.length > 0)).toBe(true);
    expect(plan.plates[0].fitsOnBed).toBe(true);
    expect(plan.plates[1].fitsOnBed).toBe(false);
  });

  it('ensures no plate in any result has items.length === 0', () => {
    const testSuites = [
      [createPart('p1', 'Tall', 50, 50, 300, 1)],
      [createPart('p2', 'Bar', 200, 40, 10, 3)],
      [createPart('p3', 'Pot', 120, 120, 150, 1), createPart('p4', 'Saucer', 110, 110, 15, 1)],
      [createPart('p5', 'Bracket', 40, 30, 12, 6)],
      [createPart('p6', 'Small', 80, 80, 20, 1), createPart('p7', 'Oversized', 400, 400, 50, 1)],
    ];

    for (const parts of testSuites) {
      const plan = computePrintPlatePlan(parts, printer);
      for (const plate of plan.plates) {
        expect(plate.items.length).toBeGreaterThan(0);
      }
    }
  });
});
