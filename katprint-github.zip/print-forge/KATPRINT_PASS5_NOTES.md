# KatPrint Pass 5 — Honesty, Clarification Gate, GitHub packaging

## Fixes
- Photo-to-Mesh UI no longer pretends to reconstruct geometry. Preview-only + explicit "not configured".
- Removed unused fake torus-knot sample mesh from `photoToMesh.ts`.
- Image-to-3D heightmap now exposes Width/Length sliders (values existed but had no controls).
- Image-to-3D copy matches the 25 MB shared image pipeline (JPEG/PNG/WebP/HEIC).

## Added
- `src/engine/clarificationGate.ts` — assess + inject critical open questions.
- Generation hook forces spec review when confidence is low, even if "skip review" is on.
- GitHub README, MIT LICENSE.

## Still not in this pass
- Real neural/photogrammetry provider integration.
- Full npm install / CI verification in the packaging environment.
