# KatPrint

Conversational 3D CAD designer and STL generator for 3D printing.

Describe a functional part in plain language (or upload a photo as reference). KatPrint extracts design intent, asks clarifying questions when confidence is low, generates parametric JSCAD, checks printability, and exports STL.

## Features

- **Describe & Design** — Gemini-backed parametric CAD with repair and fidelity review
- **Clarify before generate** — pauses on low-confidence specs so you can answer size/fit questions
- **Image-to-3D** — browser-side heightmap relief and silhouette extrusion (printable today)
- **Photo reconstruction** — reserved for a neural/photogrammetry provider (not configured; no fake meshes)
- **Projects & versions** — conversation revisions, feature parameters, printability checks

## Setup

**Prerequisites:** Node.js 20+

```bash
npm install
cp .env.example .env.local
```

Set `GEMINI_API_KEY` (or `GOOGLE_API_KEY`) in `.env.local`.

```bash
npm run dev
```

Open http://localhost:3000

## Scripts

| Command | Purpose |
|---------|---------|
| `npm run dev` | Dev server (Express + Vite) |
| `npm run build` | Production client + bundled server |
| `npm start` | Run production bundle |
| `npm run lint` | Typecheck (`tsc --noEmit`) |
| `npm test` | Vitest unit tests |

## Photo / neural 3D

`src/services/photoToMesh.ts` is an explicit stub. Uploads are preview-only until you wire a provider (Tripo3D, Meshy, CSM, Instant-Mesh, Meshroom). Image-to-3D heightmap/silhouette and parametric CAD from a reference photo are the working paths.

## License

MIT — see `LICENSE`.
