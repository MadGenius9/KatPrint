import { analyzePrintability, PrintabilityOptions, PrintabilityReport } from './printabilityAnalysis';

let workerInstance: Worker | null = null;
let currentRequestId = 0;
const pendingRequests = new Map<string, { resolve: (val: PrintabilityReport) => void; reject: (err: any) => void }>();

function getWorker(): Worker | null {
  if (typeof window === 'undefined' || typeof Worker === 'undefined') {
    return null;
  }
  if (!workerInstance) {
    try {
      workerInstance = new Worker(new URL('../workers/printabilityWorker.ts', import.meta.url), {
        type: 'module',
      });
      workerInstance.onmessage = (e: MessageEvent<{ id: string; success: boolean; report?: PrintabilityReport; error?: string }>) => {
        const { id, success, report, error } = e.data;
        const pending = pendingRequests.get(id);
        if (pending) {
          pendingRequests.delete(id);
          if (success && report) {
            pending.resolve(report);
          } else {
            pending.reject(new Error(error || 'Printability worker analysis failed'));
          }
        }
      };
      workerInstance.onerror = (err) => {
        console.warn('Printability worker error, falling back to main thread:', err);
        workerInstance = null;
      };
    } catch (e) {
      console.warn('Failed to initialize printability worker:', e);
      workerInstance = null;
    }
  }
  return workerInstance;
}

/**
 * Executes printability analysis asynchronously in a background Web Worker
 * with seamless fallback to main thread if workers are unavailable.
 */
export async function runPrintabilityAnalysisAsync(
  input: any,
  options: PrintabilityOptions = {}
): Promise<PrintabilityReport> {
  // If input is a Three.js geometry, extract serializable positions/indices for worker transfer
  let serializableInput = input;

  if (input && input.isBufferGeometry && input.attributes?.position) {
    const pos = input.attributes.position;
    const index = input.index;
    const positionsArray = Array.from(pos.array as ArrayLike<number>);
    const indicesArray = index ? Array.from(index.array as ArrayLike<number>) : null;

    serializableInput = {
      isBufferGeometry: true,
      attributes: {
        position: {
          array: positionsArray,
          count: pos.count,
          itemSize: pos.itemSize,
          getX: (i: number) => positionsArray[i * 3],
          getY: (i: number) => positionsArray[i * 3 + 1],
          getZ: (i: number) => positionsArray[i * 3 + 2],
        },
      },
      index: indicesArray
        ? {
            array: indicesArray,
            count: indicesArray.length,
            getX: (i: number) => indicesArray[i],
          }
        : null,
    };
  }

  const worker = getWorker();
  if (worker) {
    return new Promise<PrintabilityReport>((resolve, reject) => {
      const id = `req_${++currentRequestId}_${Date.now()}`;
      pendingRequests.set(id, { resolve, reject });
      try {
        worker.postMessage({ id, polygons: serializableInput, options });
      } catch (postErr) {
        pendingRequests.delete(id);
        // Fallback to synchronous analysis on error
        try {
          const syncResult = analyzePrintability(input, options);
          resolve(syncResult);
        } catch (syncErr) {
          reject(syncErr);
        }
      }
    });
  }

  // Fallback to main thread execution
  return analyzePrintability(input, options);
}
