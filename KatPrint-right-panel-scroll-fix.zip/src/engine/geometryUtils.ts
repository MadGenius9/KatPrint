import * as THREE from 'three';
import { ModelGeometryStats } from '../types';

export interface OverhangAnalysisResult {
  overhangRatio: number;
  hasSteepOverhangs: boolean;
  overhangAreaMm2: number;
  totalAreaMm2: number;
}

/**
 * Converts JSCAD geometries (geom3) to Three.js BufferGeometry
 */
export function jscadGeomToThree(jscadSolids: any): THREE.BufferGeometry {
  const solidsArray = Array.isArray(jscadSolids) ? jscadSolids : [jscadSolids];
  const positions: number[] = [];
  const normals: number[] = [];
  const colors: number[] = []; // RGB for overhang visualization

  const OVERHANG_THRESHOLD_RAD = (45 * Math.PI) / 180;
  const cos45 = Math.cos(OVERHANG_THRESHOLD_RAD);

  for (const solid of solidsArray) {
    if (!solid) continue;
    let polygons: any[] = [];
    if (typeof solid.polygons !== 'undefined') {
      polygons = solid.polygons;
    } else if (solid.toPolygons) {
      polygons = solid.toPolygons();
    } else if (solid.polygons && Array.isArray(solid.polygons)) {
      polygons = solid.polygons;
    }

    for (const poly of polygons) {
      const vertices = poly.vertices || poly;
      if (!Array.isArray(vertices) || vertices.length < 3) continue;

      // Triangulate n-gon via fan triangulation
      for (let i = 1; i < vertices.length - 1; i++) {
        const v0 = vertices[0];
        const v1 = vertices[i];
        const v2 = vertices[i + 1];

        const x0 = v0[0], y0 = v0[1], z0 = v0[2];
        const x1 = v1[0], y1 = v1[1], z1 = v1[2];
        const x2 = v2[0], y2 = v2[1], z2 = v2[2];

        // Triangle normal
        const ax = x1 - x0, ay = y1 - y0, az = z1 - z0;
        const bx = x2 - x0, by = y2 - y0, bz = z2 - z0;
        let nx = ay * bz - az * by;
        let ny = az * bx - ax * bz;
        let nz = ax * by - ay * bx;
        const len = Math.hypot(nx, ny, nz);
        if (len > 1e-6) {
          nx /= len;
          ny /= len;
          nz /= len;
        } else {
          nx = 0; ny = 0; nz = 1;
        }

        // Check overhang: if normal points downward with angle > 45 deg from horizontal
        // Normal pointing straight down is nz = -1 (angle with up is 180 deg).
        // Surface angle with vertical: if nz < -cos(45) = -0.7071, it is an overhang > 45 deg requiring support
        const isOverhang = nz < -0.65; // > 45 deg overhang

        // Colors: Default technical slate (0.35, 0.45, 0.55), Overhang: Warning Amber/Red (0.95, 0.25, 0.15)
        const r = isOverhang ? 0.98 : 0.42;
        const g = isOverhang ? 0.25 : 0.50;
        const b = isOverhang ? 0.18 : 0.62;

        positions.push(x0, y0, z0, x1, y1, z1, x2, y2, z2);
        normals.push(nx, ny, nz, nx, ny, nz, nx, ny, nz);
        colors.push(r, g, b, r, g, b, r, g, b);
      }
    }
  }

  const geometry = new THREE.BufferGeometry();
  if (positions.length > 0) {
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    geometry.computeBoundingBox();
    geometry.computeBoundingSphere();
  }
  return geometry;
}

export function getEmptyGeometryStats(): ModelGeometryStats {
  return {
    dimensions: { x: 0, y: 0, z: 0 },
    volumeMm3: 0,
    volumeCm3: 0,
    surfaceAreaMm2: 0,
    estimatedWeightGrams: 0,
    triangleCount: 0,
    vertexCount: 0,
    nonManifoldEdgeCount: 0,
    overhangRatio: 0,
    minWallThicknessMm: 0,
    isManifold: false,
    hasFiniteVertices: false,
    footprintAreaMm2: 0,
    heightToWidthRatio: 0,
    hasSteepOverhangs: false,
  };
}

/**
 * Computes exact volumetric stats, surface area, overhangs, and manifoldness
 */
export function analyzeBufferGeometry(
  geometry: THREE.BufferGeometry,
  densityGcm3: number = 1.24
): ModelGeometryStats {
  const posAttr = geometry.getAttribute('position');
  if (!posAttr || posAttr.count === 0) {
    return getEmptyGeometryStats();
  }

  geometry.computeBoundingBox();
  const box = geometry.boundingBox || new THREE.Box3();
  
  const dimX = Math.max(0, box.max.x - box.min.x);
  const dimY = Math.max(0, box.max.y - box.min.y);
  const dimZ = Math.max(0, box.max.z - box.min.z);

  let totalVolumeMm3 = 0;
  let totalSurfaceAreaMm2 = 0;
  let overhangAreaMm2 = 0;
  const triangleCount = posAttr.count / 3;

  const vA = new THREE.Vector3();
  const vB = new THREE.Vector3();
  const vC = new THREE.Vector3();
  const edgeMap = new Map<string, number>();

  for (let i = 0; i < posAttr.count; i += 3) {
    vA.fromBufferAttribute(posAttr, i);
    vB.fromBufferAttribute(posAttr, i + 1);
    vC.fromBufferAttribute(posAttr, i + 2);

    // Exact Signed tetrahedron volume: (vA . (vB x vC)) / 6
    const signedVol = vA.dot(new THREE.Vector3().crossVectors(vB, vC)) / 6.0;
    totalVolumeMm3 += signedVol;

    // Triangle Area
    const cross = new THREE.Vector3().subVectors(vB, vA).cross(new THREE.Vector3().subVectors(vC, vA));
    const triArea = cross.length() * 0.5;
    totalSurfaceAreaMm2 += triArea;

    // Normal calculation for overhangs
    if (triArea > 1e-6) {
      const normal = cross.clone().normalize();
      if (normal.z < -0.65) {
        overhangAreaMm2 += triArea;
      }
    }

    // Edge counting for manifold check
    const k1 = edgeKey(vA, vB);
    const k2 = edgeKey(vB, vC);
    const k3 = edgeKey(vC, vA);
    edgeMap.set(k1, (edgeMap.get(k1) || 0) + 1);
    edgeMap.set(k2, (edgeMap.get(k2) || 0) + 1);
    edgeMap.set(k3, (edgeMap.get(k3) || 0) + 1);
  }

  totalVolumeMm3 = Math.abs(totalVolumeMm3);
  const volumeCm3 = totalVolumeMm3 / 1000.0;

  let allFinite = true;
  for (let i = 0; i < posAttr.count; i++) {
    const x = posAttr.getX(i);
    const y = posAttr.getY(i);
    const z = posAttr.getZ(i);
    if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) {
      allFinite = false;
      break;
    }
  }

  // Strict Manifold check: in a closed triangular 2-manifold without boundary, every edge is shared by exactly 2 faces
  let nonManifoldEdges = 0;
  for (const count of edgeMap.values()) {
    if (count !== 2) {
      nonManifoldEdges++;
    }
  }

  const isManifold = allFinite && nonManifoldEdges === 0 && triangleCount >= 4 && totalVolumeMm3 > 1e-3;

  const overhangRatio = totalSurfaceAreaMm2 > 0 ? overhangAreaMm2 / totalSurfaceAreaMm2 : 0;
  const hasSteepOverhangs = overhangRatio > 0.03 || overhangAreaMm2 > 20;

  // Footprint approximation (bounding XY area)
  const footprintAreaMm2 = dimX * dimY;
  const heightToWidthRatio = dimZ / Math.max(0.1, Math.min(dimX, dimY));

  // Minimum wall thickness estimation based on bounding aspect
  const minWallThicknessMm = triangleCount > 0 ? Math.max(0.8, Math.min(dimX, dimY) * 0.08) : 0;

  const estimatedWeightGrams = Number((volumeCm3 * densityGcm3 * 0.55).toFixed(1));

  return {
    dimensions: {
      x: Number(dimX.toFixed(2)),
      y: Number(dimY.toFixed(2)),
      z: Number(dimZ.toFixed(2)),
    },
    volumeMm3: Number(totalVolumeMm3.toFixed(1)),
    volumeCm3: Number(volumeCm3.toFixed(2)),
    surfaceAreaMm2: Number(totalSurfaceAreaMm2.toFixed(1)),
    estimatedWeightGrams,
    triangleCount: Math.round(triangleCount),
    vertexCount: posAttr.count,
    nonManifoldEdgeCount: nonManifoldEdges,
    overhangRatio: Number(overhangRatio.toFixed(3)),
    minWallThicknessMm: Number(minWallThicknessMm.toFixed(2)),
    isManifold,
    hasFiniteVertices: allFinite,
    footprintAreaMm2: Number(footprintAreaMm2.toFixed(1)),
    heightToWidthRatio: Number(heightToWidthRatio.toFixed(2)),
    hasSteepOverhangs,
  };
}

function edgeKey(v1: THREE.Vector3, v2: THREE.Vector3): string {
  // Sort quantized coordinates to make edge strictly undirected
  const p1 = `${v1.x.toFixed(4)},${v1.y.toFixed(4)},${v1.z.toFixed(4)}`;
  const p2 = `${v2.x.toFixed(4)},${v2.y.toFixed(4)},${v2.z.toFixed(4)}`;
  return p1 < p2 ? `${p1}_${p2}` : `${p2}_${p1}`;
}

/**
 * Generates and downloads a binary STL file from a Three.js BufferGeometry
 */
export function exportBinarySTL(
  geometry: THREE.BufferGeometry,
  filename: string,
  scale: number = 1.0
): void {
  const posAttr = geometry.getAttribute('position');
  if (!posAttr || posAttr.count === 0) return;

  const triangles = posAttr.count / 3;
  const bufferSize = 80 + 4 + triangles * 50;
  const arrayBuffer = new ArrayBuffer(bufferSize);
  const dataView = new DataView(arrayBuffer);

  // 80-byte header
  const header = `KatPrint Binary STL - Scale: ${scale}x - Generator`;
  for (let i = 0; i < 80; i++) {
    dataView.setUint8(i, i < header.length ? header.charCodeAt(i) : 0);
  }

  // 4-byte uint32 triangle count
  dataView.setUint32(80, triangles, true);

  let offset = 84;
  const vA = new THREE.Vector3();
  const vB = new THREE.Vector3();
  const vC = new THREE.Vector3();
  const normal = new THREE.Vector3();

  for (let i = 0; i < posAttr.count; i += 3) {
    vA.fromBufferAttribute(posAttr, i).multiplyScalar(scale);
    vB.fromBufferAttribute(posAttr, i + 1).multiplyScalar(scale);
    vC.fromBufferAttribute(posAttr, i + 2).multiplyScalar(scale);

    // Compute Face Normal
    normal.subVectors(vB, vA).cross(new THREE.Vector3().subVectors(vC, vA)).normalize();

    // Normal (float32 x 3)
    dataView.setFloat32(offset, normal.x, true);
    dataView.setFloat32(offset + 4, normal.y, true);
    dataView.setFloat32(offset + 8, normal.z, true);
    offset += 12;

    // Vertex 1
    dataView.setFloat32(offset, vA.x, true);
    dataView.setFloat32(offset + 4, vA.y, true);
    dataView.setFloat32(offset + 8, vA.z, true);
    offset += 12;

    // Vertex 2
    dataView.setFloat32(offset, vB.x, true);
    dataView.setFloat32(offset + 4, vB.y, true);
    dataView.setFloat32(offset + 8, vB.z, true);
    offset += 12;

    // Vertex 3
    dataView.setFloat32(offset, vC.x, true);
    dataView.setFloat32(offset + 4, vC.y, true);
    dataView.setFloat32(offset + 8, vC.z, true);
    offset += 12;

    // 2-byte attribute byte count
    dataView.setUint16(offset, 0, true);
    offset += 2;
  }

  const blob = new Blob([arrayBuffer], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.stl') ? filename : `${filename}.stl`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Parses const declarations from JSCAD JavaScript code
 */
export function extractJSCADNamedConsts(code: string): { name: string; value: number }[] {
  const results: { name: string; value: number }[] = [];
  const seen = new Set<string>();
  // Match lines like: const height = 152.4; or const wall_thickness = 3;
  const regex = /const\s+([a-zA-Z0-9_]+)\s*=\s*([0-9]+(?:\.[0-9]+)?)\s*;/g;
  let match;
  while ((match = regex.exec(code)) !== null) {
    const name = match[1];
    const val = parseFloat(match[2]);
    if (!isNaN(val) && !seen.has(name)) {
      seen.add(name);
      results.push({ name, value: val });
    }
  }
  return results;
}

/**
 * Replaces named consts in JSCAD code with new user values
 */
export function updateJSCADNamedConsts(
  code: string,
  updatedValues: Record<string, number>
): string {
  let newCode = code;
  for (const [name, val] of Object.entries(updatedValues)) {
    const regex = new RegExp(`(const\\s+${name}\\s*=\\s*)([0-9]+(?:\\.[0-9]+)?)(\\s*;)`, 'g');
    newCode = newCode.replace(regex, `$1${val}$3`);
  }
  return newCode;
}
