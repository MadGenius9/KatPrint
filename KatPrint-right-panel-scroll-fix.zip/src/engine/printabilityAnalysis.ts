import { PrinterSpec } from '../types';

export interface PrintabilityOptions {
  maxOverhangDeg?: number; // default 45
  minWallMm?: number; // default 2 * nozzleMm = 0.8
  nozzleMm?: number; // default 0.4
  layerHeightMm?: number; // default 0.2
  bedSize?: { x: number; y: number; z: number };
}

export interface OverhangAnalysis {
  totalAreaMm2: number;
  ratio: number; // 0 - 1 of surface area
  worstAngleDeg: number;
  worstLocation: { x: number; y: number; z: number } | null;
  classification: 'none' | 'minor' | 'significant' | 'severe';
  requiresSupports: boolean;
  regionsCount: number;
}

export interface UnsupportedIsland {
  zHeightMm: number;
  areaMm2: number;
  centroid: { x: number; y: number };
  severity: 'blocking' | 'warning';
}

export interface ThinWallAnalysis {
  minWallThicknessMm: number;
  thinRegionCount: number;
  totalSamples: number;
  thinSampleRatio: number;
  thresholdMm: number;
  hasThinWalls: boolean;
}

export interface BridgeFeature {
  spanMm: number;
  status: 'safe' | 'risky' | 'failing';
  location: { x: number; y: number; z: number };
}

export interface FirstLayerAnalysis {
  areaMm2: number;
  contactRatio: number;
  needsBrim: boolean;
  needsRaft: boolean;
  status: 'optimal' | 'brim_recommended' | 'raft_recommended' | 'insufficient';
}

export interface SmallFeature {
  sizeMm: number;
  location: { x: number; y: number; z: number };
  description: string;
}

export interface PrintabilityRecommendation {
  severity: 'blocking' | 'warning' | 'info';
  message: string;
  action: 'add_supports' | 'reorient' | 'thicken_wall' | 'add_brim' | 'add_fillet' | 'redesign';
  autoFixable: boolean;
}

export interface SuggestedOrientation {
  rotationDeg: [number, number, number];
  reasoning: string;
  projectedScore: number;
}

export interface PrintabilityReport {
  score: number; // 0 - 100
  verdict: 'excellent' | 'good' | 'needs_attention' | 'problematic';
  overhangs: OverhangAnalysis;
  islands: UnsupportedIsland[];
  thinWalls: ThinWallAnalysis;
  bridges: BridgeFeature[];
  firstLayer: FirstLayerAnalysis;
  smallFeatures: SmallFeature[];
  recommendations: PrintabilityRecommendation[];
  suggestedOrientation: SuggestedOrientation | null;
}

interface Triangle3D {
  v0: [number, number, number];
  v1: [number, number, number];
  v2: [number, number, number];
  normal: [number, number, number];
  area: number;
  centroid: [number, number, number];
}

/**
 * Normalizes input polygon formats (JSCAD polygons, Three.js BufferGeometry, array of vertex arrays)
 * into a clean list of 3D triangles with precomputed normals and areas.
 */
export function extractTrianglesFromInput(input: any): Triangle3D[] {
  const triangles: Triangle3D[] = [];
  if (!input) return triangles;

  // Case 1: Three.js BufferGeometry
  if (input.isBufferGeometry || (input.attributes && input.attributes.position)) {
    const pos = input.attributes.position;
    const index = input.index;
    const count = index ? index.count : pos.count;

    for (let i = 0; i < count; i += 3) {
      const idx0 = index ? index.getX(i) : i;
      const idx1 = index ? index.getX(i + 1) : i + 1;
      const idx2 = index ? index.getX(i + 2) : i + 2;

      const v0: [number, number, number] = [pos.getX(idx0), pos.getY(idx0), pos.getZ(idx0)];
      const v1: [number, number, number] = [pos.getX(idx1), pos.getY(idx1), pos.getZ(idx1)];
      const v2: [number, number, number] = [pos.getX(idx2), pos.getY(idx2), pos.getZ(idx2)];

      const tri = createTriangle(v0, v1, v2);
      if (tri) triangles.push(tri);
    }
    return triangles;
  }

  // Case 2: Array of JSCAD solids or single solid
  const solids = Array.isArray(input) ? input : [input];

  for (const item of solids) {
    if (!item) continue;

    // Direct triangle with v0, v1, v2
    if (item.v0 && item.v1 && item.v2) {
      const tri = createTriangle(item.v0, item.v1, item.v2);
      if (tri) triangles.push(tri);
      continue;
    }

    // JSCAD solid with polygons or toPolygons()
    let polygons = item.polygons;
    if (!polygons && typeof item.toPolygons === 'function') {
      try {
        polygons = item.toPolygons();
      } catch {
        polygons = [];
      }
    }

    // If item itself is an array of polygons
    if (!polygons && Array.isArray(item)) {
      polygons = item;
    }

    if (Array.isArray(polygons)) {
      for (const poly of polygons) {
        const vertices = poly.vertices || poly;
        if (Array.isArray(vertices) && vertices.length >= 3) {
          const v0: [number, number, number] = [Number(vertices[0][0]) || 0, Number(vertices[0][1]) || 0, Number(vertices[0][2]) || 0];

          // Fan triangulation for polygons with > 3 vertices
          for (let i = 1; i < vertices.length - 1; i++) {
            const v1: [number, number, number] = [Number(vertices[i][0]) || 0, Number(vertices[i][1]) || 0, Number(vertices[i][2]) || 0];
            const v2: [number, number, number] = [Number(vertices[i + 1][0]) || 0, Number(vertices[i + 1][1]) || 0, Number(vertices[i + 1][2]) || 0];

            const tri = createTriangle(v0, v1, v2);
            if (tri) triangles.push(tri);
          }
        }
      }
    }
  }

  return triangles;
}

function createTriangle(
  v0: [number, number, number],
  v1: [number, number, number],
  v2: [number, number, number]
): Triangle3D | null {
  const ax = v1[0] - v0[0];
  const ay = v1[1] - v0[1];
  const az = v1[2] - v0[2];

  const bx = v2[0] - v0[0];
  const by = v2[1] - v0[1];
  const bz = v2[2] - v0[2];

  const cx = ay * bz - az * by;
  const cy = az * bx - ax * bz;
  const cz = ax * by - ay * bx;

  const len = Math.hypot(cx, cy, cz);
  if (len < 1e-7 || !Number.isFinite(len)) {
    return null; // Degenerate zero-area triangle
  }

  const normal: [number, number, number] = [cx / len, cy / len, cz / len];
  const area = 0.5 * len;
  const centroid: [number, number, number] = [
    (v0[0] + v1[0] + v2[0]) / 3,
    (v0[1] + v1[1] + v2[1]) / 3,
    (v0[2] + v1[2] + v2[2]) / 3,
  ];

  return { v0, v1, v2, normal, area, centroid };
}

/**
 * Main Deterministic Printability Analyzer
 */
export function analyzePrintability(
  polygons: any,
  options: PrintabilityOptions = {}
): PrintabilityReport {
  const maxOverhangDeg = options.maxOverhangDeg ?? 45;
  const nozzleMm = options.nozzleMm ?? 0.4;
  const minWallMm = options.minWallMm ?? nozzleMm * 2.0;
  const layerHeightMm = options.layerHeightMm ?? 0.2;
  const bedSize = options.bedSize ?? { x: 256, y: 256, z: 256 };

  const triangles = extractTrianglesFromInput(polygons);

  if (triangles.length === 0) {
    return createEmptyReport();
  }

  // Calculate overall bounding box and total surface area
  let minX = Infinity, minY = Infinity, minZ = Infinity;
  let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
  let totalSurfaceArea = 0;

  for (const tri of triangles) {
    totalSurfaceArea += tri.area;
    for (const v of [tri.v0, tri.v1, tri.v2]) {
      if (v[0] < minX) minX = v[0];
      if (v[0] > maxX) maxX = v[0];
      if (v[1] < minY) minY = v[1];
      if (v[1] > maxY) maxY = v[1];
      if (v[2] < minZ) minZ = v[2];
      if (v[2] > maxZ) maxZ = v[2];
    }
  }

  const dimX = Math.max(0, maxX - minX);
  const dimY = Math.max(0, maxY - minY);
  const dimZ = Math.max(0, maxZ - minZ);
  const footprintAreaMm2 = dimX * dimY;

  // -------------------------------------------------------------
  // 1. OVERHANG DETECTION
  // -------------------------------------------------------------
  // For each downward-facing polygon, compute angle with -Z
  // Normal pointing straight down is nz = -1 (0 deg from -Z, 90 deg overhang from vertical)
  // Normal with nz in [-0.7071, 0) is slope > 45 deg from vertical
  let totalOverhangArea = 0;
  let worstAngleDeg = 0;
  let worstLocation: { x: number; y: number; z: number } | null = null;
  let overhangCount = 0;

  // Overhang threshold angle from vertical Z axis: 45° (steep)
  // Slope angle from vertical = acos(|nz|) * 180 / PI
  // Or angle from -Z: acos(clamp(-nz, -1, 1)) * 180 / PI
  for (const tri of triangles) {
    const nz = tri.normal[2];
    // Downward facing if normal.z is negative (excluding tiny floating inaccuracies)
    if (nz < -0.02) {
      // Angle from vertical wall (0 = vertical wall, 90 = horizontal ceiling)
      const overhangAngleFromVertical = Math.asin(Math.min(1, Math.hypot(tri.normal[0], tri.normal[1]))) * (180 / Math.PI);
      // Angle with -Z (0 = horizontal ceiling pointing down, 90 = vertical)
      const angleFromMinusZ = Math.acos(Math.max(-1, Math.min(1, -nz))) * (180 / Math.PI);

      // A surface is an overhang if its angle from vertical exceeds maxOverhangDeg (default 45°)
      // (and it's not sitting directly on the bed plate Z <= 0.1mm)
      const isAboveBed = tri.centroid[2] > 0.2;
      const isSteep = (90 - angleFromMinusZ) > (90 - maxOverhangDeg) || (overhangAngleFromVertical > maxOverhangDeg && nz < -0.1);

      if (isAboveBed && isSteep) {
        totalOverhangArea += tri.area;
        overhangCount++;

        // Track the most severe overhang angle (closest to 90° from vertical / 0° from -Z)
        const severityAngle = 90 - angleFromMinusZ; // 90° = horizontal ceiling
        if (severityAngle > worstAngleDeg) {
          worstAngleDeg = severityAngle;
          worstLocation = {
            x: Number(tri.centroid[0].toFixed(2)),
            y: Number(tri.centroid[1].toFixed(2)),
            z: Number(tri.centroid[2].toFixed(2)),
          };
        }
      }
    }
  }

  const overhangRatio = totalSurfaceArea > 0 ? totalOverhangArea / totalSurfaceArea : 0;
  let overhangClassification: 'none' | 'minor' | 'significant' | 'severe' = 'none';

  if (totalOverhangArea < 1.0) {
    overhangClassification = 'none';
  } else if (overhangRatio < 0.05) {
    overhangClassification = 'minor';
  } else if (overhangRatio <= 0.20) {
    overhangClassification = 'significant';
  } else {
    overhangClassification = 'severe';
  }

  const overhangs: OverhangAnalysis = {
    totalAreaMm2: Number(totalOverhangArea.toFixed(2)),
    ratio: Number(overhangRatio.toFixed(3)),
    worstAngleDeg: Number(worstAngleDeg.toFixed(1)),
    worstLocation,
    classification: overhangClassification,
    requiresSupports: overhangClassification === 'significant' || overhangClassification === 'severe' || totalOverhangArea > 25,
    regionsCount: overhangCount,
  };

  // -------------------------------------------------------------
  // 2. UNSUPPORTED ISLANDS (Layer Slicing & Overlap Check)
  // -------------------------------------------------------------
  // Slices the mesh into vertical layers and checks for mid-air floating regions
  const islands: UnsupportedIsland[] = [];
  const sliceStep = Math.max(0.4, layerHeightMm * 2.0);
  const layerCount = Math.min(250, Math.ceil(dimZ / sliceStep));

  if (layerCount > 1 && dimZ > 1.0) {
    interface LayerRegion {
      z: number;
      minX: number;
      maxX: number;
      minY: number;
      maxY: number;
      area: number;
      cx: number;
      cy: number;
    }

    const layerRegions: LayerRegion[][] = [];

    for (let l = 0; l <= layerCount; l++) {
      const zPlane = minZ + l * sliceStep;
      const layerTris = triangles.filter((t) => {
        const triMinZ = Math.min(t.v0[2], t.v1[2], t.v2[2]);
        const triMaxZ = Math.max(t.v0[2], t.v1[2], t.v2[2]);
        return triMinZ <= zPlane + 0.1 && triMaxZ >= zPlane - 0.1;
      });

      if (layerTris.length === 0) {
        layerRegions.push([]);
        continue;
      }

      // Group into spatial clusters (regions)
      let lMinX = Infinity, lMaxX = -Infinity, lMinY = Infinity, lMaxY = -Infinity;
      let layerArea = 0;
      let sumX = 0, sumY = 0;

      for (const t of layerTris) {
        layerArea += t.area;
        sumX += t.centroid[0] * t.area;
        sumY += t.centroid[1] * t.area;
        for (const v of [t.v0, t.v1, t.v2]) {
          if (v[0] < lMinX) lMinX = v[0];
          if (v[0] > lMaxX) lMaxX = v[0];
          if (v[1] < lMinY) lMinY = v[1];
          if (v[1] > lMaxY) lMaxY = v[1];
        }
      }

      if (layerArea > 0.05) {
        const cx = sumX / layerArea;
        const cy = sumY / layerArea;
        layerRegions.push([
          {
            z: zPlane,
            minX: lMinX,
            maxX: lMaxX,
            minY: lMinY,
            maxY: lMaxY,
            area: layerArea,
            cx,
            cy,
          },
        ]);
      } else {
        layerRegions.push([]);
      }
    }

    // Check layer-to-layer support: if layer l has geometry that extends far outside layer l-1
    for (let l = 1; l < layerRegions.length; l++) {
      const currentRegions = layerRegions[l];
      const prevRegions = layerRegions[l - 1];

      for (const curr of currentRegions) {
        // Only flag mid-air starts above 0.8mm from the bed
        if (curr.z - minZ > 0.8) {
          let isSupported = false;

          for (const prev of prevRegions) {
            // Check bounding box overlap with 1.5mm margin for 45 deg slope tolerance
            const margin = sliceStep * 1.5;
            const overlapsX = curr.minX <= prev.maxX + margin && curr.maxX >= prev.minX - margin;
            const overlapsY = curr.minY <= prev.maxY + margin && curr.maxY >= prev.minY - margin;

            if (overlapsX && overlapsY) {
              isSupported = true;
              break;
            }
          }

          if (!isSupported && curr.area > 1.5) {
            const severity: 'blocking' | 'warning' = curr.area > 8.0 ? 'blocking' : 'warning';
            islands.push({
              zHeightMm: Number((curr.z - minZ).toFixed(2)),
              areaMm2: Number(curr.area.toFixed(2)),
              centroid: {
                x: Number(curr.cx.toFixed(2)),
                y: Number(curr.cy.toFixed(2)),
              },
              severity,
            });
          }
        }
      }
    }
  }

  // -------------------------------------------------------------
  // 3. THIN WALL DETECTION (Inward ray sampling from centroids)
  // -------------------------------------------------------------
  let minWallThicknessMm = Infinity;
  let thinRegionCount = 0;
  let totalSamples = 0;

  // Subsample triangles for fast ray-distance calculation (up to 120 samples)
  const sampleStep = Math.max(1, Math.floor(triangles.length / 100));
  const sampledTriangles: Triangle3D[] = [];
  for (let i = 0; i < triangles.length; i += sampleStep) {
    sampledTriangles.push(triangles[i]);
  }

  for (const sample of sampledTriangles) {
    totalSamples++;
    const rayOrigin = sample.centroid;
    const rayDir: [number, number, number] = [
      -sample.normal[0],
      -sample.normal[1],
      -sample.normal[2],
    ];

    // Find closest opposite face along ray
    let closestDist = Infinity;

    for (const other of triangles) {
      if (other === sample) continue;
      // Opposite faces should have opposing normals (dot product < 0)
      const dot = sample.normal[0] * other.normal[0] + sample.normal[1] * other.normal[1] + sample.normal[2] * other.normal[2];
      if (dot < -0.3) {
        // Fast ray-triangle distance approximation via centroid projection
        const toCentroid: [number, number, number] = [
          other.centroid[0] - rayOrigin[0],
          other.centroid[1] - rayOrigin[1],
          other.centroid[2] - rayOrigin[2],
        ];
        const projDist = toCentroid[0] * rayDir[0] + toCentroid[1] * rayDir[1] + toCentroid[2] * rayDir[2];

        if (projDist > 0.05 && projDist < closestDist) {
          // Check lateral deviation
          const perpX = toCentroid[0] - projDist * rayDir[0];
          const perpY = toCentroid[1] - projDist * rayDir[1];
          const perpZ = toCentroid[2] - projDist * rayDir[2];
          const perpDist = Math.hypot(perpX, perpY, perpZ);

          if (perpDist < Math.sqrt(other.area) * 1.2) {
            closestDist = projDist;
          }
        }
      }
    }

    if (closestDist < Infinity) {
      if (closestDist < minWallThicknessMm) {
        minWallThicknessMm = closestDist;
      }
      if (closestDist < minWallMm) {
        thinRegionCount++;
      }
    }
  }

  if (minWallThicknessMm === Infinity) {
    minWallThicknessMm = minWallMm * 1.5;
  }

  const thinSampleRatio = totalSamples > 0 ? thinRegionCount / totalSamples : 0;
  const thinWalls: ThinWallAnalysis = {
    minWallThicknessMm: Number(minWallThicknessMm.toFixed(2)),
    thinRegionCount,
    totalSamples,
    thinSampleRatio: Number(thinSampleRatio.toFixed(3)),
    thresholdMm: minWallMm,
    hasThinWalls: minWallThicknessMm < minWallMm && thinRegionCount > 0,
  };

  // -------------------------------------------------------------
  // 4. BRIDGE LENGTH (Unsupported Horizontal Spans)
  // -------------------------------------------------------------
  const bridges: BridgeFeature[] = [];
  // Find downward-facing horizontal faces (nz < -0.95) above base Z
  const ceilingTris = triangles.filter(
    (t) => t.normal[2] < -0.92 && t.centroid[2] - minZ > 1.0 && t.area > 2.0
  );

  if (ceilingTris.length > 0) {
    // Cluster ceiling triangles and measure their span
    let ceilingMinX = Infinity, ceilingMaxX = -Infinity;
    let ceilingMinY = Infinity, ceilingMaxY = -Infinity;
    let avgZ = 0;

    for (const c of ceilingTris) {
      avgZ += c.centroid[2];
      for (const v of [c.v0, c.v1, c.v2]) {
        if (v[0] < ceilingMinX) ceilingMinX = v[0];
        if (v[0] > ceilingMaxX) ceilingMaxX = v[0];
        if (v[1] < ceilingMinY) ceilingMinY = v[1];
        if (v[1] > ceilingMaxY) ceilingMaxY = v[1];
      }
    }
    avgZ /= ceilingTris.length;

    const spanX = Math.max(0, ceilingMaxX - ceilingMinX);
    const spanY = Math.max(0, ceilingMaxY - ceilingMinY);
    const maxSpan = Math.max(spanX, spanY);

    if (maxSpan > 4.0) {
      let status: 'safe' | 'risky' | 'failing' = 'safe';
      if (maxSpan > 50.0) {
        status = 'failing';
      } else if (maxSpan > 25.0) {
        status = 'risky';
      }

      bridges.push({
        spanMm: Number(maxSpan.toFixed(1)),
        status,
        location: {
          x: Number(((ceilingMinX + ceilingMaxX) / 2).toFixed(1)),
          y: Number(((ceilingMinY + ceilingMaxY) / 2).toFixed(1)),
          z: Number((avgZ - minZ).toFixed(1)),
        },
      });
    }
  }

  // -------------------------------------------------------------
  // 5. FIRST LAYER AREA & ADHESION
  // -------------------------------------------------------------
  let firstLayerArea = 0;
  for (const tri of triangles) {
    // Triangle touches bed if all its vertices have z within 0.15mm of minZ
    const isAtBed =
      Math.abs(tri.v0[2] - minZ) <= 0.15 &&
      Math.abs(tri.v1[2] - minZ) <= 0.15 &&
      Math.abs(tri.v2[2] - minZ) <= 0.15;

    // Normal facing down towards bed
    if (isAtBed && tri.normal[2] < -0.7) {
      firstLayerArea += tri.area;
    }
  }

  const contactRatio = footprintAreaMm2 > 0 ? firstLayerArea / footprintAreaMm2 : 0;
  let firstLayerStatus: 'optimal' | 'brim_recommended' | 'raft_recommended' | 'insufficient' = 'optimal';
  let needsBrim = false;
  let needsRaft = false;

  if (firstLayerArea < 50) {
    firstLayerStatus = 'insufficient';
    needsRaft = true;
    needsBrim = true;
  } else if (firstLayerArea < 100) {
    firstLayerStatus = 'raft_recommended';
    needsRaft = true;
    needsBrim = true;
  } else if (firstLayerArea < 400 || contactRatio < 0.15) {
    firstLayerStatus = 'brim_recommended';
    needsBrim = true;
  }

  const firstLayer: FirstLayerAnalysis = {
    areaMm2: Number(firstLayerArea.toFixed(1)),
    contactRatio: Number(contactRatio.toFixed(3)),
    needsBrim,
    needsRaft,
    status: firstLayerStatus,
  };

  // -------------------------------------------------------------
  // 6. SMALL FEATURE CHECK
  // -------------------------------------------------------------
  const smallFeatures: SmallFeature[] = [];
  // Detect edges significantly smaller than nozzleMm
  let minEdgeLength = Infinity;
  let smallEdgeCount = 0;

  for (const tri of triangles) {
    const e1 = Math.hypot(tri.v1[0] - tri.v0[0], tri.v1[1] - tri.v0[1], tri.v1[2] - tri.v0[2]);
    const e2 = Math.hypot(tri.v2[1] - tri.v1[1], tri.v2[1] - tri.v1[1], tri.v2[2] - tri.v1[2]);
    const e3 = Math.hypot(tri.v0[0] - tri.v2[0], tri.v0[1] - tri.v2[1], tri.v0[2] - tri.v2[2]);

    for (const e of [e1, e2, e3]) {
      if (e > 0.001) {
        if (e < minEdgeLength) minEdgeLength = e;
        if (e < nozzleMm * 0.7) {
          smallEdgeCount++;
        }
      }
    }
  }

  if (smallEdgeCount > 10 && minEdgeLength < nozzleMm) {
    smallFeatures.push({
      sizeMm: Number(minEdgeLength.toFixed(2)),
      location: {
        x: Number(((minX + maxX) / 2).toFixed(1)),
        y: Number(((minY + maxY) / 2).toFixed(1)),
        z: Number(((minZ + maxZ) / 2).toFixed(1)),
      },
      description: `Detected ${smallEdgeCount} mesh edges smaller than nozzle diameter (${nozzleMm}mm). Detail may be lost during slicing.`,
    });
  }

  // -------------------------------------------------------------
  // SCORE & VERDICT CALCULATION (0 - 100)
  // -------------------------------------------------------------
  let score = 100;

  // Deduct for islands
  const blockingIslands = islands.filter((i) => i.severity === 'blocking');
  score -= blockingIslands.length * 25;
  score -= (islands.length - blockingIslands.length) * 10;

  // Deduct for overhangs
  if (overhangClassification === 'severe') {
    score -= 25;
  } else if (overhangClassification === 'significant') {
    score -= 15;
  } else if (overhangClassification === 'minor') {
    score -= 5;
  }

  // Deduct for thin walls
  if (thinWalls.hasThinWalls) {
    if (thinWalls.minWallThicknessMm < minWallMm * 0.5) {
      score -= 20;
    } else {
      score -= 10;
    }
  }

  // Deduct for bridges
  const failingBridges = bridges.filter((b) => b.status === 'failing');
  const riskyBridges = bridges.filter((b) => b.status === 'risky');
  score -= failingBridges.length * 20;
  score -= riskyBridges.length * 8;

  // Deduct for first layer
  if (firstLayer.status === 'insufficient') {
    score -= 20;
  } else if (firstLayer.status === 'raft_recommended') {
    score -= 15;
  } else if (firstLayer.status === 'brim_recommended') {
    score -= 8;
  }

  // Deduct for small features
  if (smallFeatures.length > 0) {
    score -= 5;
  }

  score = Math.max(0, Math.min(100, Math.round(score)));

  let verdict: 'excellent' | 'good' | 'needs_attention' | 'problematic' = 'excellent';
  if (score >= 85) {
    verdict = 'excellent';
  } else if (score >= 70) {
    verdict = 'good';
  } else if (score >= 50) {
    verdict = 'needs_attention';
  } else {
    verdict = 'problematic';
  }

  // -------------------------------------------------------------
  // RECOMMENDATIONS GENERATION
  // -------------------------------------------------------------
  const recommendations: PrintabilityRecommendation[] = [];

  if (islands.length > 0) {
    recommendations.push({
      severity: blockingIslands.length > 0 ? 'blocking' : 'warning',
      message: `${islands.length} unsupported floating island(s) detected starting in mid-air (lowest at Z=${islands[0].zHeightMm}mm). Requires support scaffolding or reorientation.`,
      action: 'add_supports',
      autoFixable: true,
    });
  }

  if (overhangs.requiresSupports) {
    recommendations.push({
      severity: overhangClassification === 'severe' ? 'blocking' : 'warning',
      message: `${overhangs.totalAreaMm2}mm² (${(overhangs.ratio * 100).toFixed(1)}%) steep overhangs exceed ${maxOverhangDeg}°. Enable tree supports to prevent drooping.`,
      action: 'add_supports',
      autoFixable: true,
    });
  }

  if (thinWalls.hasThinWalls) {
    recommendations.push({
      severity: thinWalls.minWallThicknessMm < minWallMm * 0.5 ? 'blocking' : 'warning',
      message: `Wall thickness drops to ${thinWalls.minWallThicknessMm}mm (minimum recommended: ${minWallMm}mm for ${nozzleMm}mm nozzle). Thicken thin walls in CAD constants.`,
      action: 'thicken_wall',
      autoFixable: false,
    });
  }

  if (failingBridges.length > 0) {
    recommendations.push({
      severity: 'blocking',
      message: `Unsupported bridge span exceeds 50mm (${failingBridges[0].spanMm}mm at Z=${failingBridges[0].location.z}mm). Add support columns or redesign with a chamfer.`,
      action: 'add_fillet',
      autoFixable: false,
    });
  } else if (riskyBridges.length > 0) {
    recommendations.push({
      severity: 'warning',
      message: `Bridge span of ${riskyBridges[0].spanMm}mm is risky without high-flow cooling.`,
      action: 'add_supports',
      autoFixable: true,
    });
  }

  if (firstLayer.needsRaft) {
    recommendations.push({
      severity: 'blocking',
      message: `Bed contact area is only ${firstLayer.areaMm2}mm² (< 100mm²). Severe adhesion failure risk; generate a raft or reorient onto a larger flat face.`,
      action: 'add_brim',
      autoFixable: true,
    });
  } else if (firstLayer.needsBrim) {
    recommendations.push({
      severity: 'warning',
      message: `First layer contact area is ${firstLayer.areaMm2}mm² (< 400mm²). Enable a 5-8mm brim for reliable bed adhesion.`,
      action: 'add_brim',
      autoFixable: true,
    });
  }

  // -------------------------------------------------------------
  // ORIENTATION SUGGESTION (Test 6 axis + 45° rotations)
  // -------------------------------------------------------------
  const suggestedOrientation = computeOptimalOrientation(triangles, score, maxOverhangDeg, nozzleMm);

  if (suggestedOrientation && suggestedOrientation.projectedScore > score + 15) {
    recommendations.unshift({
      severity: 'info',
      message: `Optimal reorientation found (${suggestedOrientation.reasoning}): Projected score improves from ${score} to ${suggestedOrientation.projectedScore}/100.`,
      action: 'reorient',
      autoFixable: true,
    });
  }

  return {
    score,
    verdict,
    overhangs,
    islands,
    thinWalls,
    bridges,
    firstLayer,
    smallFeatures,
    recommendations,
    suggestedOrientation,
  };
}

/**
 * Tests 6 axis-aligned orientations + 45° X/Y rotations to find the best print orientation.
 */
function computeOptimalOrientation(
  triangles: Triangle3D[],
  currentScore: number,
  maxOverhangDeg: number,
  nozzleMm: number
): SuggestedOrientation | null {
  if (triangles.length === 0) return null;

  const candidateRotations: Array<{ rot: [number, number, number]; name: string }> = [
    { rot: [180, 0, 0], name: 'Upside Down (180° X)' },
    { rot: [90, 0, 0], name: 'Front Face Down (90° X)' },
    { rot: [-90, 0, 0], name: 'Back Face Down (-90° X)' },
    { rot: [0, 90, 0], name: 'Right Face Down (90° Y)' },
    { rot: [0, -90, 0], name: 'Left Face Down (-90° Y)' },
    { rot: [45, 0, 0], name: '45° Tilted X' },
    { rot: [-45, 0, 0], name: '-45° Tilted X' },
    { rot: [0, 45, 0], name: '45° Tilted Y' },
    { rot: [0, -45, 0], name: '-45° Tilted Y' },
  ];

  let bestOrientation: SuggestedOrientation | null = null;
  let highestScore = currentScore;

  for (const cand of candidateRotations) {
    const rx = (cand.rot[0] * Math.PI) / 180;
    const ry = (cand.rot[1] * Math.PI) / 180;
    const rz = (cand.rot[2] * Math.PI) / 180;

    const cosX = Math.cos(rx), sinX = Math.sin(rx);
    const cosY = Math.cos(ry), sinY = Math.sin(ry);
    const cosZ = Math.cos(rz), sinZ = Math.sin(rz);

    const rotateVec = (v: [number, number, number]): [number, number, number] => {
      // Rotate X
      let y1 = v[1] * cosX - v[2] * sinX;
      let z1 = v[1] * sinX + v[2] * cosX;
      let x1 = v[0];

      // Rotate Y
      let x2 = x1 * cosY + z1 * sinY;
      let z2 = -x1 * sinY + z1 * cosY;
      let y2 = y1;

      // Rotate Z
      let x3 = x2 * cosZ - y2 * sinZ;
      let y3 = x2 * sinZ + y2 * cosZ;
      let z3 = z2;

      return [x3, y3, z3];
    };

    let minRotZ = Infinity;
    const rotatedTriangles: Triangle3D[] = [];

    for (const tri of triangles) {
      const v0 = rotateVec(tri.v0);
      const v1 = rotateVec(tri.v1);
      const v2 = rotateVec(tri.v2);
      const normal = rotateVec(tri.normal);

      if (v0[2] < minRotZ) minRotZ = v0[2];
      if (v1[2] < minRotZ) minRotZ = v1[2];
      if (v2[2] < minRotZ) minRotZ = v2[2];

      const centroid: [number, number, number] = [
        (v0[0] + v1[0] + v2[0]) / 3,
        (v0[1] + v1[1] + v2[1]) / 3,
        (v0[2] + v1[2] + v2[2]) / 3,
      ];

      rotatedTriangles.push({
        v0,
        v1,
        v2,
        normal,
        area: tri.area,
        centroid,
      });
    }

    // Fast evaluation of candidate:
    // 1. Overhang area
    let candidateOverhangArea = 0;
    let candidateFirstLayerArea = 0;
    let candidateSurfaceArea = 0;

    for (const tri of rotatedTriangles) {
      candidateSurfaceArea += tri.area;
      const nz = tri.normal[2];

      // First layer check (near bed Z)
      const isAtBed =
        Math.abs(tri.v0[2] - minRotZ) <= 0.15 &&
        Math.abs(tri.v1[2] - minRotZ) <= 0.15 &&
        Math.abs(tri.v2[2] - minRotZ) <= 0.15;

      if (isAtBed && nz < -0.7) {
        candidateFirstLayerArea += tri.area;
      }

      // Overhang check
      if (nz < -0.02 && tri.centroid[2] - minRotZ > 0.2) {
        const overhangAngleFromVertical = Math.asin(Math.min(1, Math.hypot(tri.normal[0], tri.normal[1]))) * (180 / Math.PI);
        if (overhangAngleFromVertical > maxOverhangDeg && nz < -0.1) {
          candidateOverhangArea += tri.area;
        }
      }
    }

    let candScore = 100;
    const overhangRatio = candidateSurfaceArea > 0 ? candidateOverhangArea / candidateSurfaceArea : 0;
    if (overhangRatio > 0.2) candScore -= 25;
    else if (overhangRatio > 0.05) candScore -= 15;
    else if (overhangRatio > 0) candScore -= 5;

    if (candidateFirstLayerArea < 100) candScore -= 20;
    else if (candidateFirstLayerArea < 400) candScore -= 8;

    if (candScore > highestScore && candScore >= currentScore + 15) {
      highestScore = candScore;
      const reasons: string[] = [];
      if (candidateFirstLayerArea > 400) reasons.push(`maximizes bed adhesion (${candidateFirstLayerArea.toFixed(0)}mm² contact)`);
      if (overhangRatio < 0.05) reasons.push('minimizes overhangs');
      const reasoning = `${cand.name} ${reasons.length > 0 ? reasons.join(' & ') : 'reduces required supports'}`;

      bestOrientation = {
        rotationDeg: cand.rot,
        reasoning,
        projectedScore: candScore,
      };
    }
  }

  return bestOrientation;
}

function createEmptyReport(): PrintabilityReport {
  return {
    score: 0,
    verdict: 'problematic',
    overhangs: {
      totalAreaMm2: 0,
      ratio: 0,
      worstAngleDeg: 0,
      worstLocation: null,
      classification: 'none',
      requiresSupports: false,
      regionsCount: 0,
    },
    islands: [],
    thinWalls: {
      minWallThicknessMm: 0,
      thinRegionCount: 0,
      totalSamples: 0,
      thinSampleRatio: 0,
      thresholdMm: 0.8,
      hasThinWalls: false,
    },
    bridges: [],
    firstLayer: {
      areaMm2: 0,
      contactRatio: 0,
      needsBrim: true,
      needsRaft: true,
      status: 'insufficient',
    },
    smallFeatures: [],
    recommendations: [
      {
        severity: 'blocking',
        message: 'No solid geometry provided for printability evaluation.',
        action: 'redesign',
        autoFixable: false,
      },
    ],
    suggestedOrientation: null,
  };
}
