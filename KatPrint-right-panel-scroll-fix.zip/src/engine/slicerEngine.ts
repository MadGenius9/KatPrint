import {
  PrinterSpec,
  FilamentSpec,
  ModelGeometryStats,
  SlicerSettings,
  PrinterFitResult,
  ExecutedModelPart,
  PrintabilityReport,
} from '../types';
import { getPhysicalPieceCount, hasMultiplePhysicalPieces } from './stlExporter';

export function computePrinterFit(
  geometry: ModelGeometryStats,
  printer: PrinterSpec,
  scaleFactor: number,
  parts?: ExecutedModelPart[]
): PrinterFitResult {
  const scaledX = geometry.dimensions.x * scaleFactor;
  const scaledY = geometry.dimensions.y * scaleFactor;
  const scaledZ = geometry.dimensions.z * scaleFactor;

  const maxVolume = printer.buildVolume;
  const overflowX = Math.max(0, scaledX - maxVolume.x);
  const overflowY = Math.max(0, scaledY - maxVolume.y);
  const overflowZ = Math.max(0, scaledZ - maxVolume.z);

  const fitsStandard = overflowX === 0 && overflowY === 0 && overflowZ === 0;

  // Check 45 degree rotation on bed
  const bedDiagonal = Math.hypot(maxVolume.x, maxVolume.y);
  const modelFootprintDiagonal = Math.hypot(scaledX, scaledY);
  
  const rot45X = (scaledX + scaledY) * Math.SQRT1_2;
  const rot45Y = (scaledX + scaledY) * Math.SQRT1_2;
  const fitsRotated45 =
    !fitsStandard &&
    overflowZ === 0 &&
    (modelFootprintDiagonal <= bedDiagonal * 0.96 ||
      (rot45X <= maxVolume.x && rot45Y <= maxVolume.y));

  const scaledMinWall = geometry.minWallThicknessMm * scaleFactor;
  const minRequiredWall = 2 * printer.nozzleDiameter;
  const thinFeatureWarning = scaledMinWall > 0 && scaledMinWall < minRequiredWall;

  // If multi-part design, check whether EACH individual piece fits
  if (parts && hasMultiplePhysicalPieces(parts)) {
    let allPartsFit = true;
    let anyPartRequiresRotation = false;
    const oversizedParts: string[] = [];

    for (const part of parts) {
      const pDim = part.stats?.dimensions || { x: 0, y: 0, z: 0 };
      const px = pDim.x * scaleFactor;
      const py = pDim.y * scaleFactor;
      const pz = pDim.z * scaleFactor;

      const pOx = Math.max(0, px - maxVolume.x);
      const pOy = Math.max(0, py - maxVolume.y);
      const pOz = Math.max(0, pz - maxVolume.z);

      const pFitsStandard = pOx === 0 && pOy === 0 && pOz === 0;
      if (!pFitsStandard) {
        const pDiag = Math.hypot(px, py);
        const pRotX = (px + py) * Math.SQRT1_2;
        const pRotY = (px + py) * Math.SQRT1_2;
        const pFitsRot = pOz === 0 && (pDiag <= bedDiagonal * 0.96 || (pRotX <= maxVolume.x && pRotY <= maxVolume.y) || (py <= maxVolume.x && px <= maxVolume.y));
        if (pFitsRot) {
          anyPartRequiresRotation = true;
        } else {
          allPartsFit = false;
          oversizedParts.push(part.name || part.id);
        }
      }
    }

    if (allPartsFit) {
      if (!fitsStandard && !fitsRotated45) {
        return {
          status: 'green',
          message: `Assembly (${scaledX.toFixed(0)}×${scaledY.toFixed(0)} mm) is larger than the printer, but all ${getPhysicalPieceCount(parts)} printable pieces fit individually.`,
          details: [`Each of the ${getPhysicalPieceCount(parts)} separate pieces fits within the ${maxVolume.x}×${maxVolume.y}×${maxVolume.z} mm build volume.`],
          fitsStandard: true,
          fitsRotated45: anyPartRequiresRotation,
          axisOverflow: { x: 0, y: 0, z: 0 },
          thinFeatureWarning,
          minWallSizeMm: scaledMinWall,
        };
      } else {
        return {
          status: anyPartRequiresRotation ? 'yellow' : 'green',
          message: anyPartRequiresRotation
            ? `All ${getPhysicalPieceCount(parts)} printable pieces fit the build volume (some may require diagonal rotation).`
            : `All ${getPhysicalPieceCount(parts)} printable pieces fit within the build volume.`,
          details: [],
          fitsStandard: true,
          fitsRotated45: anyPartRequiresRotation,
          axisOverflow: { x: 0, y: 0, z: 0 },
          thinFeatureWarning,
          minWallSizeMm: scaledMinWall,
        };
      }
    } else {
      return {
        status: 'red',
        message: `The following pieces exceed the build volume: ${oversizedParts.join(', ')}.`,
        details: [`Parts [${oversizedParts.join(', ')}] exceed the ${printer.name} build envelope (${maxVolume.x}×${maxVolume.y}×${maxVolume.z} mm).`],
        fitsStandard: false,
        fitsRotated45: false,
        axisOverflow: { x: overflowX, y: overflowY, z: overflowZ },
        thinFeatureWarning,
        minWallSizeMm: scaledMinWall,
      };
    }
  }

  const details: string[] = [];
  if (overflowX > 0) details.push(`X axis by +${overflowX.toFixed(1)} mm (max ${maxVolume.x} mm)`);
  if (overflowY > 0) details.push(`Y axis by +${overflowY.toFixed(1)} mm (max ${maxVolume.y} mm)`);
  if (overflowZ > 0) details.push(`Z axis by +${overflowZ.toFixed(1)} mm (max ${maxVolume.z} mm)`);

  let status: 'green' | 'yellow' | 'red' = 'green';
  let message = 'Fits build plate perfectly in standard orientation.';

  if (!fitsStandard) {
    if (fitsRotated45) {
      status = 'yellow';
      message = 'Exceeds orthogonal bed bounds, but fits rotated 45° diagonally.';
    } else {
      status = 'red';
      message = `Exceeds build volume on ${details.join(', ')}.`;
    }
  }

  return {
    status,
    message,
    details,
    fitsStandard,
    fitsRotated45,
    axisOverflow: { x: overflowX, y: overflowY, z: overflowZ },
    thinFeatureWarning,
    minWallSizeMm: scaledMinWall,
  };
}

export function computeSlicerSettings(
  geometry: ModelGeometryStats,
  printer: PrinterSpec,
  filament: FilamentSpec,
  scaleFactor: number,
  mustHoldLiquid: boolean,
  printabilityReport?: PrintabilityReport
): SlicerSettings {
  const scaledX = geometry.dimensions.x * scaleFactor;
  const scaledY = geometry.dimensions.y * scaleFactor;
  const scaledZ = geometry.dimensions.z * scaleFactor;
  const scaledVolumeCm3 = geometry.volumeCm3 * Math.pow(scaleFactor, 3);
  const scaledFootprint = geometry.footprintAreaMm2 * Math.pow(scaleFactor, 2);

  // --- LAYER 1: Filament Base Defaults ---
  const [minNozzle, maxNozzle] = filament.nozzleTempRange;
  const [minBed, maxBed] = filament.bedTempRange;
  let nozzleTemp = Math.round((minNozzle + maxNozzle) / 2);
  let bedTemp = Math.round((minBed + maxBed) / 2);
  let fanPercent = filament.fanPercent;

  // --- LAYER 2: Geometric & Functional Adjustments ---
  // Aspect ratio height vs width
  const minFootprintDim = Math.max(1, Math.min(scaledX, scaledY));
  const heightRatio = scaledZ / minFootprintDim;

  // Brim logic: small footprint, high aspect ratio, or warp risk, or printability report first layer adhesion
  let brimEnabled = false;
  let brimWidthMm = 0;
  if (
    printabilityReport?.firstLayer?.needsBrim ||
    printabilityReport?.firstLayer?.needsRaft ||
    scaledFootprint < 800 ||
    heightRatio > 2.0 ||
    filament.warpRisk === 'High' ||
    filament.warpRisk === 'Extreme'
  ) {
    brimEnabled = true;
    if (printabilityReport?.firstLayer?.needsRaft || printabilityReport?.firstLayer?.status === 'insufficient') {
      brimWidthMm = 12;
    } else if (filament.warpRisk === 'Extreme') {
      brimWidthMm = 10;
    } else if (filament.warpRisk === 'High' || printabilityReport?.firstLayer?.status === 'raft_recommended') {
      brimWidthMm = 8;
    } else {
      brimWidthMm = 5;
    }
  }

  // Supports logic: overhang angles > 45 deg or unsupported islands
  const hasReportOverhangs = Boolean(
    printabilityReport?.overhangs?.requiresSupports ||
    (printabilityReport?.islands && printabilityReport.islands.length > 0)
  );
  const supportsEnabled = hasReportOverhangs || geometry.hasSteepOverhangs || geometry.overhangRatio > 0.05;
  const supportType: 'Tree / Organic' | 'Standard Grid' | 'None' = supportsEnabled
    ? 'Tree / Organic'
    : 'None';
  const supportAngleThreshold = 45;

  // Watertight / Liquid Holding & Thin Wall Rules
  let wallLoops = 3;
  if (printabilityReport?.thinWalls?.hasThinWalls) {
    wallLoops = Math.max(4, wallLoops);
  }
  let topLayers = 4;
  let bottomLayers = 4;
  let infillPercent = 15;
  let infillPattern: 'Gyroid' | 'Grid' | 'Honeycomb' | 'Adaptive Cubic' = 'Gyroid';
  let flowCompensation = 1.0;
  let nominalLayerHeight = 0.20;

  if (printabilityReport?.overhangs?.classification === 'severe') {
    nominalLayerHeight = 0.16; // Finer layer height for steep overhang stepping
  }

  if (mustHoldLiquid) {
    wallLoops = Math.max(4, wallLoops);
    topLayers = Math.max(5, topLayers);
    bottomLayers = Math.max(5, bottomLayers);
    nominalLayerHeight = 0.20; // Fixed standard layer for consistent extrusion bead
    infillPercent = Math.max(25, infillPercent);
    infillPattern = 'Gyroid'; // Best isotropic watertight cavity structure
    flowCompensation = 1.03; // Slight positive overlap for gap closure
    // Push nozzle temp to upper 85% of range for superior inter-layer thermal welding
    nozzleTemp = Math.round(minNozzle + (maxNozzle - minNozzle) * 0.85);
    // Reduce fan slightly to allow molecular chain inter-diffusion
    fanPercent = Math.max(10, Math.round(fanPercent * 0.75));
  }

  // --- LAYER 3: Printer Constraints & Kinematics Clamping ---
  // Clamp layer height between 25% and 75% of nozzle diameter
  const minLayerHeight = Number((printer.nozzleDiameter * 0.25).toFixed(2));
  const maxLayerHeight = Number((printer.nozzleDiameter * 0.75).toFixed(2));
  const layerHeight = Math.max(minLayerHeight, Math.min(maxLayerHeight, nominalLayerHeight));
  const firstLayerHeight = Number(Math.min(maxLayerHeight, layerHeight * 1.2).toFixed(2));

  // Volumetric flow speed capping
  const effectiveMaxVolFlow = Math.min(printer.maxVolumetricFlow, filament.maxVolumetricFlow);
  const lineWidth = printer.nozzleDiameter * 1.125; // standard extrusion line width
  const maxLinearSpeed = effectiveMaxVolFlow / (layerHeight * lineWidth); // mm/s

  // Nominal speeds based on machine type and geometry stability
  let baseSpeed = printer.name.includes('Bambu') ? 220 : 120;
  if (filament.id === 'tpu-95a') {
    baseSpeed = 35; // TPU is restricted to low speeds
  }

  // Speed reduction for tall skinny parts (vibration mitigation)
  if (heightRatio > 2.5) {
    baseSpeed *= 0.75;
  }

  const infillSpeed = Math.round(Math.min(baseSpeed, maxLinearSpeed));
  const innerWallSpeed = Math.round(Math.min(baseSpeed * 0.8, maxLinearSpeed * 0.85));
  const outerWallSpeed = Math.round(Math.min(baseSpeed * 0.5, maxLinearSpeed * 0.6));
  const firstLayerSpeed = Math.round(Math.min(30, maxLinearSpeed * 0.3));

  // Retraction defaults
  let retractionDistance = 0.8; // mm
  let retractionSpeed = 35; // mm/s
  if (printer.driveType === 'bowden') {
    retractionDistance = 5.0;
    retractionSpeed = 45;
  }
  if (filament.id === 'tpu-95a') {
    retractionDistance = printer.driveType === 'bowden' ? 1.5 : 0.4;
    retractionSpeed = 18;
  }

  // First layer temp +5C
  const nozzleTempFirstLayer = nozzleTemp + 5;
  const nozzleTempOtherLayers = nozzleTemp;

  // Material & Time Estimations
  const infillDensityFactor = infillPercent / 100;
  const shellFraction = Math.min(0.85, 0.25 + (wallLoops * 0.05));
  const effectiveDensityRatio = shellFraction + (1 - shellFraction) * infillDensityFactor;
  const estimatedMaterialGrams = Number(
    (scaledVolumeCm3 * filament.densityGcm3 * effectiveDensityRatio).toFixed(1)
  );

  // 1.75mm filament weight per meter
  // Area = pi * (0.875)^2 = 2.405 mm2 = 0.02405 cm2
  // Grams per meter = 0.02405 * 100 * density = 2.405 * density
  const gramsPerMeter = 2.405 * filament.densityGcm3;
  const estimatedMaterialMeters = Number(
    (estimatedMaterialGrams / Math.max(0.1, gramsPerMeter)).toFixed(2)
  );

  // Estimated Print Time Calculation (layer changes + extruded path + travel)
  const totalLayers = Math.max(1, Math.ceil(scaledZ / layerHeight));
  const totalExtrusionMm3 = scaledVolumeCm3 * 1000 * effectiveDensityRatio;
  const averageFlowMm3S = Math.min(effectiveMaxVolFlow * 0.65, 14);
  const rawExtrudeSeconds = totalExtrusionMm3 / Math.max(1, averageFlowMm3S);
  const layerChangeOverheadSeconds = totalLayers * 2.5;
  const warmUpOverheadSeconds = 120; // 2 min preheat & calibration

  const totalSeconds = rawExtrudeSeconds + layerChangeOverheadSeconds + warmUpOverheadSeconds;
  const estimatedPrintTimeMinutes = Math.max(8, Math.round(totalSeconds / 60));

  return {
    nozzleTempFirstLayer,
    nozzleTempOtherLayers,
    bedTemp,
    layerHeight,
    firstLayerHeight,
    wallLoops,
    topLayers,
    bottomLayers,
    infillPercent,
    infillPattern,
    outerWallSpeed,
    innerWallSpeed,
    infillSpeed,
    firstLayerSpeed,
    fanPercent,
    retractionDistance,
    retractionSpeed,
    supportsEnabled,
    supportType,
    supportAngleThreshold,
    brimEnabled,
    brimWidthMm,
    flowCompensation,
    estimatedPrintTimeMinutes,
    estimatedMaterialGrams,
    estimatedMaterialMeters,
  };
}

export function generateSlicerOverridesText(
  settings: SlicerSettings,
  printer: PrinterSpec,
  filament: FilamentSpec
): string {
  return `; ==========================================
; KATPRINT - SLICER OVERRIDE PROFILE
; Compatible with: OrcaSlicer, Bambu Studio, PrusaSlicer
; Target: ${printer.name} | Filament: ${filament.name}
; ==========================================

; [Thermal & Extrusion]
nozzle_temperature_initial_layer = ${settings.nozzleTempFirstLayer}
nozzle_temperature = ${settings.nozzleTempOtherLayers}
bed_temperature = ${settings.bedTemp}
fan_cooling_percentage = ${settings.fanPercent}
extrusion_multiplier = ${settings.flowCompensation.toFixed(2)}

; [Layer Heights & Shells]
layer_height = ${settings.layerHeight.toFixed(2)}
first_layer_height = ${settings.firstLayerHeight.toFixed(2)}
wall_loops = ${settings.wallLoops}
top_solid_layers = ${settings.topLayers}
bottom_solid_layers = ${settings.bottomLayers}

; [Infill]
sparse_infill_density = ${settings.infillPercent}%
sparse_infill_pattern = ${settings.infillPattern.toLowerCase()}

; [Speed Settings (mm/s)]
outer_wall_speed = ${settings.outerWallSpeed}
inner_wall_speed = ${settings.innerWallSpeed}
sparse_infill_speed = ${settings.infillSpeed}
initial_layer_speed = ${settings.firstLayerSpeed}

; [Retraction & Dynamics]
retraction_length = ${settings.retractionDistance.toFixed(1)}
retraction_speed = ${settings.retractionSpeed}

; [Adhesion & Supports]
enable_support = ${settings.supportsEnabled ? '1' : '0'}
support_type = ${settings.supportsEnabled ? 'tree' : 'none'}
support_threshold_angle = ${settings.supportAngleThreshold}
brim_type = ${settings.brimEnabled ? 'outer_only' : 'no_brim'}
brim_width = ${settings.brimWidthMm}
`;
}

export function generateGCode(options: {
  settings: SlicerSettings;
  geometryStats: ModelGeometryStats;
  printer: PrinterSpec;
  filament: FilamentSpec;
  modelName: string;
  mustHoldLiquid: boolean;
}): string {
  const { settings, printer, filament, modelName, mustHoldLiquid } = options;
  const timestamp = new Date().toISOString();

  return `; =========================================================================
; KATPRINT 3D G-CODE GENERATOR
; Model: ${modelName}
; Generated: ${timestamp}
; Printer: ${printer.name} (${printer.buildVolume.x}x${printer.buildVolume.y}x${printer.buildVolume.z}mm)
; Filament: ${filament.name} (${filament.densityGcm3} g/cm3)
; Watertight Mode: ${mustHoldLiquid ? 'ENABLED' : 'DISABLED'}
; =========================================================================

; --- START G-CODE ---
G28 ; Home all axes
G90 ; Absolute positioning
M83 ; Relative extruder mode
M104 S${settings.nozzleTempFirstLayer} ; Set nozzle temp
M140 S${settings.bedTemp} ; Set bed temp
M190 S${settings.bedTemp} ; Wait for bed temp
M109 S${settings.nozzleTempFirstLayer} ; Wait for nozzle temp

; Prime line
G1 Z2.0 F3000 ; Move Z Axis up
G1 X10.1 Y20 Z0.28 F5000.0 ; Move to start position
G1 X10.1 Y200.0 Z0.28 F1500.0 E15 ; Draw the first line
G1 X10.4 Y200.0 Z0.28 F5000.0 ; Move to side a little
G1 X10.4 Y20 Z0.28 F1500.0 E30 ; Draw the second line
G92 E0 ; Reset Extruder
G1 Z2.0 F3000 ; Move Z Axis up
G1 X15 Y20 Z0.3 F5000.0 ; Move over to prevent blob squish

; --- PRINT PARAMETERS ---
; Layer Height: ${settings.layerHeight} mm (First Layer: ${settings.firstLayerHeight} mm)
; Wall Loops: ${settings.wallLoops}
; Infill: ${settings.infillPercent}% ${settings.infillPattern}
; Fan Speed: ${settings.fanPercent}%
; Flow Compensation: ${settings.flowCompensation}x

; --- SLICER OVERRIDE CONFIG BLOCK ---
${generateSlicerOverridesText(settings, printer, filament)}

; --- END G-CODE ---
M140 S0 ; Turn off bed
M104 S0 ; Turn off extruder
M106 S0 ; Turn off cooling fan
G91 ; Relative positioning
G1 Z10 F3000 ; Lift nozzle 10mm
G90 ; Absolute positioning
G1 X0 Y${printer.buildVolume.y - 10} F3000 ; Present print
M84 ; Disable stepper motors
; Finished KatPrint G-code script.
`;
}

export function exportGCodeFile(options: {
  settings: SlicerSettings;
  geometryStats: ModelGeometryStats;
  printer: PrinterSpec;
  filament: FilamentSpec;
  modelName: string;
  mustHoldLiquid: boolean;
}): void {
  const gcode = generateGCode(options);
  const blob = new Blob([gcode], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const safeName = options.modelName.toLowerCase().replace(/[^a-z0-9]+/g, '_') || 'model';
  a.href = url;
  a.download = `${safeName}_${options.printer.id}_${options.filament.id}.gcode`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
