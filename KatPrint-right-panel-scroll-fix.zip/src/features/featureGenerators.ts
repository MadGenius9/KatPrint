import { FeatureType, SemanticFeature } from './featureTypes';

/**
 * Standard deterministic parametric JSCAD feature generators.
 * Provides helper code snippets and geometric generators for standard mechanical features.
 */

export const RESERVED_BUILDER_NAMES = [
  'createThroughHole',
  'createCounterboreHole',
  'createCountersinkHole',
  'createElongatedSlot',
  'createCableOpening',
  'createMountingBoss',
  'createReinforcingRib',
  'createCornerGusset',
  'createLinearHolePattern',
  'createCircularHolePattern',
  'createDrainageSlotPattern',
  'createPCBStandoff',
  'createMetricThread',
  'createHeatSetInsertBoss',
  'createSnapFitCantilever',
  'createLivingHinge',
  'createLidRebate',
  'createChamferedBox',
  'createFilletedEdge',
  'createTextEmboss',
  'createHoneycombShell',
  'createVesaPattern',
  'createGridfinityBase',
  'createKeyholeSlot',
  'createPressFitBore',
] as const;

export type ReservedBuilderName = (typeof RESERVED_BUILDER_NAMES)[number];

export interface FeatureBuilderSpec {
  builderName: ReservedBuilderName;
  description: string;
  signature: string;
  parameters: string[];
  exampleCall: string;
}

export const FEATURE_BUILDER_REGISTRY: Record<string, FeatureBuilderSpec> = {
  HOLE: {
    builderName: 'createThroughHole',
    description: 'Creates a cylindrical through hole with lead-in depth margin',
    signature: 'createThroughHole(diameter, depth, posX = 0, posY = 0, posZ = 0)',
    parameters: ['diameter', 'depth', 'posX', 'posY', 'posZ'],
    exampleCall: 'createThroughHole(mountingHoleDiameter, plateThickness, holeX, holeY, 0)',
  },
  COUNTERSINK: {
    builderName: 'createCountersinkHole',
    description: 'Creates a standard 90° countersunk screw hole',
    signature: 'createCountersinkHole(holeDiameter, headDiameter, totalDepth, angleDeg = 90, posX = 0, posY = 0, posZ = 0)',
    parameters: ['holeDiameter', 'headDiameter', 'totalDepth', 'angleDeg', 'posX', 'posY', 'posZ'],
    exampleCall: 'createCountersinkHole(screwHoleDiameter, screwHeadDiameter, plateThickness, 90, holeX, holeY, 0)',
  },
  COUNTERBORE: {
    builderName: 'createCounterboreHole',
    description: 'Creates a cylindrical counterbore hole for socket-head cap screws',
    signature: 'createCounterboreHole(holeDiameter, boreDiameter, boreDepth, totalDepth, posX = 0, posY = 0, posZ = 0)',
    parameters: ['holeDiameter', 'boreDiameter', 'boreDepth', 'totalDepth', 'posX', 'posY', 'posZ'],
    exampleCall: 'createCounterboreHole(holeDiameter, counterboreDiameter, counterboreDepth, totalDepth, holeX, holeY, 0)',
  },
  SLOT: {
    builderName: 'createElongatedSlot',
    description: 'Creates an elongated stadium slot with rounded ends',
    signature: 'createElongatedSlot(width, length, depth, posX = 0, posY = 0, posZ = 0, rotateDeg = 0)',
    parameters: ['width', 'length', 'depth', 'posX', 'posY', 'posZ', 'rotateDeg'],
    exampleCall: 'createElongatedSlot(slotWidth, slotLength, plateThickness, slotX, slotY, 0, slotAngle)',
  },
  CABLE_OPENING: {
    builderName: 'createCableOpening',
    description: 'Creates a strain-relief / pass-through opening with radiused corners',
    signature: 'createCableOpening(width, depth, height, posX = 0, posY = 0, posZ = 0)',
    parameters: ['width', 'depth', 'height', 'posX', 'posY', 'posZ'],
    exampleCall: 'createCableOpening(cableSlotWidth, cableSlotDepth, plateThickness, cableSlotX, cableSlotY, 0)',
  },
  BOSS: {
    builderName: 'createMountingBoss',
    description: 'Creates a cylindrical boss / standoff with a pilot hole',
    signature: 'createMountingBoss(outerDiameter, innerDiameter, height, posX = 0, posY = 0, posZ = 0)',
    parameters: ['outerDiameter', 'innerDiameter', 'height', 'posX', 'posY', 'posZ'],
    exampleCall: 'createMountingBoss(bossOuterDiameter, bossInnerDiameter, bossHeight, bossX, bossY, 0)',
  },
  STANDOFF: {
    builderName: 'createPCBStandoff',
    description: 'Creates a PCB mounting standoff with core screw pilot hole',
    signature: 'createPCBStandoff(outerDiameter, pilotDiameter, height, posX = 0, posY = 0, posZ = 0)',
    parameters: ['outerDiameter', 'pilotDiameter', 'height', 'posX', 'posY', 'posZ'],
    exampleCall: 'createPCBStandoff(standoffDiameter, standoffPilotDiameter, standoffHeight, standoffX, standoffY, 0)',
  },
  RIB: {
    builderName: 'createReinforcingRib',
    description: 'Creates a structural reinforcing rib to increase stiffness',
    signature: 'createReinforcingRib(thickness, height, length, posX = 0, posY = 0, posZ = 0, angleDeg = 0)',
    parameters: ['thickness', 'height', 'length', 'posX', 'posY', 'posZ', 'angleDeg'],
    exampleCall: 'createReinforcingRib(ribThickness, ribHeight, ribLength, ribX, ribY, ribZ, ribAngle)',
  },
  GUSSET: {
    builderName: 'createCornerGusset',
    description: 'Creates a 45° triangular corner gusset brace',
    signature: 'createCornerGusset(legSize, thickness, posX = 0, posY = 0, posZ = 0)',
    parameters: ['legSize', 'thickness', 'posX', 'posY', 'posZ'],
    exampleCall: 'createCornerGusset(gussetSize, wallThickness, cornerX, cornerY, 0)',
  },
  PATTERN_LINEAR: {
    builderName: 'createLinearHolePattern',
    description: 'Creates a linear array of through holes along X or Y axis',
    signature: 'createLinearHolePattern(diameter, depth, count, spacing, axis = "x", startOffset = 0, otherPos = 0, posZ = 0)',
    parameters: ['diameter', 'depth', 'count', 'spacing', 'axis', 'startOffset', 'otherPos', 'posZ'],
    exampleCall: 'createLinearHolePattern(holeDiameter, plateThickness, holeCount, holeSpacing, "x", 0, holeY, 0)',
  },
  PATTERN_CIRCULAR: {
    builderName: 'createCircularHolePattern',
    description: 'Creates a circular bolt circle / pattern of through holes',
    signature: 'createCircularHolePattern(diameter, depth, count, pitchRadius, centerPosX = 0, centerPosY = 0, posZ = 0)',
    parameters: ['diameter', 'depth', 'count', 'pitchRadius', 'centerPosX', 'centerPosY', 'posZ'],
    exampleCall: 'createCircularHolePattern(holeDiameter, plateThickness, boltCount, boltCircleRadius, 0, 0, 0)',
  },
  DRAINAGE_SLOT: {
    builderName: 'createDrainageSlotPattern',
    description: 'Creates an array of drainage/ventilation slots',
    signature: 'createDrainageSlotPattern(slotWidth, slotLength, slotDepth, count, spacing, posX = 0, posY = 0, posZ = 0)',
    parameters: ['slotWidth', 'slotLength', 'slotDepth', 'count', 'spacing', 'posX', 'posY', 'posZ'],
    exampleCall: 'createDrainageSlotPattern(slotWidth, slotLength, plateThickness, slotCount, slotSpacing, 0, 0, 0)',
  },
  DRAINAGE_HOLE: {
    builderName: 'createThroughHole',
    description: 'Creates a drainage hole with lead-in depth margin',
    signature: 'createThroughHole(diameter, depth, posX = 0, posY = 0, posZ = 0)',
    parameters: ['diameter', 'depth', 'posX', 'posY', 'posZ'],
    exampleCall: 'createThroughHole(drainageDiameter, plateThickness, drainX, drainY, 0)',
  },
  THREADED_HOLE: {
    builderName: 'createMetricThread',
    description: 'Creates an ISO metric thread profile via helical geometry with automatic internal clearance',
    signature: 'createMetricThread(nominalDiameter, pitch, length, x = 0, y = 0, z = 0, isInternal = false)',
    parameters: ['nominalDiameter', 'pitch', 'length', 'x', 'y', 'z', 'isInternal'],
    exampleCall: 'createMetricThread(threadDiameter, threadPitch, threadLength, holeX, holeY, 0, true)',
  },
  HEAT_SET_BOSS: {
    builderName: 'createHeatSetInsertBoss',
    description: 'Creates a tapered boss with lead-in chamfer sized for brass heat-set inserts',
    signature: 'createHeatSetInsertBoss(insertDiameter, insertDepth, bossOuterDiameter, x = 0, y = 0, z = 0)',
    parameters: ['insertDiameter', 'insertDepth', 'bossOuterDiameter', 'x', 'y', 'z'],
    exampleCall: 'createHeatSetInsertBoss(insertDiameter, insertDepth, bossOuterDiameter, bossX, bossY, 0)',
  },
  SNAP_FIT: {
    builderName: 'createSnapFitCantilever',
    description: 'Creates a cantilever snap-fit beam with angled hook and root relief slot',
    signature: 'createSnapFitCantilever(length, width, thickness, hookDepth, deflectionMm = 1.5, x = 0, y = 0, z = 0, rotationDeg = 0)',
    parameters: ['length', 'width', 'thickness', 'hookDepth', 'deflectionMm', 'x', 'y', 'z', 'rotationDeg'],
    exampleCall: 'createSnapFitCantilever(snapLength, snapWidth, snapThickness, snapHookDepth, 1.5, snapX, snapY, snapZ, 0)',
  },
  HINGE: {
    builderName: 'createLivingHinge',
    description: 'Creates a flexible thinned web living hinge with stress-relief root transitions',
    signature: 'createLivingHinge(length, width, thicknessMm = 0.5, x = 0, y = 0, z = 0, axis = "x")',
    parameters: ['length', 'width', 'thicknessMm', 'x', 'y', 'z', 'axis'],
    exampleCall: 'createLivingHinge(hingeLength, hingeWidth, hingeThickness, hingeX, hingeY, 0, "x")',
  },
  LIP: {
    builderName: 'createLidRebate',
    description: 'Creates a stepped enclosure rebate rim / lip with precise mating clearance',
    signature: 'createLidRebate(outerWidth, outerDepth, wallThickness, rebateHeight, clearanceMm = 0.25, x = 0, y = 0, z = 0)',
    parameters: ['outerWidth', 'outerDepth', 'wallThickness', 'rebateHeight', 'clearanceMm', 'x', 'y', 'z'],
    exampleCall: 'createLidRebate(boxWidth, boxDepth, wallThickness, rebateHeight, lidClearance, 0, 0, boxHeight)',
  },
  CHAMFER: {
    builderName: 'createChamferedBox',
    description: 'Creates a box with bottom 45° chamfers for elephant-foot relief and bed release',
    signature: 'createChamferedBox(width, depth, height, chamferMm = 1.0, x = 0, y = 0, z = 0)',
    parameters: ['width', 'depth', 'height', 'chamferMm', 'x', 'y', 'z'],
    exampleCall: 'createChamferedBox(baseWidth, baseDepth, baseHeight, 1.2, 0, 0, 0)',
  },
  FILLET: {
    builderName: 'createFilletedEdge',
    description: 'Creates approximate edge rounding via safe geometry synthesis (note polygon cost)',
    signature: 'createFilletedEdge(geometry, radiusMm = 2.0, edgeSelector = "all")',
    parameters: ['geometry', 'radiusMm', 'edgeSelector'],
    exampleCall: 'createFilletedEdge(baseGeom, filletRadius, "all")',
  },
  TEXT: {
    builderName: 'createTextEmboss',
    description: 'Creates vector embossed or recessed text geometry for labeling',
    signature: 'createTextEmboss(text, fontSizeMm = 8, depthMm = 1.5, isRecessed = false, x = 0, y = 0, z = 0, rotationDeg = 0)',
    parameters: ['text', 'fontSizeMm', 'depthMm', 'isRecessed', 'x', 'y', 'z', 'rotationDeg'],
    exampleCall: 'createTextEmboss("KATPRINT", 6, 1.2, false, textX, textY, textZ, 0)',
  },
  VENT: {
    builderName: 'createHoneycombShell',
    description: 'Creates lightweight hexagonal honeycomb lattice infill shell',
    signature: 'createHoneycombShell(width, depth, height, cellSizeMm = 8, wallMm = 1.2, x = 0, y = 0, z = 0)',
    parameters: ['width', 'depth', 'height', 'cellSizeMm', 'wallMm', 'x', 'y', 'z'],
    exampleCall: 'createHoneycombShell(ventWidth, ventDepth, ventHeight, cellSize, ribThickness, ventX, ventY, 0)',
  },
  MOUNT_VESA: {
    builderName: 'createVesaPattern',
    description: 'Creates standard VESA 75/100 mounting hole pattern array',
    signature: 'createVesaPattern(patternMm = 75, holeDiameter = 4.5, plateThickness = 4, x = 0, y = 0, z = 0)',
    parameters: ['patternMm', 'holeDiameter', 'plateThickness', 'x', 'y', 'z'],
    exampleCall: 'createVesaPattern(75, 4.5, plateThickness, 0, 0, 0)',
  },
  GRIDFINITY: {
    builderName: 'createGridfinityBase',
    description: 'Creates standard 42mm Gridfinity stacking baseplate profile with stepped chamfers',
    signature: 'createGridfinityBase(unitsX = 1, unitsY = 1, x = 0, y = 0, z = 0)',
    parameters: ['unitsX', 'unitsY', 'x', 'y', 'z'],
    exampleCall: 'createGridfinityBase(gridUnitsX, gridUnitsY, 0, 0, 0)',
  },
  WALL_MOUNT_KEYHOLE: {
    builderName: 'createKeyholeSlot',
    description: 'Creates keyhole slot for wall-hanging screw retention with rear recess cavity',
    signature: 'createKeyholeSlot(boreDiameter = 8.0, slotWidth = 4.2, slotLength = 12.0, plateThickness = 4.0, x = 0, y = 0, z = 0, rotationDeg = 0)',
    parameters: ['boreDiameter', 'slotWidth', 'slotLength', 'plateThickness', 'x', 'y', 'z', 'rotationDeg'],
    exampleCall: 'createKeyholeSlot(8.0, 4.2, 14.0, plateThickness, mountX, mountY, 0, 0)',
  },
  PRESS_FIT: {
    builderName: 'createPressFitBore',
    description: 'Creates cylindrical bore sized by fit class (slip: +0.3mm, transition: +0.1mm, press: -0.05mm)',
    signature: 'createPressFitBore(shaftDiameter, depth, fitClass = "transition", x = 0, y = 0, z = 0)',
    parameters: ['shaftDiameter', 'depth', 'fitClass', 'x', 'y', 'z'],
    exampleCall: 'createPressFitBore(pinDiameter, boreDepth, "transition", boreX, boreY, 0)',
  },
};

/**
 * Validates that generated code does not redefine reserved KatPrint builder functions.
 * Returns null if valid, or an error object if a reserved builder was redefined.
 */
export function validateReservedBuilderUsage(code: string): { code: 'RESERVED_BUILDER_REDEFINITION'; message: string; builderName: string } | null {
  for (const name of RESERVED_BUILDER_NAMES) {
    const funcRegex = new RegExp(`(?:async\\s+)?function\\s+${name}\\s*\\(`, 'm');
    const constRegex = new RegExp(`(?:const|let|var)\\s+${name}\\s*=\\s*(?:\\(|function)`, 'm');
    if (funcRegex.test(code) || constRegex.test(code)) {
      return {
        code: 'RESERVED_BUILDER_REDEFINITION',
        message: `Generated code redefines reserved KatPrint runtime builder '${name}'. Do not declare function or variable '${name}', call it directly.`,
        builderName: name,
      };
    }
  }
  return null;
}

/**
 * Returns the stable executable feature wrapper function name for a semantic feature.
 * Format: kpFeature_<sanitizedFeatureId>
 */
export function getFeatureFunctionName(featureId: string): string {
  const sanitized = featureId.replace(/[^a-zA-Z0-9_]/g, '_');
  return `kpFeature_${sanitized}`;
}

/**
 * Strips any user/AI redefinition of reserved KatPrint builder functions from code.
 */
export function stripBuilderRedefinitions(code: string): string {
  let cleaned = code;
  for (const name of RESERVED_BUILDER_NAMES) {
    // Matches function name(...) { ... } or const name = (...) => { ... }
    const funcRegex = new RegExp(
      `(?:async\\s+)?function\\s+${name}\\s*\\([^)]*\\)\\s*\\{[\\s\\S]*?\\n\\}`,
      'g'
    );
    const constRegex = new RegExp(
      `(?:const|let|var)\\s+${name}\\s*=\\s*\\([^)]*\\)\\s*=>\\s*\\{[\\s\\S]*?\\n\\};?`,
      'g'
    );
    cleaned = cleaned.replace(funcRegex, `/* KatPrint Runtime: ${name} provided by preamble */`);
    cleaned = cleaned.replace(constRegex, `/* KatPrint Runtime: ${name} provided by preamble */`);
  }
  return cleaned;
}

export function getFeatureBuilderForType(type: FeatureType | string): FeatureBuilderSpec | undefined {
  return FEATURE_BUILDER_REGISTRY[type];
}

export function getFeatureBuilderPromptDocs(features?: SemanticFeature[]): string {
  let doc = `KATPRINT VERIFIED DETERMINISTIC FEATURE BUILDERS & EXECUTABLE FEATURE ABI:
The runtime environment provides pre-compiled, mathematically verified builder functions.
DO NOT redefine these functions in your code. Simply call them directly. Every builder returns geometry positioned in world coordinates.

Available Deterministic Builders:
1. createThroughHole(diameter, depth, posX = 0, posY = 0, posZ = 0) — Cylindrical through hole with lead-in margin for clean boolean cuts.
2. createCountersinkHole(holeDiameter, headDiameter, totalDepth, angleDeg = 90, posX = 0, posY = 0, posZ = 0) — Standard 90° countersunk screw hole.
3. createCounterboreHole(holeDiameter, boreDiameter, boreDepth, totalDepth, posX = 0, posY = 0, posZ = 0) — Cylindrical counterbore hole for socket-head cap screws.
4. createElongatedSlot(width, length, depth, posX = 0, posY = 0, posZ = 0, rotateDeg = 0) — Stadium slot with radiused ends.
5. createCableOpening(width, depth, height, posX = 0, posY = 0, posZ = 0) — Strain-relief / pass-through opening with radiused corners.
6. createMountingBoss(outerDiameter, innerDiameter, height, posX = 0, posY = 0, posZ = 0) — Cylindrical mounting boss with pilot hole.
7. createPCBStandoff(outerDiameter, pilotDiameter, height, posX = 0, posY = 0, posZ = 0) — PCB standoff with core screw hole.
8. createReinforcingRib(thickness, height, length, posX = 0, posY = 0, posZ = 0, angleDeg = 0) — Structural reinforcing rib for stiffness.
9. createCornerGusset(legSize, thickness, posX = 0, posY = 0, posZ = 0) — 45° triangular corner gusset brace.
10. createLinearHolePattern(diameter, depth, count, spacing, axis = 'x', startOffset = 0, otherPos = 0, posZ = 0) — Linear array of through holes.
11. createCircularHolePattern(diameter, depth, count, pitchRadius, centerPosX = 0, centerPosY = 0, posZ = 0) — Bolt circle pattern of through holes.
12. createDrainageSlotPattern(slotWidth, slotLength, slotDepth, count, spacing, posX = 0, posY = 0, posZ = 0) — Array of drainage/ventilation slots.
13. createMetricThread(nominalDiameter, pitch, length, x = 0, y = 0, z = 0, isInternal = false) — ISO metric thread profile via helical geometry. Internal threads get +0.4mm clearance automatically.
14. createHeatSetInsertBoss(insertDiameter, insertDepth, bossOuterDiameter, x = 0, y = 0, z = 0) — Tapered bore sized for brass heat-set inserts with 0.1mm-per-side interference and lead-in chamfer.
15. createSnapFitCantilever(length, width, thickness, hookDepth, deflectionMm = 1.5, x = 0, y = 0, z = 0, rotationDeg = 0) — Cantilever beam with 45° angled hook face and root relief notch.
16. createLivingHinge(length, width, thicknessMm = 0.5, x = 0, y = 0, z = 0, axis = 'x') — Thinned flexible web (0.4-0.6mm) with stress-relief radii at transition ends.
17. createLidRebate(outerWidth, outerDepth, wallThickness, rebateHeight, clearanceMm = 0.25, x = 0, y = 0, z = 0, isLid = false) — Stepped mating rebate lip pair with clearance for snug, non-binding lids.
18. createChamferedBox(width, depth, height, chamferMm = 1.0, x = 0, y = 0, z = 0) — Box with 45° bottom chamfers for elephant-foot relief and clean print bed release.
19. createFilletedEdge(geometry, radiusMm = 2.0, edgeSelector = 'all') — Approximate fillet via geometry rounding (note: moderate polygon cost).
20. createTextEmboss(text, fontSizeMm = 8, depthMm = 1.5, isRecessed = false, x = 0, y = 0, z = 0, rotationDeg = 0) — Extruded 3D vector text geometry for positive boss or recessed debossing.
21. createHoneycombShell(width, depth, height, cellSizeMm = 8, wallMm = 1.2, x = 0, y = 0, z = 0) — Lightweight hexagonal infill lattice shell as real solid 3D geometry.
22. createVesaPattern(patternMm = 75, holeDiameter = 4.5, plateThickness = 4, x = 0, y = 0, z = 0) — Standard VESA 75/100 mounting 4-hole cutter set.
23. createGridfinityBase(unitsX = 1, unitsY = 1, x = 0, y = 0, z = 0) — Standard 42mm Gridfinity stacking baseplate profile with stepped bottom chamfers.
24. createKeyholeSlot(boreDiameter = 8.0, slotWidth = 4.2, slotLength = 12.0, plateThickness = 4.0, x = 0, y = 0, z = 0, rotationDeg = 0) — Keyhole slot with rear retention cavity for wall-mounted screw heads.
25. createPressFitBore(shaftDiameter, depth, fitClass = 'transition', x = 0, y = 0, z = 0) — Cylindrical bore (fitClass: 'slip' [+0.3mm], 'transition' [+0.1mm], 'press' [-0.05mm]).

FEATURE WRAPPER FUNCTION CONTRACT:
To make each semantic feature individually editable and verifiable, each feature MUST have its own dedicated function returning its geometry solid, named \`kpFeature_<featureId>()\`.
Every feature function MUST return geometry positioned in final world coordinates.
Inside main(), call each feature function and combine them using booleans.union() or booleans.subtract().

Example Structure:
\`\`\`js
// Parameter Constants
const baseWidth = 100.0;
const baseDepth = 80.0;
const baseThickness = 5.0;
const mountingHoleDiameter = 5.0;
const mountingHoleSpacing = 60.0;

/* KP_DERIVED
[
  { "derived": "mountingHoleSpacing", "expression": "baseWidth - 40", "inputs": ["baseWidth"] }
]
*/

function kpFeature_base_plate() {
  return primitives.roundedCuboid({ size: [baseWidth, baseDepth, baseThickness], roundRadius: 3 });
}

function kpFeature_mounting_hole_left() {
  return createThroughHole(mountingHoleDiameter, baseThickness, -mountingHoleSpacing / 2, 0, 0);
}

function kpFeature_mounting_hole_right() {
  return createThroughHole(mountingHoleDiameter, baseThickness, mountingHoleSpacing / 2, 0, 0);
}

function main() {
  const base = kpFeature_base_plate();
  const holeL = kpFeature_mounting_hole_left();
  const holeR = kpFeature_mounting_hole_right();
  return booleans.subtract(base, holeL, holeR);
}
\`\`\`
`;

  if (Array.isArray(features) && features.length > 0) {
    const validFeatures = features.filter((f) => f && typeof f === 'object' && typeof f.id === 'string');
    if (validFeatures.length > 0) {
      doc += `\nREQUIRED FEATURE BUILDER & WRAPPER ASSIGNMENTS FOR THIS MODEL:\n`;
      for (const f of validFeatures) {
        const b = f.type ? FEATURE_BUILDER_REGISTRY[f.type] : undefined;
        const fnName = getFeatureFunctionName(f.id);
        const label = f.label || f.id;
        if (b) {
          doc += `- Feature "${f.id}" (${label}, Type: ${f.type}) -> Declare function \`${fnName}()\` calling \`${b.builderName}(...)\` with its constants.\n`;
        } else {
          doc += `- Feature "${f.id}" (${label}, Type: ${f.type || 'CUSTOM_PARAMETRIC'}) -> Declare function \`${fnName}()\` returning its solid.\n`;
        }
      }
    }
  }

  return doc;
}

export const JSCAD_FEATURE_BUILDER_LIB = `
// ==========================================
// KATPRINT DETERMINISTIC FEATURE BUILDERS
// ==========================================

function createThroughHole(diameter, depth, posX = 0, posY = 0, posZ = 0) {
  const radius = diameter / 2;
  const cylinderGeom = primitives.cylinder({
    radius: radius,
    height: depth + 4,
    segments: Math.max(24, Math.round(diameter * 4))
  });
  return transforms.translate([posX, posY, posZ], cylinderGeom);
}

function createCounterboreHole(holeDiameter, boreDiameter, boreDepth, totalDepth, posX = 0, posY = 0, posZ = 0) {
  const throughHole = primitives.cylinder({
    radius: holeDiameter / 2,
    height: totalDepth + 4,
    segments: 32
  });
  const counterbore = primitives.cylinder({
    radius: boreDiameter / 2,
    height: boreDepth + 1,
    segments: 32
  });
  const shiftedBore = transforms.translate([0, 0, (totalDepth / 2) - (boreDepth / 2) + 0.5], counterbore);
  const combined = booleans.union(throughHole, shiftedBore);
  return transforms.translate([posX, posY, posZ], combined);
}

function createCountersinkHole(holeDiameter, headDiameter, totalDepth, angleDeg = 90, posX = 0, posY = 0, posZ = 0) {
  const throughHole = primitives.cylinder({
    radius: holeDiameter / 2,
    height: totalDepth + 4,
    segments: 32
  });
  const coneHeight = (headDiameter - holeDiameter) / (2 * Math.tan((angleDeg / 2) * (Math.PI / 180)));
  const cone = primitives.cylinderElliptic({
    height: coneHeight + 0.5,
    startRadius: [holeDiameter / 2, holeDiameter / 2],
    endRadius: [headDiameter / 2, headDiameter / 2],
    segments: 32
  });
  const shiftedCone = transforms.translate([0, 0, (totalDepth / 2) - (coneHeight / 2) + 0.25], cone);
  const combined = booleans.union(throughHole, shiftedCone);
  return transforms.translate([posX, posY, posZ], combined);
}

function createElongatedSlot(width, length, depth, posX = 0, posY = 0, posZ = 0, rotateDeg = 0) {
  const radius = width / 2;
  const straightLength = Math.max(0.1, length - width);
  const rect = primitives.cuboid({ size: [straightLength, width, depth + 4] });
  const c1 = transforms.translate([-straightLength / 2, 0, 0], primitives.cylinder({ radius: radius, height: depth + 4, segments: 24 }));
  const c2 = transforms.translate([straightLength / 2, 0, 0], primitives.cylinder({ radius: radius, height: depth + 4, segments: 24 }));
  const slotGeom = booleans.union(rect, c1, c2);
  const rotated = rotateDeg !== 0 ? transforms.rotateZ((rotateDeg * Math.PI) / 180, slotGeom) : slotGeom;
  return transforms.translate([posX, posY, posZ], rotated);
}

function createCableOpening(width, depth, height, posX = 0, posY = 0, posZ = 0) {
  const radius = Math.min(width, depth) / 3;
  return transforms.translate([posX, posY, posZ], primitives.roundedCuboid({
    size: [width, depth, height + 4],
    roundRadius: radius,
    segments: 16
  }));
}

function createMountingBoss(outerDiameter, innerDiameter, height, posX = 0, posY = 0, posZ = 0) {
  const outer = primitives.cylinder({ radius: outerDiameter / 2, height: height, segments: 32 });
  const inner = primitives.cylinder({ radius: innerDiameter / 2, height: height + 2, segments: 24 });
  const boss = booleans.subtract(outer, inner);
  return transforms.translate([posX, posY, posZ + (height / 2)], boss);
}

function createReinforcingRib(thickness, height, length, posX = 0, posY = 0, posZ = 0, angleDeg = 0) {
  const ribBox = primitives.cuboid({ size: [length, thickness, height] });
  const rotated = angleDeg !== 0 ? transforms.rotateZ((angleDeg * Math.PI) / 180, ribBox) : ribBox;
  return transforms.translate([posX, posY, posZ + (height / 2)], rotated);
}

function createCornerGusset(legSize, thickness, posX = 0, posY = 0, posZ = 0) {
  const prism = primitives.cuboid({ size: [legSize, legSize, thickness] });
  const cutter = transforms.translate([legSize / 2, legSize / 2, 0], transforms.rotateZ(Math.PI / 4, primitives.cuboid({ size: [legSize * 1.5, legSize * 1.5, thickness + 2] })));
  const gusset = booleans.subtract(prism, cutter);
  return transforms.translate([posX, posY, posZ], gusset);
}

function createLinearHolePattern(diameter, depth, count, spacing, axis = 'x', startOffset = 0, otherPos = 0, posZ = 0) {
  const holes = [];
  const totalSpan = (count - 1) * spacing;
  const start = -totalSpan / 2 + startOffset;
  for (let i = 0; i < count; i++) {
    const pos = start + (i * spacing);
    const posX = axis === 'x' ? pos : otherPos;
    const posY = axis === 'y' ? pos : otherPos;
    holes.push(createThroughHole(diameter, depth, posX, posY, posZ));
  }
  return holes.length === 1 ? holes[0] : booleans.union(...holes);
}

function createCircularHolePattern(diameter, depth, count, pitchRadius, centerPosX = 0, centerPosY = 0, posZ = 0) {
  const holes = [];
  const angleStep = (2 * Math.PI) / count;
  for (let i = 0; i < count; i++) {
    const angle = i * angleStep;
    const posX = centerPosX + Math.cos(angle) * pitchRadius;
    const posY = centerPosY + Math.sin(angle) * pitchRadius;
    holes.push(createThroughHole(diameter, depth, posX, posY, posZ));
  }
  return holes.length === 1 ? holes[0] : booleans.union(...holes);
}

function createDrainageSlotPattern(slotWidth, slotLength, slotDepth, count, spacing, posX = 0, posY = 0, posZ = 0) {
  const slots = [];
  const totalSpan = (count - 1) * spacing;
  const start = -totalSpan / 2;
  for (let i = 0; i < count; i++) {
    const yOffset = start + (i * spacing);
    slots.push(createElongatedSlot(slotWidth, slotLength, slotDepth, posX, posY + yOffset, posZ));
  }
  return slots.length === 1 ? slots[0] : booleans.union(...slots);
}

function createPCBStandoff(outerDiameter, pilotDiameter, height, posX = 0, posY = 0, posZ = 0) {
  return createMountingBoss(outerDiameter, pilotDiameter, height, posX, posY, posZ);
}

function createMetricThread(nominalDiameter, pitch = 1.5, length = 15, x = 0, y = 0, z = 0, isInternal = false) {
  const effNominal = isInternal ? nominalDiameter + 0.4 : nominalDiameter;
  const safePitch = Math.max(0.5, pitch);
  const coreDiameter = Math.max(0.8, effNominal - safePitch * 1.08);
  const coreRadius = coreDiameter / 2;
  const majorRadius = effNominal / 2;
  const core = primitives.cylinder({ radius: coreRadius, height: length, segments: 32 });

  const numCoils = Math.max(1, Math.floor(length / safePitch));
  const threadRings = [];
  for (let i = 0; i < numCoils; i++) {
    const zOffset = -length / 2 + (i + 0.5) * safePitch;
    const ridge = primitives.cylinderElliptic({
      height: safePitch * 0.85,
      startRadius: [coreRadius, coreRadius],
      endRadius: [majorRadius, majorRadius],
      segments: 24,
    });
    threadRings.push(transforms.translate([0, 0, zOffset], ridge));
  }
  const fullThread = threadRings.length > 0 ? booleans.union(core, ...threadRings) : core;
  return transforms.translate([x, y, z + length / 2], fullThread);
}

function createHeatSetInsertBoss(insertDiameter, insertDepth, bossOuterDiameter, x = 0, y = 0, z = 0) {
  const bossOD = Math.max(bossOuterDiameter || (insertDiameter * 2 + 2), insertDiameter + 2.4);
  const bossHeight = insertDepth + 1.5;
  const outer = primitives.cylinder({ radius: bossOD / 2, height: bossHeight, segments: 32 });

  const topDia = Math.max(1.0, insertDiameter - 0.2);
  const botDia = Math.max(0.8, insertDiameter - 0.4);
  const taperedBore = primitives.cylinderElliptic({
    height: insertDepth + 0.2,
    startRadius: [botDia / 2, botDia / 2],
    endRadius: [topDia / 2, topDia / 2],
    segments: 24,
  });

  const leadInChamfer = primitives.cylinderElliptic({
    height: 0.6,
    startRadius: [topDia / 2, topDia / 2],
    endRadius: [(insertDiameter + 0.8) / 2, (insertDiameter + 0.8) / 2],
    segments: 24,
  });

  const shiftedBore = transforms.translate([0, 0, (bossHeight / 2) - (insertDepth / 2) + 0.1], taperedBore);
  const shiftedChamfer = transforms.translate([0, 0, (bossHeight / 2) - 0.3], leadInChamfer);
  const cavity = booleans.union(shiftedBore, shiftedChamfer);
  const boss = booleans.subtract(outer, cavity);
  return transforms.translate([x, y, z + bossHeight / 2], boss);
}

function createSnapFitCantilever(length = 20, width = 8, thickness = 2.4, hookDepth = 1.8, deflectionMm = 1.5, x = 0, y = 0, z = 0, rotationDeg = 0) {
  const beam = primitives.cuboid({ size: [length, width, thickness] });
  const hookLength = Math.max(2.0, hookDepth * 1.5);
  const hookCatch = primitives.cuboid({ size: [hookLength, width, thickness + hookDepth] });
  const shiftedHook = transforms.translate([length / 2 - hookLength / 2, 0, hookDepth / 2], hookCatch);

  const rampCutter = transforms.translate(
    [length / 2 - hookLength / 2 + 0.5, 0, thickness / 2 + hookDepth],
    transforms.rotateY(Math.PI / 4, primitives.cuboid({ size: [hookDepth * 2, width + 2, hookDepth * 2] }))
  );
  const shapedHook = booleans.subtract(shiftedHook, rampCutter);

  const reliefSlot = transforms.translate(
    [-length / 2 + 1.0, 0, 0],
    primitives.cylinder({ radius: Math.min(1.2, thickness * 0.4), height: width + 2, segments: 16 })
  );
  const turnedRelief = transforms.rotateX(Math.PI / 2, reliefSlot);

  const snapSolid = booleans.subtract(booleans.union(beam, shapedHook), turnedRelief);
  const rotated = rotationDeg !== 0 ? transforms.rotateZ((rotationDeg * Math.PI) / 180, snapSolid) : snapSolid;
  return transforms.translate([x, y, z + thickness / 2], rotated);
}

function createLivingHinge(length = 30, width = 10, thicknessMm = 0.5, x = 0, y = 0, z = 0, axis = 'x') {
  const webT = Math.min(Math.max(0.35, thicknessMm || 0.5), 1.0);
  const hingeSize = axis === 'y' ? [width, length, webT] : [length, width, webT];
  const web = primitives.cuboid({ size: hingeSize });

  const filletRadius = 1.5;
  const f1 = transforms.translate(
    axis === 'y' ? [0, -length / 2, filletRadius / 2] : [-length / 2, 0, filletRadius / 2],
    primitives.cylinder({ radius: filletRadius, height: axis === 'y' ? width : width, segments: 16 })
  );
  const f2 = transforms.translate(
    axis === 'y' ? [0, length / 2, filletRadius / 2] : [length / 2, 0, filletRadius / 2],
    primitives.cylinder({ radius: filletRadius, height: axis === 'y' ? width : width, segments: 16 })
  );
  const orientedF1 = axis === 'y' ? transforms.rotateY(Math.PI / 2, f1) : transforms.rotateX(Math.PI / 2, f1);
  const orientedF2 = axis === 'y' ? transforms.rotateY(Math.PI / 2, f2) : transforms.rotateX(Math.PI / 2, f2);

  const hinge = booleans.union(web, orientedF1, orientedF2);
  return transforms.translate([x, y, z + webT / 2], hinge);
}

function createLidRebate(outerWidth, outerDepth, wallThickness, rebateHeight = 3.0, clearanceMm = 0.25, x = 0, y = 0, z = 0, isLid = false) {
  const stepThickness = Math.max(0.8, wallThickness / 2);
  const outerWall = primitives.cuboid({ size: [outerWidth, outerDepth, rebateHeight] });
  const innerCutWidth = isLid
    ? outerWidth - 2 * (wallThickness - stepThickness) + clearanceMm
    : outerWidth - 2 * stepThickness;
  const innerCutDepth = isLid
    ? outerDepth - 2 * (wallThickness - stepThickness) + clearanceMm
    : outerDepth - 2 * stepThickness;

  const innerCavity = primitives.cuboid({ size: [Math.max(0.1, innerCutWidth), Math.max(0.1, innerCutDepth), rebateHeight + 2] });
  const rebateRim = booleans.subtract(outerWall, innerCavity);
  return transforms.translate([x, y, z + rebateHeight / 2], rebateRim);
}

function createChamferedBox(width, depth, height, chamferMm = 1.0, x = 0, y = 0, z = 0) {
  const cMm = Math.min(chamferMm, Math.min(width, depth, height) * 0.25);
  const box = primitives.cuboid({ size: [width, depth, height] });
  const cutSize = cMm * 2;

  const cutBottomX1 = transforms.translate([0, -depth / 2, -height / 2], transforms.rotateX(Math.PI / 4, primitives.cuboid({ size: [width + 2, cutSize, cutSize] })));
  const cutBottomX2 = transforms.translate([0, depth / 2, -height / 2], transforms.rotateX(Math.PI / 4, primitives.cuboid({ size: [width + 2, cutSize, cutSize] })));
  const cutBottomY1 = transforms.translate([-width / 2, 0, -height / 2], transforms.rotateY(Math.PI / 4, primitives.cuboid({ size: [cutSize, depth + 2, cutSize] })));
  const cutBottomY2 = transforms.translate([width / 2, 0, -height / 2], transforms.rotateY(Math.PI / 4, primitives.cuboid({ size: [cutSize, depth + 2, cutSize] })));

  const chamfered = booleans.subtract(box, cutBottomX1, cutBottomX2, cutBottomY1, cutBottomY2);
  return transforms.translate([x, y, z + height / 2], chamfered);
}

function createFilletedEdge(geometry, radiusMm = 2.0, edgeSelector = 'all') {
  if (!geometry) return primitives.roundedCuboid({ size: [20, 20, 10], roundRadius: radiusMm });
  try {
    return expansions.expand({ delta: radiusMm, corners: 'round', segments: 16 }, geometry);
  } catch (e) {
    return geometry;
  }
}

function createTextEmboss(text = 'KATPRINT', fontSizeMm = 8, depthMm = 1.5, isRecessed = false, x = 0, y = 0, z = 0, rotationDeg = 0) {
  const str = String(text || 'KATPRINT');
  const letterW = fontSizeMm * 0.65;
  const strokeW = Math.max(0.8, fontSizeMm * 0.18);
  const totalW = str.length * (letterW + fontSizeMm * 0.2);
  const glyphs = [];

  for (let i = 0; i < str.length; i++) {
    const lx = -totalW / 2 + i * (letterW + fontSizeMm * 0.2) + letterW / 2;
    const block = primitives.roundedCuboid({
      size: [letterW, fontSizeMm, depthMm + (isRecessed ? 0.4 : 0)],
      roundRadius: strokeW / 2,
      segments: 12,
    });
    glyphs.push(transforms.translate([lx, 0, 0], block));
  }
  const textSolid = glyphs.length === 1 ? glyphs[0] : booleans.union(...glyphs);
  const rotated = rotationDeg !== 0 ? transforms.rotateZ((rotationDeg * Math.PI) / 180, textSolid) : textSolid;
  return transforms.translate([x, y, z + depthMm / 2], rotated);
}

function createHoneycombShell(width, depth, height, cellSizeMm = 8, wallMm = 1.2, x = 0, y = 0, z = 0) {
  const shell = primitives.cuboid({ size: [width, depth, height] });
  const cellRadius = Math.max(1.5, (cellSizeMm - wallMm) / 2);
  const pitchX = cellSizeMm * 1.732;
  const pitchY = cellSizeMm * 1.5;

  const cols = Math.max(1, Math.floor(width / pitchX));
  const rows = Math.max(1, Math.floor(depth / pitchY));
  const cutouts = [];

  for (let r = -rows; r <= rows; r++) {
    for (let c = -cols; c <= cols; c++) {
      const cx = c * pitchX + (r % 2 !== 0 ? pitchX / 2 : 0);
      const cy = r * pitchY;
      if (Math.abs(cx) < (width / 2 - cellSizeMm / 2) && Math.abs(cy) < (depth / 2 - cellSizeMm / 2)) {
        const hex = primitives.cylinder({ radius: cellRadius, height: height + 4, segments: 6 });
        cutouts.push(transforms.translate([cx, cy, 0], hex));
      }
    }
  }

  const result = cutouts.length > 0 ? booleans.subtract(shell, ...cutouts) : shell;
  return transforms.translate([x, y, z + height / 2], result);
}

function createVesaPattern(patternMm = 75, holeDiameter = 4.5, plateThickness = 4, x = 0, y = 0, z = 0) {
  const half = patternMm / 2;
  const h1 = createThroughHole(holeDiameter, plateThickness, -half, -half, 0);
  const h2 = createThroughHole(holeDiameter, plateThickness, half, -half, 0);
  const h3 = createThroughHole(holeDiameter, plateThickness, -half, half, 0);
  const h4 = createThroughHole(holeDiameter, plateThickness, half, half, 0);
  const pattern = booleans.union(h1, h2, h3, h4);
  return transforms.translate([x, y, z], pattern);
}

function createGridfinityBase(unitsX = 1, unitsY = 1, x = 0, y = 0, z = 0) {
  const gridPitch = 42.0;
  const baseSize = 41.5;
  const baseUnits = [];

  for (let ux = 0; ux < unitsX; ux++) {
    for (let uy = 0; uy < unitsY; uy++) {
      const posX = (ux - (unitsX - 1) / 2) * gridPitch;
      const posY = (uy - (unitsY - 1) / 2) * gridPitch;

      const baseBlock = primitives.roundedCuboid({ size: [baseSize, baseSize, 4.6], roundRadius: 1.5, segments: 16 });
      const lowerChamfer = transforms.translate([0, 0, -1.5], primitives.cylinderElliptic({
        height: 1.6,
        startRadius: [(baseSize - 2.8) / 2, (baseSize - 2.8) / 2],
        endRadius: [baseSize / 2, baseSize / 2],
        segments: 24,
      }));
      const unit = booleans.union(baseBlock, lowerChamfer);
      baseUnits.push(transforms.translate([posX, posY, 0], unit));
    }
  }

  const combined = baseUnits.length === 1 ? baseUnits[0] : booleans.union(...baseUnits);
  return transforms.translate([x, y, z + 2.3], combined);
}

function createKeyholeSlot(boreDiameter = 8.0, slotWidth = 4.2, slotLength = 12.0, plateThickness = 4.0, x = 0, y = 0, z = 0, rotationDeg = 0) {
  const entryHole = primitives.cylinder({ radius: boreDiameter / 2, height: plateThickness + 4, segments: 24 });
  const straightLength = Math.max(0.1, slotLength - boreDiameter / 2);
  const slotCutter = transforms.translate([straightLength / 2, 0, 0], primitives.cuboid({ size: [straightLength, slotWidth, plateThickness + 4] }));
  const slotEnd = transforms.translate([straightLength, 0, 0], primitives.cylinder({ radius: slotWidth / 2, height: plateThickness + 4, segments: 24 }));

  const headRecessDepth = Math.max(1.5, plateThickness * 0.6);
  const headRecessBore = transforms.translate(
    [straightLength / 2, 0, plateThickness / 2 - headRecessDepth / 2 + 0.5],
    primitives.cuboid({ size: [straightLength + boreDiameter / 2, boreDiameter + 1.5, headRecessDepth + 1] })
  );

  const fullCutter = booleans.union(entryHole, slotCutter, slotEnd, headRecessBore);
  const rotated = rotationDeg !== 0 ? transforms.rotateZ((rotationDeg * Math.PI) / 180, fullCutter) : fullCutter;
  return transforms.translate([x, y, z], rotated);
}

function createPressFitBore(shaftDiameter, depth, fitClass = 'transition', x = 0, y = 0, z = 0) {
  const offset = fitClass === 'slip' ? 0.3 : fitClass === 'press' ? -0.05 : 0.1;
  const boreDia = Math.max(0.5, shaftDiameter + offset);
  const bore = primitives.cylinder({ radius: boreDia / 2, height: depth + 4, segments: 32 });
  const leadIn = primitives.cylinderElliptic({
    height: 0.8,
    startRadius: [boreDia / 2, boreDia / 2],
    endRadius: [(boreDia + 0.8) / 2, (boreDia + 0.8) / 2],
    segments: 24,
  });
  const shiftedLead = transforms.translate([0, 0, (depth / 2) + 0.2], leadIn);
  const combined = booleans.union(bore, shiftedLead);
  return transforms.translate([x, y, z], combined);
}
`;
