/**
 * Deterministic Derived Parameters Engine for KatForge CAD Models.
 *
 * Provides safe expression parsing, topological graph resolution, cycle detection,
 * live re-evaluation, and source-code literal rewriting without eval() or Function().
 */

export interface DerivedRelationship {
  derived: string;
  expression: string;
  inputs: string[];
}

/**
 * Extracts the KP_DERIVED JSON block from JSCAD code comments.
 * Supports /* KP_DERIVED ... *\/ and // KP_DERIVED ... comment formats.
 */
export function parseDerivedBlock(code: string): DerivedRelationship[] {
  if (!code || typeof code !== 'string') return [];

  // Match /* KP_DERIVED ... */ or // KP_DERIVED ...
  const blockRegex = /\/\*\s*KP_DERIVED([\s\S]*?)\*\/|\/\/\s*KP_DERIVED([^\n]*)/i;
  const match = code.match(blockRegex);
  if (!match) return [];

  const rawJson = (match[1] || match[2] || '').trim();
  if (!rawJson) return [];

  try {
    const parsed = JSON.parse(rawJson);
    if (Array.isArray(parsed)) {
      return parsed
        .filter((item) => item && typeof item === 'object' && typeof item.derived === 'string' && typeof item.expression === 'string')
        .map((item) => ({
          derived: String(item.derived).trim(),
          expression: String(item.expression).trim(),
          inputs: Array.isArray(item.inputs) ? item.inputs.map((s: any) => String(s).trim()).filter(Boolean) : extractIdentifiersFromExpression(String(item.expression)),
        }));
    }
  } catch (err) {
    console.warn('[derivedParameters] Failed to parse KP_DERIVED JSON block:', err);
  }

  return [];
}

/**
 * Extracts variable identifiers referenced in an arithmetic expression string.
 */
export function extractIdentifiersFromExpression(expr: string): string[] {
  const matches = expr.match(/[a-zA-Z_$][a-zA-Z0-9_$]*/g) || [];
  const reserved = new Set([
    'Math', 'min', 'max', 'abs', 'sqrt', 'round', 'floor', 'ceil', 'sin', 'cos', 'tan', 'PI', 'E'
  ]);
  const ids = new Set<string>();
  for (const m of matches) {
    if (!reserved.has(m)) {
      ids.add(m);
    }
  }
  return Array.from(ids);
}

// ---------------------------------------------------------------------------
// Safe Recursive-Descent Expression Evaluator (No eval, No Function)
// ---------------------------------------------------------------------------

type TokenType = 'NUMBER' | 'IDENT' | 'OP' | 'LPAREN' | 'RPAREN' | 'COMMA' | 'EOF';

interface Token {
  type: TokenType;
  value: string | number;
}

function tokenize(input: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  const len = input.length;

  while (i < len) {
    const ch = input[i];

    if (/\s/.test(ch)) {
      i++;
      continue;
    }

    if (/[0-9]/.test(ch) || (ch === '.' && i + 1 < len && /[0-9]/.test(input[i + 1]))) {
      let numStr = '';
      while (i < len && (/[0-9]/.test(input[i]) || input[i] === '.')) {
        numStr += input[i++];
      }
      tokens.push({ type: 'NUMBER', value: parseFloat(numStr) });
      continue;
    }

    if (/[a-zA-Z_$]/.test(ch)) {
      let idStr = '';
      while (i < len && /[a-zA-Z0-9_$.]/.test(input[i])) {
        idStr += input[i++];
      }
      tokens.push({ type: 'IDENT', value: idStr });
      continue;
    }

    if (ch === '(') {
      tokens.push({ type: 'LPAREN', value: '(' });
      i++;
      continue;
    }

    if (ch === ')') {
      tokens.push({ type: 'RPAREN', value: ')' });
      i++;
      continue;
    }

    if (ch === ',') {
      tokens.push({ type: 'COMMA', value: ',' });
      i++;
      continue;
    }

    if (ch === '*' && i + 1 < len && input[i + 1] === '*') {
      tokens.push({ type: 'OP', value: '^' });
      i += 2;
      continue;
    }

    if ('+-*/%^'.includes(ch)) {
      tokens.push({ type: 'OP', value: ch });
      i++;
      continue;
    }

    // Ignore unrecognized character
    i++;
  }

  tokens.push({ type: 'EOF', value: '' });
  return tokens;
}

class ExpressionParser {
  private tokens: Token[];
  private pos = 0;
  private context: Record<string, number>;

  constructor(tokens: Token[], context: Record<string, number>) {
    this.tokens = tokens;
    this.context = context;
  }

  private peek(): Token {
    return this.tokens[this.pos] || { type: 'EOF', value: '' };
  }

  private consume(expected?: TokenType): Token {
    const tok = this.peek();
    if (expected && tok.type !== expected) {
      throw new Error(`Unexpected token '${tok.value}' (expected ${expected})`);
    }
    this.pos++;
    return tok;
  }

  public parse(): number {
    const res = this.parseExpression();
    if (this.peek().type !== 'EOF') {
      throw new Error(`Unexpected trailing tokens after expression: '${this.peek().value}'`);
    }
    return res;
  }

  private parseExpression(): number {
    return this.parseAddition();
  }

  private parseAddition(): number {
    let left = this.parseMultiplication();
    while (this.peek().type === 'OP' && (this.peek().value === '+' || this.peek().value === '-')) {
      const op = this.consume().value;
      const right = this.parseMultiplication();
      if (op === '+') left += right;
      else left -= right;
    }
    return left;
  }

  private parseMultiplication(): number {
    let left = this.parseExponent();
    while (this.peek().type === 'OP' && (this.peek().value === '*' || this.peek().value === '/' || this.peek().value === '%')) {
      const op = this.consume().value;
      const right = this.parseExponent();
      if (op === '*') left *= right;
      else if (op === '/') {
        if (Math.abs(right) < 1e-12) throw new Error('Division by zero in derived parameter calculation');
        left /= right;
      } else left %= right;
    }
    return left;
  }

  private parseExponent(): number {
    let left = this.parseUnary();
    if (this.peek().type === 'OP' && this.peek().value === '^') {
      this.consume();
      const right = this.parseExponent();
      left = Math.pow(left, right);
    }
    return left;
  }

  private parseUnary(): number {
    if (this.peek().type === 'OP' && this.peek().value === '-') {
      this.consume();
      return -this.parseUnary();
    }
    if (this.peek().type === 'OP' && this.peek().value === '+') {
      this.consume();
      return this.parseUnary();
    }
    return this.parsePrimary();
  }

  private parsePrimary(): number {
    const tok = this.peek();

    if (tok.type === 'NUMBER') {
      this.consume();
      return typeof tok.value === 'number' ? tok.value : parseFloat(tok.value as string);
    }

    if (tok.type === 'LPAREN') {
      this.consume('LPAREN');
      const val = this.parseExpression();
      this.consume('RPAREN');
      return val;
    }

    if (tok.type === 'IDENT') {
      const id = String(this.consume('IDENT').value);

      // Function call e.g. Math.min(a, b), min(a, b), Math.sqrt(x)
      if (this.peek().type === 'LPAREN') {
        this.consume('LPAREN');
        const args: number[] = [];
        if (this.peek().type !== 'RPAREN') {
          args.push(this.parseExpression());
          while (this.peek().type === 'COMMA') {
            this.consume('COMMA');
            args.push(this.parseExpression());
          }
        }
        this.consume('RPAREN');
        return this.executeFunction(id, args);
      }

      // Identifier constants
      if (id === 'Math.PI' || id === 'PI') return Math.PI;
      if (id === 'Math.E' || id === 'E') return Math.E;

      // Variable lookup in context
      if (Object.prototype.hasOwnProperty.call(this.context, id)) {
        const val = this.context[id];
        if (typeof val !== 'number' || isNaN(val)) {
          throw new Error(`Variable '${id}' resolved to invalid number: ${val}`);
        }
        return val;
      }

      throw new Error(`Unknown variable or undefined constant '${id}' in expression`);
    }

    throw new Error(`Syntax error: unexpected token '${tok.value}'`);
  }

  private executeFunction(fnName: string, args: number[]): number {
    const norm = fnName.replace(/^Math\./, '').toLowerCase();
    switch (norm) {
      case 'min':
        if (args.length === 0) return 0;
        return Math.min(...args);
      case 'max':
        if (args.length === 0) return 0;
        return Math.max(...args);
      case 'abs':
        return Math.abs(args[0] || 0);
      case 'sqrt':
        return Math.sqrt(Math.max(0, args[0] || 0));
      case 'round':
        return Math.round(args[0] || 0);
      case 'floor':
        return Math.floor(args[0] || 0);
      case 'ceil':
        return Math.ceil(args[0] || 0);
      case 'sin':
        return Math.sin(args[0] || 0);
      case 'cos':
        return Math.cos(args[0] || 0);
      case 'tan':
        return Math.tan(args[0] || 0);
      default:
        throw new Error(`Unsupported function '${fnName}' in safe expression evaluator`);
    }
  }
}

/**
 * Safely evaluates a single mathematical expression with given variable context.
 */
export function evaluateSafeExpression(expr: string, context: Record<string, number>): number {
  const tokens = tokenize(expr);
  const parser = new ExpressionParser(tokens, context);
  return parser.parse();
}

// ---------------------------------------------------------------------------
// Topological Dependency Resolution & Cycle Detection
// ---------------------------------------------------------------------------

/**
 * Computes the topological evaluation order of derived relationships.
 * Throws an Error if a circular dependency is detected.
 */
export function getTopologicalOrder(relationships: DerivedRelationship[]): DerivedRelationship[] {
  const byName = new Map<string, DerivedRelationship>();
  for (const rel of relationships) {
    byName.set(rel.derived, rel);
  }

  const visited = new Set<string>();
  const inStack = new Set<string>();
  const pathStack: string[] = [];
  const ordered: DerivedRelationship[] = [];

  function visit(name: string) {
    if (inStack.has(name)) {
      const cyclePath = [...pathStack.slice(pathStack.indexOf(name)), name].join(' -> ');
      throw new Error(`Circular dependency detected in derived parameters: ${cyclePath}`);
    }
    if (visited.has(name)) return;

    const rel = byName.get(name);
    if (!rel) return; // Base parameter

    inStack.add(name);
    pathStack.push(name);

    for (const input of rel.inputs) {
      if (byName.has(input)) {
        visit(input);
      }
    }

    inStack.delete(name);
    pathStack.pop();
    visited.add(name);
    ordered.push(rel);
  }

  for (const rel of relationships) {
    if (!visited.has(rel.derived)) {
      visit(rel.derived);
    }
  }

  return ordered;
}

/**
 * Evaluates all derived relationships in topological order given the current constant values.
 * Returns the merged map containing both updated base constants and newly derived constants.
 */
export function evaluateDerived(
  constants: Record<string, number>,
  relationships: DerivedRelationship[]
): Record<string, number> {
  const result: Record<string, number> = { ...constants };
  if (!relationships || relationships.length === 0) return result;

  // 1. Get topological execution order
  const orderedRelationships = getTopologicalOrder(relationships);

  // 2. Sequentially evaluate each relationship
  for (const rel of orderedRelationships) {
    try {
      const computed = evaluateSafeExpression(rel.expression, result);
      // Clean up floating point precision issues (e.g. 10.000000000000002 -> 10)
      result[rel.derived] = Number(Number(computed.toFixed(4)).toString());
    } catch (err: any) {
      console.warn(`[evaluateDerived] Error calculating ${rel.derived} = "${rel.expression}":`, err.message);
    }
  }

  return result;
}

/**
 * Formats relationships into a standard KP_DERIVED comment block.
 */
export function formatDerivedBlock(relationships: DerivedRelationship[]): string {
  if (!relationships || relationships.length === 0) return '';
  const json = JSON.stringify(relationships, null, 2);
  return `/* KP_DERIVED\n${json}\n*/`;
}

/**
 * Rewrites top-level constant literals in the JSCAD source code.
 * Recomputes all dependent derived constants in topological order before writing.
 */
export function rewriteConstants(
  code: string,
  newValues: Record<string, number>,
  relationships?: DerivedRelationship[]
): string {
  if (!code || typeof code !== 'string') return code;

  // 1. Parse or use provided relationships
  const activeRelationships = relationships !== undefined ? relationships : parseDerivedBlock(code);

  // 2. Extract existing named constants from code
  const currentConsts: Record<string, number> = {};
  const constRegex = /(?:const|let|var)\s+([a-zA-Z0-9_$]+)\s*=\s*([-+]?[0-9]*\.?[0-9]+)\s*;/g;
  let match: RegExpExecArray | null;
  while ((match = constRegex.exec(code)) !== null) {
    const name = match[1];
    const val = parseFloat(match[2]);
    if (!isNaN(val)) {
      currentConsts[name] = val;
    }
  }

  // 3. Merge incoming new values
  const mergedBase = { ...currentConsts, ...newValues };

  // 4. Compute all derived parameters in topological order
  const evaluatedAll = evaluateDerived(mergedBase, activeRelationships);

  // 5. Rewrite each constant in code
  let updatedCode = code;
  for (const [name, val] of Object.entries(evaluatedAll)) {
    if (typeof val !== 'number' || isNaN(val)) continue;
    const valStr = Number.isInteger(val) ? `${val}.0` : val.toString();
    const replacePattern = new RegExp(`((?:const|let|var)\\s+${name}\\s*=\\s*)([-+]?[0-9]*\\.?[0-9]+)(\\s*;)`, 'g');
    updatedCode = updatedCode.replace(replacePattern, `$1${valStr}$3`);
  }

  // 6. If relationships were explicitly modified (e.g. unlinked), update the KP_DERIVED block
  if (relationships !== undefined) {
    const blockRegex = /\/\*\s*KP_DERIVED[\s\S]*?\*\/|\/\/\s*KP_DERIVED[^\n]*/i;
    const newBlock = formatDerivedBlock(relationships);
    if (blockRegex.test(updatedCode)) {
      updatedCode = updatedCode.replace(blockRegex, newBlock);
    } else if (newBlock) {
      // Prepend or insert after the constants block
      updatedCode = `${newBlock}\n\n${updatedCode}`;
    }
  }

  return updatedCode;
}

/**
 * Unlinks a derived parameter by removing it from the KP_DERIVED relationship table.
 * Once unlinked, the parameter remains a numeric literal in code and becomes independently editable.
 */
export function unlinkDerived(code: string, derivedParamName: string): string {
  const relationships = parseDerivedBlock(code);
  const remaining = relationships.filter((rel) => rel.derived !== derivedParamName);
  return rewriteConstants(code, {}, remaining);
}
