import { analyzePrintability, PrintabilityOptions } from '../engine/printabilityAnalysis';

self.onmessage = (e: MessageEvent<{ id: string; polygons: any; options?: PrintabilityOptions }>) => {
  const { id, polygons, options } = e.data;
  try {
    const report = analyzePrintability(polygons, options);
    self.postMessage({ id, success: true, report });
  } catch (err: any) {
    self.postMessage({ id, success: false, error: err?.message || String(err) });
  }
};
