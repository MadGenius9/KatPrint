import React, { useState } from 'react';
import {
  X,
  Play,
  CheckCircle2,
  AlertCircle,
  FlaskConical,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Cpu,
  Layers,
  RefreshCw,
  AlertTriangle,
  Clock,
  Check,
  Activity,
  History,
  GitBranch,
  RotateCcw,
  Database,
  GitCompare,
} from 'lucide-react';
import { classifyPromptIntent, matchKnownReference } from '../engine/promptClassifier';
import { requestJscadGeneration } from '../services/geminiService';
import { executeJscadCode } from '../engine/jscadRunner';
import { analyzeBufferGeometry } from '../engine/geometryUtils';
import { parseRevisionInstruction } from '../revisions/parseRevision';
import { buildModelVersion, restoreVersionAsNewHead, branchNewVersion } from '../versions/versionService';
import { compareVersions } from '../versions/compareVersions';
import { projectRepository } from '../projects/projectRepository';
import { KatPrintProject, ModelVersion } from '../projects/projectTypes';
import { normalizeKatPrintProject, duplicateProjectGraph, createBlankProject } from '../projects/projectService';
import {
  planSemanticFeatureModel,
  finalizeFeatureModelForCode,
  extractFeatureCodeBindings,
  validateFeatureBindings,
  isExplicitParameterOverride,
  FeatureParameter,
} from '../features';
import {
  executeSemanticFeatureGeometries,
  rankSelectionIntersections,
} from '../features/featureSelection';
import { buildDesignSpecification } from '../engine/designIntent/designSpecification';
import { applyDirectParameterUpdateToProject } from '../projects/revisionEngine';

interface TestCase {
  id: string;
  title: string;
  category: string;
  prompt: string;
  expectedClassification: 'PARAMETRIC' | 'ORGANIC' | 'HYBRID';
  expectedReferenceName?: string;
  expectedReferenceDimensions?: { width: number; depth: number; height: number };
  expectedVerifications: string[];
}

export const CLASSIFIER_REGRESSION_TESTS: TestCase[] = [
  {
    id: 'reg-1',
    title: 'Test 1: Soap dish for a Dr. Squatch bar',
    category: 'Brand Reference Object',
    prompt: 'Make a soap dish for a Dr. Squatch bar.',
    expectedClassification: 'PARAMETRIC',
    expectedReferenceName: 'Dr. Squatch Soap Bar',
    expectedReferenceDimensions: { width: 76.2, depth: 76.2, height: 25.4 },
    expectedVerifications: [
      'Classification: PARAMETRIC (Primary: soap dish)',
      'Reference Object: Dr. Squatch Soap Bar (76.2 × 76.2 × 25.4 mm)',
      'Brand name is a reference item, NOT a sculpture request',
      'Fit clearance added (+2.0 mm)',
    ],
  },
  {
    id: 'reg-2',
    title: 'Test 2: Wall holder for an Xbox controller',
    category: 'Brand Reference Object',
    prompt: 'Make a wall holder for an Xbox controller.',
    expectedClassification: 'PARAMETRIC',
    expectedReferenceName: 'Xbox Wireless Controller',
    expectedReferenceDimensions: { width: 155.0, depth: 108.0, height: 63.0 },
    expectedVerifications: [
      'Classification: PARAMETRIC (Primary: wall holder)',
      'Reference Object: Xbox Wireless Controller (155 × 108 × 63 mm)',
      'Precision mechanical mounting cradle',
    ],
  },
  {
    id: 'reg-3',
    title: 'Test 3: Milwaukee M18 battery holder',
    category: 'Brand Reference Object',
    prompt: 'Make a Milwaukee M18 battery holder.',
    expectedClassification: 'PARAMETRIC',
    expectedReferenceName: 'Milwaukee M18 RedLithium Battery',
    expectedReferenceDimensions: { width: 78.0, depth: 120.0, height: 68.0 },
    expectedVerifications: [
      'Classification: PARAMETRIC (Primary: battery holder)',
      'Reference Object: Milwaukee M18 RedLithium Battery (78 × 120 × 68 mm)',
      'Tool battery slide rail / latch cradle',
    ],
  },
  {
    id: 'reg-4',
    title: 'Test 4: Stanley cup holder',
    category: 'Brand Reference Object',
    prompt: 'Make a Stanley cup holder.',
    expectedClassification: 'PARAMETRIC',
    expectedReferenceName: 'Stanley Quencher 40 oz Tumbler',
    expectedVerifications: [
      'Classification: PARAMETRIC (Primary: cup holder)',
      'Reference Object: Stanley Quencher 40 oz Tumbler (Ø78 mm base)',
      'Stepped cylindrical cup holder with drainage',
    ],
  },
  {
    id: 'reg-5',
    title: 'Test 5: Soap dish with recessed text',
    category: 'Decorative Text Accent',
    prompt: 'Make a soap dish with DR. SQUATCH recessed into the front.',
    expectedClassification: 'PARAMETRIC',
    expectedVerifications: [
      'Classification: PARAMETRIC (Primary: soap dish)',
      'Decorative requirement: Recessed DR. SQUATCH text',
      'Text engraving does NOT trigger organic/hybrid routing',
    ],
  },
  {
    id: 'reg-6',
    title: 'Test 6: Soap dish with footprint cutout',
    category: 'Decorative Cutout Accent',
    prompt: 'Make a soap dish with a simple sasquatch-footprint cutout.',
    expectedClassification: 'PARAMETRIC',
    expectedVerifications: [
      'Classification: PARAMETRIC (Primary: soap dish)',
      'Decorative requirement: 2D footprint drainage cutout',
      '2D silhouette does NOT trigger organic/hybrid routing',
    ],
  },
  {
    id: 'reg-7',
    title: 'Test 7: Realistic sasquatch figurine',
    category: 'Freeform Sculpture',
    prompt: 'Make a realistic sasquatch figurine.',
    expectedClassification: 'ORGANIC',
    expectedVerifications: [
      'Classification: ORGANIC',
      'Requires Text-to-3D neural mesh generation',
      'Sculptural requirement: Realistic sasquatch anatomy',
    ],
  },
  {
    id: 'reg-8',
    title: 'Test 8: Soap dish shaped like realistic sasquatch hands',
    category: 'Sculptural Body + Functional Interface',
    prompt: 'Make a soap dish shaped like realistic sasquatch hands holding the soap.',
    expectedClassification: 'HYBRID',
    expectedVerifications: [
      'Classification: HYBRID',
      'Sculptural requirement: Anatomical hands sculpture',
      'Functional requirement: Holds soap bar',
    ],
  },
  {
    id: 'reg-9',
    title: 'Test 9: Realistic skull',
    category: 'Freeform Sculpture',
    prompt: 'Make a realistic skull.',
    expectedClassification: 'ORGANIC',
    expectedVerifications: [
      'Classification: ORGANIC',
      'Sculptural requirement: Anatomical skull geometry',
      'No mechanical mounting features',
    ],
  },
  {
    id: 'reg-10',
    title: 'Test 10: Skull-shaped gear knob with M12 thread',
    category: 'Sculptural Body + Functional Interface',
    prompt: 'Make a realistic skull-shaped gear knob with an M12 threaded mounting hole.',
    expectedClassification: 'HYBRID',
    expectedVerifications: [
      'Classification: HYBRID',
      'Sculptural requirement: Realistic skull body',
      'Functional requirement: M12 precision threaded hole',
    ],
  },
  {
    id: 'reg-11',
    title: 'Test 11: Rectangular gear knob with recessed skull icon',
    category: 'Decorative Icon Accent',
    prompt: 'Make a rectangular gear knob and put a skull icon recessed into the top.',
    expectedClassification: 'PARAMETRIC',
    expectedVerifications: [
      'Classification: PARAMETRIC (Primary: rectangular gear knob)',
      'Decorative requirement: 2D skull icon recess on top',
      'Geometric body with 2D icon recess is 100% parametric CAD',
    ],
  },
];

interface FidelityTestCase {
  id: string;
  title: string;
  category: string;
  prompt: string;
  expectedDimensions: { x: number; y: number; z: number };
  tolerancePercent: number;
  expectedVerifications: string[];
}

export const PROMPT_FIDELITY_TESTS: FidelityTestCase[] = [
  {
    id: 'test-1',
    title: 'Test 1: Rectangular Plate with Corner Holes',
    category: 'Dimensions & Holes',
    prompt: 'Create a rectangular mounting plate 120 mm × 80 mm × 5 mm with four 6 mm mounting holes positioned exactly 10 mm from each corner.',
    expectedDimensions: { x: 120, y: 80, z: 5 },
    tolerancePercent: 20,
    expectedVerifications: [
      'Dimensions: ~120 × ~80 × ~5 mm',
      'Positive volume (>0 mm³)',
      'Closed triangular manifold (0 non-manifold edges)',
      '4 corner mounting holes',
    ],
  },
  {
    id: 'test-2',
    title: 'Test 2: Inch-to-Millimeter Electronics Enclosure',
    category: 'Unit Conversion (Inches)',
    prompt: 'Create a 4 in × 2 in × 1 in electronics enclosure with 0.125 in walls, four M3 mounting corner holes, and a removable top lid.',
    expectedDimensions: { x: 101.6, y: 50.8, z: 25.4 },
    tolerancePercent: 20,
    expectedVerifications: [
      'Converted dimensions: ~101.6 × ~50.8 × ~25.4 mm',
      'Positive volume (>0 mm³)',
      'Closed triangular manifold',
      'Corner mounting holes',
    ],
  },
  {
    id: 'test-3',
    title: 'Test 3: Radial Bolt Flange',
    category: 'Radial Pattern',
    prompt: 'Create a circular flange 100 mm diameter, 8 mm thick, with a 30 mm central bore and 6 equidistant 5 mm bolt holes around a 75 mm bolt circle.',
    expectedDimensions: { x: 100, y: 100, z: 8 },
    tolerancePercent: 20,
    expectedVerifications: [
      'Outer diameter: ~100 mm, thickness: ~8 mm',
      'Central bore: ~30 mm diameter',
      '6 bolt holes on bolt circle',
      'Positive volume (>0 mm³)',
    ],
  },
  {
    id: 'test-4',
    title: 'Test 4: Phone Stand with Angled Slot & Cable Relief',
    category: 'Functional Angles',
    prompt: 'Design a desktop phone stand 80 mm wide with a 12 mm deep slot, 70 degree viewing angle rest, and a bottom cutout slot for a charging cable.',
    expectedDimensions: { x: 80, y: 70, z: 75 },
    tolerancePercent: 25,
    expectedVerifications: [
      'Width: ~80 mm',
      'Support stand structure',
      'Bottom charging cable cutout slot',
      'Positive volume (>0 mm³)',
    ],
  },
  {
    id: 'test-5',
    title: 'Test 5: Screwdriver Rack with Exact Count',
    category: 'Exact Quantities',
    prompt: 'Create a wall-mounted tool organizer rack designed to hold exactly 5 screwdrivers with 8 mm wide shaft slots spaced 25 mm apart.',
    expectedDimensions: { x: 150, y: 45, z: 30 },
    tolerancePercent: 30,
    expectedVerifications: [
      '5 screwdriver tool slots',
      'Wall mounting screw holes',
      'Positive volume (>0 mm³)',
      'Closed triangular manifold',
    ],
  },
];

interface Phase2TestResult {
  testId: string;
  passed: boolean;
  title: string;
  details: string;
  durationMs: number;
}

interface Phase2TestCase {
  id: string;
  title: string;
  category: string;
  description: string;
  run: () => Promise<{ passed: boolean; details: string }>;
}

export const PHASE2_REGRESSION_TESTS: Phase2TestCase[] = [
  {
    id: 'p2-1',
    title: 'Test A: Cumulative Multi-Turn Revision Parsing',
    category: 'Cumulative Design',
    description: 'Verifies parsing revision instructions and preserving existing constraints (Base dimensions + cable slots + mounting holes).',
    run: async () => {
      const v1Code = `const { cube } = require('@jscad/modeling').primitives; function main() { return cube({ size: [100, 60, 25] }); } module.exports = { main };`;
      const dummyVersion: ModelVersion = {
        id: 'v1',
        projectId: 'p1',
        versionNumber: 1,
        label: 'V1 Initial',
        createdAt: new Date().toISOString(),
        changeType: 'INITIAL_GENERATION',
        changeSummary: 'Initial enclosure',
        cadCode: v1Code,
        geometryMetadata: {
          dimensions: { x: 100, y: 60, z: 25 },
          volumeMm3: 150000,
          volumeCm3: 150,
          surfaceAreaMm2: 20000,
          estimatedWeightGrams: 186,
          triangleCount: 400,
          vertexCount: 1200,
          isManifold: true,
          overhangRatio: 0,
          minWallThicknessMm: 3,
          footprintAreaMm2: 6000,
          heightToWidthRatio: 0.25,
          hasSteepOverhangs: false,
        },
        designSpecification: {
          originalPrompt: 'Electronics Enclosure',
          primaryObject: 'Electronics Enclosure',
          category: 'enclosure',
          intendedFunction: 'housing',
          mountingStyle: 'screws',
          compatibilityTargets: [],
          explicitDimensions: [
            { name: 'Width', value: 100, axis: 'x', source: 'explicit' },
            { name: 'Depth', value: 60, axis: 'y', source: 'explicit' },
            { name: 'Height', value: 25, axis: 'z', source: 'explicit' },
          ],
          inferredDimensions: [],
          criticalDimensions: [],
          requiredFeatures: [
            { id: 'f1', name: 'Base housing', description: 'Base enclosure', source: 'explicit', confidence: 1 },
            { id: 'f2', name: 'Cable routing slot', description: 'Cable slot', source: 'explicit', confidence: 1 },
          ],
          optionalFeatures: [],
          mountingRequirements: ['Corner screw holes'],
          fitRequirements: [],
          ergonomicRequirements: [],
          structuralRequirements: ['3mm walls'],
          aestheticRequirements: [],
          printRequirements: [],
          assumptions: [],
          unresolvedQuestions: [],
          generationStrategy: 'box_with_slots',
          confidence: 95,
        },
      };

      const parsed1 = parseRevisionInstruction('Make the base 20 mm wider and add 2 M4 mounting holes in the corners', dummyVersion);
      const hasWidthChange = parsed1.requestedChanges.some(c => c.feature.toLowerCase().includes('width') || String(c.toValue).includes('120'));
      const hasHoles = parsed1.requestedChanges.some(c => c.feature.toLowerCase().includes('hole') || c.change.toLowerCase().includes('hole'));
      const preservesCable = parsed1.preservedFeatures.some(f => f.toLowerCase().includes('cable'));

      const passed = hasWidthChange && hasHoles && preservesCable;
      return {
        passed,
        details: passed
          ? 'Successfully parsed width change (+20mm), added 2 M4 holes, and protected existing cable slot constraint.'
          : `Failed: width=${hasWidthChange}, holes=${hasHoles}, preservedCable=${preservesCable}`,
      };
    },
  },
  {
    id: 'p2-2',
    title: 'Test B: Non-Destructive Version Restore',
    category: 'Version History',
    description: 'Verifies that restoring an earlier version (V2 from V3) creates a new V4 restored version without destroying V2 or V3.',
    run: async () => {
      const baseGeom = {
        dimensions: { x: 100, y: 60, z: 25 },
        volumeMm3: 150000,
        volumeCm3: 150,
        surfaceAreaMm2: 20000,
        estimatedWeightGrams: 186,
        triangleCount: 400,
        vertexCount: 1200,
        isManifold: true,
        overhangRatio: 0,
        minWallThicknessMm: 3,
        footprintAreaMm2: 6000,
        heightToWidthRatio: 0.25,
        hasSteepOverhangs: false,
      };

      const dummySpec = {
        originalPrompt: 'Box',
        primaryObject: 'Box',
        category: 'box',
        intendedFunction: 'container',
        mountingStyle: 'none',
        compatibilityTargets: [],
        explicitDimensions: [],
        inferredDimensions: [],
        criticalDimensions: [],
        requiredFeatures: [],
        optionalFeatures: [],
        mountingRequirements: [],
        fitRequirements: [],
        ergonomicRequirements: [],
        structuralRequirements: [],
        aestheticRequirements: [],
        printRequirements: [],
        assumptions: [],
        unresolvedQuestions: [],
        generationStrategy: 'box',
        confidence: 90,
      };

      const v1 = buildModelVersion({ projectId: '1', versionNumber: 1, label: 'Initial V1', cadCode: 'cube 1', geometryMetadata: baseGeom, designSpecification: dummySpec, changeType: 'INITIAL_GENERATION', changeSummary: 'Initial V1' });
      const v2 = buildModelVersion({ projectId: '1', versionNumber: 2, label: 'Added Cable Slot', cadCode: 'cube 2', geometryMetadata: baseGeom, designSpecification: dummySpec, changeType: 'REVISION', changeSummary: 'Added Cable Slot' });
      const v3 = buildModelVersion({ projectId: '1', versionNumber: 3, label: 'Experimental Lid', cadCode: 'cube 3', geometryMetadata: baseGeom, designSpecification: dummySpec, changeType: 'REVISION', changeSummary: 'Experimental Lid' });

      const updatedVersions = restoreVersionAsNewHead([v1, v2, v3], v2.id);
      const v4Restored = updatedVersions[updatedVersions.length - 1];

      const isV4 = v4Restored.versionNumber === 4;
      const isRestoredLabel = v4Restored.label.includes('Restored from V2');
      const codeMatchesV2 = v4Restored.cadCode === v2.cadCode;

      const passed = isV4 && isRestoredLabel && codeMatchesV2;
      return {
        passed,
        details: passed
          ? `Created non-destructive V${v4Restored.versionNumber} ("${v4Restored.label}") with identical CAD code from V2.`
          : `Failed: verNum=${v4Restored.versionNumber}, label=${v4Restored.label}`,
      };
    },
  },
  {
    id: 'p2-3',
    title: 'Test C: Pronoun & Semantic Reference Resolution',
    category: 'Conversational Context',
    description: 'Tests resolving instructions like "Move those holes 5 mm farther apart" by matching context entities.',
    run: async () => {
      const dummyVersion: ModelVersion = {
        id: 'v1',
        projectId: 'p1',
        versionNumber: 1,
        label: 'V1',
        createdAt: new Date().toISOString(),
        changeType: 'INITIAL_GENERATION',
        changeSummary: 'Initial',
        cadCode: '...',
        geometryMetadata: {
          dimensions: { x: 100, y: 60, z: 25 },
          volumeMm3: 150000,
          volumeCm3: 150,
          surfaceAreaMm2: 20000,
          estimatedWeightGrams: 186,
          triangleCount: 400,
          vertexCount: 1200,
          isManifold: true,
          overhangRatio: 0,
          minWallThicknessMm: 3,
          footprintAreaMm2: 6000,
          heightToWidthRatio: 0.25,
          hasSteepOverhangs: false,
        },
        designSpecification: {
          originalPrompt: 'Box with mounting holes',
          primaryObject: 'Box',
          category: 'box',
          intendedFunction: 'enclosure',
          mountingStyle: 'holes',
          compatibilityTargets: [],
          explicitDimensions: [],
          inferredDimensions: [],
          criticalDimensions: [],
          requiredFeatures: [
            { id: 'f1', name: 'Mounting holes', description: 'Four M4 corner holes', source: 'explicit', confidence: 1 },
          ],
          optionalFeatures: [],
          mountingRequirements: [],
          fitRequirements: [],
          ergonomicRequirements: [],
          structuralRequirements: [],
          aestheticRequirements: [],
          printRequirements: [],
          assumptions: [],
          unresolvedQuestions: [],
          generationStrategy: 'box',
          confidence: 90,
        },
      };

      const instruction = 'Move those mounting holes 5 mm farther apart toward the outside corners';
      const parsed = parseRevisionInstruction(instruction, dummyVersion);
      
      const targetsHoles = parsed.requestedChanges.some(f => f.feature.toLowerCase().includes('hole') || f.change.toLowerCase().includes('hole'));
      const hasExplanation = parsed.explanation && parsed.explanation.length > 0;

      const passed = targetsHoles && !!hasExplanation;
      return {
        passed,
        details: passed
          ? 'Successfully resolved pronoun "those mounting holes" to feature hole entity with displacement intent.'
          : `Failed: targetsHoles=${targetsHoles}`,
      };
    },
  },
  {
    id: 'p2-4',
    title: 'Test D: Natural Undo & Rollback Detection',
    category: 'Conversational Context',
    description: 'Verifies natural language rollback prompts like "Undo that last change" and "Go back to the previous version".',
    run: async () => {
      const dummyVersion: ModelVersion = {
        id: 'v2',
        projectId: 'p1',
        versionNumber: 2,
        label: 'V2',
        createdAt: new Date().toISOString(),
        changeType: 'REVISION',
        changeSummary: 'Added holes',
        cadCode: '...',
        geometryMetadata: {
          dimensions: { x: 100, y: 60, z: 25 },
          volumeMm3: 150000,
          volumeCm3: 150,
          surfaceAreaMm2: 20000,
          estimatedWeightGrams: 186,
          triangleCount: 400,
          vertexCount: 1200,
          isManifold: true,
          overhangRatio: 0,
          minWallThicknessMm: 3,
          footprintAreaMm2: 6000,
          heightToWidthRatio: 0.25,
          hasSteepOverhangs: false,
        },
        designSpecification: {
          originalPrompt: 'Box',
          primaryObject: 'Box',
          category: 'box',
          intendedFunction: 'box',
          mountingStyle: 'none',
          compatibilityTargets: [],
          explicitDimensions: [],
          inferredDimensions: [],
          criticalDimensions: [],
          requiredFeatures: [],
          optionalFeatures: [],
          mountingRequirements: [],
          fitRequirements: [],
          ergonomicRequirements: [],
          structuralRequirements: [],
          aestheticRequirements: [],
          printRequirements: [],
          assumptions: [],
          unresolvedQuestions: [],
          generationStrategy: 'box',
          confidence: 90,
        },
      };

      const dummyProject: KatPrintProject = {
        id: 'p1',
        name: 'Test',
        originalPrompt: 'Box',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        currentVersionId: 'v2',
        versions: [
          { ...dummyVersion, id: 'v1', versionNumber: 1, label: 'V1 Initial' },
          dummyVersion,
        ],
        conversation: [],
        projectSettings: {
          printerId: 'bambu-x1c',
          filamentId: 'pla',
          generationMode: 'precision',
          autoApplyProposedChanges: true,
          enableThinking: true,
          scaleFactor: 1.0,
          mustHoldLiquid: false,
        },
        referenceObjects: [],
      };

      const p1 = parseRevisionInstruction('Undo that last change', dummyVersion, dummyProject);
      const p2 = parseRevisionInstruction('Actually go back to the version before we added the screw holes', dummyVersion, dummyProject);

      const isRollback1 = !!p1.isNaturalUndo;
      const isRollback2 = !!p2.isNaturalUndo;

      const passed = isRollback1 && isRollback2;
      return {
        passed,
        details: passed
          ? 'Detected rollback requests correctly for both direct "Undo that" and contextual "Go back to before".'
          : `Failed: p1Rollback=${isRollback1}, p2Rollback=${isRollback2}`,
      };
    },
  },
  {
    id: 'p2-5',
    title: 'Test E: Version Comparison & Dimensional Diff Engine',
    category: 'Version Comparison',
    description: 'Computes exact geometric deltas, volume percentage change, and added/removed feature lists between two versions.',
    run: async () => {
      const vA: ModelVersion = {
        id: 'ver_a',
        projectId: 'p1',
        versionNumber: 2,
        label: 'Base Stand',
        cadCode: '...',
        createdAt: new Date().toISOString(),
        changeType: 'INITIAL_GENERATION',
        changeSummary: 'Base model',
        geometryMetadata: {
          dimensions: { x: 100, y: 80, z: 50 },
          volumeMm3: 200000,
          volumeCm3: 200,
          surfaceAreaMm2: 25000,
          estimatedWeightGrams: 248,
          triangleCount: 450,
          vertexCount: 1350,
          isManifold: true,
          overhangRatio: 0,
          minWallThicknessMm: 3,
          footprintAreaMm2: 8000,
          heightToWidthRatio: 0.5,
          hasSteepOverhangs: false,
        },
        designSpecification: {
          originalPrompt: 'Stand',
          primaryObject: 'Stand',
          category: 'stand',
          intendedFunction: 'support',
          mountingStyle: 'desk',
          compatibilityTargets: [],
          explicitDimensions: [
            { name: 'Width', value: 100, axis: 'x', source: 'explicit' },
            { name: 'Depth', value: 80, axis: 'y', source: 'explicit' },
            { name: 'Height', value: 50, axis: 'z', source: 'explicit' },
          ],
          inferredDimensions: [],
          criticalDimensions: [],
          requiredFeatures: [
            { id: 'f1', name: 'Tilt cradle', description: 'Tilt cradle', source: 'explicit', confidence: 1 },
            { id: 'f2', name: 'Base plate', description: 'Base plate', source: 'explicit', confidence: 1 },
          ],
          optionalFeatures: [],
          mountingRequirements: [],
          fitRequirements: [],
          ergonomicRequirements: [],
          structuralRequirements: [],
          aestheticRequirements: [],
          printRequirements: [],
          assumptions: [],
          unresolvedQuestions: [],
          generationStrategy: 'stand',
          confidence: 90,
        },
      };

      const vB: ModelVersion = {
        id: 'ver_b',
        projectId: 'p1',
        versionNumber: 5,
        label: 'Wide Stand with Cable Slot',
        cadCode: '...',
        createdAt: new Date().toISOString(),
        changeType: 'REVISION',
        changeSummary: 'Made 20mm wider, added cable slot',
        geometryMetadata: {
          dimensions: { x: 120, y: 80, z: 50 },
          volumeMm3: 220000,
          volumeCm3: 220,
          surfaceAreaMm2: 28000,
          estimatedWeightGrams: 272,
          triangleCount: 520,
          vertexCount: 1560,
          isManifold: true,
          overhangRatio: 0,
          minWallThicknessMm: 3,
          footprintAreaMm2: 9600,
          heightToWidthRatio: 0.41,
          hasSteepOverhangs: false,
        },
        designSpecification: {
          originalPrompt: 'Stand',
          primaryObject: 'Stand',
          category: 'stand',
          intendedFunction: 'support',
          mountingStyle: 'desk',
          compatibilityTargets: [],
          explicitDimensions: [
            { name: 'Width', value: 120, axis: 'x', source: 'explicit' },
            { name: 'Depth', value: 80, axis: 'y', source: 'explicit' },
            { name: 'Height', value: 50, axis: 'z', source: 'explicit' },
          ],
          inferredDimensions: [],
          criticalDimensions: [],
          requiredFeatures: [
            { id: 'f1', name: 'Tilt cradle', description: 'Tilt cradle', source: 'explicit', confidence: 1 },
            { id: 'f2', name: 'Base plate', description: 'Base plate', source: 'explicit', confidence: 1 },
            { id: 'f3', name: 'Cable routing slot', description: 'Cable routing slot', source: 'explicit', confidence: 1 },
            { id: 'f4', name: 'Mounting holes', description: 'Mounting holes', source: 'explicit', confidence: 1 },
          ],
          optionalFeatures: [],
          mountingRequirements: [],
          fitRequirements: [],
          ergonomicRequirements: [],
          structuralRequirements: [],
          aestheticRequirements: [],
          printRequirements: [],
          assumptions: [],
          unresolvedQuestions: [],
          generationStrategy: 'stand',
          confidence: 90,
        },
      };

      const diff = compareVersions(vA, vB);

      const correctWidthDiff = diff.dimensionDiffs.width.diff === 20;
      const correctVolumePct = diff.volumeDiff.percentChange === 10;
      const detectedCableSlot = diff.addedFeatures.some(f => f.toLowerCase().includes('cable'));

      const passed = correctWidthDiff && correctVolumePct && detectedCableSlot;
      return {
        passed,
        details: passed
          ? 'Diff verified: Width +20.0 mm, Volume +10.0%, and added "Cable routing slot" feature detected.'
          : `Failed: widthDiff=${diff.dimensionDiffs.width.diff}, volPct=${diff.volumeDiff.percentChange}, addedFeat=${diff.addedFeatures.join(',')}`,
      };
    },
  },
  {
    id: 'p2-6',
    title: 'Test F: IndexedDB / Project Repository Round-Trip',
    category: 'Persistence',
    description: 'Creates a test project in IndexedDB, writes version history, retrieves by ID, and verifies data integrity.',
    run: async () => {
      const testProj: KatPrintProject = {
        id: `test_proj_${Date.now()}`,
        name: 'Automated Test Enclosure',
        originalPrompt: 'Enclosure test',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        currentVersionId: 'v1',
        versions: [],
        conversation: [],
        projectSettings: {
          printerId: 'bambu-x1c',
          filamentId: 'pla',
          generationMode: 'precision',
          autoApplyProposedChanges: true,
          enableThinking: true,
          scaleFactor: 1.0,
          mustHoldLiquid: false,
        },
        referenceObjects: [],
      };

      await projectRepository.createProject(testProj);
      const loaded = await projectRepository.getProject(testProj.id);
      
      const isMatch = loaded && loaded.id === testProj.id;
      
      // Clean up test project
      await projectRepository.deleteProject(testProj.id);

      const passed = !!isMatch;
      return {
        passed,
        details: passed
          ? 'Successfully stored, indexed, and reloaded project with complete version tree from local storage.'
          : 'Failed to reload saved test project from repository.',
      };
    },
  },
  {
    id: 'p2-7',
    title: 'Test G: .katprint Package Serialization & Deserialization',
    category: 'Portability',
    description: 'Validates export package JSON structure, checksum schema, and deserialization into active KatPrintProject entity.',
    run: async () => {
      const original: KatPrintProject = {
        id: 'proj_export_test',
        name: 'Export Test Model',
        originalPrompt: 'Make a bracket',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        currentVersionId: 'v1',
        versions: [],
        conversation: [
          { id: 'msg1', projectId: 'proj_export_test', role: 'user', content: 'Make a bracket', timestamp: new Date().toISOString() },
        ],
        projectSettings: {
          printerId: 'prusa-mk4',
          filamentId: 'petg',
          generationMode: 'precision',
          autoApplyProposedChanges: true,
          enableThinking: true,
          scaleFactor: 1.0,
          mustHoldLiquid: false,
        },
        referenceObjects: [],
      };

      const packageJson = JSON.stringify({
        app: 'KatPrint CAD',
        format: 'katprint-project-package',
        schemaVersion: '2.0',
        project: original,
      });

      const parsed = JSON.parse(packageJson);
      const isValid = parsed.format === 'katprint-project-package' && parsed.project?.id === original.id;

      return {
        passed: isValid,
        details: isValid
          ? 'Verified .katprint JSON package schema and exact entity round-trip preservation.'
          : 'Failed: package schema invalid or corrupted.',
      };
    },
  },
  {
    id: 'p2-8',
    title: 'Test H: Project Normalization & Schema Migration (V1 -> V2)',
    category: 'Schema & Migration',
    description: 'Ensures legacy V1 schema structures are upgraded with non-null defaults without fabricating fake geometry data or inflated match scores.',
    run: async () => {
      const legacyV1 = {
        id: 'legacy_proj_123',
        name: 'Legacy Project',
        versions: [
          {
            id: 'legacy_v1',
            versionNumber: 1,
            cadCode: '// jscad\nconst main = () => cube({ size: 10 });',
            // No geometryMetadata, no designMatchScore
          },
        ],
        // No projectSettings
      };

      const normalized = normalizeKatPrintProject(legacyV1);

      const hasSettings = normalized.projectSettings !== undefined && normalized.projectSettings.printerId === 'bambu-x1c';
      const versionNorm = normalized.versions[0];
      const matchScoreNull = versionNorm.designMatchScore === null;
      const geomMetaEmptyOrNull = !versionNorm.geometryMetadata; // Must not fabricate fake geometry

      const passed = hasSettings && matchScoreNull && geomMetaEmptyOrNull;
      return {
        passed,
        details: passed
          ? 'Successfully migrated legacy V1 project: injected default projectSettings, preserved designMatchScore as null (no fake confidence), and did not fabricate geometry.'
          : `Failed: hasSettings=${hasSettings}, matchScoreNull=${matchScoreNull}, geomMetaEmptyOrNull=${geomMetaEmptyOrNull}`,
      };
    },
  },
  {
    id: 'p2-9',
    title: 'Test I: Machine & Filament Settings Persistence',
    category: 'Persistence',
    description: 'Validates that printer, filament, scale factor, and watertight liquid mode settings are persisted and restored accurately.',
    run: async () => {
      const proj = createBlankProject('Hardware Test Project', {
        printerId: 'prusa-xl',
        filamentId: 'petg',
        scaleFactor: 1.25,
        mustHoldLiquid: true,
      });

      const hasPrusa = proj.projectSettings.printerId === 'prusa-xl';
      const hasPetg = proj.projectSettings.filamentId === 'petg';
      const hasScale = proj.projectSettings.scaleFactor === 1.25;
      const hasLiquid = proj.projectSettings.mustHoldLiquid === true;

      const passed = hasPrusa && hasPetg && hasScale && hasLiquid;
      return {
        passed,
        details: passed
          ? 'Verified hardware settings persistence: Prusa XL, PETG, 1.25x scale factor, and Watertight/Liquid mode active.'
          : `Failed: printer=${proj.projectSettings.printerId}, filament=${proj.projectSettings.filamentId}, scale=${proj.projectSettings.scaleFactor}, liquid=${proj.projectSettings.mustHoldLiquid}`,
      };
    },
  },
  {
    id: 'p2-10',
    title: 'Test J: Generation Identity & STL Export Validation Gate',
    category: 'Data Integrity',
    description: 'Enforces that STL export is blocked if active geometry generation ID mismatches the current generation ID or is non-manifold.',
    run: async () => {
      const genIdA = 'gen_active_123';
      const genIdB = 'gen_stale_456';

      const validateExport = (
        isGenerating: boolean,
        activeGeomGenId: string | null,
        currentGenId: string | null,
        isManifold: boolean,
        isNonEmpty: boolean
      ) => {
        if (isGenerating) return { allowed: false, reason: 'Generation in progress' };
        if (activeGeomGenId && currentGenId && activeGeomGenId !== currentGenId) {
          return { allowed: false, reason: 'Active 3D geometry does not match latest generation' };
        }
        if (!isManifold) return { allowed: false, reason: 'Non-manifold mesh' };
        if (!isNonEmpty) return { allowed: false, reason: 'Empty mesh' };
        return { allowed: true, reason: '' };
      };

      const checkStale = validateExport(false, genIdA, genIdB, true, true);
      const checkNonManifold = validateExport(false, genIdA, genIdA, false, true);
      const checkValid = validateExport(false, genIdA, genIdA, true, true);

      const passed = !checkStale.allowed && !checkNonManifold.allowed && checkValid.allowed;
      return {
        passed,
        details: passed
          ? 'Generation identity export gate strictly prevents stale geometry and non-manifold mesh exports.'
          : `Failed: staleAllowed=${checkStale.allowed}, nonManifoldAllowed=${checkNonManifold.allowed}, validAllowed=${checkValid.allowed}`,
      };
    },
  },
  {
    id: 'p2-11',
    title: 'Test K: Project Graph Deep Clone & ID Collision Prevention',
    category: 'Portability',
    description: 'Verifies that duplicateProjectGraph creates unique project and version IDs with properly remapped parent and conversation links.',
    run: async () => {
      const orig = createBlankProject('Original Project');
      orig.versions = [
        {
          id: 'ver_orig_1',
          projectId: orig.id,
          versionNumber: 1,
          label: 'V1',
          createdAt: new Date().toISOString(),
          cadCode: 'cube({ size: 10 });',
          changeType: 'INITIAL_GENERATION',
          changeSummary: 'Initial model',
        },
      ];
      orig.currentVersionId = 'ver_orig_1';
      orig.conversation = [
        {
          id: 'msg_orig_1',
          projectId: orig.id,
          role: 'user',
          content: 'Create a box',
          timestamp: new Date().toISOString(),
          versionId: 'ver_orig_1',
          relatedVersionId: 'ver_orig_1',
        },
      ];

      const duplicated = duplicateProjectGraph(orig, 'Cloned Project');

      const isDiffProjId = duplicated.id !== orig.id;
      const isDiffVerId = duplicated.versions[0].id !== orig.versions[0].id;
      const isRemappedHead = duplicated.currentVersionId === duplicated.versions[0].id;
      const isRemappedMsg = duplicated.conversation[0].versionId === duplicated.versions[0].id;

      const passed = isDiffProjId && isDiffVerId && isRemappedHead && isRemappedMsg;
      return {
        passed,
        details: passed
          ? 'Deep project graph clone verified: Project ID, version IDs, current head pointer, and conversation references fully isolated with 0 collisions.'
          : `Failed: diffProj=${isDiffProjId}, diffVer=${isDiffVerId}, remappedHead=${isRemappedHead}, remappedMsg=${isRemappedMsg}`,
      };
    },
  },
  {
    id: 'p3-1',
    title: 'Test L: Phase 3.1 Semantic FeatureModel Planning & Strict Extraction',
    category: 'Semantic FeatureModel',
    description: 'Verifies planning a SemanticFeatureModel from DesignSpecification and extracting exact constant bindings without fuzzy guessing.',
    run: async () => {
      const prompt = 'Create an electronics box 120 mm wide, 80 mm deep, 40 mm high with 3 mm wall thickness and four 4 mm mounting holes.';
      const spec = buildDesignSpecification(prompt, {
        objectName: 'Electronics Box',
        classification: 'parametric',
        units: 'mm',
        overallDimensions: { width: 120, depth: 80, height: 40 },
        wallThicknessMm: 3,
        features: ['Box shell', 'Hollow cavity', 'Mounting holes'],
        quantities: { holes: 4 },
        spatialArrangements: [],
        printConsiderations: [],
        warnings: [],
      });

      const model = planSemanticFeatureModel(spec, prompt);
      const hasBase = model.features.some((f) => f.type === 'BASE_BODY' || f.type === 'PLATE');
      const hasHoles = model.features.some((f) => f.type === 'HOLE');
      const hasWallParam = model.parameters.some((p) => p.name.toLowerCase().includes('wall') || p.id === 'wall_thickness');

      const sampleCode = `
const WIDTH = 120;
const DEPTH = 80;
const HEIGHT = 40;
const WALL_THICKNESS = 3;
const HOLE_DIAMETER = 4;

function kpFeature_feat_base_prism() {
  return cube({ size: [WIDTH, DEPTH, HEIGHT] });
}

function kpFeature_feat_mounting_holes() {
  return createThroughHole(HOLE_DIAMETER, 20);
}

function main() {
  const solid = kpFeature_feat_base_prism();
  const holes = kpFeature_feat_mounting_holes();
  return subtract(solid, holes);
}
module.exports = { main };
`;

      const bindings = extractFeatureCodeBindings(sampleCode, model, 'strict');
      const hasBindingForBase = bindings.some((b) => b.featureFunctionName === 'kpFeature_feat_base_prism');

      const passed = hasBase && hasHoles && hasWallParam && hasBindingForBase;
      return {
        passed,
        details: passed
          ? `Planned ${model.features.length} semantic features and ${model.parameters.length} parameters. Strict AST parser extracted wrapper bindings accurately.`
          : `Failed: hasBase=${hasBase}, hasHoles=${hasHoles}, hasWallParam=${hasWallParam}, hasBindingForBase=${hasBindingForBase}`,
      };
    },
  },
  {
    id: 'p3-2',
    title: 'Test M: Phase 3.1 Strict Parameter Locking & Explicit Override Rule',
    category: 'Parameter Locking',
    description: 'Verifies that locked parameters reject general revision overrides but accept explicit override commands.',
    run: async () => {
      const lockedParam: FeatureParameter = {
        id: 'wall_thickness',
        featureId: 'feat_wall',
        name: 'Wall Thickness',
        semanticName: 'Wall Thickness',
        value: 3,
        unit: 'mm',
        source: 'explicit',
        locked: true,
      };

      const isExplicitGeneral = isExplicitParameterOverride(
        lockedParam,
        'Make the enclosure wider and deeper'
      );

      const isExplicitDirect = isExplicitParameterOverride(
        lockedParam,
        'Change the locked wall thickness to 4 mm'
      );

      const passed = !isExplicitGeneral && isExplicitDirect;
      return {
        passed,
        details: passed
          ? 'Parameter locking verified: General revisions do not modify locked parameters; explicit user instructions override successfully.'
          : `Failed: isExplicitGeneral=${isExplicitGeneral}, isExplicitDirect=${isExplicitDirect}`,
      };
    },
  },
  {
    id: 'p3-3',
    title: 'Test N: Phase 3.1 Strict Code Binding Finalization & Validation',
    category: 'Binding Persistence',
    description: 'Validates that finalizeFeatureModelForCode populates codeBindings, bindingValidation, and verifies geometry without fuzzy guessing.',
    run: async () => {
      const prompt = 'Enclosure with lid';
      const spec = buildDesignSpecification(prompt, {
        objectName: 'Enclosure',
        classification: 'parametric',
        units: 'mm',
        overallDimensions: { width: 100, depth: 60, height: 30 },
        features: ['Base Box'],
        quantities: {},
        spatialArrangements: [],
        printConsiderations: [],
        warnings: [],
      });

      const model = planSemanticFeatureModel(spec, prompt);
      const code = `
const WIDTH = 100;
const DEPTH = 60;
const HEIGHT = 30;

function kpFeature_feat_base_prism() {
  return cube({ size: [WIDTH, DEPTH, HEIGHT] });
}

function main() {
  return kpFeature_feat_base_prism();
}
module.exports = { main };
`;

      const finalized = finalizeFeatureModelForCode(
        model,
        code,
        {
          dimensions: { x: 100, y: 60, z: 30 },
          volumeMm3: 180000,
          volumeCm3: 180,
          surfaceAreaMm2: 21600,
          estimatedWeightGrams: 223,
          triangleCount: 12,
          vertexCount: 36,
          isManifold: true,
          overhangRatio: 0,
          minWallThicknessMm: 3,
          footprintAreaMm2: 6000,
          heightToWidthRatio: 0.3,
          hasSteepOverhangs: false,
        },
        'strict'
      );

      const hasBindings = Object.keys(finalized.codeBindings || {}).length > 0;
      const hasValidation = finalized.bindingValidation !== undefined;
      const isBound = (finalized.bindingValidation?.boundFeatures.length ?? 0) > 0;

      const passed = hasBindings && hasValidation && isBound;
      return {
        passed,
        details: passed
          ? `Finalized feature model with ${Object.keys(finalized.codeBindings || {}).length} code bindings and verified feature geometry status.`
          : `Failed: hasBindings=${hasBindings}, hasValidation=${hasValidation}, isBound=${isBound}`,
      };
    },
  },
  {
    id: 'p3-4',
    title: 'Test O: Phase 3.2 3D Semantic Feature Selection & Proxy Geometry Execution',
    category: '3D Feature Selection',
    description: 'Executes individual kpFeature_* wrappers inside the JSCAD sandbox and verifies proxy meshes, metadata, and raycast priority ranking.',
    run: async () => {
      const sampleCode = `
const WIDTH = 100;
const DEPTH = 60;
const HEIGHT = 20;
const HOLE_DIA = 4;

function kpFeature_feat_base_prism() {
  return cube({ size: [WIDTH, DEPTH, HEIGHT] });
}

function kpFeature_feat_mounting_hole_left() {
  return translate([-35, 0, 0], cylinder({ radius: HOLE_DIA / 2, height: 30 }));
}

function kpFeature_feat_mounting_hole_right() {
  return translate([35, 0, 0], cylinder({ radius: HOLE_DIA / 2, height: 30 }));
}

function main() {
  const solid = kpFeature_feat_base_prism();
  const leftHole = kpFeature_feat_mounting_hole_left();
  const rightHole = kpFeature_feat_mounting_hole_right();
  return subtract(solid, union(leftHole, rightHole));
}
module.exports = { main };
`;

      const prompt = 'Enclosure with two mounting holes';
      const spec = buildDesignSpecification(prompt, {
        objectName: 'Enclosure',
        classification: 'parametric',
        units: 'mm',
        overallDimensions: { width: 100, depth: 60, height: 20 },
        features: ['Base Body', 'Left Mounting Hole', 'Right Mounting Hole'],
        quantities: { holes: 2 },
        spatialArrangements: [],
        printConsiderations: [],
        warnings: [],
      });

      const model = planSemanticFeatureModel(spec, prompt);
      const finalized = finalizeFeatureModelForCode(
        model,
        sampleCode,
        {
          dimensions: { x: 100, y: 60, z: 20 },
          volumeMm3: 119000,
          volumeCm3: 119,
          surfaceAreaMm2: 18000,
          estimatedWeightGrams: 147,
          triangleCount: 64,
          vertexCount: 192,
          isManifold: true,
          overhangRatio: 0,
          minWallThicknessMm: 3,
          footprintAreaMm2: 6000,
          heightToWidthRatio: 0.2,
          hasSteepOverhangs: false,
        },
        'strict'
      );

      const proxiesResult = executeSemanticFeatureGeometries(sampleCode, finalized);
      const proxies = proxiesResult.featureGeometries;

      const hasBaseProxy = proxies.some((p) => p.featureId === 'feat_base_prism' || p.featureId.includes('base'));
      const hasHoleProxies = proxies.filter((p) => p.isCutterProxy || p.featureType === 'HOLE').length >= 1;

      // Test selection priority ranking
      const geomMap = new Map();
      for (const p of proxies) {
        geomMap.set(p.featureId, p);
      }

      // Simulate a ray hitting both the hole and the base solid
      const baseId = proxies.find((p) => !p.isCutterProxy)?.featureId || 'feat_base';
      const holeId = proxies.find((p) => p.isCutterProxy)?.featureId || 'feat_hole';

      const simulatedHits = [
        {
          object: { userData: { semanticFeatureId: baseId } },
          distance: 50.0,
        },
        {
          object: { userData: { semanticFeatureId: holeId } },
          distance: 51.5,
        },
      ];

      const ranked = rankSelectionIntersections(simulatedHits as any, geomMap);
      const isSubtractivePrioritized = ranked.primaryFeatureId === holeId;

      const passed = proxies.length >= 2 && hasHoleProxies && isSubtractivePrioritized;
      return {
        passed,
        details: passed
          ? `Successfully generated ${proxies.length} 3D pick proxies. Subtractive hole volume prioritized over base solid in raycast ranking.`
          : `Failed: proxies=${proxies.length}, hasHoles=${hasHoleProxies}, holePrioritized=${isSubtractivePrioritized}`,
      };
    },
  },
  {
    id: 'p3-5',
    title: 'Test P: Phase 3.2 Direct 3D Feature Parameter Revision Lineage',
    category: 'Direct Parameter Revision',
    description: 'Verifies updating a parameter on a 3D-selected feature creates a REVISION model version with zero AI calls and preserved bindings.',
    run: async () => {
      const code = `
const WIDTH = 100;
const DEPTH = 60;
const HEIGHT = 25;

function kpFeature_feat_base_prism() {
  return cube({ size: [WIDTH, DEPTH, HEIGHT] });
}

function main() {
  return kpFeature_feat_base_prism();
}
module.exports = { main };
`;

      const prompt = 'Simple block 100 x 60 x 25';
      const spec = buildDesignSpecification(prompt, {
        objectName: 'Block',
        classification: 'parametric',
        units: 'mm',
        overallDimensions: { width: 100, depth: 60, height: 25 },
        features: ['Base Body'],
        quantities: {},
        spatialArrangements: [],
        printConsiderations: [],
        warnings: [],
      });

      const model = planSemanticFeatureModel(spec, prompt);
      const finalized = finalizeFeatureModelForCode(
        model,
        code,
        {
          dimensions: { x: 100, y: 60, z: 25 },
          volumeMm3: 150000,
          volumeCm3: 150,
          surfaceAreaMm2: 20000,
          estimatedWeightGrams: 186,
          triangleCount: 12,
          vertexCount: 36,
          isManifold: true,
          overhangRatio: 0,
          minWallThicknessMm: 3,
          footprintAreaMm2: 6000,
          heightToWidthRatio: 0.25,
          hasSteepOverhangs: false,
        },
        'strict'
      );

      const targetParam = finalized.parameters.find((p) => p.jscadConstantName === 'WIDTH') || finalized.parameters[0];

      const proj: KatPrintProject = {
        id: 'proj_feat_sel_test',
        name: 'Feature Selection Direct Edit Test',
        originalPrompt: prompt,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        currentVersionId: 'v1',
        versions: [
          {
            id: 'v1',
            projectId: 'proj_feat_sel_test',
            versionNumber: 1,
            label: 'V1 Initial',
            createdAt: new Date().toISOString(),
            changeType: 'INITIAL_GENERATION',
            changeSummary: 'Initial model',
            cadCode: code,
            featureModel: finalized,
            isCurrentHead: true,
          },
        ],
        conversation: [],
        projectSettings: {
          printerId: 'bambu-x1c',
          filamentId: 'pla',
          generationMode: 'precision',
          autoApplyProposedChanges: true,
          enableThinking: true,
          scaleFactor: 1.0,
          mustHoldLiquid: false,
        },
        referenceObjects: [],
      };

      const outcome = await applyDirectParameterUpdateToProject({
        project: proj,
        parameterId: targetParam.id,
        newValue: 140,
        selectedFilamentDensity: 1.24,
      });

      const newVer = outcome.newVersion;
      const isRevision = newVer.changeType === 'REVISION';
      const hasUpdatedCode = newVer.cadCode?.includes('const WIDTH = 140;') || newVer.cadCode?.includes('140');
      const preservedBindings = (newVer.featureModel?.codeBindings?.length ?? 0) > 0;

      const passed = isRevision && !!hasUpdatedCode && preservedBindings;
      return {
        passed,
        details: passed
          ? `Direct parameter update applied seamlessly: V${newVer.versionNumber} created with changeType REVISION, updated constant value, and strict code bindings preserved.`
          : `Failed: isRevision=${isRevision}, hasUpdatedCode=${hasUpdatedCode}, preservedBindings=${preservedBindings}`,
      };
    },
  },
];

interface ClassifierResult {
  testId: string;
  passed: boolean;
  actualClassification: string;
  actualReferenceName: string | null;
  actualReferenceDimensions: string | null;
  details: string;
}

interface FidelityResult {
  testId: string;
  passed: boolean;
  actualDimensions?: { x: number; y: number; z: number };
  volumeMm3?: number;
  isManifold?: boolean;
  triangleCount?: number;
  error?: string;
  durationMs: number;
}

interface TestSuiteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRunTest: (prompt: string) => void;
}

export const TestSuiteModal: React.FC<TestSuiteModalProps> = ({
  isOpen,
  onClose,
  onRunTest,
}) => {
  const [activeTab, setActiveTab] = useState<'classifier' | 'fidelity' | 'phase2'>('phase2');
  
  // Classifier test execution state (Deterministic, 0 AI calls)
  const [isRunningClassifier, setIsRunningClassifier] = useState(false);
  const [classifierResults, setClassifierResults] = useState<Record<string, ClassifierResult> | null>(null);
  const [classifierDurationMs, setClassifierDurationMs] = useState<number | null>(null);

  // Fidelity test execution state (Calls Gemini)
  const [isRunningFidelity, setIsRunningFidelity] = useState(false);
  const [currentFidelityIndex, setCurrentFidelityIndex] = useState<number | null>(null);
  const [fidelityResults, setFidelityResults] = useState<Record<string, FidelityResult>>({});
  const [showFidelityWarning, setShowFidelityWarning] = useState(false);
  const [fidelityDurationMs, setFidelityDurationMs] = useState<number | null>(null);

  // Phase 2 Workspace & Versioning test execution state (Deterministic)
  const [isRunningPhase2, setIsRunningPhase2] = useState(false);
  const [phase2Results, setPhase2Results] = useState<Record<string, Phase2TestResult>>({});
  const [phase2DurationMs, setPhase2DurationMs] = useState<number | null>(null);

  if (!isOpen) return null;

  // Run all Phase 2 tests (Deterministic, tests versioning, revisions, diffs, IndexedDB round-trip)
  const handleRunAllPhase2Tests = async () => {
    setIsRunningPhase2(true);
    const startTime = performance.now();
    const results: Record<string, Phase2TestResult> = {};

    for (const test of PHASE2_REGRESSION_TESTS) {
      const itemStart = performance.now();
      try {
        const out = await test.run();
        const itemDuration = Math.round(performance.now() - itemStart);
        results[test.id] = {
          testId: test.id,
          title: test.title,
          passed: out.passed,
          details: out.details,
          durationMs: itemDuration,
        };
      } catch (err: any) {
        results[test.id] = {
          testId: test.id,
          title: test.title,
          passed: false,
          details: err?.message || 'Execution error',
          durationMs: Math.round(performance.now() - itemStart),
        };
      }
    }

    setPhase2Results(results);
    setPhase2DurationMs(Math.round(performance.now() - startTime));
    setIsRunningPhase2(false);
  };

  // Run all classifier tests (Instant, deterministic, zero network calls)
  const handleRunAllClassifierTests = () => {
    setIsRunningClassifier(true);
    const startTime = performance.now();
    const results: Record<string, ClassifierResult> = {};

    for (const test of CLASSIFIER_REGRESSION_TESTS) {
      const classified = classifyPromptIntent(test.prompt);
      const isClassMatch = classified.classification === test.expectedClassification;
      
      let isRefMatch = true;
      let refDetail = '';
      if (test.expectedReferenceName) {
        const refObj = classified.referenceDetails || matchKnownReference(test.prompt);
        const refName = refObj?.name || classified.referenceObject || '';
        const nameMatches = refName.toLowerCase().includes(test.expectedReferenceName.toLowerCase()) ||
          test.expectedReferenceName.toLowerCase().includes(refName.toLowerCase());
        
        if (!nameMatches) {
          isRefMatch = false;
        }

        if (test.expectedReferenceDimensions && refObj?.dimensions) {
          const dimsMatch =
            Math.abs(refObj.dimensions.width - test.expectedReferenceDimensions.width) < 0.1 &&
            Math.abs(refObj.dimensions.depth - test.expectedReferenceDimensions.depth) < 0.1 &&
            Math.abs(refObj.dimensions.height - test.expectedReferenceDimensions.height) < 0.1;
          if (!dimsMatch) isRefMatch = false;
        }

        refDetail = refObj
          ? `${refObj.name} (${refObj.dimensions.width} × ${refObj.dimensions.depth} × ${refObj.dimensions.height} mm)`
          : 'None detected';
      }

      const passed = isClassMatch && isRefMatch;
      results[test.id] = {
        testId: test.id,
        passed,
        actualClassification: classified.classification,
        actualReferenceName: classified.referenceObject || (classified.referenceDetails?.name ?? null),
        actualReferenceDimensions: classified.referenceDetails
          ? `${classified.referenceDetails.dimensions.width} × ${classified.referenceDetails.dimensions.depth} × ${classified.referenceDetails.dimensions.height} mm`
          : null,
        details: passed
          ? `Exact match: ${classified.classification}${refDetail ? ` with reference ${refDetail}` : ''}`
          : `Mismatch: Got ${classified.classification}, expected ${test.expectedClassification}${
              test.expectedReferenceName ? ` (Ref: ${refDetail})` : ''
            }`,
      };
    }

    const duration = performance.now() - startTime;
    setClassifierResults(results);
    setClassifierDurationMs(Math.round(duration));
    setIsRunningClassifier(false);
  };

  // Run all CAD Fidelity Tests (Calls Gemini with user warning)
  const handleStartFidelityTests = async () => {
    setShowFidelityWarning(false);
    setIsRunningFidelity(true);
    setFidelityResults({});
    const startTime = performance.now();

    for (let i = 0; i < PROMPT_FIDELITY_TESTS.length; i++) {
      setCurrentFidelityIndex(i);
      const test = PROMPT_FIDELITY_TESTS[i];
      const itemStart = performance.now();

      try {
        const response = await requestJscadGeneration(test.prompt);
        const geom = executeJscadCode(response.code);
        const stats = analyzeBufferGeometry(geom);
        const itemDuration = Math.round(performance.now() - itemStart);

        const dims = stats.dimensions;
        const volume = stats.volumeMm3;
        const isManifold = stats.isManifold && stats.nonManifoldEdgeCount === 0;
        const hasTriangles = stats.triangleCount > 0;

        // Verify dimensions against expected bounds (allowing standard orientation permutations)
        const expected = test.expectedDimensions;
        const tol = (test.tolerancePercent || 25) / 100;
        
        const actualSorted = [dims.x, dims.y, dims.z].sort((a, b) => a - b);
        const expectedSorted = [expected.x, expected.y, expected.z].sort((a, b) => a - b);

        const dimsMatch = actualSorted.every((val, idx) => {
          const exp = expectedSorted[idx];
          const minAllowed = exp * (1 - tol);
          const maxAllowed = exp * (1 + tol);
          return val >= minAllowed && val <= maxAllowed;
        });

        // Code feature checks
        const code = response.code.toLowerCase();
        let featuresPresent = true;
        if (test.id === 'test-1') {
          // Plate with 4 corner holes
          featuresPresent = (code.includes('cylinder') || code.includes('circle')) && (code.includes('subtract') || code.includes('difference'));
        } else if (test.id === 'test-2') {
          // Enclosure with lid and walls
          featuresPresent = code.includes('subtract') || code.includes('difference') || code.includes('cuboid');
        } else if (test.id === 'test-3') {
          // Radial flange with central bore and bolt holes
          featuresPresent = (code.includes('cylinder') || code.includes('circle')) && (code.includes('subtract') || code.includes('difference'));
        }

        const passed = volume > 0.1 && hasTriangles && isManifold && dimsMatch && featuresPresent;

        setFidelityResults((prev) => ({
          ...prev,
          [test.id]: {
            testId: test.id,
            passed,
            actualDimensions: dims,
            volumeMm3: volume,
            isManifold,
            triangleCount: stats.triangleCount,
            durationMs: itemDuration,
          },
        }));
      } catch (err: any) {
        const itemDuration = Math.round(performance.now() - itemStart);
        setFidelityResults((prev) => ({
          ...prev,
          [test.id]: {
            testId: test.id,
            passed: false,
            error: err?.message || 'Generation or execution error',
            durationMs: itemDuration,
          },
        }));
      }
    }

    setFidelityDurationMs(Math.round(performance.now() - startTime));
    setIsRunningFidelity(false);
    setCurrentFidelityIndex(null);
  };

  // Compute summary stats for classifier tests
  const classifierPassedCount = classifierResults
    ? Object.values(classifierResults).filter((r: ClassifierResult) => r.passed).length
    : 0;
  const classifierTotalCount = CLASSIFIER_REGRESSION_TESTS.length;
  const classifierFailedCount = classifierResults
    ? classifierTotalCount - classifierPassedCount
    : 0;

  // Compute summary stats for fidelity tests
  const fidelityRanCount = Object.keys(fidelityResults).length;
  const fidelityPassedCount = Object.values(fidelityResults).filter((r: FidelityResult) => r.passed).length;
  const fidelityFailedCount = fidelityRanCount - fidelityPassedCount;

  // Compute summary stats for Phase 2 tests
  const phase2RanCount = Object.keys(phase2Results).length;
  const phase2PassedCount = Object.values(phase2Results).filter((r: Phase2TestResult) => r.passed).length;
  const phase2FailedCount = phase2RanCount - phase2PassedCount;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-fadeIn">
      <div className="trace clip-corner bg-kf-panel border border-kf-border rounded-xl shadow-2xl w-full max-w-4xl flex flex-col max-h-[90vh] overflow-hidden text-kf-text font-sans">
        {/* Header */}
        <div className="trace clip-corner flex items-center justify-between px-5 py-3.5 border-b border-kf-border bg-kf-panel-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-kf-pink/15 border border-kf-pink/30 flex items-center justify-center text-kf-pink">
              <FlaskConical className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold font-mono tracking-tight text-kf-text">
                KatPrint Automated Quality &amp; Fidelity Test Suite
              </h2>
              <p className="text-[11px] text-kf-muted">
                Deterministic classifier regression tests (0 AI quota) &amp; full CAD geometry verification benchmarks.
              </p>
            </div>
          </div>
          <button
            type="button"
            id="btn-close-test-suite"
            onClick={onClose}
            className="text-kf-muted hover:text-kf-text p-1.5 rounded-md hover:bg-kf-border/40 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection & Top Action Bar */}
        <div className="flex items-center justify-between border-b border-kf-border bg-kf-bg px-5 pt-2 font-mono text-xs">
          <div className="flex gap-2">
            <button
              type="button"
              id="tab-phase2-tests"
              onClick={() => setActiveTab('phase2')}
              className={`pb-2.5 px-3 border-b-2 font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'phase2'
                  ? 'border-kf-pink text-kf-pink'
                  : 'border-transparent text-kf-muted hover:text-kf-text'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Phase 2 Workspace &amp; Versioning Tests ({PHASE2_REGRESSION_TESTS.length})</span>
            </button>
            <button
              type="button"
              id="tab-classifier-tests"
              onClick={() => setActiveTab('classifier')}
              className={`pb-2.5 px-3 border-b-2 font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'classifier'
                  ? 'border-kf-pink text-kf-pink'
                  : 'border-transparent text-kf-muted hover:text-kf-text'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Classifier Tests ({CLASSIFIER_REGRESSION_TESTS.length})</span>
            </button>
            <button
              type="button"
              id="tab-fidelity-tests"
              onClick={() => setActiveTab('fidelity')}
              className={`pb-2.5 px-3 border-b-2 font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'fidelity'
                  ? 'border-kf-pink text-kf-pink'
                  : 'border-transparent text-kf-muted hover:text-kf-text'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>CAD Fidelity Benchmarks ({PROMPT_FIDELITY_TESTS.length})</span>
            </button>
          </div>

          <div className="pb-2">
            {activeTab === 'phase2' ? (
              <button
                type="button"
                id="btn-run-all-phase2-tests"
                disabled={isRunningPhase2}
                onClick={handleRunAllPhase2Tests}
                className="flex items-center gap-1.5 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-50 text-[#0A0004] font-bold px-3 py-1.5 rounded-md text-xs transition shadow-sm cursor-pointer"
              >
                {isRunningPhase2 ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Play className="w-3.5 h-3.5 fill-current" />
                )}
                <span>Run Phase 2 Regression Tests</span>
              </button>
            ) : activeTab === 'classifier' ? (
              <button
                type="button"
                id="btn-run-all-classifier-tests"
                disabled={isRunningClassifier}
                onClick={handleRunAllClassifierTests}
                className="flex items-center gap-1.5 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-50 text-[#0A0004] font-bold px-3 py-1.5 rounded-md text-xs transition shadow-sm cursor-pointer"
              >
                {isRunningClassifier ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Play className="w-3.5 h-3.5 fill-current" />
                )}
                <span>Run All Classifier Tests</span>
              </button>
            ) : (
              <button
                type="button"
                id="btn-run-all-fidelity-tests"
                disabled={isRunningFidelity}
                onClick={() => setShowFidelityWarning(true)}
                className="flex items-center gap-1.5 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-50 text-[#0A0004] font-bold px-3 py-1.5 rounded-md text-xs transition shadow-sm cursor-pointer"
              >
                {isRunningFidelity ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Play className="w-3.5 h-3.5 fill-current" />
                )}
                <span>Run All CAD Fidelity Tests</span>
              </button>
            )}
          </div>
        </div>

        {/* Status Scoreboard Banner */}
        {activeTab === 'phase2' && phase2RanCount > 0 && (
          <div className="trace clip-corner bg-kf-panel-2 border-b border-kf-border px-5 py-2.5 flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-4">
              <span className="text-kf-text font-bold uppercase tracking-wider">Phase 2 Results:</span>
              <span className="text-kf-ok bg-kf-ok/10 border border-kf-ok/30 px-2 py-0.5 rounded font-bold">
                Passed: {phase2PassedCount}
              </span>
              <span className={`px-2 py-0.5 rounded font-bold border ${
                phase2FailedCount === 0
                  ? 'text-kf-muted bg-kf-panel border-kf-border'
                  : 'text-kf-fail bg-kf-fail/10 border-kf-fail/30'
              }`}>
                Failed: {phase2FailedCount}
              </span>
              <span className="text-kf-muted">Completed: {phase2RanCount} / {PHASE2_REGRESSION_TESTS.length}</span>
            </div>
            {phase2DurationMs !== null && (
              <span className="text-kf-muted flex items-center gap-1 text-[11px]">
                <Clock className="w-3 h-3 text-kf-pink" />
                <span>Duration: {phase2DurationMs} ms</span>
              </span>
            )}
          </div>
        )}

        {activeTab === 'classifier' && classifierResults && (
          <div className="trace clip-corner bg-kf-panel-2 border-b border-kf-border px-5 py-2.5 flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-4">
              <span className="text-kf-text font-bold uppercase tracking-wider">Results:</span>
              <span className="text-kf-ok bg-kf-ok/10 border border-kf-ok/30 px-2 py-0.5 rounded font-bold">
                Passed: {classifierPassedCount}
              </span>
              <span className={`px-2 py-0.5 rounded font-bold border ${
                classifierFailedCount === 0
                  ? 'text-kf-muted bg-kf-panel border-kf-border'
                  : 'text-kf-fail bg-kf-fail/10 border-kf-fail/30'
              }`}>
                Failed: {classifierFailedCount}
              </span>
              <span className="text-kf-muted">Total: {classifierTotalCount}</span>
            </div>
            {classifierDurationMs !== null && (
              <span className="text-kf-muted flex items-center gap-1 text-[11px]">
                <Clock className="w-3 h-3 text-kf-pink" />
                <span>Duration: {classifierDurationMs} ms (Local execution)</span>
              </span>
            )}
          </div>
        )}

        {activeTab === 'fidelity' && fidelityRanCount > 0 && (
          <div className="trace clip-corner bg-kf-panel-2 border-b border-kf-border px-5 py-2.5 flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-4">
              <span className="text-kf-text font-bold uppercase tracking-wider">CAD Benchmarks:</span>
              <span className="text-kf-ok bg-kf-ok/10 border border-kf-ok/30 px-2 py-0.5 rounded font-bold">
                Passed: {fidelityPassedCount}
              </span>
              <span className={`px-2 py-0.5 rounded font-bold border ${
                fidelityFailedCount === 0
                  ? 'text-kf-muted bg-kf-panel border-kf-border'
                  : 'text-kf-fail bg-kf-fail/10 border-kf-fail/30'
              }`}>
                Failed: {fidelityFailedCount}
              </span>
              <span className="text-kf-muted">Completed: {fidelityRanCount} / {PROMPT_FIDELITY_TESTS.length}</span>
            </div>
            {fidelityDurationMs !== null && (
              <span className="text-kf-muted flex items-center gap-1 text-[11px]">
                <Clock className="w-3 h-3 text-kf-pink" />
                <span>Duration: {(fidelityDurationMs / 1000).toFixed(1)} s</span>
              </span>
            )}
          </div>
        )}

        {/* Warning Modal before running AI Fidelity Tests */}
        {showFidelityWarning && (
          <div className="bg-kf-warn/15 border-b border-kf-warn/30 p-3.5 flex items-start justify-between gap-3 text-xs font-mono">
            <div className="flex items-start gap-2 text-kf-warn">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block">AI Generative Request Notice</span>
                <p className="text-[11px] font-sans text-kf-text mt-0.5">
                  Running all {PROMPT_FIDELITY_TESTS.length} CAD fidelity tests will synthesize new 3D geometry using Gemini and verify manifold geometry measurements in real-time. This consumes AI quota and takes approximately 30–60 seconds.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setShowFidelityWarning(false)}
                className="px-2.5 py-1 rounded bg-kf-panel border border-kf-border text-kf-muted hover:text-kf-text text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                id="btn-confirm-fidelity-tests"
                onClick={handleStartFidelityTests}
                className="px-3 py-1 rounded bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-bold text-xs"
              >
                Proceed &amp; Run
              </button>
            </div>
          </div>
        )}

        {/* Content Body */}
        <div className="p-5 flex flex-col gap-3.5 overflow-y-auto">
          {activeTab === 'phase2' && (
            <div className="flex flex-col gap-3">
              {PHASE2_REGRESSION_TESTS.map((test) => {
                const res = phase2Results[test.id];

                return (
                  <div
                    key={test.id}
                    className={`bg-kf-panel-2 border rounded-lg p-3.5 flex flex-col gap-2.5 transition shadow-sm ${
                      res
                        ? res.passed
                          ? 'border-kf-ok/40 bg-kf-ok/[0.02]'
                          : 'border-kf-fail/40 bg-kf-fail/[0.02]'
                        : 'border-kf-border hover:border-kf-pink/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-kf-text">
                          {test.title}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 font-mono text-[10px]">
                        {res ? (
                          <span
                            className={`px-2 py-0.5 rounded font-bold border flex items-center gap-1 ${
                              res.passed
                                ? 'bg-kf-ok/15 text-kf-ok border-kf-ok/30'
                                : 'bg-kf-fail/15 text-kf-fail border-kf-fail/30'
                            }`}
                          >
                            {res.passed ? <CheckCircle2 className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
                            <span>{res.passed ? 'PASS' : 'FAIL'}</span>
                          </span>
                        ) : (
                          <span className="text-kf-muted bg-kf-panel px-2 py-0.5 rounded border border-kf-border">
                            Not Evaluated
                          </span>
                        )}
                        <span className="px-2 py-0.5 rounded bg-kf-panel text-kf-pink border border-kf-pink/25">
                          {test.category}
                        </span>
                      </div>
                    </div>

                    <div className="bg-kf-bg border border-kf-border p-2.5 rounded text-xs font-mono text-kf-muted leading-relaxed select-text">
                      {test.description}
                    </div>

                    {res && (
                      <div className="trace clip-corner bg-kf-panel p-2.5 rounded border border-kf-border text-[11px] font-mono flex items-center justify-between">
                        <span className={res.passed ? 'text-kf-ok' : 'text-kf-fail'}>
                          {res.details}
                        </span>
                        <span className="text-kf-muted text-[10px] shrink-0 ml-2">
                          {res.durationMs} ms
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'classifier' && (
            <div className="flex flex-col gap-3">
              {CLASSIFIER_REGRESSION_TESTS.map((test) => {
                const res = classifierResults ? classifierResults[test.id] : null;

                return (
                  <div
                    key={test.id}
                    className={`bg-kf-panel-2 border rounded-lg p-3.5 flex flex-col gap-2.5 transition shadow-sm ${
                      res
                        ? res.passed
                          ? 'border-kf-ok/40 bg-kf-ok/[0.02]'
                          : 'border-kf-fail/40 bg-kf-fail/[0.02]'
                        : 'border-kf-border hover:border-kf-pink/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-kf-text">
                          {test.title}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 font-mono text-[10px]">
                        {res ? (
                          <span
                            className={`px-2 py-0.5 rounded font-bold border flex items-center gap-1 ${
                              res.passed
                                ? 'bg-kf-ok/15 text-kf-ok border-kf-ok/30'
                                : 'bg-kf-fail/15 text-kf-fail border-kf-fail/30'
                            }`}
                          >
                            {res.passed ? <CheckCircle2 className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
                            <span>{res.passed ? 'PASS' : 'FAIL'}</span>
                          </span>
                        ) : (
                          <span className="text-kf-muted bg-kf-panel px-2 py-0.5 rounded border border-kf-border">
                            Not Evaluated
                          </span>
                        )}
                        <span className="px-2 py-0.5 rounded bg-kf-panel text-kf-pink border border-kf-pink/25">
                          {test.category}
                        </span>
                      </div>
                    </div>

                    <div className="bg-kf-bg border border-kf-border p-2.5 rounded text-xs font-mono text-kf-muted leading-relaxed select-text">
                      &quot;{test.prompt}&quot;
                    </div>

                    {/* Test Specification Grid: EXPECTED vs ACTUAL */}
                    <div className="trace clip-corner grid grid-cols-2 gap-2 text-[11px] font-mono bg-kf-panel p-2.5 rounded border border-kf-border">
                      <div className="flex flex-col gap-1">
                        <span className="text-[10px] uppercase font-bold text-kf-muted">Expected:</span>
                        <div className="text-kf-text">
                          Classification: <strong className="text-kf-pink">{test.expectedClassification}</strong>
                        </div>
                        {test.expectedReferenceName && (
                          <div className="text-kf-text">
                            Ref Object: <strong>{test.expectedReferenceName}</strong>
                            {test.expectedReferenceDimensions && (
                              <span className="text-kf-muted block text-[10px]">
                                {test.expectedReferenceDimensions.width} × {test.expectedReferenceDimensions.depth} × {test.expectedReferenceDimensions.height} mm
                              </span>
                            )}
                          </div>
                        )}
                      </div>

                      <div className="flex flex-col gap-1 border-l border-kf-border pl-2.5">
                        <span className="text-[10px] uppercase font-bold text-kf-muted">Actual:</span>
                        {res ? (
                          <>
                            <div className={res.actualClassification === test.expectedClassification ? 'text-kf-ok font-bold' : 'text-kf-fail font-bold'}>
                              Classification: {res.actualClassification}
                            </div>
                            {res.actualReferenceName && (
                              <div className="text-kf-text">
                                Ref Object: <strong>{res.actualReferenceName}</strong>
                                {res.actualReferenceDimensions && (
                                  <span className="text-kf-muted block text-[10px]">
                                    {res.actualReferenceDimensions}
                                  </span>
                                )}
                              </div>
                            )}
                            {!res.actualReferenceName && test.expectedReferenceName && (
                              <div className="text-kf-fail text-[10px]">No reference object identified</div>
                            )}
                          </>
                        ) : (
                          <div className="text-kf-muted italic">Click &quot;Run All Classifier Tests&quot; to evaluate</div>
                        )}
                      </div>
                    </div>

                    {/* Expected Verifications */}
                    <div className="flex flex-wrap gap-1.5 pt-0.5">
                      {test.expectedVerifications.map((v, i) => (
                        <span
                          key={i}
                          className="text-[10px] font-mono bg-kf-panel border border-kf-border text-kf-muted px-2 py-0.5 rounded flex items-center gap-1"
                        >
                          <Check className="w-3 h-3 text-kf-ok" />
                          <span>{v}</span>
                        </span>
                      ))}
                    </div>

                    <div className="flex justify-end pt-1">
                      <button
                        type="button"
                        id={`btn-run-${test.id}`}
                        onClick={() => {
                          onRunTest(test.prompt);
                          onClose();
                        }}
                        className="flex items-center gap-1.5 bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-mono text-xs font-bold px-3 py-1.5 rounded transition shadow-sm cursor-pointer"
                      >
                        <span>Run in KatPrint Pipeline</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'fidelity' && (
            <div className="flex flex-col gap-3">
              {PROMPT_FIDELITY_TESTS.map((test, index) => {
                const res = fidelityResults[test.id];
                const isCurrent = isRunningFidelity && currentFidelityIndex === index;

                return (
                  <div
                    key={test.id}
                    className={`bg-kf-panel-2 border rounded-lg p-3.5 flex flex-col gap-2.5 transition shadow-sm ${
                      isCurrent
                        ? 'border-kf-pink animate-pulse bg-kf-pink/[0.03]'
                        : res
                        ? res.passed
                          ? 'border-kf-ok/40 bg-kf-ok/[0.02]'
                          : 'border-kf-fail/40 bg-kf-fail/[0.02]'
                        : 'border-kf-border hover:border-kf-pink/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-kf-text">
                          {test.title}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 font-mono text-[10px]">
                        {isCurrent ? (
                          <span className="px-2 py-0.5 rounded font-bold border bg-kf-pink/15 text-kf-pink border-kf-pink/30 flex items-center gap-1">
                            <RefreshCw className="w-3 h-3 animate-spin" />
                            <span>Synthesizing...</span>
                          </span>
                        ) : res ? (
                          <span
                            className={`px-2 py-0.5 rounded font-bold border flex items-center gap-1 ${
                              res.passed
                                ? 'bg-kf-ok/15 text-kf-ok border-kf-ok/30'
                                : 'bg-kf-fail/15 text-kf-fail border-kf-fail/30'
                            }`}
                          >
                            {res.passed ? <CheckCircle2 className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
                            <span>{res.passed ? 'PASS' : 'FAIL'}</span>
                          </span>
                        ) : (
                          <span className="text-kf-muted bg-kf-panel px-2 py-0.5 rounded border border-kf-border">
                            Awaiting Run
                          </span>
                        )}
                        <span className="px-2 py-0.5 rounded bg-kf-panel text-kf-pink border border-kf-pink/25">
                          {test.category}
                        </span>
                      </div>
                    </div>

                    <div className="bg-kf-bg border border-kf-border p-2.5 rounded text-xs font-mono text-kf-muted leading-relaxed select-text">
                      &quot;{test.prompt}&quot;
                    </div>

                    {/* Geometric Expected vs Actual Grid */}
                    <div className="trace clip-corner grid grid-cols-3 gap-2 text-[11px] font-mono bg-kf-panel p-2.5 rounded border border-kf-border">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-kf-muted block">Expected:</span>
                        <div className="text-kf-text mt-0.5">
                          {test.expectedDimensions.x} × {test.expectedDimensions.y} × {test.expectedDimensions.z} mm
                        </div>
                        <span className="text-[10px] text-kf-muted block">Volume &gt; 0 mm³, Manifold</span>
                      </div>

                      <div>
                        <span className="text-[10px] uppercase font-bold text-kf-muted block">Actual Measurements:</span>
                        {res ? (
                          res.error ? (
                            <div className="text-kf-fail text-[10px]">{res.error}</div>
                          ) : (
                            <div className="text-kf-text mt-0.5">
                              {res.actualDimensions?.x.toFixed(1)} × {res.actualDimensions?.y.toFixed(1)} × {res.actualDimensions?.z.toFixed(1)} mm
                              <span className="text-[10px] text-kf-muted block">
                                {res.volumeMm3?.toFixed(1)} mm³ | {res.triangleCount} tris
                              </span>
                            </div>
                          )
                        ) : (
                          <div className="text-kf-muted italic text-[10px]">Run test to measure</div>
                        )}
                      </div>

                      <div>
                        <span className="text-[10px] uppercase font-bold text-kf-muted block">Tolerance &amp; Status:</span>
                        <div className="text-kf-text mt-0.5">
                          ±{test.tolerancePercent}% Bounds
                        </div>
                        {res && (
                          <span className={`text-[10px] font-bold block ${res.isManifold ? 'text-kf-ok' : 'text-kf-fail'}`}>
                            {res.isManifold ? '100% Watertight Manifold' : 'Non-Manifold Mesh'} ({res.durationMs}ms)
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex justify-end pt-1">
                      <button
                        type="button"
                        id={`btn-load-pipeline-${test.id}`}
                        onClick={() => {
                          onRunTest(test.prompt);
                          onClose();
                        }}
                        className="flex items-center gap-1.5 bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-mono text-xs font-bold px-3 py-1.5 rounded transition shadow-sm cursor-pointer"
                      >
                        <span>Load in KatPrint Editor</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
