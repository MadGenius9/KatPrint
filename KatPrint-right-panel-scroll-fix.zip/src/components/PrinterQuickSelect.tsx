import React from 'react';
import { PrinterSpec, PrinterFitResult } from '../types';
import { ChevronDown, ChevronUp, AlertTriangle, Check } from 'lucide-react';

export interface PrinterQuickSelectProps {
  printers: PrinterSpec[];
  printerGroups: [string, PrinterSpec[]][];
  selectedPrinterId: string;
  selectedPrinter: PrinterSpec;
  fitResult: PrinterFitResult | null;
  onPrinterChange: (id: string) => void;
  onOpenCustomPrinter: () => void;
  collapsed: boolean;
  onToggleCollapsed: () => void;
}

export const PrinterQuickSelect: React.FC<PrinterQuickSelectProps> = ({
  printerGroups,
  selectedPrinterId,
  selectedPrinter,
  fitResult,
  onPrinterChange,
  onOpenCustomPrinter,
  collapsed,
  onToggleCollapsed,
}) => {
  const overflows: string[] = [];
  if (fitResult?.axisOverflow?.x && fitResult.axisOverflow.x > 0) {
    overflows.push(`+${fitResult.axisOverflow.x.toFixed(1)} mm X`);
  }
  if (fitResult?.axisOverflow?.y && fitResult.axisOverflow.y > 0) {
    overflows.push(`+${fitResult.axisOverflow.y.toFixed(1)} mm Y`);
  }
  if (fitResult?.axisOverflow?.z && fitResult.axisOverflow.z > 0) {
    overflows.push(`+${fitResult.axisOverflow.z.toFixed(1)} mm Z`);
  }

  const doesFit = fitResult ? (fitResult.fitsStandard || fitResult.fitsRotated45) : true;
  const overflowDescription = overflows.length > 0 ? overflows.join(', ') : 'dimensions exceed limits';

  return (
    <div className="trace clip-corner p-[1px]">
      <div className="bg-kf-panel p-3 space-y-2.5">
        {/* Header Row */}
        <div className="flex items-center justify-between">
          <span className="section-label">PRINTER</span>
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              id="btn-quickselect-configure"
              onClick={onOpenCustomPrinter}
              className="font-mono text-[10px] text-kf-pink hover:text-kf-pink-hi transition cursor-pointer"
            >
              Configure
            </button>
            <button
              type="button"
              id="btn-quickselect-toggle-collapse"
              onClick={onToggleCollapsed}
              className="text-kf-muted hover:text-kf-text transition cursor-pointer p-0.5"
              title={collapsed ? 'Expand printer selector' : 'Collapse printer selector'}
            >
              {collapsed ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {collapsed ? (
          /* Collapsed View (Single Line Summary) */
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-kf-text truncate font-medium" title={selectedPrinter.name}>
              {selectedPrinter.name}
            </span>
            <span className="text-[10px] text-kf-muted shrink-0 ml-2">
              {selectedPrinter.buildVolume.x} × {selectedPrinter.buildVolume.y} × {selectedPrinter.buildVolume.z} mm
            </span>
          </div>
        ) : (
          /* Expanded View */
          <div className="space-y-2">
            <select
              id="quick-select-printer"
              value={selectedPrinterId}
              onChange={(e) => onPrinterChange(e.target.value)}
              className="w-full bg-kf-panel-2 border border-kf-border px-3 py-2 text-xs font-mono text-kf-text focus:outline-none focus:border-kf-pink clip-corner"
            >
              {printerGroups.map(([groupName, groupPrinters]) => (
                <optgroup key={groupName} label={groupName} className="bg-kf-panel font-bold text-kf-muted">
                  {groupPrinters.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.buildVolume.x}×{p.buildVolume.y}×{p.buildVolume.z}mm)
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>

            {/* Build Volume & Nozzle Readout */}
            <div className="font-mono text-[10px] text-kf-muted">
              {selectedPrinter.buildVolume.x} × {selectedPrinter.buildVolume.y} × {selectedPrinter.buildVolume.z} mm · {selectedPrinter.nozzleDiameter} mm nozzle
            </div>

            {/* Fit Result Warning or Check */}
            {fitResult !== null && (
              <div className="pt-0.5">
                {doesFit ? (
                  <div className="flex items-center gap-1.5 text-[10px] font-mono text-kf-muted">
                    <Check className="w-3.5 h-3.5 text-kf-ok shrink-0" />
                    <span>Fits build volume</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 text-[10px] font-mono text-kf-pink">
                    <AlertTriangle className="w-3.5 h-3.5 text-kf-pink shrink-0" />
                    <span className="truncate" title={`Exceeds build volume: ${overflowDescription}`}>
                      Exceeds {overflowDescription}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
