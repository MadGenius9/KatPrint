import React, { useState, useMemo } from 'react';
import {
  HelpCircle,
  Table,
  AlertTriangle,
  Sparkles,
  RefreshCw,
  Check,
  CheckCircle2,
  Sliders,
  ArrowRight,
  ShieldCheck,
  Info,
  Layers,
  Settings2,
} from 'lucide-react';
import {
  ExtractedRequirements,
  AssumptionLedgerEntry,
  OpenQuestion,
  SpecReviewIssue,
} from '../types';

export interface SpecReviewPanelProps {
  requirements: ExtractedRequirements;
  prompt: string;
  onProceedToGeneration: (
    updatedRequirements: ExtractedRequirements,
    userOverrides: string[]
  ) => void;
  onRegenerateSpec: (
    updatedPrompt: string,
    updatedRequirements: ExtractedRequirements,
    userOverrides: string[]
  ) => void;
  isRegenerating?: boolean;
  isGenerating?: boolean;
  skipSpecReview?: boolean;
  onToggleSkipSpecReview?: (skip: boolean) => void;
}

export const SpecReviewPanel: React.FC<SpecReviewPanelProps> = ({
  requirements,
  prompt,
  onProceedToGeneration,
  onRegenerateSpec,
  isRegenerating = false,
  isGenerating = false,
  skipSpecReview = false,
  onToggleSkipSpecReview,
}) => {
  const [editedRequirements, setEditedRequirements] = useState<ExtractedRequirements>(() => ({
    ...requirements,
    assumptionLedger: requirements.assumptionLedger ? [...requirements.assumptionLedger] : [],
    openQuestions: requirements.openQuestions ? [...requirements.openQuestions] : [],
    specReviewIssues: requirements.specReviewIssues ? [...requirements.specReviewIssues] : [],
    userOverrides: requirements.userOverrides ? [...requirements.userOverrides] : [],
  }));

  const [questionInputs, setQuestionInputs] = useState<Record<string, string>>(() => {
    const map: Record<string, string> = {};
    (requirements.openQuestions || []).forEach((q, idx) => {
      const key = q.id || `q_${idx}`;
      map[key] = q.assumedAnswer || '';
    });
    return map;
  });

  const [questionApplied, setQuestionApplied] = useState<Record<string, boolean>>({});

  const [overrideMap, setOverrideMap] = useState<Record<string, string>>(() => {
    const map: Record<string, string> = {};
    (requirements.userOverrides || []).forEach((ov) => {
      const splitIdx = ov.indexOf(':');
      if (splitIdx !== -1) {
        map[ov.slice(0, splitIdx).trim()] = ov;
      } else {
        map[ov] = ov;
      }
    });
    return map;
  });

  // Sort ledger lowest-confidence first so risky guesses are at the top
  const sortedLedger = useMemo(() => {
    const list = editedRequirements.assumptionLedger || [];
    return [...list].sort((a, b) => {
      const confA = typeof a.confidence === 'number'
        ? a.confidence
        : a.basis === 'engineering_default' || a.basis === 'inferred_from_load'
        ? 0.3
        : a.basis === 'measured_from_image'
        ? 0.6
        : 0.95;

      const confB = typeof b.confidence === 'number'
        ? b.confidence
        : b.basis === 'engineering_default' || b.basis === 'inferred_from_load'
        ? 0.3
        : b.basis === 'measured_from_image'
        ? 0.6
        : 0.95;

      return confA - confB;
    });
  }, [editedRequirements.assumptionLedger]);

  const activeOverrides = useMemo(() => Object.values(overrideMap), [overrideMap]);

  // Handle Question Answer Change
  const handleQuestionInputChange = (qKey: string, val: string) => {
    setQuestionInputs((prev) => ({ ...prev, [qKey]: val }));
  };

  // Apply User Answer to Question
  const handleApplyQuestionAnswer = (q: OpenQuestion, idx: number) => {
    const qKey = q.id || `q_${idx}`;
    const userAnswer = (questionInputs[qKey] || '').trim();
    if (!userAnswer) return;

    setQuestionApplied((prev) => ({ ...prev, [qKey]: true }));

    const overrideStr = `${q.question}: answered by user as "${userAnswer}" (was assumed: "${q.assumedAnswer}")`;
    setOverrideMap((prev) => ({
      ...prev,
      [`question_${qKey}`]: overrideStr,
    }));

    // Update the question inside editedRequirements
    setEditedRequirements((prev) => {
      const updatedQuestions = (prev.openQuestions || []).map((item, i) => {
        if ((item.id && item.id === q.id) || i === idx) {
          return { ...item, assumedAnswer: userAnswer };
        }
        return item;
      });
      return { ...prev, openQuestions: updatedQuestions };
    });
  };

  // Reset Question to AI Assumption
  const handleUseAssumption = (q: OpenQuestion, idx: number) => {
    const qKey = q.id || `q_${idx}`;
    setQuestionInputs((prev) => ({ ...prev, [qKey]: q.assumedAnswer }));
    setQuestionApplied((prev) => ({ ...prev, [qKey]: false }));

    setOverrideMap((prev) => {
      const next = { ...prev };
      delete next[`question_${qKey}`];
      return next;
    });

    setEditedRequirements((prev) => {
      const updatedQuestions = (prev.openQuestions || []).map((item, i) => {
        if ((item.id && item.id === q.id) || i === idx) {
          return { ...item, assumedAnswer: q.assumedAnswer };
        }
        return item;
      });
      return { ...prev, openQuestions: updatedQuestions };
    });
  };

  // Handle Ledger Parameter Value Change
  const handleLedgerValueChange = (
    originalEntry: AssumptionLedgerEntry,
    newRawValue: string
  ) => {
    const isNum = typeof originalEntry.value === 'number';
    const parsedVal = isNum ? parseFloat(newRawValue) : newRawValue;
    const finalVal = isNum && isNaN(parsedVal as number) ? 0 : parsedVal;

    // Update in ledger
    setEditedRequirements((prev) => {
      const nextLedger = (prev.assumptionLedger || []).map((entry) => {
        if (entry.parameter === originalEntry.parameter) {
          return { ...entry, value: finalVal };
        }
        return entry;
      });

      // Patch specific top-level requirement attributes if matching known parameter names
      const nextReqs: ExtractedRequirements = {
        ...prev,
        assumptionLedger: nextLedger,
      };

      const paramLower = originalEntry.parameter.toLowerCase();
      if (typeof finalVal === 'number') {
        if (paramLower.includes('wall') || paramLower.includes('thickness')) {
          nextReqs.wallThicknessMm = finalVal;
        } else if (paramLower === 'width' || paramLower.includes('targetwidth') || paramLower.includes('outerwidth')) {
          nextReqs.overallDimensions = { ...nextReqs.overallDimensions, width: finalVal };
        } else if (paramLower === 'depth' || paramLower.includes('targetdepth') || paramLower.includes('outerdepth') || paramLower.includes('length')) {
          nextReqs.overallDimensions = { ...nextReqs.overallDimensions, depth: finalVal };
        } else if (paramLower === 'height' || paramLower.includes('targetheight') || paramLower.includes('outerheight')) {
          nextReqs.overallDimensions = { ...nextReqs.overallDimensions, height: finalVal };
        }
      }

      return nextReqs;
    });

    const unitSuffix = originalEntry.unit ? `${originalEntry.unit}` : '';
    const overrideStr = `${originalEntry.parameter} set to ${finalVal}${unitSuffix} by user (was ${originalEntry.value}${unitSuffix}, ${originalEntry.basis})`;

    setOverrideMap((prev) => ({
      ...prev,
      [`ledger_${originalEntry.parameter}`]: overrideStr,
    }));
  };

  // Proceed with Generation using patched requirements and overrides
  const handleGenerateModel = () => {
    const finalReqs: ExtractedRequirements = {
      ...editedRequirements,
      userOverrides: activeOverrides,
    };
    onProceedToGeneration(finalReqs, activeOverrides);
  };

  // Regenerate Spec with Overrides
  const handleRegenerateSpec = () => {
    const overrideLines = activeOverrides.length > 0
      ? `\n\nAUTHORITATIVE USER-CONFIRMED SPECIFICATIONS & ANSWERS:\n` +
        activeOverrides.map((o) => `- ${o}`).join('\n')
      : '';
    const updatedPrompt = `${prompt}${overrideLines}`;

    const finalReqs: ExtractedRequirements = {
      ...editedRequirements,
      userOverrides: activeOverrides,
    };
    onRegenerateSpec(updatedPrompt, finalReqs, activeOverrides);
  };

  // Helper for basis badge styling
  const getBasisBadge = (basis: AssumptionLedgerEntry['basis']) => {
    switch (basis) {
      case 'user_stated':
        return {
          label: 'User Stated',
          classes: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
          confidenceLabel: 'High',
        };
      case 'reference_library':
        return {
          label: 'Ref Library',
          classes: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
          confidenceLabel: 'High',
        };
      case 'measured_from_image':
        return {
          label: 'Image Measurement',
          classes: 'bg-sky-500/15 text-sky-400 border-sky-500/30',
          confidenceLabel: 'Moderate',
        };
      case 'inferred_from_load':
        return {
          label: 'Inferred Load',
          classes: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
          confidenceLabel: 'Low (Inferred)',
        };
      case 'engineering_default':
      default:
        return {
          label: 'Engineering Default',
          classes: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
          confidenceLabel: 'Low (Default)',
        };
    }
  };

  const hasOpenQuestions = (editedRequirements.openQuestions || []).length > 0;
  const hasLedger = sortedLedger.length > 0;
  const hasIssues = (editedRequirements.specReviewIssues || []).length > 0;

  return (
    <div className="trace clip-corner bg-kf-panel border border-kf-pink/50 rounded-lg p-4 flex flex-col gap-4 shadow-lg animate-fadeIn text-kf-text font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-kf-border pb-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-kf-pink shrink-0" />
          <div>
            <h2 className="text-sm font-mono font-bold uppercase tracking-wider text-kf-text flex items-center gap-2">
              <span>Spec &amp; Assumption Review</span>
              <span className="text-[10px] font-mono bg-kf-pink/15 text-kf-pink px-2 py-0.5 rounded border border-kf-pink/30">
                Pre-CAD Verification
              </span>
            </h2>
            <p className="text-[11px] text-kf-muted mt-0.5">
              Review AI engineering guesses, adjust dimensions, or answer open questions before generating CAD.
            </p>
          </div>
        </div>

        {onToggleSkipSpecReview && (
          <label className="flex items-center gap-2 cursor-pointer self-start sm:self-auto text-[11px] font-mono text-kf-muted hover:text-kf-text select-none">
            <input
              type="checkbox"
              checked={skipSpecReview}
              onChange={(e) => onToggleSkipSpecReview(e.target.checked)}
              className="rounded border-kf-border bg-kf-panel-2 text-kf-pink focus:ring-kf-pink"
            />
            <span>Skip review in future</span>
          </label>
        )}
      </div>

      {/* SECTION 1: OPEN QUESTIONS */}
      {hasOpenQuestions && (
        <div className="flex flex-col gap-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-kf-pink" />
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-kf-text">
                1. Open Design Questions ({editedRequirements.openQuestions?.length})
              </span>
            </div>
            <span className="text-[10px] font-mono text-kf-muted">
              Unanswered questions proceed with AI assumption
            </span>
          </div>

          <div className="flex flex-col gap-2.5">
            {editedRequirements.openQuestions?.map((q, idx) => {
              const qKey = q.id || `q_${idx}`;
              const isApplied = !!questionApplied[qKey];
              const currentInputVal = questionInputs[qKey] ?? q.assumedAnswer ?? '';
              const isModified = currentInputVal !== q.assumedAnswer;

              return (
                <div
                  key={qKey}
                  className="trace clip-corner bg-kf-panel-2 border border-kf-border rounded-md p-3 flex flex-col gap-2 transition hover:border-kf-pink/40"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex flex-col gap-0.5">
                      <span className="text-xs font-mono font-bold text-kf-text">
                        {q.question}
                      </span>
                      {q.whyItMatters && (
                        <span className="text-[11px] text-kf-muted italic">
                          Why it matters: {q.whyItMatters}
                        </span>
                      )}
                    </div>

                    {isApplied ? (
                      <span className="text-[10px] font-mono font-semibold text-kf-ok bg-kf-ok/10 border border-kf-ok/30 px-2 py-0.5 rounded shrink-0 flex items-center gap-1">
                        <Check className="w-3 h-3" /> Answer Applied
                      </span>
                    ) : (
                      <span className="text-[10px] font-mono text-kf-muted bg-kf-panel px-2 py-0.5 rounded border border-kf-border shrink-0">
                        Default Assumption
                      </span>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-center mt-1">
                    <input
                      type="text"
                      value={currentInputVal}
                      onChange={(e) => handleQuestionInputChange(qKey, e.target.value)}
                      placeholder={`AI assumption: ${q.assumedAnswer}`}
                      className="flex-1 bg-kf-panel border border-kf-border rounded px-3 py-1.5 text-xs font-sans text-kf-text focus:outline-none focus:border-kf-pink"
                    />

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleApplyQuestionAnswer(q, idx)}
                        disabled={!currentInputVal.trim()}
                        className="bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] text-[11px] font-mono font-bold px-3 py-1.5 rounded transition disabled:opacity-50 cursor-pointer"
                      >
                        Apply my answer
                      </button>

                      {isModified && (
                        <button
                          type="button"
                          onClick={() => handleUseAssumption(q, idx)}
                          className="bg-kf-panel hover:bg-kf-border/80 border border-kf-border text-kf-muted hover:text-kf-text text-[11px] font-mono px-2.5 py-1.5 rounded transition cursor-pointer"
                          title="Reset to AI assumption"
                        >
                          Use assumption
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SECTION 2: ASSUMPTION LEDGER */}
      {hasLedger && (
        <div className="flex flex-col gap-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Table className="w-4 h-4 text-kf-pink" />
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-kf-text">
                2. Assumption Ledger ({sortedLedger.length} parameters)
              </span>
            </div>
            <span className="text-[10px] font-mono text-kf-muted">
              Sorted by lowest confidence first (riskiest guesses top)
            </span>
          </div>

          <div className="border border-kf-border rounded-md overflow-hidden bg-kf-panel-2">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-kf-panel border-b border-kf-border font-mono text-[10px] uppercase text-kf-muted">
                    <th className="p-2.5 font-bold">Parameter</th>
                    <th className="p-2.5 font-bold w-36">Value &amp; Unit</th>
                    <th className="p-2.5 font-bold">Basis &amp; Confidence</th>
                    <th className="p-2.5 font-bold">Engineering Reasoning</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-kf-border">
                  {sortedLedger.map((entry, idx) => {
                    const badge = getBasisBadge(entry.basis);
                    const isOverridden = activeOverrides.some((o) =>
                      o.startsWith(`${entry.parameter} set to`)
                    );

                    return (
                      <tr
                        key={`${entry.parameter}-${idx}`}
                        className={`hover:bg-kf-panel/60 transition ${
                          isOverridden ? 'bg-kf-pink/5' : ''
                        }`}
                      >
                        <td className="p-2.5 font-mono font-medium text-kf-text align-top">
                          <div className="flex items-center gap-1.5">
                            <span>{entry.parameter}</span>
                            {isOverridden && (
                              <span className="text-[9px] font-mono bg-kf-pink/20 text-kf-pink px-1 rounded">
                                User Set
                              </span>
                            )}
                          </div>
                        </td>

                        <td className="p-2.5 font-mono align-top">
                          <div className="flex items-center gap-1.5">
                            <input
                              type={typeof entry.value === 'number' ? 'number' : 'text'}
                              value={entry.value}
                              step={typeof entry.value === 'number' && (entry.value as number) < 10 ? '0.1' : '1'}
                              onChange={(e) =>
                                handleLedgerValueChange(entry, e.target.value)
                              }
                              className="w-20 bg-kf-panel border border-kf-border text-right px-2 py-1 rounded text-xs font-mono text-kf-pink focus:outline-none focus:border-kf-pink"
                            />
                            <span className="text-[11px] text-kf-muted shrink-0">
                              {entry.unit || ''}
                            </span>
                          </div>
                        </td>

                        <td className="p-2.5 font-mono align-top">
                          <span
                            className={`inline-block text-[10px] px-2 py-0.5 rounded border ${badge.classes} font-semibold`}
                            title={`Confidence: ${typeof entry.confidence === 'number' ? `${Math.round(entry.confidence * 100)}%` : badge.confidenceLabel}`}
                          >
                            {badge.label}
                          </span>
                        </td>

                        <td className="p-2.5 text-[11px] text-kf-muted leading-snug align-top">
                          {entry.reasoning || 'Derived from standard design rules'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: SPEC REVIEW ISSUES */}
      {hasIssues && (
        <div className="flex flex-col gap-2.5">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-kf-warn" />
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-kf-text">
              3. Spec Review Issues ({editedRequirements.specReviewIssues?.length})
            </span>
          </div>

          <div className="flex flex-col gap-2">
            {editedRequirements.specReviewIssues?.map((issue, idx) => (
              <div
                key={idx}
                className="trace clip-corner bg-kf-panel-2 border border-kf-warn/40 rounded-md p-2.5 flex flex-col gap-1 text-xs"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded font-bold ${
                        issue.severity === 'blocking'
                          ? 'bg-kf-fail/20 text-kf-fail border border-kf-fail/40'
                          : 'bg-kf-warn/20 text-kf-warn border border-kf-warn/40'
                      }`}
                    >
                      {issue.severity}
                    </span>
                    <span className="font-mono font-bold text-kf-text">
                      {issue.field}
                    </span>
                  </div>

                  {issue.correctedValue !== undefined && (
                    <span className="text-[10px] font-mono text-kf-ok bg-kf-ok/10 border border-kf-ok/30 px-1.5 py-0.5 rounded">
                      Corrected to: {String(issue.correctedValue)}
                    </span>
                  )}
                </div>

                <p className="text-[11px] text-kf-muted">{issue.problem}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Active User Overrides Summary Banner */}
      {activeOverrides.length > 0 && (
        <div className="bg-kf-pink/10 border border-kf-pink/30 rounded-md p-2.5 flex flex-col gap-1 text-xs font-mono">
          <span className="text-[10px] font-bold text-kf-pink uppercase tracking-wider">
            Active User Overrides ({activeOverrides.length}):
          </span>
          <ul className="text-[11px] text-kf-text list-disc list-inside space-y-0.5">
            {activeOverrides.map((ov, i) => (
              <li key={i}>{ov}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Footer Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-kf-border">
        <button
          type="button"
          onClick={handleRegenerateSpec}
          disabled={isRegenerating || isGenerating}
          className="w-full sm:w-auto flex items-center justify-center gap-1.5 bg-kf-panel-2 hover:bg-kf-panel border border-kf-border text-kf-text text-xs font-mono font-semibold px-4 py-2.5 rounded-md transition disabled:opacity-50 cursor-pointer"
        >
          {isRegenerating ? (
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <RefreshCw className="w-3.5 h-3.5 text-kf-muted" />
          )}
          <span>Regenerate Spec with Edits</span>
        </button>

        <button
          type="button"
          id="btn-confirm-spec-generate"
          onClick={handleGenerateModel}
          disabled={isGenerating || isRegenerating}
          className="w-full sm:w-auto flex items-center justify-center gap-2 bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] text-xs font-mono font-bold uppercase tracking-wider px-6 py-2.5 rounded-md transition shadow-md shadow-kf-pink/20 disabled:opacity-50 cursor-pointer"
        >
          {isGenerating ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Generating CAD...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>Generate Model</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
