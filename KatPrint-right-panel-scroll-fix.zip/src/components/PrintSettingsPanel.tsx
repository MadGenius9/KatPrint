import React, { useState } from 'react';
import {
  ModelGeometryStats,
  PrinterSpec,
  FilamentSpec,
  SlicerSettings,
  PrinterFitResult,
  ReferenceObject,
  ExecutedModelPart,
  PrintabilityReport,
} from '../types';
import {
  Sliders,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Download,
  Copy,
  Check,
  Sparkles,
  RefreshCw,
  Gauge,
  Flame,
  Scale,
  Layers,
  Box,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Loader2,
} from 'lucide-react';
import { generateSlicerOverridesText } from '../engine/slicerEngine';
import { downloadExportSTL } from '../engine/stlExporter';
import { PrintabilityPanel } from './PrintabilityPanel';
import * as THREE from 'three';

interface PrintSettingsPanelProps {
  geometry: THREE.BufferGeometry | null;
  parts?: ExecutedModelPart[];
  stats: ModelGeometryStats;
  printer: PrinterSpec;
  filament: FilamentSpec;
  settings: SlicerSettings;
  fitResult: PrinterFitResult;
  scaleFactor: number;
  onScaleChange: (newScale: number) => void;
  mustHoldLiquid: boolean;
  onToggleMustHoldLiquid: () => void;
  onExplainSettings: () => Promise<void>;
  explanation: string | null;
  isExplaining: boolean;
  onOpenMonitor: () => void;
  modelName: string;
  referenceObject?: ReferenceObject | null;
  exportValidation?: { allowed: boolean; reason: string };
  printabilityReport?: PrintabilityReport | null;
  isAnalyzingPrintability?: boolean;
  onApplyOrientation?: (rotationDeg: [number, number, number]) => void;
}

export const PrintSettingsPanel: React.FC<PrintSettingsPanelProps> = ({
  geometry,
  parts = [],
  stats,
  printer,
  filament,
  settings,
  fitResult,
  scaleFactor,
  onScaleChange,
  mustHoldLiquid,
  onToggleMustHoldLiquid,
  onExplainSettings,
  explanation,
  isExplaining,
  onOpenMonitor,
  modelName,
  referenceObject,
  exportValidation,
  printabilityReport,
  isAnalyzingPrintability,
  onApplyOrientation,
}) => {
  const [copiedOverrides, setCopiedOverrides] = useState(false);
  const [expandedTable, setExpandedTable] = useState(false);
  const [exportProgress, setExportProgress] = useState<number | null>(null);

  const scaledX = stats.dimensions.x * scaleFactor;
  const scaledY = stats.dimensions.y * scaleFactor;
  const scaledZ = stats.dimensions.z * scaleFactor;
  const scaledVolumeCm3 = stats.volumeCm3 * Math.pow(scaleFactor, 3);

  const handleCopyOverrides = () => {
    const text = generateSlicerOverridesText(settings, printer, filament);
    navigator.clipboard.writeText(text);
    setCopiedOverrides(true);
    setTimeout(() => setCopiedOverrides(false), 2000);
  };

  const hasParts = parts && parts.length > 0;
  const isExportDisabled = exportValidation
    ? !exportValidation.allowed
    : (!geometry && !hasParts);
  const exportDisabledReason = exportValidation
    ? exportValidation.reason
    : (!geometry && !hasParts
    ? 'No active 3D model geometry to export.'
    : '');

  const handleExportSTL = async () => {
    if (exportProgress !== null || isExportDisabled || (!geometry && !hasParts)) return;
    const cleanName = (modelName || 'model')
      .replace(/^TEMPLATE-/i, '')
      .toLowerCase()
      .replace(/[^a-z0-9_]/g, '_')
      .slice(0, 32);
    const heightMm = (scaledZ || 10).toFixed(0);
    const filename = `katprint_${cleanName}_${heightMm}mm_${filament.id}`;

    setExportProgress(0);
    try {
      await downloadExportSTL(
        geometry,
        parts,
        filename,
        scaleFactor,
        10,
        (percent) => setExportProgress(percent)
      );
    } catch (err) {
      console.error('Failed to export STL:', err);
    } finally {
      setTimeout(() => setExportProgress(null), 750);
    }
  };

  return (
    <div className="flex flex-col gap-4 text-kf-text overflow-y-auto pr-1">
      {/* 1. PROMINENT DOWNLOAD STL HERO BUTTON */}
      <div className="trace clip-corner bg-kf-panel border border-kf-border rounded-lg p-3.5 flex flex-col gap-2.5 shadow-md">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-kf-text font-mono flex items-center gap-1.5">
            <Download className="w-4 h-4 text-kf-pink" />
            <span>Ready for Slicing</span>
          </span>
          <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
            isExportDisabled 
              ? 'text-kf-fail bg-kf-fail/10 border-kf-fail/30' 
              : 'text-kf-ok bg-kf-ok/10 border-kf-ok/30'
          }`}>
            {exportProgress !== null
              ? `Exporting ${exportProgress}%`
              : isExportDisabled
              ? 'Export Locked'
              : 'Binary STL (mm)'}
          </span>
        </div>

        <button
          type="button"
          id="btn-export-stl-main"
          disabled={isExportDisabled || exportProgress !== null}
          onClick={handleExportSTL}
          className="w-full flex items-center justify-center gap-2 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-40 disabled:cursor-not-allowed text-[#0A0004] font-mono font-bold py-3 px-4 rounded-md text-sm transition shadow-md shadow-kf-pink/25 cursor-pointer"
        >
          {exportProgress !== null ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-[#0A0004]" />
              <span>{exportProgress > 0 ? `Generating STL (${exportProgress}%)...` : 'Generating STL File...'}</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4" />
              <span>Download STL for Your Slicer</span>
            </>
          )}
        </button>

        {isExportDisabled ? (
          <p className="text-[10.5px] font-mono text-kf-fail bg-kf-fail/10 border border-kf-fail/30 p-2 rounded text-center">
            {exportDisabledReason}
          </p>
        ) : (
          <p className="text-[10.5px] font-sans text-kf-muted text-center">
            Standard mm units. Compatible directly with Bambu Studio, OrcaSlicer, PrusaSlicer, and Cura.
          </p>
        )}
      </div>

      {/* 2. PHYSICAL DIMENSIONS READOUT & SCALE SLIDER */}
      <div className="trace clip-corner border border-kf-border bg-kf-panel rounded-lg p-3.5 flex flex-col gap-3 shadow-sm">
        <div className="flex items-center justify-between border-b border-kf-border pb-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-kf-muted font-mono flex items-center gap-1.5">
            <Scale className="w-3.5 h-3.5 text-kf-pink" />
            <span>Dimensions &amp; Scale</span>
          </span>
          <span className="text-[11px] font-mono text-kf-muted">
            {stats.triangleCount.toLocaleString()} Triangles
          </span>
        </div>

        {/* Live Bounding Box Readout */}
        <div className="trace clip-corner grid grid-cols-3 gap-2 bg-kf-panel-2 p-2.5 rounded-md border border-kf-border text-center font-mono">
          <div>
            <div className="text-[10px] text-kf-muted">X (Width)</div>
            <div className="text-xs font-bold text-[#00f0ff]">{scaledX.toFixed(1)} mm</div>
          </div>
          <div>
            <div className="text-[10px] text-kf-muted">Y (Depth)</div>
            <div className="text-xs font-bold text-[#00f0ff]">{scaledY.toFixed(1)} mm</div>
          </div>
          <div>
            <div className="text-[10px] text-kf-muted">Z (Height)</div>
            <div className="text-xs font-bold text-kf-pink">{scaledZ.toFixed(1)} mm</div>
          </div>
        </div>

        {/* Volume & Weight */}
        <div className="grid grid-cols-2 gap-2 text-xs font-mono">
          <div className="trace clip-corner flex justify-between bg-kf-panel-2 px-2.5 py-1.5 rounded-md border border-kf-border">
            <span className="text-kf-muted">Volume:</span>
            <span className="text-kf-text font-medium">{scaledVolumeCm3.toFixed(1)} cm³</span>
          </div>
          <div className="trace clip-corner flex justify-between bg-kf-panel-2 px-2.5 py-1.5 rounded-md border border-kf-border">
            <span className="text-kf-muted">Est. Weight:</span>
            <span className="text-kf-pink font-medium">{settings.estimatedMaterialGrams} g</span>
          </div>
        </div>

        {/* Scale Slider 25% - 400% */}
        <div className="flex flex-col gap-2 pt-1">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-kf-muted">Uniform Scale Factor</span>
            <span className="text-kf-pink font-bold">{(scaleFactor * 100).toFixed(0)}%</span>
          </div>

          <input
            type="range"
            id="slider-model-scale"
            min={0.25}
            max={4.0}
            step={0.05}
            value={scaleFactor}
            onChange={(e) => onScaleChange(parseFloat(e.target.value))}
            className="kf-slider w-full cursor-pointer"
          />

          {/* Quick Presets */}
          <div className="flex justify-between gap-1 pt-0.5">
            {[0.5, 0.75, 1.0, 1.5, 2.0].map((preset) => (
              <button
                key={preset}
                type="button"
                id={`btn-scale-${preset}`}
                onClick={() => onScaleChange(preset)}
                className={`flex-1 py-1 text-[10px] font-mono rounded-md border transition ${
                  Math.abs(scaleFactor - preset) < 0.01
                    ? 'bg-kf-pink text-[#0A0004] border-kf-pink font-semibold shadow-sm'
                    : 'bg-kf-panel-2 border-kf-border text-kf-muted hover:text-kf-text'
                }`}
              >
                {(preset * 100).toFixed(0)}%
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 3. PRINTER FIT CHECK STATUS BANNER */}
      <div
        className={`border p-3.5 rounded-lg flex flex-col gap-2 transition shadow-sm ${
          fitResult.status === 'green'
            ? 'bg-kf-ok/10 border-kf-ok/40 text-kf-ok'
            : fitResult.status === 'yellow'
            ? 'bg-kf-warn/10 border-kf-warn/40 text-kf-warn'
            : 'bg-kf-fail/10 border-kf-fail/40 text-kf-fail'
        }`}
      >
        <div className="flex items-start gap-2.5">
          {fitResult.status === 'green' ? (
            <CheckCircle2 className="w-5 h-5 text-kf-ok shrink-0 mt-0.5" />
          ) : fitResult.status === 'yellow' ? (
            <AlertTriangle className="w-5 h-5 text-kf-warn shrink-0 mt-0.5" />
          ) : (
            <XCircle className="w-5 h-5 text-kf-fail shrink-0 mt-0.5" />
          )}

          <div className="flex flex-col">
            <div className="text-xs font-mono font-bold uppercase tracking-wider">
              {fitResult.status === 'green'
                ? `Fits ${printer.name} Bed`
                : fitResult.status === 'yellow'
                ? 'Fit Warning: 45° Bed Rotation Required'
                : 'Fit Failed: Exceeds Build Volume'}
            </div>
            <div className="text-[11px] leading-relaxed opacity-90 mt-0.5">{fitResult.message}</div>
          </div>
        </div>
      </div>

      {/* 4. DETERMINISTIC PRINTABILITY AUDIT */}
      <PrintabilityPanel
        report={printabilityReport || null}
        printer={printer}
        filament={filament}
        isAnalyzing={isAnalyzingPrintability}
        onApplyOrientation={onApplyOrientation}
      />

      {/* 5. RECOMMENDED SLICER SETTINGS GUIDE */}
      <div className="trace clip-corner border border-kf-border bg-kf-panel rounded-lg overflow-hidden flex flex-col shadow-sm">
        <div
          className="trace clip-corner flex items-center justify-between p-3.5 border-b border-kf-border cursor-pointer bg-kf-panel-2 hover:bg-kf-border/40 transition"
          onClick={() => setExpandedTable(!expandedTable)}
        >
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-kf-warn" />
            <span className="text-xs font-semibold uppercase tracking-wider text-kf-text font-mono">
              Recommended Slicer Profile Tips
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-kf-pink bg-kf-pink/10 px-2 py-0.5 rounded border border-kf-pink/25">
              ~{settings.estimatedPrintTimeMinutes} min
            </span>
            {expandedTable ? (
              <ChevronUp className="w-3.5 h-3.5 text-kf-muted" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5 text-kf-muted" />
            )}
          </div>
        </div>

        {/* High-level quick guide always visible */}
        <div className="trace clip-corner p-3 grid grid-cols-2 gap-2 text-xs font-mono bg-kf-panel border-b border-kf-border/60">
          <div className="trace clip-corner bg-kf-panel-2 p-2 rounded border border-kf-border">
            <span className="text-[10px] text-kf-muted block">Infill:</span>
            <span className="font-semibold text-kf-text">{settings.infillPercent}% {settings.infillPattern}</span>
          </div>
          <div className="trace clip-corner bg-kf-panel-2 p-2 rounded border border-kf-border">
            <span className="text-[10px] text-kf-muted block">Walls / Loops:</span>
            <span className="font-semibold text-kf-text">{settings.wallLoops} perimeters</span>
          </div>
          <div className="trace clip-corner bg-kf-panel-2 p-2 rounded border border-kf-border">
            <span className="text-[10px] text-kf-muted block">Supports:</span>
            <span className={`font-semibold ${settings.supportsEnabled ? 'text-kf-warn' : 'text-kf-ok'}`}>
              {settings.supportsEnabled ? 'Tree Supports' : 'None Needed'}
            </span>
          </div>
          <div className="trace clip-corner bg-kf-panel-2 p-2 rounded border border-kf-border">
            <span className="text-[10px] text-kf-muted block">Bed Contact / Brim:</span>
            <span className="font-semibold text-kf-text">{settings.brimEnabled ? 'Brim Advised' : 'Skirt / None'}</span>
          </div>
        </div>

        {expandedTable && (
          <div className="p-3.5 flex flex-col gap-2 text-xs font-mono bg-kf-panel">
            <div className="grid grid-cols-2 gap-x-3 gap-y-2">
              <div className="flex justify-between border-b border-kf-border/60 pb-1">
                <span className="text-kf-muted">Nozzle Temp:</span>
                <span className="text-kf-text font-medium">
                  {settings.nozzleTempFirstLayer}°C / {settings.nozzleTempOtherLayers}°C
                </span>
              </div>

              <div className="flex justify-between border-b border-kf-border/60 pb-1">
                <span className="text-kf-muted">Bed Temp:</span>
                <span className="text-kf-text font-medium">{settings.bedTemp}°C</span>
              </div>

              <div className="flex justify-between border-b border-kf-border/60 pb-1">
                <span className="text-kf-muted">Layer Height:</span>
                <span className="text-kf-pink font-medium">
                  {settings.layerHeight.toFixed(2)} mm
                </span>
              </div>

              <div className="flex justify-between border-b border-kf-border/60 pb-1">
                <span className="text-kf-muted">Top / Bottom:</span>
                <span className="text-kf-text font-medium">
                  {settings.topLayers}T / {settings.bottomLayers}B
                </span>
              </div>

              <div className="flex justify-between border-b border-kf-border/60 pb-1">
                <span className="text-kf-muted">Wall Speed:</span>
                <span className="text-kf-text font-medium">
                  {settings.outerWallSpeed} / {settings.innerWallSpeed} mm/s
                </span>
              </div>

              <div className="flex justify-between border-b border-kf-border/60 pb-1">
                <span className="text-kf-muted">Est. Filament:</span>
                <span className="text-kf-text font-medium">
                  {settings.estimatedMaterialMeters} m ({settings.estimatedMaterialGrams} g)
                </span>
              </div>
            </div>

            <button
              type="button"
              id="btn-copy-slicer-overrides"
              onClick={handleCopyOverrides}
              className="mt-2 flex items-center justify-center gap-1.5 bg-kf-panel-2 hover:bg-kf-border text-kf-text border border-kf-border font-mono py-2 px-3 rounded-md text-xs transition shadow-sm"
            >
              {copiedOverrides ? (
                <Check className="w-3.5 h-3.5 text-kf-ok" />
              ) : (
                <Copy className="w-3.5 h-3.5 text-kf-pink" />
              )}
              <span>{copiedOverrides ? 'Copied Slicer Tips!' : 'Copy Slicer Settings'}</span>
            </button>
          </div>
        )}
      </div>

      {/* 5. GEMINI EXPLANATION OF DESIGN & PRINT CHOICES */}
      <div className="trace clip-corner border border-kf-border bg-kf-panel rounded-lg p-3.5 flex flex-col gap-2.5 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-kf-pink" />
            <span className="text-xs font-semibold uppercase tracking-wider text-kf-text font-mono">
              Engineering Rationale
            </span>
          </div>

          <button
            type="button"
            id="btn-explain-slicer"
            onClick={onExplainSettings}
            disabled={isExplaining}
            className="flex items-center gap-1.5 text-[11px] font-mono text-kf-pink hover:text-kf-pink-hi bg-kf-pink/10 border border-kf-pink/25 px-2.5 py-1 rounded-md transition disabled:opacity-50 cursor-pointer"
          >
            {isExplaining ? (
              <RefreshCw className="w-3 h-3 animate-spin" />
            ) : (
              <Sparkles className="w-3 h-3" />
            )}
            <span>{explanation ? 'Regenerate' : 'Analyze Why'}</span>
          </button>
        </div>

        {explanation ? (
          <div className="trace clip-corner text-xs text-kf-text leading-relaxed font-sans bg-kf-panel-2 p-3 rounded-md border border-kf-border whitespace-pre-line select-text">
            {explanation}
          </div>
        ) : (
          <div className="text-[11px] text-kf-muted font-mono py-1">
            Click &apos;Analyze Why&apos; for a product designer breakdown of wall perimeters, infill density, and structural clearances chosen for this geometry.
          </div>
        )}
      </div>
    </div>
  );
};

