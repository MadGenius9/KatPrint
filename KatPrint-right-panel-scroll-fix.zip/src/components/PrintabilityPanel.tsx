import React, { useState } from 'react';
import {
  PrintabilityReport,
  PrinterSpec,
  FilamentSpec,
} from '../types';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Compass,
  Layers,
  Sparkles,
  Maximize2,
  Minimize2,
  Zap,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCw,
  ChevronDown,
  ChevronUp,
  Info,
} from 'lucide-react';

interface PrintabilityPanelProps {
  report: PrintabilityReport | null;
  printer?: PrinterSpec;
  filament?: FilamentSpec;
  isAnalyzing?: boolean;
  onApplyOrientation?: (rotationDeg: [number, number, number]) => void;
  className?: string;
}

export const PrintabilityPanel: React.FC<PrintabilityPanelProps> = ({
  report,
  printer,
  filament,
  isAnalyzing = false,
  onApplyOrientation,
  className = '',
}) => {
  const [expandedSection, setExpandedSection] = useState<'all' | 'overhangs' | 'islands' | 'walls' | 'bridges' | 'firstLayer' | 'none'>('all');
  const [showHelp, setShowHelp] = useState(false);

  if (!report) {
    return (
      <div className={`trace clip-corner border border-kf-border bg-kf-panel rounded-lg p-4 flex flex-col items-center justify-center text-center gap-2 ${className}`}>
        <ShieldCheck className="w-8 h-8 text-kf-muted opacity-50" />
        <div className="text-xs font-mono text-kf-muted">
          {isAnalyzing ? 'Analyzing 3D mesh printability...' : 'Generate or select a 3D model to inspect printability metrics.'}
        </div>
      </div>
    );
  }

  const {
    score,
    verdict,
    overhangs,
    islands,
    thinWalls,
    bridges,
    firstLayer,
    smallFeatures,
    recommendations,
    suggestedOrientation,
  } = report;

  const getVerdictStyle = () => {
    switch (verdict) {
      case 'excellent':
        return {
          bg: 'bg-kf-ok/10',
          border: 'border-kf-ok/40',
          text: 'text-kf-ok',
          label: 'Excellent Printability',
          badgeBg: 'bg-kf-ok text-[#0A0004]',
        };
      case 'good':
        return {
          bg: 'bg-kf-pink/10',
          border: 'border-kf-pink/40',
          text: 'text-kf-pink',
          label: 'Good (Minor Supports)',
          badgeBg: 'bg-kf-pink text-[#0A0004]',
        };
      case 'needs_attention':
        return {
          bg: 'bg-kf-warn/10',
          border: 'border-kf-warn/40',
          text: 'text-kf-warn',
          label: 'Needs Attention',
          badgeBg: 'bg-kf-warn text-[#0A0004]',
        };
      case 'problematic':
      default:
        return {
          bg: 'bg-kf-fail/10',
          border: 'border-kf-fail/40',
          text: 'text-kf-fail',
          label: 'Severe Printability Risk',
          badgeBg: 'bg-kf-fail text-[#0A0004]',
        };
    }
  };

  const style = getVerdictStyle();

  return (
    <div className={`flex flex-col gap-3 text-kf-text ${className}`}>
      {/* 1. SCORE HEADER BANNER */}
      <div className={`trace clip-corner border ${style.border} ${style.bg} rounded-lg p-3.5 flex flex-col gap-2.5 shadow-sm`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {verdict === 'excellent' ? (
              <ShieldCheck className={`w-5 h-5 ${style.text}`} />
            ) : verdict === 'good' ? (
              <CheckCircle2 className={`w-5 h-5 ${style.text}`} />
            ) : verdict === 'needs_attention' ? (
              <AlertTriangle className={`w-5 h-5 ${style.text}`} />
            ) : (
              <ShieldAlert className={`w-5 h-5 ${style.text}`} />
            )}
            <div>
              <div className="text-xs font-mono font-bold uppercase tracking-wider text-kf-text">
                Printability Audit
              </div>
              <div className={`text-[11px] font-mono font-semibold ${style.text}`}>
                {style.label}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowHelp(!showHelp)}
              className="text-kf-muted hover:text-kf-text p-1 rounded transition"
              title="Printability guide"
            >
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
            <div className={`px-2.5 py-1 rounded-md font-mono font-bold text-sm ${style.badgeBg} shadow-sm`}>
              {score}/100
            </div>
          </div>
        </div>

        {/* Linear score meter */}
        <div className="w-full bg-kf-panel-2 rounded-full h-1.5 overflow-hidden border border-kf-border">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              score >= 85
                ? 'bg-kf-ok'
                : score >= 70
                ? 'bg-kf-pink'
                : score >= 50
                ? 'bg-kf-warn'
                : 'bg-kf-fail'
            }`}
            style={{ width: `${Math.max(5, score)}%` }}
          />
        </div>

        {showHelp && (
          <div className="text-[11px] font-sans text-kf-muted bg-kf-panel-2 p-2.5 rounded border border-kf-border leading-relaxed mt-1">
            <span className="text-kf-text font-semibold">Deterministic Printability Analysis</span> inspects face normals, slicing layers, ray-sampled wall boundaries, and bridging spans against your target nozzle ({printer?.nozzleDiameter ?? 0.4}mm) and filament settings.
          </div>
        )}
      </div>

      {/* 2. SUGGESTED OPTIMAL ORIENTATION BANNER */}
      {suggestedOrientation && (
        <div className="trace clip-corner border border-kf-pink/40 bg-kf-pink/10 rounded-lg p-3 flex flex-col gap-2 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-kf-pink font-mono text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-4 h-4" />
              <span>Recommended Orientation</span>
            </div>
            <span className="text-[10px] font-mono bg-kf-pink text-[#0A0004] font-bold px-1.5 py-0.5 rounded">
              +{suggestedOrientation.projectedScore - score} pts
            </span>
          </div>

          <p className="text-xs font-sans text-kf-text leading-snug">
            {suggestedOrientation.reasoning}. Projected score improves from{' '}
            <span className="font-mono font-bold text-kf-muted">{score}</span> to{' '}
            <span className="font-mono font-bold text-kf-ok">{suggestedOrientation.projectedScore}/100</span>.
          </p>

          {onApplyOrientation && (
            <button
              type="button"
              id="btn-apply-suggested-orientation"
              onClick={() => onApplyOrientation(suggestedOrientation.rotationDeg)}
              className="mt-1 flex items-center justify-center gap-1.5 bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-mono font-bold py-1.5 px-3 rounded text-xs transition cursor-pointer"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Apply Rotation ({suggestedOrientation.rotationDeg.join('°, ')}°)</span>
            </button>
          )}
        </div>
      )}

      {/* 3. CORE GEOMETRIC AUDIT TILES */}
      <div className="grid grid-cols-2 gap-2 text-xs font-mono">
        {/* Overhangs Tile */}
        <div className="trace clip-corner bg-kf-panel-2 border border-kf-border rounded-lg p-2.5 flex flex-col gap-1">
          <div className="flex items-center justify-between text-kf-muted text-[10.5px]">
            <span className="flex items-center gap-1">
              <Compass className="w-3 h-3 text-kf-pink" />
              <span>Overhangs</span>
            </span>
            <span
              className={`text-[9.5px] px-1 py-0.2 rounded uppercase font-bold ${
                overhangs.classification === 'none' || overhangs.classification === 'minor'
                  ? 'text-kf-ok bg-kf-ok/10'
                  : overhangs.classification === 'significant'
                  ? 'text-kf-warn bg-kf-warn/10'
                  : 'text-kf-fail bg-kf-fail/10'
              }`}
            >
              {overhangs.classification}
            </span>
          </div>
          <div className="font-bold text-kf-text text-sm">
            {overhangs.totalAreaMm2} <span className="text-[10px] font-normal text-kf-muted">mm²</span>
          </div>
          <div className="text-[10px] text-kf-muted">
            {(overhangs.ratio * 100).toFixed(1)}% of surface &bull; Worst: {overhangs.worstAngleDeg}°
          </div>
        </div>

        {/* Unsupported Islands Tile */}
        <div className="trace clip-corner bg-kf-panel-2 border border-kf-border rounded-lg p-2.5 flex flex-col gap-1">
          <div className="flex items-center justify-between text-kf-muted text-[10.5px]">
            <span className="flex items-center gap-1">
              <Layers className="w-3 h-3 text-kf-pink" />
              <span>Floating Islands</span>
            </span>
            <span
              className={`text-[9.5px] px-1 py-0.2 rounded uppercase font-bold ${
                islands.length === 0
                  ? 'text-kf-ok bg-kf-ok/10'
                  : 'text-kf-fail bg-kf-fail/10'
              }`}
            >
              {islands.length === 0 ? '0 detected' : `${islands.length} risk`}
            </span>
          </div>
          <div className="font-bold text-kf-text text-sm">
            {islands.length}{' '}
            <span className="text-[10px] font-normal text-kf-muted">mid-air start{islands.length !== 1 ? 's' : ''}</span>
          </div>
          <div className="text-[10px] text-kf-muted">
            {islands.length > 0 ? `Lowest at Z=${islands[0].zHeightMm}mm` : 'All layers self-supported'}
          </div>
        </div>

        {/* Wall Thickness Tile */}
        <div className="trace clip-corner bg-kf-panel-2 border border-kf-border rounded-lg p-2.5 flex flex-col gap-1">
          <div className="flex items-center justify-between text-kf-muted text-[10.5px]">
            <span className="flex items-center gap-1">
              <Minimize2 className="w-3 h-3 text-kf-pink" />
              <span>Min Wall</span>
            </span>
            <span
              className={`text-[9.5px] px-1 py-0.2 rounded uppercase font-bold ${
                !thinWalls.hasThinWalls
                  ? 'text-kf-ok bg-kf-ok/10'
                  : thinWalls.minWallThicknessMm < thinWalls.thresholdMm * 0.5
                  ? 'text-kf-fail bg-kf-fail/10'
                  : 'text-kf-warn bg-kf-warn/10'
              }`}
            >
              {thinWalls.hasThinWalls ? 'Thin Wall' : 'Adequate'}
            </span>
          </div>
          <div className="font-bold text-kf-text text-sm">
            {thinWalls.minWallThicknessMm} <span className="text-[10px] font-normal text-kf-muted">mm</span>
          </div>
          <div className="text-[10px] text-kf-muted">
            Threshold: {thinWalls.thresholdMm}mm (2x nozzle)
          </div>
        </div>

        {/* First Layer Adhesion Tile */}
        <div className="trace clip-corner bg-kf-panel-2 border border-kf-border rounded-lg p-2.5 flex flex-col gap-1">
          <div className="flex items-center justify-between text-kf-muted text-[10.5px]">
            <span className="flex items-center gap-1">
              <Maximize2 className="w-3 h-3 text-kf-pink" />
              <span>Bed Contact</span>
            </span>
            <span
              className={`text-[9.5px] px-1 py-0.2 rounded uppercase font-bold ${
                firstLayer.status === 'optimal'
                  ? 'text-kf-ok bg-kf-ok/10'
                  : firstLayer.status === 'brim_recommended'
                  ? 'text-kf-warn bg-kf-warn/10'
                  : 'text-kf-fail bg-kf-fail/10'
              }`}
            >
              {firstLayer.status.replace('_', ' ')}
            </span>
          </div>
          <div className="font-bold text-kf-text text-sm">
            {firstLayer.areaMm2} <span className="text-[10px] font-normal text-kf-muted">mm²</span>
          </div>
          <div className="text-[10px] text-kf-muted">
            {firstLayer.needsRaft ? 'Raft Required' : firstLayer.needsBrim ? 'Brim Advised' : 'Good Direct Adhesion'}
          </div>
        </div>
      </div>

      {/* 4. BRIDGES & DETAIL METRICS (if present) */}
      {(bridges.length > 0 || smallFeatures.length > 0) && (
        <div className="trace clip-corner bg-kf-panel border border-kf-border rounded-lg p-3 flex flex-col gap-2 text-xs font-mono">
          {bridges.length > 0 && (
            <div className="flex items-center justify-between border-b border-kf-border/60 pb-1.5">
              <span className="text-kf-muted">Horizontal Bridge Span:</span>
              <span className={`font-bold ${
                bridges[0].status === 'safe'
                  ? 'text-kf-ok'
                  : bridges[0].status === 'risky'
                  ? 'text-kf-warn'
                  : 'text-kf-fail'
              }`}>
                {bridges[0].spanMm} mm ({bridges[0].status})
              </span>
            </div>
          )}

          {smallFeatures.length > 0 && (
            <div className="flex items-center justify-between">
              <span className="text-kf-muted">Sub-Nozzle Features:</span>
              <span className="text-kf-warn font-bold">
                {smallFeatures[0].sizeMm} mm (&lt; {printer?.nozzleDiameter ?? 0.4}mm)
              </span>
            </div>
          )}
        </div>
      )}

      {/* 5. DETAILED ACTION RECOMMENDATIONS */}
      {recommendations.length > 0 && (
        <div className="trace clip-corner border border-kf-border bg-kf-panel rounded-lg p-3.5 flex flex-col gap-2 shadow-sm">
          <div className="flex items-center justify-between border-b border-kf-border pb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-kf-muted font-mono flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-kf-pink" />
              <span>Actionable Recommendations</span>
            </span>
            <span className="text-[10px] font-mono text-kf-muted">
              {recommendations.length} items
            </span>
          </div>

          <div className="flex flex-col gap-2 pt-1">
            {recommendations.map((rec, idx) => (
              <div
                key={idx}
                className={`p-2.5 rounded-md border text-xs font-sans flex items-start gap-2 ${
                  rec.severity === 'blocking'
                    ? 'bg-kf-fail/10 border-kf-fail/30 text-kf-text'
                    : rec.severity === 'warning'
                    ? 'bg-kf-warn/10 border-kf-warn/30 text-kf-text'
                    : 'bg-kf-panel-2 border-kf-border text-kf-text'
                }`}
              >
                {rec.severity === 'blocking' ? (
                  <XCircle className="w-4 h-4 text-kf-fail shrink-0 mt-0.5" />
                ) : rec.severity === 'warning' ? (
                  <AlertTriangle className="w-4 h-4 text-kf-warn shrink-0 mt-0.5" />
                ) : (
                  <Info className="w-4 h-4 text-kf-pink shrink-0 mt-0.5" />
                )}

                <div className="flex flex-col gap-1">
                  <div className="leading-snug">{rec.message}</div>
                  <div className="flex items-center gap-1.5 font-mono text-[10px]">
                    <span className="px-1.5 py-0.2 bg-kf-panel border border-kf-border rounded uppercase text-kf-muted">
                      {rec.action.replace('_', ' ')}
                    </span>
                    {rec.autoFixable && (
                      <span className="text-kf-ok">
                        &bull; Auto-configured in slicer
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
