import React, { useEffect, useState, useRef } from 'react';
import {
  X,
  Play,
  Square,
  Radio,
  Thermometer,
  Wind,
  Gauge,
  Clock,
  Layers,
  Activity,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { WebSocketTelemetry, PrinterSpec, FilamentSpec, SlicerSettings, ModelGeometryStats } from '../types';

interface LivePrinterMonitorProps {
  isOpen: boolean;
  onClose: () => void;
  printer: PrinterSpec;
  filament: FilamentSpec;
  settings: SlicerSettings;
  geometryStats: ModelGeometryStats;
  scaleFactor: number;
}

export const LivePrinterMonitor: React.FC<LivePrinterMonitorProps> = ({
  isOpen,
  onClose,
  printer,
  filament,
  settings,
  geometryStats,
  scaleFactor,
}) => {
  const [telemetry, setTelemetry] = useState<WebSocketTelemetry | null>(null);
  const [wsConnected, setWsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      setWsConnected(true);
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'telemetry') {
          setTelemetry(msg.data);
        }
      } catch (e) {
        console.error('WS Parse Error:', e);
      }
    };

    ws.onclose = () => {
      setWsConnected(false);
    };

    return () => {
      ws.close();
    };
  }, [isOpen]);

  const handleStartSimulation = () => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    wsRef.current.send(
      JSON.stringify({
        type: 'start_sim',
        config: {
          printerName: printer.name,
          nozzleTemp: settings.nozzleTempFirstLayer,
          bedTemp: settings.bedTemp,
          fanPercent: settings.fanPercent,
          outerWallSpeed: settings.outerWallSpeed,
          layerHeight: settings.layerHeight,
          dimensions: {
            x: geometryStats.dimensions.x * scaleFactor,
            y: geometryStats.dimensions.y * scaleFactor,
            z: geometryStats.dimensions.z * scaleFactor,
          },
          printTimeMinutes: settings.estimatedPrintTimeMinutes,
        },
      })
    );
  };

  const handleCancelSimulation = () => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    wsRef.current.send(JSON.stringify({ type: 'cancel_sim' }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="trace clip-corner bg-kf-panel border border-kf-border rounded-xl w-full max-w-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150 text-kf-text">
        {/* Modal Header */}
        <div className="trace clip-corner flex items-center justify-between px-5 py-3.5 border-b border-kf-border bg-kf-panel-2">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-kf-pink animate-pulse" />
            <span className="text-xs font-semibold uppercase tracking-wider text-kf-text font-mono">
              Live Printer Telemetry & Execution Monitor
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span
              className={`flex items-center gap-1 text-[11px] font-mono px-2.5 py-0.5 rounded-md border ${
                wsConnected
                  ? 'bg-kf-ok/10 border-kf-ok/40 text-kf-ok'
                  : 'bg-kf-fail/10 border-kf-fail/40 text-kf-fail'
              }`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${wsConnected ? 'bg-kf-ok animate-ping' : 'bg-kf-fail'}`} />
              {wsConnected ? 'WebSocket Connected' : 'Disconnected'}
            </span>

            <button
              id="btn-close-monitor"
              onClick={onClose}
              className="text-kf-muted hover:text-kf-text p-1 rounded-md transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 flex flex-col gap-4">
          {/* Status Banner */}
          <div className="trace clip-corner bg-kf-panel-2 border border-kf-border p-3.5 rounded-lg flex items-center justify-between font-mono">
            <div>
              <div className="text-[10px] text-kf-muted uppercase">Target Machine</div>
              <div className="text-xs font-bold text-kf-text">{printer.name}</div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-kf-muted uppercase">Machine State</div>
              <div
                className={`text-xs font-bold uppercase ${
                  telemetry?.status === 'printing'
                    ? 'text-kf-pink'
                    : telemetry?.status === 'preheating' || telemetry?.status === 'calibrating'
                    ? 'text-kf-warn'
                    : telemetry?.status === 'completed'
                    ? 'text-kf-ok'
                    : 'text-kf-muted'
                }`}
              >
                {telemetry?.status || 'Idle / Standby'}
              </div>
            </div>
          </div>

          {/* Real-time Progress */}
          <div className="flex flex-col gap-1.5 font-mono">
            <div className="flex justify-between text-xs">
              <span className="text-kf-muted">
                Layer {telemetry?.currentLayer || 0} of {telemetry?.totalLayers || 0}
              </span>
              <span className="text-kf-pink font-bold">{telemetry?.progressPercent || 0}%</span>
            </div>

            <div className="w-full bg-kf-bg h-3 rounded-md overflow-hidden border border-kf-border">
              <div
                className="bg-gradient-to-r from-kf-pink-dim to-kf-pink h-full transition-all duration-300 shadow-[0_0_8px_rgba(255,61,138,0.5)]"
                style={{ width: `${telemetry?.progressPercent || 0}%` }}
              />
            </div>
          </div>

          {/* Gauges Grid */}
          <div className="grid grid-cols-4 gap-2.5 font-mono">
            {/* Nozzle Temp */}
            <div className="trace clip-corner bg-kf-panel-2 border border-kf-border p-3 rounded-lg text-center">
              <div className="flex items-center justify-center gap-1 text-[10px] text-kf-muted mb-1">
                <Thermometer className="w-3 h-3 text-kf-warn" />
                <span>Extruder</span>
              </div>
              <div className="text-sm font-bold text-kf-warn">
                {telemetry?.nozzleTemp || 24}°C
              </div>
              <div className="text-[10px] text-kf-muted">
                Target: {telemetry?.targetNozzleTemp || settings.nozzleTempFirstLayer}°C
              </div>
            </div>

            {/* Bed Temp */}
            <div className="trace clip-corner bg-kf-panel-2 border border-kf-border p-3 rounded-lg text-center">
              <div className="flex items-center justify-center gap-1 text-[10px] text-kf-muted mb-1">
                <Thermometer className="w-3 h-3 text-kf-fail" />
                <span>Heated Bed</span>
              </div>
              <div className="text-sm font-bold text-kf-fail">{telemetry?.bedTemp || 22}°C</div>
              <div className="text-[10px] text-kf-muted">
                Target: {telemetry?.targetBedTemp || settings.bedTemp}°C
              </div>
            </div>

            {/* Print Speed */}
            <div className="trace clip-corner bg-kf-panel-2 border border-kf-border p-3 rounded-lg text-center">
              <div className="flex items-center justify-center gap-1 text-[10px] text-kf-muted mb-1">
                <Gauge className="w-3 h-3 text-kf-pink" />
                <span>Toolhead Speed</span>
              </div>
              <div className="text-sm font-bold text-kf-pink">
                {telemetry?.currentSpeedMmS || 0} mm/s
              </div>
              <div className="text-[10px] text-kf-muted">
                Flow: {telemetry?.flowRateMm3S || 0} mm³/s
              </div>
            </div>

            {/* Fan Speed */}
            <div className="trace clip-corner bg-kf-panel-2 border border-kf-border p-3 rounded-lg text-center">
              <div className="flex items-center justify-center gap-1 text-[10px] text-kf-muted mb-1">
                <Wind className="w-3 h-3 text-cyan-400" />
                <span>Part Fan</span>
              </div>
              <div className="text-sm font-bold text-cyan-400">
                {telemetry?.fanSpeedPercent || 0}%
              </div>
              <div className="text-[10px] text-kf-muted">
                Elapsed: {Math.floor((telemetry?.printTimeElapsedSec || 0) / 60)}m
              </div>
            </div>
          </div>

          {/* Console / Status Message */}
          <div className="trace clip-corner bg-kf-panel-2 border border-kf-border p-3 rounded-lg font-mono text-[11px] text-kf-muted flex items-start gap-2">
            <Activity className="w-3.5 h-3.5 text-kf-pink shrink-0 mt-0.5" />
            <span className="leading-snug text-kf-text">{telemetry?.message || 'Ready.'}</span>
          </div>

          {/* Modal Action Controls */}
          <div className="flex justify-end gap-2 pt-2 border-t border-kf-border">
            {telemetry?.status === 'printing' ||
            telemetry?.status === 'preheating' ||
            telemetry?.status === 'calibrating' ? (
              <button
                type="button"
                id="btn-abort-sim"
                onClick={handleCancelSimulation}
                className="flex items-center gap-1.5 bg-kf-fail/20 hover:bg-kf-fail/30 text-kf-fail border border-kf-fail/50 font-mono py-2 px-3.5 rounded-md text-xs transition"
              >
                <Square className="w-3.5 h-3.5" />
                <span>Abort Print Job</span>
              </button>
            ) : (
              <button
                type="button"
                id="btn-start-sim"
                onClick={handleStartSimulation}
                className="flex items-center gap-1.5 bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-mono font-semibold py-2 px-4 rounded-md text-xs transition shadow-md shadow-kf-pink/20"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Start Print Job Simulation</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
