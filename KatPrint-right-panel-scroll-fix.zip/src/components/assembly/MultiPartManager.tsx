import React, { useState } from 'react';
import {
  Layers,
  Package,
  Eye,
  EyeOff,
  Download,
  Sliders,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  FileArchive,
  ChevronDown,
  ChevronUp,
  Info,
  Maximize2,
  Plus,
  Minus,
} from 'lucide-react';
import { ExecutedModelPart, ModelAssemblyDefinition, PrinterSpec, FilamentSpec } from '../../types';
import { downloadBinarySTL, downloadMultiPartZip, downloadExportSTL, getPhysicalPieceCount, hasMultiplePhysicalPieces } from '../../engine/stlExporter';

export interface MultiPartManagerProps {
  parts: ExecutedModelPart[];
  assemblyDef?: ModelAssemblyDefinition | null;
  projectName: string;
  versionLabel?: string;
  selectedPartId?: string | null;
  onSelectPart: (partId: string | null) => void;
  partVisibility: Record<string, boolean>;
  onTogglePartVisibility: (partId: string) => void;
  explodedOffset: number;
  onExplodedOffsetChange: (offset: number) => void;
  scaleFactor?: number;
  printer?: PrinterSpec;
  filament?: FilamentSpec;
  onOpenPlateLayoutModal?: () => void;
  onUpdatePartQuantity?: (partId: string, quantity: number) => void;
}

export const PART_PALETTE = [
  '#3b82f6', // Bright Blue
  '#10b981', // Emerald Green
  '#f59e0b', // Amber
  '#ec4899', // Pink
  '#8b5cf6', // Purple
  '#06b6d4', // Cyan
  '#f97316', // Orange
  '#14b8a6', // Teal
];

export const MultiPartManager: React.FC<MultiPartManagerProps> = ({
  parts = [],
  assemblyDef,
  projectName,
  versionLabel = 'V1',
  selectedPartId,
  onSelectPart,
  partVisibility,
  onTogglePartVisibility,
  explodedOffset,
  onExplodedOffsetChange,
  scaleFactor = 1.0,
  printer,
  filament,
  onOpenPlateLayoutModal,
  onUpdatePartQuantity,
}) => {
  const [isExportingZip, setIsExportingZip] = useState(false);
  const [showRelationships, setShowRelationships] = useState(true);

  const totalVolume = parts.reduce((acc, p) => acc + (p.stats?.volumeCm3 || 0) * (p.quantity || 1), 0) * Math.pow(scaleFactor, 3);
  const totalWeight = parts.reduce((acc, p) => acc + (p.stats?.estimatedWeightGrams || 0) * (p.quantity || 1), 0) * Math.pow(scaleFactor, 3);
  const totalQuantity = getPhysicalPieceCount(parts);

  const handleDownloadSingleStl = () => {
    downloadExportSTL(null, parts, `${projectName}_all_pieces`, scaleFactor, 10);
  };

  const handleExportZip = async () => {
    setIsExportingZip(true);
    try {
      await downloadMultiPartZip({
        projectName,
        versionLabel,
        parts,
        assemblyDef,
        scale: scaleFactor,
        filamentType: filament?.name || 'PLA',
        printerName: printer?.name || 'Bambu Lab X1-Carbon',
      });
    } catch (err) {
      console.error('Failed to export multi-part ZIP:', err);
    } finally {
      setIsExportingZip(false);
    }
  };

  if (!hasMultiplePhysicalPieces(parts)) {
    return (
      <div className="p-4 rounded-xl bg-[#151419] border border-[#24222b] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-white">
            <Package className="w-4 h-4 text-pink-400" />
            <span>Single-Part Model</span>
          </div>
          <span className="text-[11px] text-[#8c8694]">1 Component</span>
        </div>
        <p className="text-xs text-[#9d98a5] leading-relaxed">
          This model is executed as a single solid. If you need multiple pieces (e.g. &ldquo;box with a separate lid and hinge pin&rdquo;), ask in the chat and KatPrint will generate them as separate printable solids.
        </p>
      </div>
    );
  }

  const partNamesSummary = parts.map(p => (p.quantity > 1 ? `${p.name} (${p.quantity}x)` : p.name)).join(', ');

  return (
    <div className="space-y-4">
      {/* Assembly Header & Overview Card */}
      <div className="p-4 rounded-2xl bg-[#16151a] border border-[#282531] space-y-3 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-pink-500/10 border border-pink-500/20 flex items-center justify-center text-pink-400">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight">
                {totalQuantity} Printable Pieces
              </h3>
              <p className="text-[11px] text-[#8c8694] line-clamp-1">
                {partNamesSummary}
              </p>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-pink-500/20 text-pink-400 border border-pink-500/30">
            {parts.length} Part {parts.length === 1 ? 'Type' : 'Types'} · {totalQuantity} Pieces
          </span>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-[#23212b]">
          <div className="bg-[#121115] p-2 rounded-xl border border-[#201e26]">
            <div className="text-[10px] uppercase font-bold text-[#8c8694]">Total Volume</div>
            <div className="text-xs font-bold text-white mt-0.5">{totalVolume.toFixed(1)} cm³</div>
          </div>
          <div className="bg-[#121115] p-2 rounded-xl border border-[#201e26]">
            <div className="text-[10px] uppercase font-bold text-[#8c8694]">Est. Filament</div>
            <div className="text-xs font-bold text-pink-400 mt-0.5">{totalWeight.toFixed(1)} g ({filament?.name || 'PLA'})</div>
          </div>
        </div>

        {/* Exploded View Slider */}
        <div className="space-y-1.5 pt-2 border-t border-[#23212b]">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-white flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-pink-400" />
              Exploded View (Visual)
            </span>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono text-pink-400 font-bold">{explodedOffset} mm</span>
              {explodedOffset > 0 && (
                <button
                  onClick={() => onExplodedOffsetChange(0)}
                  className="text-[10px] text-[#9d98a5] hover:text-white underline"
                >
                  Collapse
                </button>
              )}
            </div>
          </div>
          <input
            type="range"
            min="0"
            max="80"
            step="2"
            value={explodedOffset}
            onChange={(e) => onExplodedOffsetChange(Number(e.target.value))}
            className="w-full accent-pink-500 h-1.5 bg-[#25232d] rounded-lg cursor-pointer"
          />
        </div>

        {/* Action Buttons: Primary Download 1 STL + Secondary ZIP */}
        <div className="grid grid-cols-2 gap-2 pt-2">
          <button
            onClick={handleDownloadSingleStl}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-pink-500 hover:bg-pink-600 text-white text-xs font-bold shadow-md shadow-pink-500/20 transition-all cursor-pointer"
            title="Exports all pieces as separate disconnected solids spaced 10mm apart on Z=0 in one STL"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download STL</span>
          </button>
          <button
            onClick={handleExportZip}
            disabled={isExportingZip}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[#201e28] hover:bg-[#282633] disabled:opacity-50 text-white text-xs font-semibold border border-[#34313f] transition-all cursor-pointer"
            title="Download ZIP package with individual part STLs, assembly guide, and manifest"
          >
            <FileArchive className="w-3.5 h-3.5 text-blue-400" />
            <span>{isExportingZip ? 'Packaging...' : 'Export ZIP'}</span>
          </button>
        </div>

        {/* Slicer Import & Split Info Callout */}
        <div className="p-2.5 rounded-xl bg-[#121116] border border-[#23202d] text-[11px] text-[#9d98a5] leading-relaxed flex items-start gap-2">
          <Info className="w-3.5 h-3.5 text-pink-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-white">Slicer Ready: </span>
            <span>
              All pieces are exported into a single STL as separate disconnected solids. In{' '}
              <strong className="text-[#d5d0dd]">Bambu Studio, OrcaSlicer, PrusaSlicer, or Cura</strong>, simply click{' '}
              <strong className="text-pink-400">&ldquo;Split to Objects&rdquo;</strong> to arrange, rotate, and slice each piece on your print bed.
            </span>
          </div>
        </div>
      </div>

      {/* Bill of Materials / Part List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold text-white uppercase tracking-wider">Bill of Materials</span>
          <span className="text-[11px] text-[#8c8694]">Click part to inspect in 3D</span>
        </div>

        <div className="space-y-2">
          {parts.map((part, idx) => {
            const isSelected = selectedPartId === part.id;
            const isVisible = partVisibility[part.id] !== false;
            const color = PART_PALETTE[idx % PART_PALETTE.length];
            const dims = part.stats?.dimensions || { x: 0, y: 0, z: 0 };
            const scaledDims = `${(dims.x * scaleFactor).toFixed(1)} × ${(dims.y * scaleFactor).toFixed(1)} × ${(dims.z * scaleFactor).toFixed(1)} mm`;

            return (
              <div
                key={part.id}
                onClick={() => onSelectPart(isSelected ? null : part.id)}
                className={`p-3 rounded-xl border transition-all cursor-pointer flex flex-col gap-2 ${
                  isSelected
                    ? 'bg-[#1e1c25] border-pink-500 shadow-md shadow-pink-500/10'
                    : 'bg-[#151419] border-[#25232d] hover:border-[#3a3746]'
                } ${!isVisible ? 'opacity-50' : ''}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full shrink-0 shadow-sm"
                      style={{ backgroundColor: color }}
                    />
                    <span className="text-xs font-bold text-white tracking-tight">{part.name}</span>
                    {part.quantity > 1 && (
                      <span className="px-1.5 py-0.2 rounded bg-[#272430] text-[10px] font-mono text-[#b8b3be] border border-[#383444]">
                        {part.quantity}x
                      </span>
                    )}
                  </div>

                  {/* Actions: Visibility & Direct STL download */}
                  <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => onTogglePartVisibility(part.id)}
                      className={`p-1.5 rounded-lg transition-colors ${
                        isVisible ? 'text-[#a8a3ad] hover:text-white hover:bg-[#23212b]' : 'text-pink-400 bg-pink-500/10'
                      }`}
                      title={isVisible ? 'Hide in 3D' : 'Show in 3D'}
                    >
                      {isVisible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      onClick={() => downloadBinarySTL(part.geometry, `${projectName}_${part.name}`, scaleFactor)}
                      className="p-1.5 rounded-lg text-[#a8a3ad] hover:text-pink-400 hover:bg-[#23212b] transition-colors"
                      title="Download STL for this part only"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Dimensions & Print Specs */}
                <div className="flex items-center justify-between text-[11px] text-[#8c8694] border-t border-[#1e1d24] pt-1.5 font-mono">
                  <span>{scaledDims}</span>
                  <div className="flex items-center gap-2">
                    <span>{((part.stats?.volumeCm3 || 0) * Math.pow(scaleFactor, 3)).toFixed(1)} cm³</span>
                    {part.requiresSupports && (
                      <span className="text-amber-400 text-[10px] font-semibold flex items-center gap-0.5" title="Supports recommended for this part">
                        <AlertTriangle className="w-3 h-3" />
                        Supports
                      </span>
                    )}
                  </div>
                </div>

                {/* Quantity adjuster if handler is provided */}
                {onUpdatePartQuantity && (
                  <div
                    className="flex items-center justify-between pt-1 border-t border-[#1e1d24] text-xs"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <span className="text-[11px] text-[#8c8694]">Print Quantity:</span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => onUpdatePartQuantity(part.id, Math.max(1, (part.quantity || 1) - 1))}
                        disabled={(part.quantity || 1) <= 1}
                        className="p-1 rounded bg-[#23212b] hover:bg-[#2e2b38] disabled:opacity-30 text-white"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="font-mono text-xs font-bold text-white px-1.5">{part.quantity || 1}</span>
                      <button
                        onClick={() => onUpdatePartQuantity(part.id, (part.quantity || 1) + 1)}
                        className="p-1 rounded bg-[#23212b] hover:bg-[#2e2b38] text-white"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Assembly Mating Relationships Card */}
      {assemblyDef && assemblyDef.relationships && assemblyDef.relationships.length > 0 && (
        <div className="p-3.5 rounded-xl bg-[#141318] border border-[#222029] space-y-2">
          <button
            onClick={() => setShowRelationships(!showRelationships)}
            className="w-full flex items-center justify-between text-xs font-bold text-white"
          >
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-pink-400" />
              Mating Clearance Fits ({assemblyDef.relationships.length})
            </span>
            {showRelationships ? <ChevronUp className="w-4 h-4 text-[#8c8694]" /> : <ChevronDown className="w-4 h-4 text-[#8c8694]" />}
          </button>

          {showRelationships && (
            <div className="space-y-1.5 pt-1.5 border-t border-[#1f1d26]">
              {assemblyDef.relationships.map((rel, i) => (
                <div key={i} className="text-xs p-2 rounded-lg bg-[#18171e] border border-[#262430] space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">
                      {rel.sourcePartId} ➡️ {rel.targetPartId}
                    </span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                      {rel.type}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#9d98a5]">{rel.description}</div>
                  {rel.clearanceMm !== undefined && (
                    <div className="text-[11px] font-mono text-emerald-400">
                      Clearance: {rel.clearanceMm} mm (FDM fit verified)
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
