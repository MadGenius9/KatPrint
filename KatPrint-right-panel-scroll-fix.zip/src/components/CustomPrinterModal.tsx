import React, { useState } from 'react';
import { X, Save, Settings, Wrench } from 'lucide-react';
import { PrinterSpec } from '../types';

interface CustomPrinterModalProps {
  isOpen: boolean;
  onClose: () => void;
  printer?: PrinterSpec;
  initialPrinter?: PrinterSpec;
  onSave: (updated: PrinterSpec) => void;
}

const DEFAULT_FALLBACK_PRINTER: PrinterSpec = {
  id: 'custom',
  name: 'Custom 3D Printer',
  buildVolume: { x: 220, y: 220, z: 250 },
  nozzleDiameter: 0.4,
  driveType: 'direct',
  isEnclosed: false,
  maxVolumetricFlow: 20,
  isCustom: true,
};

export const CustomPrinterModal: React.FC<CustomPrinterModalProps> = ({
  isOpen,
  onClose,
  printer,
  initialPrinter,
  onSave,
}) => {
  const activePrinter = printer || initialPrinter || DEFAULT_FALLBACK_PRINTER;

  const [name, setName] = useState(activePrinter.name);
  const [volX, setVolX] = useState(activePrinter.buildVolume.x);
  const [volY, setVolY] = useState(activePrinter.buildVolume.y);
  const [volZ, setVolZ] = useState(activePrinter.buildVolume.z);
  const [nozzle, setNozzle] = useState(activePrinter.nozzleDiameter);
  const [driveType, setDriveType] = useState<'direct' | 'bowden'>(activePrinter.driveType);
  const [isEnclosed, setIsEnclosed] = useState(activePrinter.isEnclosed);
  const [maxVolFlow, setMaxVolFlow] = useState(activePrinter.maxVolumetricFlow);

  // Sync state whenever active printer changes or modal opens
  React.useEffect(() => {
    if (activePrinter) {
      setName(activePrinter.name);
      setVolX(activePrinter.buildVolume.x);
      setVolY(activePrinter.buildVolume.y);
      setVolZ(activePrinter.buildVolume.z);
      setNozzle(activePrinter.nozzleDiameter);
      setDriveType(activePrinter.driveType);
      setIsEnclosed(activePrinter.isEnclosed);
      setMaxVolFlow(activePrinter.maxVolumetricFlow);
    }
  }, [activePrinter, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...activePrinter,
      name,
      buildVolume: { x: volX, y: volY, z: volZ },
      nozzleDiameter: nozzle,
      driveType,
      isEnclosed,
      maxVolumetricFlow: maxVolFlow,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="trace clip-corner bg-kf-panel border border-kf-border rounded-xl w-full max-w-lg shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150 text-kf-text">
        <div className="trace clip-corner flex items-center justify-between px-5 py-3.5 border-b border-kf-border bg-kf-panel-2">
          <div className="flex items-center gap-2">
            <Wrench className="w-4 h-4 text-kf-pink" />
            <span className="text-xs font-semibold uppercase tracking-wider text-kf-text font-mono">
              Configure Custom 3D Printer
            </span>
          </div>
          <button onClick={onClose} className="text-kf-muted hover:text-kf-text p-1 rounded-md transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 flex flex-col gap-4 text-xs font-mono">
          <div>
            <label className="text-kf-muted block mb-1">Printer Profile Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-kf-panel-2 border border-kf-border px-3 py-2 rounded-md text-kf-text focus:outline-none focus:border-kf-pink font-sans text-xs"
            />
          </div>

          <div className="grid grid-cols-3 gap-2.5">
            <div>
              <label className="text-kf-muted block mb-1">Volume X (mm)</label>
              <input
                type="number"
                value={volX}
                onChange={(e) => setVolX(parseFloat(e.target.value))}
                className="w-full bg-kf-panel-2 border border-kf-border px-2.5 py-1.5 rounded-md text-kf-pink focus:outline-none focus:border-kf-pink"
              />
            </div>
            <div>
              <label className="text-kf-muted block mb-1">Volume Y (mm)</label>
              <input
                type="number"
                value={volY}
                onChange={(e) => setVolY(parseFloat(e.target.value))}
                className="w-full bg-kf-panel-2 border border-kf-border px-2.5 py-1.5 rounded-md text-kf-pink focus:outline-none focus:border-kf-pink"
              />
            </div>
            <div>
              <label className="text-kf-muted block mb-1">Volume Z (mm)</label>
              <input
                type="number"
                value={volZ}
                onChange={(e) => setVolZ(parseFloat(e.target.value))}
                className="w-full bg-kf-panel-2 border border-kf-border px-2.5 py-1.5 rounded-md text-kf-pink focus:outline-none focus:border-kf-pink"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-kf-muted block mb-1">Nozzle Diameter (mm)</label>
              <select
                value={nozzle}
                onChange={(e) => setNozzle(parseFloat(e.target.value))}
                className="w-full bg-kf-panel-2 border border-kf-border px-2.5 py-1.5 rounded-md text-kf-text focus:outline-none focus:border-kf-pink"
              >
                <option value={0.2}>0.2 mm (Fine Detail)</option>
                <option value={0.4}>0.4 mm (Standard)</option>
                <option value={0.6}>0.6 mm (High Flow)</option>
                <option value={0.8}>0.8 mm (Coarse Rapid)</option>
              </select>
            </div>

            <div>
              <label className="text-kf-muted block mb-1">Max Flow (mm³/s)</label>
              <input
                type="number"
                value={maxVolFlow}
                onChange={(e) => setMaxVolFlow(parseFloat(e.target.value))}
                className="w-full bg-kf-panel-2 border border-kf-border px-2.5 py-1.5 rounded-md text-kf-text focus:outline-none focus:border-kf-pink"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <div>
              <label className="text-kf-muted block mb-1">Drive Kinematics</label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setDriveType('direct')}
                  className={`flex-1 py-1.5 text-center rounded-md border transition ${
                    driveType === 'direct'
                      ? 'bg-kf-pink border-kf-pink text-[#0A0004] font-semibold'
                      : 'bg-kf-panel-2 border-kf-border text-kf-muted hover:text-kf-text'
                  }`}
                >
                  Direct Drive
                </button>
                <button
                  type="button"
                  onClick={() => setDriveType('bowden')}
                  className={`flex-1 py-1.5 text-center rounded-md border transition ${
                    driveType === 'bowden'
                      ? 'bg-kf-pink border-kf-pink text-[#0A0004] font-semibold'
                      : 'bg-kf-panel-2 border-kf-border text-kf-muted hover:text-kf-text'
                  }`}
                >
                  Bowden
                </button>
              </div>
            </div>

            <div>
              <label className="text-kf-muted block mb-1">Thermal Chamber</label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsEnclosed(true)}
                  className={`flex-1 py-1.5 text-center rounded-md border transition ${
                    isEnclosed
                      ? 'bg-kf-pink border-kf-pink text-[#0A0004] font-semibold'
                      : 'bg-kf-panel-2 border-kf-border text-kf-muted hover:text-kf-text'
                  }`}
                >
                  Enclosed
                </button>
                <button
                  type="button"
                  onClick={() => setIsEnclosed(false)}
                  className={`flex-1 py-1.5 text-center rounded-md border transition ${
                    !isEnclosed
                      ? 'bg-kf-pink border-kf-pink text-[#0A0004] font-semibold'
                      : 'bg-kf-panel-2 border-kf-border text-kf-muted hover:text-kf-text'
                  }`}
                >
                  Open Frame
                </button>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3.5 border-t border-kf-border mt-1">
            <button
              type="button"
              onClick={onClose}
              className="bg-kf-panel-2 hover:bg-kf-border text-kf-muted hover:text-kf-text px-3.5 py-1.5 rounded-md border border-kf-border transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] px-4 py-1.5 rounded-md font-semibold flex items-center gap-1.5 shadow-md shadow-kf-pink/20 transition"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Apply Profile</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
