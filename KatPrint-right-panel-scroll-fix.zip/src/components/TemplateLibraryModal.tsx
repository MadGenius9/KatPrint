import React from 'react';
import { X, Box, Layers, Sliders, ArrowRight } from 'lucide-react';

interface TemplateItem {
  id: string;
  name: string;
  category: string;
  description: string;
  defaultPrompt: string;
}

const TEMPLATE_PRESETS: TemplateItem[] = [
  {
    id: 'tpl-planter',
    name: 'Self-Watering Planter & Reservoir',
    category: 'Home & Garden',
    description: 'Double-walled planter with water reservoir, wicking column, and drainage holes.',
    defaultPrompt: 'Self-watering planter 150mm tall with 35mm bottom reservoir, wicking column and drainage slots',
  },
  {
    id: 'tpl-enclosure',
    name: 'Electronics Project Enclosure',
    category: 'Electronics',
    description: 'Snap-fit parametric box with 4 corner mounting standoffs and cable openings.',
    defaultPrompt: 'Electronics enclosure box 100x60x25mm with 3mm walls and four M3 mounting corner standoffs',
  },
  {
    id: 'tpl-bracket',
    name: 'Reinforced 90° Angle Bracket',
    category: 'Mechanical',
    description: 'Heavy duty angle mounting bracket with center gusset web and countersunk screw holes.',
    defaultPrompt: 'Heavy duty angled mounting bracket 60x60mm with 5mm thickness and 4 countersunk screw holes',
  },
  {
    id: 'tpl-bin',
    name: 'Stackable Modular Organizer Bin',
    category: 'Storage',
    description: 'Interlocking organizer bin with stacking rim and chamfered bottom lip.',
    defaultPrompt: 'Interlocking parametric storage bin 100x80x50mm with 3mm wall thickness and stacking rim',
  },
  {
    id: 'tpl-flange',
    name: 'Circular Bolt Flange Adapter',
    category: 'Mechanical',
    description: 'Circular flange with central bore and radial bolt circle pattern.',
    defaultPrompt: 'Circular flange 100mm diameter, 8mm thick, 30mm central bore, 6x 5mm bolt holes around 75mm bolt circle',
  },
  {
    id: 'tpl-stand',
    name: 'Desk Phone / Tablet Stand',
    category: 'Office & Desk',
    description: 'Angled cradle stand with cable pass-through slot and non-slip lip.',
    defaultPrompt: 'Desk phone stand with 12mm deep slot, 70 degree viewing angle, and charging cable cutout',
  },
];

interface TemplateLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTemplate: (prompt: string) => void;
}

export const TemplateLibraryModal: React.FC<TemplateLibraryModalProps> = ({
  isOpen,
  onClose,
  onSelectTemplate,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-fadeIn">
      <div className="trace clip-corner bg-kf-panel border border-kf-border rounded-xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[85vh] overflow-hidden text-kf-text font-sans">
        {/* Header */}
        <div className="trace clip-corner flex items-center justify-between px-5 py-4 border-b border-kf-border bg-kf-panel-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-kf-pink/15 border border-kf-pink/30 flex items-center justify-center text-kf-pink">
              <Box className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold font-mono tracking-tight text-kf-text">
                Explicit Parametric Template Library
              </h2>
              <p className="text-[11px] text-kf-muted">
                Pre-engineered mechanical templates (explicitly chosen, never silently substituted).
              </p>
            </div>
          </div>
          <button
            type="button"
            id="btn-close-template-modal"
            onClick={onClose}
            className="text-kf-muted hover:text-kf-text p-1.5 rounded-md hover:bg-kf-border/40 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Template Grid */}
        <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-3.5 overflow-y-auto">
          {TEMPLATE_PRESETS.map((tpl) => (
            <div
              key={tpl.id}
              className="trace clip-corner bg-kf-panel-2 border border-kf-border rounded-lg p-3.5 flex flex-col justify-between gap-3 hover:border-kf-pink/40 transition shadow-sm"
            >
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-kf-text">
                    {tpl.name}
                  </span>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-kf-panel border border-kf-border text-kf-muted">
                    {tpl.category}
                  </span>
                </div>
                <p className="text-[11px] text-kf-muted leading-snug">
                  {tpl.description}
                </p>
              </div>

              <button
                type="button"
                id={`btn-load-${tpl.id}`}
                onClick={() => {
                  onSelectTemplate(tpl.defaultPrompt);
                  onClose();
                }}
                className="w-full flex items-center justify-center gap-1.5 bg-kf-panel hover:bg-kf-border/60 border border-kf-border hover:border-kf-pink/40 text-kf-pink font-mono text-xs font-semibold py-1.5 px-3 rounded transition cursor-pointer"
              >
                <span>Load Template</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
