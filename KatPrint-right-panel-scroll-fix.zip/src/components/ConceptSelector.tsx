import React, { useState } from 'react';
import {
  Compass,
  Layers,
  Clock,
  Weight,
  CheckCircle2,
  XCircle,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  PenTool,
  Wand2,
  Cpu,
  Boxes,
  HelpCircle,
} from 'lucide-react';
import { DesignConcept, ExtractedRequirements } from '../types';

interface ConceptSelectorProps {
  concepts: DesignConcept[];
  prompt: string;
  baseRequirements: ExtractedRequirements;
  onSelectConcept: (concept: DesignConcept) => void;
  onCustomApproach: (customDirectives: string) => void;
  onSkip?: () => void;
  isGenerating?: boolean;
}

export const ConceptSelector: React.FC<ConceptSelectorProps> = ({
  concepts,
  prompt,
  baseRequirements,
  onSelectConcept,
  onCustomApproach,
  onSkip,
  isGenerating = false,
}) => {
  const [selectedConceptId, setSelectedConceptId] = useState<string | null>(null);
  const [showCustomInput, setShowCustomInput] = useState(false);
  const [customDirectives, setCustomDirectives] = useState('');

  const formatTime = (minutes: number) => {
    if (minutes < 60) return `${minutes}m`;
    const hrs = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hrs}h ${mins}m` : `${hrs}h`;
  };

  const getDifficultyColor = (diff: string) => {
    switch (diff) {
      case 'easy':
        return 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60';
      case 'advanced':
        return 'text-amber-400 bg-amber-950/40 border-amber-800/60';
      default:
        return 'text-sky-400 bg-sky-950/40 border-sky-800/60';
    }
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (customDirectives.trim() && !isGenerating) {
      onCustomApproach(customDirectives.trim());
    }
  };

  return (
    <div className="flex flex-col gap-4 text-kf-text animate-fadeIn">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-kf-border">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded bg-kf-pink/15 text-kf-pink border border-kf-pink/30">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-mono font-bold uppercase tracking-wider text-kf-text">
                Choose Design Strategy
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-kf-pink/15 text-kf-pink border border-kf-pink/30 font-bold uppercase">
                3 Variants
              </span>
            </div>
            <p className="text-xs text-kf-muted mt-0.5">
              Select an architectural strategy before CAD synthesis. Each variant differs in mechanical mounting, part count, and manufacturing trade-offs.
            </p>
          </div>
        </div>

        {onSkip && (
          <button
            type="button"
            onClick={onSkip}
            disabled={isGenerating}
            className="text-[11px] font-mono text-kf-muted hover:text-kf-text px-2.5 py-1 rounded border border-kf-border hover:border-kf-muted transition shrink-0 cursor-pointer self-start sm:self-auto"
          >
            Skip & use base spec &rarr;
          </button>
        )}
      </div>

      {/* 3 Strategy Concept Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5">
        {concepts.map((concept, idx) => {
          const isSelected = selectedConceptId === concept.id;
          const letter = (concept.id || ['a', 'b', 'c'][idx] || 'a').toUpperCase();

          return (
            <div
              key={concept.id || idx}
              id={`concept-card-${concept.id}`}
              className={`trace clip-corner p-[1px] transition-all flex flex-col ${
                isSelected
                  ? 'trace-active border-kf-pink shadow-lg shadow-kf-pink/10 ring-1 ring-kf-pink'
                  : 'hover:border-kf-pink/50'
              }`}
            >
              <div className="bg-kf-panel-2 p-3.5 flex flex-col justify-between h-full gap-3.5">
                {/* Concept Title & ID */}
                <div className="flex flex-col gap-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded bg-kf-pink/20 text-kf-pink border border-kf-pink/40 uppercase tracking-wider">
                      Strategy {letter}
                    </span>
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border uppercase ${getDifficultyColor(
                        concept.difficulty
                      )}`}
                    >
                      {concept.difficulty}
                    </span>
                  </div>

                  <h3 className="text-xs font-mono font-bold text-kf-text leading-tight group-hover:text-kf-pink transition">
                    {concept.name}
                  </h3>

                  <p className="text-[11px] text-kf-muted leading-relaxed font-sans">
                    {concept.approach}
                  </p>
                </div>

                {/* Key Features List */}
                <div className="space-y-1.5 bg-kf-panel/60 p-2.5 rounded border border-kf-border/80">
                  <span className="text-[10px] font-mono font-bold text-kf-text uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-kf-pink" />
                    Key Features
                  </span>
                  <ul className="space-y-1">
                    {concept.keyFeatures.map((feat, fIdx) => (
                      <li key={fIdx} className="text-[11px] text-kf-muted flex items-start gap-1.5 leading-snug">
                        <span className="text-kf-pink mt-0.5 shrink-0">&bull;</span>
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Trade-offs: Pros & Cons */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                  {/* Pros */}
                  <div className="space-y-1 bg-emerald-950/20 p-2 rounded border border-emerald-800/30">
                    <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 shrink-0" />
                      Pros
                    </span>
                    <ul className="space-y-1">
                      {concept.tradeoffs.pros.map((pro, pIdx) => (
                        <li key={pIdx} className="text-[10px] text-emerald-200/90 leading-tight">
                          + {pro}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Cons */}
                  <div className="space-y-1 bg-amber-950/20 p-2 rounded border border-amber-800/30">
                    <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1">
                      <XCircle className="w-3 h-3 shrink-0" />
                      Cons
                    </span>
                    <ul className="space-y-1">
                      {concept.tradeoffs.cons.map((con, cIdx) => (
                        <li key={cIdx} className="text-[10px] text-amber-200/90 leading-tight">
                          - {con}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Dimension deltas notice if any */}
                {concept.dimensionDeltas && concept.dimensionDeltas.toLowerCase() !== 'matches base specification dimensions' && (
                  <div className="text-[10px] font-mono text-kf-muted bg-kf-panel p-2 rounded border border-kf-border flex items-center gap-1.5">
                    <HelpCircle className="w-3 h-3 text-kf-pink shrink-0" />
                    <span className="truncate">{concept.dimensionDeltas}</span>
                  </div>
                )}

                {/* Small Stat Row */}
                <div className="pt-2 border-t border-kf-border flex flex-wrap items-center justify-between gap-2 text-[10px] font-mono text-kf-muted">
                  <div className="flex items-center gap-1" title="Estimated print time">
                    <Clock className="w-3 h-3 text-kf-pink" />
                    <span>{formatTime(concept.estimatedPrintTimeMin)}</span>
                  </div>
                  <div className="flex items-center gap-1" title="Estimated material weight">
                    <Weight className="w-3 h-3 text-kf-pink" />
                    <span>{concept.estimatedMaterialG}g</span>
                  </div>
                  <div className="flex items-center gap-1" title="Part count">
                    <Layers className="w-3 h-3 text-kf-pink" />
                    <span>{concept.partCount} {concept.partCount === 1 ? 'part' : 'parts'}</span>
                  </div>
                  <div className="flex items-center gap-1" title="Support requirements">
                    {concept.requiresSupports ? (
                      <span className="text-amber-400 flex items-center gap-0.5">
                        <AlertTriangle className="w-3 h-3" /> Supports
                      </span>
                    ) : (
                      <span className="text-emerald-400 flex items-center gap-0.5">
                        <ShieldCheck className="w-3 h-3" /> Support-free
                      </span>
                    )}
                  </div>
                </div>

                {/* Selection Action Button */}
                <button
                  type="button"
                  id={`btn-select-concept-${concept.id}`}
                  disabled={isGenerating}
                  onClick={() => {
                    setSelectedConceptId(concept.id);
                    onSelectConcept(concept);
                  }}
                  className="w-full mt-1 flex items-center justify-center gap-2 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-50 text-kf-bg font-mono font-bold uppercase tracking-wider py-2 px-3 text-xs rounded transition shadow cursor-pointer"
                >
                  <Cpu className="w-3.5 h-3.5 text-[#0A0004]" />
                  <span>Select & Generate</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#0A0004]" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Fourth Option: "Let me describe my own approach" */}
      <div className="trace clip-corner p-[1px] mt-1">
        <div className="bg-kf-panel-2 p-3 flex flex-col gap-2.5">
          <button
            type="button"
            id="btn-toggle-custom-approach"
            onClick={() => setShowCustomInput((v) => !v)}
            className="flex items-center justify-between text-left text-xs font-mono font-bold text-kf-text hover:text-kf-pink transition cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <PenTool className="w-3.5 h-3.5 text-kf-pink" />
              <span className="uppercase tracking-wider">Custom Strategy: Let me describe my own approach</span>
            </div>
            <span className="text-[11px] font-mono text-kf-pink underline">
              {showCustomInput ? 'Hide' : 'Open custom input'}
            </span>
          </button>

          {showCustomInput && (
            <form onSubmit={handleCustomSubmit} className="flex flex-col gap-2.5 pt-2 border-t border-kf-border animate-fadeIn">
              <p className="text-[11px] text-kf-muted">
                Specify your exact architectural directive (mounting style, split parts, snap fits, or clearances). This will be appended as an authoritative design constraint before CAD synthesis.
              </p>
              <textarea
                id="custom-approach-input"
                rows={3}
                value={customDirectives}
                onChange={(e) => setCustomDirectives(e.target.value)}
                placeholder="e.g., Use a two-piece split clamp with captive M4 hex nuts, mounting horizontally under the desk with a 45-degree angled insertion channel..."
                className="w-full bg-kf-panel border border-kf-border rounded p-2.5 text-xs text-kf-text placeholder-kf-muted focus:outline-none focus:border-kf-pink focus:ring-1 focus:ring-kf-pink/20 font-sans resize-none leading-relaxed"
              />
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCustomInput(false)}
                  className="px-3 py-1.5 text-xs font-mono text-kf-muted hover:text-kf-text border border-kf-border rounded transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="btn-submit-custom-approach"
                  disabled={!customDirectives.trim() || isGenerating}
                  className="flex items-center gap-1.5 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-50 text-kf-bg font-mono font-bold uppercase tracking-wider py-1.5 px-3 text-xs rounded transition shadow cursor-pointer"
                >
                  <Wand2 className="w-3.5 h-3.5 text-[#0A0004]" />
                  <span>Apply Custom Strategy & Generate</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
