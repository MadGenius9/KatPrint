import React, { useState } from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  XCircle,
  HelpCircle,
  Wand2,
  RefreshCw,
  ShieldCheck,
  Tag,
  Sparkles,
  Info,
  Layers,
  Box,
  Ruler,
  Check,
  Lightbulb,
  Cpu,
  Eye,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { DesignValidationReport, ExtractedRequirements, PrintabilityChecklist } from '../types';

interface DesignCheckPanelProps {
  report: DesignValidationReport | null;
  requirements: ExtractedRequirements | null;
  printabilityChecklist?: PrintabilityChecklist | null;
  onFixMissingFeatures: (missing: string[]) => void;
  isFixing: boolean;
  onApplyImprovement?: (suggestion: string) => void;
}

export const DesignCheckPanel: React.FC<DesignCheckPanelProps> = ({
  report,
  requirements,
  printabilityChecklist,
  onFixMissingFeatures,
  isFixing,
  onApplyImprovement,
}) => {
  const [showAllChecks, setShowAllChecks] = useState<boolean>(false);

  if (!report && !requirements) return null;

  const hasMissing = report?.missingFeatures && report.missingFeatures.length > 0;
  const items = report?.items || [];
  const checks = report?.designChecks || [];
  const fidelity = report?.fidelityReview;
  const breakdown = report?.scoreBreakdown || fidelity?.scoreBreakdown || null;

  const verdict = report?.verdict || (report?.passed ? 'VERIFIED' : 'UNVERIFIED');
  const refObj = requirements?.referenceObject;

  const refDimX = refObj?.dimensions ? ((refObj.dimensions as any).width ?? (refObj.dimensions as any).x ?? 0) : 0;
  const refDimY = refObj?.dimensions ? ((refObj.dimensions as any).depth ?? (refObj.dimensions as any).y ?? 0) : 0;
  const refDimZ = refObj?.dimensions ? ((refObj.dimensions as any).height ?? (refObj.dimensions as any).z ?? 0) : 0;

  // Extract problems or uncertainties for "Needs Attention"
  const problems = fidelity?.problems || [];
  const uncertainWarnings = [
    ...(report?.warnings || []),
    ...items.filter((it) => it.status === 'uncertain' || it.status === 'missing').map((it) => it.detail || it.label),
  ];
  const uniqueWarnings = Array.from(new Set(uncertainWarnings)).filter(Boolean);

  return (
    <div className="trace clip-corner border border-kf-border bg-kf-panel rounded-lg p-3.5 flex flex-col gap-3.5 shadow-sm">
      {/* 1. HEADER & DESIGN MATCH SCORE */}
      <div className="flex flex-col gap-2 border-b border-kf-border pb-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-kf-pink" />
            <span className="text-xs font-semibold uppercase tracking-wider text-kf-text font-mono">
              Design &amp; Printability Audit
            </span>
          </div>
          {report && (
            <div className="flex items-center gap-1.5 font-mono text-[11px]">
              <span
                className={`px-2 py-0.5 rounded font-bold border ${
                  verdict === 'VERIFIED'
                    ? 'bg-kf-ok/10 text-kf-ok border-kf-ok/30'
                    : verdict === 'PARTIALLY VERIFIED'
                    ? 'bg-kf-warn/10 text-kf-warn border-kf-warn/30'
                    : 'bg-kf-fail/10 text-kf-fail border-kf-fail/30'
                }`}
              >
                {verdict} {typeof report.overallScore === 'number' ? `(${report.overallScore}%)` : '(Not Evaluated)'}
              </span>
            </div>
          )}
        </div>

        {/* Precision Match Score Card */}
        {report && (
          <div className="trace clip-corner bg-kf-panel-2 rounded-lg p-2.5 border border-kf-border flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono font-bold text-kf-text uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-kf-pink" />
                Design Match Score
              </span>
              <span className="text-sm font-black font-mono text-kf-pink">
                {typeof report.overallScore === 'number' ? `${report.overallScore}%` : 'Not Evaluated'}
              </span>
            </div>

            {/* Score Breakdown Bars (Only if Fidelity Review Breakdown exists) */}
            {breakdown && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 font-mono text-[10px]">
                <div className="bg-kf-bg/60 p-1.5 rounded border border-kf-border/40">
                  <span className="text-kf-muted block text-[9.5px]">Intent Match</span>
                  <span className="font-bold text-kf-text">{breakdown.intentMatch}%</span>
                </div>
                <div className="bg-kf-bg/60 p-1.5 rounded border border-kf-border/40">
                  <span className="text-kf-muted block text-[9.5px]">Dimensions</span>
                  <span className="font-bold text-kf-text">{breakdown.dimensions}%</span>
                </div>
                <div className="bg-kf-bg/60 p-1.5 rounded border border-kf-border/40">
                  <span className="text-kf-muted block text-[9.5px]">Req. Features</span>
                  <span className="font-bold text-kf-text">{breakdown.requiredFeatures}%</span>
                </div>
                <div className="bg-kf-bg/60 p-1.5 rounded border border-kf-border/40">
                  <span className="text-kf-muted block text-[9.5px]">Printability</span>
                  <span className="font-bold text-kf-ok">{breakdown.printability}%</span>
                </div>
                <div className="bg-kf-bg/60 p-1.5 rounded border border-kf-border/40 col-span-2 sm:col-span-1">
                  <span className="text-kf-muted block text-[9.5px]">Visual Match</span>
                  <span className="font-bold text-kf-text">{breakdown.visualMatch}%</span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 2. NEEDS ATTENTION / CAUTION BOX (IF ANY PROBLEM) */}
      {(problems.length > 0 || (report && !report.passed) || hasMissing) && (
        <div className="bg-kf-warn/10 border border-kf-warn/30 rounded-lg p-2.5 flex flex-col gap-1.5 text-xs font-sans">
          <div className="flex items-center gap-1.5 font-mono font-bold text-kf-warn text-[11px] uppercase tracking-wider">
            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
            <span>Needs Attention</span>
          </div>

          {problems.map((p, idx) => (
            <div key={idx} className="flex items-start gap-1 text-[11px] text-kf-text">
              <span className="text-kf-warn font-bold">⚠</span>
              <span>
                <strong className="text-kf-warn font-semibold">{p.requirement}:</strong> {p.issue}
                {p.recommendedCorrection ? ` (${p.recommendedCorrection})` : ''}
              </span>
            </div>
          ))}

          {problems.length === 0 && uniqueWarnings.slice(0, 3).map((w, idx) => (
            <div key={idx} className="flex items-start gap-1 text-[11px] text-kf-text">
              <span className="text-kf-warn font-bold">⚠</span>
              <span>{w}</span>
            </div>
          ))}
        </div>
      )}

      {/* 3. REAL-WORLD REFERENCE OBJECT CARD (IF DETECTED) */}
      {refObj && (
        <div className="trace clip-corner bg-kf-panel-2 rounded-lg p-3 border border-kf-border flex flex-col gap-2 shadow-inner">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Box className="w-3.5 h-3.5 text-kf-pink" />
              <span className="text-xs font-bold text-kf-text font-mono">{refObj.name}</span>
            </div>
            <span
              className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                refObj.confidence === 'verified'
                  ? 'bg-kf-ok/15 text-kf-ok border-kf-ok/30'
                  : 'bg-kf-warn/15 text-kf-warn border-kf-warn/30'
              }`}
            >
              {refObj.confidence === 'verified' ? '✓ Verified Dimensions' : '⚠ Estimated Dimensions'}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-1.5 text-center font-mono text-[11px] bg-kf-bg/60 p-2 rounded border border-kf-border/70">
            <div>
              <span className="text-[10px] text-kf-muted block">Item X</span>
              <span className="font-semibold text-kf-text">{refDimX} mm</span>
            </div>
            <div>
              <span className="text-[10px] text-kf-muted block">Item Y</span>
              <span className="font-semibold text-kf-text">{refDimY} mm</span>
            </div>
            <div>
              <span className="text-[10px] text-kf-muted block">Item Z</span>
              <span className="font-semibold text-kf-text">{refDimZ} mm</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-[10.5px] font-mono text-kf-muted pt-0.5">
            <span>Clearance fit added: <strong className="text-kf-pink">+{refObj.clearanceMm || 2.0} mm</strong></span>
            <span className="text-[9.5px] opacity-75">Source: {refObj.sourceNote || 'Database'}</span>
          </div>
        </div>
      )}

      {/* 4. USER EXPLICIT REQUIREMENTS vs AI DESIGN DECISIONS */}
      {requirements && (
        <div className="trace clip-corner bg-kf-panel-2 rounded-md p-3 border border-kf-border text-[11px] font-mono flex flex-col gap-2.5">
          {/* Model Type */}
          <div className="text-kf-muted flex items-center justify-between pb-1 border-b border-kf-border/60">
            <span className="flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-kf-pink" />
              <span>Model Type / Intent:</span>
            </span>
            <span className="text-kf-text font-semibold">
              {requirements.designPlan?.inferredCategory
                ? String(requirements.designPlan.inferredCategory).replace(/_/g, ' ')
                : requirements.classification === 'parametric'
                ? 'Functional / Parametric'
                : requirements.classification === 'organic'
                ? 'Freeform / Organic'
                : 'Hybrid Organic & Mechanical'}
            </span>
          </div>

          {/* Design Strategy & Purpose */}
          {requirements.designPlan?.function && (
            <div className="text-kf-muted flex flex-col gap-0.5 pb-1 border-b border-kf-border/60">
              <span className="text-[10px] text-kf-pink font-bold uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-kf-pink" /> Inferred Purpose &amp; Use Case:
              </span>
              <span className="text-kf-text font-medium text-[11px] leading-snug font-sans">
                {requirements.designPlan.function}
                {requirements.designPlan.targetUseCase ? ` (${requirements.designPlan.targetUseCase})` : ''}
              </span>
              {requirements.designPlan.mountingStyle && requirements.designPlan.mountingStyle !== 'freestanding' && (
                <span className="text-[10px] text-kf-muted font-mono mt-0.5">
                  Mounting: <strong className="text-kf-text">{requirements.designPlan.mountingStyle}</strong>
                </span>
              )}
            </div>
          )}

          {/* Target Dimensions */}
          {requirements.overallDimensions && (
            <div className="text-kf-muted flex items-center justify-between pb-1 border-b border-kf-border/60">
              <span className="flex items-center gap-1.5">
                <Ruler className="w-3.5 h-3.5 text-kf-pink" />
                <span>Overall Bounds:</span>
              </span>
              <span className="text-kf-pink font-semibold">
                {requirements.overallDimensions.width !== null ? `${requirements.overallDimensions.width} mm` : 'Auto'} ×{' '}
                {requirements.overallDimensions.depth !== null
                  ? `${requirements.overallDimensions.depth} mm`
                  : requirements.overallDimensions.diameter !== null
                  ? `Ø${requirements.overallDimensions.diameter} mm`
                  : 'Auto'} ×{' '}
                {requirements.overallDimensions.height !== null ? `${requirements.overallDimensions.height} mm` : 'Auto'}
              </span>
            </div>
          )}

          {/* Key Inferred Features */}
          {requirements.designPlan?.keyFeatures && requirements.designPlan.keyFeatures.length > 0 && (
            <div className="flex flex-col gap-1 pb-1 border-b border-kf-border/60">
              <span className="text-[10px] text-kf-text font-bold uppercase tracking-wider flex items-center gap-1">
                <Layers className="w-3 h-3 text-kf-pink" /> Inferred Key Features:
              </span>
              <div className="flex flex-wrap gap-1">
                {requirements.designPlan.keyFeatures.map((feat: string, i: number) => (
                  <span
                    key={i}
                    className="text-[10px] font-mono bg-kf-pink/10 text-kf-pink px-2 py-0.5 rounded border border-kf-pink/25"
                  >
                    {feat}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* User Explicit Requirements */}
          {requirements.explicitRequirements && requirements.explicitRequirements.length > 0 && (
            <div className="flex flex-col gap-1">
              <span className="text-[10px] text-kf-text font-bold uppercase tracking-wider flex items-center gap-1">
                <Tag className="w-3 h-3 text-kf-pink" /> User Stated Requirements:
              </span>
              <ul className="list-disc list-inside text-kf-text text-[10.5px] space-y-1 pl-1">
                {requirements.explicitRequirements.map((req, i) => (
                  <li key={i} className="leading-snug">{req}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* 5. PRINTABILITY AUDIT CHECKLIST */}
      {printabilityChecklist && (
        <div className="flex flex-col gap-2">
          <span className="text-[11px] font-mono font-semibold uppercase tracking-wider text-kf-muted flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-kf-pink" />
            <span>Printability Inspection</span>
          </span>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            <div className="trace clip-corner flex items-center gap-2 bg-kf-panel-2 p-2 rounded border border-kf-border">
              <Check className={`w-3.5 h-3.5 ${printabilityChecklist.validGeometry ? 'text-kf-ok' : 'text-kf-fail'}`} />
              <div>
                <span className="text-[10px] text-kf-muted block">Valid Geometry</span>
                <span className="font-semibold">{printabilityChecklist.validGeometry ? 'Solid Manifold' : 'Open Mesh'}</span>
              </div>
            </div>

            <div className="trace clip-corner flex items-center gap-2 bg-kf-panel-2 p-2 rounded border border-kf-border">
              <Check className={`w-3.5 h-3.5 ${printabilityChecklist.fitsSelectedPrinter ? 'text-kf-ok' : 'text-kf-fail'}`} />
              <div>
                <span className="text-[10px] text-kf-muted block">Build Volume Fit</span>
                <span className="font-semibold">{printabilityChecklist.fitsSelectedPrinter ? 'Fits 100%' : 'Exceeds Bed'}</span>
              </div>
            </div>

            <div className="trace clip-corner flex items-center gap-2 bg-kf-panel-2 p-2 rounded border border-kf-border">
              <Check className={`w-3.5 h-3.5 ${printabilityChecklist.flatPrintableBase ? 'text-kf-ok' : 'text-kf-warn'}`} />
              <div>
                <span className="text-[10px] text-kf-muted block">Bed Adhesion</span>
                <span className="font-semibold">{printabilityChecklist.flatPrintableBase ? 'Flat Base Contact' : 'Brim Advised'}</span>
              </div>
            </div>

            <div className="trace clip-corner flex items-center gap-2 bg-kf-panel-2 p-2 rounded border border-kf-border">
              <Check className={`w-3.5 h-3.5 ${printabilityChecklist.reasonableWallThickness ? 'text-kf-ok' : 'text-kf-warn'}`} />
              <div>
                <span className="text-[10px] text-kf-muted block">Wall Thickness</span>
                <span className="font-semibold">{printabilityChecklist.reasonableWallThickness ? 'Durable >= 2.4mm' : 'Thin Wall'}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. VERIFICATION CHECKLIST ITEMS */}
      {items.length > 0 && (
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-semibold uppercase tracking-wider text-kf-muted flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-kf-pink" />
              <span>Inspection Checklist ({items.length})</span>
            </span>
            <button
              onClick={() => setShowAllChecks(!showAllChecks)}
              className="text-[10px] font-mono text-kf-pink hover:underline flex items-center gap-0.5 cursor-pointer"
            >
              {showAllChecks ? 'Collapse' : 'Show All'}
              {showAllChecks ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
          </div>

          <div className={`flex flex-col gap-1.5 ${showAllChecks ? 'max-h-96' : 'max-h-48'} overflow-y-auto pr-1`}>
            {items.map((item, idx) => {
              let Icon = CheckCircle2;
              let colorClass = 'text-kf-ok border-kf-ok/30 bg-kf-ok/5';
              let iconColor = 'text-kf-ok';

              if (item.status === 'missing') {
                Icon = XCircle;
                colorClass = 'text-kf-fail border-kf-fail/30 bg-kf-fail/5';
                iconColor = 'text-kf-fail';
              } else if (item.status === 'warning') {
                Icon = AlertTriangle;
                colorClass = 'text-kf-warn border-kf-warn/30 bg-kf-warn/5';
                iconColor = 'text-kf-warn';
              } else if (item.status === 'uncertain') {
                Icon = HelpCircle;
                colorClass = 'text-kf-muted border-kf-border bg-kf-panel-2';
                iconColor = 'text-kf-muted';
              }

              return (
                <div
                  key={item.id || idx}
                  className={`p-2 rounded-md border flex items-start gap-2 text-xs transition ${colorClass}`}
                >
                  <Icon className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${iconColor}`} />
                  <div className="flex-1 flex flex-col">
                    <div className="flex items-center justify-between gap-1">
                      <span className="font-medium text-[11px] leading-tight text-kf-text">
                        {item.label}
                      </span>
                      {item.verificationSource && (
                        <span className="text-[9px] uppercase px-1 py-0.2 rounded border border-kf-border bg-kf-panel font-mono text-kf-muted shrink-0">
                          {item.verificationSource}
                        </span>
                      )}
                    </div>
                    {item.detail && (
                      <span className="text-[10px] text-kf-muted leading-tight mt-0.5 font-mono">
                        {item.detail}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 7. SUGGESTED PRODUCT IMPROVEMENTS */}
      {requirements?.suggestedImprovements && requirements.suggestedImprovements.length > 0 && (
        <div className="border border-kf-pink/20 bg-kf-pink/5 rounded-lg p-2.5 flex flex-col gap-1.5">
          <span className="text-[10.5px] font-mono font-bold uppercase tracking-wider text-kf-pink flex items-center gap-1">
            <Lightbulb className="w-3.5 h-3.5 text-kf-pink" /> Suggested Refinements:
          </span>
          <div className="flex flex-col gap-1">
            {requirements.suggestedImprovements.map((suggestion, i) => (
              <div key={i} className="trace clip-corner flex items-center justify-between gap-2 text-[10.5px] font-sans text-kf-text bg-kf-panel/80 p-1.5 rounded border border-kf-border">
                <span className="leading-snug">{suggestion}</span>
                {onApplyImprovement && (
                  <button
                    type="button"
                    onClick={() => onApplyImprovement(suggestion)}
                    className="shrink-0 text-[10px] font-mono px-2 py-0.5 rounded bg-kf-pink/15 hover:bg-kf-pink text-kf-pink hover:text-[#0A0004] transition border border-kf-pink/30 font-semibold cursor-pointer"
                  >
                    Apply
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 8. FIX MISSING FEATURES BUTTON */}
      {hasMissing && (
        <button
          type="button"
          id="btn-fix-missing-features"
          disabled={isFixing}
          onClick={() => onFixMissingFeatures(report.missingFeatures)}
          className="w-full flex items-center justify-center gap-2 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-50 text-[#0A0004] font-semibold py-2 px-3 rounded-md text-xs font-mono transition shadow-md shadow-kf-pink/20 cursor-pointer"
        >
          {isFixing ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Auto-Correcting Missing Features...</span>
            </>
          ) : (
            <>
              <Wand2 className="w-3.5 h-3.5" />
              <span>Fix Missing Features ({report.missingFeatures.length})</span>
            </>
          )}
        </button>
      )}
    </div>
  );
};
