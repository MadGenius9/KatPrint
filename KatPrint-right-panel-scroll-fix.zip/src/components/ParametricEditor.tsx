import React, { useState, useEffect, useMemo } from 'react';
import {
  Sparkles,
  Sliders,
  Code,
  RefreshCw,
  Copy,
  Check,
  AlertCircle,
  Wand2,
  FlaskConical,
  Box,
  Edit3,
  Send,
  Activity,
  ChevronDown,
  ChevronUp,
  Zap,
  ShieldCheck,
  Info,
  Link,
  Unlink,
} from 'lucide-react';
import { extractJSCADNamedConsts } from '../engine/geometryUtils';
import {
  parseDerivedBlock,
  rewriteConstants,
  unlinkDerived,
  DerivedRelationship,
} from '../features/derivedParameters';
import {
  DesignValidationReport,
  ExtractedRequirements,
  GenerationPipelineStage,
  GenerationError,
  GenerationDiagnostics,
  GenerationMode,
  DesignSpecification,
  DesignCheck,
  FidelityReviewResult,
} from '../types';
import { DesignCheckPanel } from './DesignCheckPanel';
import { DesignUnderstandingPanel } from './DesignUnderstandingPanel';
import { GenerationPipelineStatus } from './GenerationPipelineStatus';
import { TestSuiteModal } from './TestSuiteModal';
import { TemplateLibraryModal } from './TemplateLibraryModal';

export interface GeneratePromptOptions {
  useTemplate?: boolean;
  simplifyToParametric?: boolean;
  mode?: GenerationMode;
  exploreApproaches?: boolean;
}

export interface ParametricEditorProps {
  currentCode: string;
  onCodeChange: (newCode: string) => void;
  onGeneratePrompt: (prompt: string, options?: GeneratePromptOptions) => Promise<void>;
  onRevisePrompt: (revisionPrompt: string) => Promise<void>;
  onFixMissingFeatures: (missing: string[]) => Promise<void>;
  onSimplifyToParametric?: (prompt: string) => Promise<void>;
  isGenerating: boolean;
  isRevising: boolean;
  isFixing: boolean;
  pipelineStage: GenerationPipelineStage;
  repairAttempt: number;
  errorMessage: string | null;
  generationError?: GenerationError | null;
  generationDiagnostics?: GenerationDiagnostics | null;
  validationReport: DesignValidationReport | null;
  extractedRequirements: ExtractedRequirements | null;
  activePrompt: string;
  generationMode?: GenerationMode;
  onModeChange?: (mode: GenerationMode) => void;
  exploreApproaches?: boolean;
  onToggleExploreApproaches?: (enabled: boolean) => void;
  designSpecification?: DesignSpecification | null;
  designChecklist?: DesignCheck[] | null;
  fidelityReviewResult?: FidelityReviewResult | null;
  isViewingHistorical?: boolean;
}

const REGRESSION_PROMPTS = [
  {
    label: 'Under-Desk Xbox Controller',
    prompt: 'Make me something I can screw underneath my desk that holds my Xbox controller but lets me grab it quickly.',
  },
  {
    label: 'Toothbrush Holder (No Water)',
    prompt: 'Make a toothbrush holder that doesn\'t leave water sitting in the bottom.',
  },
  {
    label: 'Nightstand Phone Stand (Charger)',
    prompt: 'Make a phone stand for my nightstand where I can plug the charger into the bottom.',
  },
  {
    label: 'Dr. Squatch Soap Dish',
    prompt: 'Make me a soap dish for one of those square Dr. Squatch bars.',
  },
  {
    label: 'Wall Dual Controller Mount',
    prompt: 'I need something small that screws to the wall and holds two game controllers.',
  },
];

export const ParametricEditor: React.FC<ParametricEditorProps> = ({
  currentCode,
  onCodeChange,
  onGeneratePrompt,
  onRevisePrompt,
  onFixMissingFeatures,
  onSimplifyToParametric,
  isGenerating,
  isRevising,
  isFixing,
  pipelineStage,
  repairAttempt,
  errorMessage,
  generationError,
  generationDiagnostics,
  validationReport,
  extractedRequirements,
  activePrompt,
  generationMode = 'precision',
  onModeChange,
  exploreApproaches: exploreApproachesProp,
  onToggleExploreApproaches,
  designSpecification,
  designChecklist,
  fidelityReviewResult,
  isViewingHistorical = false,
}) => {
  const [prompt, setPrompt] = useState(
    'Make me something I can screw underneath my desk that holds my Xbox controller but lets me grab it quickly.'
  );
  const [selectedMode, setSelectedMode] = useState<GenerationMode>(generationMode);
  const [localExploreApproaches, setLocalExploreApproaches] = useState<boolean>(() => {
    return localStorage.getItem('katprint_explore_approaches') === 'true';
  });

  const exploreApproaches = exploreApproachesProp !== undefined ? exploreApproachesProp : localExploreApproaches;

  const handleExploreToggle = (val: boolean) => {
    setLocalExploreApproaches(val);
    localStorage.setItem('katprint_explore_approaches', val ? 'true' : 'false');
    if (onToggleExploreApproaches) {
      onToggleExploreApproaches(val);
    }
  };

  const [revisionText, setRevisionText] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [showDiagnostics, setShowDiagnostics] = useState(false);
  const [showTechDetails, setShowTechDetails] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isTestSuiteOpen, setIsTestSuiteOpen] = useState(false);
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [showAdvancedCreate, setShowAdvancedCreate] = useState(false);

  // Sync mode whenever project changes or parent updates generationMode
  useEffect(() => {
    if (generationMode) {
      setSelectedMode(generationMode);
    }
  }, [generationMode]);

  // Extract parsed live variables and derived relationships from code
  const namedConsts = extractJSCADNamedConsts(currentCode);
  const derivedRelationships = useMemo(() => parseDerivedBlock(currentCode), [currentCode]);
  const derivedMap = useMemo(() => {
    const map = new Map<string, DerivedRelationship>();
    for (const rel of derivedRelationships) {
      map.set(rel.derived, rel);
    }
    return map;
  }, [derivedRelationships]);

  const handleVarChange = (name: string, newVal: number) => {
    if (isNaN(newVal) || newVal <= 0) return;
    const updated = rewriteConstants(currentCode, { [name]: newVal });
    onCodeChange(updated);
  };

  const handleUnlink = (derivedParamName: string) => {
    const updated = unlinkDerived(currentCode, derivedParamName);
    onCodeChange(updated);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleModeToggle = (newMode: GenerationMode) => {
    setSelectedMode(newMode);
    if (onModeChange) onModeChange(newMode);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim() && !isGenerating) {
      onGeneratePrompt(prompt.trim(), { useTemplate: false, mode: selectedMode, exploreApproaches });
    }
  };

  const handleRevisionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (revisionText.trim() && !isRevising && !isGenerating) {
      onRevisePrompt(revisionText.trim());
      setRevisionText('');
    }
  };

  const canSimplify = Boolean(
    generationError?.canSimplifyToParametric ||
      generationError?.errorCategory === 'ORGANIC_UNCONFIGURED' ||
      generationError?.errorCategory === 'HYBRID_UNCONFIGURED'
  );

  return (
    <div className="flex flex-col gap-4 text-kf-text">
      {/* Primary Authoritative Prompt Form */}
      <form onSubmit={handleSubmit} className="flex flex-col gap-2.5">
        <div className="flex items-center justify-between">
          <label htmlFor="prompt-input" className="section-label flex items-center gap-1.5">
            <Wand2 className="w-3.5 h-3.5 text-kf-pink" />
            <span>Describe your model</span>
          </label>
          <span className="text-[10px] text-kf-muted font-mono">AI CAD</span>
        </div>

        {/* Generation Mode Selector & Explore Approaches */}
        <div className="trace clip-corner bg-kf-panel-2 p-1.5 rounded-lg border border-kf-border flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1">
            <button
              type="button"
              id="btn-mode-precision"
              onClick={() => handleModeToggle('precision')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-mono font-bold transition cursor-pointer ${
                selectedMode === 'precision'
                  ? 'bg-kf-pink text-[#0A0004] shadow-sm'
                  : 'text-kf-muted hover:text-kf-text hover:bg-kf-panel'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Precision</span>
            </button>
            <button
              type="button"
              id="btn-mode-fast"
              onClick={() => handleModeToggle('fast')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-mono font-bold transition cursor-pointer ${
                selectedMode === 'fast'
                  ? 'bg-kf-pink text-[#0A0004] shadow-sm'
                  : 'text-kf-muted hover:text-kf-text hover:bg-kf-panel'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Fast</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <label
              htmlFor="toggle-explore-approaches"
              className="flex items-center gap-1.5 cursor-pointer select-none text-[11px] font-mono text-kf-muted hover:text-kf-text transition pr-1"
            >
              <input
                type="checkbox"
                id="toggle-explore-approaches"
                checked={exploreApproaches}
                onChange={(e) => handleExploreToggle(e.target.checked)}
                className="accent-kf-pink w-3.5 h-3.5 rounded bg-kf-panel border-kf-border cursor-pointer"
              />
              <span className={exploreApproaches ? 'text-kf-pink font-bold' : ''}>
                Explore approaches
              </span>
            </label>
          </div>
        </div>

        <div className="relative">
          <textarea
            id="prompt-input"
            rows={3}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe what you want naturally: e.g., 'Make me something I can screw underneath my desk that holds my Xbox controller but lets me grab it quickly'..."
            className="w-full bg-kf-panel-2 border border-kf-border rounded-md p-3 text-xs text-kf-text placeholder-kf-muted focus:outline-none focus:border-kf-pink focus:ring-1 focus:ring-kf-pink/20 transition font-sans resize-none leading-relaxed"
          />
        </div>

        <button
          type="button"
          onClick={() => setShowAdvancedCreate((v) => !v)}
          className="w-full flex items-center justify-between px-2 py-1.5 text-[10px] font-mono uppercase tracking-[0.18em] text-kf-muted hover:text-kf-text border-y border-kf-border/60 transition"
        >
          <span>Advanced tools</span>
          {showAdvancedCreate ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </button>

        {showAdvancedCreate && (
          <div className="trace clip-corner p-[1px]">
            <div className="bg-kf-panel-2 p-2.5 space-y-2.5">
              <div className="flex items-center gap-2">
                <button type="button" onClick={() => setIsTemplateModalOpen(true)} className="flex-1 px-2 py-1.5 border border-kf-border text-[10px] font-mono text-kf-muted hover:text-kf-text hover:border-kf-pink/50"><Box className="w-3 h-3 inline mr-1" />Templates</button>
                <button type="button" onClick={() => setIsTestSuiteOpen(true)} className="flex-1 px-2 py-1.5 border border-kf-border text-[10px] font-mono text-kf-muted hover:text-kf-text hover:border-kf-pink/50"><FlaskConical className="w-3 h-3 inline mr-1" />Test Suite</button>
              </div>
              <div className="space-y-1.5">
                <span className="section-label">Test prompts</span>
                <div className="flex flex-wrap gap-1">
                  {REGRESSION_PROMPTS.map((item, idx) => (
                    <button key={idx} type="button" onClick={() => setPrompt(item.prompt)} className="text-[9px] font-mono bg-kf-panel hover:bg-kf-hover text-kf-muted hover:text-kf-pink border border-kf-border px-2 py-1 transition text-left" title={item.prompt}>
                      + {item.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        <button
          type="submit"
          id="btn-generate-cad"
          disabled={isGenerating || isRevising || !prompt.trim()}
          className={`sweep ${isGenerating ? '' : 'sweep-idle'} clip-corner w-full mt-1 flex items-center justify-center gap-2 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-50 text-kf-bg font-mono font-bold uppercase tracking-wider py-2.5 px-4 text-xs transition shadow-md shadow-kf-pink/20 cursor-pointer`}
        >
          {isGenerating ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-[#0A0004]" />
              <span>Running KatPrint {selectedMode === 'precision' ? 'Precision' : 'Fast'} Pipeline...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-[#0A0004]" />
              <span>{selectedMode === 'precision' ? 'Generate & Verify' : 'Generate Fast'}</span>
            </>
          )}
        </button>
      </form>

      {/* Multi-Pass Pipeline Status Stepper */}
      {isGenerating && (
        <GenerationPipelineStatus
          stage={pipelineStage}
          mode={selectedMode}
          repairAttempt={repairAttempt}
        />
      )}

      {/* Progressive disclosure: keep design interpretation available without crowding the create flow. */}
      {(designSpecification || extractedRequirements) && (
        <details className="trace clip-corner p-[1px] group">
          <summary className="list-none cursor-pointer bg-kf-panel px-3 py-2.5 flex items-center justify-between text-[10px] font-mono uppercase tracking-[0.18em] text-kf-muted hover:text-kf-text">
            <span>Design details</span>
            <ChevronDown className="w-3.5 h-3.5 group-open:rotate-180 transition-transform" />
          </summary>
          <div className="trace clip-corner bg-kf-panel p-2.5 border-t border-kf-border">
            <DesignUnderstandingPanel
              specification={designSpecification || validationReport?.fidelityReview?.designSpecification || extractedRequirements?.designSpecification}
              requirements={extractedRequirements}
            />
          </div>
        </details>
      )}

      {/* Error state with informative message, Simplify button, and Retry / Template buttons */}
      {errorMessage && (
        <div className="bg-kf-fail/15 border border-kf-fail/50 p-3.5 rounded-md text-xs text-kf-fail flex flex-col gap-2.5 shadow-sm">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-kf-fail shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs">Generation Notice</span>
                {generationError?.errorCategory && (
                  <span className="text-[10px] font-mono bg-kf-fail/20 px-1.5 py-0.5 rounded border border-kf-fail/30 uppercase">
                    {generationError.errorCategory}
                  </span>
                )}
              </div>
              <p className="text-[11px] leading-snug font-medium mt-1 text-kf-text">{errorMessage}</p>
            </div>
          </div>

          {generationError?.technicalDetails && (
            <div className="border-t border-kf-fail/30 pt-1.5 flex flex-col gap-1">
              <button
                type="button"
                id="btn-toggle-tech-details"
                onClick={() => setShowTechDetails(!showTechDetails)}
                className="text-[10px] font-mono text-kf-muted hover:text-kf-text flex items-center gap-1 cursor-pointer"
              >
                {showTechDetails ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                <span>{showTechDetails ? 'Hide technical details' : 'Show technical details'}</span>
              </button>
              {showTechDetails && (
                <pre className="text-[10px] font-mono bg-kf-panel-2 p-2 rounded border border-kf-border overflow-x-auto text-kf-muted whitespace-pre-wrap select-text">
                  {generationError.technicalDetails}
                </pre>
              )}
            </div>
          )}

          <div className="flex flex-wrap items-center justify-end gap-2 pt-1 border-t border-kf-fail/20">
            {canSimplify && (
              <button
                type="button"
                id="btn-simplify-to-parametric"
                onClick={() => {
                  if (onSimplifyToParametric) {
                    onSimplifyToParametric(prompt.trim());
                  } else {
                    onGeneratePrompt(prompt.trim(), { useTemplate: false, simplifyToParametric: true, mode: selectedMode });
                  }
                }}
                disabled={isGenerating || !prompt.trim()}
                className="bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] text-[11px] font-mono font-bold px-3 py-1.5 rounded transition shadow-sm disabled:opacity-50 cursor-pointer flex items-center gap-1"
              >
                <Sparkles className="w-3 h-3" />
                <span>Simplify to Parametric CAD</span>
              </button>
            )}

            <button
              type="button"
              id="btn-retry-prompt"
              onClick={() => prompt.trim() && onGeneratePrompt(prompt.trim(), { useTemplate: false, mode: selectedMode })}
              disabled={isGenerating || !prompt.trim()}
              className="bg-kf-fail hover:bg-kf-fail/90 text-white text-[11px] font-mono font-semibold px-2.5 py-1.5 rounded transition disabled:opacity-50 cursor-pointer"
            >
              Retry
            </button>
            <button
              type="button"
              id="btn-use-template-on-error"
              onClick={() => prompt.trim() && onGeneratePrompt(prompt.trim(), { useTemplate: true, mode: 'fast' })}
              disabled={isGenerating || !prompt.trim()}
              className="bg-kf-panel-2 hover:bg-kf-border/80 border border-kf-border text-kf-text text-[11px] font-mono font-semibold px-2.5 py-1.5 rounded transition disabled:opacity-50 cursor-pointer"
            >
              Template Mode
            </button>
          </div>
        </div>
      )}

      {/* Generation Diagnostics Drawer */}
      {generationDiagnostics && (
        <div className="trace clip-corner border border-kf-border bg-kf-panel rounded-lg overflow-hidden shadow-sm">
          <button
            type="button"
            id="btn-toggle-diagnostics"
            onClick={() => setShowDiagnostics(!showDiagnostics)}
            className="w-full flex items-center justify-between p-3 text-xs text-kf-muted hover:text-kf-text hover:bg-kf-border/30 transition font-mono cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Activity className="w-3.5 h-3.5 text-kf-pink" />
              <span>Generation Diagnostics &amp; AI Usage</span>
            </div>
            <span className="text-[10px] text-kf-pink font-mono bg-kf-pink/10 px-2 py-0.5 rounded border border-kf-pink/20">
              {showDiagnostics ? 'Hide [-]' : 'Inspect [+]'}
            </span>
          </button>

          {showDiagnostics && (
            <div className="trace clip-corner p-3 border-t border-kf-border bg-kf-panel-2 text-[11px] font-mono flex flex-col gap-2.5">
              <div className="grid grid-cols-2 gap-2">
                <div className="trace clip-corner bg-kf-panel p-2 rounded border border-kf-border flex flex-col">
                  <span className="text-[10px] text-kf-muted">Generation ID:</span>
                  <span className="text-kf-text font-bold truncate">{generationDiagnostics.generationId}</span>
                </div>
                <div className="trace clip-corner bg-kf-panel p-2 rounded border border-kf-border flex flex-col">
                  <span className="text-[10px] text-kf-muted">Pipeline Status:</span>
                  <span className="text-kf-ok font-bold uppercase">{generationDiagnostics.status || 'Success'}</span>
                </div>
                <div className="trace clip-corner bg-kf-panel p-2 rounded border border-kf-border flex flex-col">
                  <span className="text-[10px] text-kf-muted">Pipeline Mode:</span>
                  <span className="text-kf-pink font-bold uppercase">{generationDiagnostics.mode || selectedMode}</span>
                </div>
                <div className="trace clip-corner bg-kf-panel p-2 rounded border border-kf-border flex flex-col">
                  <span className="text-[10px] text-kf-muted">Duration / Latency:</span>
                  <span className="text-kf-text font-medium">
                    {generationDiagnostics.latencyMs ? `${generationDiagnostics.latencyMs} ms` : 'N/A'}
                  </span>
                </div>
                <div className="trace clip-corner bg-kf-panel p-2 rounded border border-kf-border flex flex-col">
                  <span className="text-[10px] text-kf-muted">Primary Model:</span>
                  <span className="text-kf-pink font-bold">
                    {generationDiagnostics.modelUsed || generationDiagnostics.modelsUsed?.[0] || 'N/A'}
                  </span>
                </div>
                <div className="trace clip-corner bg-kf-panel p-2 rounded border border-kf-border flex flex-col">
                  <span className="text-[10px] text-kf-muted">AI Calls &amp; Repairs:</span>
                  <span className="text-kf-text">
                    {generationDiagnostics.totalAIRequests ?? generationDiagnostics.aiCallsMade ?? 1} call(s) • {generationDiagnostics.repairAttempts || 0} repair(s)
                  </span>
                </div>
                <div className="trace clip-corner bg-kf-panel p-2 rounded border border-kf-border flex flex-col">
                  <span className="text-[10px] text-kf-muted">Manifold Status:</span>
                  <span className={generationDiagnostics.isManifold ? 'text-kf-ok font-bold' : 'text-kf-fail font-bold'}>
                    {generationDiagnostics.isManifold
                      ? 'Closed 2-Manifold (0 non-manifold edges)'
                      : `Non-Manifold (${generationDiagnostics.nonManifoldEdgeCount || 0} open edges)`}
                  </span>
                </div>
                <div className="trace clip-corner bg-kf-panel p-2 rounded border border-kf-border flex flex-col">
                  <span className="text-[10px] text-kf-muted">Design Match:</span>
                  <span className="text-kf-pink font-bold">
                    {typeof validationReport?.overallScore === 'number'
                      ? `${validationReport.overallScore}%`
                      : typeof fidelityReviewResult?.overallScore === 'number'
                      ? `${fidelityReviewResult.overallScore}%`
                      : 'Not Evaluated'}
                  </span>
                </div>
              </div>

              {/* AI Requests by Purpose Breakdown */}
              {generationDiagnostics.requestsByPurpose && Object.keys(generationDiagnostics.requestsByPurpose).length > 0 && (
                <div className="trace clip-corner bg-kf-panel p-2 rounded border border-kf-border flex flex-col gap-1">
                  <span className="text-[10px] text-kf-muted font-bold">AI Requests by Purpose:</span>
                  <div className="grid grid-cols-2 gap-1 text-[10px]">
                    {Object.entries(generationDiagnostics.requestsByPurpose).map(([purpose, count]) => (
                      <div key={purpose} className="trace clip-corner flex justify-between items-center bg-kf-panel-2 px-1.5 py-0.5 rounded border border-kf-border">
                        <span className="text-kf-muted truncate capitalize">{purpose.replace(/_/g, ' ')}:</span>
                        <span className="text-kf-pink font-bold">{count}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Detailed Request Records */}
              {generationDiagnostics.requestRecords && generationDiagnostics.requestRecords.length > 0 && (
                <div className="trace clip-corner bg-kf-panel p-2 rounded border border-kf-border flex flex-col gap-1">
                  <span className="text-[10px] text-kf-muted font-bold">Request Log ({generationDiagnostics.requestRecords.length}):</span>
                  <div className="flex flex-col gap-1 max-h-32 overflow-y-auto">
                    {generationDiagnostics.requestRecords.map((req, idx) => (
                      <div key={idx} className="trace clip-corner flex items-center justify-between text-[9px] bg-kf-panel-2 px-1.5 py-1 rounded border border-kf-border">
                        <span className="text-kf-text font-bold truncate max-w-[120px] capitalize">
                          {req.purpose.replace(/_/g, ' ')}
                        </span>
                        <span className="text-kf-muted">{req.durationMs}ms</span>
                        <span className={req.status === 'success' ? 'text-kf-ok' : 'text-kf-fail'}>{req.status}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {generationDiagnostics.measuredDimensions && (
                <div className="trace clip-corner bg-kf-panel p-2 rounded border border-kf-border">
                  <span className="text-[10px] text-kf-muted block mb-1">Measured Geometry &amp; Volume:</span>
                  <div className="grid grid-cols-3 gap-1 text-[10px] text-kf-text font-bold">
                    <span>X: {generationDiagnostics.measuredDimensions.x?.toFixed(1)} mm</span>
                    <span>Y: {generationDiagnostics.measuredDimensions.y?.toFixed(1)} mm</span>
                    <span>Z: {generationDiagnostics.measuredDimensions.z?.toFixed(1)} mm</span>
                  </div>
                  <div className="grid grid-cols-3 gap-1 text-[10px] mt-1 pt-1 border-t border-kf-border text-kf-muted">
                    <span>Vol: {generationDiagnostics.measuredVolumeMm3 ? (generationDiagnostics.measuredVolumeMm3 / 1000).toFixed(2) : 0} cm³</span>
                    <span>Triangles: {generationDiagnostics.polygonCount || 0}</span>
                    <span>Edges: {generationDiagnostics.nonManifoldEdgeCount || 0}</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Design Validation & Feature Checklist Scorecard */}
      <DesignCheckPanel
        report={validationReport}
        requirements={extractedRequirements}
        onFixMissingFeatures={onFixMissingFeatures}
        isFixing={isFixing}
      />

      {/* Natural Language Model Revision Input */}
      {activePrompt && (
        <div className="trace clip-corner border border-kf-border bg-kf-panel rounded-lg p-3.5 flex flex-col gap-2.5 shadow-sm">
          <div className="flex items-center justify-between border-b border-kf-border pb-2">
            <div className="flex items-center gap-1.5">
              <Edit3 className="w-3.5 h-3.5 text-kf-pink" />
              <span className="text-xs font-semibold uppercase tracking-wider text-kf-text font-mono">
                Natural-Language Revision
              </span>
            </div>
            <span className="text-[10px] font-mono text-kf-muted">Iterative Edit</span>
          </div>

          {isViewingHistorical ? (
            <div className="bg-kf-pink/10 border border-kf-pink/30 rounded p-2.5 flex items-center gap-2 text-xs font-mono text-kf-pink">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>Viewing historical version. Restore as Head or create a Branch to submit revisions.</span>
            </div>
          ) : (
            <form onSubmit={handleRevisionSubmit} className="flex gap-2">
              <input
                type="text"
                id="input-revision-prompt"
                value={revisionText}
                onChange={(e) => setRevisionText(e.target.value)}
                placeholder="e.g. Make it 20mm taller and space the holes 5mm further apart..."
                className="flex-1 bg-kf-panel-2 border border-kf-border rounded-md px-3 py-2 text-xs font-sans text-kf-text placeholder-kf-muted focus:outline-none focus:border-kf-pink"
              />
              <button
                type="submit"
                id="btn-submit-revision"
                disabled={isRevising || isGenerating || !revisionText.trim()}
                className="flex items-center gap-1 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-50 text-[#0A0004] font-semibold text-xs px-3 py-2 rounded-md font-mono transition cursor-pointer"
              >
                {isRevising ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Send className="w-3.5 h-3.5" />
                )}
                <span>Revise</span>
              </button>
            </form>
          )}
        </div>
      )}

      {/* Live Editable Named Constants Panel */}
      <div className="trace clip-corner border border-kf-border bg-kf-panel rounded-lg p-3.5 flex flex-col gap-3 shadow-sm">
        <div className="flex items-center justify-between border-b border-kf-border pb-2.5">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-kf-pink" />
            <span className="text-xs font-semibold uppercase tracking-wider text-kf-text font-mono">
              Live Parametric Dimensions
            </span>
          </div>
          <span className="text-[11px] font-mono text-kf-pink bg-kf-pink/10 px-2 py-0.5 rounded border border-kf-pink/25">
            {namedConsts.length} Variables
          </span>
        </div>

        {namedConsts.length === 0 ? (
          <div className="text-[11px] text-kf-muted font-mono py-2 text-center">
            No top-level named consts detected. Edit the code below or generate a new prompt.
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {namedConsts.map((item, index) => {
              const maxRange = Math.max(item.value * 2.5, 100);
              const minRange = Math.max(0.5, Number((item.value * 0.1).toFixed(1)));
              const step = item.value < 10 ? 0.2 : 1;
              const derivedRel = derivedMap.get(item.name);
              const isDerived = Boolean(derivedRel);
              const drivesList = derivedRelationships
                .filter((r) => r.inputs.includes(item.name))
                .map((r) => r.derived);

              return (
                <div
                  key={`${item.name}-${index}`}
                  className={`trace clip-corner flex flex-col gap-1.5 p-2.5 rounded-md border ${
                    isDerived
                      ? 'bg-kf-panel-2/50 border-kf-border/50 opacity-90'
                      : 'bg-kf-panel-2 border-kf-border'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-mono">
                    <div className="flex items-center gap-1.5 min-w-0">
                      {isDerived ? (
                        <span
                          className="flex items-center gap-1 text-[10px] text-kf-muted bg-kf-panel px-1.5 py-0.5 rounded border border-kf-border shrink-0"
                          title={`Derived: ${derivedRel?.expression} (from ${derivedRel?.inputs.join(', ')})`}
                        >
                          <Link className="w-2.5 h-2.5 text-kf-pink" />
                          <span>Derived</span>
                        </span>
                      ) : null}
                      <span className="text-kf-text font-medium truncate" title={item.name}>
                        {item.name}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {isDerived && (
                        <button
                          type="button"
                          id={`btn-unlink-${item.name}-${index}`}
                          onClick={() => handleUnlink(item.name)}
                          title="Unlink derived relationship to edit independently"
                          className="flex items-center gap-1 text-[10px] font-mono text-kf-muted hover:text-kf-pink bg-kf-panel hover:bg-kf-panel-2 border border-kf-border px-1.5 py-0.5 rounded transition cursor-pointer"
                        >
                          <Unlink className="w-2.5 h-2.5" />
                          <span>Unlink</span>
                        </button>
                      )}
                      <input
                        type="number"
                        id={`input-param-${item.name}-${index}`}
                        value={item.value}
                        step={step}
                        min={minRange}
                        max={maxRange}
                        readOnly={isDerived}
                        disabled={isDerived}
                        onChange={(e) => handleVarChange(item.name, parseFloat(e.target.value))}
                        className={`w-20 border text-right px-2 py-1 rounded text-xs font-mono focus:outline-none ${
                          isDerived
                            ? 'bg-kf-panel/40 border-kf-border/40 text-kf-muted cursor-not-allowed select-all'
                            : 'bg-kf-panel border-kf-border text-kf-pink focus:border-kf-pink'
                        }`}
                      />
                      <span className="text-[11px] text-kf-muted">mm</span>
                    </div>
                  </div>

                  {isDerived ? (
                    <div className="flex items-center justify-between text-[10px] font-mono text-kf-muted px-1">
                      <span className="truncate" title={derivedRel?.expression}>
                        = {derivedRel?.expression}
                      </span>
                      <span className="text-[9px] text-kf-muted/80">auto-computed</span>
                    </div>
                  ) : (
                    <>
                      <input
                        type="range"
                        id={`slider-param-${item.name}-${index}`}
                        min={minRange}
                        max={maxRange}
                        step={step}
                        value={item.value}
                        onChange={(e) => handleVarChange(item.name, parseFloat(e.target.value))}
                        className="kf-slider w-full cursor-pointer"
                      />
                      {drivesList.length > 0 && (
                        <div className="text-[9px] font-mono text-kf-muted/80 px-0.5 flex items-center gap-1">
                          <span className="text-kf-pink/70">↳ Drives:</span>
                          <span className="truncate">{drivesList.join(', ')}</span>
                        </div>
                      )}
                    </>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Code Inspector Toggle */}
      <div className="trace clip-corner border border-kf-border bg-kf-panel rounded-lg overflow-hidden shadow-sm">
        <button
          type="button"
          id="btn-toggle-code-view"
          onClick={() => setShowCode(!showCode)}
          className="w-full flex items-center justify-between p-3 text-xs text-kf-muted hover:text-kf-text hover:bg-kf-border/30 transition font-mono cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <Code className="w-3.5 h-3.5 text-kf-muted" />
            <span>JSCAD Source Script</span>
          </div>
          <span className="text-[11px] text-kf-muted">{showCode ? 'Hide [-]' : 'Show [+]'}</span>
        </button>

        {showCode && (
          <div className="trace clip-corner p-3 border-t border-kf-border bg-kf-panel-2 flex flex-col gap-2">
            <div className="flex justify-end gap-2">
              <button
                type="button"
                id="btn-copy-jscad"
                onClick={handleCopyCode}
                className="flex items-center gap-1.5 text-[11px] font-mono text-kf-muted hover:text-kf-text bg-kf-panel border border-kf-border px-2.5 py-1 rounded-md cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3 text-kf-ok" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy JS'}</span>
              </button>
            </div>
            <textarea
              id="jscad-code-editor"
              rows={12}
              value={currentCode}
              onChange={(e) => onCodeChange(e.target.value)}
              className="w-full font-mono text-[11px] bg-kf-bg border border-kf-border p-2.5 text-kf-pink rounded-md focus:outline-none focus:border-kf-pink leading-tight select-text"
              spellCheck={false}
            />
          </div>
        )}
      </div>

      {/* Test Suite Modal */}
      <TestSuiteModal
        isOpen={isTestSuiteOpen}
        onClose={() => setIsTestSuiteOpen(false)}
        onRunTest={(testPrompt) => {
          setPrompt(testPrompt);
          onGeneratePrompt(testPrompt, { useTemplate: false, mode: selectedMode });
        }}
      />

      {/* Explicit Template Library Modal */}
      <TemplateLibraryModal
        isOpen={isTemplateModalOpen}
        onClose={() => setIsTemplateModalOpen(false)}
        onSelectTemplate={(templatePrompt) => {
          setPrompt(templatePrompt);
          onGeneratePrompt(templatePrompt, { useTemplate: true, mode: 'fast' });
        }}
      />
    </div>
  );
};
