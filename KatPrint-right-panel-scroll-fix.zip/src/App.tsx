import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import * as THREE from 'three';
import {
  Printer,
  Flame,
  Layers,
  Sparkles,
  RefreshCw,
  AlertTriangle,
  FileCode,
  Download,
  Upload,
  Droplets,
  Activity,
  Sliders,
  Settings,
  HelpCircle,
  Maximize2,
  Box,
  Image as ImageIcon,
  Camera,
  Cpu,
  ShieldCheck,
  Flower2,
  FolderKanban,
  History,
  MessageSquare,
  Package,
  HardDrive,
  FlaskConical,
  GitBranch,
  Edit2,
  Check,
  X,
  Plus,
  Eye,
  RotateCcw,
  Boxes,
  LayoutGrid,
  Loader2,
  MoreHorizontal,
} from 'lucide-react';

import {
  PrinterSpec,
  FilamentSpec,
  ModelGeometryStats,
  PrinterFitResult,
  SlicerSettings,
  CreationMode,
  GenerationPipelineStage,
  ExtractedRequirements,
  DesignConcept,
  DesignValidationReport,
  GenerationError,
  GenerationDiagnostics,
  DesignSpecification,
  DesignCheck,
  FidelityReviewResult,
  GenerationMode,
  AIRequestRecord,
  ExecutedModelPart,
  ProjectReferenceImage,
  PrintabilityReport,
} from './types';

import {
  KatPrintProject,
  ModelVersion,
  DesignConversationMessage,
  DesignChangeSet,
} from './projects/projectTypes';
import { projectRepository } from './projects/projectRepository';
import {
  createDefaultProject,
  createBlankProject,
  inferProjectName,
  getNextVersionNumber,
  createVersionLabel,
  duplicateProjectGraph,
  buildModelVersion,
} from './projects/projectService';
import { updateProjectMemoryFromVersion } from './projects/projectMemory';
import { buildGenerationDiagnostics } from './projects/generationDiagnostics';
import {
  applyRevisionToProject,
  applyDirectParameterUpdateToProject,
  applyBoundParameterChangesToProject,
  restoreVersionAsNewHead,
  branchNewVersion,
  parseRevisionInstruction,
} from './projects/revisionEngine';
import { exportProjectPackage } from './projects/projectSerializer';
import { sanitizeStlFilename } from './versions/versionService';
import {
  SemanticFeatureModel,
  planSemanticFeatureModel,
  verifySemanticFeatureModel,
  finalizeFeatureModelForCode,
  reconstructLegacyFeatureModel,
  toggleParameterLock,
  ManipulatorType,
  SemanticRevisionOpType,
} from './features';
import { FeatureInspector } from './components/features/FeatureInspector';

import { INITIAL_PRINTERS } from './data/printers';
import { FILAMENTS } from './data/filaments';
import { analyzeBufferGeometry, exportBinarySTL } from './engine/geometryUtils';
import { getPhysicalPieceCount, hasMultiplePhysicalPieces, validateExecutedModelParts, downloadExportSTL } from './engine/stlExporter';
import { computePrinterFit, computeSlicerSettings, exportGCodeFile } from './engine/slicerEngine';
import { runPrintabilityAnalysisAsync } from './engine/clientPrintability';
import { executeJscadCode, executeJscadModel, DEFAULT_PLANTER_JSCAD } from './engine/jscadRunner';
import { generateCadThumbnail } from './engine/designVerification/renderInspectionViews';
import {
  requestJscadGeneration,
  requestJscadRevision,
  requestFixMissingFeatures,
  requestSlicerExplanation,
  requestFidelityReview,
  requestTargetedRepair,
  extractPromptRequirements,
  requestConceptVariants,
  mapApiErrorMessage,
} from './services/geminiService';
import { buildDesignSpecification } from './engine/designIntent/designSpecification';
import { generateDesignChecklist } from './engine/designIntent/designChecklist';
import { performDeterministicInspection } from './engine/designVerification/geometryVerification';
import { renderInspectionViews } from './engine/designVerification/renderInspectionViews';

import { Viewer3D } from './components/Viewer3D';
import { ParametricEditor } from './components/ParametricEditor';
import { ImageToMeshEditor } from './components/ImageToMeshEditor';
import { PrintSettingsPanel } from './components/PrintSettingsPanel';
import { LivePrinterMonitor } from './components/LivePrinterMonitor';
import { CustomPrinterModal } from './components/CustomPrinterModal';
import { PrinterQuickSelect } from './components/PrinterQuickSelect';
import { TestSuiteModal } from './components/TestSuiteModal';
import { MultiPartManager } from './components/assembly/MultiPartManager';
import { PlateLayoutModal } from './components/assembly/PlateLayoutModal';
import { ReferencePhotosManager } from './components/ReferencePhotosManager';

// Phase 2 UI Components
import { ProjectLibrary } from './components/projects/ProjectLibrary';
import { VersionHistoryPanel } from './components/projects/VersionHistoryPanel';
import { VersionComparisonModal } from './components/projects/VersionComparisonModal';
import { ProjectConversationPanel } from './components/projects/ProjectConversationPanel';
import { ProposedChangesModal } from './components/projects/ProposedChangesModal';
import { StorageManagementModal } from './components/projects/StorageManagementModal';
import { SpecReviewPanel } from './components/SpecReviewPanel';
import { ConceptSelector } from './components/ConceptSelector';

export default function App() {
  // Navigation: Workspace vs Project Library
  const [navView, setNavView] = useState<'workspace' | 'projects'>('workspace');
  const [rightPanelTab, setRightPanelTab] = useState<'design' | 'print' | 'versions'>('design');
  const [designPanelMode, setDesignPanelMode] = useState<'assistant' | 'feature'>('assistant');
  const [isHeaderMenuOpen, setIsHeaderMenuOpen] = useState(false);

  // Mode Selection
  const [mode, setMode] = useState<CreationMode>('describe');

  // Projects State & Persistence
  const [projects, setProjects] = useState<KatPrintProject[]>([]);
  const [activeProject, setActiveProject] = useState<KatPrintProject | null>(null);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('saved');
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [editableTitle, setEditableTitle] = useState('');

  // Version Viewing / Comparison State
  const [viewingVersionId, setViewingVersionId] = useState<string | null>(null);
  const [isComparisonModalOpen, setIsComparisonModalOpen] = useState(false);
  const [compareVersionA, setCompareVersionA] = useState<ModelVersion | undefined>(undefined);
  const [compareVersionB, setCompareVersionB] = useState<ModelVersion | undefined>(undefined);

  // Proposed Changes Modal
  const [proposedChangeSet, setProposedChangeSet] = useState<DesignChangeSet | null>(null);
  const [pendingRevisionInstruction, setPendingRevisionInstruction] = useState<string | null>(null);

  // Multi-Part Assembly & Reference Photos Modals and State
  const [currentParts, setCurrentParts] = useState<ExecutedModelPart[]>([]);
  const [explodedOffset, setExplodedOffset] = useState<number>(0);
  const [partVisibility, setPartVisibility] = useState<Record<string, boolean>>({});
  const [selectedPartId, setSelectedPartId] = useState<string | null>(null);
  const [isPlateLayoutOpen, setIsPlateLayoutOpen] = useState(false);
  const [isReferencePhotosOpen, setIsReferencePhotosOpen] = useState(false);

  // Additional Modals
  const [isStorageModalOpen, setIsStorageModalOpen] = useState(false);
  const [isTestSuiteOpen, setIsTestSuiteOpen] = useState(false);
  const [isCustomPrinterOpen, setIsCustomPrinterOpen] = useState(false);
  const [isLiveMonitorOpen, setIsLiveMonitorOpen] = useState(false);

  // Hardware State
  const [printers, setPrinters] = useState<PrinterSpec[]>(INITIAL_PRINTERS);
  const [selectedPrinterId, setSelectedPrinterId] = useState<string>('bambu-x1c');
  const [selectedFilamentId, setSelectedFilamentId] = useState<string>('pla');
  const [mustHoldLiquid, setMustHoldLiquid] = useState<boolean>(false);
  const [scaleFactor, setScaleFactor] = useState<number>(1.0);
  const [printerCardCollapsed, setPrinterCardCollapsed] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('kf.printerCardCollapsed');
      return saved !== null ? JSON.parse(saved) : false;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('kf.printerCardCollapsed', JSON.stringify(printerCardCollapsed));
    } catch {
      // ignore
    }
  }, [printerCardCollapsed]);

  // 3D Geometry State
  const [currentJscadCode, setCurrentJscadCode] = useState<string>(DEFAULT_PLANTER_JSCAD);
  const [activeGeometry, setActiveGeometry] = useState<THREE.BufferGeometry | null>(null);
  const [modelName, setModelName] = useState<string>('Self-Watering Planter');
  const [highlightOverhangs, setHighlightOverhangs] = useState<boolean>(true);

  // AI Pipeline States
  const [isGeneratingCad, setIsGeneratingCad] = useState<boolean>(false);
  const [isRevisingCad, setIsRevisingCad] = useState<boolean>(false);
  const [isFixingFeatures, setIsFixingFeatures] = useState<boolean>(false);
  const [pipelineStage, setPipelineStage] = useState<GenerationPipelineStage>('idle');
  const [repairAttempt, setRepairAttempt] = useState<number>(1);
  const [cadErrorMessage, setCadErrorMessage] = useState<string | null>(null);
  const [generationError, setGenerationError] = useState<GenerationError | null>(null);
  const [generationDiagnostics, setGenerationDiagnostics] = useState<GenerationDiagnostics | null>(null);
  const [generationId, setGenerationId] = useState<string | null>(null);
  const [currentGenerationId, setCurrentGenerationId] = useState<string | null>(null);
  const [activeGeometryGenerationId, setActiveGeometryGenerationId] = useState<string | null>(null);
  const [lastGenerationStatus, setLastGenerationStatus] = useState<'idle' | 'generating' | 'success' | 'error'>('success');
  const [cadSource, setCadSource] = useState<'ai' | 'template' | null>(null);
  const [lastPrompt, setLastPrompt] = useState<string>(
    '100 mm × 60 mm × 25 mm electronics enclosure with 3 mm walls, four M4 mounting holes in corners, two 20 mm cable openings on left, and removable top lid'
  );
  const [extractedRequirements, setExtractedRequirements] = useState<ExtractedRequirements | null>(null);
  const [validationReport, setValidationReport] = useState<DesignValidationReport | null>(null);

  // Spec Review Step State
  const [skipSpecReview, setSkipSpecReview] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('katprint_skip_spec_review') === 'true';
    }
    return false;
  });
  const [isReviewingSpec, setIsReviewingSpec] = useState<boolean>(false);
  const [isRegeneratingSpec, setIsRegeneratingSpec] = useState<boolean>(false);
  const [pendingSpecPrompt, setPendingSpecPrompt] = useState<string>('');
  const [pendingSpecOptions, setPendingSpecOptions] = useState<any>(null);

  const handleToggleSkipSpecReview = useCallback((val: boolean) => {
    setSkipSpecReview(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('katprint_skip_spec_review', String(val));
    }
  }, []);

  // Concept Variant Strategy State
  const [exploreApproaches, setExploreApproaches] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('katprint_explore_approaches') === 'true';
    }
    return false;
  });
  const [isSelectingConcept, setIsSelectingConcept] = useState<boolean>(false);
  const [conceptVariants, setConceptVariants] = useState<DesignConcept[]>([]);
  const [pendingConceptPrompt, setPendingConceptPrompt] = useState<string>('');
  const [pendingConceptReqs, setPendingConceptReqs] = useState<ExtractedRequirements | null>(null);
  const [pendingConceptUserOverrides, setPendingConceptUserOverrides] = useState<string[]>([]);
  const [pendingConceptOptions, setPendingConceptOptions] = useState<any>(null);
  const [pendingConceptAiRecords, setPendingConceptAiRecords] = useState<AIRequestRecord[]>([]);

  const handleToggleExploreApproaches = useCallback((val: boolean) => {
    setExploreApproaches(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('katprint_explore_approaches', String(val));
    }
  }, []);

  // Precision Engine State
  const [designSpecification, setDesignSpecification] = useState<DesignSpecification | null>(null);
  const [designChecklist, setDesignChecklist] = useState<DesignCheck[]>([]);
  const [fidelityReviewResult, setFidelityReviewResult] = useState<FidelityReviewResult | null>(null);

  // Slicer Explanation & Printability Audit
  const [slicerExplanation, setSlicerExplanation] = useState<string | null>(null);
  const [isExplainingSlicer, setIsExplainingSlicer] = useState<boolean>(false);
  const [printabilityReport, setPrintabilityReport] = useState<PrintabilityReport | null>(null);
  const [isAnalyzingPrintability, setIsAnalyzingPrintability] = useState<boolean>(false);

  // STL Export Generation State
  const [stlExportProgress, setStlExportProgress] = useState<number | null>(null);

  // Semantic 3D Feature Selection
  const [selectedFeatureId, setSelectedFeatureId] = useState<string | null>(null);
  const [selectedFeatureIds, setSelectedFeatureIds] = useState<string[]>([]);
  const [debugShowPickProxies, setDebugShowPickProxies] = useState<boolean>(false);
  const [focusTarget, setFocusTarget] = useState<{ featureId: string; nonce: number } | null>(null);

  const handleSelectFeature = useCallback((featureId: string | null) => {
    setSelectedFeatureId(featureId);
    setSelectedFeatureIds(featureId ? [featureId] : []);
    if (featureId) {
      // Auto-open features tab to display parameters immediately upon 3D click
      setRightPanelTab('design');
      setDesignPanelMode('feature');
    }
  }, []);

  const handleMultiSelectFeatures = useCallback((featureIds: string[]) => {
    setSelectedFeatureIds(featureIds);
    setSelectedFeatureId(featureIds[featureIds.length - 1] || null);
    if (featureIds.length > 0) {
      setRightPanelTab('design');
      setDesignPanelMode('feature');
    }
  }, []);

  const handleFocusFeature = useCallback((featureId: string) => {
    setFocusTarget({ featureId, nonce: Date.now() });
  }, []);

  // Left panel scroll affordance fade state
  const leftPanelScrollRef = useRef<HTMLDivElement>(null);
  const [showLeftPanelScrollFade, setShowLeftPanelScrollFade] = useState<boolean>(false);

  useEffect(() => {
    const el = leftPanelScrollRef.current;
    if (!el) return;

    let rafId: number | null = null;

    const checkScroll = () => {
      if (rafId !== null) return;
      rafId = requestAnimationFrame(() => {
        rafId = null;
        if (!el) return;
        const hasOverflow = el.scrollHeight > el.clientHeight + 4;
        const isAtBottom = el.scrollHeight - el.scrollTop - el.clientHeight <= 8;
        setShowLeftPanelScrollFade(hasOverflow && !isAtBottom);
      });
    };

    checkScroll();
    el.addEventListener('scroll', checkScroll, { passive: true });

    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => checkScroll());
      ro.observe(el);
    }

    return () => {
      if (rafId !== null) cancelAnimationFrame(rafId);
      el.removeEventListener('scroll', checkScroll);
      if (ro) ro.disconnect();
    };
  }, [navView, mode, isReviewingSpec, isSelectingConcept, printerCardCollapsed, currentJscadCode, activeProject]);

  // Current active printer and filament objects
  const selectedPrinter = useMemo(
    () => printers.find((p) => p.id === selectedPrinterId) || printers[0],
    [printers, selectedPrinterId]
  );

  const printerGroups = useMemo(() => {
    const groups: { [key: string]: PrinterSpec[] } = {
      'Creality': [],
      'Bambu Lab': [],
      'Prusa Research': [],
      'Elegoo': [],
      'Anycubic': [],
      'Sovol / QIDI / Voron': [],
      'Custom / DIY': [],
    };

    for (const p of printers) {
      if (!p) continue;
      const pName = p.name || '';
      const pId = p.id || '';

      if (p.isCustom || pId === 'custom') {
        groups['Custom / DIY'].push(p);
      } else if (pName.startsWith('Creality') || pId.startsWith('ender-')) {
        groups['Creality'].push(p);
      } else if (pName.startsWith('Bambu')) {
        groups['Bambu Lab'].push(p);
      } else if (pName.startsWith('Prusa')) {
        groups['Prusa Research'].push(p);
      } else if (pName.startsWith('Elegoo')) {
        groups['Elegoo'].push(p);
      } else if (pName.startsWith('Anycubic')) {
        groups['Anycubic'].push(p);
      } else if (pName.startsWith('Sovol') || pName.startsWith('QIDI') || pName.startsWith('Voron')) {
        groups['Sovol / QIDI / Voron'].push(p);
      } else {
        if (!groups['Other']) groups['Other'] = [];
        groups['Other'].push(p);
      }
    }

    return Object.entries(groups).filter(([, list]) => list.length > 0);
  }, [printers]);

  const selectedFilament = useMemo(
    () => FILAMENTS.find((f) => f.id === selectedFilamentId) || FILAMENTS[0],
    [selectedFilamentId]
  );

  // Save active project to IndexedDB when changed
  const persistActiveProject = useCallback(async (updated: KatPrintProject) => {
    setSaveStatus('saving');
    try {
      await projectRepository.saveProject(updated);
      setProjects((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
      setActiveProject(updated);
      setSaveStatus('saved');
    } catch (err) {
      console.error('Failed to persist project:', err);
      setSaveStatus('error');
    }
  }, []);

  // Centralized Version Geometry & Identity Activation Helper
  const activateVersionGeometry = useCallback(
    (
      version: ModelVersion | null | undefined,
      options?: { head?: boolean; density?: number }
    ) => {
      const isHead = options?.head !== false;
      if (!version || !version.cadCode) {
        setCurrentJscadCode('');
        setActiveGeometry(null);
        if (isHead) {
          setCurrentGenerationId(null);
          setGenerationId(null);
        }
        setActiveGeometryGenerationId(null);
        setLastGenerationStatus('idle');
        setCadErrorMessage(null);
        setGenerationError(null);
        return { success: false, isManifold: false };
      }

      const script = version.cadCode;
      setCurrentJscadCode(script);
      setLastPrompt(version.prompt || '');
      setCadSource(script ? 'ai' : null);
      setDesignSpecification(version.designSpecification || null);
      setDesignChecklist(version.designChecklist || []);
      setFidelityReviewResult(version.fidelityReview || null);

      if (version.generationDiagnostics) {
        setGenerationDiagnostics(version.generationDiagnostics);
      }

      const vGenId = version.generationDiagnostics?.generationId || version.id || null;
      setActiveGeometryGenerationId(vGenId);

      try {
        const executed = executeJscadModel(script, version.assembly);
        const geom = executed.combinedGeometry;
        const density = options?.density ?? selectedFilament.densityGcm3 ?? 1.24;
        const stats = analyzeBufferGeometry(geom, density);
        const isValid =
          stats.triangleCount > 0 &&
          stats.volumeMm3 > 0 &&
          stats.isManifold === true &&
          (stats.nonManifoldEdgeCount ?? 0) === 0;

        setActiveGeometry(geom);
        setCurrentParts(executed.parts || []);

        if (isHead) {
          setCurrentGenerationId(vGenId);
          setGenerationId(vGenId);
        }

        if (isValid) {
          setLastGenerationStatus('success');
          setCadErrorMessage(null);
          setGenerationError(null);
        } else {
          setLastGenerationStatus('error');
          setCadErrorMessage(
            stats.isManifold
              ? 'Model has zero volume or no solid triangles.'
              : `Model contains ${stats.nonManifoldEdgeCount || 'open'} non-manifold edges.`
          );
        }

        return { success: isValid, isManifold: stats.isManifold, stats };
      } catch (err: any) {
        console.error('Failed to activate version geometry:', err);
        setActiveGeometry(null);
        setLastGenerationStatus('error');
        setCadErrorMessage(err?.message || 'Failed to render 3D geometry.');
        return { success: false, isManifold: false };
      }
    },
    [selectedFilament.densityGcm3]
  );

  // Centralized project activation & geometry validation
  const activateProject = useCallback(
    (project: KatPrintProject) => {
      if (!project) return;
      setActiveProject(project);
      setEditableTitle(project.name);
      setModelName(project.name);
      setViewingVersionId(null);

      // Validate & restore hardware configuration
      if (project.projectSettings) {
        const validPrinter = printers.some((p) => p.id === project.projectSettings.printerId);
        const targetPrinterId = validPrinter ? project.projectSettings.printerId : 'bambu-x1c';
        setSelectedPrinterId(targetPrinterId);

        const validFilament = FILAMENTS.some((f) => f.id === project.projectSettings.filamentId);
        const targetFilamentId = validFilament ? project.projectSettings.filamentId : 'pla';
        setSelectedFilamentId(targetFilamentId);

        if (typeof project.projectSettings.scaleFactor === 'number') {
          setScaleFactor(project.projectSettings.scaleFactor);
        }
        if (typeof project.projectSettings.mustHoldLiquid === 'boolean') {
          setMustHoldLiquid(project.projectSettings.mustHoldLiquid);
        }
      }

      const versions = project.versions || [];
      const currentVer =
        versions.find((v) => v.id === project.currentVersionId) || versions[versions.length - 1];

      activateVersionGeometry(currentVer, { head: true });
    },
    [printers, activateVersionGeometry]
  );

  // Update active project's generation mode and persist
  const handleGenerationModeChange = async (newMode: GenerationMode) => {
    if (!activeProject) return;
    const updated: KatPrintProject = {
      ...activeProject,
      projectSettings: {
        ...activeProject.projectSettings,
        generationMode: newMode,
      },
      updatedAt: new Date().toISOString(),
    };
    await persistActiveProject(updated);
  };

  // Load projects from IndexedDB on startup
  useEffect(() => {
    let isMounted = true;
    async function initProjects() {
      try {
        const loaded = await projectRepository.listProjects();
        if (!isMounted) return;

        if (loaded && loaded.length > 0) {
          setProjects(loaded);
          activateProject(loaded[0]);
        } else {
          // Initialize first default project
          const defaultProj = createDefaultProject('Self-Watering Planter with internal reservoir and wicking channel');
          defaultProj.name = 'Self-Watering Planter';
          
          let initialGeom: THREE.BufferGeometry | null = null;
          try {
            initialGeom = executeJscadCode(DEFAULT_PLANTER_JSCAD);
            setActiveGeometry(initialGeom);
          } catch (e) {
            console.error('Planter geometry init error:', e);
          }

          const stats = initialGeom ? analyzeBufferGeometry(initialGeom, 1.24) : undefined;
          const initialFeatureModel = reconstructLegacyFeatureModel(
            DEFAULT_PLANTER_JSCAD,
            'Self-watering planter with reservoir and wicking channel',
            undefined,
            stats
          ).model;
          const verifiedInitialModel = stats
            ? verifySemanticFeatureModel(initialFeatureModel, stats, DEFAULT_PLANTER_JSCAD).updatedModel
            : initialFeatureModel;

          const v1 = buildModelVersion({
            projectId: defaultProj.id,
            versionNumber: 1,
            label: 'V1 — Initial Planter Design',
            prompt: 'Self-watering planter with reservoir and wicking channel',
            cadCode: DEFAULT_PLANTER_JSCAD,
            geometryMetadata: stats,
            changeSummary: 'Initial parametric planter design with live sliders and wicking channels.',
            changeType: 'INITIAL_GENERATION',
            isCurrentHead: true,
            status: 'unverified',
            designMatchScore: null,
            featureModel: verifiedInitialModel,
          });

          defaultProj.versions = [v1];
          defaultProj.currentVersionId = v1.id;
          await projectRepository.saveProject(defaultProj);

          setProjects([defaultProj]);
          activateProject(defaultProj);
        }
      } catch (err) {
        console.error('Failed to initialize projects database:', err);
      }
    }

    initProjects();
    return () => {
      isMounted = false;
    };
  }, [activateProject]);

  // Active Version calculation
  const currentActiveVersion = useMemo(() => {
    if (!activeProject || !activeProject.versions) return null;
    if (viewingVersionId) {
      return activeProject.versions.find((v) => v.id === viewingVersionId) || null;
    }
    return activeProject.versions.find((v) => v.id === activeProject.currentVersionId) ||
      activeProject.versions[activeProject.versions.length - 1] || null;
  }, [activeProject, viewingVersionId]);

  // Reconcile 3D feature selection when active version or feature model changes
  useEffect(() => {
    const model = currentActiveVersion?.featureModel;
    if (!model || !Array.isArray(model.features)) {
      if (selectedFeatureId !== null) setSelectedFeatureId(null);
      if (selectedFeatureIds.length > 0) setSelectedFeatureIds([]);
      return;
    }

    const validFeatureIds = new Set(model.features.map((f) => f.id));
    const nextSelectedIds = selectedFeatureIds.filter((id) => validFeatureIds.has(id));
    const isPrimaryValid = selectedFeatureId ? validFeatureIds.has(selectedFeatureId) : false;
    const nextPrimaryId = isPrimaryValid
      ? selectedFeatureId
      : nextSelectedIds.length > 0
      ? nextSelectedIds[nextSelectedIds.length - 1]
      : null;

    if (
      nextSelectedIds.length !== selectedFeatureIds.length ||
      nextPrimaryId !== selectedFeatureId
    ) {
      setSelectedFeatureIds(nextSelectedIds);
      setSelectedFeatureId(nextPrimaryId);
    }
  }, [currentActiveVersion?.id, currentActiveVersion?.featureModel]);

  // Volumetric & Overhang stats
  const geometryStats: ModelGeometryStats = useMemo(() => {
    if (!activeGeometry) {
      return {
        dimensions: { x: 0, y: 0, z: 0 },
        volumeMm3: 0,
        volumeCm3: 0,
        surfaceAreaMm2: 0,
        estimatedWeightGrams: 0,
        triangleCount: 0,
        vertexCount: 0,
        nonManifoldEdgeCount: 0,
        overhangRatio: 0,
        minWallThicknessMm: 0,
        isManifold: false,
        footprintAreaMm2: 0,
        heightToWidthRatio: 0,
        hasSteepOverhangs: false,
      };
    }
    return analyzeBufferGeometry(activeGeometry, selectedFilament.densityGcm3);
  }, [activeGeometry, selectedFilament.densityGcm3]);

  // Live Printer Fit Check
  const printerFitResult: PrinterFitResult = useMemo(() => {
    return computePrinterFit(geometryStats, selectedPrinter, scaleFactor, currentParts);
  }, [geometryStats, selectedPrinter, scaleFactor, currentParts]);

  // Background Web Worker Printability Analysis
  useEffect(() => {
    let isCurrent = true;
    if (!activeGeometry || geometryStats.triangleCount === 0) {
      setPrintabilityReport(null);
      setIsAnalyzingPrintability(false);
      return;
    }

    setIsAnalyzingPrintability(true);
    runPrintabilityAnalysisAsync(activeGeometry, {
      nozzleMm: selectedPrinter.nozzleDiameter,
      layerHeightMm: selectedPrinter.nozzleDiameter * 0.5,
      bedSize: selectedPrinter.buildVolume,
    })
      .then((rep) => {
        if (isCurrent) {
          setPrintabilityReport(rep);
          setIsAnalyzingPrintability(false);
        }
      })
      .catch((err) => {
        console.warn('Printability analysis error:', err);
        if (isCurrent) {
          setIsAnalyzingPrintability(false);
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [activeGeometry, selectedPrinter.nozzleDiameter, selectedPrinter.buildVolume]);

  // Slicer Settings Engine
  const slicerSettings: SlicerSettings = useMemo(() => {
    return computeSlicerSettings(
      geometryStats,
      selectedPrinter,
      selectedFilament,
      scaleFactor,
      mustHoldLiquid,
      printabilityReport || undefined
    );
  }, [geometryStats, selectedPrinter, selectedFilament, scaleFactor, mustHoldLiquid, printabilityReport]);

  // Centralized Export Validation Guard
  const exportValidation = useMemo(() => {
    if (!activeGeometry && (!currentParts || currentParts.length === 0)) {
      return { allowed: false, reason: 'No active 3D model geometry loaded.' };
    }
    if (isGeneratingCad || isRevisingCad) {
      return {
        allowed: false,
        reason: 'Generation in progress — export will be available once rendering completes.',
      };
    }
    const hasParts = currentParts && currentParts.length > 0;
    const triangles = geometryStats?.triangleCount || 0;
    if (!hasParts && triangles <= 0) {
      return { allowed: false, reason: 'Model has no mesh polygons/triangles.' };
    }
    if (hasMultiplePhysicalPieces(currentParts)) {
      const partValidation = validateExecutedModelParts(currentParts);
      if (!partValidation.valid && (!activeGeometry || (geometryStats?.triangleCount || 0) <= 0)) {
        const first = partValidation.invalidParts[0];
        return {
          allowed: false,
          reason: `STL export blocked: ${first?.partName || 'A part'} ${first?.reason || 'is invalid'}.`,
        };
      }
    }
    return { allowed: true, reason: '' };
  }, [activeGeometry, geometryStats, isGeneratingCad, isRevisingCad, currentParts]);

  // Helper to commit a new version to active project
  const recordNewVersion = useCallback(
    async (
      code: string,
      geom: THREE.BufferGeometry,
      prompt: string,
      changeSummary: string,
      changeType: 'INITIAL_GENERATION' | 'REVISION' | 'RESTORED' | 'BRANCH' | 'MANUAL_EDIT' = 'REVISION',
      score: number | null = null,
      spec?: DesignSpecification,
      checklist?: DesignCheck[],
      review?: FidelityReviewResult,
      diffExplanation?: string,
      targetProject?: KatPrintProject,
      featureModel?: SemanticFeatureModel | null
    ) => {
      const projectToUpdate = targetProject || activeProject;
      if (!projectToUpdate) return;

      const stats = analyzeBufferGeometry(geom, selectedFilament.densityGcm3);
      const nextNum = getNextVersionNumber(projectToUpdate.versions);
      const newVerId = `ver_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      const now = new Date().toISOString();

      const thumbnail = generateCadThumbnail(geom);
      const finalScore = score !== undefined ? score : null;
      const status = stats.isManifold
        ? finalScore !== null
          ? finalScore >= 90
            ? 'verified'
            : finalScore >= 70
            ? 'unverified'
            : 'failed'
          : 'unverified'
        : 'failed';

      // Feature Verification & Code Binding Finalization if model provided
      let verifiedFeatureModel = featureModel;
      if (verifiedFeatureModel) {
        verifiedFeatureModel = finalizeFeatureModelForCode(
          verifiedFeatureModel,
          code,
          stats,
          verifiedFeatureModel.generationStrategy === 'legacy-reconstructed' ? 'legacy' : 'strict'
        );
      }

      const newVersion = buildModelVersion({
        id: newVerId,
        projectId: projectToUpdate.id,
        versionNumber: nextNum,
        parentVersionId: projectToUpdate.currentVersionId,
        label: createVersionLabel(nextNum, prompt, changeType),
        prompt,
        userInstruction: prompt,
        cadCode: code,
        geometryMetadata: stats,
        changeSummary,
        changeType,
        isCurrentHead: true,
        status,
        designMatchScore: finalScore,
        designSpecification: spec,
        designChecklist: checklist,
        featureModel: verifiedFeatureModel,
        fidelityReview: review,
        diffExplanation,
        thumbnail: thumbnail || undefined,
      });

      const updatedVersions = (projectToUpdate.versions || []).map((v) => ({ ...v, isCurrentHead: false }));
      updatedVersions.push(newVersion);

      const updatedProject: KatPrintProject = {
        ...projectToUpdate,
        currentVersionId: newVerId,
        versions: updatedVersions,
        thumbnail: thumbnail || projectToUpdate.thumbnail,
        projectMemory: updateProjectMemoryFromVersion(projectToUpdate.projectMemory, newVersion, prompt),
        updatedAt: now,
      };

      await persistActiveProject(updatedProject);
      setViewingVersionId(null);
    },
    [activeProject, selectedFilament.densityGcm3, persistActiveProject]
  );

  // Core CAD Generation Pipeline (Precision or Fast) after Specs are Confirmed
  const executeCadGenerationPipeline = async (
    promptText: string,
    reqs: ExtractedRequirements,
    userOverrides: string[] = [],
    options?: {
      useTemplate?: boolean;
      simplifyToParametric?: boolean;
      mode?: GenerationMode;
      targetProject?: KatPrintProject;
      bypassSpecReview?: boolean;
      exploreApproaches?: boolean;
    },
    priorAiRecords: AIRequestRecord[] = []
  ) => {
    const pipelineStartTime = Date.now();
    const thisGenId = `gen_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const currentMode =
      options?.mode ??
      options?.targetProject?.projectSettings?.generationMode ??
      activeProject?.projectSettings?.generationMode ??
      'precision';
    setCurrentGenerationId(thisGenId);
    setLastGenerationStatus('generating');
    setIsGeneratingCad(true);
    setIsReviewingSpec(false);
    setCadErrorMessage(null);
    setGenerationError(null);
    setLastPrompt(promptText);
    setSlicerExplanation(null);
    setRepairAttempt(1);

    try {
      const activeProjRefImages = (options?.targetProject || activeProject)?.referenceImages;
      const aiRecords: AIRequestRecord[] = [...priorAiRecords];

      if (currentMode === 'precision') {
        const spec = buildDesignSpecification(promptText, reqs);
        setDesignSpecification(spec);

        // Step 2: Planning Semantic Feature Model & Generating Checklist
        setPipelineStage('planning_geometry');
        const plannedFeatureModel = planSemanticFeatureModel(spec, promptText);
        const checklist = generateDesignChecklist(spec);
        setDesignChecklist(checklist);

        // Step 3: Generating Parametric CAD Code
        setPipelineStage('generating_cad');
        const result = await requestJscadGeneration(promptText, {
          requirements: reqs,
          userOverrides,
          featureModel: plannedFeatureModel,
          designSpecification: spec,
          designChecklist: checklist,
          simplifyToParametric: options?.simplifyToParametric,
          mode: 'precision',
          referenceImages: activeProjRefImages,
        });
        if (result.diagnostics?.requestRecords) {
          aiRecords.push(...result.diagnostics.requestRecords);
        }

        // Step 4: Building Solid Model
        setPipelineStage('building_model');
        let currentCode = result.code;
        const executed = executeJscadModel(currentCode);
        let newGeom = executed.combinedGeometry;
        setCurrentParts(executed.parts || []);
        setCurrentJscadCode(currentCode);
        setActiveGeometry(newGeom);
        setActiveGeometryGenerationId(thisGenId);
        setLastGenerationStatus('success');
        setCadSource(result.source);
        setGenerationId(result.generationId || thisGenId);

        let geomStats = analyzeBufferGeometry(newGeom, selectedFilament.densityGcm3);
        let activeFeatureModel = finalizeFeatureModelForCode(
          plannedFeatureModel,
          currentCode,
          geomStats,
          'strict'
        );

        // Step 5: Checking Dimensions & Geometry
        setPipelineStage('checking_dimensions');
        const initialInspection = performDeterministicInspection(newGeom, currentCode, spec, checklist);
        setDesignChecklist(initialInspection.checks);

        // Step 6: Rendering Inspection Views
        setPipelineStage('rendering_views');
        const renderedViews = await renderInspectionViews(newGeom);

        // Step 7: Multi-View Visual & Mechanical Fidelity Inspection
        setPipelineStage('inspecting_design');
        const reviewRes = await requestFidelityReview({
          specification: spec,
          code: currentCode,
          geometryStats: geomStats,
          deterministicChecks: initialInspection.checks,
          views: renderedViews,
          purpose: 'visual_fidelity_review',
        });
        if (reviewRes.diagnostics?.requestRecords) {
          aiRecords.push(...reviewRes.diagnostics.requestRecords);
        }
        const review = reviewRes.review;
        setFidelityReviewResult(review);

        // Step 8: Targeted 1-Pass Precision Correction (if needed)
        const semanticBinding = activeFeatureModel.bindingValidation;
        const hasCriticalBindingDefects =
          (semanticBinding?.criticalUnboundParameters.length ?? 0) > 0 ||
          (semanticBinding?.missingBuilderFeatures.some((fid) =>
            activeFeatureModel.features.find((f) => f.id === fid)?.criticality === 'critical'
          ) ?? false);

        const needsCorrection =
          !initialInspection.criticalPassed ||
          review.requiresRepair ||
          (review.problems && review.problems.length > 0 && review.verdict !== 'PASS') ||
          hasCriticalBindingDefects;
        let finalScore = typeof review.overallScore === 'number' ? review.overallScore : null;
        let finalReview = review;
        let finalChecklist = initialInspection.checks;

        if (needsCorrection) {
          setPipelineStage('correcting_model');
          setRepairAttempt(1);

          try {
            const repairResult = await requestTargetedRepair({
              originalPrompt: promptText,
              currentCode,
              specification: spec,
              reviewResult: review,
              deterministicChecks: initialInspection.checks,
              geometryStats: geomStats,
              featureModel: activeFeatureModel,
              bindingValidation: activeFeatureModel.bindingValidation,
              lockedParameterIds: activeFeatureModel.parameters.filter((p) => p.locked).map((p) => p.id),
            });
            if (repairResult.diagnostics?.requestRecords) {
              aiRecords.push(...repairResult.diagnostics.requestRecords);
            }

            currentCode = repairResult.code;
            const repairedExec = executeJscadModel(currentCode);
            newGeom = repairedExec.combinedGeometry;
            setCurrentParts(repairedExec.parts || []);
            setCurrentJscadCode(currentCode);
            setActiveGeometry(newGeom);
            setActiveGeometryGenerationId(thisGenId);

            // Re-render fresh views and re-inspect geometry
            setPipelineStage('final_verification');
            const postRepairViews = await renderInspectionViews(newGeom);
            const postRepairGeomStats = analyzeBufferGeometry(newGeom, selectedFilament.densityGcm3);
            const postRepairInspection = performDeterministicInspection(newGeom, currentCode, spec, checklist);
            setDesignChecklist(postRepairInspection.checks);
            finalChecklist = postRepairInspection.checks;

            activeFeatureModel = finalizeFeatureModelForCode(
              activeFeatureModel,
              currentCode,
              postRepairGeomStats,
              'strict'
            );

            // Final Visual & Fidelity Inspection Pass
            const finalReviewRes = await requestFidelityReview({
              specification: spec,
              code: currentCode,
              geometryStats: postRepairGeomStats,
              deterministicChecks: postRepairInspection.checks,
              views: postRepairViews,
              purpose: 'final_visual_review',
            });
            if (finalReviewRes.diagnostics?.requestRecords) {
              aiRecords.push(...finalReviewRes.diagnostics.requestRecords);
            }
            finalReview = finalReviewRes.review;

            setFidelityReviewResult(finalReview);
            finalScore = typeof finalReview.overallScore === 'number' ? finalReview.overallScore : null;

            const verifiedCount = postRepairInspection.passedChecksCount;
            const totalCount = Math.max(1, postRepairInspection.totalChecksCount);
            const isAllPassed = postRepairInspection.criticalPassed && finalReview.verdict === 'PASS';

            setValidationReport({
              items: postRepairInspection.items,
              overallScore: finalScore,
              passed: isAllPassed,
              verdict: finalReview.verdict === 'INVALID_DESIGN' ? 'FAILED' : isAllPassed ? 'VERIFIED' : 'PARTIALLY VERIFIED',
              summary: finalReview.summary || `Precision verification complete: ${verifiedCount} of ${totalCount} design checks verified.`,
              missingFeatures: (finalReview.problems || []).map((p) => p.requirement),
              warnings: postRepairInspection.warnings,
              fidelityReview: finalReview,
            });
          } catch (repairErr) {
            console.warn('Targeted repair encountered an error, falling back to verified base model:', repairErr);
            setPipelineStage('final_verification');
          }
        } else {
          setPipelineStage('final_verification');
          setValidationReport({
            items: initialInspection.items,
            overallScore: finalScore,
            passed: review.verdict === 'PASS' || review.verdict === 'NEEDS_MINOR_CORRECTION',
            verdict: review.verdict === 'INVALID_DESIGN' ? 'FAILED' : 'VERIFIED',
            summary: review.summary || 'Precision fidelity review complete.',
            missingFeatures: (review.problems || []).map((p) => p.requirement),
            warnings: initialInspection.warnings,
            fidelityReview: review,
          });
        }

        const finalGeomStats = analyzeBufferGeometry(newGeom, selectedFilament.densityGcm3);
        const totalDuration = Date.now() - pipelineStartTime;

        const diag = buildGenerationDiagnostics({
          generationId: result.generationId || thisGenId,
          timestamp: Date.now(),
          mode: 'precision',
          requestRecords: aiRecords,
          repairAttempts: needsCorrection ? 1 : 0,
          latencyMs: totalDuration,
          totalDurationMs: totalDuration,
          status: 'success',
          geometryMeasurements: finalGeomStats,
          measuredDimensions: finalGeomStats.dimensions,
          measuredVolumeMm3: finalGeomStats.volumeMm3,
          polygonCount: finalGeomStats.triangleCount,
          triangleCount: finalGeomStats.triangleCount,
          vertexCount: finalGeomStats.triangleCount * 3,
          isManifold: finalGeomStats.isManifold,
          nonManifoldEdgeCount: finalGeomStats.nonManifoldEdgeCount,
          precisionScore: typeof finalScore === 'number' ? finalScore : undefined,
          semanticFeatureCount: activeFeatureModel.features.length,
          verifiedFeatureCount: activeFeatureModel.features.filter((f) => f.status === 'verified').length,
          failedFeatureCount: activeFeatureModel.features.filter((f) => f.status === 'failed').length,
          unknownFeatureCount: activeFeatureModel.features.filter((f) => f.status === 'unknown').length,
          bindingCount: Object.keys(activeFeatureModel.codeBindings || {}).length,
          boundFeatureCount: activeFeatureModel.bindingValidation?.boundFeatures.length ?? 0,
          builderBoundFeatureCount: activeFeatureModel.bindingValidation?.builderBoundFeatures.length ?? 0,
          criticalUnboundParameterCount: activeFeatureModel.bindingValidation?.criticalUnboundParameters.length ?? 0,
          missingBuilderFeatureCount: activeFeatureModel.bindingValidation?.missingBuilderFeatures.length ?? 0,
          unusedFeatureWrapperCount: activeFeatureModel.bindingValidation?.unboundFeatures.length ?? 0,
          featureModelVersion: activeFeatureModel.schemaVersion,
        });

        setGenerationDiagnostics(diag);

        const cleanPrompt = inferProjectName(promptText, spec);
        setModelName(cleanPrompt);
        setEditableTitle(cleanPrompt);
        setPipelineStage('completed');

        // Persist to project version history
        await recordNewVersion(
          currentCode,
          newGeom,
          promptText,
          'Precision CAD synthesis with full multi-view verification',
          'INITIAL_GENERATION',
          finalScore,
          spec,
          finalChecklist,
          finalReview,
          undefined,
          options?.targetProject,
          activeFeatureModel
        );
      } else {
        // Fast Mode Flow
        const spec = buildDesignSpecification(promptText, reqs);
        setDesignSpecification(spec);

        const plannedFeatureModel = planSemanticFeatureModel(spec, promptText);
        const checklist = generateDesignChecklist(spec);
        setDesignChecklist(checklist);

        setPipelineStage('generating_cad');
        const result = await requestJscadGeneration(promptText, {
          requirements: reqs,
          userOverrides,
          featureModel: plannedFeatureModel,
          designSpecification: spec,
          designChecklist: checklist,
          simplifyToParametric: options?.simplifyToParametric,
          mode: 'fast',
          referenceImages: activeProjRefImages,
        });
        if (result.diagnostics?.requestRecords) {
          aiRecords.push(...result.diagnostics.requestRecords);
        }

        setPipelineStage('executing_geometry');
        const executed = executeJscadModel(result.code);
        const newGeom = executed.combinedGeometry;
        setCurrentParts(executed.parts || []);
        setCurrentJscadCode(result.code);
        setActiveGeometry(newGeom);
        setActiveGeometryGenerationId(thisGenId);
        setLastGenerationStatus('success');
        setCadSource(result.source);
        setGenerationId(result.generationId || thisGenId);

        const finalFastGeomStats = analyzeBufferGeometry(newGeom, selectedFilament.densityGcm3);
        const finalFastFeatureModel = finalizeFeatureModelForCode(
          plannedFeatureModel,
          result.code,
          finalFastGeomStats,
          'strict'
        );

        const fastTotalDuration = Date.now() - pipelineStartTime;
        const fastDiag = buildGenerationDiagnostics({
          generationId: result.generationId || thisGenId,
          timestamp: Date.now(),
          mode: 'fast',
          requestRecords: aiRecords,
          repairAttempts: result.diagnostics?.repairAttempts || 0,
          latencyMs: fastTotalDuration,
          totalDurationMs: fastTotalDuration,
          status: 'success',
          geometryMeasurements: finalFastGeomStats,
          measuredDimensions: finalFastGeomStats.dimensions,
          measuredVolumeMm3: finalFastGeomStats.volumeMm3,
          polygonCount: finalFastGeomStats.triangleCount,
          triangleCount: finalFastGeomStats.triangleCount,
          vertexCount: finalFastGeomStats.triangleCount * 3,
          isManifold: finalFastGeomStats.isManifold,
          nonManifoldEdgeCount: finalFastGeomStats.nonManifoldEdgeCount,
          semanticFeatureCount: finalFastFeatureModel.features.length,
          verifiedFeatureCount: finalFastFeatureModel.features.filter((f) => f.status === 'verified').length,
          failedFeatureCount: finalFastFeatureModel.features.filter((f) => f.status === 'failed').length,
          unknownFeatureCount: finalFastFeatureModel.features.filter((f) => f.status === 'unknown').length,
          bindingCount: Object.keys(finalFastFeatureModel.codeBindings || {}).length,
          boundFeatureCount: finalFastFeatureModel.bindingValidation?.boundFeatures.length ?? 0,
          builderBoundFeatureCount: finalFastFeatureModel.bindingValidation?.builderBoundFeatures.length ?? 0,
          criticalUnboundParameterCount: finalFastFeatureModel.bindingValidation?.criticalUnboundParameters.length ?? 0,
          missingBuilderFeatureCount: finalFastFeatureModel.bindingValidation?.missingBuilderFeatures.length ?? 0,
          unusedFeatureWrapperCount: finalFastFeatureModel.bindingValidation?.unboundFeatures.length ?? 0,
          featureModelVersion: finalFastFeatureModel.schemaVersion,
        });

        setGenerationDiagnostics(fastDiag);
        setGenerationError(null);

        if (result.validationReport) setValidationReport(result.validationReport);

        const cleanPrompt = inferProjectName(promptText);
        setModelName(cleanPrompt);
        setEditableTitle(cleanPrompt);
        setPipelineStage('completed');

        await recordNewVersion(
          result.code,
          newGeom,
          promptText,
          'Fast generative CAD model',
          'INITIAL_GENERATION',
          null,
          spec,
          undefined,
          undefined,
          undefined,
          options?.targetProject,
          finalFastFeatureModel
        );
      }
    } catch (err: any) {
      console.error('CAD generation failed:', err);
      setPipelineStage('error');
      setLastGenerationStatus('error');
      const userMsg = mapApiErrorMessage(err, (err as any)?.status);
      setCadErrorMessage(userMsg);
      setGenerationError({
        error: userMsg,
        errorCategory: err.errorCategory || 'UNKNOWN_ERROR',
        technicalDetails: err.technicalDetails || err.message,
        statusCode: err.status,
        canSimplifyToParametric: err.canSimplifyToParametric,
        requirements: err.requirements,
      });
      if (err.diagnostics || err.raw?.diagnostics) {
        setGenerationDiagnostics(err.diagnostics || err.raw.diagnostics);
      }
    } finally {
      setIsGeneratingCad(false);
    }
  };

  // Generate JSCAD (Initial or Brand New Prompt)
  const handleGenerateJscad = async (
    promptText: string,
    options?: {
      useTemplate?: boolean;
      simplifyToParametric?: boolean;
      mode?: GenerationMode;
      targetProject?: KatPrintProject;
      bypassSpecReview?: boolean;
      exploreApproaches?: boolean;
    }
  ) => {
    const thisGenId = `gen_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    setCurrentGenerationId(thisGenId);
    setLastGenerationStatus('generating');
    setIsGeneratingCad(true);
    setCadErrorMessage(null);
    setGenerationError(null);
    setLastPrompt(promptText);
    setSlicerExplanation(null);
    setRepairAttempt(1);

    try {
      const activeProjRefImages = (options?.targetProject || activeProject)?.referenceImages;

      if (options?.useTemplate) {
        setPipelineStage('generating_cad');
        const result = await requestJscadGeneration(promptText, {
          useTemplate: true,
          mode: 'fast',
          referenceImages: activeProjRefImages,
        });
        const executed = executeJscadModel(result.code);
        const newGeom = executed.combinedGeometry;
        setCurrentParts(executed.parts || []);
        setCurrentJscadCode(result.code);
        setActiveGeometry(newGeom);
        setActiveGeometryGenerationId(thisGenId);
        setLastGenerationStatus('success');
        setCadSource('template');
        setGenerationId(result.generationId || thisGenId);
        setGenerationDiagnostics(result.diagnostics || null);
        setValidationReport(result.validationReport || null);
        const name = `Template — ${inferProjectName(promptText)}`;
        setModelName(name);
        setPipelineStage('completed');

        await recordNewVersion(
          result.code,
          newGeom,
          promptText,
          'Generated from parametric template library',
          'INITIAL_GENERATION',
          null,
          undefined,
          undefined,
          undefined,
          undefined,
          options?.targetProject
        );
        return;
      }

      // Step 1: Understanding Design Intent & Requirements Extraction
      setPipelineStage('understanding_design');
      const extractionRes = await extractPromptRequirements(promptText, activeProjRefImages);
      const reqs = extractionRes.requirements;
      setExtractedRequirements(reqs);

      const aiRecords: AIRequestRecord[] = [];
      if (extractionRes.diagnostics?.requestRecords) {
        aiRecords.push(...extractionRes.diagnostics.requestRecords);
      }

      // If spec review is enabled and not bypassed, halt here for user inspection
      if (!skipSpecReview && !options?.bypassSpecReview) {
        setPipelineStage('review_spec');
        setIsGeneratingCad(false);
        setIsReviewingSpec(true);
        setPendingSpecPrompt(promptText);
        setPendingSpecOptions(options);
        return;
      }

      // Auto-advance directly if skipSpecReview is ON
      const shouldExplore = options?.exploreApproaches ?? exploreApproaches;
      if (shouldExplore) {
        await triggerConceptVariantStage(promptText, reqs, reqs.userOverrides || [], options, aiRecords);
      } else {
        await executeCadGenerationPipeline(promptText, reqs, reqs.userOverrides || [], options, aiRecords);
      }
    } catch (err: any) {
      console.error('CAD requirements extraction failed:', err);
      setPipelineStage('error');
      setLastGenerationStatus('error');
      const userMsg = mapApiErrorMessage(err, (err as any)?.status);
      setCadErrorMessage(userMsg);
      setGenerationError({
        error: userMsg,
        errorCategory: err.errorCategory || 'UNKNOWN_ERROR',
        technicalDetails: err.technicalDetails || err.message,
        statusCode: err.status,
        canSimplifyToParametric: err.canSimplifyToParametric,
        requirements: err.requirements,
      });
      if (err.diagnostics || err.raw?.diagnostics) {
        setGenerationDiagnostics(err.diagnostics || err.raw.diagnostics);
      }
      setIsGeneratingCad(false);
    }
  };

  const triggerConceptVariantStage = async (
    promptText: string,
    reqs: ExtractedRequirements,
    userOverrides: string[] = [],
    options?: any,
    priorAiRecords: AIRequestRecord[] = []
  ) => {
    const activeProjRefImages = (options?.targetProject || activeProject)?.referenceImages;
    const cacheKey = `${promptText.trim().toLowerCase()}:::${reqs.objectName || ''}:::${reqs.overallDimensions?.width || 0}x${reqs.overallDimensions?.depth || 0}x${reqs.overallDimensions?.height || 0}:::${reqs.wallThicknessMm || 0}`;

    const existingProject = options?.targetProject || activeProject;
    const cached = existingProject?.conceptCache?.[cacheKey];

    setPendingConceptPrompt(promptText);
    setPendingConceptReqs(reqs);
    setPendingConceptUserOverrides(userOverrides);
    setPendingConceptOptions(options);
    setPendingConceptAiRecords(priorAiRecords);
    setIsReviewingSpec(false);

    if (cached && Array.isArray(cached) && cached.length > 0) {
      setConceptVariants(cached);
      setIsSelectingConcept(true);
      setPipelineStage('choose_approach');
      setIsGeneratingCad(false);
      return;
    }

    // Fetch from /api/generate-concepts
    setPipelineStage('choose_approach');
    setIsGeneratingCad(true);
    try {
      const res = await requestConceptVariants({
        prompt: promptText,
        requirements: reqs,
        referenceImages: activeProjRefImages,
      });

      if (res.diagnostics?.requestRecords) {
        priorAiRecords.push(...res.diagnostics.requestRecords);
      }

      if (res.concepts && Array.isArray(res.concepts) && res.concepts.length > 0) {
        // Save in conceptCache
        if (existingProject) {
          const updatedCache = {
            ...(existingProject.conceptCache || {}),
            [cacheKey]: res.concepts,
          };
          const updatedProject = {
            ...existingProject,
            conceptCache: updatedCache,
          };
          await persistActiveProject(updatedProject);
        }

        setConceptVariants(res.concepts);
        setIsSelectingConcept(true);
        setIsGeneratingCad(false);
        return;
      }
    } catch (conceptErr) {
      console.warn('Concept variant generation failed or was skipped, proceeding to direct CAD synthesis:', conceptErr);
    }

    // Fall back silently to direct CAD generation
    setIsSelectingConcept(false);
    await executeCadGenerationPipeline(promptText, reqs, userOverrides, options, priorAiRecords);
  };

  const handleSelectConcept = async (concept: DesignConcept) => {
    const baseReqs = pendingConceptReqs || extractedRequirements;
    if (!baseReqs) return;

    const mergedReqs: ExtractedRequirements = {
      ...baseReqs,
      ...(concept.specPatch || {}),
      designPlan: {
        ...(baseReqs.designPlan || {}),
        ...(concept.specPatch?.designPlan || {}),
        keyFeatures: [
          ...(concept.keyFeatures || []),
          ...(concept.specPatch?.designPlan?.keyFeatures || []),
        ],
      },
      functionalRequirements: [
        ...(baseReqs.functionalRequirements || []),
        ...(concept.specPatch?.functionalRequirements || []),
      ],
    };

    const updatedOverrides = [
      ...pendingConceptUserOverrides,
      `SELECTED STRATEGY: ${concept.name}. ${concept.approach}`,
      ...concept.keyFeatures.map((f) => `Feature constraint: ${f}`),
    ];

    setIsSelectingConcept(false);
    setExtractedRequirements(mergedReqs);
    await executeCadGenerationPipeline(
      pendingConceptPrompt,
      mergedReqs,
      updatedOverrides,
      pendingConceptOptions,
      pendingConceptAiRecords
    );
  };

  const handleCustomApproach = async (customDirectives: string) => {
    const baseReqs = pendingConceptReqs || extractedRequirements;
    if (!baseReqs) return;

    const updatedOverrides = [
      ...pendingConceptUserOverrides,
      `AUTHORITATIVE USER STRATEGY DIRECTIVE: ${customDirectives}`,
    ];

    setIsSelectingConcept(false);
    await executeCadGenerationPipeline(
      pendingConceptPrompt,
      baseReqs,
      updatedOverrides,
      pendingConceptOptions,
      pendingConceptAiRecords
    );
  };

  const handleSkipConceptSelection = async () => {
    const baseReqs = pendingConceptReqs || extractedRequirements;
    if (!baseReqs) return;

    setIsSelectingConcept(false);
    await executeCadGenerationPipeline(
      pendingConceptPrompt,
      baseReqs,
      pendingConceptUserOverrides,
      pendingConceptOptions,
      pendingConceptAiRecords
    );
  };

  const handleConfirmSpecAndGenerate = async (
    updatedReqs: ExtractedRequirements,
    userOverrides: string[]
  ) => {
    const promptToUse = pendingSpecPrompt || lastPrompt;
    const optionsToUse = pendingSpecOptions;
    const shouldExplore = optionsToUse?.exploreApproaches ?? exploreApproaches;

    if (shouldExplore) {
      await triggerConceptVariantStage(promptToUse, updatedReqs, userOverrides, optionsToUse);
    } else {
      setIsReviewingSpec(false);
      await executeCadGenerationPipeline(promptToUse, updatedReqs, userOverrides, optionsToUse);
    }
  };

  const handleRegenerateSpec = async (
    updatedPrompt: string,
    updatedReqs: ExtractedRequirements,
    userOverrides: string[]
  ) => {
    setIsRegeneratingSpec(true);
    setPipelineStage('understanding_design');
    try {
      const activeProjRefImages = activeProject?.referenceImages;
      const extractionRes = await extractPromptRequirements(updatedPrompt, activeProjRefImages);
      const refreshedReqs = extractionRes.requirements;
      refreshedReqs.userOverrides = Array.from(new Set([...(refreshedReqs.userOverrides || []), ...userOverrides]));
      setExtractedRequirements(refreshedReqs);
      setLastPrompt(updatedPrompt);
      setPendingSpecPrompt(updatedPrompt);
      setPipelineStage('review_spec');
      setIsReviewingSpec(true);
    } catch (err: any) {
      console.error('Failed to regenerate spec:', err);
      setPipelineStage('error');
      const userMsg = mapApiErrorMessage(err, (err as any)?.status);
      setCadErrorMessage(userMsg);
    } finally {
      setIsRegeneratingSpec(false);
    }
  };

  // Conversational Multi-Turn Revision Workflow
  const handleConversationalRevision = async (instruction: string) => {
    if (!activeProject) return;

    if (viewingVersionId && viewingVersionId !== activeProject.currentVersionId) {
      alert('Cannot modify historical versions directly. Please return to head or restore this version first.');
      return;
    }

    // Check if user is asking to review changes first (default false for explicit user consent)
    const autoApply = activeProject.projectSettings?.autoApplyProposedChanges ?? false;

    if (!autoApply) {
      // Generate proposed changes for user review
      const currentVer = currentActiveVersion;
      if (currentVer) {
        const changeSet = parseRevisionInstruction(instruction, currentVer, activeProject);
        setProposedChangeSet(changeSet);
        setPendingRevisionInstruction(instruction);
        return;
      }
    }

    await executeDirectRevision(instruction);
  };

  const handleFixMissingFeatures = async (missingFeatures: string[]) => {
    if (!activeProject || missingFeatures.length === 0) return;
    if (viewingVersionId && viewingVersionId !== activeProject.currentVersionId) {
      alert('Cannot modify historical versions directly. Please return to head or restore this version first.');
      return;
    }
    setIsFixingFeatures(true);
    try {
      await handleConversationalRevision(`Add the missing required features: ${missingFeatures.join(', ')}`);
    } finally {
      setIsFixingFeatures(false);
    }
  };

  // Execute Direct Revision
  const executeDirectRevision = async (instruction: string) => {
    if (!activeProject) return;

    setIsRevisingCad(true);
    setCadErrorMessage(null);
    setGenerationError(null);
    setPipelineStage('generating_cad');

    try {
      const outcome = await applyRevisionToProject({
        project: activeProject,
        instruction,
        currentCode: currentJscadCode,
        selectedFilamentDensity: selectedFilament.densityGcm3,
        selectedFeatureIds: selectedFeatureIds.length > 0 ? selectedFeatureIds : selectedFeatureId ? [selectedFeatureId] : undefined,
      });

      // Update 3D Geometry and set active head identity
      const geomRes = activateVersionGeometry(outcome.newVersion, { head: true });
      if (!geomRes.success) {
        setLastGenerationStatus('error');
      }

      // Update Active Project state and persist to IndexedDB
      await persistActiveProject(outcome.updatedProject);
      setViewingVersionId(null);
      setPipelineStage('completed');
    } catch (err: any) {
      console.error('Revision error:', err);
      setPipelineStage('error');
      setLastGenerationStatus('error');
      const userMsg = mapApiErrorMessage(err, (err as any)?.status);
      setCadErrorMessage(userMsg);
      setGenerationError({
        error: userMsg,
        errorCategory: err.errorCategory || 'UNKNOWN_ERROR',
        technicalDetails: err.technicalDetails || err.message,
        statusCode: err.status,
      });
    } finally {
      setIsRevisingCad(false);
    }
  };

  // Handle Natural Language Undo / Rollback
  const handleRollbackLastRevision = async () => {
    if (!activeProject || !activeProject.versions || activeProject.versions.length <= 1) return;
    const prevVersion = activeProject.versions[activeProject.versions.length - 2];
    if (!prevVersion) return;

    await handleRestoreVersion(prevVersion);
  };

  // Handle Direct 3D Manipulation Commits (dragging gizmos, hole dragging, spacing adjustments)
  const handleManipulationCommit = async (params: {
    featureId: string;
    featureIds?: string[];
    manipulatorId: string;
    manipulatorType: ManipulatorType;
    parameterChanges: Array<{
      parameterId: string;
      newValue: number | string | boolean;
      oldValue?: number | string | boolean;
      unit?: string;
    }>;
    instructionSummary?: string;
  }) => {
    if (!activeProject) return;
    if (viewingVersionId && viewingVersionId !== activeProject.currentVersionId) {
      alert('Cannot modify historical versions directly. Please return to head or restore this version first.');
      return;
    }

    try {
      let opType: SemanticRevisionOpType = 'SET_PARAMETER';
      if (params.manipulatorType === 'POSITION') opType = 'MOVE_FEATURE';
      else if (['RADIUS', 'DIAMETER', 'WIDTH', 'LENGTH', 'HEIGHT', 'DEPTH', 'THICKNESS'].includes(params.manipulatorType)) {
        opType = 'RESIZE_FEATURE';
      }

      const outcome = await applyBoundParameterChangesToProject({
        project: activeProject,
        updates: params.parameterChanges.map((pc) => ({
          parameterId: pc.parameterId,
          newValue: pc.newValue,
        })),
        selectedFilamentDensity: selectedFilament.densityGcm3,
        operationType: opType,
        customSummary: params.instructionSummary || `Direct manipulation of ${params.featureId}`,
        featureIds: params.featureIds || [params.featureId],
        manipulatorType: params.manipulatorType,
      });

      const geomRes = activateVersionGeometry(outcome.newVersion, { head: true });
      if (!geomRes.success) {
        setLastGenerationStatus('error');
      }

      await persistActiveProject(outcome.updatedProject);
      setViewingVersionId(null);
    } catch (err: any) {
      console.error('Manipulation commit error:', err);
      alert(`Direct manipulation failed: ${err.message || err}`);
    }
  };

  // Restore previous version (Non-destructive new head)
  const handleRestoreVersion = async (version: ModelVersion) => {
    if (!activeProject || !activeProject.versions) return;
    try {
      const updatedVersions = restoreVersionAsNewHead(activeProject.versions, version.id);
      const newHead = updatedVersions.find((v) => v.isCurrentHead)!;

      activateVersionGeometry(newHead, { head: true });

      const restoreMsg: DesignConversationMessage = {
        id: `msg_restore_${Date.now()}`,
        projectId: activeProject.id,
        role: 'system',
        content: `Restored to **V${version.versionNumber}** (${version.label}) as new head version **V${newHead.versionNumber}**.`,
        timestamp: new Date().toISOString(),
        relatedVersionId: newHead.id,
        versionId: newHead.id,
      };

      const updatedProj: KatPrintProject = {
        ...activeProject,
        currentVersionId: newHead.id,
        versions: updatedVersions,
        conversation: [...(activeProject.conversation || []), restoreMsg],
        thumbnail: newHead.thumbnail || activeProject.thumbnail,
        projectMemory: updateProjectMemoryFromVersion(activeProject.projectMemory, newHead, `Restore V${newHead.versionNumber}`),
        updatedAt: new Date().toISOString(),
      };

      await persistActiveProject(updatedProj);
      setViewingVersionId(null);
    } catch (err: any) {
      console.error('Failed to restore version:', err);
    }
  };

  // Branch new version from an existing version
  const handleBranchVersion = async (version: ModelVersion) => {
    if (!activeProject || !activeProject.versions) return;
    try {
      const updatedVersions = branchNewVersion(activeProject.versions, version.id, `Branch from V${version.versionNumber}`);
      const newBranch = updatedVersions.find((v) => v.isCurrentHead)!;

      activateVersionGeometry(newBranch, { head: true });

      const branchMsg: DesignConversationMessage = {
        id: `msg_branch_${Date.now()}`,
        projectId: activeProject.id,
        role: 'system',
        content: `Branched new active lineage from **V${version.versionNumber}** as **V${newBranch.versionNumber}**.`,
        timestamp: new Date().toISOString(),
        relatedVersionId: newBranch.id,
        versionId: newBranch.id,
      };

      const updatedProj: KatPrintProject = {
        ...activeProject,
        currentVersionId: newBranch.id,
        versions: updatedVersions,
        conversation: [...(activeProject.conversation || []), branchMsg],
        thumbnail: newBranch.thumbnail || activeProject.thumbnail,
        projectMemory: updateProjectMemoryFromVersion(activeProject.projectMemory, newBranch, `Branch V${newBranch.versionNumber}`),
        updatedAt: new Date().toISOString(),
      };

      await persistActiveProject(updatedProj);
      setViewingVersionId(null);
    } catch (err: any) {
      console.error('Failed to branch version:', err);
    }
  };

  // Return to Head version
  const handleReturnToHead = useCallback(() => {
    setViewingVersionId(null);
    if (!activeProject || !activeProject.versions) return;
    const head =
      activeProject.versions.find((v) => v.id === activeProject.currentVersionId) ||
      activeProject.versions[activeProject.versions.length - 1];
    if (head) {
      activateVersionGeometry(head, { head: true });
    }
  }, [activeProject, activateVersionGeometry]);

  // Inspect previous version in 3D viewer without changing head
  const handleSelectVersionForViewing = (version: ModelVersion) => {
    setViewingVersionId(version.id);
    activateVersionGeometry(version, { head: false });
  };

  // Version Comparison modal
  const handleCompareVersions = (versionA: ModelVersion, versionB: ModelVersion) => {
    setCompareVersionA(versionA);
    setCompareVersionB(versionB);
    setIsComparisonModalOpen(true);
  };

  // Rename a specific version's label
  const handleRenameVersionLabel = async (versionId: string, newLabel: string) => {
    if (!activeProject || !activeProject.versions) return;
    const updatedVersions = activeProject.versions.map((v) =>
      v.id === versionId ? { ...v, label: newLabel.trim() || v.label } : v
    );
    const updatedProj: KatPrintProject = {
      ...activeProject,
      versions: updatedVersions,
      updatedAt: new Date().toISOString(),
    };
    await persistActiveProject(updatedProj);
  };

  // Export STL for a specific version in timeline
  const handleExportVersionStl = (version: ModelVersion) => {
    if (!activeProject) return;
    const script = version.cadCode;
    if (!script) {
      alert('No CAD script available for this version.');
      return;
    }
    try {
      const executed = executeJscadModel(script);
      const geom = executed.combinedGeometry;
      const stats = analyzeBufferGeometry(geom, selectedFilament.densityGcm3);
      if (stats.triangleCount <= 0 && (!executed.parts || executed.parts.length === 0)) {
        alert(`Cannot export V${version.versionNumber}: Model geometry has no mesh triangles.`);
        return;
      }
      const filename = sanitizeStlFilename(activeProject.name, version.versionNumber);
      downloadExportSTL(geom, executed.parts, filename, scaleFactor);
    } catch (err: any) {
      alert(`Failed to export version STL: ${err?.message || 'Geometry error'}`);
    }
  };

  // View diagnostics & fidelity details for a specific version
  const handleViewVersionDiagnostics = (version: ModelVersion) => {
    if (version.generationDiagnostics) {
      setGenerationDiagnostics(version.generationDiagnostics);
    }
    if (version.fidelityReview) {
      setFidelityReviewResult(version.fidelityReview);
    }
    if (version.designSpecification) {
      setDesignSpecification(version.designSpecification);
    }
    if (version.designChecklist) {
      setDesignChecklist(version.designChecklist);
    }
    handleSelectVersionForViewing(version);
    setRightPanelTab('print');
  };

  // Create brand new project from user prompt
  const handleCreateNewProject = async (prompt: string, customName?: string) => {
    const promptText = prompt.trim() || '100 mm × 60 mm × 25 mm electronics enclosure with 3 mm walls and removable top lid';
    const newProj = createDefaultProject(promptText);
    if (customName && customName.trim()) {
      newProj.name = customName.trim();
    }

    await projectRepository.saveProject(newProj);
    const all = await projectRepository.listProjects();
    setProjects(all);
    activateProject(newProj);
    setNavView('workspace');

    // Generate initial CAD for the new project passing targetProject directly to avoid race conditions
    handleGenerateJscad(promptText, {
      mode: newProj.projectSettings?.generationMode || 'precision',
      targetProject: newProj,
    });
  };

  // Create empty / blank project without initial AI generation
  const handleCreateBlankProject = async (customName?: string) => {
    const blank = createBlankProject(customName || 'Untitled Project', {
      printerId: selectedPrinterId,
      filamentId: selectedFilamentId,
      scaleFactor,
      mustHoldLiquid,
    });

    await projectRepository.saveProject(blank);
    const all = await projectRepository.listProjects();
    setProjects(all);
    activateProject(blank);
    setNavView('workspace');
  };

  // Select project from library
  const handleSelectProject = (project: KatPrintProject) => {
    if (!project) return;
    activateProject(project);
    setNavView('workspace');
  };

  // Update printer and persist to project settings
  const handlePrinterChange = async (printerId: string) => {
    setSelectedPrinterId(printerId);
    if (activeProject) {
      const updated: KatPrintProject = {
        ...activeProject,
        projectSettings: {
          ...activeProject.projectSettings,
          printerId,
        },
        updatedAt: new Date().toISOString(),
      };
      await persistActiveProject(updated);
    }
  };

  // Update filament and persist to project settings
  const handleFilamentChange = async (filamentId: string) => {
    setSelectedFilamentId(filamentId);
    if (activeProject) {
      const updated: KatPrintProject = {
        ...activeProject,
        projectSettings: {
          ...activeProject.projectSettings,
          filamentId,
        },
        updatedAt: new Date().toISOString(),
      };
      await persistActiveProject(updated);
    }
  };

  // Update scale factor and persist to project settings
  const handleScaleFactorChange = async (scale: number) => {
    setScaleFactor(scale);
    if (activeProject) {
      const updated: KatPrintProject = {
        ...activeProject,
        projectSettings: {
          ...activeProject.projectSettings,
          scaleFactor: scale,
        },
        updatedAt: new Date().toISOString(),
      };
      await persistActiveProject(updated);
    }
  };

  // Update watertight mode and persist to project settings
  const handleMustHoldLiquidChange = async (enabled: boolean) => {
    setMustHoldLiquid(enabled);
    if (activeProject) {
      const updated: KatPrintProject = {
        ...activeProject,
        projectSettings: {
          ...activeProject.projectSettings,
          mustHoldLiquid: enabled,
        },
        updatedAt: new Date().toISOString(),
      };
      await persistActiveProject(updated);
    }
  };

  // Delete project
  const handleDeleteProject = async (target: string | KatPrintProject) => {
    const projectId = typeof target === 'string' ? target : target?.id;
    if (!projectId) return;
    await projectRepository.deleteProject(projectId);
    const remaining = await projectRepository.listProjects();
    setProjects(remaining);
    if (activeProject?.id === projectId) {
      if (remaining.length > 0) {
        activateProject(remaining[0]);
      } else {
        await handleCreateBlankProject('Untitled Project');
      }
    }
  };

  // Duplicate project
  const handleDuplicateProject = async (project: KatPrintProject) => {
    const cloned = duplicateProjectGraph(project);
    await projectRepository.createProject(cloned);
    const all = await projectRepository.listProjects();
    setProjects(all);
  };

  // Rename project
  const handleRenameProject = async (project: KatPrintProject, newName: string) => {
    const updated: KatPrintProject = {
      ...project,
      name: newName.trim() || project.name,
      updatedAt: new Date().toISOString(),
    };
    await projectRepository.updateProject(updated);
    const all = await projectRepository.listProjects();
    setProjects(all);
    if (activeProject?.id === project.id) {
      setActiveProject(updated);
      setEditableTitle(updated.name);
      setModelName(updated.name);
    }
  };

  // Favorite toggle
  const handleToggleFavorite = async (target: string | KatPrintProject) => {
    const projectId = typeof target === 'string' ? target : target?.id;
    if (!projectId) return;
    const proj = projects.find((p) => p.id === projectId);
    if (!proj) return;
    const isFav = !proj.isFavorite;
    const updated: KatPrintProject = {
      ...proj,
      isFavorite: isFav,
      updatedAt: new Date().toISOString(),
    };
    await projectRepository.updateProject(updated);
    const all = await projectRepository.listProjects();
    setProjects(all);
    if (activeProject?.id === projectId) {
      setActiveProject(updated);
    }
  };

  // Export .katprint project package
  const handleExportKatPrint = (proj?: KatPrintProject) => {
    const target = proj || activeProject;
    if (!target) return;
    exportProjectPackage(target);
  };

  // Import .katprint project package
  const handleImportKatPrint = async (fileContent: string) => {
    try {
      const imported = await projectRepository.importProjectFile(fileContent);
      const all = await projectRepository.listProjects();
      setProjects(all);
      activateProject(imported);
      setNavView('workspace');
    } catch (err: any) {
      alert(`Could not import project package: ${err?.message || 'Invalid format'}`);
    }
  };

  // Save renamed title
  const handleSaveTitle = async () => {
    if (!activeProject || !editableTitle.trim()) {
      setIsEditingTitle(false);
      return;
    }
    const updated: KatPrintProject = {
      ...activeProject,
      name: editableTitle.trim(),
      updatedAt: new Date().toISOString(),
    };
    await persistActiveProject(updated);
    setModelName(editableTitle.trim());
    setIsEditingTitle(false);
  };

  // Direct Semantic Parameter Update
  const [isApplyingParameter, setIsApplyingParameter] = useState(false);

  const handleUpdateFeatureParameter = async (
    parameterId: string,
    newValue: number | string | boolean
  ) => {
    if (!activeProject) return;
    setIsApplyingParameter(true);
    try {
      const outcome = await applyDirectParameterUpdateToProject({
        project: activeProject,
        parameterId,
        newValue,
        selectedFilamentDensity: selectedFilament.densityGcm3,
      });

      await persistActiveProject(outcome.updatedProject);
      const newHead = outcome.newVersion;
      activateVersionGeometry(newHead, { head: true });
    } catch (err: any) {
      console.error('Failed to apply direct parameter update:', err);
      setCadErrorMessage(err?.message || 'Failed to update feature parameter.');
    } finally {
      setIsApplyingParameter(false);
    }
  };

  // Reconstruct Feature Model for Legacy Versions
  const handleReconstructFeatureModel = async () => {
    if (!activeProject || !currentActiveVersion) return;
    const { model } = reconstructLegacyFeatureModel(
      currentActiveVersion.cadCode || currentJscadCode,
      currentActiveVersion.prompt || activeProject.originalPrompt || '',
      currentActiveVersion.designSpecification,
      currentActiveVersion.geometryMetadata
    );

    const verified = verifySemanticFeatureModel(
      model,
      geometryStats,
      currentActiveVersion.cadCode || currentJscadCode
    ).updatedModel;

    const updatedVersions = activeProject.versions.map((v) =>
      v.id === currentActiveVersion.id ? { ...v, featureModel: verified } : v
    );

    const updatedProj: KatPrintProject = {
      ...activeProject,
      versions: updatedVersions,
      updatedAt: new Date().toISOString(),
    };

    await persistActiveProject(updatedProj);
  };

  // Toggle Parameter Lock
  const handleToggleLockParameter = async (parameterId: string, currentLocked: boolean) => {
    if (!activeProject || !currentActiveVersion || !currentActiveVersion.featureModel) return;
    const updatedModel = toggleParameterLock(currentActiveVersion.featureModel, parameterId, !currentLocked);

    const updatedVersions = activeProject.versions.map((v) =>
      v.id === currentActiveVersion.id ? { ...v, featureModel: updatedModel } : v
    );

    const updatedProj: KatPrintProject = {
      ...activeProject,
      versions: updatedVersions,
      updatedAt: new Date().toISOString(),
    };

    await persistActiveProject(updatedProj);
  };

  // Code editor update
  const handleCodeUpdate = useCallback((newCode: string) => {
    const thisGenId = `gen_manual_${Date.now()}`;
    setCurrentGenerationId(thisGenId);
    setCurrentJscadCode(newCode);
    try {
      const executed = executeJscadModel(newCode);
      setActiveGeometry(executed.combinedGeometry);
      setCurrentParts(executed.parts || []);
      setActiveGeometryGenerationId(thisGenId);
      setLastGenerationStatus('success');
      setCadErrorMessage(null);
    } catch (err: any) {
      setLastGenerationStatus('error');
      setCadErrorMessage(err?.message || 'Syntax error in JSCAD script.');
    }
  }, []);

  // Update Reference Images for Active Project
  const handleUpdateReferenceImages = async (images: ProjectReferenceImage[]) => {
    if (!activeProject) return;
    const updated: KatPrintProject = {
      ...activeProject,
      referenceImages: images,
      updatedAt: new Date().toISOString(),
    };
    await persistActiveProject(updated);
  };

  // Mode 2 & Mode 3 outputs
  const handleExternalGeometry = useCallback((geom: THREE.BufferGeometry) => {
    const thisGenId = `gen_ext_${Date.now()}`;
    setCurrentGenerationId(thisGenId);
    setActiveGeometry(geom);
    setActiveGeometryGenerationId(thisGenId);
    setLastGenerationStatus('success');
    setSlicerExplanation(null);
  }, []);

  // Slicer settings explanation
  const handleExplainSlicerSettings = async () => {
    setIsExplainingSlicer(true);
    try {
      const explanation = await requestSlicerExplanation({
        settings: slicerSettings,
        geometry: geometryStats,
        printer: selectedPrinter,
        filament: selectedFilament,
        mustHoldLiquid,
        printabilityReport,
      });
      setSlicerExplanation(explanation);
    } catch (err: any) {
      console.error('Explanation request error:', err);
      setSlicerExplanation(
        'Calculated based on volumetric flow ceilings, perimeter requirements, and cooling constraints.'
      );
    } finally {
      setIsExplainingSlicer(false);
    }
  };

  // Reorient model to optimal orientation
  const handleApplySuggestedOrientation = useCallback(async (rotDeg: [number, number, number]) => {
    const instruction = `Reorient the 3D model geometry by rotating [${rotDeg[0]}°, ${rotDeg[1]}°, ${rotDeg[2]}°] around the origin and translating so its minimum Z rests flat on the Z=0 build plate.`;
    await handleConversationalRevision(instruction);
  }, [handleConversationalRevision]);

  // Custom Printer Update
  const handleSaveCustomPrinter = (updated: PrinterSpec) => {
    setPrinters((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    setSelectedPrinterId(updated.id);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-kf-bg text-kf-text font-sans select-none overflow-hidden">
      {/* ========================================================================= */}
      {/* 1. TOP HEADER / BRAND & WORKSPACE NAVIGATION BAR */}
      {/* ========================================================================= */}
      <header className="h-14 bg-kf-panel border-b border-kf-border px-4 flex items-center justify-between shrink-0 z-40 font-sans relative">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={() => setNavView(navView === 'projects' ? 'workspace' : 'projects')}
            className="flex items-center gap-2.5 text-left cursor-pointer group"
            title={navView === 'projects' ? 'Back to Design Studio' : 'Open Projects'}
          >
            <Flower2 className="w-5 h-5 text-kf-pink shrink-0" />
            <span className="font-display font-bold text-sm tracking-[0.14em] uppercase text-kf-text">KatPrint</span>
          </button>

          <div className="h-5 w-px bg-kf-border" />

          <button
            type="button"
            onClick={() => setNavView(navView === 'projects' ? 'workspace' : 'projects')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 border border-kf-border bg-kf-panel-2 text-kf-muted hover:text-kf-text hover:border-kf-pink/50 font-mono text-[11px] transition cursor-pointer clip-corner"
          >
            {navView === 'projects' ? <Box className="w-3.5 h-3.5" /> : <FolderKanban className="w-3.5 h-3.5" />}
            <span>{navView === 'projects' ? 'Design Studio' : `Projects (${projects.length})`}</span>
          </button>

          {navView === 'workspace' && activeProject && (
            <div className="flex items-center gap-2 min-w-0">
              <div className="h-5 w-px bg-kf-border" />
              {isEditingTitle ? (
                <div className="flex items-center gap-1">
                  <input
                    type="text"
                    value={editableTitle}
                    onChange={(e) => setEditableTitle(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSaveTitle()}
                    className="bg-kf-bg border border-kf-pink px-2 py-1 text-xs font-mono text-kf-text focus:outline-none clip-corner"
                    autoFocus
                  />
                  <button type="button" onClick={handleSaveTitle} className="text-kf-ok p-1"><Check className="w-3.5 h-3.5" /></button>
                  <button
                    type="button"
                    onClick={() => { setEditableTitle(activeProject.name); setIsEditingTitle(false); }}
                    className="text-kf-muted hover:text-kf-text p-1"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsEditingTitle(true)}
                  className="flex items-center gap-1.5 min-w-0 group cursor-pointer"
                  title="Rename project"
                >
                  <span className="font-semibold text-xs text-kf-text max-w-[240px] truncate">{activeProject.name}</span>
                  <Edit2 className="w-3 h-3 text-kf-muted group-hover:text-kf-pink transition opacity-0 group-hover:opacity-100" />
                </button>
              )}

              {currentActiveVersion && (
                <span className="px-1.5 py-0.5 bg-kf-pink/10 text-kf-pink border border-kf-pink/30 font-mono text-[9px] font-bold">
                  V{currentActiveVersion.versionNumber}
                </span>
              )}

              <span className="text-[10px] font-mono text-kf-muted flex items-center gap-1">
                <span className={`w-1.5 h-1.5 ${saveStatus === 'saved' ? 'bg-kf-ok' : saveStatus === 'saving' ? 'bg-kf-warn animate-pulse' : 'bg-kf-fail'}`} />
                {saveStatus === 'saved' ? 'Saved' : saveStatus === 'saving' ? 'Saving' : 'Sync Error'}
              </span>
            </div>
          )}
        </div>

        {navView === 'workspace' && (
          <div className="flex items-center gap-2">
            <button
              type="button"
              id="btn-header-export-stl"
              disabled={!exportValidation.allowed || stlExportProgress !== null}
              title={stlExportProgress !== null ? `Generating STL (${stlExportProgress}%)` : exportValidation.allowed ? 'Download printable STL' : exportValidation.reason}
              onClick={async () => {
                if (stlExportProgress !== null || !exportValidation.allowed || (!activeGeometry && (!currentParts || currentParts.length === 0))) return;
                const cleanName = (modelName || activeProject?.name || 'model').replace(/^TEMPLATE-/i, '').toLowerCase().replace(/[^a-z0-9_]/g, '_').slice(0, 32);
                const heightMm = ((geometryStats?.dimensions?.z || 10) * scaleFactor).toFixed(0);
                const filename = `katprint_${cleanName}_${heightMm}mm_${selectedFilament.id}`;
                setStlExportProgress(0);
                try {
                  await downloadExportSTL(activeGeometry, currentParts, filename, scaleFactor, 10, (percent) => setStlExportProgress(percent));
                } catch (err) {
                  console.error('Failed to download STL:', err);
                } finally {
                  setTimeout(() => setStlExportProgress(null), 750);
                }
              }}
              className={`sweep ${stlExportProgress !== null ? '' : 'sweep-idle'} clip-corner flex items-center gap-2 px-3.5 py-2 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-40 text-kf-bg font-mono text-[11px] font-bold uppercase tracking-wider transition cursor-pointer`}
            >
              {stlExportProgress !== null ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              <span>{stlExportProgress !== null ? `${stlExportProgress}%` : 'Download STL'}</span>
            </button>

            <div className="relative">
              <button
                type="button"
                onClick={() => setIsHeaderMenuOpen((v) => !v)}
                className="w-9 h-9 border border-kf-border bg-kf-panel-2 text-kf-muted hover:text-kf-pink hover:border-kf-pink/50 flex items-center justify-center transition cursor-pointer clip-corner"
                title="More tools"
              >
                <MoreHorizontal className="w-4 h-4" />
              </button>
              {isHeaderMenuOpen && (
                <div className="absolute right-0 top-11 w-52 trace clip-corner p-[1px] shadow-2xl z-50">
                  <div className="bg-kf-panel p-1.5 space-y-1">
                    <button type="button" onClick={() => { setIsTestSuiteOpen(true); setIsHeaderMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-mono text-kf-muted hover:text-kf-text hover:bg-kf-panel-2"><FlaskConical className="w-3.5 h-3.5 text-kf-pink" />Test Suite</button>
                    <button type="button" onClick={() => { setIsStorageModalOpen(true); setIsHeaderMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-mono text-kf-muted hover:text-kf-text hover:bg-kf-panel-2"><HardDrive className="w-3.5 h-3.5" />Storage & Backup</button>
                    {activeProject && <button type="button" onClick={() => { handleExportKatPrint(); setIsHeaderMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-mono text-kf-muted hover:text-kf-text hover:bg-kf-panel-2"><Package className="w-3.5 h-3.5 text-kf-pink" />Export .katprint</button>}
                    {hasMultiplePhysicalPieces(currentParts) && <button type="button" onClick={() => { setRightPanelTab('print'); setIsHeaderMenuOpen(false); }} className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-mono text-kf-muted hover:text-kf-text hover:bg-kf-panel-2"><Boxes className="w-3.5 h-3.5 text-kf-pink" />Printable Pieces ({getPhysicalPieceCount(currentParts)})</button>}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      {/* ========================================================================= */}
      {/* 2. MAIN APPLICATION CONTENT VIEW */}
      {/* ========================================================================= */}
      {navView === 'projects' ? (
        /* PROJECT LIBRARY VIEW */
        <main className="flex-1 overflow-y-auto bg-kf-bg">
          <ProjectLibrary
            projects={projects}
            activeProjectId={activeProject?.id || null}
            onOpenProject={handleSelectProject}
            onCreateProject={(prompt, name) => handleCreateNewProject(prompt, name)}
            onDeleteProject={handleDeleteProject}
            onDuplicateProject={handleDuplicateProject}
            onRenameProject={handleRenameProject}
            onToggleFavorite={handleToggleFavorite}
            onExportProject={handleExportKatPrint}
            onImportProject={handleImportKatPrint}
            onOpenStorageManager={() => setIsStorageModalOpen(true)}
          />
        </main>
      ) : (
        /* WORKSPACE 3-COLUMN LAYOUT */
        <main className="flex-1 min-h-0 flex overflow-hidden">
          {/* ------------------------------------------------------------- */}
          {/* LEFT PANEL: Machine/Filament Settings & Mode Generator */}
          {/* ------------------------------------------------------------- */}
          <section className={`relative w-[340px] ${(isReviewingSpec || isSelectingConcept) ? 'lg:w-[600px]' : ''} bg-kf-panel border-r border-kf-border flex flex-col shrink-0 overflow-hidden transition-all duration-200 ${isGeneratingCad ? 'trace-active' : ''}`}>
            <div ref={leftPanelScrollRef} className="flex-1 overflow-y-auto kf-scroll kf-scroll-stable p-3 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="section-label">Create</span>
                <div className="flex items-center border border-kf-border bg-kf-panel-2 p-0.5 clip-corner">
                  <button
                    type="button"
                    onClick={() => setMode('describe')}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 text-[10px] font-mono font-bold uppercase tracking-wider transition ${mode === 'describe' ? 'bg-kf-pink text-kf-bg' : 'text-kf-muted hover:text-kf-text'}`}
                  >
                    <Sparkles className="w-3.5 h-3.5" /> AI Design
                  </button>
                  <button
                    type="button"
                    onClick={() => setMode('image')}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 text-[10px] font-mono font-bold uppercase tracking-wider transition ${mode === 'image' ? 'bg-kf-pink text-kf-bg' : 'text-kf-muted hover:text-kf-text'}`}
                  >
                    <ImageIcon className="w-3.5 h-3.5" /> Image Relief
                  </button>
                </div>
              </div>

              {!isReviewingSpec && !isSelectingConcept && (
                <PrinterQuickSelect
                  printers={printers}
                  printerGroups={printerGroups}
                  selectedPrinterId={selectedPrinterId}
                  selectedPrinter={selectedPrinter}
                  fitResult={activeGeometry ? printerFitResult : null}
                  onPrinterChange={handlePrinterChange}
                  onOpenCustomPrinter={() => setIsCustomPrinterOpen(true)}
                  collapsed={printerCardCollapsed}
                  onToggleCollapsed={() => setPrinterCardCollapsed((c) => !c)}
                />
              )}

              {mode === 'describe' && (
                <>
                  {isReviewingSpec && extractedRequirements ? (
                    <div className="trace clip-corner p-[1px] trace-active">
                      <div className="bg-kf-panel p-3">
                        <SpecReviewPanel
                          requirements={extractedRequirements}
                          prompt={pendingSpecPrompt || lastPrompt}
                          onProceedToGeneration={(updatedReqs, userOverrides) => {
                            handleConfirmSpecAndGenerate(updatedReqs, userOverrides);
                          }}
                          onRegenerateSpec={(updatedPrompt, updatedReqs, userOverrides) => {
                            handleRegenerateSpec(updatedPrompt, updatedReqs, userOverrides);
                          }}
                          isRegenerating={isRegeneratingSpec}
                          isGenerating={isGeneratingCad}
                          skipSpecReview={skipSpecReview}
                          onToggleSkipSpecReview={handleToggleSkipSpecReview}
                        />
                      </div>
                    </div>
                  ) : isSelectingConcept && (pendingConceptReqs || extractedRequirements) ? (
                    <div className="trace clip-corner p-[1px] trace-active">
                      <div className="bg-kf-panel p-3">
                        <ConceptSelector
                          concepts={conceptVariants}
                          prompt={pendingConceptPrompt || lastPrompt}
                          baseRequirements={(pendingConceptReqs || extractedRequirements)!}
                          onSelectConcept={handleSelectConcept}
                          onCustomApproach={handleCustomApproach}
                          onSkip={handleSkipConceptSelection}
                          isGenerating={isGeneratingCad}
                        />
                      </div>
                    </div>
                  ) : (
                    <>
                      {activeProject && (
                        <button
                          type="button"
                          onClick={() => setIsReferencePhotosOpen(true)}
                          className="trace clip-corner p-[1px] text-left group"
                        >
                          <div className="bg-kf-panel-2 px-3 py-2.5 flex items-center justify-between gap-3">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <Camera className="w-4 h-4 text-kf-pink shrink-0" />
                              <div className="min-w-0">
                                <div className="text-[11px] font-mono font-bold text-kf-text uppercase tracking-wider">Reference Photos</div>
                                <div className="text-[10px] text-kf-muted truncate">
                                  {(activeProject.referenceImages?.length || 0) > 0
                                    ? `${activeProject.referenceImages?.length} attached to this design`
                                    : 'Optional visual context for Gemini'}
                                </div>
                              </div>
                            </div>
                            <span className="text-kf-pink text-lg leading-none">+</span>
                          </div>
                        </button>
                      )}

                      <div className={`trace clip-corner p-[1px] ${isGeneratingCad ? 'trace-active' : ''}`}>
                        <div className="bg-kf-panel p-3">
                          <ParametricEditor
                            currentCode={currentJscadCode}
                            onCodeChange={handleCodeUpdate}
                            onGeneratePrompt={handleGenerateJscad}
                            onRevisePrompt={handleConversationalRevision}
                            onFixMissingFeatures={handleFixMissingFeatures}
                            isGenerating={isGeneratingCad}
                            isRevising={isRevisingCad}
                            isFixing={isFixingFeatures}
                            pipelineStage={pipelineStage}
                            repairAttempt={repairAttempt}
                            errorMessage={cadErrorMessage}
                            generationError={generationError}
                            generationDiagnostics={generationDiagnostics}
                            generationMode={activeProject?.projectSettings?.generationMode || 'precision'}
                            onModeChange={handleGenerationModeChange}
                            exploreApproaches={exploreApproaches}
                            onToggleExploreApproaches={handleToggleExploreApproaches}
                            isViewingHistorical={Boolean(viewingVersionId && viewingVersionId !== activeProject?.currentVersionId)}
                            onSimplifyToParametric={(prompt) =>
                              handleGenerateJscad(prompt, {
                                simplifyToParametric: true,
                                mode: activeProject?.projectSettings?.generationMode || 'precision',
                              })
                            }
                            validationReport={validationReport}
                            extractedRequirements={extractedRequirements}
                            activePrompt={lastPrompt}
                            designSpecification={designSpecification}
                            designChecklist={designChecklist}
                            fidelityReviewResult={fidelityReviewResult}
                          />
                        </div>
                      </div>
                    </>
                  )}
                </>
              )}

              {mode === 'image' && (
                <div className="trace clip-corner p-[1px]">
                  <div className="bg-kf-panel p-3">
                    <ImageToMeshEditor onGeometryGenerated={handleExternalGeometry} />
                  </div>
                </div>
              )}
            </div>

            {/* Scroll Affordance Bottom Fade */}
            {showLeftPanelScrollFade && (
              <div
                className="pointer-events-none absolute bottom-0 left-0 right-0 h-6 bg-gradient-to-t from-kf-panel to-transparent z-20"
                aria-hidden="true"
              />
            )}
          </section>

          {/* ------------------------------------------------------------- */}
          {/* CENTER VIEWPORT: Three.js WebGL 3D Viewer */}
          {/* ------------------------------------------------------------- */}
          <section className="flex-1 relative bg-kf-bg">
            {/* Template Banner */}
            {cadSource === 'template' && (
              <div
                id="template-model-banner"
                className="absolute top-3 left-3 right-3 z-30 bg-kf-warn/20 border border-kf-warn/70 backdrop-blur-md px-4 py-2.5 rounded-lg shadow-lg flex items-center justify-between gap-3 text-kf-warn"
              >
                <div className="flex items-center gap-2.5">
                  <AlertTriangle className="w-5 h-5 text-kf-warn shrink-0" />
                  <span className="text-xs font-medium leading-snug">
                    Loaded from Parametric Template Library. To synthesize new geometry from your prompt, click Authoritative Generate.
                  </span>
                </div>
                <button
                  type="button"
                  id="btn-retry-with-ai"
                  onClick={() =>
                    handleGenerateJscad(lastPrompt, {
                      mode: activeProject?.projectSettings?.generationMode || 'precision',
                    })
                  }
                  disabled={isGeneratingCad}
                  className="shrink-0 flex items-center gap-1.5 bg-kf-warn hover:bg-kf-warn/90 text-[#140F00] font-mono text-xs font-bold px-3 py-1.5 rounded transition disabled:opacity-50 shadow-sm cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingCad ? 'animate-spin' : ''}`} />
                  <span>Generate with AI</span>
                </button>
              </div>
            )}

            {/* Viewing Older Version Banner */}
            {viewingVersionId && currentActiveVersion && (
              <div
                id="viewing-older-version-banner"
                className="absolute top-3 left-3 right-3 z-30 bg-kf-pink/20 border border-kf-pink/70 backdrop-blur-md px-4 py-2.5 rounded-lg shadow-lg flex items-center justify-between gap-3 text-kf-text"
              >
                <div className="flex items-center gap-2.5 font-mono text-xs">
                  <Eye className="w-4 h-4 text-kf-pink shrink-0" />
                  <span>
                    Viewing <strong>V{currentActiveVersion.versionNumber}</strong> ({currentActiveVersion.label})
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleRestoreVersion(currentActiveVersion)}
                    className="flex items-center gap-1 bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-mono text-xs font-bold px-3 py-1 rounded transition shadow-sm cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Restore as Head</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleReturnToHead}
                    className="px-2.5 py-1 rounded bg-kf-panel border border-kf-border text-xs text-kf-muted hover:text-kf-text cursor-pointer"
                  >
                    Return to Head
                  </button>
                </div>
              </div>
            )}

            {/* 3D WebGL Canvas */}
            <Viewer3D
              geometry={activeGeometry}
              printer={selectedPrinter}
              scaleFactor={scaleFactor}
              highlightOverhangs={highlightOverhangs}
              onToggleOverhangs={() => setHighlightOverhangs(!highlightOverhangs)}
              isGenerating={isGeneratingCad}
              referenceObject={extractedRequirements?.referenceObject}
              parts={currentParts}
              isMultiPart={hasMultiplePhysicalPieces(currentParts)}
              selectedPartId={selectedPartId}
              onSelectPart={setSelectedPartId}
              explodedOffset={explodedOffset}
              partVisibility={partVisibility}
              featureModel={currentActiveVersion?.featureModel}
              cadCode={currentActiveVersion?.cadCode || currentJscadCode}
              versionId={currentActiveVersion?.id}
              selectedFeatureId={selectedFeatureId}
              selectedFeatureIds={selectedFeatureIds}
              onSelectFeature={handleSelectFeature}
              onMultiSelectFeatures={handleMultiSelectFeatures}
              focusFeature={focusTarget}
              onFocusFeature={handleFocusFeature}
              debugShowPickProxies={debugShowPickProxies}
              onToggleDebugProxies={() => setDebugShowPickProxies(!debugShowPickProxies)}
              onManipulationCommit={handleManipulationCommit}
              isReadOnly={Boolean(viewingVersionId && viewingVersionId !== activeProject?.currentVersionId)}
            />
          </section>

          {/* ------------------------------------------------------------- */}
          {/* RIGHT PANEL: Multi-Tab Studio Panel (Revisions, History, Slicer, Code) */}
          {/* ------------------------------------------------------------- */}
          <section className={`w-[360px] h-full min-h-0 bg-kf-panel border-l border-kf-border flex flex-col shrink-0 overflow-hidden ${isRevisingCad ? 'trace-active' : ''}`} data-panel="right-sidebar">
            <div className="h-11 shrink-0 flex items-end border-b border-kf-border bg-kf-panel-2 px-2 font-mono text-[11px]">
              <button
                type="button"
                onClick={() => setRightPanelTab('design')}
                className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-3 border-b-2 uppercase tracking-wider transition ${rightPanelTab === 'design' ? 'border-kf-pink text-kf-pink font-bold' : 'border-transparent text-kf-muted hover:text-kf-text'}`}
              >
                <MessageSquare className="w-3.5 h-3.5" /> Design
              </button>
              <button
                type="button"
                onClick={() => setRightPanelTab('print')}
                className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-3 border-b-2 uppercase tracking-wider transition ${rightPanelTab === 'print' ? 'border-kf-pink text-kf-pink font-bold' : 'border-transparent text-kf-muted hover:text-kf-text'}`}
              >
                <Printer className="w-3.5 h-3.5" /> Print
                {hasMultiplePhysicalPieces(currentParts) && <span className="text-[9px] text-kf-pink">{getPhysicalPieceCount(currentParts)}</span>}
              </button>
              <button
                type="button"
                onClick={() => setRightPanelTab('versions')}
                className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-3 border-b-2 uppercase tracking-wider transition ${rightPanelTab === 'versions' ? 'border-kf-pink text-kf-pink font-bold' : 'border-transparent text-kf-muted hover:text-kf-text'}`}
              >
                <History className="w-3.5 h-3.5" /> History
              </button>
            </div>

            <div className="flex-1 min-h-0 overflow-hidden">
              {rightPanelTab === 'design' && (
                <div className="h-full flex flex-col">
                  <div className="h-10 shrink-0 flex items-center gap-1 border-b border-kf-border px-2 bg-kf-panel">
                    <button
                      type="button"
                      onClick={() => setDesignPanelMode('assistant')}
                      className={`flex-1 px-2 py-1.5 font-mono text-[10px] uppercase tracking-wider transition ${designPanelMode === 'assistant' ? 'bg-kf-pink text-kf-bg font-bold' : 'text-kf-muted hover:text-kf-text'}`}
                    >
                      Assistant
                    </button>
                    <button
                      type="button"
                      onClick={() => setDesignPanelMode('feature')}
                      className={`flex-1 px-2 py-1.5 font-mono text-[10px] uppercase tracking-wider transition ${designPanelMode === 'feature' ? 'bg-kf-pink text-kf-bg font-bold' : 'text-kf-muted hover:text-kf-text'}`}
                    >
                      Feature {selectedFeatureIds.length > 0 ? `(${selectedFeatureIds.length})` : ''}
                    </button>
                  </div>

                  <div className="flex-1 min-h-0 overflow-y-scroll overflow-x-hidden kf-scroll kf-scroll-stable overscroll-contain">
                    {designPanelMode === 'assistant' && activeProject && (
                      <ProjectConversationPanel
                        project={activeProject}
                        activeVersion={currentActiveVersion}
                        viewingVersionId={viewingVersionId}
                        selectedFeatureId={selectedFeatureId}
                        selectedFeatureIds={selectedFeatureIds}
                        onDeselectFeature={() => handleSelectFeature(null)}
                        autoApply={activeProject.projectSettings?.autoApplyProposedChanges ?? false}
                        onSendInstruction={handleConversationalRevision}
                        onUndo={handleRollbackLastRevision}
                        onSelectVersion={(vId) => {
                          const v = activeProject.versions.find((item) => item.id === vId);
                          if (v) handleSelectVersionForViewing(v);
                        }}
                        onRestoreVersion={handleRestoreVersion}
                        onBranchVersion={handleBranchVersion}
                        onReturnToCurrent={handleReturnToHead}
                        isProcessing={isRevisingCad}
                        onToggleAutoApply={async (enabled) => {
                          const updated: KatPrintProject = {
                            ...activeProject,
                            projectSettings: { ...activeProject.projectSettings, autoApplyProposedChanges: enabled },
                          };
                          await persistActiveProject(updated);
                        }}
                      />
                    )}

                    {designPanelMode === 'feature' && (
                      <div className="p-3">
                        <FeatureInspector
                          featureModel={currentActiveVersion?.featureModel}
                          cadCode={currentActiveVersion?.cadCode || currentJscadCode}
                          selectedFeatureId={selectedFeatureId}
                          selectedFeatureIds={selectedFeatureIds}
                          onSelectFeature={handleSelectFeature}
                          onFocusFeature={handleFocusFeature}
                          onUpdateParameter={handleUpdateFeatureParameter}
                          onToggleLock={handleToggleLockParameter}
                          onReconstructFeatureModel={handleReconstructFeatureModel}
                          isApplying={isApplyingParameter}
                          isReadOnly={Boolean(viewingVersionId && viewingVersionId !== activeProject?.currentVersionId)}
                        />
                      </div>
                    )}
                  </div>
                </div>
              )}

              {rightPanelTab === 'print' && (
                <div className="h-full min-h-0 overflow-y-scroll overflow-x-hidden kf-scroll kf-scroll-stable overscroll-contain p-3 pb-8 space-y-3">
                  <div className="trace clip-corner p-[1px]">
                    <div className="bg-kf-panel p-3 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="section-label">Printer & Material</span>
                        <button type="button" onClick={() => setIsCustomPrinterOpen(true)} className="font-mono text-[10px] text-kf-pink hover:text-kf-pink-hi">Configure</button>
                      </div>

                      <div className="space-y-1.5">
                        <label htmlFor="select-printer" className="text-[10px] font-mono uppercase tracking-wider text-kf-muted">Printer</label>
                        <select
                          id="select-printer"
                          value={selectedPrinterId}
                          onChange={(e) => handlePrinterChange(e.target.value)}
                          className="w-full bg-kf-panel-2 border border-kf-border px-3 py-2 text-xs font-mono text-kf-text focus:outline-none focus:border-kf-pink clip-corner"
                        >
                          {printerGroups.map(([groupName, groupPrinters]) => (
                            <optgroup key={groupName} label={groupName} className="bg-kf-panel font-bold text-kf-muted">
                              {groupPrinters.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.buildVolume.x}×{p.buildVolume.y}×{p.buildVolume.z}mm)</option>)}
                            </optgroup>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1.5">
                        <label htmlFor="select-filament" className="text-[10px] font-mono uppercase tracking-wider text-kf-muted">Material</label>
                        <select
                          id="select-filament"
                          value={selectedFilamentId}
                          onChange={(e) => handleFilamentChange(e.target.value)}
                          className="w-full bg-kf-panel-2 border border-kf-border px-3 py-2 text-xs font-mono text-kf-text focus:outline-none focus:border-kf-pink clip-corner"
                        >
                          {FILAMENTS.map((f) => <option key={f.id} value={f.id}>{f.name} · {f.densityGcm3} g/cm³</option>)}
                        </select>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleMustHoldLiquidChange(!mustHoldLiquid)}
                        className={`w-full flex items-center justify-between px-3 py-2 border font-mono text-[10px] uppercase tracking-wider transition ${mustHoldLiquid ? 'border-kf-pink bg-kf-pink/10 text-kf-pink' : 'border-kf-border bg-kf-panel-2 text-kf-muted hover:text-kf-text'}`}
                      >
                        <span className="flex items-center gap-2"><Droplets className="w-3.5 h-3.5" /> Watertight Mode</span>
                        <span>{mustHoldLiquid ? 'On' : 'Off'}</span>
                      </button>
                    </div>
                  </div>

                  {hasMultiplePhysicalPieces(currentParts) && (
                    <div className="trace clip-corner p-[1px]">
                      <div className="bg-kf-panel p-3">
                        <MultiPartManager
                          parts={currentParts}
                          assemblyDef={currentActiveVersion?.assembly}
                          projectName={activeProject?.name || 'Assembly'}
                          versionLabel={currentActiveVersion?.label}
                          selectedPartId={selectedPartId}
                          onSelectPart={setSelectedPartId}
                          partVisibility={partVisibility}
                          onTogglePartVisibility={(pId) => setPartVisibility((prev) => ({ ...prev, [pId]: prev[pId] === false ? true : false }))}
                          explodedOffset={explodedOffset}
                          onExplodedOffsetChange={setExplodedOffset}
                          scaleFactor={scaleFactor}
                          printer={selectedPrinter}
                          filament={selectedFilament}
                          onOpenPlateLayoutModal={() => setIsPlateLayoutOpen(true)}
                          onUpdatePartQuantity={(pId, qty) => setCurrentParts((prev) => prev.map((p) => (p.id === pId ? { ...p, quantity: Math.max(1, qty) } : p)))}
                        />
                      </div>
                    </div>
                  )}

                  <div className="trace clip-corner p-[1px]">
                    <div className="bg-kf-panel p-3">
                      <PrintSettingsPanel
                        geometry={activeGeometry}
                        parts={currentParts}
                        stats={geometryStats}
                        fitResult={printerFitResult}
                        settings={slicerSettings}
                        printer={selectedPrinter}
                        filament={selectedFilament}
                        scaleFactor={scaleFactor}
                        onScaleChange={handleScaleFactorChange}
                        mustHoldLiquid={mustHoldLiquid}
                        onToggleMustHoldLiquid={() => handleMustHoldLiquidChange(!mustHoldLiquid)}
                        onExplainSettings={handleExplainSlicerSettings}
                        explanation={slicerExplanation}
                        isExplaining={isExplainingSlicer}
                        onOpenMonitor={() => setIsLiveMonitorOpen(true)}
                        modelName={modelName}
                        referenceObject={extractedRequirements?.referenceObject}
                        exportValidation={exportValidation}
                        printabilityReport={printabilityReport}
                        isAnalyzingPrintability={isAnalyzingPrintability}
                        onApplyOrientation={handleApplySuggestedOrientation}
                      />
                    </div>
                  </div>
                </div>
              )}

              {rightPanelTab === 'versions' && activeProject && (
                <div className="h-full min-h-0 overflow-y-scroll overflow-x-hidden kf-scroll kf-scroll-stable overscroll-contain p-3 pb-8">
                  <VersionHistoryPanel
                    project={activeProject}
                    activeVersionId={activeProject.currentVersionId}
                    viewingVersionId={viewingVersionId}
                    onSelectVersionToView={handleSelectVersionForViewing}
                    onRestoreVersion={handleRestoreVersion}
                    onBranchVersion={handleBranchVersion}
                    onCompareVersions={handleCompareVersions}
                    onRenameVersionLabel={handleRenameVersionLabel}
                    onExportVersionStl={handleExportVersionStl}
                    onViewDiagnostics={handleViewVersionDiagnostics}
                  />
                </div>
              )}
            </div>
          </section>
        </main>
      )}

      {/* ========================================================================= */}
      {/* 3. MODALS & DIALOGS */}
      {/* ========================================================================= */}
      {/* Version Comparison Modal */}
      {isComparisonModalOpen && activeProject && (
        <VersionComparisonModal
          project={activeProject}
          onClose={() => setIsComparisonModalOpen(false)}
          initialVersionA={compareVersionA}
          initialVersionB={compareVersionB}
          onRestoreVersion={(v) => {
            handleRestoreVersion(v);
            setIsComparisonModalOpen(false);
          }}
          onExportVersionStl={handleExportVersionStl}
        />
      )}

      {/* Proposed Changes Review Modal */}
      {proposedChangeSet && (
        <ProposedChangesModal
          changeSet={proposedChangeSet}
          userInstruction={pendingRevisionInstruction || ''}
          onConfirm={(autoApplyFuture) => {
            const instructionToRun = pendingRevisionInstruction;
            // Dismiss the modal immediately so the user returns to the workspace and sees pipeline progress
            setProposedChangeSet(null);
            setPendingRevisionInstruction(null);

            if (autoApplyFuture && activeProject) {
              const updatedProj: KatPrintProject = {
                ...activeProject,
                projectSettings: {
                  ...activeProject.projectSettings,
                  autoApplyProposedChanges: true,
                },
                updatedAt: new Date().toISOString(),
              };
              persistActiveProject(updatedProj).catch((e) =>
                console.error('Failed to update project auto-apply setting:', e)
              );
            }
            if (instructionToRun) {
              executeDirectRevision(instructionToRun);
            }
          }}
          onCancel={() => {
            setProposedChangeSet(null);
            setPendingRevisionInstruction(null);
          }}
        />
      )}

      {/* Storage Management Modal */}
      <StorageManagementModal
        isOpen={isStorageModalOpen}
        onClose={() => setIsStorageModalOpen(false)}
        onDataCleared={async () => {
          const list = await projectRepository.listProjects();
          setProjects(list);
          if (list.length > 0) {
            activateProject(list[0]);
          } else {
            await handleCreateBlankProject('Untitled Project');
          }
        }}
        onStorageCleared={async () => {
          const list = await projectRepository.listProjects();
          setProjects(list);
          if (list.length > 0) {
            activateProject(list[0]);
          } else {
            await handleCreateBlankProject('Untitled Project');
          }
        }}
      />

      {/* Quality Benchmark & Test Suite Modal */}
      <TestSuiteModal
        isOpen={isTestSuiteOpen}
        onClose={() => setIsTestSuiteOpen(false)}
        onRunTest={(prompt) => {
          setNavView('workspace');
          handleGenerateJscad(prompt, { mode: 'precision' });
        }}
      />

      {/* Custom Printer Setup Modal */}
      <CustomPrinterModal
        isOpen={isCustomPrinterOpen}
        onClose={() => setIsCustomPrinterOpen(false)}
        onSave={handleSaveCustomPrinter}
        printer={selectedPrinter}
        initialPrinter={selectedPrinter}
      />

      {/* Live Telemetry Simulation Modal */}
      <LivePrinterMonitor
        isOpen={isLiveMonitorOpen}
        onClose={() => setIsLiveMonitorOpen(false)}
        printer={selectedPrinter}
        filament={selectedFilament}
        settings={slicerSettings}
        stats={geometryStats}
      />

      {/* Multi-Plate Print Bed Layout Modal */}
      {isPlateLayoutOpen && (
        <PlateLayoutModal
          isOpen={isPlateLayoutOpen}
          onClose={() => setIsPlateLayoutOpen(false)}
          parts={currentParts}
          printer={selectedPrinter}
          filament={selectedFilament}
          projectName={activeProject?.name || 'Assembly'}
          versionLabel={currentActiveVersion?.label}
          scaleFactor={scaleFactor}
        />
      )}

      {/* Reference Photos Manager Modal */}
      {isReferencePhotosOpen && (
        <ReferencePhotosManager
          isOpen={isReferencePhotosOpen}
          onClose={() => setIsReferencePhotosOpen(false)}
          referenceImages={activeProject?.referenceImages || []}
          onUpdateReferenceImages={handleUpdateReferenceImages}
        />
      )}
    </div>
  );
}
