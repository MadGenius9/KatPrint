import {
  DesignSpecification,
  DesignCheck,
  DesignConcept,
  ModelGeometryStats,
  FidelityReviewResult,
  GenerationDiagnostics,
  GenerationMode,
  PrinterSpec,
  FilamentSpec,
  ProjectReferenceImage,
  ModelPartDefinition,
  PartRelationship,
  ModelAssemblyDefinition,
  ExecutedModelPart,
  ExecutedModel,
  PrintPlatePlan,
} from '../types';
import type { SemanticFeatureModel, SemanticRevisionOperation } from '../features/featureTypes';
import type { FeatureModelDiff } from '../features/featureModel';

export type {
  DesignSpecification,
  DesignCheck,
  DesignConcept,
  ModelGeometryStats,
  FidelityReviewResult,
  GenerationDiagnostics,
  GenerationMode,
  PrinterSpec,
  FilamentSpec,
  SemanticFeatureModel,
  SemanticRevisionOperation,
  FeatureModelDiff,
  ProjectReferenceImage,
  ModelPartDefinition,
  PartRelationship,
  ModelAssemblyDefinition,
  ExecutedModelPart,
  ExecutedModel,
  PrintPlatePlan,
};

export type InspectionViewSet = {
  isometric?: string;
  front?: string;
  rear?: string;
  left?: string;
  right?: string;
  top?: string;
  bottom?: string;
  allViews?: Array<{ viewName: string; dataUrl: string }>;
};

export interface ProjectReferenceObject {
  id: string;
  name: string;
  category: string;
  dimensions: {
    width: number;
    depth: number;
    height: number;
    diameter?: number;
  };
  criticalClearanceMm?: number;
  notes?: string;
}

export interface ProjectSettings {
  printerId: string;
  filamentId: string;
  generationMode: GenerationMode;
  autoApplyProposedChanges: boolean;
  enableThinking: boolean;
  scaleFactor: number;
  mustHoldLiquid: boolean;
}

export interface ProjectMemory {
  objectPurpose?: string;
  currentDimensions?: {
    width?: number;
    depth?: number;
    height?: number;
  };
  currentFeatures?: string[];
  compatibilityTargets?: string[];
  mountingInterfaces?: string[];
  importantDecisions?: string[];
  userRejectedOptions?: string[];
  unresolvedRequirements?: string[];
}

export type VersionChangeType =
  | 'INITIAL_GENERATION'
  | 'PROMPT_REVISION'
  | 'REVISION'
  | 'MANUAL_EDIT'
  | 'PRECISION_REPAIR'
  | 'RESTORED'
  | 'BRANCH';

/**
 * Authoritative Canonical ModelVersion Schema
 * No legacy duplicate aliases (jscadScript, specification, checklist, verificationScore)
 */
export interface ModelVersion {
  id: string;
  projectId: string;
  versionNumber: number;
  label: string;
  createdAt: string;
  parentVersionId?: string | null;
  sourceVersionId?: string | null;
  changeType: VersionChangeType;
  changeSummary: string;
  userInstruction?: string;
  prompt?: string;
  cadCode: string;
  designSpecification?: DesignSpecification;
  designChecklist?: DesignCheck[];
  featureModel?: SemanticFeatureModel | null;
  assembly?: ModelAssemblyDefinition | null;
  fidelityReview?: FidelityReviewResult;
  geometryMetadata?: ModelGeometryStats;
  generationDiagnostics?: GenerationDiagnostics;
  exportValidation?: {
    allowed: boolean;
    reason: string;
  };
  designMatchScore?: number | null;
  thumbnail?: string;
  isCurrentHead?: boolean;
  status?: 'verified' | 'unverified' | 'failed';
  inspectionImages?: InspectionViewSet;
  diffExplanation?: string;
  semanticRevisionOperation?: SemanticRevisionOperation | null;
}

/**
 * Legacy schema definition used strictly at the boundary of serialization/migration
 */
export interface LegacyModelVersion {
  id?: string;
  projectId?: string;
  versionNumber?: number;
  label?: string;
  createdAt?: string;
  parentVersionId?: string | null;
  sourceVersionId?: string | null;
  changeType?: VersionChangeType;
  changeSummary?: string;
  userInstruction?: string;
  prompt?: string;
  cadCode?: string;
  jscadScript?: string;
  designSpecification?: DesignSpecification;
  specification?: DesignSpecification;
  designChecklist?: DesignCheck[];
  checklist?: DesignCheck[];
  featureModel?: SemanticFeatureModel | null;
  assembly?: ModelAssemblyDefinition | null;
  semanticRevisionOperation?: SemanticRevisionOperation | null;
  fidelityReview?: FidelityReviewResult;
  geometryMetadata?: ModelGeometryStats;
  generationDiagnostics?: GenerationDiagnostics;
  exportValidation?: {
    allowed: boolean;
    reason: string;
  };
  designMatchScore?: number | null;
  verificationScore?: number;
  thumbnail?: string;
  isCurrentHead?: boolean;
  status?: 'verified' | 'unverified' | 'failed';
  inspectionImages?: InspectionViewSet;
  diffExplanation?: string;
  dimensions?: { x: number; y: number; z: number };
  volumeMm3?: number;
  triangleCount?: number;
  isManifold?: boolean;
  nonManifoldEdgeCount?: number;
  surfaceAreaMm2?: number;
}

export interface DesignConversationMessage {
  id: string;
  projectId: string;
  role: 'user' | 'katprint' | 'system';
  content: string;
  timestamp: string;
  versionId?: string;
  relatedVersionId?: string;
  actionType?: 'generate' | 'revise' | 'restore' | 'branch' | 'undo' | 'repair' | 'manual';
  changes?: string[];
  designMatchScore?: number | null;
  fidelityReviewResult?: FidelityReviewResult;
}

export interface KatPrintProject {
  id: string;
  dataSchemaVersion?: number;
  name: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
  originalPrompt: string;
  currentVersionId: string | null;
  versions: ModelVersion[];
  conversation: DesignConversationMessage[];
  projectSettings: ProjectSettings;
  referenceObjects: ProjectReferenceObject[];
  referenceImages?: ProjectReferenceImage[];
  projectMemory?: ProjectMemory;
  printerProfileId?: string;
  materialProfileId?: string;
  thumbnail?: string;
  tags?: string[];
  isFavorite?: boolean;
  conceptCache?: Record<string, DesignConcept[]>;
}

export interface DesignFeatureInstance {
  id: string;
  type: string;
  label: string;
  parameters?: Record<string, number | string | boolean>;
  source: 'user' | 'inferred' | 'template' | 'reference' | 'revision';
  geometryHints?: string[];
}

export interface DesignChange {
  feature: string;
  change: string;
  fromValue?: string | number;
  toValue?: string | number;
  category?: 'dimension' | 'feature' | 'interface' | 'material' | 'aesthetic';
}

export interface DesignChangeSet {
  requestedChanges: DesignChange[];
  preservedFeatures: string[];
  potentiallyAffectedRequirements: string[];
  newDesignSpecification: DesignSpecification;
  confidence: number;
  isNaturalUndo?: boolean;
  targetRestoreVersionId?: string;
  isRelativeModification?: boolean;
  explanation?: string;
}

export interface RevisionRequest {
  projectId: string;
  activeVersionId: string;
  userInstruction: string;
  currentDesignSpecification: DesignSpecification;
  currentCadCode: string;
  currentGeometryMetadata: ModelGeometryStats;
  conversationContext: DesignConversationMessage[];
  projectMemory?: ProjectMemory;
  requestedChanges: DesignChange[];
  preserveRequirements: string[];
}

export interface VersionComparisonData {
  versionA: ModelVersion;
  versionB: ModelVersion;
  dimensionDiffs: {
    width: { a: number; b: number; diff: number };
    depth: { a: number; b: number; diff: number };
    height: { a: number; b: number; diff: number };
  };
  volumeDiff: { a: number; b: number; diff: number; percentChange: number };
  triangleCountDiff: { a: number; b: number; diff: number };
  scoreDiff: { a: number | null; b: number | null; diff: number | null };
  manifoldStatus: { a: boolean; b: boolean };
  addedFeatures: string[];
  removedFeatures: string[];
  preservedFeatures: string[];
  specificationDiffs: Array<{ label: string; valueA: string; valueB: string }>;
  codeChanged: boolean;
  featureModelDiff?: FeatureModelDiff;
}

export interface StorageUsageStats {
  projectCount: number;
  versionCount: number;
  estimatedBytes: number;
  lastUpdated: string;
}
