import {
  KatPrintProject,
  ModelVersion,
  LegacyModelVersion,
  ProjectSettings,
  DesignSpecification,
  DesignCheck,
  ModelGeometryStats,
  FidelityReviewResult,
  GenerationDiagnostics,
  InspectionViewSet,
  VersionChangeType,
  DesignConversationMessage,
  SemanticFeatureModel,
  SemanticRevisionOperation,
  ModelAssemblyDefinition,
} from './projectTypes';
import { initializeProjectMemory } from './projectMemory';

export interface BuildModelVersionParams {
  id?: string;
  projectId: string;
  versionNumber: number;
  label?: string;
  createdAt?: string;
  parentVersionId?: string | null;
  sourceVersionId?: string | null;
  changeType: VersionChangeType;
  changeSummary: string;
  userInstruction?: string;
  prompt?: string;
  cadCode: string;
  designSpecification?: DesignSpecification;
  designChecklist?: DesignCheck[];
  featureModel?: SemanticFeatureModel | null;
  assembly?: ModelAssemblyDefinition | null;
  fidelityReview?: FidelityReviewResult;
  geometryMetadata?: ModelGeometryStats;
  generationDiagnostics?: GenerationDiagnostics;
  exportValidation?: {
    allowed: boolean;
    reason: string;
  };
  designMatchScore?: number | null;
  thumbnail?: string;
  isCurrentHead?: boolean;
  status?: 'verified' | 'unverified' | 'failed';
  inspectionImages?: InspectionViewSet;
  diffExplanation?: string;
  semanticRevisionOperation?: SemanticRevisionOperation | null;
}

/**
 * Authoritative single ModelVersion factory.
 * Guarantees no legacy field drift and no fake default scores.
 */
export function buildModelVersion(params: BuildModelVersionParams): ModelVersion {
  const geomMeta = params.geometryMetadata;
  const isManifold = geomMeta?.isManifold;
  const vol = geomMeta?.volumeMm3 ?? 0;
  const triangles = geomMeta?.triangleCount ?? 0;

  // Real score calculation: ONLY from explicit designMatchScore or fidelityReview.overallScore.
  // NEVER default to 90 or 95!
  let score: number | null = null;
  if (typeof params.designMatchScore === 'number') {
    score = params.designMatchScore;
  } else if (params.fidelityReview && typeof params.fidelityReview.overallScore === 'number') {
    score = params.fidelityReview.overallScore;
  }

  // Determine export validation accurately
  const exportVal = params.exportValidation || (geomMeta ? {
    allowed: triangles > 0,
    reason: triangles <= 0 ? 'No mesh triangles' : '',
  } : undefined);

  // Status is separate from fake score
  let status: 'verified' | 'unverified' | 'failed' = params.status || 'unverified';
  if (!params.status) {
    if (geomMeta && (!geomMeta.isManifold || geomMeta.triangleCount <= 0 || geomMeta.volumeMm3 <= 0)) {
      status = 'failed';
    } else if (score !== null) {
      status = score >= 90 ? 'verified' : score >= 70 ? 'unverified' : 'failed';
    } else if (geomMeta && geomMeta.isManifold && geomMeta.volumeMm3 > 0) {
      status = 'unverified';
    }
  }

  return {
    id: params.id || `ver_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    projectId: params.projectId,
    versionNumber: params.versionNumber,
    label: params.label || createVersionLabel(params.versionNumber, params.userInstruction, params.changeType),
    createdAt: params.createdAt || new Date().toISOString(),
    parentVersionId: params.parentVersionId ?? null,
    sourceVersionId: params.sourceVersionId,
    changeType: params.changeType,
    changeSummary: params.changeSummary,
    userInstruction: params.userInstruction,
    prompt: params.prompt,
    cadCode: params.cadCode,
    designSpecification: params.designSpecification,
    designChecklist: params.designChecklist,
    featureModel: params.featureModel ?? null,
    assembly: params.assembly ?? null,
    fidelityReview: params.fidelityReview,
    geometryMetadata: geomMeta,
    generationDiagnostics: params.generationDiagnostics,
    exportValidation: exportVal,
    designMatchScore: score,
    thumbnail: params.thumbnail,
    isCurrentHead: params.isCurrentHead,
    status,
    inspectionImages: params.inspectionImages,
    diffExplanation: params.diffExplanation,
    semanticRevisionOperation: params.semanticRevisionOperation ?? null,
  };
}

/**
 * Migration boundary normalizer.
 * Reads legacy aliases (jscadScript, specification, checklist, verificationScore, etc.)
 * but outputs CANONICAL ModelVersion fields ONLY.
 */
export function normalizeModelVersion(rawVersion: LegacyModelVersion | any): ModelVersion {
  const script = rawVersion.cadCode || rawVersion.jscadScript || '';

  // Extract geometry metadata if present
  let geomMeta: ModelGeometryStats | undefined = rawVersion.geometryMetadata;
  if (!geomMeta && (rawVersion.dimensions || rawVersion.volumeMm3 !== undefined || rawVersion.triangleCount !== undefined || rawVersion.isManifold !== undefined)) {
    geomMeta = {
      dimensions: rawVersion.dimensions || { x: 0, y: 0, z: 0 },
      volumeMm3: rawVersion.volumeMm3 ?? 0,
      volumeCm3: (rawVersion.volumeMm3 ?? 0) / 1000,
      surfaceAreaMm2: rawVersion.surfaceAreaMm2 || 0,
      estimatedWeightGrams: 0,
      triangleCount: rawVersion.triangleCount ?? 0,
      vertexCount: (rawVersion.triangleCount ?? 0) * 3,
      isManifold: rawVersion.isManifold ?? false,
      nonManifoldEdgeCount: rawVersion.nonManifoldEdgeCount || 0,
      overhangRatio: 0,
      minWallThicknessMm: 0,
      footprintAreaMm2: 0,
      heightToWidthRatio: 0,
      hasSteepOverhangs: false,
    };
  }

  // Preserve null if unknown, do not convert absence of evidence into 90% confidence
  const score: number | null = rawVersion.designMatchScore !== undefined
    ? rawVersion.designMatchScore
    : rawVersion.verificationScore !== undefined
    ? rawVersion.verificationScore
    : rawVersion.fidelityReview?.overallScore !== undefined
    ? rawVersion.fidelityReview.overallScore
    : null;

  const spec: DesignSpecification | undefined = rawVersion.designSpecification || rawVersion.specification || undefined;
  const checklist: DesignCheck[] | undefined = rawVersion.designChecklist || rawVersion.checklist || undefined;

  const isManifold = geomMeta?.isManifold ?? rawVersion.isManifold ?? (geomMeta ? false : undefined);
  const vol = geomMeta?.volumeMm3 ?? rawVersion.volumeMm3 ?? 0;
  const triangles = geomMeta?.triangleCount ?? rawVersion.triangleCount ?? 0;

  // Construct CANONICAL object explicitly — do not spread rawVersion with legacy aliases back out
  return {
    id: rawVersion.id || `ver_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    projectId: rawVersion.projectId || '',
    versionNumber: rawVersion.versionNumber || 1,
    label: rawVersion.label || `V${rawVersion.versionNumber || 1}`,
    createdAt: rawVersion.createdAt || new Date().toISOString(),
    parentVersionId: rawVersion.parentVersionId ?? null,
    sourceVersionId: rawVersion.sourceVersionId,
    changeType: rawVersion.changeType || 'INITIAL_GENERATION',
    changeSummary: rawVersion.changeSummary || 'Initial version',
    userInstruction: rawVersion.userInstruction,
    prompt: rawVersion.prompt,
    cadCode: script,
    designSpecification: spec,
    designChecklist: checklist,
    featureModel: rawVersion.featureModel ?? null,
    assembly: rawVersion.assembly ?? null,
    fidelityReview: rawVersion.fidelityReview,
    geometryMetadata: geomMeta,
    generationDiagnostics: rawVersion.generationDiagnostics,
    exportValidation: rawVersion.exportValidation || (geomMeta ? {
      allowed: triangles > 0,
      reason: triangles <= 0 ? 'No mesh triangles' : '',
    } : undefined),
    designMatchScore: score,
    thumbnail: rawVersion.thumbnail,
    isCurrentHead: rawVersion.isCurrentHead,
    status: rawVersion.status || (score !== null ? (score >= 90 ? 'verified' : score >= 70 ? 'unverified' : 'failed') : (geomMeta && isManifold ? 'unverified' : 'failed')),
    inspectionImages: rawVersion.inspectionImages,
    diffExplanation: rawVersion.diffExplanation,
    semanticRevisionOperation: rawVersion.semanticRevisionOperation ?? null,
  };
}

export function normalizeKatPrintProject(raw: any): KatPrintProject {
  const id = raw?.id || `proj_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const now = new Date().toISOString();

  const rawVersions = Array.isArray(raw?.versions) ? raw.versions : [];
  const versions: ModelVersion[] = rawVersions.map((v: any) => {
    const norm = normalizeModelVersion(v);
    return { ...norm, projectId: norm.projectId || id };
  });

  let currentVersionId = raw?.currentVersionId;
  if (versions.length > 0) {
    const exists = versions.some((v) => v.id === currentVersionId);
    if (!exists) {
      const headVer = versions.find((v) => v.isCurrentHead);
      currentVersionId = headVer ? headVer.id : versions[versions.length - 1].id;
    }
    // Ensure the current head flag is consistent
    versions.forEach((v) => {
      v.isCurrentHead = (v.id === currentVersionId);
    });
  } else {
    currentVersionId = null;
  }

  const rawConv = Array.isArray(raw?.conversation) ? raw.conversation : [];
  const conversation: DesignConversationMessage[] = rawConv.map((m: any) => ({
    id: m.id || `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    projectId: id,
    role: m.role === 'user' ? 'user' : m.role === 'system' ? 'system' : 'katprint',
    content: m.content || '',
    timestamp: m.timestamp || now,
    versionId: m.versionId,
    relatedVersionId: m.relatedVersionId,
    actionType: m.actionType,
    changes: Array.isArray(m.changes) ? m.changes : undefined,
    designMatchScore: m.designMatchScore !== undefined ? m.designMatchScore : null,
    fidelityReviewResult: m.fidelityReviewResult,
  }));

  const projectSettings: ProjectSettings = {
    printerId: raw?.projectSettings?.printerId || 'bambu-x1c',
    filamentId: raw?.projectSettings?.filamentId || 'pla',
    generationMode: raw?.projectSettings?.generationMode || 'precision',
    autoApplyProposedChanges: !!raw?.projectSettings?.autoApplyProposedChanges,
    enableThinking: raw?.projectSettings?.enableThinking !== false,
    scaleFactor: typeof raw?.projectSettings?.scaleFactor === 'number' ? raw.projectSettings.scaleFactor : 1.0,
    mustHoldLiquid: !!raw?.projectSettings?.mustHoldLiquid,
  };

  // Convert legacy 'favorite' tag into isFavorite = true and remove it from tags array
  const rawTags: string[] = Array.isArray(raw?.tags) ? raw.tags : [];
  const hasFavoriteTag = rawTags.includes('favorite');
  const cleanTags = rawTags.filter((t) => t !== 'favorite');
  const isFavorite = Boolean(raw?.isFavorite || hasFavoriteTag);

  return {
    id,
    dataSchemaVersion: 3,
    name: raw?.name || 'Untitled Project',
    description: raw?.description,
    createdAt: raw?.createdAt || now,
    updatedAt: raw?.updatedAt || now,
    originalPrompt: raw?.originalPrompt || '',
    currentVersionId,
    versions,
    conversation,
    projectMemory: raw?.projectMemory,
    projectSettings,
    referenceObjects: Array.isArray(raw?.referenceObjects) ? raw.referenceObjects : [],
    referenceImages: Array.isArray(raw?.referenceImages) ? raw.referenceImages : [],
    tags: cleanTags,
    isFavorite,
    thumbnail: raw?.thumbnail,
  };
}

export function duplicateProjectGraph(
  original: KatPrintProject,
  newName?: string
): KatPrintProject {
  const newProjectId = `proj_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const now = new Date().toISOString();

  // Create version ID remapping table
  const versionIdMap = new Map<string, string>();
  const originalVersions = original.versions || [];
  originalVersions.forEach((v) => {
    versionIdMap.set(v.id, `ver_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
  });

  // Remap versions
  const clonedVersions: ModelVersion[] = originalVersions.map((v) => {
    const newVersionId = versionIdMap.get(v.id)!;
    const remappedParent = v.parentVersionId ? versionIdMap.get(v.parentVersionId) || null : null;
    const remappedSource = v.sourceVersionId ? versionIdMap.get(v.sourceVersionId) || undefined : undefined;
    const normalized = normalizeModelVersion(v);

    return {
      ...normalized,
      id: newVersionId,
      projectId: newProjectId,
      parentVersionId: remappedParent,
      sourceVersionId: remappedSource,
    };
  });

  // Remap currentVersionId
  let remappedCurrentVersionId: string | null = null;
  if (original.currentVersionId && versionIdMap.has(original.currentVersionId)) {
    remappedCurrentVersionId = versionIdMap.get(original.currentVersionId)!;
  } else if (clonedVersions.length > 0) {
    remappedCurrentVersionId = clonedVersions[clonedVersions.length - 1].id;
  }

  // Remap conversation messages
  const originalConversation = original.conversation || [];
  const clonedConversation: DesignConversationMessage[] = originalConversation.map((m) => {
    const newMsgId = `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const remappedVerId = m.versionId ? versionIdMap.get(m.versionId) || undefined : undefined;
    const remappedRelId = m.relatedVersionId ? versionIdMap.get(m.relatedVersionId) || undefined : undefined;

    return {
      ...m,
      id: newMsgId,
      projectId: newProjectId,
      versionId: remappedVerId,
      relatedVersionId: remappedRelId,
    };
  });

  return {
    ...original,
    id: newProjectId,
    dataSchemaVersion: 3,
    name: newName || `${original.name} (Copy)`,
    createdAt: now,
    updatedAt: now,
    currentVersionId: remappedCurrentVersionId,
    versions: clonedVersions,
    conversation: clonedConversation,
    projectMemory: original.projectMemory ? JSON.parse(JSON.stringify(original.projectMemory)) : undefined,
    projectSettings: original.projectSettings ? JSON.parse(JSON.stringify(original.projectSettings)) : {
      printerId: 'bambu-x1c',
      filamentId: 'pla',
      generationMode: 'precision',
      autoApplyProposedChanges: false,
      enableThinking: true,
      scaleFactor: 1.0,
      mustHoldLiquid: false,
    },
    referenceObjects: original.referenceObjects ? JSON.parse(JSON.stringify(original.referenceObjects)) : [],
    tags: original.tags ? [...original.tags] : [],
    isFavorite: original.isFavorite ?? false,
    thumbnail: original.thumbnail,
  };
}

export function inferProjectName(prompt: string, spec?: DesignSpecification): string {
  if (spec?.primaryObject && spec.primaryObject.length < 45 && !spec.primaryObject.toLowerCase().includes('mechanical component')) {
    return spec.primaryObject;
  }

  const clean = prompt.trim().replace(/^make (?:me )?(?:a |an )?/i, '').replace(/^design (?:a |an )?/i, '');
  if (!clean) return 'KatPrint Project';
  
  // Specific recognizable objects
  if (/dr\.?\s*squatch/i.test(clean) && /soap/i.test(clean)) return 'Dr. Squatch Soap Dish';
  if (/xbox/i.test(clean) && /controller/i.test(clean)) return 'Under-Desk Xbox Controller Mount';
  if (/phone/i.test(clean) && /stand/i.test(clean)) return 'Desktop Phone Stand';
  if (/cable/i.test(clean) && /clip|organizer/i.test(clean)) return 'Cable Management Clip';
  if (/esp32|arduino|raspberry\s*pi/i.test(clean) && /case|enclosure/i.test(clean)) return 'Electronics Enclosure';
  if (/headphone/i.test(clean) && /hanger|stand|hook/i.test(clean)) return 'Under-Desk Headphone Hanger';

  // Capitalize first 4-5 words
  const words = clean.split(/[.,;\n]/)[0].split(/\s+/).slice(0, 5);
  if (words.length > 0 && words[0].length > 0) {
    return words
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ');
  }

  return 'KatPrint CAD Project';
}

export function createBlankProject(
  name: string = 'Untitled Project',
  settings?: Partial<ProjectSettings>
): KatPrintProject {
  const now = new Date().toISOString();
  const id = `proj_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const defaultSettings: ProjectSettings = {
    printerId: 'bambu-x1c',
    filamentId: 'pla',
    generationMode: 'precision',
    autoApplyProposedChanges: false,
    enableThinking: true,
    scaleFactor: 1.0,
    mustHoldLiquid: false,
    ...settings,
  };

  return {
    id,
    dataSchemaVersion: 3,
    name,
    createdAt: now,
    updatedAt: now,
    originalPrompt: '',
    currentVersionId: null,
    versions: [],
    conversation: [
      {
        id: `msg_init_${Date.now()}`,
        projectId: id,
        role: 'katprint',
        content: 'Welcome to your KatPrint design workspace. Enter a prompt to generate CAD geometry or import a project package.',
        timestamp: now,
      },
    ],
    projectSettings: defaultSettings,
    referenceObjects: [],
    tags: [],
    isFavorite: false,
  };
}

export function createDefaultProject(
  prompt: string = '100 mm × 60 mm × 25 mm electronics enclosure with 3 mm walls, four M4 mounting holes in corners, two 20 mm cable openings on left, and removable top lid',
  settings?: Partial<ProjectSettings>
): KatPrintProject {
  const now = new Date().toISOString();
  const id = `proj_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const defaultSettings: ProjectSettings = {
    printerId: 'bambu-x1c',
    filamentId: 'pla',
    generationMode: 'precision',
    autoApplyProposedChanges: false,
    enableThinking: true,
    scaleFactor: 1.0,
    mustHoldLiquid: false,
    ...settings,
  };

  return {
    id,
    dataSchemaVersion: 3,
    name: inferProjectName(prompt),
    createdAt: now,
    updatedAt: now,
    originalPrompt: prompt,
    currentVersionId: null,
    versions: [],
    conversation: [
      {
        id: `msg_init_${Date.now()}`,
        projectId: id,
        role: 'katprint',
        content: 'Welcome to your KatPrint design workspace. Describe what you want to create or pick a starting template.',
        timestamp: now,
      },
    ],
    projectSettings: defaultSettings,
    referenceObjects: [],
    projectMemory: initializeProjectMemory(prompt),
    tags: [],
    isFavorite: false,
  };
}

export function getNextVersionNumber(versions: ModelVersion[]): number {
  if (!versions || versions.length === 0) return 1;
  const maxNum = versions.reduce((max, v) => Math.max(max, v.versionNumber || 0), 0);
  return maxNum + 1;
}

export function createVersionLabel(
  versionNumber: number,
  instruction?: string,
  changeType?: VersionChangeType
): string {
  if (changeType === 'INITIAL_GENERATION' || versionNumber === 1) {
    return `V${versionNumber} — Initial Design`;
  }
  if (changeType === 'RESTORED') {
    return `V${versionNumber} — ${instruction || 'Restored Version'}`;
  }
  if (changeType === 'BRANCH') {
    return `V${versionNumber} — ${instruction || 'Branched Design'}`;
  }
  if (changeType === 'MANUAL_EDIT') {
    return `V${versionNumber} — Manual Script Edit`;
  }

  if (instruction) {
    const trimmed = instruction.trim().replace(/^(?:please\s+)?(?:make|add|change|round|increase|decrease|move|remove)\s+/i, '');
    const words = trimmed.split(/\s+/).slice(0, 4).join(' ');
    const capital = words.charAt(0).toUpperCase() + words.slice(1);
    return `V${versionNumber} — ${capital}`;
  }

  return `V${versionNumber} — Revision`;
}
