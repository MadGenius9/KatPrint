import React from 'react';
import type * as THREE from 'three';
import {
  AlertTriangle,
  RefreshCw,
  Eye,
  RotateCcw,
  MessageSquare,
  Sparkles,
  Camera,
} from 'lucide-react';
import { Viewer3D } from '../Viewer3D';
import { hasMultiplePhysicalPieces } from '../../engine/stlExporter';
import type {
  PrinterSpec,
  ExecutedModelPart,
  ExtractedRequirements,
} from '../../types';
import type { KatPrintProject, ModelVersion } from '../../projects/projectTypes';
import type { ManipulatorType } from '../../features';

export interface ViewerFrameProps {
  mobileTab: 'create' | 'viewer' | 'assistant' | 'print' | 'projects';
  setMobileTab: (tab: 'create' | 'viewer' | 'assistant' | 'print' | 'projects') => void;
  setRightPanelTab: (tab: 'design' | 'print' | 'versions') => void;
  setDesignPanelMode: (mode: 'assistant' | 'feature') => void;
  cadSource: string | null;
  lastPrompt: string;
  activeProject: KatPrintProject | null;
  isGeneratingCad: boolean;
  handleGenerateJscad: (
    prompt?: string,
    options?: {
      mode?: 'precision' | 'creative' | 'organic' | 'fast';
      simplifyToParametric?: boolean;
      autoHeal?: boolean;
      isFixPass?: boolean;
      feedbackInstructions?: string;
    }
  ) => Promise<void>;
  viewingVersionId: string | null;
  currentActiveVersion: ModelVersion | null;
  handleRestoreVersion: (version: ModelVersion) => Promise<void>;
  handleReturnToHead: () => void;
  activeGeometry: THREE.BufferGeometry | null;
  selectedPrinter: PrinterSpec;
  scaleFactor: number;
  highlightOverhangs: boolean;
  setHighlightOverhangs: React.Dispatch<React.SetStateAction<boolean>>;
  extractedRequirements: ExtractedRequirements | null;
  currentParts: ExecutedModelPart[];
  selectedPartId: string | null;
  setSelectedPartId: (id: string | null) => void;
  explodedOffset: number;
  partVisibility: Record<string, boolean>;
  currentJscadCode: string;
  selectedFeatureId: string | null;
  selectedFeatureIds: string[];
  handleSelectFeature: (featureId: string | null) => void;
  handleMultiSelectFeatures: (featureIds: string[]) => void;
  focusTarget: { featureId: string; nonce: number } | null;
  handleFocusFeature: (featureId: string) => void;
  debugShowPickProxies: boolean;
  setDebugShowPickProxies: React.Dispatch<React.SetStateAction<boolean>>;
  handleManipulationCommit: (params: {
    featureId: string;
    featureIds?: string[];
    manipulatorId: string;
    manipulatorType: ManipulatorType;
    parameterChanges: Array<{
      parameterId: string;
      newValue: number | string | boolean;
      oldValue?: number | string | boolean;
      unit?: string;
    }>;
    instructionSummary?: string;
  }) => Promise<void>;
  onOpenCamera?: () => void;
}

export const ViewerFrame: React.FC<ViewerFrameProps> = ({
  mobileTab,
  setMobileTab,
  setRightPanelTab,
  setDesignPanelMode,
  cadSource,
  lastPrompt,
  activeProject,
  isGeneratingCad,
  handleGenerateJscad,
  viewingVersionId,
  currentActiveVersion,
  handleRestoreVersion,
  handleReturnToHead,
  activeGeometry,
  selectedPrinter,
  scaleFactor,
  highlightOverhangs,
  setHighlightOverhangs,
  extractedRequirements,
  currentParts,
  selectedPartId,
  setSelectedPartId,
  explodedOffset,
  partVisibility,
  currentJscadCode,
  selectedFeatureId,
  selectedFeatureIds,
  handleSelectFeature,
  handleMultiSelectFeatures,
  focusTarget,
  handleFocusFeature,
  debugShowPickProxies,
  setDebugShowPickProxies,
  handleManipulationCommit,
  onOpenCamera,
}) => {
  return (
    <section
      className={`${
        mobileTab === 'viewer' ? 'flex w-full h-full pb-16 lg:pb-0' : 'hidden'
      } lg:flex lg:flex-1 relative bg-kf-bg flex-col`}
    >
      {/* Template Banner */}
      {cadSource === 'template' && (
        <div
          id="template-model-banner"
          className="shrink-0 m-3 mb-1.5 z-30 bg-kf-warn/20 border border-kf-warn/70 backdrop-blur-md px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg shadow-lg flex items-center justify-between gap-2 sm:gap-3 text-kf-warn"
        >
          <div className="flex items-center gap-2 sm:gap-2.5">
            <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5 text-kf-warn shrink-0" />
            <span className="text-[11px] sm:text-xs font-medium leading-snug">
              Loaded from Parametric Template Library. Click Generate with AI for custom geometry.
            </span>
          </div>
          <button
            type="button"
            id="btn-retry-with-ai"
            onClick={() =>
              handleGenerateJscad(lastPrompt, {
                mode: activeProject?.projectSettings?.generationMode || 'precision',
              })
            }
            disabled={isGeneratingCad}
            className="shrink-0 flex items-center gap-1 sm:gap-1.5 bg-kf-warn hover:bg-kf-warn/90 text-[#140F00] font-mono text-[10px] sm:text-xs font-bold px-2.5 sm:px-3 py-1.5 rounded transition disabled:opacity-50 shadow-sm cursor-pointer"
          >
            <RefreshCw className={`w-3 h-3 sm:w-3.5 sm:h-3.5 ${isGeneratingCad ? 'animate-spin' : ''}`} />
            <span>AI Generate</span>
          </button>
        </div>
      )}

      {/* Viewing Older Version Banner */}
      {viewingVersionId && currentActiveVersion && (
        <div
          id="viewing-older-version-banner"
          className="shrink-0 m-3 mb-1.5 z-30 bg-kf-pink/20 border border-kf-pink/70 backdrop-blur-md px-3 sm:px-4 py-2 sm:py-2.5 rounded-lg shadow-lg flex items-center justify-between gap-2 sm:gap-3 text-kf-text"
        >
          <div className="flex items-center gap-2 font-mono text-[11px] sm:text-xs min-w-0 truncate">
            <Eye className="w-4 h-4 text-kf-pink shrink-0" />
            <span className="truncate">
              Viewing <strong>V{currentActiveVersion.versionNumber}</strong> ({currentActiveVersion.label})
            </span>
          </div>
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={() => handleRestoreVersion(currentActiveVersion)}
              className="flex items-center gap-1 bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-mono text-[10px] sm:text-xs font-bold px-2.5 sm:px-3 py-1 rounded transition shadow-sm cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Restore</span>
            </button>
            <button
              type="button"
              onClick={handleReturnToHead}
              className="px-2 sm:px-2.5 py-1 rounded bg-kf-panel border border-kf-border text-[10px] sm:text-xs text-kf-muted hover:text-kf-text cursor-pointer"
            >
              Head
            </button>
          </div>
        </div>
      )}

      {/* 3D WebGL Canvas */}
      <div className="flex-1 min-h-0 w-full relative">
        <Viewer3D
          geometry={activeGeometry}
          printer={selectedPrinter}
          scaleFactor={scaleFactor}
          highlightOverhangs={highlightOverhangs}
          onToggleOverhangs={() => setHighlightOverhangs(!highlightOverhangs)}
          isGenerating={isGeneratingCad}
          referenceObject={extractedRequirements?.referenceObject}
          parts={currentParts}
          isMultiPart={hasMultiplePhysicalPieces(currentParts)}
          selectedPartId={selectedPartId}
          onSelectPart={setSelectedPartId}
          explodedOffset={explodedOffset}
          partVisibility={partVisibility}
          featureModel={currentActiveVersion?.featureModel}
          cadCode={currentActiveVersion?.cadCode || currentJscadCode}
          versionId={currentActiveVersion?.id}
          selectedFeatureId={selectedFeatureId}
          selectedFeatureIds={selectedFeatureIds}
          onSelectFeature={handleSelectFeature}
          onMultiSelectFeatures={handleMultiSelectFeatures}
          focusFeature={focusTarget}
          onFocusFeature={handleFocusFeature}
          debugShowPickProxies={debugShowPickProxies}
          onToggleDebugProxies={() => setDebugShowPickProxies(!debugShowPickProxies)}
          onManipulationCommit={handleManipulationCommit}
          isReadOnly={Boolean(viewingVersionId && viewingVersionId !== activeProject?.currentVersionId)}
        />
      </div>

      {/* Mobile Floating Quick Action Bar (Only on mobile Viewer tab) */}
      <div className="lg:hidden absolute bottom-20 right-3 z-30 flex items-center gap-2 pointer-events-auto">
        {onOpenCamera && (
          <button
            type="button"
            id="btn-viewer-snap-camera"
            onClick={onOpenCamera}
            className="flex items-center gap-1.5 px-3 py-2 bg-kf-panel-2/90 border border-kf-pink/50 backdrop-blur-md rounded-full text-xs font-mono font-bold text-kf-pink shadow-lg hover:border-kf-pink transition active:scale-95 cursor-pointer"
            title="Snap camera photo for 3D conversion"
          >
            <Camera className="w-3.5 h-3.5 text-kf-pink" />
            <span>Camera</span>
          </button>
        )}
        <button
          type="button"
          onClick={() => {
            setMobileTab('assistant');
            setRightPanelTab('design');
            setDesignPanelMode('assistant');
          }}
          className="flex items-center gap-1.5 px-3 py-2 bg-kf-panel-2/90 border border-kf-pink/50 backdrop-blur-md rounded-full text-xs font-mono font-bold text-kf-text shadow-lg hover:border-kf-pink transition active:scale-95 cursor-pointer"
          title="Revise model with AI Assistant"
        >
          <MessageSquare className="w-3.5 h-3.5 text-kf-pink" />
          <span>Revise</span>
        </button>
        <button
          type="button"
          onClick={() => {
            setMobileTab('create');
          }}
          className="flex items-center gap-1.5 px-3 py-2 bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] rounded-full text-xs font-mono font-bold shadow-lg transition active:scale-95 cursor-pointer"
          title="Create or adjust parameters"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Create</span>
        </button>
      </div>
    </section>
  );
};
