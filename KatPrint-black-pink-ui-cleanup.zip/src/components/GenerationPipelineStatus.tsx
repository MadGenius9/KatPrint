import React from 'react';
import {
  CheckCircle2,
  RefreshCw,
  Cpu,
  Layers,
  ShieldCheck,
  Wrench,
  Sparkles,
  Camera,
  Search,
  CheckCheck,
} from 'lucide-react';
import { GenerationPipelineStage, GenerationMode } from '../types';

interface GenerationPipelineStatusProps {
  stage: GenerationPipelineStage;
  mode?: GenerationMode;
  repairAttempt?: number;
}

const FAST_STAGES: { id: GenerationPipelineStage; label: string; icon: any }[] = [
  { id: 'understanding_design', label: '1. Understand Design Intent', icon: Sparkles },
  { id: 'generating_cad', label: '2. Synthesize Parametric CSG', icon: Cpu },
  { id: 'building_model', label: '3. Execute & Validate Geometry', icon: Wrench },
  { id: 'checking_dimensions', label: '4. Deterministic Inspection', icon: ShieldCheck },
];

const PRECISION_STAGES: { id: GenerationPipelineStage; label: string; icon: any }[] = [
  { id: 'understanding_design', label: '1. Understand Design Intent', icon: Sparkles },
  { id: 'planning_geometry', label: '2. Build Design Specification', icon: Layers },
  { id: 'generating_cad', label: '3. Generate Parametric CAD', icon: Cpu },
  { id: 'building_model', label: '4. Build & Measure Geometry', icon: Wrench },
  { id: 'checking_dimensions', label: '5. Deterministic Inspection', icon: Search },
  { id: 'rendering_views', label: '6. Render Multi-View Inspection', icon: Camera },
  { id: 'inspecting_design', label: '7. AI Visual Fidelity Review', icon: ShieldCheck },
  { id: 'correcting_model', label: '8. Targeted Precision Correction', icon: Wrench },
  { id: 'final_verification', label: '9. Final Revalidation & Score', icon: CheckCheck },
];

export const GenerationPipelineStatus: React.FC<GenerationPipelineStatusProps> = ({
  stage,
  mode = 'precision',
  repairAttempt = 1,
}) => {
  if (stage === 'idle' || stage === 'completed' || stage === 'error') return null;

  const stages = mode === 'fast' ? FAST_STAGES : PRECISION_STAGES;

  // Filter out correcting_model unless we are at or past that stage
  const visibleStages = stages.filter((s) => {
    if (s.id === 'correcting_model') {
      return stage === 'correcting_model' || stage === 'final_verification' || repairAttempt > 0;
    }
    return true;
  });

  const currentIdx = visibleStages.findIndex((s) => s.id === stage);

  return (
    <div className="trace clip-corner bg-kf-panel-2 border border-kf-pink/40 rounded-lg p-3 flex flex-col gap-2.5 shadow-md animate-fadeIn">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <RefreshCw className="w-4 h-4 text-kf-pink animate-spin" />
          <span className="text-xs font-mono font-bold text-kf-pink uppercase tracking-wider">
            {stage === 'correcting_model'
              ? `Targeted Precision Correction (Attempt 1/1)...`
              : mode === 'precision'
              ? 'KatPrint Precision Pipeline Active'
              : 'KatPrint Fast Pipeline Active'}
          </span>
        </div>
        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-kf-pink/15 text-kf-pink border border-kf-pink/30 uppercase">
          {mode} mode
        </span>
      </div>

      <div className="flex flex-col gap-1.5 font-mono text-[11px]">
        {visibleStages.map((s, idx) => {
          const isDone = currentIdx > idx;
          const isCurrent = currentIdx === idx;
          const Icon = s.icon;

          return (
            <div
              key={s.id}
              className={`flex items-center justify-between px-2 py-1 rounded transition ${
                isCurrent
                  ? 'bg-kf-pink/15 text-kf-pink font-semibold border border-kf-pink/30'
                  : isDone
                  ? 'text-kf-ok'
                  : 'text-kf-muted opacity-60'
              }`}
            >
              <div className="flex items-center gap-2">
                <Icon className="w-3.5 h-3.5" />
                <span>{s.label}</span>
              </div>
              {isDone ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-kf-ok shrink-0" />
              ) : isCurrent ? (
                <RefreshCw className="w-3 h-3 text-kf-pink animate-spin shrink-0" />
              ) : (
                <span className="text-[10px] text-kf-muted">—</span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
