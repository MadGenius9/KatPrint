import React, { useState } from 'react';
import {
  Sparkles,
  ChevronDown,
  ChevronUp,
  Cpu,
  Layers,
  Ruler,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ShieldCheck,
  Compass,
} from 'lucide-react';
import { DesignSpecification, ExtractedRequirements } from '../types';

interface DesignUnderstandingPanelProps {
  specification?: DesignSpecification | null;
  requirements?: ExtractedRequirements | null;
}

export const DesignUnderstandingPanel: React.FC<DesignUnderstandingPanelProps> = ({
  specification,
  requirements,
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(true);

  if (!specification && !requirements) return null;

  const spec = specification || requirements?.designSpecification;
  const plan = requirements?.designPlan;

  const primaryObject = spec?.primaryObject || requirements?.objectName || 'Mechanical Component';
  const intendedFunction = spec?.intendedFunction || plan?.function || 'Hold and protect component';
  const mountingStyle = spec?.mountingStyle || plan?.mountingStyle || 'Freestanding / Surface';
  const confidence = spec?.confidence ?? plan?.confidenceScore ?? null;
  const category = spec?.category || requirements?.inferredCategory || 'PARAMETRIC_FUNCTIONAL';

  const targets = spec?.compatibilityTargets || [];
  const refObj = requirements?.referenceObject || plan?.referenceObject;

  const features = spec?.requiredFeatures || [];
  const assumptions = spec?.assumptions || [];
  const strategy = spec?.generationStrategy || 'Parametric CSG Functional CAD';

  const confidenceBadgeColor =
    confidence === null
      ? 'bg-kf-muted/15 text-kf-muted border-kf-border'
      : confidence >= 90
      ? 'bg-kf-ok/15 text-kf-ok border-kf-ok/30'
      : confidence >= 70
      ? 'bg-kf-warn/15 text-kf-warn border-kf-warn/30'
      : 'bg-red-500/15 text-red-400 border-red-500/30';

  const confidenceLabel =
    confidence === null
      ? 'Not Evaluated'
      : confidence >= 90
      ? 'High Confidence'
      : confidence >= 70
      ? 'Good Confidence'
      : 'Assumptions Needed';

  return (
    <div className="trace clip-corner bg-kf-panel-2 border border-kf-border rounded-lg overflow-hidden transition-all shadow-sm">
      {/* Header Bar */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-3 py-2 flex items-center justify-between bg-kf-panel hover:bg-kf-panel/80 transition text-left cursor-pointer border-b border-kf-border/40"
      >
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-kf-pink/15 text-kf-pink">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-bold font-mono uppercase tracking-wider text-kf-text">
            How KatPrint Understood Your Design
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span
            className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${confidenceBadgeColor}`}
          >
            {confidence !== null ? `${confidence}% ${confidenceLabel}` : confidenceLabel}
          </span>
          {isOpen ? (
            <ChevronUp className="w-3.5 h-3.5 text-kf-muted" />
          ) : (
            <ChevronDown className="w-3.5 h-3.5 text-kf-muted" />
          )}
        </div>
      </button>

      {/* Collapsible Content */}
      {isOpen && (
        <div className="p-3 flex flex-col gap-2.5 text-xs font-sans">
          {/* Top Grid: Primary Object & Purpose */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 bg-kf-bg/60 p-2.5 rounded border border-kf-border/40 font-mono">
            <div className="flex flex-col gap-0.5">
              <span className="text-[10px] text-kf-muted font-bold uppercase tracking-wider flex items-center gap-1">
                <Cpu className="w-3 h-3 text-kf-pink" /> Primary Object
              </span>
              <span className="text-kf-text font-bold text-xs font-sans">
                {primaryObject}
              </span>
              <span className="text-[10px] text-kf-pink font-mono mt-0.5">
                {category.replace(/_/g, ' ')}
              </span>
            </div>

            <div className="flex flex-col gap-0.5">
              <span className="text-[10px] text-kf-muted font-bold uppercase tracking-wider flex items-center gap-1">
                <Compass className="w-3 h-3 text-kf-pink" /> Mounting &amp; Purpose
              </span>
              <span className="text-kf-text font-medium text-xs font-sans leading-tight">
                {intendedFunction}
              </span>
              <span className="text-[10px] text-kf-muted font-mono mt-0.5">
                Mount: <strong className="text-kf-text">{mountingStyle}</strong>
              </span>
            </div>
          </div>

          {/* Target Compatibility & Reference Fit */}
          {(targets.length > 0 || refObj) && (
            <div className="bg-kf-bg/40 p-2 rounded border border-kf-border/40 flex flex-col gap-1.5 font-mono">
              <span className="text-[10px] text-kf-muted font-bold uppercase tracking-wider flex items-center gap-1">
                <Ruler className="w-3 h-3 text-kf-pink" /> Reference Target &amp; Fit Clearance
              </span>
              {targets.map((tgt, i) => (
                <div
                  key={i}
                  className="trace clip-corner flex items-center justify-between bg-kf-panel px-2 py-1 rounded text-[11px] border border-kf-border/50"
                >
                  <span className="text-kf-text font-medium">
                    {tgt.name} ({tgt.relationship})
                  </span>
                  <span className="text-kf-ok font-bold text-[10px] bg-kf-ok/10 px-1.5 py-0.2 rounded">
                    +{tgt.clearanceMm} mm clearance ({tgt.source})
                  </span>
                </div>
              ))}
              {!targets.length && refObj && (
                <div className="trace clip-corner flex items-center justify-between bg-kf-panel px-2 py-1 rounded text-[11px] border border-kf-border/50">
                  <span className="text-kf-text font-medium">
                    {refObj.name}
                  </span>
                  <span className="text-kf-ok font-bold text-[10px] bg-kf-ok/10 px-1.5 py-0.2 rounded">
                    {refObj.dimensions.width}×{refObj.dimensions.depth}×{refObj.dimensions.height} mm (+{refObj.clearanceMm || 2.0}mm clearance)
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Inferred Key Features with Checkmarks */}
          {features.length > 0 && (
            <div className="flex flex-col gap-1.5">
              <span className="text-[10px] text-kf-muted font-bold uppercase tracking-wider font-mono flex items-center gap-1">
                <Layers className="w-3 h-3 text-kf-pink" /> Required Design Features
              </span>
              <div className="grid grid-cols-1 gap-1">
                {features.map((feat, idx) => (
                  <div
                    key={feat.id || idx}
                    className="trace clip-corner flex items-start gap-1.5 bg-kf-panel/60 px-2 py-1 rounded border border-kf-border/40 text-[11px]"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-kf-ok shrink-0 mt-0.5" />
                    <div className="flex flex-col">
                      <span className="font-semibold text-kf-text">
                        {feat.name}
                      </span>
                      <span className="text-[10px] text-kf-muted font-sans leading-tight">
                        {feat.description}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Assumptions */}
          {assumptions.length > 0 && (
            <div className="flex flex-col gap-1 text-[11px] font-sans bg-kf-bg/40 p-2 rounded border border-kf-border/30">
              <span className="text-[10px] text-kf-muted font-bold uppercase tracking-wider font-mono flex items-center gap-1">
                <HelpCircle className="w-3 h-3 text-kf-pink" /> Intelligent Assumptions
              </span>
              <ul className="list-disc list-inside text-kf-muted text-[10.5px] space-y-0.5">
                {assumptions.map((asm, i) => (
                  <li key={i}>
                    <strong className="text-kf-text">
                      {typeof asm === 'string' ? asm : asm.assumption}
                    </strong>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Strategy Footer */}
          <div className="flex items-center justify-between text-[10px] font-mono text-kf-muted pt-1 border-t border-kf-border/40">
            <span>Strategy: <strong className="text-kf-text">{strategy}</strong></span>
            <span className="flex items-center gap-1 text-kf-ok font-semibold">
              <ShieldCheck className="w-3 h-3" /> Precision Ready
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
