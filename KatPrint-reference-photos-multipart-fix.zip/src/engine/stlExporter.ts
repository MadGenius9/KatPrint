import * as THREE from 'three';
import JSZip from 'jszip';
import { ExecutedModelPart, ModelAssemblyDefinition } from '../types';

/**
 * Generates an ArrayBuffer containing an exact binary STL file
 */
export function generateBinaryStlBuffer(
  geometry: THREE.BufferGeometry,
  headerTitle: string = 'KatPrint 3D Binary STL',
  scale: number = 1.0
): ArrayBuffer {
  const posAttr = geometry.getAttribute('position');
  if (!posAttr || posAttr.count === 0) {
    // Empty STL
    const emptyBuf = new ArrayBuffer(84);
    return emptyBuf;
  }

  const triangles = Math.floor(posAttr.count / 3);
  const bufferSize = 80 + 4 + triangles * 50;
  const arrayBuffer = new ArrayBuffer(bufferSize);
  const dataView = new DataView(arrayBuffer);

  // 80-byte header
  const header = headerTitle.slice(0, 79);
  for (let i = 0; i < 80; i++) {
    dataView.setUint8(i, i < header.length ? header.charCodeAt(i) : 0);
  }

  // 4-byte uint32 triangle count
  dataView.setUint32(80, triangles, true);

  let offset = 84;
  const vA = new THREE.Vector3();
  const vB = new THREE.Vector3();
  const vC = new THREE.Vector3();
  const normal = new THREE.Vector3();

  for (let i = 0; i < posAttr.count; i += 3) {
    vA.fromBufferAttribute(posAttr, i).multiplyScalar(scale);
    vB.fromBufferAttribute(posAttr, i + 1).multiplyScalar(scale);
    vC.fromBufferAttribute(posAttr, i + 2).multiplyScalar(scale);

    // Compute Face Normal
    normal.subVectors(vB, vA).cross(new THREE.Vector3().subVectors(vC, vA)).normalize();

    // Normal (float32 x 3)
    dataView.setFloat32(offset, normal.x, true);
    dataView.setFloat32(offset + 4, normal.y, true);
    dataView.setFloat32(offset + 8, normal.z, true);
    offset += 12;

    // Vertex 1
    dataView.setFloat32(offset, vA.x, true);
    dataView.setFloat32(offset + 4, vA.y, true);
    dataView.setFloat32(offset + 8, vA.z, true);
    offset += 12;

    // Vertex 2
    dataView.setFloat32(offset, vB.x, true);
    dataView.setFloat32(offset + 4, vB.y, true);
    dataView.setFloat32(offset + 8, vB.z, true);
    offset += 12;

    // Vertex 3
    dataView.setFloat32(offset, vC.x, true);
    dataView.setFloat32(offset + 4, vC.y, true);
    dataView.setFloat32(offset + 8, vC.z, true);
    offset += 12;

    // 2-byte attribute byte count
    dataView.setUint16(offset, 0, true);
    offset += 2;
  }

  return arrayBuffer;
}

/**
 * Triggers a browser download for a single binary STL
 */
export function downloadBinarySTL(
  geometry: THREE.BufferGeometry,
  filename: string,
  scale: number = 1.0
): void {
  const arrayBuffer = generateBinaryStlBuffer(geometry, `KatPrint STL - ${filename}`, scale);
  const blob = new Blob([arrayBuffer], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.stl') ? filename : `${filename}.stl`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Calculates the total number of physical printable pieces, summing (quantity || 1) across all parts.
 */
export function getPhysicalPieceCount(parts: ExecutedModelPart[] | undefined | null): number {
  if (!parts || parts.length === 0) return 1;
  return parts.reduce((sum, p) => sum + Math.max(1, p.quantity || 1), 0);
}

/**
 * Checks if the model consists of multiple physical pieces (either multiple parts or single part with quantity > 1).
 */
export function hasMultiplePhysicalPieces(parts: ExecutedModelPart[] | undefined | null): boolean {
  return getPhysicalPieceCount(parts) > 1;
}

export interface ExecutedPartValidationResult {
  valid: boolean;
  invalidParts: Array<{ partId: string; partName: string; reason: string }>;
}

export function validateExecutedModelParts(parts: ExecutedModelPart[] | undefined | null): ExecutedPartValidationResult {
  const invalidParts: ExecutedPartValidationResult['invalidParts'] = [];
  for (const part of parts || []) {
    const pos = part.geometry?.getAttribute?.('position');
    const stats = part.stats;
    let reason = '';
    if (!pos || pos.count <= 0) reason = 'has no mesh triangles';
    else if (!stats || stats.triangleCount <= 0) reason = 'has no mesh triangles';
    else if (!Number.isFinite(stats.volumeMm3) || stats.volumeMm3 <= 0) reason = 'has zero or invalid volume';
    else if (!stats.isManifold || (stats.nonManifoldEdgeCount ?? 0) > 0) reason = 'is non-manifold';
    else {
      for (let i = 0; i < pos.count; i++) {
        if (!Number.isFinite(pos.getX(i)) || !Number.isFinite(pos.getY(i)) || !Number.isFinite(pos.getZ(i))) {
          reason = 'contains non-finite coordinates';
          break;
        }
      }
    }
    if (reason) invalidParts.push({ partId: part.id, partName: part.name || part.id, reason });
  }
  return { valid: invalidParts.length === 0, invalidParts };
}

/**
 * Creates a combined BufferGeometry for multi-part STL export where:
 * 1. Each part (and each quantity instance) is an independent, disconnected triangle shell.
 * 2. Each part instance is translated so its bottom is on Z=0 (min Z = 0).
 * 3. Each part instance is spaced along the X-axis (with spacingMm = 10mm gap between bounding boxes) so no shells intersect/overlap.
 * 4. Triangles are appended together without boolean union.
 * 5. When opened in slicers (Bambu Studio, OrcaSlicer, PrusaSlicer, Cura), clicking 'Split to Objects' separates each piece cleanly.
 */
export function createMultiPartExportGeometry(
  parts: ExecutedModelPart[],
  spacingMm: number = 10,
  scale: number = 1.0
): THREE.BufferGeometry {
  if (!parts || parts.length === 0) {
    return new THREE.BufferGeometry();
  }

  // If single part with 1 quantity, position its min Z at 0
  if (parts.length === 1 && (parts[0].quantity || 1) === 1) {
    const geom = parts[0].geometry.clone();
    geom.computeBoundingBox();
    if (geom.boundingBox) {
      const minZ = geom.boundingBox.min.z;
      geom.translate(0, 0, -minZ);
    }
    return geom;
  }

  const allPositions: number[] = [];
  const allNormals: number[] = [];

  let currentXOffset = 0;

  for (const part of parts) {
    const qty = Math.max(1, part.quantity || 1);
    const srcGeom = part.geometry;
    srcGeom.computeBoundingBox();
    const box = srcGeom.boundingBox || new THREE.Box3();
    const width = Math.max(0.1, box.max.x - box.min.x);
    const centerY = (box.min.y + box.max.y) / 2;
    const minZ = box.min.z;

    for (let i = 0; i < qty; i++) {
      const posAttr = srcGeom.getAttribute('position');
      const normAttr = srcGeom.getAttribute('normal');

      if (!posAttr) continue;

      const translateX = currentXOffset - box.min.x;
      const translateY = -centerY; // center along Y=0
      const translateZ = -minZ; // place flat on Z=0

      for (let v = 0; v < posAttr.count; v++) {
        const x = posAttr.getX(v) + translateX;
        const y = posAttr.getY(v) + translateY;
        const z = posAttr.getZ(v) + translateZ;
        allPositions.push(x, y, z);

        if (normAttr) {
          allNormals.push(normAttr.getX(v), normAttr.getY(v), normAttr.getZ(v));
        } else {
          allNormals.push(0, 0, 1);
        }
      }

      currentXOffset += width + spacingMm;
    }
  }

  const exportGeom = new THREE.BufferGeometry();
  if (allPositions.length > 0) {
    exportGeom.setAttribute('position', new THREE.Float32BufferAttribute(allPositions, 3));
    exportGeom.setAttribute('normal', new THREE.Float32BufferAttribute(allNormals, 3));
    exportGeom.computeBoundingBox();
    exportGeom.computeBoundingSphere();
  }

  return exportGeom;
}

/**
 * Downloads a single STL file for the model.
 * If the model has multiple parts, exports all pieces as separate disconnected shells placed on Z=0 with 10mm spacing.
 * If single part, exports with base on Z=0.
 */
export function downloadExportSTL(
  activeGeometry: THREE.BufferGeometry | null,
  parts: ExecutedModelPart[] | undefined,
  filename: string,
  scale: number = 1.0,
  spacingMm: number = 10
): void {
  let exportGeom: THREE.BufferGeometry | null = null;
  if (parts && (parts.length > 1 || (parts[0]?.quantity || 1) > 1)) {
    exportGeom = createMultiPartExportGeometry(parts, spacingMm, scale);
  } else if (activeGeometry) {
    exportGeom = activeGeometry.clone();
    exportGeom.computeBoundingBox();
    if (exportGeom.boundingBox) {
      const minZ = exportGeom.boundingBox.min.z;
      exportGeom.translate(0, 0, -minZ);
    }
  }

  if (!exportGeom) return;

  const arrayBuffer = generateBinaryStlBuffer(exportGeom, `KatPrint STL - ${filename}`, scale);
  const blob = new Blob([arrayBuffer], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.stl') ? filename : `${filename}.stl`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export interface MultiPartZipPackageOptions {
  projectName: string;
  versionLabel?: string;
  parts: ExecutedModelPart[];
  combinedGeometry?: THREE.BufferGeometry | null;
  assemblyDef?: ModelAssemblyDefinition | null;
  scale?: number;
  filamentType?: string;
  printerName?: string;
}

/**
 * Creates a comprehensive multi-part STL ZIP bundle with individual STLs, assembled STL, BOM, and print guide
 */
export async function packageMultiPartZip(options: MultiPartZipPackageOptions): Promise<Blob> {
  const {
    projectName,
    versionLabel = 'V1',
    parts,
    combinedGeometry,
    assemblyDef,
    scale = 1.0,
    filamentType = 'PLA',
    printerName = 'Bambu Lab X1-Carbon',
  } = options;

  const zip = new JSZip();
  const safeProjectName = (projectName || 'katprint_model').replace(/[^a-zA-Z0-9_-]/g, '_');
  const folder = zip.folder(`${safeProjectName}_${versionLabel}_STLs`) || zip;

  let totalVolumeCm3 = 0;
  let totalWeightGrams = 0;
  const partsBOM: Array<{
    filename: string;
    partName: string;
    quantity: number;
    dimensionsMm: string;
    volumeCm3: number;
    weightGrams: number;
    needsSupport: boolean;
  }> = [];

  // 1. Add individual part STLs
  parts.forEach((part, idx) => {
    const safePartName = (part.name || part.id || `part_${idx + 1}`).replace(/[^a-zA-Z0-9_-]/g, '_');
    const filename = `${String(idx + 1).padStart(2, '0')}_${safePartName}.stl`;
    const stlBuffer = generateBinaryStlBuffer(part.geometry, `KatPrint Part: ${part.name}`, scale);
    folder.file(filename, stlBuffer);

    const dims = part.stats?.dimensions || { x: 0, y: 0, z: 0 };
    const scaledDims = `${(dims.x * scale).toFixed(1)} × ${(dims.y * scale).toFixed(1)} × ${(dims.z * scale).toFixed(1)} mm`;
    const vol = (part.stats?.volumeCm3 || 0) * Math.pow(scale, 3);
    const weight = (part.stats?.estimatedWeightGrams || 0) * Math.pow(scale, 3) * (part.quantity || 1);
    totalVolumeCm3 += vol * (part.quantity || 1);
    totalWeightGrams += weight;

    partsBOM.push({
      filename,
      partName: part.name || part.id,
      quantity: part.quantity || 1,
      dimensionsMm: scaledDims,
      volumeCm3: vol,
      weightGrams: weight,
      needsSupport: !!part.requiresSupports,
    });
  });

  // 2. Add combined assembled STL if available
  if (combinedGeometry) {
    const assembledBuffer = generateBinaryStlBuffer(combinedGeometry, `KatPrint Assembly - ${projectName}`, scale);
    folder.file(`00_FULL_ASSEMBLY_REFERENCE.stl`, assembledBuffer);
  }

  // 3. Generate Markdown Assembly Guide & Bill of Materials
  let readme = `# ${projectName} (${versionLabel}) - Multi-Part 3D Print Package

Generated by **KatPrint 3D (CAD & Slicer Co-Pilot)**
- **Scale Factor**: ${scale}x (${scale === 1 ? '100% full scale' : `${(scale * 100).toFixed(0)}%`})
- **Target Printer**: ${printerName}
- **Target Filament**: ${filamentType}
- **Total Print Volume**: ${totalVolumeCm3.toFixed(2)} cm³
- **Total Estimated Filament**: ${totalWeightGrams.toFixed(1)} g

---

## 📦 Bill of Materials & Part Checklist

| # | File Name | Part Name | Qty | Dimensions (X×Y×Z) | Approx Weight | Supports |
|---|---|---|---|---|---|---|
`;

  partsBOM.forEach((p, i) => {
    readme += `| ${i + 1} | \`${p.filename}\` | **${p.partName}** | ${p.quantity}x | ${p.dimensionsMm} | ${(p.weightGrams).toFixed(1)} g | ${p.needsSupport ? '⚠️ Required' : '✅ None'} |\n`;
  });

  readme += `
---

## 🛠️ Assembly Instructions & Mating Relationships

`;

  if (assemblyDef && assemblyDef.relationships && assemblyDef.relationships.length > 0) {
    readme += `### Defined Part Relationships:\n`;
    assemblyDef.relationships.forEach((rel, i) => {
      const src = rel.sourcePartId || rel.partAId || 'Part A';
      const tgt = rel.targetPartId || rel.partBId || 'Part B';
      const desc = rel.description || rel.notes || rel.type;
      readme += `${i + 1}. **${src}** ➡️ **${tgt}** (${rel.type})\n`;
      readme += `   - Description: ${desc}\n`;
      if (rel.clearanceMm !== undefined) {
        readme += `   - Designed Clearance / Tolerance: **${rel.clearanceMm} mm**\n`;
      }
    });
    readme += '\n';
  } else {
    readme += `This multi-part model includes all mating components for full assembly. Print each part in the quantities specified above.\n\n`;
  }

  readme += `## 🖨️ Slicing & Printing Recommendations
1. **Layer Height**: 0.20mm Standard (0.16mm for fine threads or mating snap joints).
2. **Infill**: 15%–25% Gyroid or Cross-Hatch for balanced strength.
3. **Wall Loops / Perimeters**: 3–4 walls for mechanical durability.
4. **Bed Adhesion**: Use a clean PEI textured sheet or smooth plate with standard brim if contact area is small.
5. **Clearance Fit**: Parts have built-in FDM engineering tolerances (0.2–0.4mm) for seamless fit.

---
*Created with KatPrint 3D*
`;

  folder.file('ASSEMBLY_GUIDE.md', readme);

  // 4. Generate JSON manifest
  const manifest = {
    projectName,
    version: versionLabel,
    exportedAt: new Date().toISOString(),
    scale,
    totalParts: parts.length,
    totalQuantity: parts.reduce((acc, p) => acc + (p.quantity || 1), 0),
    totalVolumeCm3,
    totalWeightGrams,
    parts: partsBOM,
    relationships: assemblyDef?.relationships || [],
  };

  folder.file('assembly_manifest.json', JSON.stringify(manifest, null, 2));

  return await zip.generateAsync({ type: 'blob' });
}

/**
 * Generates and downloads the multi-part ZIP bundle directly in the browser
 */
export async function downloadMultiPartZip(options: MultiPartZipPackageOptions): Promise<void> {
  const blob = await packageMultiPartZip(options);
  const safeProjectName = (options.projectName || 'katprint_model').replace(/[^a-zA-Z0-9_-]/g, '_');
  const filename = `${safeProjectName}_${options.versionLabel || 'V1'}_multi_part_STLs.zip`;
  
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
