import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import * as THREE from 'three';
import {
  Printer,
  Flame,
  Layers,
  FileCode,
  Download,
  Upload,
  Droplets,
  Activity,
  Sliders,
  Settings,
  HelpCircle,
  Maximize2,
  Box,
  Image as ImageIcon,
  Camera,
  Cpu,
  ShieldCheck,
  FolderKanban,
  History,
  MessageSquare,
  Package,
  HardDrive,
  FlaskConical,
  GitBranch,
  Edit2,
  Check,
  X,
  Plus,
  Boxes,
  LayoutGrid,
  Loader2,
  Wand2,
  Bookmark,
} from 'lucide-react';

import {
  GenerationRecord,
  PrintResult,
  CadExample,
} from './types';
import { PrintResultModal } from './components/PrintResultModal';
import { GenerationHistoryModal } from './components/GenerationHistoryModal';
import { ExampleLibraryModal } from './components/ExampleLibraryModal';

import {
  PrinterSpec,
  FilamentSpec,
  ModelGeometryStats,
  PrinterFitResult,
  SlicerSettings,
  CreationMode,
  GenerationPipelineStage,
  ExtractedRequirements,
  DesignConcept,
  DesignValidationReport,
  GenerationError,
  GenerationDiagnostics,
  DesignSpecification,
  DesignCheck,
  FidelityReviewResult,
  GenerationMode,
  AIRequestRecord,
  ExecutedModelPart,
  ProjectReferenceImage,
  PrintabilityReport,
  DesignIntentAudit,
  RequirementCoverageReport,
  SemanticFeaturePlan,
  ProjectDesignState,
  PrecisionReviewProblem,
  ReferenceImageObservation,
} from './types';

import {
  KatPrintProject,
  ModelVersion,
  DesignConversationMessage,
  DesignChangeSet,
} from './projects/projectTypes';
import { projectRepository } from './projects/projectRepository';
import {
  createDefaultProject,
  createBlankProject,
  inferProjectName,
  getNextVersionNumber,
  createVersionLabel,
  duplicateProjectGraph,
  buildModelVersion,
} from './projects/projectService';
import {
  updateProjectMemoryFromVersion,
  initializeProjectDesignState,
  mergeDesignStateWithSpecification,
  partitionCachedReferenceImages,
  mergeReferenceImageObservations,
  attachObservationsToReferenceImages,
} from './projects/projectMemory';
import { buildGenerationDiagnostics } from './projects/generationDiagnostics';
import {
  applyRevisionToProject,
  applyDirectParameterUpdateToProject,
  applyBoundParameterChangesToProject,
  restoreVersionAsNewHead,
  branchNewVersion,
  parseRevisionInstruction,
} from './projects/revisionEngine';
import { exportProjectPackage } from './projects/projectSerializer';
import { sanitizeStlFilename } from './versions/versionService';
import {
  SemanticFeatureModel,
  planSemanticFeatureModel,
  planSemanticFeatureModelFromPlan,
  evaluateSemanticPlanCoverage,
  verifySemanticFeatureModel,
  finalizeFeatureModelForCode,
  reconstructLegacyFeatureModel,
  toggleParameterLock,
  shouldGenerateMultipleSemanticPlans,
  ManipulatorType,
  SemanticRevisionOpType,
} from './features';

import { FILAMENTS } from './data/filaments';
import { FIT_COUPON_JSCAD } from './engine/fitCoupon';
import { saveStoredPrinterOverride } from './storage/printerStorage';
import { analyzeBufferGeometry, exportBinarySTL } from './engine/geometryUtils';
import { getPhysicalPieceCount, hasMultiplePhysicalPieces, validateExecutedModelParts, downloadExportSTL } from './engine/stlExporter';
import { computeSlicerSettings, exportGCodeFile } from './engine/slicerEngine';
import { useModelState } from './hooks/useModelState';
import { useGeneration } from './hooks/useGeneration';
import { useProjectState } from './hooks/useProjectState';
import { useModals } from './hooks/useModals';
import { runPrintabilityAnalysisAsync } from './engine/clientPrintability';
import { executeJscadCode, executeJscadModel, DEFAULT_PLANTER_JSCAD } from './engine/jscadRunner';
import { generateCadThumbnail } from './engine/designVerification/renderInspectionViews';

import { ViewerFrame } from './components/viewer/ViewerFrame';
import { LivePrinterMonitor } from './components/LivePrinterMonitor';
import { CustomPrinterModal } from './components/CustomPrinterModal';
import { FitTestModal } from './components/FitTestModal';
import { TestSuiteModal } from './components/TestSuiteModal';
import { PlateLayoutModal } from './components/assembly/PlateLayoutModal';
import { ReferencePhotosManager } from './components/ReferencePhotosManager';

// Phase 2 UI Components
import { ProjectLibrary } from './components/projects/ProjectLibrary';
import { VersionComparisonModal } from './components/projects/VersionComparisonModal';
import { ProposedChangesModal } from './components/projects/ProposedChangesModal';
import { StorageManagementModal } from './components/projects/StorageManagementModal';
import { LeftPanel } from './components/panels/LeftPanel';
import { RightPanel } from './components/panels/RightPanel';
import { Header } from './components/layout/Header';
import { ProjectPipelineStepper, PipelineStageName } from './components/layout/ProjectPipelineStepper';
import { CameraCaptureModal, CapturedPhotoData } from './components/camera/CameraCaptureModal';

export default function App() {
  // Navigation: Workspace vs Project Library
  const [navView, setNavView] = useState<'workspace' | 'projects'>('workspace');
  const [mobileTab, setMobileTab] = useState<'create' | 'viewer' | 'assistant' | 'print' | 'projects'>('create');
  const [rightPanelTab, setRightPanelTab] = useState<'design' | 'print' | 'versions'>('design');
  const [designPanelMode, setDesignPanelMode] = useState<'assistant' | 'feature'>('assistant');
  const [isHeaderMenuOpen, setIsHeaderMenuOpen] = useState(false);

  // Mode Selection
  const [mode, setMode] = useState<CreationMode>('describe');

  // Model State (Parts, Scale, Printer, Filament, Watertight, Fit)
  const model = useModelState();

  // Projects State & Persistence Hook
  const project = useProjectState();

  // Modals
  const { activeModal, openModal, closeModal } = useModals();

  // Proposed Changes Modal
  const [proposedChangeSet, setProposedChangeSet] = useState<DesignChangeSet | null>(null);
  const [pendingRevisionInstruction, setPendingRevisionInstruction] = useState<string | null>(null);
  const [isCameraModalOpen, setIsCameraModalOpen] = useState(false);
  const [experienceMode, setExperienceMode] = useState<'quick' | 'advanced'>('quick');

  // Multi-Part Assembly State
  const [explodedOffset, setExplodedOffset] = useState<number>(0);
  const [partVisibility, setPartVisibility] = useState<Record<string, boolean>>({});
  const [selectedPartId, setSelectedPartId] = useState<string | null>(null);

  const [selectedRecordForModal, setSelectedRecordForModal] = useState<GenerationRecord | null>(null);
  const [hasExportedStl, setHasExportedStl] = useState(false);

  const [printerCardCollapsed, setPrinterCardCollapsed] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('kf.printerCardCollapsed');
      if (saved !== null) return JSON.parse(saved);
      return typeof window !== 'undefined' ? window.innerWidth < 1024 : false;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('kf.printerCardCollapsed', JSON.stringify(printerCardCollapsed));
    } catch {
      // ignore
    }
  }, [printerCardCollapsed]);

  const [highlightOverhangs, setHighlightOverhangs] = useState<boolean>(true);

  // STL Export Generation State
  const [stlExportProgress, setStlExportProgress] = useState<number | null>(null);

  // Semantic 3D Feature Selection
  const [selectedFeatureId, setSelectedFeatureId] = useState<string | null>(null);
  const [selectedFeatureIds, setSelectedFeatureIds] = useState<string[]>([]);
  const [debugShowPickProxies, setDebugShowPickProxies] = useState<boolean>(false);
  const [focusTarget, setFocusTarget] = useState<{ featureId: string; nonce: number } | null>(null);

  const handleSelectFeature = useCallback((featureId: string | null) => {
    setSelectedFeatureId(featureId);
    setSelectedFeatureIds(featureId ? [featureId] : []);
    if (featureId) {
      // Auto-open features tab to display parameters immediately upon 3D click
      setRightPanelTab('design');
      setDesignPanelMode('feature');
    }
  }, []);

  const handleMultiSelectFeatures = useCallback((featureIds: string[]) => {
    setSelectedFeatureIds(featureIds);
    setSelectedFeatureId(featureIds[featureIds.length - 1] || null);
    if (featureIds.length > 0) {
      setRightPanelTab('design');
      setDesignPanelMode('feature');
    }
  }, []);

  const handleFocusFeature = useCallback((featureId: string) => {
    setFocusTarget({ featureId, nonce: Date.now() });
  }, []);

  // Left panel scroll affordance fade state
  const leftPanelScrollRef = useRef<HTMLDivElement>(null);
  const [showLeftPanelScrollFade, setShowLeftPanelScrollFade] = useState<boolean>(false);

  const slicerSettingsRef = useRef<SlicerSettings>();

  // Generation Hook: encapsulates entire CAD generation, revision, review, repair, and logging pipeline
  const generation = useGeneration({
    model,
    activeProject: project.activeProject,
    referenceImages: project.referenceImages,
    currentActiveVersion: project.currentActiveVersion,
    viewingVersionId: project.viewingVersionId,
    selectedFeatureId,
    selectedFeatureIds,
    setMobileTab,
    setViewingVersionId: project.setViewingVersionId,
    setEditableTitle: project.setEditableTitle,
    setRightPanelTab,
    setHasExportedStl,
    recordNewVersion: project.recordNewVersion,
    persistActiveProject: project.persistActiveProject,
    getSlicerSettings: () => slicerSettingsRef.current,
    setProposedChangeSet,
    setPendingRevisionInstruction,
    handleCreateBlankProject: async (name) => {
      await project.handleCreateBlankProject(name);
    },
  });

  const {
    currentJscadCode,
    setCurrentJscadCode,
    activeGeometry,
    setActiveGeometry,
    modelName,
    setModelName,
    isGeneratingCad,
    setIsGeneratingCad,
    isRevisingCad,
    setIsRevisingCad,
    isFixingFeatures,
    setIsFixingFeatures,
    pipelineStage,
    setPipelineStage,
    repairAttempt,
    setRepairAttempt,
    generationStatusText,
    setGenerationStatusText,
    cadErrorMessage,
    setCadErrorMessage,
    generationError,
    setGenerationError,
    generationDiagnostics,
    setGenerationDiagnostics,
    generationId,
    setGenerationId,
    currentGenerationId,
    setCurrentGenerationId,
    activeGeometryGenerationId,
    setActiveGeometryGenerationId,
    lastGenerationStatus,
    setLastGenerationStatus,
    cadSource,
    setCadSource,
    lastPrompt,
    setLastPrompt,
    extractedRequirements,
    setExtractedRequirements,
    validationReport,
    setValidationReport,
    skipSpecReview,
    setSkipSpecReview,
    handleToggleSkipSpecReview,
    isReviewingSpec,
    setIsReviewingSpec,
    isRegeneratingSpec,
    setIsRegeneratingSpec,
    pendingSpecPrompt,
    setPendingSpecPrompt,
    exploreApproaches,
    setExploreApproaches,
    handleToggleExploreApproaches,
    isSelectingConcept,
    setIsSelectingConcept,
    conceptVariants,
    setConceptVariants,
    pendingConceptReqs,
    pendingConceptPrompt,
    designSpecification,
    setDesignSpecification,
    designChecklist,
    setDesignChecklist,
    fidelityReviewResult,
    setFidelityReviewResult,
    slicerExplanation,
    setSlicerExplanation,
    isExplainingSlicer,
    setIsExplainingSlicer,
    printabilityReport,
    setPrintabilityReport,
    isAnalyzingPrintability,
    setIsAnalyzingPrintability,
    generationRecords,
    setGenerationRecords,
    currentGenerationRecord,
    setCurrentGenerationRecord,
    recordSuccessfulGeneration,
    handleSavePrintResult,
    handleReopenRecord,
    handleLoadLibraryExample,
    handleGenerateJscad,
    executeCadGenerationPipeline,
    executeDirectRevision,
    handleConversationalRevision,
    handleFixMissingFeatures,
    handleTargetedRepair,
    handleRetryLastPrompt,
    handleExplainSlicerSettings,
    triggerConceptVariantStage,
    handleSelectConcept,
    handleCustomApproach,
    handleSkipConceptSelection,
    handleConfirmSpecAndGenerate,
    handleRegenerateSpec,
    handleClearJob: genClearJob,
    activateVersionGeometry,
  } = generation;

  useEffect(() => {
    const el = leftPanelScrollRef.current;
    if (!el) return;

    let rafId: number | null = null;

    const checkScroll = () => {
      if (rafId !== null) return;
      rafId = requestAnimationFrame(() => {
        rafId = null;
        if (!el) return;
        const hasOverflow = el.scrollHeight > el.clientHeight + 4;
        const isAtBottom = el.scrollHeight - el.scrollTop - el.clientHeight <= 8;
        setShowLeftPanelScrollFade(hasOverflow && !isAtBottom);
      });
    };

    checkScroll();
    el.addEventListener('scroll', checkScroll, { passive: true });

    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => checkScroll());
      ro.observe(el);
    }

    return () => {
      if (rafId !== null) cancelAnimationFrame(rafId);
      el.removeEventListener('scroll', checkScroll);
      if (ro) ro.disconnect();
    };
  }, [navView, mode, isReviewingSpec, isSelectingConcept, printerCardCollapsed, currentJscadCode, project.activeProject]);

  // Centralized project activation & geometry validation
  const activateProject = useCallback(
    (proj: KatPrintProject) => {
      if (!proj) return;
      project.activateProject(proj);
      project.setEditableTitle(proj.name);
      setModelName(proj.name);
      project.setViewingVersionId(null);

      // Validate & restore hardware configuration
      if (proj.projectSettings) {
        const validPrinter = model.printers.some((p) => p.id === proj.projectSettings.printerId);
        const targetPrinterId = validPrinter ? proj.projectSettings.printerId : 'bambu-x1c';
        model.setSelectedPrinterId(targetPrinterId);

        const validFilament = FILAMENTS.some((f) => f.id === proj.projectSettings.filamentId);
        const targetFilamentId = validFilament ? proj.projectSettings.filamentId : 'pla';
        model.setSelectedFilamentId(targetFilamentId);

        if (typeof proj.projectSettings.scaleFactor === 'number') {
          model.setScaleFactor(proj.projectSettings.scaleFactor);
        }
        if (typeof proj.projectSettings.mustHoldLiquid === 'boolean') {
          model.setMustHoldLiquid(proj.projectSettings.mustHoldLiquid);
        }
      }

      const versions = proj.versions || [];
      const currentVer =
        versions.find((v) => v.id === proj.currentVersionId) || versions[versions.length - 1];
      if (currentVer) {
        activateVersionGeometry(currentVer, { head: true });
      }
    },
    [project, model, activateVersionGeometry, setModelName]
  );

  // Update active project's generation mode and persist
  const handleGenerationModeChange = async (newMode: GenerationMode) => {
    await project.handleGenerationModeChange(newMode);
  };

  // Sync 3D geometry when project or active version loads/changes
  useEffect(() => {
    if (project.currentActiveVersion) {
      activateVersionGeometry(project.currentActiveVersion, {
        head: !project.viewingVersionId || project.viewingVersionId === project.activeProject?.currentVersionId,
      });
    }
  }, [project.currentActiveVersion?.id, project.viewingVersionId, activateVersionGeometry, project.activeProject?.currentVersionId]);

  useEffect(() => {
    if (project.activeProject) {
      setModelName(project.activeProject.name);
      if (project.activeProject.projectSettings) {
        const ps = project.activeProject.projectSettings;
        if (ps.printerId && model.printers.some((p) => p.id === ps.printerId)) {
          model.setSelectedPrinterId(ps.printerId);
        }
        if (ps.filamentId) {
          model.setSelectedFilamentId(ps.filamentId);
        }
        if (typeof ps.scaleFactor === 'number') {
          model.setScaleFactor(ps.scaleFactor);
        }
        if (typeof ps.mustHoldLiquid === 'boolean') {
          model.setMustHoldLiquid(ps.mustHoldLiquid);
        }
      }
    }
  }, [project.activeProject?.id, model, setModelName]);

  // Reconcile 3D feature selection when active version or feature model changes
  useEffect(() => {
    const featModel = project.currentActiveVersion?.featureModel;
    if (!featModel || !Array.isArray(featModel.features)) {
      if (selectedFeatureId !== null) setSelectedFeatureId(null);
      if (selectedFeatureIds.length > 0) setSelectedFeatureIds([]);
      return;
    }

    const validFeatureIds = new Set(featModel.features.map((f) => f.id));
    const nextSelectedIds = selectedFeatureIds.filter((id) => validFeatureIds.has(id));
    const isPrimaryValid = selectedFeatureId ? validFeatureIds.has(selectedFeatureId) : false;
    const nextPrimaryId = isPrimaryValid
      ? selectedFeatureId
      : nextSelectedIds.length > 0
      ? nextSelectedIds[nextSelectedIds.length - 1]
      : null;

    if (
      nextSelectedIds.length !== selectedFeatureIds.length ||
      nextPrimaryId !== selectedFeatureId
    ) {
      setSelectedFeatureIds(nextSelectedIds);
      setSelectedFeatureId(nextPrimaryId);
    }
  }, [project.currentActiveVersion?.id, project.currentActiveVersion?.featureModel, selectedFeatureId, selectedFeatureIds]);

  // Volumetric & Overhang stats
  const geometryStats: ModelGeometryStats = useMemo(() => {
    if (!activeGeometry) {
      return {
        dimensions: { x: 0, y: 0, z: 0 },
        volumeMm3: 0,
        volumeCm3: 0,
        surfaceAreaMm2: 0,
        estimatedWeightGrams: 0,
        triangleCount: 0,
        vertexCount: 0,
        nonManifoldEdgeCount: 0,
        overhangRatio: 0,
        minWallThicknessMm: 0,
        isManifold: false,
        footprintAreaMm2: 0,
        heightToWidthRatio: 0,
        hasSteepOverhangs: false,
      };
    }
    return analyzeBufferGeometry(activeGeometry, model.selectedFilament.densityGcm3);
  }, [activeGeometry, model.selectedFilament.densityGcm3]);

  // Synchronize geometry stats to model state for live printer fit check
  useEffect(() => {
    model.setGeometryStats(geometryStats);
  }, [geometryStats, model.setGeometryStats]);

  // Slicer Settings Engine
  const slicerSettings: SlicerSettings = useMemo(() => {
    return computeSlicerSettings(
      geometryStats,
      model.selectedPrinter,
      model.selectedFilament,
      model.scaleFactor,
      model.mustHoldLiquid,
      printabilityReport || undefined
    );
  }, [geometryStats, model.selectedPrinter, model.selectedFilament, model.scaleFactor, model.mustHoldLiquid, printabilityReport]);

  slicerSettingsRef.current = slicerSettings;

  // Centralized Export Validation Guard
  const exportValidation = useMemo(() => {
    if (!activeGeometry && (!model.currentParts || model.currentParts.length === 0)) {
      return { allowed: false, reason: 'No active 3D model geometry loaded.' };
    }
    if (isGeneratingCad || isRevisingCad) {
      return {
        allowed: false,
        reason: 'Generation in progress — export will be available once rendering completes.',
      };
    }
    const hasParts = model.currentParts && model.currentParts.length > 0;
    const triangles = geometryStats?.triangleCount || 0;
    if (!hasParts && triangles <= 0) {
      return { allowed: false, reason: 'Model has no mesh polygons/triangles.' };
    }
    if (hasMultiplePhysicalPieces(model.currentParts)) {
      const partValidation = validateExecutedModelParts(model.currentParts);
      if (!partValidation.valid && (!activeGeometry || (geometryStats?.triangleCount || 0) <= 0)) {
        const first = partValidation.invalidParts[0];
        return {
          allowed: false,
          reason: `STL export blocked: ${first?.partName || 'A part'} ${first?.reason || 'is invalid'}.`,
        };
      }
    }
    return { allowed: true, reason: '' };
  }, [activeGeometry, geometryStats, isGeneratingCad, isRevisingCad, model.currentParts]);

  const handleLogResultForRecord = useCallback(
    (record: GenerationRecord) => {
      setSelectedRecordForModal(record);
      openModal('printResult');
    },
    [openModal]
  );

  // Handle Natural Language Undo / Rollback
  const handleRollbackLastRevision = async () => {
    const restored = await project.handleRollbackLastRevision();
    if (restored) {
      activateVersionGeometry(restored, { head: true });
    }
  };

  // Handle Direct 3D Manipulation Commits (dragging gizmos, hole dragging, spacing adjustments)
  const handleManipulationCommit = async (params: {
    featureId: string;
    featureIds?: string[];
    manipulatorId: string;
    manipulatorType: ManipulatorType;
    parameterChanges: Array<{
      parameterId: string;
      newValue: number | string | boolean;
      oldValue?: number | string | boolean;
      unit?: string;
    }>;
    instructionSummary?: string;
  }) => {
    const outcome = await project.handleManipulationCommit({
      ...params,
      selectedFilamentDensity: model.selectedFilament.densityGcm3,
    });
    if (outcome?.newVersion) {
      const geomRes = activateVersionGeometry(outcome.newVersion, { head: true });
      if (!geomRes.success) {
        setLastGenerationStatus('error');
      }
    }
  };

  // Restore previous version (Non-destructive new head)
  const handleRestoreVersion = async (version: ModelVersion) => {
    const newHead = await project.handleRestoreVersion(version);
    if (newHead) {
      activateVersionGeometry(newHead, { head: true });
    }
  };

  // Branch new version from an existing version
  const handleBranchVersion = async (version: ModelVersion) => {
    const newBranch = await project.handleBranchVersion(version);
    if (newBranch) {
      activateVersionGeometry(newBranch, { head: true });
    }
  };

  // Return to Head version
  const handleReturnToHead = useCallback(() => {
    const head = project.handleReturnToHead();
    if (head) {
      activateVersionGeometry(head, { head: true });
    }
  }, [project, activateVersionGeometry]);

  // Inspect previous version in 3D viewer without changing head
  const handleSelectVersionForViewing = (version: ModelVersion) => {
    project.handleSelectVersionForViewing(version);
    activateVersionGeometry(version, { head: false });
  };

  // Version Comparison modal
  const handleCompareVersions = (versionA: ModelVersion, versionB: ModelVersion) => {
    project.handleCompareVersions(versionA, versionB);
    openModal('comparison');
  };

  // Rename a specific version's label
  const handleRenameVersionLabel = async (versionId: string, newLabel: string) => {
    await project.handleRenameVersionLabel(versionId, newLabel);
  };

  // Export STL for a specific version in timeline
  const handleExportVersionStl = (version: ModelVersion) => {
    project.handleExportVersionStl(version, model.scaleFactor);
  };

  // View diagnostics & fidelity details for a specific version
  const handleViewVersionDiagnostics = (version: ModelVersion) => {
    if (version.generationDiagnostics) {
      setGenerationDiagnostics(version.generationDiagnostics);
    }
    if (version.fidelityReview) {
      setFidelityReviewResult(version.fidelityReview);
    }
    if (version.designSpecification) {
      setDesignSpecification(version.designSpecification);
    }
    if (version.designChecklist) {
      setDesignChecklist(version.designChecklist);
    }
    handleSelectVersionForViewing(version);
    setRightPanelTab('print');
  };

  // Create brand new project from user prompt
  const handleCreateNewProject = async (prompt: string, customName?: string) => {
    const promptText = prompt.trim() || '100 mm × 60 mm × 25 mm electronics enclosure with 3 mm walls and removable top lid';
    const newProj = createDefaultProject(promptText);
    if (customName && customName.trim()) {
      newProj.name = customName.trim();
    }

    await projectRepository.saveProject(newProj);
    const all = await projectRepository.listProjects();
    project.setProjects(all);
    activateProject(newProj);
    setNavView('workspace');

    // Generate initial CAD for the new project passing targetProject directly to avoid race conditions
    handleGenerateJscad(promptText, {
      mode: newProj.projectSettings?.generationMode || 'precision',
      targetProject: newProj,
    });
  };

  // Clear previous job / reset workspace for fresh design
  const handleClearJob = async () => {
    setSelectedFeatureId(null);
    setSelectedFeatureIds([]);
    setProposedChangeSet(null);
    project.setViewingVersionId(null);
    await genClearJob();
  };

  // Create empty / blank project without initial AI generation
  const handleCreateBlankProject = async (customName?: string) => {
    const blank = await project.handleCreateBlankProject(customName);
    activateProject(blank);
    setNavView('workspace');
    setMobileTab('create');
  };

  // Select project from library
  const handleSelectProject = (proj: KatPrintProject) => {
    if (!proj) return;
    activateProject(proj);
    setNavView('workspace');
    setMobileTab('viewer');
  };

  // Update printer and persist to project settings
  const handlePrinterChange = async (printerId: string) => {
    model.setSelectedPrinterId(printerId);
    await project.handlePrinterChange(printerId);
  };

  // Update filament and persist to project settings
  const handleFilamentChange = async (filamentId: string) => {
    model.setSelectedFilamentId(filamentId);
    await project.handleFilamentChange(filamentId);
  };

  // Update scale factor and persist to project settings
  const handleScaleFactorChange = async (scale: number) => {
    model.setScaleFactor(scale);
    await project.handleScaleFactorChange(scale);
  };

  // Update watertight mode and persist to project settings
  const handleMustHoldLiquidChange = async (enabled: boolean) => {
    model.setMustHoldLiquid(enabled);
    await project.handleMustHoldLiquidChange(enabled);
  };

  // Delete project
  const handleDeleteProject = async (target: string | KatPrintProject) => {
    await project.handleDeleteProject(target);
  };

  // Duplicate project
  const handleDuplicateProject = async (proj: KatPrintProject) => {
    await project.handleDuplicateProject(proj);
  };

  // Project rename action
  const handleRenameProject = async (proj: KatPrintProject, newName: string) => {
    await project.handleRenameProject(proj, newName);
    setModelName(newName.trim() || proj.name);
  };

  // Favorite toggle
  const handleToggleFavorite = async (target: string | KatPrintProject) => {
    await project.handleToggleFavorite(target);
  };

  // Export project package archive
  const handleExportKatPrint = (proj?: KatPrintProject) => {
    project.handleExportKatPrint(proj);
  };

  // Import .katprint project package
  const handleImportKatPrint = async (fileContent: string) => {
    const imported = await project.handleImportKatPrint(fileContent);
    if (imported) {
      activateProject(imported);
      setNavView('workspace');
    }
  };

  // Save renamed title
  const handleSaveTitle = async () => {
    await project.handleSaveTitle();
    if (project.editableTitle.trim()) {
      setModelName(project.editableTitle.trim());
    }
  };

  const handleUpdateFeatureParameter = async (
    parameterId: string,
    newValue: number | string | boolean
  ) => {
    const newHead = await project.handleUpdateFeatureParameter(
      parameterId,
      newValue,
      model.selectedFilament.densityGcm3
    );
    if (newHead) {
      activateVersionGeometry(newHead, { head: true });
    }
  };

  // Reconstruct Feature Model for Legacy Versions
  const handleReconstructFeatureModel = async () => {
    await project.handleReconstructFeatureModel(currentJscadCode, geometryStats);
  };

  // Toggle Parameter Lock
  const handleToggleLockParameter = async (parameterId: string, currentLocked: boolean) => {
    await project.handleToggleLockParameter(parameterId, currentLocked);
  };

  // Code editor update
  const handleCodeUpdate = useCallback((newCode: string) => {
    const thisGenId = `gen_manual_${Date.now()}`;
    setCurrentGenerationId(thisGenId);
    setCurrentJscadCode(newCode);
    try {
      const executed = executeJscadModel(newCode);
      setActiveGeometry(executed.combinedGeometry);
      model.setCurrentParts(executed.parts || []);
      setActiveGeometryGenerationId(thisGenId);
      setLastGenerationStatus('success');
      setCadErrorMessage(null);
    } catch (err: any) {
      setLastGenerationStatus('error');
      setCadErrorMessage(err?.message || 'Syntax error in JSCAD script.');
    }
  }, []);

  // Update Reference Images for Active Project
  const handleUpdateReferenceImages = async (images: ProjectReferenceImage[]) => {
    await project.handleUpdateReferenceImages(images);
  };

  // Mode 2 & Mode 3 outputs
  const handleExternalGeometry = useCallback((geom: THREE.BufferGeometry) => {
    const thisGenId = `gen_ext_${Date.now()}`;
    setCurrentGenerationId(thisGenId);
    setActiveGeometry(geom);
    setActiveGeometryGenerationId(thisGenId);
    setLastGenerationStatus('success');
    setSlicerExplanation(null);
  }, []);

  // Reorient model to optimal orientation
  const handleApplySuggestedOrientation = useCallback(async (rotDeg: [number, number, number]) => {
    const instruction = `Reorient the 3D model geometry by rotating [${rotDeg[0]}°, ${rotDeg[1]}°, ${rotDeg[2]}°] around the origin and translating so its minimum Z rests flat on the Z=0 build plate.`;
    await handleConversationalRevision(instruction);
  }, [handleConversationalRevision]);

  // Custom Printer Update
  const handleSaveCustomPrinter = (updated: PrinterSpec) => {
    saveStoredPrinterOverride(updated.id, updated);
    model.setPrinters((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    model.setSelectedPrinterId(updated.id);
  };

  // Fit Test Coupon Loading & Clearance Persistence
  const handleLoadFitCoupon = useCallback(() => {
    const thisGenId = `gen_fit_coupon_${Date.now()}`;
    setCurrentGenerationId(thisGenId);
    setCurrentJscadCode(FIT_COUPON_JSCAD);
    try {
      const executed = executeJscadModel(FIT_COUPON_JSCAD);
      setActiveGeometry(executed.combinedGeometry);
      model.setCurrentParts(executed.parts || []);
      setActiveGeometryGenerationId(thisGenId);
      setModelName('Fit Test Coupon');
      project.setEditableTitle('Fit Test Coupon');
      setLastGenerationStatus('success');
      setCadErrorMessage(null);
    } catch (err: any) {
      console.error('Failed to execute fit coupon geometry:', err);
    }
  }, []);

  const handleSaveFitTestClearance = useCallback((printerId: string, clearanceMm: number, filamentId: string) => {
    const measuredAt = new Date().toISOString().slice(0, 10);
    const patch: Partial<PrinterSpec> = {
      measuredClearanceMm: clearanceMm,
      clearanceMeasuredAt: measuredAt,
      clearanceFilamentId: filamentId,
    };
    saveStoredPrinterOverride(printerId, patch);
    model.setPrinters((prev) => prev.map((p) => (p.id === printerId ? { ...p, ...patch } : p)));
  }, []);

  const currentPipelineStage: PipelineStageName = useMemo(() => {
    if (hasExportedStl) return 'EXPORT';
    if (mobileTab === 'print' || rightPanelTab === 'print') return 'PRINT_CHECK';
    if (mobileTab === 'viewer' && activeGeometry) return '3D_MODEL';
    if (isReviewingSpec || isSelectingConcept || extractedRequirements) return 'ANALYSIS';
    if ((project.activeProject?.referenceImages?.length || 0) > 0 && !activeGeometry) return 'REFERENCE';
    return 'DESIGN';
  }, [hasExportedStl, mobileTab, rightPanelTab, activeGeometry, isReviewingSpec, isSelectingConcept, extractedRequirements, project.activeProject?.referenceImages]);

  const handleSelectPipelineStage = useCallback((stage: PipelineStageName) => {
    if (stage === 'REFERENCE') {
      setMobileTab('create');
      setMode('describe');
      const photoEl = document.getElementById('photo-input-container');
      if (photoEl) photoEl.scrollIntoView({ behavior: 'smooth' });
    } else if (stage === 'ANALYSIS') {
      setMobileTab('create');
      setMode('describe');
    } else if (stage === 'DESIGN') {
      setMobileTab('create');
      setMode('describe');
      const promptInput = document.getElementById('parametric-prompt-input');
      if (promptInput) {
        promptInput.focus();
        promptInput.scrollIntoView({ behavior: 'smooth' });
      }
    } else if (stage === '3D_MODEL') {
      setMobileTab('viewer');
    } else if (stage === 'PRINT_CHECK') {
      setMobileTab('print');
      setRightPanelTab('print');
    } else if (stage === 'EXPORT') {
      setMobileTab('print');
      setRightPanelTab('print');
      const exportBtn = document.getElementById('btn-export-binary-stl');
      if (exportBtn) exportBtn.scrollIntoView({ behavior: 'smooth' });
    }
  }, []);

  const isBusy = isGeneratingCad || isRevisingCad || stlExportProgress !== null;

  return (
    <div className="flex flex-col h-screen w-screen bg-kf-bg text-kf-text font-sans overflow-hidden">
      {/* ========================================================================= */}
      {/* 1. TOP HEADER / BRAND & WORKSPACE NAVIGATION BAR */}
      {/* ========================================================================= */}
      <Header
        navView={navView}
        setNavView={setNavView}
        setMobileTab={setMobileTab}
        projects={project.projects}
        activeProject={project.activeProject}
        isEditingTitle={project.isEditingTitle}
        editableTitle={project.editableTitle}
        setEditableTitle={project.setEditableTitle}
        handleSaveTitle={handleSaveTitle}
        setIsEditingTitle={project.setIsEditingTitle}
        currentActiveVersion={project.currentActiveVersion}
        saveStatus={project.saveStatus}
        isBusy={isBusy}
        setIsHistoryModalOpen={() => openModal('history')}
        setIsLibraryModalOpen={() => openModal('library')}
        handleClearJob={handleClearJob}
        exportValidation={exportValidation}
        stlExportProgress={stlExportProgress}
        activeGeometry={activeGeometry}
        currentParts={model.currentParts}
        modelName={modelName}
        geometryStats={geometryStats}
        scaleFactor={model.scaleFactor}
        selectedFilament={model.selectedFilament}
        setStlExportProgress={setStlExportProgress}
        setHasExportedStl={setHasExportedStl}
        isHeaderMenuOpen={isHeaderMenuOpen}
        setIsHeaderMenuOpen={setIsHeaderMenuOpen}
        setIsTestSuiteOpen={() => openModal('testSuite')}
        setIsStorageModalOpen={() => openModal('storage')}
        handleExportKatPrint={handleExportKatPrint}
        setRightPanelTab={setRightPanelTab}
        onOpenCamera={() => setIsCameraModalOpen(true)}
      />

      {/* Creation Workflow Pipeline Stepper */}
      {navView === 'workspace' && (
        <ProjectPipelineStepper
          currentStage={currentPipelineStage}
          onSelectStage={handleSelectPipelineStage}
          experienceMode={experienceMode}
          onToggleExperienceMode={setExperienceMode}
          hasGeometry={Boolean(activeGeometry)}
          hasReferenceImages={(project.activeProject?.referenceImages?.length || 0) > 0}
          hasRequirements={Boolean(extractedRequirements)}
        />
      )}

      {/* ========================================================================= */}
      {/* 2. MAIN APPLICATION CONTENT VIEW */}
      {/* ========================================================================= */}
      {navView === 'projects' ? (
        /* PROJECT LIBRARY VIEW */
        <main className="flex-1 overflow-y-auto bg-kf-bg pb-16 lg:pb-0">
          <ProjectLibrary
            projects={project.projects}
            activeProjectId={project.activeProject?.id || null}
            onOpenProject={handleSelectProject}
            onCreateProject={(prompt, name) => handleCreateNewProject(prompt, name)}
            onDeleteProject={handleDeleteProject}
            onDuplicateProject={handleDuplicateProject}
            onRenameProject={handleRenameProject}
            onToggleFavorite={handleToggleFavorite}
            onExportProject={handleExportKatPrint}
            onImportProject={handleImportKatPrint}
            onOpenStorageManager={() => openModal('storage')}
          />
        </main>
      ) : (
        /* WORKSPACE: DESKTOP 3-COLUMN / MOBILE ADAPTIVE VIEW */
        <main className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden relative">
          {/* ------------------------------------------------------------- */}
          {/* LEFT PANEL: Machine/Filament Settings & Mode Generator */}
          {/* ------------------------------------------------------------- */}
          <LeftPanel
            mobileTab={mobileTab}
            mode={mode}
            setMode={setMode}
            experienceMode={experienceMode}
            onUpdateReferenceImages={handleUpdateReferenceImages}
            isReviewingSpec={isReviewingSpec}
            isSelectingConcept={isSelectingConcept}
            isGeneratingCad={isGeneratingCad}
            leftPanelScrollRef={leftPanelScrollRef}
            printers={model.printers}
            printerGroups={model.printerGroups}
            selectedPrinterId={model.selectedPrinterId}
            selectedPrinter={model.selectedPrinter}
            activeGeometry={activeGeometry}
            printerFitResult={model.printerFitResult}
            handlePrinterChange={handlePrinterChange}
            setIsCustomPrinterOpen={() => openModal('customPrinter')}
            setIsFitTestOpen={() => openModal('fitTest')}
            printerCardCollapsed={printerCardCollapsed}
            setPrinterCardCollapsed={setPrinterCardCollapsed}
            extractedRequirements={extractedRequirements}
            pendingSpecPrompt={pendingSpecPrompt}
            lastPrompt={lastPrompt}
            handleConfirmSpecAndGenerate={handleConfirmSpecAndGenerate}
            handleRegenerateSpec={handleRegenerateSpec}
            isRegeneratingSpec={isRegeneratingSpec}
            skipSpecReview={skipSpecReview}
            handleToggleSkipSpecReview={handleToggleSkipSpecReview}
            pendingConceptReqs={pendingConceptReqs}
            conceptVariants={conceptVariants}
            pendingConceptPrompt={pendingConceptPrompt}
            handleSelectConcept={handleSelectConcept}
            handleCustomApproach={handleCustomApproach}
            handleSkipConceptSelection={handleSkipConceptSelection}
            activeProject={project.activeProject}
            setIsReferencePhotosOpen={() => openModal('referencePhotos')}
            currentJscadCode={currentJscadCode}
            handleCodeUpdate={handleCodeUpdate}
            handleGenerateJscad={handleGenerateJscad}
            handleConversationalRevision={handleConversationalRevision}
            handleFixMissingFeatures={handleFixMissingFeatures}
            isRevisingCad={isRevisingCad}
            isFixingFeatures={isFixingFeatures}
            pipelineStage={pipelineStage}
            repairAttempt={repairAttempt}
            cadErrorMessage={cadErrorMessage}
            generationStatusText={generationStatusText}
            generationError={generationError}
            generationDiagnostics={generationDiagnostics}
            handleGenerationModeChange={handleGenerationModeChange}
            exploreApproaches={exploreApproaches}
            handleToggleExploreApproaches={handleToggleExploreApproaches}
            viewingVersionId={project.viewingVersionId}
            validationReport={validationReport}
            handleClearJob={handleClearJob}
            designSpecification={designSpecification}
            designChecklist={designChecklist}
            fidelityReviewResult={fidelityReviewResult}
            handleExternalGeometry={handleExternalGeometry}
            showLeftPanelScrollFade={showLeftPanelScrollFade}
            onOpenCamera={() => setIsCameraModalOpen(true)}
          />

          {/* ------------------------------------------------------------- */}
          {/* CENTER VIEWPORT: Three.js WebGL 3D Viewer */}
          {/* ------------------------------------------------------------- */}
          <ViewerFrame
            mobileTab={mobileTab}
            setMobileTab={setMobileTab}
            setRightPanelTab={setRightPanelTab}
            setDesignPanelMode={setDesignPanelMode}
            cadSource={cadSource}
            lastPrompt={lastPrompt}
            activeProject={project.activeProject}
            isGeneratingCad={isGeneratingCad}
            handleGenerateJscad={handleGenerateJscad}
            viewingVersionId={project.viewingVersionId}
            currentActiveVersion={project.currentActiveVersion}
            handleRestoreVersion={handleRestoreVersion}
            handleReturnToHead={handleReturnToHead}
            activeGeometry={activeGeometry}
            selectedPrinter={model.selectedPrinter}
            scaleFactor={model.scaleFactor}
            highlightOverhangs={highlightOverhangs}
            setHighlightOverhangs={setHighlightOverhangs}
            extractedRequirements={extractedRequirements}
            currentParts={model.currentParts}
            selectedPartId={selectedPartId}
            setSelectedPartId={setSelectedPartId}
            explodedOffset={explodedOffset}
            partVisibility={partVisibility}
            currentJscadCode={currentJscadCode}
            selectedFeatureId={selectedFeatureId}
            selectedFeatureIds={selectedFeatureIds}
            handleSelectFeature={handleSelectFeature}
            handleMultiSelectFeatures={handleMultiSelectFeatures}
            focusTarget={focusTarget}
            handleFocusFeature={handleFocusFeature}
            debugShowPickProxies={debugShowPickProxies}
            setDebugShowPickProxies={setDebugShowPickProxies}
            handleManipulationCommit={handleManipulationCommit}
            onOpenCamera={() => setIsCameraModalOpen(true)}
          />

          {/* ------------------------------------------------------------- */}
          {/* RIGHT PANEL: Multi-Tab Studio Panel (Revisions, History, Slicer, Code) */}
          {/* ------------------------------------------------------------- */}
          <RightPanel
            mobileTab={mobileTab}
            setMobileTab={setMobileTab}
            rightPanelTab={rightPanelTab}
            setRightPanelTab={setRightPanelTab}
            isRevisingCad={isRevisingCad}
            currentParts={model.currentParts}
            designPanelMode={designPanelMode}
            setDesignPanelMode={setDesignPanelMode}
            selectedFeatureId={selectedFeatureId}
            selectedFeatureIds={selectedFeatureIds}
            activeProject={project.activeProject}
            currentActiveVersion={project.currentActiveVersion}
            viewingVersionId={project.viewingVersionId}
            handleSelectFeature={handleSelectFeature}
            handleConversationalRevision={handleConversationalRevision}
            handleRollbackLastRevision={handleRollbackLastRevision}
            handleSelectVersionForViewing={handleSelectVersionForViewing}
            handleRestoreVersion={handleRestoreVersion}
            handleBranchVersion={handleBranchVersion}
            handleReturnToHead={handleReturnToHead}
            persistActiveProject={project.persistActiveProject}
            currentJscadCode={currentJscadCode}
            handleFocusFeature={handleFocusFeature}
            handleUpdateFeatureParameter={handleUpdateFeatureParameter}
            handleToggleLockParameter={handleToggleLockParameter}
            handleReconstructFeatureModel={handleReconstructFeatureModel}
            isApplyingParameter={project.isApplyingParameter}
            setIsCustomPrinterOpen={() => openModal('customPrinter')}
            selectedPrinterId={model.selectedPrinterId}
            handlePrinterChange={handlePrinterChange}
            printerGroups={model.printerGroups}
            selectedFilamentId={model.selectedFilamentId}
            handleFilamentChange={handleFilamentChange}
            mustHoldLiquid={model.mustHoldLiquid}
            handleMustHoldLiquidChange={handleMustHoldLiquidChange}
            selectedPartId={selectedPartId}
            setSelectedPartId={setSelectedPartId}
            partVisibility={partVisibility}
            setPartVisibility={setPartVisibility}
            explodedOffset={explodedOffset}
            setExplodedOffset={setExplodedOffset}
            scaleFactor={model.scaleFactor}
            selectedPrinter={model.selectedPrinter}
            selectedFilament={model.selectedFilament}
            setIsPlateLayoutOpen={() => openModal('plateLayout')}
            setCurrentParts={model.setCurrentParts}
            activeGeometry={activeGeometry}
            geometryStats={geometryStats}
            printerFitResult={model.printerFitResult}
            slicerSettings={slicerSettings}
            handleScaleFactorChange={handleScaleFactorChange}
            handleExplainSlicerSettings={handleExplainSlicerSettings}
            slicerExplanation={slicerExplanation}
            isExplainingSlicer={isExplainingSlicer}
            setIsLiveMonitorOpen={() => openModal('liveMonitor')}
            modelName={modelName}
            extractedRequirements={extractedRequirements}
            exportValidation={exportValidation}
            printabilityReport={printabilityReport}
            isAnalyzingPrintability={isAnalyzingPrintability}
            handleApplySuggestedOrientation={handleApplySuggestedOrientation}
            hasExportedStl={hasExportedStl}
            currentGenerationRecord={currentGenerationRecord}
            setSelectedRecordForModal={setSelectedRecordForModal}
            setIsPrintResultModalOpen={() => openModal('printResult')}
            handleCompareVersions={handleCompareVersions}
            handleRenameVersionLabel={handleRenameVersionLabel}
            handleExportVersionStl={handleExportVersionStl}
            handleViewVersionDiagnostics={handleViewVersionDiagnostics}
          />
        </main>
      )}

      {/* ========================================================================= */}
      {/* 2.5 MOBILE BOTTOM NAVIGATION BAR (CYBERPUNK HUD) */}
      {/* ========================================================================= */}
      <nav
        id="mobile-bottom-navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 h-16 bg-kf-panel/95 backdrop-blur-md border-t border-kf-border z-40 flex items-center justify-around px-1 pb-safe select-none shadow-[0_-4px_20px_rgba(0,0,0,0.5)]"
      >
        <button
          type="button"
          onClick={() => {
            setNavView('workspace');
            setMobileTab('create');
          }}
          className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 transition cursor-pointer relative ${
            navView === 'workspace' && mobileTab === 'create'
              ? 'text-kf-pink font-bold'
              : 'text-kf-muted hover:text-kf-text'
          }`}
        >
          <div className="relative">
            <Wand2 className="w-5 h-5" />
            {(isReviewingSpec || isSelectingConcept) && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-kf-pink animate-ping" />
            )}
          </div>
          <span className="text-[10px] font-mono tracking-tight uppercase">Create</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setNavView('workspace');
            setMobileTab('viewer');
          }}
          className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 transition cursor-pointer relative ${
            navView === 'workspace' && mobileTab === 'viewer'
              ? 'text-kf-pink font-bold'
              : 'text-kf-muted hover:text-kf-text'
          }`}
        >
          <div className="relative">
            <Box className="w-5 h-5" />
            {isGeneratingCad && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-kf-warn animate-pulse" />
            )}
          </div>
          <span className="text-[10px] font-mono tracking-tight uppercase">3D View</span>
        </button>

        {/* Center Primary Action: Instant Camera Snapshot & 3D Conversion */}
        <button
          type="button"
          id="btn-mobile-nav-camera"
          onClick={() => setIsCameraModalOpen(true)}
          className="flex flex-col items-center justify-center -mt-5 py-0.5 transition cursor-pointer relative group active:scale-95 flex-1"
          title="Snap photo with camera and convert to 3D CAD"
        >
          <div className="w-12 h-12 rounded-full bg-kf-pink shadow-[0_0_16px_rgba(255,61,138,0.6)] flex items-center justify-center border-2 border-kf-panel text-[#0A0004] group-hover:bg-kf-pink-hi transition">
            <Camera className="w-6 h-6" />
          </div>
          <span className="text-[10px] font-mono tracking-tight uppercase text-kf-pink font-bold mt-1">Camera</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setNavView('workspace');
            setMobileTab('assistant');
            setRightPanelTab('design');
            setDesignPanelMode('assistant');
          }}
          className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 transition cursor-pointer relative ${
            navView === 'workspace' && mobileTab === 'assistant'
              ? 'text-kf-pink font-bold'
              : 'text-kf-muted hover:text-kf-text'
          }`}
        >
          <div className="relative">
            <MessageSquare className="w-5 h-5" />
            {isRevisingCad && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-kf-pink animate-pulse" />
            )}
          </div>
          <span className="text-[10px] font-mono tracking-tight uppercase">Assistant</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setNavView('workspace');
            setMobileTab('print');
            setRightPanelTab('print');
          }}
          className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 transition cursor-pointer relative ${
            navView === 'workspace' && mobileTab === 'print'
              ? 'text-kf-pink font-bold'
              : 'text-kf-muted hover:text-kf-text'
          }`}
        >
          <div className="relative">
            <Printer className="w-5 h-5" />
            {hasMultiplePhysicalPieces(model.currentParts) && (
              <span className="absolute -top-1 -right-1 bg-kf-pink text-kf-bg text-[8px] font-mono font-bold rounded-full w-3.5 h-3.5 flex items-center justify-center">
                {getPhysicalPieceCount(model.currentParts)}
              </span>
            )}
          </div>
          <span className="text-[10px] font-mono tracking-tight uppercase">Print</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setNavView('projects');
            setMobileTab('projects');
          }}
          className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 transition cursor-pointer relative ${
            navView === 'projects' || mobileTab === 'projects'
              ? 'text-kf-pink font-bold'
              : 'text-kf-muted hover:text-kf-text'
          }`}
        >
          <div className="relative">
            <FolderKanban className="w-5 h-5" />
            {project.projects.length > 0 && (
              <span className="absolute -top-1 -right-1.5 bg-kf-panel-2 border border-kf-border text-kf-text text-[8px] font-mono rounded px-1">
                {project.projects.length}
              </span>
            )}
          </div>
          <span className="text-[10px] font-mono tracking-tight uppercase">Projects</span>
        </button>
      </nav>

      {/* ========================================================================= */}
      {/* 3. MODALS & DIALOGS */}
      {/* ========================================================================= */}
      {/* Version Comparison Modal */}
      {activeModal === 'comparison' && project.activeProject && (
        <VersionComparisonModal
          project={project.activeProject}
          onClose={closeModal}
          initialVersionA={project.compareVersionA}
          initialVersionB={project.compareVersionB}
          onRestoreVersion={(v) => {
            handleRestoreVersion(v);
            closeModal();
          }}
          onExportVersionStl={handleExportVersionStl}
        />
      )}

      {/* Proposed Changes Review Modal */}
      {proposedChangeSet && (
        <ProposedChangesModal
          changeSet={proposedChangeSet}
          userInstruction={pendingRevisionInstruction || ''}
          onConfirm={(autoApplyFuture) => {
            const instructionToRun = pendingRevisionInstruction;
            // Dismiss the modal immediately so the user returns to the workspace and sees pipeline progress
            setProposedChangeSet(null);
            setPendingRevisionInstruction(null);

            if (autoApplyFuture && project.activeProject) {
              const updatedProj: KatPrintProject = {
                ...project.activeProject,
                projectSettings: {
                  ...project.activeProject.projectSettings,
                  autoApplyProposedChanges: true,
                },
                updatedAt: new Date().toISOString(),
              };
              project.persistActiveProject(updatedProj).catch((e) =>
                console.error('Failed to update project auto-apply setting:', e)
              );
            }
            if (instructionToRun) {
              executeDirectRevision(instructionToRun);
            }
          }}
          onCancel={() => {
            setProposedChangeSet(null);
            setPendingRevisionInstruction(null);
          }}
        />
      )}

      {/* Storage Management Modal */}
      <StorageManagementModal
        isOpen={activeModal === 'storage'}
        onClose={closeModal}
        onDataCleared={async () => {
          const list = await projectRepository.listProjects();
          project.setProjects(list);
          if (list.length > 0) {
            activateProject(list[0]);
          } else {
            await handleCreateBlankProject('Untitled Project');
          }
        }}
        onStorageCleared={async () => {
          const list = await projectRepository.listProjects();
          project.setProjects(list);
          if (list.length > 0) {
            activateProject(list[0]);
          } else {
            await handleCreateBlankProject('Untitled Project');
          }
        }}
      />

      {/* Quality Benchmark Modal */}
      <TestSuiteModal
        isOpen={activeModal === 'testSuite'}
        onClose={closeModal}
        onRunTest={(prompt) => {
          setNavView('workspace');
          handleGenerateJscad(prompt, { mode: 'precision' });
        }}
      />

      {/* Custom Printer Setup Modal */}
      <CustomPrinterModal
        isOpen={activeModal === 'customPrinter'}
        onClose={closeModal}
        onSave={handleSaveCustomPrinter}
        printer={model.selectedPrinter}
        initialPrinter={model.selectedPrinter}
      />

      {/* Fit Test Coupon Calibration Modal */}
      <FitTestModal
        isOpen={activeModal === 'fitTest'}
        onClose={closeModal}
        printer={model.selectedPrinter}
        filament={model.selectedFilament}
        onLoadCouponIntoViewer={handleLoadFitCoupon}
        onExportStl={async () => {
          if (!activeGeometry && (!model.currentParts || model.currentParts.length === 0)) return;
          setStlExportProgress(0);
          try {
            await downloadExportSTL(activeGeometry!, model.currentParts, 'fit_test_coupon.stl', model.scaleFactor, 10, (percent) => setStlExportProgress(percent));
            setTimeout(() => setStlExportProgress(null), 750);
          } catch (err) {
            console.error('Failed to export coupon STL:', err);
            setStlExportProgress(null);
          }
        }}
        onSaveClearance={handleSaveFitTestClearance}
      />

      {/* Live Telemetry Simulation Modal */}
      <LivePrinterMonitor
        isOpen={activeModal === 'liveMonitor'}
        onClose={closeModal}
        printer={model.selectedPrinter}
        filament={model.selectedFilament}
        settings={slicerSettings}
        stats={geometryStats}
      />

      {/* Multi-Plate Print Bed Layout Modal */}
      {activeModal === 'plateLayout' && (
        <PlateLayoutModal
          isOpen={activeModal === 'plateLayout'}
          onClose={closeModal}
          parts={model.currentParts}
          printer={model.selectedPrinter}
          filament={model.selectedFilament}
          projectName={project.activeProject?.name || 'Assembly'}
          versionLabel={project.currentActiveVersion?.label}
          scaleFactor={model.scaleFactor}
        />
      )}

      {/* Reference Photos Manager Modal */}
      {activeModal === 'referencePhotos' && (
        <ReferencePhotosManager
          isOpen={activeModal === 'referencePhotos'}
          onClose={closeModal}
          referenceImages={project.activeProject?.referenceImages || []}
          onUpdateReferenceImages={handleUpdateReferenceImages}
          onOpenCamera={() => setIsCameraModalOpen(true)}
        />
      )}

      {/* Live Camera Viewfinder & 3D Conversion Modal */}
      <CameraCaptureModal
        isOpen={isCameraModalOpen}
        onClose={() => setIsCameraModalOpen(false)}
        hasActiveProject={Boolean(project.activeProject)}
        onCaptureAndConvert={async (photo, conversionPrompt) => {
          setIsCameraModalOpen(false);
          const newRefImage: ProjectReferenceImage = {
            id: `ref_img_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
            fileName: photo.fileName,
            filename: photo.fileName,
            dataUrl: photo.dataUrl,
            thumbnailDataUrl: photo.dataUrl,
            mimeType: photo.mimeType as any,
            width: photo.width,
            height: photo.height,
            role: 'front',
            notes: 'Captured via Camera for 3D conversion',
            createdAt: new Date().toISOString(),
          };

          const currentRefs = project.activeProject?.referenceImages || [];
          const updatedRefs = [...currentRefs, newRefImage];

          let targetProj = project.activeProject;
          if (targetProj) {
            targetProj = {
              ...targetProj,
              referenceImages: updatedRefs,
              updatedAt: new Date().toISOString(),
            };
            await project.persistActiveProject(targetProj);
          }

          setNavView('workspace');
          setMobileTab('viewer');

          await handleGenerateJscad(conversionPrompt, {
            mode: project.activeProject?.projectSettings?.generationMode || 'precision',
            targetProject: targetProj || undefined,
          });
        }}
        onAddAsReferenceOnly={async (photo) => {
          const newRefImage: ProjectReferenceImage = {
            id: `ref_img_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
            fileName: photo.fileName,
            filename: photo.fileName,
            dataUrl: photo.dataUrl,
            thumbnailDataUrl: photo.dataUrl,
            mimeType: photo.mimeType as any,
            width: photo.width,
            height: photo.height,
            role: 'front',
            notes: 'Captured via Camera',
            createdAt: new Date().toISOString(),
          };
          if (project.handleUpdateReferenceImages) {
            project.handleUpdateReferenceImages([...(project.referenceImages || []), newRefImage]);
          } else if (project.activeProject) {
            const updated = {
              ...project.activeProject,
              referenceImages: [...(project.activeProject.referenceImages || []), newRefImage],
              updatedAt: new Date().toISOString(),
            };
            await project.persistActiveProject(updated);
          }
        }}
      />

      {/* Print Result Feedback Modal */}
      {selectedRecordForModal && (
        <PrintResultModal
          isOpen={activeModal === 'printResult'}
          onClose={() => {
            closeModal();
            setSelectedRecordForModal(null);
          }}
          record={selectedRecordForModal}
          onSave={handleSavePrintResult}
        />
      )}

      {/* Machine History & Stats Modal */}
      <GenerationHistoryModal
        isOpen={activeModal === 'history'}
        onClose={closeModal}
        records={generationRecords}
        onReopen={handleReopenRecord}
        onLogResult={handleLogResultForRecord}
        onOpenLibrary={() => {
          openModal('library');
        }}
      />

      {/* CAD Examples Catalog Modal */}
      <ExampleLibraryModal
        isOpen={activeModal === 'library'}
        onClose={closeModal}
        onLoadExample={handleLoadLibraryExample}
      />
    </div>
  );
}
