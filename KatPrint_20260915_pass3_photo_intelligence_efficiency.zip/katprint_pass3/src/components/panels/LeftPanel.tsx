import React from 'react';
import type * as THREE from 'three';
import {
  Sparkles,
  Image as ImageIcon,
  Camera,
} from 'lucide-react';
import { PrinterQuickSelect } from '../PrinterQuickSelect';
import { ParametricEditor, GeneratePromptOptions } from '../ParametricEditor';
import { ImageToMeshEditor } from '../ImageToMeshEditor';
import { SpecReviewPanel } from '../SpecReviewPanel';
import { ConceptSelector } from '../ConceptSelector';
import { PhotoInput } from '../camera/PhotoInput';
import { FILAMENTS } from '../../data/filaments';
import type {
  PrinterSpec,
  PrinterFitResult,
  DesignValidationReport,
  ExtractedRequirements,
  GenerationPipelineStage,
  GenerationError,
  GenerationDiagnostics,
  GenerationMode,
  DesignSpecification,
  DesignCheck,
  FidelityReviewResult,
  DesignConcept,
  ProjectReferenceImage,
} from '../../types';
import type { KatPrintProject } from '../../projects/projectTypes';

export interface LeftPanelProps {
  mobileTab: 'create' | 'viewer' | 'assistant' | 'print' | 'projects';
  mode: 'describe' | 'image';
  setMode: (mode: 'describe' | 'image') => void;
  experienceMode?: 'quick' | 'advanced';
  onUpdateReferenceImages?: (images: ProjectReferenceImage[]) => void;
  isReviewingSpec: boolean;
  isSelectingConcept: boolean;
  isGeneratingCad: boolean;
  leftPanelScrollRef: React.RefObject<HTMLDivElement | null>;
  printers: PrinterSpec[];
  printerGroups: [string, PrinterSpec[]][];
  selectedPrinterId: string;
  selectedPrinter: PrinterSpec;
  activeGeometry: THREE.BufferGeometry | null;
  printerFitResult: PrinterFitResult;
  handlePrinterChange: (id: string) => Promise<void> | void;
  setIsCustomPrinterOpen: (open: boolean) => void;
  setIsFitTestOpen: (open: boolean) => void;
  printerCardCollapsed: boolean;
  setPrinterCardCollapsed: React.Dispatch<React.SetStateAction<boolean>>;
  extractedRequirements: ExtractedRequirements | null;
  pendingSpecPrompt: string;
  lastPrompt: string;
  handleConfirmSpecAndGenerate: (updatedReqs: ExtractedRequirements, userOverrides: string[]) => void;
  handleRegenerateSpec: (updatedPrompt: string, updatedReqs: ExtractedRequirements, userOverrides: string[]) => void;
  isRegeneratingSpec: boolean;
  skipSpecReview: boolean;
  handleToggleSkipSpecReview: (val: boolean) => void;
  pendingConceptReqs: ExtractedRequirements | null;
  conceptVariants: DesignConcept[];
  pendingConceptPrompt: string;
  handleSelectConcept: (concept: DesignConcept) => void;
  handleCustomApproach: (customDirectives: string) => void;
  handleSkipConceptSelection: () => void;
  activeProject: KatPrintProject | null;
  setIsReferencePhotosOpen: (open: boolean) => void;
  currentJscadCode: string;
  handleCodeUpdate: (newCode: string) => void;
  handleGenerateJscad: (prompt: string, options?: GeneratePromptOptions) => Promise<void>;
  handleConversationalRevision: (instruction: string) => Promise<void>;
  handleFixMissingFeatures: (missingFeatures: string[]) => Promise<void>;
  isRevisingCad: boolean;
  isFixingFeatures: boolean;
  pipelineStage: GenerationPipelineStage;
  repairAttempt: number;
  cadErrorMessage: string | null;
  generationStatusText: string;
  generationError: GenerationError | null;
  generationDiagnostics: GenerationDiagnostics | null;
  handleGenerationModeChange: (newMode: GenerationMode) => Promise<void> | void;
  exploreApproaches: boolean;
  handleToggleExploreApproaches: (val: boolean) => void;
  viewingVersionId: string | null;
  validationReport: DesignValidationReport | null;
  handleClearJob: () => Promise<void> | void;
  designSpecification: DesignSpecification | null;
  designChecklist: DesignCheck[] | null;
  fidelityReviewResult: FidelityReviewResult | null;
  handleExternalGeometry: (geom: THREE.BufferGeometry) => void;
  showLeftPanelScrollFade: boolean;
  onOpenCamera?: () => void;
}

export const LeftPanel: React.FC<LeftPanelProps> = ({
  mobileTab,
  mode,
  setMode,
  experienceMode = 'quick',
  onUpdateReferenceImages,
  isReviewingSpec,
  isSelectingConcept,
  isGeneratingCad,
  leftPanelScrollRef,
  printers,
  printerGroups,
  selectedPrinterId,
  selectedPrinter,
  activeGeometry,
  printerFitResult,
  handlePrinterChange,
  setIsCustomPrinterOpen,
  setIsFitTestOpen,
  printerCardCollapsed,
  setPrinterCardCollapsed,
  extractedRequirements,
  pendingSpecPrompt,
  lastPrompt,
  handleConfirmSpecAndGenerate,
  handleRegenerateSpec,
  isRegeneratingSpec,
  skipSpecReview,
  handleToggleSkipSpecReview,
  pendingConceptReqs,
  conceptVariants,
  pendingConceptPrompt,
  handleSelectConcept,
  handleCustomApproach,
  handleSkipConceptSelection,
  activeProject,
  setIsReferencePhotosOpen,
  currentJscadCode,
  handleCodeUpdate,
  handleGenerateJscad,
  handleConversationalRevision,
  handleFixMissingFeatures,
  isRevisingCad,
  isFixingFeatures,
  pipelineStage,
  repairAttempt,
  cadErrorMessage,
  generationStatusText,
  generationError,
  generationDiagnostics,
  handleGenerationModeChange,
  exploreApproaches,
  handleToggleExploreApproaches,
  viewingVersionId,
  validationReport,
  handleClearJob,
  designSpecification,
  designChecklist,
  fidelityReviewResult,
  handleExternalGeometry,
  showLeftPanelScrollFade,
  onOpenCamera,
}) => {
  return (
    <aside
      id="left-create-panel"
      className={`${
        mobileTab === 'create' ? 'flex w-full h-full pb-16 lg:pb-0' : 'hidden'
      } lg:flex relative lg:w-[340px] ${(isReviewingSpec || isSelectingConcept) ? 'lg:w-[600px]' : ''} bg-kf-panel lg:border-r border-kf-border h-full min-h-0 max-h-full overflow-hidden flex-col shrink-0 transition-all duration-200 ${isGeneratingCad ? 'trace-active' : ''}`}
    >
      {/* Fixed Left-Side Header Controls */}
      <div className="shrink-0 p-3 pb-2 border-b border-kf-border flex items-center justify-between">
        <span className="section-label">Create</span>
        <div className="flex items-center border border-kf-border bg-kf-panel-2 p-0.5 clip-corner">
          <button
            type="button"
            id="btn-tab-ai-design"
            onClick={() => setMode('describe')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 text-[10px] font-mono font-bold uppercase tracking-wider transition cursor-pointer ${mode === 'describe' ? 'bg-kf-pink text-kf-bg' : 'text-kf-muted hover:text-kf-text'}`}
          >
            <Sparkles className="w-3.5 h-3.5" /> AI Design
          </button>
          <button
            type="button"
            id="btn-tab-image-relief"
            onClick={() => setMode('image')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 text-[10px] font-mono font-bold uppercase tracking-wider transition cursor-pointer ${mode === 'image' ? 'bg-kf-pink text-kf-bg' : 'text-kf-muted hover:text-kf-text'}`}
          >
            <ImageIcon className="w-3.5 h-3.5" /> Image Relief
          </button>
        </div>
      </div>

      {/* Scrollable Left-Side Content */}
      <div
        ref={leftPanelScrollRef}
        id="left-panel-scroll-content"
        className="flex-1 min-h-0 max-h-full overflow-y-auto overflow-x-hidden kp-panel-scroll p-3 pb-12 flex flex-col gap-3"
      >
        {!isReviewingSpec && !isSelectingConcept && (
          <PrinterQuickSelect
            printers={printers}
            printerGroups={printerGroups}
            selectedPrinterId={selectedPrinterId}
            selectedPrinter={selectedPrinter}
            fitResult={activeGeometry ? printerFitResult : null}
            onPrinterChange={handlePrinterChange}
            onOpenCustomPrinter={() => setIsCustomPrinterOpen(true)}
            onOpenFitTest={() => setIsFitTestOpen(true)}
            filaments={FILAMENTS}
            collapsed={printerCardCollapsed}
            onToggleCollapsed={() => setPrinterCardCollapsed((c) => !c)}
          />
        )}

        {mode === 'describe' && (
          <>
            {isReviewingSpec && extractedRequirements ? (
              <div className="trace clip-corner p-[1px] trace-active">
                <div className="bg-kf-panel p-3">
                  <SpecReviewPanel
                    requirements={extractedRequirements}
                    prompt={pendingSpecPrompt || lastPrompt}
                    onProceedToGeneration={(updatedReqs, userOverrides) => {
                      handleConfirmSpecAndGenerate(updatedReqs, userOverrides);
                    }}
                    onRegenerateSpec={(updatedPrompt, updatedReqs, userOverrides) => {
                      handleRegenerateSpec(updatedPrompt, updatedReqs, userOverrides);
                    }}
                    isRegenerating={isRegeneratingSpec}
                    isGenerating={isGeneratingCad}
                    skipSpecReview={skipSpecReview}
                    onToggleSkipSpecReview={handleToggleSkipSpecReview}
                  />
                </div>
              </div>
            ) : isSelectingConcept && (pendingConceptReqs || extractedRequirements) ? (
              <div className="trace clip-corner p-[1px] trace-active">
                <div className="bg-kf-panel p-3">
                  <ConceptSelector
                    concepts={conceptVariants}
                    prompt={pendingConceptPrompt || lastPrompt}
                    baseRequirements={(pendingConceptReqs || extractedRequirements)!}
                    onSelectConcept={handleSelectConcept}
                    onCustomApproach={handleCustomApproach}
                    onSkip={handleSkipConceptSelection}
                    isGenerating={isGeneratingCad}
                  />
                </div>
              </div>
            ) : (
              <>
                {activeProject && (
                  <div className="trace clip-corner p-[1px]">
                    <div className="bg-kf-panel p-3">
                      <PhotoInput
                        referenceImages={activeProject.referenceImages || []}
                        onUpdateReferenceImages={(imgs) => {
                          if (onUpdateReferenceImages) {
                            onUpdateReferenceImages(imgs);
                          }
                        }}
                        onSelectPromptMode={() => {
                          const promptInput = document.getElementById('parametric-prompt-input');
                          if (promptInput) {
                            promptInput.focus();
                            promptInput.scrollIntoView({ behavior: 'smooth' });
                          }
                        }}
                        onPhotoAnalyzed={(analysis, suggestedPrompt) => {
                          const promptInput = document.getElementById('parametric-prompt-input') as HTMLTextAreaElement | null;
                          if (promptInput) {
                            promptInput.value = suggestedPrompt;
                            // Trigger synthetic input event
                            promptInput.dispatchEvent(new Event('input', { bubbles: true }));
                          }
                        }}
                        isGenerating={isGeneratingCad}
                      />
                    </div>
                  </div>
                )}

                <div className={`trace clip-corner p-[1px] ${isGeneratingCad ? 'trace-active' : ''}`}>
                  <div className="bg-kf-panel p-3">
                    <ParametricEditor
                      currentCode={currentJscadCode}
                      onCodeChange={handleCodeUpdate}
                      onGeneratePrompt={handleGenerateJscad}
                      onRevisePrompt={handleConversationalRevision}
                      onFixMissingFeatures={handleFixMissingFeatures}
                      isGenerating={isGeneratingCad}
                      isRevising={isRevisingCad}
                      isFixing={isFixingFeatures}
                      pipelineStage={pipelineStage}
                      repairAttempt={repairAttempt}
                      errorMessage={cadErrorMessage}
                      generationStatusText={generationStatusText}
                      generationError={generationError}
                      generationDiagnostics={generationDiagnostics}
                      generationMode={activeProject?.projectSettings?.generationMode || 'precision'}
                      onModeChange={handleGenerationModeChange}
                      exploreApproaches={exploreApproaches}
                      onToggleExploreApproaches={handleToggleExploreApproaches}
                      isViewingHistorical={Boolean(viewingVersionId && viewingVersionId !== activeProject?.currentVersionId)}
                      onSimplifyToParametric={(prompt) =>
                        handleGenerateJscad(prompt, {
                          simplifyToParametric: true,
                          mode: activeProject?.projectSettings?.generationMode || 'precision',
                        })
                      }
                      validationReport={validationReport}
                      extractedRequirements={extractedRequirements}
                      activePrompt={lastPrompt}
                      onClearJob={handleClearJob}
                      designSpecification={designSpecification}
                      designChecklist={designChecklist}
                      fidelityReviewResult={fidelityReviewResult}
                      onOpenCamera={onOpenCamera}
                    />
                  </div>
                </div>
              </>
            )}
          </>
        )}

        {mode === 'image' && (
          <div className="trace clip-corner p-[1px]">
            <div className="bg-kf-panel p-3">
              <ImageToMeshEditor onGeometryGenerated={handleExternalGeometry} />
            </div>
          </div>
        )}
      </div>

      {/* Scroll Affordance Bottom Fade */}
      {showLeftPanelScrollFade && (
        <div
          className="pointer-events-none absolute bottom-0 left-0 right-0 h-6 bg-gradient-to-t from-kf-panel to-transparent z-20"
          aria-hidden="true"
        />
      )}
    </aside>
  );
};
