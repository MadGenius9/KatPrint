# KatPrint

Conversational 3D CAD designer and STL generator for 3D printing.

## Secrets

Set `GEMINI_API_KEY` (or `GOOGLE_API_KEY`) in Settings > Secrets (or in `.env.local` for local execution).

## Run Locally

```bash
npm run dev
```

