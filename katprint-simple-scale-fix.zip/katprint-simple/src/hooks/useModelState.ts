import { useState, useMemo, useCallback } from 'react';
import {
  ExecutedModelPart,
  PrinterSpec,
  FilamentSpec,
  PrinterFitResult,
  ModelGeometryStats,
} from '../types';
import { INITIAL_PRINTERS } from '../data/printers';
import { FILAMENTS } from '../data/filaments';
import { getMergedPrinters, saveStoredPrinterOverride } from '../storage/printerStorage';
import { computePrinterFit } from '../engine/slicerEngine';

export const EMPTY_GEOMETRY_STATS: ModelGeometryStats = {
  dimensions: { x: 0, y: 0, z: 0 },
  volumeMm3: 0,
  volumeCm3: 0,
  surfaceAreaMm2: 0,
  estimatedWeightGrams: 0,
  triangleCount: 0,
  vertexCount: 0,
  nonManifoldEdgeCount: 0,
  overhangRatio: 0,
  minWallThicknessMm: 0,
  isManifold: false,
  footprintAreaMm2: 0,
  heightToWidthRatio: 0,
  hasSteepOverhangs: false,
};

export interface UseModelStateOptions {
  geometryStats?: ModelGeometryStats;
  initialPrinterId?: string;
  initialFilamentId?: string;
}

export function useModelState(options?: UseModelStateOptions | ModelGeometryStats) {
  const externalStats = options && ('dimensions' in options ? options : options.geometryStats);

  // Multi-Part Assembly: Current Parts
  const [currentParts, setCurrentParts] = useState<ExecutedModelPart[]>([]);

  // Scale Factor
  const [scaleFactor, setScaleFactor] = useState<number>(1.0);

  // Hardware State: Printers & Clearances
  const [printers, setPrinters] = useState<PrinterSpec[]>(() => getMergedPrinters(INITIAL_PRINTERS));
  const [selectedPrinterId, setSelectedPrinterId] = useState<string>(
    options && !('dimensions' in options) && options.initialPrinterId ? options.initialPrinterId : 'bambu-x1c'
  );

  // Resolved PrinterSpec (including storage-merged clearance fields)
  const selectedPrinter = useMemo(
    () => printers.find((p) => p.id === selectedPrinterId) || printers[0],
    [printers, selectedPrinterId]
  );

  // Grouped printers for selector UI
  const printerGroups = useMemo(() => {
    const groups: { [key: string]: PrinterSpec[] } = {
      'Creality': [],
      'Bambu Lab': [],
      'Prusa Research': [],
      'Elegoo': [],
      'Anycubic': [],
      'Sovol / QIDI / Voron': [],
      'Custom / DIY': [],
    };

    for (const p of printers) {
      if (!p) continue;
      const pName = p.name || '';
      const pId = p.id || '';

      if (p.isCustom || pId === 'custom') {
        groups['Custom / DIY'].push(p);
      } else if (pName.startsWith('Creality') || pId.startsWith('ender-')) {
        groups['Creality'].push(p);
      } else if (pName.startsWith('Bambu')) {
        groups['Bambu Lab'].push(p);
      } else if (pName.startsWith('Prusa')) {
        groups['Prusa Research'].push(p);
      } else if (pName.startsWith('Elegoo')) {
        groups['Elegoo'].push(p);
      } else if (pName.startsWith('Anycubic')) {
        groups['Anycubic'].push(p);
      } else if (pName.startsWith('Sovol') || pName.startsWith('QIDI') || pName.startsWith('Voron')) {
        groups['Sovol / QIDI / Voron'].push(p);
      } else {
        if (!groups['Other']) groups['Other'] = [];
        groups['Other'].push(p);
      }
    }

    return Object.entries(groups).filter(([, list]) => list.length > 0);
  }, [printers]);

  // Filament State
  const [selectedFilamentId, setSelectedFilamentId] = useState<string>(
    options && !('dimensions' in options) && options.initialFilamentId ? options.initialFilamentId : 'pla'
  );

  const selectedFilament = useMemo(
    () => FILAMENTS.find((f) => f.id === selectedFilamentId) || FILAMENTS[0],
    [selectedFilamentId]
  );

  // Watertight / Liquid retention
  const [mustHoldLiquid, setMustHoldLiquid] = useState<boolean>(false);

  // Synced geometry stats for fit check
  const [syncedGeometryStats, setSyncedGeometryStats] = useState<ModelGeometryStats | null>(null);

  const setGeometryStats = useCallback((nextStats: ModelGeometryStats | null) => {
    setSyncedGeometryStats((prev) => {
      if (!prev && !nextStats) return prev;
      if (prev && nextStats) {
        if (
          prev.triangleCount === nextStats.triangleCount &&
          prev.volumeMm3 === nextStats.volumeMm3 &&
          prev.surfaceAreaMm2 === nextStats.surfaceAreaMm2 &&
          prev.dimensions.x === nextStats.dimensions.x &&
          prev.dimensions.y === nextStats.dimensions.y &&
          prev.dimensions.z === nextStats.dimensions.z &&
          prev.isManifold === nextStats.isManifold &&
          prev.estimatedWeightGrams === nextStats.estimatedWeightGrams &&
          prev.nonManifoldEdgeCount === nextStats.nonManifoldEdgeCount &&
          prev.overhangRatio === nextStats.overhangRatio &&
          prev.minWallThicknessMm === nextStats.minWallThicknessMm &&
          prev.footprintAreaMm2 === nextStats.footprintAreaMm2
        ) {
          return prev;
        }
      }
      return nextStats;
    });
  }, []);

  const setCurrentPartsSafe = useCallback((nextParts: ExecutedModelPart[] | ((prev: ExecutedModelPart[]) => ExecutedModelPart[])) => {
    setCurrentParts((prev) => {
      const resolved = typeof nextParts === 'function' ? nextParts(prev) : nextParts;
      if (prev === resolved) return prev;
      if (prev.length === 0 && (!resolved || resolved.length === 0)) return prev;
      if (
        resolved &&
        prev.length === resolved.length &&
        prev.every(
          (p, i) =>
            p.id === resolved[i].id &&
            p.name === resolved[i].name &&
            p.stats?.triangleCount === resolved[i].stats?.triangleCount
        )
      ) {
        return prev;
      }
      return resolved;
    });
  }, []);

  const effectiveGeometryStats = externalStats ?? syncedGeometryStats ?? EMPTY_GEOMETRY_STATS;

  // Derived fit-check result (bounding box vs build volume, green/yellow/red status, failing axis text)
  const printerFitResult: PrinterFitResult = useMemo(() => {
    return computePrinterFit(effectiveGeometryStats, selectedPrinter, scaleFactor, currentParts);
  }, [effectiveGeometryStats, selectedPrinter, scaleFactor, currentParts]);

  // Setter callbacks
  const selectPrinter = useCallback((printerId: string) => {
    setSelectedPrinterId(printerId);
  }, []);

  const selectFilament = useCallback((filamentId: string) => {
    setSelectedFilamentId(filamentId);
  }, []);

  const setScale = useCallback((scale: number) => {
    setScaleFactor(scale);
  }, []);

  const toggleMustHoldLiquid = useCallback(() => {
    setMustHoldLiquid((prev) => !prev);
  }, []);

  const saveCustomPrinter = useCallback((updated: PrinterSpec) => {
    saveStoredPrinterOverride(updated.id, updated);
    setPrinters((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    setSelectedPrinterId(updated.id);
  }, []);

  const saveFitTestClearance = useCallback((printerId: string, clearanceMm: number, filamentId: string) => {
    const measuredAt = new Date().toISOString().slice(0, 10);
    const patch: Partial<PrinterSpec> = {
      measuredClearanceMm: clearanceMm,
      clearanceMeasuredAt: measuredAt,
      clearanceFilamentId: filamentId,
    };
    saveStoredPrinterOverride(printerId, patch);
    setPrinters((prev) => prev.map((p) => (p.id === printerId ? { ...p, ...patch } : p)));
  }, []);

  return {
    // Current Parts
    currentParts,
    setCurrentParts: setCurrentPartsSafe,

    // Scale Factor
    scaleFactor,
    setScaleFactor,
    setScale,

    // Printers & Selected Printer
    printers,
    setPrinters,
    selectedPrinterId,
    setSelectedPrinterId,
    selectPrinter,
    selectedPrinter,
    printerGroups,

    // Filament & Selected Filament
    selectedFilamentId,
    setSelectedFilamentId,
    selectFilament,
    selectedFilament,

    // Watertight
    mustHoldLiquid,
    setMustHoldLiquid,
    toggleMustHoldLiquid,

    // Fit Check Result
    printerFitResult,
    setGeometryStats,
    setFitGeometryStats: setGeometryStats,

    // Storage persistence helpers
    saveCustomPrinter,
    saveFitTestClearance,
  };
}

export type ModelState = ReturnType<typeof useModelState>;
