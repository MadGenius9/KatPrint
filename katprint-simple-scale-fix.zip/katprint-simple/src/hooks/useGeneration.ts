import { useState, useCallback, useEffect } from 'react';
import * as THREE from 'three';
import {
  GenerationRecord,
  PrintResult,
  CadExample,
  PrinterSpec,
  FilamentSpec,
  ModelGeometryStats,
  SlicerSettings,
  GenerationPipelineStage,
  ExtractedRequirements,
  DesignConcept,
  DesignValidationReport,
  GenerationError,
  GenerationDiagnostics,
  DesignSpecification,
  DesignCheck,
  FidelityReviewResult,
  GenerationMode,
  AIRequestRecord,
  ExecutedModelPart,
  ProjectReferenceImage,
  PrintabilityReport,
  DesignIntentAudit,
  RequirementCoverageReport,
  SemanticFeaturePlan,
  ProjectDesignState,
  PrecisionReviewProblem,
  ReferenceImageObservation,
} from '../types';
import {
  KatPrintProject,
  ModelVersion,
} from '../projects/projectTypes';
import {
  loadGenerationRecords,
  saveGenerationRecord,
  updateGenerationPrintResult,
} from '../storage/generationStorage';
import {
  loadAllExamples,
  saveUserExample,
} from '../examples/exampleLibrary';
import {
  selectExamples,
  classifyPromptShapeClass,
  tokenizeAndStem,
} from '../examples/selectExamples';
import {
  inferProjectName,
} from '../projects/projectService';
import {
  initializeProjectDesignState,
  mergeDesignStateWithSpecification,
  partitionCachedReferenceImages,
  attachObservationsToReferenceImages,
} from '../projects/projectMemory';
import { buildGenerationDiagnostics } from '../projects/generationDiagnostics';
import {
  applyRevisionToProject,
  parseRevisionInstruction,
} from '../projects/revisionEngine';
import {
  SemanticFeatureModel,
  planSemanticFeatureModel,
  planSemanticFeatureModelFromPlan,
  evaluateSemanticPlanCoverage,
  finalizeFeatureModelForCode,
} from '../features';
import { analyzeBufferGeometry } from '../engine/geometryUtils';
import { runPrintabilityAnalysisAsync } from '../engine/clientPrintability';
import { executeJscadModel, DEFAULT_PLANTER_JSCAD } from '../engine/jscadRunner';
import {
  requestJscadGeneration,
  requestJscadRevision,
  requestSlicerExplanation,
  requestFidelityReview,
  requestTargetedRepair,
  requestPlanSemanticFeatures,
  requestRepairSemanticPlan,
  requestAuditDesignIntent,
  requestAnalyzeReferenceImages,
  extractPromptRequirements,
  requestConceptVariants,
  mapApiErrorMessage,
} from '../services/geminiService';
import { buildDesignSpecification } from '../engine/designIntent/designSpecification';
import { generateDesignChecklist } from '../engine/designIntent/designChecklist';
import { performDeterministicInspection } from '../engine/designVerification/geometryVerification';
import { assessClarificationNeeds, ensureCriticalOpenQuestions } from '../engine/clarificationGate';
import { renderInspectionViews } from '../engine/designVerification/renderInspectionViews';
import { useModelState } from './useModelState';

export interface UseGenerationDeps {
  model: ReturnType<typeof useModelState>;
  activeProject: KatPrintProject | null;
  referenceImages?: ProjectReferenceImage[];
  currentActiveVersion?: ModelVersion | null;
  viewingVersionId?: string | null;
  selectedFeatureId?: string | null;
  selectedFeatureIds?: string[];
  setMobileTab?: (tab: 'model' | 'viewer' | 'params') => void;
  setViewingVersionId?: (id: string | null) => void;
  setEditableTitle?: (title: string) => void;
  setRightPanelTab?: (tab: 'model' | 'print' | 'params' | 'export') => void;
  setHasExportedStl?: (hasExported: boolean) => void;
  recordNewVersion?: (
    code: string,
    geom: THREE.BufferGeometry,
    prompt: string,
    changeSummary: string,
    changeType?: 'INITIAL_GENERATION' | 'REVISION' | 'RESTORED' | 'BRANCH' | 'MANUAL_EDIT',
    score?: number | null,
    spec?: DesignSpecification,
    checklist?: DesignCheck[],
    review?: FidelityReviewResult,
    diffExplanation?: string,
    targetProject?: KatPrintProject,
    featureModel?: SemanticFeatureModel | null,
    projectDesignState?: ProjectDesignState | null,
    semanticFeaturePlan?: SemanticFeaturePlan | null,
    requirementCoverageReport?: RequirementCoverageReport | null,
    designIntentAudit?: DesignIntentAudit | null,
    statusOverride?: 'verified' | 'unverified' | 'failed'
  ) => Promise<void>;
  persistActiveProject?: (project: KatPrintProject) => Promise<void>;
  getSlicerSettings?: () => SlicerSettings | undefined;
  slicerSettings?: SlicerSettings;
  geometryStats?: ModelGeometryStats;
  setProposedChangeSet?: (changeSet: any) => void;
  setPendingRevisionInstruction?: (instruction: string) => void;
  handleCreateBlankProject?: (customName?: string) => Promise<void>;
  handleRestoreVersion?: (version: ModelVersion) => Promise<void>;
}

export function useGeneration(deps: UseGenerationDeps) {
  const {
    model,
    activeProject,
    currentActiveVersion,
    viewingVersionId,
    selectedFeatureId,
    selectedFeatureIds = [],
    setMobileTab,
    setViewingVersionId,
    setEditableTitle,
    setRightPanelTab,
    setHasExportedStl,
    recordNewVersion,
    persistActiveProject,
    slicerSettings,
    geometryStats,
    setProposedChangeSet,
    setPendingRevisionInstruction,
    handleCreateBlankProject,
  } = deps;

  // 3D Geometry State
  const [currentJscadCode, setCurrentJscadCode] = useState<string>(DEFAULT_PLANTER_JSCAD);
  const [activeGeometry, setActiveGeometry] = useState<THREE.BufferGeometry | null>(null);
  const [modelName, setModelName] = useState<string>('Self-Watering Planter');

  // AI Pipeline States
  const [isGeneratingCad, setIsGeneratingCad] = useState<boolean>(false);
  const [isRevisingCad, setIsRevisingCad] = useState<boolean>(false);
  const [isFixingFeatures, setIsFixingFeatures] = useState<boolean>(false);
  const [pipelineStage, setPipelineStage] = useState<GenerationPipelineStage>('idle');
  const [repairAttempt, setRepairAttempt] = useState<number>(1);
  const [generationStatusText, setGenerationStatusText] = useState<string>('');
  const [cadErrorMessage, setCadErrorMessage] = useState<string | null>(null);
  const [generationError, setGenerationError] = useState<GenerationError | null>(null);
  const [generationDiagnostics, setGenerationDiagnostics] = useState<GenerationDiagnostics | null>(null);
  const [generationId, setGenerationId] = useState<string | null>(null);
  const [currentGenerationId, setCurrentGenerationId] = useState<string | null>(null);
  const [activeGeometryGenerationId, setActiveGeometryGenerationId] = useState<string | null>(null);
  const [lastGenerationStatus, setLastGenerationStatus] = useState<'idle' | 'generating' | 'success' | 'error'>('success');
  const [cadSource, setCadSource] = useState<'ai' | 'template' | null>(null);
  const [lastPrompt, setLastPrompt] = useState<string>(
    '100 mm × 60 mm × 25 mm electronics enclosure with 3 mm walls, four M4 mounting holes in corners, two 20 mm cable openings on left, and removable top lid'
  );
  const [extractedRequirements, setExtractedRequirements] = useState<ExtractedRequirements | null>(null);
  const [validationReport, setValidationReport] = useState<DesignValidationReport | null>(null);

  // Spec Review Step State
  const [skipSpecReview, setSkipSpecReview] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('katprint_skip_spec_review') === 'true';
    }
    return false;
  });
  const [isReviewingSpec, setIsReviewingSpec] = useState<boolean>(false);
  const [isRegeneratingSpec, setIsRegeneratingSpec] = useState<boolean>(false);
  const [pendingSpecPrompt, setPendingSpecPrompt] = useState<string>('');
  const [pendingSpecOptions, setPendingSpecOptions] = useState<any>(null);
  const [forcedClarification, setForcedClarification] = useState<boolean>(false);

  const handleToggleSkipSpecReview = useCallback((val: boolean) => {
    setSkipSpecReview(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('katprint_skip_spec_review', String(val));
    }
  }, []);

  // Concept Variant Strategy State
  const [exploreApproaches, setExploreApproaches] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('katprint_explore_approaches') === 'true';
    }
    return false;
  });
  const [isSelectingConcept, setIsSelectingConcept] = useState<boolean>(false);
  const [conceptVariants, setConceptVariants] = useState<DesignConcept[]>([]);
  const [pendingConceptPrompt, setPendingConceptPrompt] = useState<string>('');
  const [pendingConceptReqs, setPendingConceptReqs] = useState<ExtractedRequirements | null>(null);
  const [pendingConceptUserOverrides, setPendingConceptUserOverrides] = useState<string[]>([]);
  const [pendingConceptOptions, setPendingConceptOptions] = useState<any>(null);
  const [pendingConceptAiRecords, setPendingConceptAiRecords] = useState<AIRequestRecord[]>([]);

  const handleToggleExploreApproaches = useCallback((val: boolean) => {
    setExploreApproaches(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('katprint_explore_approaches', String(val));
    }
  }, []);

  // Precision Engine State
  const [designSpecification, setDesignSpecification] = useState<DesignSpecification | null>(null);
  const [designChecklist, setDesignChecklist] = useState<DesignCheck[]>([]);
  const [fidelityReviewResult, setFidelityReviewResult] = useState<FidelityReviewResult | null>(null);

  // Slicer Explanation & Printability Audit
  const [slicerExplanation, setSlicerExplanation] = useState<string | null>(null);
  const [isExplainingSlicer, setIsExplainingSlicer] = useState<boolean>(false);
  const [printabilityReport, setPrintabilityReport] = useState<PrintabilityReport | null>(null);
  const [isAnalyzingPrintability, setIsAnalyzingPrintability] = useState<boolean>(false);

  // Generation Records State
  const [generationRecords, setGenerationRecords] = useState<GenerationRecord[]>(() => loadGenerationRecords());
  const [currentGenerationRecord, setCurrentGenerationRecord] = useState<GenerationRecord | null>(null);
  const [selectedRecordForModal, setSelectedRecordForModal] = useState<GenerationRecord | null>(null);

  // Background Web Worker Printability Analysis
  useEffect(() => {
    let isCurrent = true;
    if (!activeGeometry || (geometryStats && geometryStats.triangleCount === 0)) {
      setPrintabilityReport(null);
      setIsAnalyzingPrintability(false);
      return;
    }

    setIsAnalyzingPrintability(true);
    runPrintabilityAnalysisAsync(activeGeometry, {
      nozzleMm: model.selectedPrinter.nozzleDiameter,
      layerHeightMm: model.selectedPrinter.nozzleDiameter * 0.5,
      bedSize: model.selectedPrinter.buildVolume,
    })
      .then((rep) => {
        if (isCurrent) {
          setPrintabilityReport(rep);
          setIsAnalyzingPrintability(false);
        }
      })
      .catch((err) => {
        console.warn('Printability analysis error:', err);
        if (isCurrent) {
          setIsAnalyzingPrintability(false);
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [
    activeGeometry,
    model.selectedPrinter.id,
    model.selectedPrinter.nozzleDiameter,
    model.selectedPrinter.buildVolume.x,
    model.selectedPrinter.buildVolume.y,
    model.selectedPrinter.buildVolume.z,
    geometryStats?.triangleCount,
  ]);

  // Centralized Version Geometry & Identity Activation Helper
  const activateVersionGeometry = useCallback(
    (
      version: ModelVersion | null | undefined,
      options?: { head?: boolean; density?: number }
    ) => {
      const isHead = options?.head !== false;
      if (!version || !version.cadCode) {
        setCurrentJscadCode('');
        setActiveGeometry(null);
        if (isHead) {
          setCurrentGenerationId(null);
          setGenerationId(null);
        }
        setActiveGeometryGenerationId(null);
        setLastGenerationStatus('idle');
        setCadErrorMessage(null);
        setGenerationError(null);
        return { success: false, isManifold: false };
      }
      const script = version.cadCode;
      setCurrentJscadCode(script);
      setLastPrompt(version.prompt || '');
      setCadSource(script ? 'ai' : null);
      setDesignSpecification(version.designSpecification || null);
      setDesignChecklist(version.designChecklist || []);
      setFidelityReviewResult(version.fidelityReview || null);
      if (version.generationDiagnostics) {
        setGenerationDiagnostics(version.generationDiagnostics);
      }
      const vGenId = version.generationDiagnostics?.generationId || version.id || null;
      setActiveGeometryGenerationId(vGenId);
      try {
        const executed = executeJscadModel(script, version.assembly);
        const geom = executed.combinedGeometry;
        const density = options?.density ?? model.selectedFilament.densityGcm3 ?? 1.24;
        const stats = analyzeBufferGeometry(geom, density);
        const isValid =
          stats.triangleCount > 0 &&
          stats.volumeMm3 > 0 &&
          stats.isManifold === true;
        setActiveGeometry(geom);
        model.setCurrentParts(executed.parts || []);
        if (isHead) {
          setCurrentGenerationId(vGenId);
          setGenerationId(vGenId);
        }
        if (isValid) {
          setLastGenerationStatus('success');
          setCadErrorMessage(null);
          setGenerationError(null);
        } else {
          setLastGenerationStatus('error');
          setCadErrorMessage(
            stats.isManifold
              ? 'Model has zero volume or no solid triangles.'
              : 'Model is not closed (open surface).'
          );
        }
        return { success: isValid, isManifold: stats.isManifold, stats };
      } catch (err: any) {
        console.error('Failed to activate version geometry:', err);
        setActiveGeometry(null);
        setLastGenerationStatus('error');
        setCadErrorMessage(err?.message || 'Failed to render 3D geometry.');
        return { success: false, isManifold: false };
      }
    },
    [model.selectedFilament.densityGcm3, model.setCurrentParts]
  );

  // Helper to commit generation record into persistent learning store
  const recordSuccessfulGeneration = useCallback(
    (
      genId: string,
      prompt: string,
      code: string,
      geom: THREE.BufferGeometry,
      parts: ExecutedModelPart[],
      source: 'ai' | 'template',
      hasMeasuredDeltaFlags: boolean = false
    ) => {
      try {
        const stats = analyzeBufferGeometry(geom, model.selectedFilament.densityGcm3);
        const activeSlicer = deps.getSlicerSettings ? deps.getSlicerSettings() : slicerSettings;
        const record: GenerationRecord = {
          id: genId,
          createdAt: new Date().toISOString(),
          prompt,
          finalCode: code,
          measuredDimensions: {
            x: stats.dimensions.x,
            y: stats.dimensions.y,
            z: stats.dimensions.z,
          },
          parts: parts.map((p) => ({
            id: p.id,
            name: p.name,
            quantity: p.quantity,
            dimensions: p.boundingBox,
          })),
          printer: model.selectedPrinter,
          filament: model.selectedFilament,
          computedSettings: activeSlicer,
          source,
          matingClearanceMm:
            typeof model.selectedPrinter?.measuredClearanceMm === 'number'
              ? model.selectedPrinter.measuredClearanceMm
              : 0.25,
          hasMeasuredDeltaFlags,
        };

        saveGenerationRecord(record);
        setCurrentGenerationRecord(record);
        setGenerationRecords(loadGenerationRecords());
        if (setHasExportedStl) setHasExportedStl(false);
      } catch (err) {
        console.error('Failed to record generation:', err);
      }
    },
    [model.selectedFilament, model.selectedPrinter, slicerSettings, setHasExportedStl, deps.getSlicerSettings]
  );

  const handleSavePrintResult = useCallback(
    (result: PrintResult, addToLibraryTitle?: string) => {
      updateGenerationPrintResult(result.generationId, result);
      if (currentGenerationRecord && currentGenerationRecord.id === result.generationId) {
        setCurrentGenerationRecord({
          ...currentGenerationRecord,
          printResult: result,
        });
      }

      if (addToLibraryTitle) {
        const targetRecord =
          currentGenerationRecord && currentGenerationRecord.id === result.generationId
            ? currentGenerationRecord
            : generationRecords.find((r) => r.id === result.generationId);
        if (targetRecord) {
          const shapeClass = classifyPromptShapeClass(targetRecord.prompt);
          const keywords = tokenizeAndStem(`${targetRecord.prompt} ${addToLibraryTitle}`);
          const newEx: CadExample = {
            id: `user_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
            title: addToLibraryTitle,
            prompt: targetRecord.prompt,
            code: targetRecord.finalCode,
            shapeClass,
            keywords,
            dimsMm: targetRecord.measuredDimensions,
            isMultiPart: Boolean(targetRecord.parts && targetRecord.parts.length > 1),
            holdsLiquid: /(?:water|liquid|reservoir|planter|cup|vase|bowl)/i.test(targetRecord.prompt),
            source: 'user',
            createdAt: new Date().toISOString(),
            starred: false,
          };
          saveUserExample(newEx);
        }
      }
      setGenerationRecords(loadGenerationRecords());
    },
    [currentGenerationRecord, generationRecords]
  );

  const handleReopenRecord = useCallback(
    (record: GenerationRecord) => {
      setCurrentGenerationRecord(record);
      setCurrentJscadCode(record.finalCode);
      const executed = executeJscadModel(record.finalCode);
      setActiveGeometry(executed.combinedGeometry);
      model.setCurrentParts(executed.parts || []);
      setModelName(record.prompt ? record.prompt.slice(0, 32) : 'CAD Model');
      setCadSource(record.source);
      if (setRightPanelTab) setRightPanelTab('print');
    },
    [model, setRightPanelTab]
  );

  const handleLoadLibraryExample = useCallback(
    (ex: CadExample) => {
      setCurrentJscadCode(ex.code);
      const executed = executeJscadModel(ex.code);
      setActiveGeometry(executed.combinedGeometry);
      model.setCurrentParts(executed.parts || []);
      setModelName(ex.title);
      setCadSource(ex.source === 'seed' ? 'template' : 'ai');
      if (setRightPanelTab) setRightPanelTab('print');
    },
    [model, setRightPanelTab]
  );

  const handleLogResultForRecord = useCallback(
    (record: GenerationRecord) => {
      setSelectedRecordForModal(record);
    },
    []
  );

  // Core CAD Generation Pipeline (Precision or Fast) after Specs are Confirmed
  const executeCadGenerationPipeline = async (
    promptText: string,
    reqs: ExtractedRequirements,
    userOverrides: string[] = [],
    options?: {
      useTemplate?: boolean;
      simplifyToParametric?: boolean;
      mode?: GenerationMode;
      targetProject?: KatPrintProject;
      bypassSpecReview?: boolean;
      exploreApproaches?: boolean;
    },
    priorAiRecords: AIRequestRecord[] = []
  ) => {
    const pipelineStartTime = Date.now();
    const thisGenId = `gen_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const currentMode =
      options?.mode ??
      options?.targetProject?.projectSettings?.generationMode ??
      activeProject?.projectSettings?.generationMode ??
      'precision';
    setCurrentGenerationId(thisGenId);
    setLastGenerationStatus('generating');
    setIsGeneratingCad(true);
    setIsReviewingSpec(false);
    if (setMobileTab) setMobileTab('viewer');
    setCadErrorMessage(null);
    setGenerationError(null);
    setLastPrompt(promptText);
    setSlicerExplanation(null);
    setRepairAttempt(1);

    try {
      const activeProjRefImages = (options?.targetProject || activeProject)?.referenceImages;
      const aiRecords: AIRequestRecord[] = [...priorAiRecords];

      if (currentMode === 'precision') {
        const spec = buildDesignSpecification(promptText, reqs);
        setDesignSpecification(spec);

        // Reference Image Analysis with Hash-Partitioned Caching
        let refImageObservations: any[] = [];
        let updatedRefImages = activeProjRefImages ? [...activeProjRefImages] : [];
        if (activeProjRefImages && activeProjRefImages.length > 0) {
          const { cachedImages, uncachedImages } = partitionCachedReferenceImages(activeProjRefImages);
          const cachedObservations = cachedImages.map((c) => c.observation);
          if (uncachedImages.length > 0) {
            try {
              const obsRes = await requestAnalyzeReferenceImages({
                referenceImages: uncachedImages,
                prompt: promptText,
              });
              if (obsRes.diagnostics?.requestRecords) {
                aiRecords.push(...obsRes.diagnostics.requestRecords);
              }
              const freshObs = obsRes.observations || [];
              updatedRefImages = attachObservationsToReferenceImages(activeProjRefImages, uncachedImages, freshObs);
              refImageObservations = updatedRefImages
                .map((img) => img.analysisObservation)
                .filter((obs): obs is ReferenceImageObservation => obs !== undefined && obs !== null);
            } catch (refErr) {
              console.warn('Reference image analysis failed:', refErr);
              refImageObservations = cachedObservations;
            }
          } else {
            refImageObservations = cachedObservations;
          }
        }

        const baseProject = options?.targetProject || activeProject;
        const existingDesignState = baseProject?.projectDesignState;
        const initialDesignState = existingDesignState
          ? mergeDesignStateWithSpecification(existingDesignState, spec)
          : initializeProjectDesignState(promptText, spec);

        // Step 2: Planning Semantic Feature Model & Generating Checklist
        setPipelineStage('planning_geometry');
        const checklist = generateDesignChecklist(spec);
        setDesignChecklist(checklist);

        let plannedFeatureModel: SemanticFeatureModel;
        let plannedPlan: SemanticFeaturePlan | null = null;
        let plannerDiagnostics: any = undefined;

        const hasReferenceImages = updatedRefImages && updatedRefImages.length > 0;

        if (hasReferenceImages) {
          try {
            const planRes = await requestPlanSemanticFeatures({
              prompt: promptText,
              spec,
              checklist,
              mode: 'precision',
              referenceImages: updatedRefImages,
              projectDesignState: initialDesignState,
              projectMemory: baseProject?.projectMemory,
              printer: model.selectedPrinter,
              referenceImageObservations: refImageObservations,
            });
            if (planRes.diagnostics?.requestRecords) {
              aiRecords.push(...planRes.diagnostics.requestRecords);
            }
            plannedFeatureModel = planRes.featureModel;
            plannedPlan = planRes.plan || null;
            plannerDiagnostics = planRes.diagnostics || {
              usedFallback: planRes.usedFallback,
              fallbackReason: planRes.fallbackReason,
              plansRequested: planRes.plansRequested,
              plansReceived: planRes.plansReceived,
              initialPlansReceived: planRes.initialPlansReceived,
              retryPlansReceived: planRes.retryPlansReceived,
              validPlansEvaluated: planRes.validPlansEvaluated,
              distinctPlansEvaluated: planRes.distinctPlansEvaluated,
              degradedMultiPlan: planRes.degradedMultiPlan,
              degradedReason: planRes.degradedReason,
              plansEvaluated: planRes.plansEvaluated,
            };
          } catch (planErr) {
            console.warn('AI semantic feature planning failed, falling back to local planner:', planErr);
            plannedFeatureModel = planSemanticFeatureModel(spec, promptText);
            plannerDiagnostics = {
              usedFallback: true,
              fallbackReason: 'semantic_planner_request_failed',
              plansRequested: 1,
              plansReceived: 0,
              plansEvaluated: 0,
              validPlansEvaluated: 0,
              distinctPlansEvaluated: 0,
              degradedMultiPlan: false,
            };
          }

          // Semantic Plan Coverage Verification & Pre-Generation Repair
          if (plannedPlan) {
            try {
              const planCoverage = evaluateSemanticPlanCoverage(plannedPlan, spec, initialDesignState);
              const unresolvedCrit = planCoverage.items
                .filter((i) => i.importance === 'critical' && i.status === 'unresolved')
                .map((i) => i.requirement);

              if (!planCoverage.allCriticalPassed && unresolvedCrit.length > 0) {
                console.log('Semantic plan has unmet critical requirements, repairing plan before CAD generation...', unresolvedCrit);
                const repairedRes = await requestRepairSemanticPlan({
                  prompt: promptText,
                  currentPlan: plannedPlan,
                  unresolvedCriticalRequirements: unresolvedCrit,
                  spec,
                  projectDesignState: initialDesignState,
                  referenceImageObservations: refImageObservations,
                  projectMemory: baseProject?.projectMemory,
                  printer: model.selectedPrinter,
                });
                if (repairedRes.diagnostics?.requestRecords) {
                  aiRecords.push(...repairedRes.diagnostics.requestRecords);
                }

                let allCritPassed = false;
                if (repairedRes.repairedPlan) {
                  plannedPlan = repairedRes.repairedPlan;
                  plannedFeatureModel = planSemanticFeatureModelFromPlan(plannedPlan, promptText, spec);
                  const postRepairCoverage = evaluateSemanticPlanCoverage(plannedPlan, spec, initialDesignState);
                  allCritPassed = postRepairCoverage.allCriticalPassed;
                }

                if (!allCritPassed) {
                  const clarificationQuestion = repairedRes.clarificationNeeded ||
                    (repairedRes.unresolvableCriticalRequirements && repairedRes.unresolvableCriticalRequirements.length > 0
                      ? `I need clarification on: ${repairedRes.unresolvableCriticalRequirements.join(', ')} before I can generate an accurate CAD model.`
                      : `I need clarification on ${unresolvedCrit.join(', ')} to ensure correct fit and manufacturing compatibility.`);

                  setCadErrorMessage(`Clarification required: ${clarificationQuestion}`);
                  setGenerationError({
                    error: `Clarification required: ${clarificationQuestion}`,
                    errorCategory: 'DESIGN_INTENT_AMBIGUITY',
                    technicalDetails: `Unresolved critical requirements: ${unresolvedCrit.join(', ')}`,
                  });
                  setPipelineStage('idle');
                  setIsGeneratingCad(false);
                  return;
                }
              }
            } catch (repairPlanErr: any) {
              console.warn('Semantic plan repair failed:', repairPlanErr);
            }
          }
        } else {
          // Direct fast deterministic semantic feature plan for standard text prompts
          plannedFeatureModel = planSemanticFeatureModel(spec, promptText);
          plannerDiagnostics = {
            usedFallback: false,
            fallbackReason: 'fast_direct_plan',
            plansRequested: 1,
            plansReceived: 1,
            plansEvaluated: 1,
            validPlansEvaluated: 1,
            distinctPlansEvaluated: 1,
            degradedMultiPlan: false,
          };
        }

        // Step 3: Generating Parametric CAD Code (Server executes and verifies geometry)
        setPipelineStage('generating_cad');
        const genRequestId = `req_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
        const precisionLibExamples = loadAllExamples();
        const selectedPrecisionExamples = selectExamples(promptText, reqs, precisionLibExamples, 3);
        const result = await requestJscadGeneration(promptText, {
          requirements: reqs,
          userOverrides,
          featureModel: plannedFeatureModel,
          designSpecification: spec,
          designChecklist: checklist,
          simplifyToParametric: options?.simplifyToParametric,
          mode: 'precision',
          referenceImages: updatedRefImages,
          requestId: genRequestId,
          examples: selectedPrecisionExamples.map((ex) => ({
            id: ex.id,
            title: ex.title,
            code: ex.code,
            source: ex.source,
          })),
          onProgress: (statusText) => setGenerationStatusText(statusText),
        });
        if (result.diagnostics?.requestRecords) {
          aiRecords.push(...result.diagnostics.requestRecords);
        }

        // Step 4: Building Solid Model
        setPipelineStage('building_model');
        let currentCode = result.code;
        const executed = executeJscadModel(currentCode);
        let newGeom = executed.combinedGeometry;
        model.setCurrentParts(executed.parts || []);
        setCurrentJscadCode(currentCode);
        setActiveGeometry(newGeom);
        setActiveGeometryGenerationId(thisGenId);
        setLastGenerationStatus('success');
        setCadSource(result.source);
        setGenerationId(result.generationId || thisGenId);

        let geomStats = analyzeBufferGeometry(newGeom, model.selectedFilament.densityGcm3);
        let activeFeatureModel = finalizeFeatureModelForCode(
          plannedFeatureModel,
          currentCode,
          geomStats,
          'strict'
        );

        // Step 5: Checking Dimensions & Geometry
        setPipelineStage('checking_dimensions');
        const initialInspection = performDeterministicInspection(newGeom, currentCode, spec, checklist);
        setDesignChecklist(initialInspection.checks);

        let review: FidelityReviewResult = {
          verdict: initialInspection.criticalPassed ? 'PASS' : 'NEEDS_MINOR_CORRECTION',
          overallScore: Math.round((result.diagnostics?.auditScore ?? (initialInspection.criticalPassed ? 0.95 : 0.75)) * 100),
          summary: 'Geometry verified with measured physical feedback.',
          verifiedRequirements: result.validationReport?.items?.filter((i) => i.status === 'verified').map((i) => i.label) || [],
          problems: [],
          missingFeatures: result.validationReport?.missingFeatures || [],
          visualMismatch: [],
          requiresRepair: false,
          scoreBreakdown: {
            intentMatch: 95,
            dimensions: 95,
            requiredFeatures: 95,
            printability: 95,
            visualMatch: 90,
          },
        };
        let designIntentAudit: DesignIntentAudit | null = null;
        let requirementCoverageReport: RequirementCoverageReport | null = null;

        if (hasReferenceImages) {
          // Multimodal review passes for reference images
          setPipelineStage('rendering_views');
          const renderedViews = await renderInspectionViews(newGeom);

          setPipelineStage('inspecting_design');
          try {
            const reviewRes = await requestFidelityReview({
              specification: spec,
              code: currentCode,
              geometryStats: geomStats,
              deterministicChecks: initialInspection.checks,
              views: renderedViews,
              purpose: 'visual_fidelity_review',
            });
            if (reviewRes.diagnostics?.requestRecords) {
              aiRecords.push(...reviewRes.diagnostics.requestRecords);
            }
            review = reviewRes.review;
          } catch (reviewErr) {
            console.warn('Fidelity review pass skipped:', reviewErr);
          }
          setFidelityReviewResult(review);

          try {
            const auditRes = await requestAuditDesignIntent({
              prompt: promptText,
              code: currentCode,
              measurements: geomStats,
              spec,
              featureModel: activeFeatureModel,
              designState: initialDesignState,
              referenceImages: updatedRefImages,
              semanticFeaturePlan: plannedPlan || undefined,
              referenceImageObservations: refImageObservations,
            });
            if (auditRes.diagnostics?.requestRecords) {
              aiRecords.push(...auditRes.diagnostics.requestRecords);
            }
            designIntentAudit = auditRes.audit;
            requirementCoverageReport = auditRes.coverageReport;
          } catch (auditErr) {
            console.warn('Design intent audit initial pass failed:', auditErr);
          }
        } else {
          setFidelityReviewResult(review);
        }

        // Candidate Evaluation Record Setup
        interface CadCandidate {
          code: string;
          geom: THREE.BufferGeometry;
          parts: any[];
          geomStats: ModelGeometryStats;
          featureModel: SemanticFeatureModel;
          inspection: ReturnType<typeof performDeterministicInspection>;
          review: FidelityReviewResult;
          score: number | null;
          designIntentAudit: DesignIntentAudit | null;
          requirementCoverageReport: RequirementCoverageReport | null;
          scoreValue: number;
        }

        const evaluateCandidateQuality = (
          candStats: ModelGeometryStats,
          candInsp: ReturnType<typeof performDeterministicInspection>,
          candRev: FidelityReviewResult,
          candAudit: DesignIntentAudit | null,
          candModel?: SemanticFeatureModel
        ): number => {
          let q = 0;
          if (candStats.isManifold && candStats.volumeMm3 > 0) {
            q += 35;
          } else {
            return 0;
          }

          if (candInsp.criticalPassed) {
            q += 25;
          } else {
            q -= 15;
          }

          const numScore = typeof candRev.overallScore === 'number'
            ? candRev.overallScore
            : (candRev.verdict === 'PASS' ? 85 : candRev.verdict === 'INVALID_DESIGN' ? 0 : 50);
          q += Math.max(0, Math.min(25, (numScore / 100) * 25));

          if (candAudit) {
            if (candAudit.verdict === 'pass') q += 15;
            else if (candAudit.verdict === 'needs_repair') q += 5;
            else if (candAudit.verdict === 'fail') q -= 20;

            if (candAudit.defects && candAudit.defects.length > 0) {
              for (const d of candAudit.defects) {
                if (d.severity === 'critical') q -= 12;
                else if (d.severity === 'major') q -= 6;
                else q -= 2;
              }
            }
            if (candAudit.missingFeatures && candAudit.missingFeatures.length > 0) {
              q -= candAudit.missingFeatures.length * 8;
            }
          }

          if (candModel?.bindingValidation) {
            const criticalUnbound = candModel.bindingValidation.criticalUnboundParameters?.length || 0;
            const missingBuilder = candModel.bindingValidation.missingBuilderFeatures?.length || 0;
            q -= (criticalUnbound * 10 + missingBuilder * 5);
          }

          return Math.max(0, q);
        };

        const candidates: CadCandidate[] = [];
        candidates.push({
          code: currentCode,
          geom: newGeom,
          parts: executed.parts || [],
          geomStats,
          featureModel: activeFeatureModel,
          inspection: initialInspection,
          review,
          score: typeof review.overallScore === 'number' ? review.overallScore : null,
          designIntentAudit,
          requirementCoverageReport,
          scoreValue: evaluateCandidateQuality(geomStats, initialInspection, review, designIntentAudit, activeFeatureModel),
        });

        // Step 9: Targeted Precision Correction Loop (Only for multimodal reference image flows if defects detected)
        let needsCorrection = hasReferenceImages && (
          !initialInspection.criticalPassed ||
          review.requiresRepair ||
          (review.problems && review.problems.length > 0 && review.verdict !== 'PASS')
        );

        let finalScore = typeof review.overallScore === 'number' ? review.overallScore : null;
        let finalReview = review;
        let finalChecklist = initialInspection.checks;
        let repairAttempts = 0;

        const MAX_TARGETED_REPAIR_ATTEMPTS = 2;
        let bestRepairQuality = candidates[0].scoreValue;
        let forceSimplifiedRecovery = false;

        while (needsCorrection && repairAttempts < MAX_TARGETED_REPAIR_ATTEMPTS) {
          repairAttempts++;
          setPipelineStage('correcting_model');
          setRepairAttempt(repairAttempts);

          const combinedProblems: PrecisionReviewProblem[] = [...(finalReview.problems || [])];
          if (designIntentAudit?.defects) {
            for (const d of designIntentAudit.defects) {
              if (!combinedProblems.some((p) => p.requirement === d.issue)) {
                combinedProblems.push({
                  requirement: d.issue,
                  issue: d.issue,
                  severity: d.severity === 'critical' ? 'critical' : d.severity === 'major' ? 'important' : 'minor',
                  recommendedCorrection: d.recommendation,
                  affectedFeatureId: d.featureId,
                });
              }
            }
          }

          const reviewForRepair = {
            ...finalReview,
            problems: combinedProblems,
            requiresRepair: true,
          };

          try {
            const repairResult = await requestTargetedRepair({
              originalPrompt: promptText,
              currentCode,
              specification: spec,
              reviewResult: reviewForRepair,
              deterministicChecks: finalChecklist,
              geometryStats: geomStats,
              featureModel: activeFeatureModel,
              bindingValidation: activeFeatureModel.bindingValidation,
              lockedParameterIds: activeFeatureModel.parameters.filter((p) => p.locked).map((p) => p.id),
              repairStrategy: forceSimplifiedRecovery ? 'simplify' : 'targeted',
            });
            if (repairResult.diagnostics?.requestRecords) {
              aiRecords.push(...repairResult.diagnostics.requestRecords);
            }

            currentCode = repairResult.code;
            const repairedExec = executeJscadModel(currentCode);
            newGeom = repairedExec.combinedGeometry;
            model.setCurrentParts(repairedExec.parts || []);
            setCurrentJscadCode(currentCode);
            setActiveGeometry(newGeom);
            setActiveGeometryGenerationId(thisGenId);

            setPipelineStage('final_verification');
            const postRepairViews = await renderInspectionViews(newGeom);
            geomStats = analyzeBufferGeometry(newGeom, model.selectedFilament.densityGcm3);
            const postRepairInspection = performDeterministicInspection(newGeom, currentCode, spec, checklist);
            setDesignChecklist(postRepairInspection.checks);
            finalChecklist = postRepairInspection.checks;

            activeFeatureModel = finalizeFeatureModelForCode(
              activeFeatureModel,
              currentCode,
              geomStats,
              'strict'
            );

            const finalReviewRes = await requestFidelityReview({
              specification: spec,
              code: currentCode,
              geometryStats: geomStats,
              deterministicChecks: postRepairInspection.checks,
              views: postRepairViews,
              purpose: 'final_visual_review',
            });
            if (finalReviewRes.diagnostics?.requestRecords) {
              aiRecords.push(...finalReviewRes.diagnostics.requestRecords);
            }
            finalReview = finalReviewRes.review;
            setFidelityReviewResult(finalReview);
            finalScore = typeof finalReview.overallScore === 'number' ? finalReview.overallScore : null;

            // Re-audit the repaired geometry. Reusing the pre-repair audit here can make a
            // genuinely improved candidate look worse (or let a regressed candidate pass).
            let repairedAudit = designIntentAudit;
            let repairedCoverage = requirementCoverageReport;
            try {
              const repairedAuditRes = await requestAuditDesignIntent({
                prompt: promptText,
                code: currentCode,
                measurements: geomStats,
                spec,
                featureModel: activeFeatureModel,
                designState: initialDesignState,
                referenceImages: updatedRefImages,
                semanticFeaturePlan: plannedPlan || undefined,
                referenceImageObservations: refImageObservations,
              });
              if (repairedAuditRes.diagnostics?.requestRecords) {
                aiRecords.push(...repairedAuditRes.diagnostics.requestRecords);
              }
              repairedAudit = repairedAuditRes.audit;
              repairedCoverage = repairedAuditRes.coverageReport;
            } catch (auditErr) {
              console.warn('Post-repair design intent audit failed; retaining previous audit:', auditErr);
            }

            const repairedQuality = evaluateCandidateQuality(
              geomStats,
              postRepairInspection,
              finalReview,
              repairedAudit,
              activeFeatureModel
            );

            candidates.push({
              code: currentCode,
              geom: newGeom,
              parts: repairedExec.parts || [],
              geomStats,
              featureModel: activeFeatureModel,
              inspection: postRepairInspection,
              review: finalReview,
              score: finalScore,
              designIntentAudit: repairedAudit,
              requirementCoverageReport: repairedCoverage,
              scoreValue: repairedQuality,
            });

            designIntentAudit = repairedAudit;
            requirementCoverageReport = repairedCoverage;

            const repairedHasCriticalAuditDefect = (repairedAudit?.defects || []).some((d) => d.severity === 'critical');
            const repairedHasCriticalCoverageGap = (repairedCoverage?.unmetCriticalRequirements?.length || 0) > 0;
            needsCorrection = hasReferenceImages && (
              !postRepairInspection.criticalPassed ||
              finalReview.requiresRepair ||
              finalReview.verdict !== 'PASS' ||
              repairedAudit?.verdict === 'needs_repair' ||
              repairedAudit?.verdict === 'fail' ||
              repairedHasCriticalAuditDefect ||
              repairedHasCriticalCoverageGap
            );

            // Do not burn another AI repair call if this attempt failed to improve the
            // engineering-quality score. Candidate selection below still preserves the best version.
            if (repairedQuality <= bestRepairQuality) {
              if (repairAttempts < MAX_TARGETED_REPAIR_ATTEMPTS && !forceSimplifiedRecovery) {
                // A precise patch can get trapped in fragile CSG. Spend the final repair budget
                // on a robust parametric recovery pass instead of repeating the same strategy.
                console.warn('Targeted repair did not improve candidate quality; switching to simplified recovery.');
                forceSimplifiedRecovery = true;
                continue;
              }
              console.warn('Repair did not improve candidate quality; preserving the best prior candidate.');
              break;
            }
            bestRepairQuality = repairedQuality;
            forceSimplifiedRecovery = false;
          } catch (repairErr) {
            if (repairAttempts < MAX_TARGETED_REPAIR_ATTEMPTS && !forceSimplifiedRecovery) {
              console.warn('Targeted repair failed; retrying once with simplified parametric recovery:', repairErr);
              forceSimplifiedRecovery = true;
              continue;
            }
            console.warn('Repair recovery encountered an error, preserving best candidate:', repairErr);
            break;
          }
        }

        // Candidate Comparison Gate (Deterministic Engineering Comparison)
        const comparePrecisionCandidates = (a: CadCandidate, b: CadCandidate): number => {
          // 1. Manifold geometry with positive volume
          const aValid = a.geomStats.isManifold && a.geomStats.volumeMm3 > 0 && Number.isFinite(a.geomStats.volumeMm3);
          const bValid = b.geomStats.isManifold && b.geomStats.volumeMm3 > 0 && Number.isFinite(b.geomStats.volumeMm3);
          if (aValid !== bValid) return bValid ? 1 : -1;

          // 2. Critical deterministic inspection passed
          const aInspCrit = a.inspection.criticalPassed;
          const bInspCrit = b.inspection.criticalPassed;
          if (aInspCrit !== bInspCrit) return bInspCrit ? 1 : -1;

          // 3. Zero unmet critical requirement coverage items
          const aUnmetCrit = a.requirementCoverageReport?.unmetCriticalRequirements?.length ?? 0;
          const bUnmetCrit = b.requirementCoverageReport?.unmetCriticalRequirements?.length ?? 0;
          if (aUnmetCrit !== bUnmetCrit) return aUnmetCrit - bUnmetCrit;

          // 4. Zero critical semantic parameter binding failures
          const aUnboundCrit = a.featureModel.bindingValidation?.criticalUnboundParameters?.length ?? 0;
          const bUnboundCrit = b.featureModel.bindingValidation?.criticalUnboundParameters?.length ?? 0;
          if (aUnboundCrit !== bUnboundCrit) return aUnboundCrit - bUnboundCrit;

          // 5. Design Intent Audit verdict (pass > needs_repair > unknown > fail)
          const auditRank = (audit: DesignIntentAudit | null): number => {
            if (!audit) return 0;
            if (audit.verdict === 'pass') return 4;
            if (audit.verdict === 'needs_repair') return 3;
            if (audit.verdict === 'unknown') return 2;
            if (audit.verdict === 'fail') return 1;
            return 0;
          };
          const aAuditRank = auditRank(a.designIntentAudit);
          const bAuditRank = auditRank(b.designIntentAudit);
          if (aAuditRank !== bAuditRank) return bAuditRank - aAuditRank;

          // 6. Fewer critical audit defects
          const aCritDefects = (a.designIntentAudit?.defects || []).filter((d) => d.severity === 'critical').length;
          const bCritDefects = (b.designIntentAudit?.defects || []).filter((d) => d.severity === 'critical').length;
          if (aCritDefects !== bCritDefects) return aCritDefects - bCritDefects;

          // 7. Fewer major audit defects
          const aMajorDefects = (a.designIntentAudit?.defects || []).filter((d) => d.severity === 'major').length;
          const bMajorDefects = (b.designIntentAudit?.defects || []).filter((d) => d.severity === 'major').length;
          if (aMajorDefects !== bMajorDefects) return aMajorDefects - bMajorDefects;

          // 8. Higher requirement coverage percent
          const aCoverage = a.requirementCoverageReport?.coveragePercent ?? (a.inspection.passedChecksCount / Math.max(1, a.inspection.totalChecksCount) * 100);
          const bCoverage = b.requirementCoverageReport?.coveragePercent ?? (b.inspection.passedChecksCount / Math.max(1, b.inspection.totalChecksCount) * 100);
          if (Math.abs(aCoverage - bCoverage) >= 5) return bCoverage - aCoverage;

          // 9. Fidelity Review verdict: PASS > NEEDS_REPAIR > INVALID_DESIGN
          const reviewRank = (v?: string) => (v === 'PASS' ? 3 : v === 'NEEDS_REPAIR' ? 2 : 1);
          const aRevRank = reviewRank(a.review.verdict);
          const bRevRank = reviewRank(b.review.verdict);
          if (aRevRank !== bRevRank) return bRevRank - aRevRank;

          // 10. Numeric fidelity score only as final tie-breaker
          const aScore = typeof a.score === 'number' ? a.score : 50;
          const bScore = typeof b.score === 'number' ? b.score : 50;
          return bScore - aScore;
        };

        // Select Best Candidate from history
        if (candidates.length > 1) {
          candidates.sort(comparePrecisionCandidates);
          const best = candidates[0];
          currentCode = best.code;
          newGeom = best.geom;
          model.setCurrentParts(best.parts);
          setCurrentJscadCode(best.code);
          setActiveGeometry(best.geom);
          geomStats = best.geomStats;
          activeFeatureModel = best.featureModel;
          finalReview = best.review;
          finalScore = best.score;
          finalChecklist = best.inspection.checks;
          designIntentAudit = best.designIntentAudit;
          requirementCoverageReport = best.requirementCoverageReport;
          setFidelityReviewResult(finalReview);
        }

        setPipelineStage('final_verification');
        const finalInspection = performDeterministicInspection(newGeom, currentCode, spec, checklist);
        const verifiedCount = finalInspection.passedChecksCount;
        const totalCount = Math.max(1, finalInspection.totalChecksCount);

        // Strict Status Gating: VERIFIED requires manifold geom, critical geometry pass, review PASS, audit pass, 0 unmet critical reqs, and clean parameter bindings
        const auditPassed = designIntentAudit?.verdict === 'pass';
        const noCriticalCoverageFailures = !requirementCoverageReport || requirementCoverageReport.unmetCriticalRequirements.length === 0;
        const bindingsPassed = !activeFeatureModel.bindingValidation || activeFeatureModel.bindingValidation.criticalUnboundParameters.length === 0;
        const geometryValid = geomStats.isManifold && geomStats.volumeMm3 > 0 && Number.isFinite(geomStats.volumeMm3);

        const isStrictlyPassed =
          geometryValid &&
          finalInspection.criticalPassed &&
          finalReview.verdict === 'PASS' &&
          auditPassed &&
          noCriticalCoverageFailures &&
          bindingsPassed;

        const finalVerdict =
          !geometryValid || finalReview.verdict === 'INVALID_DESIGN' || !finalInspection.criticalPassed || (designIntentAudit?.verdict === 'fail')
            ? 'FAILED'
            : isStrictlyPassed
            ? 'VERIFIED'
            : 'PARTIALLY VERIFIED';

        setValidationReport({
          items: finalInspection.items,
          overallScore: finalScore,
          passed: isStrictlyPassed,
          verdict: finalVerdict,
          summary: finalReview.summary || `Precision verification complete: ${verifiedCount} of ${totalCount} design checks verified.`,
          missingFeatures: (finalReview.problems || []).map((p) => p.requirement),
          warnings: finalInspection.warnings,
          fidelityReview: finalReview,
        });

        const finalGeomStats = analyzeBufferGeometry(newGeom, model.selectedFilament.densityGcm3);
        const totalDuration = Date.now() - pipelineStartTime;

        const diag = buildGenerationDiagnostics({
          generationId: result.generationId || thisGenId,
          timestamp: Date.now(),
          mode: 'precision',
          requestRecords: aiRecords,
          repairAttempts,
          latencyMs: totalDuration,
          totalDurationMs: totalDuration,
          status: 'success',
          geometryMeasurements: finalGeomStats,
          measuredDimensions: finalGeomStats.dimensions,
          measuredVolumeMm3: finalGeomStats.volumeMm3,
          polygonCount: finalGeomStats.triangleCount,
          triangleCount: finalGeomStats.triangleCount,
          vertexCount: finalGeomStats.triangleCount * 3,
          isManifold: finalGeomStats.isManifold,
          nonManifoldEdgeCount: finalGeomStats.nonManifoldEdgeCount,
          precisionScore: typeof finalScore === 'number' ? finalScore : undefined,
          validationVerdict: finalVerdict,
          semanticFeatureCount: activeFeatureModel.features.length,
          verifiedFeatureCount: activeFeatureModel.features.filter((f) => f.status === 'verified').length,
          failedFeatureCount: activeFeatureModel.features.filter((f) => f.status === 'failed').length,
          unknownFeatureCount: activeFeatureModel.features.filter((f) => f.status === 'unknown').length,
          bindingCount: Object.keys(activeFeatureModel.codeBindings || {}).length,
          boundFeatureCount: activeFeatureModel.bindingValidation?.boundFeatures.length ?? 0,
          builderBoundFeatureCount: activeFeatureModel.bindingValidation?.builderBoundFeatures.length ?? 0,
          criticalUnboundParameterCount: activeFeatureModel.bindingValidation?.criticalUnboundParameters.length ?? 0,
          missingBuilderFeatureCount: activeFeatureModel.bindingValidation?.missingBuilderFeatures.length ?? 0,
          unusedFeatureWrapperCount: activeFeatureModel.bindingValidation?.unboundFeatures.length ?? 0,
          featureModelVersion: activeFeatureModel.schemaVersion,
          usedFallback: plannerDiagnostics?.usedFallback,
          fallbackReason: plannerDiagnostics?.fallbackReason,
          plansRequested: plannerDiagnostics?.plansRequested,
          plansReceived: plannerDiagnostics?.plansReceived,
          initialPlansReceived: plannerDiagnostics?.initialPlansReceived,
          retryPlansReceived: plannerDiagnostics?.retryPlansReceived,
          validPlansEvaluated: plannerDiagnostics?.validPlansEvaluated,
          distinctPlansEvaluated: plannerDiagnostics?.distinctPlansEvaluated,
          degradedMultiPlan: plannerDiagnostics?.degradedMultiPlan,
          degradedReason: plannerDiagnostics?.degradedReason,
          plansEvaluated: plannerDiagnostics?.plansEvaluated,
        });

        setGenerationDiagnostics(diag);

        const cleanPrompt = inferProjectName(promptText, spec);
        setModelName(cleanPrompt);
        if (setEditableTitle) setEditableTitle(cleanPrompt);
        setPipelineStage('completed');

        // Persist to project version history
        const projectToSave = baseProject ? { ...baseProject, referenceImages: updatedRefImages } : baseProject;
        const precisionStatusOverride: 'verified' | 'unverified' | 'failed' =
          finalVerdict === 'VERIFIED' ? 'verified' : (finalVerdict === 'FAILED' ? 'failed' : 'unverified');

        if (recordNewVersion) {
          await recordNewVersion(
            currentCode,
            newGeom,
            promptText,
            'Precision CAD synthesis with full multi-view verification',
            'INITIAL_GENERATION',
            finalScore,
            spec,
            finalChecklist,
            finalReview,
            undefined,
            projectToSave,
            activeFeatureModel,
            initialDesignState,
            plannedPlan,
            requirementCoverageReport,
            designIntentAudit,
            precisionStatusOverride
          );
        }

        const hasFlags =
          Boolean(result.diagnostics?.measuredFeedbackFlags && result.diagnostics.measuredFeedbackFlags.length > 0) ||
          !finalInspection.criticalPassed;
        recordSuccessfulGeneration(
          result.generationId || thisGenId,
          promptText,
          currentCode,
          newGeom,
          model.currentParts,
          result.source === 'template' ? 'template' : 'ai',
          hasFlags
        );
      } else {
        // Fast Mode Flow
        const spec = buildDesignSpecification(promptText, reqs);
        setDesignSpecification(spec);
        const baseProject = options?.targetProject || activeProject;
        const existingDesignState = baseProject?.projectDesignState;
        const initialDesignState = existingDesignState
          ? mergeDesignStateWithSpecification(existingDesignState, spec)
          : initializeProjectDesignState(promptText, spec);

        const checklist = generateDesignChecklist(spec);
        setDesignChecklist(checklist);

        // Fast mode reference image handling: Use cached observations only, do NOT run new image analysis
        const { cachedImages } = partitionCachedReferenceImages(activeProjRefImages || []);
        const fastCachedObservations = cachedImages.map((c) => c.observation);

        let plannedFeatureModel: SemanticFeatureModel;
        let plannedPlan: SemanticFeaturePlan | null = null;
        let fastPlannerDiag: any = undefined;
        try {
          const planRes = await requestPlanSemanticFeatures({
            prompt: promptText,
            spec,
            checklist,
            mode: 'fast',
            referenceImages: activeProjRefImages,
            projectDesignState: initialDesignState,
            projectMemory: baseProject?.projectMemory,
            printer: model.selectedPrinter,
            referenceImageObservations: fastCachedObservations,
          });
          if (planRes.diagnostics?.requestRecords) {
            aiRecords.push(...planRes.diagnostics.requestRecords);
          }
          plannedFeatureModel = planRes.featureModel;
          plannedPlan = planRes.plan || null;
          fastPlannerDiag = planRes.diagnostics || {
            usedFallback: planRes.usedFallback,
            fallbackReason: planRes.fallbackReason,
            plansRequested: planRes.plansRequested,
            plansReceived: planRes.plansReceived,
            initialPlansReceived: planRes.initialPlansReceived,
            retryPlansReceived: planRes.retryPlansReceived,
            validPlansEvaluated: planRes.validPlansEvaluated,
            distinctPlansEvaluated: planRes.distinctPlansEvaluated,
            degradedMultiPlan: planRes.degradedMultiPlan,
            degradedReason: planRes.degradedReason,
            plansEvaluated: planRes.plansEvaluated,
          };
        } catch (planErr) {
          console.warn('Fast mode AI semantic planning failed, falling back to local planner:', planErr);
          plannedFeatureModel = planSemanticFeatureModel(spec, promptText);
          fastPlannerDiag = {
            usedFallback: true,
            fallbackReason: 'semantic_planner_request_failed',
            plansRequested: 1,
            plansReceived: 0,
            plansEvaluated: 0,
            validPlansEvaluated: 0,
            distinctPlansEvaluated: 0,
            degradedMultiPlan: false,
          };
        }

        setPipelineStage('generating_cad');
        const fastRequestId = `req_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
        const fastLibExamples = loadAllExamples();
        const selectedFastExamples = selectExamples(promptText, reqs, fastLibExamples, 3);
        const result = await requestJscadGeneration(promptText, {
          requirements: reqs,
          userOverrides,
          featureModel: plannedFeatureModel,
          designSpecification: spec,
          designChecklist: checklist,
          simplifyToParametric: options?.simplifyToParametric,
          mode: 'fast',
          referenceImages: activeProjRefImages,
          requestId: fastRequestId,
          examples: selectedFastExamples.map((ex) => ({
            id: ex.id,
            title: ex.title,
            code: ex.code,
            source: ex.source,
          })),
          onProgress: (statusText) => setGenerationStatusText(statusText),
        });
        if (result.diagnostics?.requestRecords) {
          aiRecords.push(...result.diagnostics.requestRecords);
        }

        setPipelineStage('executing_geometry');
        const executed = executeJscadModel(result.code);
        const newGeom = executed.combinedGeometry;
        model.setCurrentParts(executed.parts || []);
        setCurrentJscadCode(result.code);
        setActiveGeometry(newGeom);
        setActiveGeometryGenerationId(thisGenId);
        setLastGenerationStatus('success');
        setCadSource(result.source);
        setGenerationId(result.generationId || thisGenId);

        const finalFastGeomStats = analyzeBufferGeometry(newGeom, model.selectedFilament.densityGcm3);
        const finalFastFeatureModel = finalizeFeatureModelForCode(
          plannedFeatureModel,
          result.code,
          finalFastGeomStats,
          'strict'
        );

        const fastTotalDuration = Date.now() - pipelineStartTime;
        const fastDiag = buildGenerationDiagnostics({
          generationId: result.generationId || thisGenId,
          timestamp: Date.now(),
          mode: 'fast',
          requestRecords: aiRecords,
          repairAttempts: result.diagnostics?.repairAttempts || 0,
          latencyMs: fastTotalDuration,
          totalDurationMs: fastTotalDuration,
          status: 'success',
          geometryMeasurements: finalFastGeomStats,
          measuredDimensions: finalFastGeomStats.dimensions,
          measuredVolumeMm3: finalFastGeomStats.volumeMm3,
          polygonCount: finalFastGeomStats.triangleCount,
          triangleCount: finalFastGeomStats.triangleCount,
          vertexCount: finalFastGeomStats.triangleCount * 3,
          isManifold: finalFastGeomStats.isManifold,
          nonManifoldEdgeCount: finalFastGeomStats.nonManifoldEdgeCount,
          semanticFeatureCount: finalFastFeatureModel.features.length,
          verifiedFeatureCount: finalFastFeatureModel.features.filter((f) => f.status === 'verified').length,
          failedFeatureCount: finalFastFeatureModel.features.filter((f) => f.status === 'failed').length,
          unknownFeatureCount: finalFastFeatureModel.features.filter((f) => f.status === 'unknown').length,
          bindingCount: Object.keys(finalFastFeatureModel.codeBindings || {}).length,
          boundFeatureCount: finalFastFeatureModel.bindingValidation?.boundFeatures.length ?? 0,
          builderBoundFeatureCount: finalFastFeatureModel.bindingValidation?.builderBoundFeatures.length ?? 0,
          criticalUnboundParameterCount: finalFastFeatureModel.bindingValidation?.criticalUnboundParameters.length ?? 0,
          missingBuilderFeatureCount: finalFastFeatureModel.bindingValidation?.missingBuilderFeatures.length ?? 0,
          unusedFeatureWrapperCount: finalFastFeatureModel.bindingValidation?.unboundFeatures.length ?? 0,
          featureModelVersion: finalFastFeatureModel.schemaVersion,
          usedFallback: fastPlannerDiag?.usedFallback,
          fallbackReason: fastPlannerDiag?.fallbackReason,
          plansRequested: fastPlannerDiag?.plansRequested,
          plansReceived: fastPlannerDiag?.plansReceived,
          initialPlansReceived: fastPlannerDiag?.initialPlansReceived,
          retryPlansReceived: fastPlannerDiag?.retryPlansReceived,
          validPlansEvaluated: fastPlannerDiag?.validPlansEvaluated,
          distinctPlansEvaluated: fastPlannerDiag?.distinctPlansEvaluated,
          degradedMultiPlan: fastPlannerDiag?.degradedMultiPlan,
          degradedReason: fastPlannerDiag?.degradedReason,
          plansEvaluated: fastPlannerDiag?.plansEvaluated,
        });

        setGenerationDiagnostics(fastDiag);
        setGenerationError(null);

        if (result.validationReport) setValidationReport(result.validationReport);

        const cleanPrompt = inferProjectName(promptText);
        setModelName(cleanPrompt);
        if (setEditableTitle) setEditableTitle(cleanPrompt);
        setPipelineStage('completed');

        if (recordNewVersion) {
          await recordNewVersion(
            result.code,
            newGeom,
            promptText,
            'Fast generative CAD model',
            'INITIAL_GENERATION',
            null,
            spec,
            undefined,
            undefined,
            undefined,
            options?.targetProject,
            finalFastFeatureModel,
            initialDesignState,
            plannedPlan,
            undefined,
            undefined,
            'unverified'
          );
        }

        recordSuccessfulGeneration(
          result.generationId || thisGenId,
          promptText,
          result.code,
          newGeom,
          executed.parts || [],
          result.source === 'template' ? 'template' : 'ai',
          false
        );
      }
    } catch (err: any) {
      console.error('CAD generation failed:', err);
      setPipelineStage('error');
      setLastGenerationStatus('error');
      const userMsg = mapApiErrorMessage(err, (err as any)?.status);
      setCadErrorMessage(userMsg);
      setGenerationError({
        error: userMsg,
        errorCategory: err.errorCategory || 'UNKNOWN_ERROR',
        technicalDetails: err.technicalDetails || err.message,
        statusCode: err.status,
        canSimplifyToParametric: err.canSimplifyToParametric,
        requirements: err.requirements,
      });
      if (err.diagnostics || err.raw?.diagnostics) {
        setGenerationDiagnostics(err.diagnostics || err.raw.diagnostics);
      }
    } finally {
      setIsGeneratingCad(false);
      setGenerationStatusText('');
    }
  };

  // Generate JSCAD (Initial or Brand New Prompt)
  const handleGenerateJscad = async (
    promptText: string,
    options?: {
      useTemplate?: boolean;
      simplifyToParametric?: boolean;
      mode?: GenerationMode;
      targetProject?: KatPrintProject;
      bypassSpecReview?: boolean;
      exploreApproaches?: boolean;
    }
  ) => {
    const thisGenId = `gen_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    setCurrentGenerationId(thisGenId);
    setLastGenerationStatus('generating');
    setIsGeneratingCad(true);
    setCadErrorMessage(null);
    setGenerationError(null);
    setLastPrompt(promptText);
    setSlicerExplanation(null);
    setRepairAttempt(1);

    try {
      const activeProjRefImages = (options?.targetProject || activeProject)?.referenceImages;

      if (options?.useTemplate) {
        setPipelineStage('generating_cad');
        const result = await requestJscadGeneration(promptText, {
          useTemplate: true,
          mode: 'fast',
          referenceImages: activeProjRefImages,
        });
        const executed = executeJscadModel(result.code);
        const newGeom = executed.combinedGeometry;
        model.setCurrentParts(executed.parts || []);
        setCurrentJscadCode(result.code);
        setActiveGeometry(newGeom);
        setActiveGeometryGenerationId(thisGenId);
        setLastGenerationStatus('success');
        setCadSource('template');
        setGenerationId(result.generationId || thisGenId);
        setGenerationDiagnostics(result.diagnostics || null);
        setValidationReport(result.validationReport || null);
        const name = `Template — ${inferProjectName(promptText)}`;
        setModelName(name);
        setPipelineStage('completed');

        if (recordNewVersion) {
          await recordNewVersion(
            result.code,
            newGeom,
            promptText,
            'Generated from parametric template library',
            'INITIAL_GENERATION',
            null,
            undefined,
            undefined,
            undefined,
            undefined,
            options?.targetProject,
            undefined,
            undefined,
            undefined,
            undefined,
            undefined,
            'unverified'
          );
        }

        recordSuccessfulGeneration(
          result.generationId || thisGenId,
          promptText,
          result.code,
          newGeom,
          executed.parts || [],
          'template',
          false
        );
        return;
      }

      // Step 1: Understanding Design Intent & Requirements Extraction
      setPipelineStage('understanding_design');
      const extractionRes = await extractPromptRequirements(promptText, activeProjRefImages);
      const reqs = ensureCriticalOpenQuestions(extractionRes.requirements);
      setExtractedRequirements(reqs);

      const aiRecords: AIRequestRecord[] = [];
      if (extractionRes.diagnostics?.requestRecords) {
        aiRecords.push(...extractionRes.diagnostics.requestRecords);
      }

      const clarification = assessClarificationNeeds(reqs);
      const forceClarify = clarification.needsClarification && !options?.bypassSpecReview;
      const routineReview = !skipSpecReview && !options?.bypassSpecReview;

      if (forceClarify || routineReview) {
        setPipelineStage('review_spec');
        setIsGeneratingCad(false);
        setIsReviewingSpec(true);
        setForcedClarification(forceClarify && skipSpecReview);
        setPendingSpecPrompt(promptText);
        setPendingSpecOptions(options);
        return;
      }

      setForcedClarification(false);

      // Auto-advance only when confidence is high and skip is enabled
      const shouldExplore = options?.exploreApproaches ?? exploreApproaches;
      if (shouldExplore) {
        await triggerConceptVariantStage(promptText, reqs, reqs.userOverrides || [], options, aiRecords);
      } else {
        await executeCadGenerationPipeline(promptText, reqs, reqs.userOverrides || [], options, aiRecords);
      }
    } catch (err: any) {
      console.error('CAD requirements extraction failed:', err);
      setPipelineStage('error');
      setLastGenerationStatus('error');
      const userMsg = mapApiErrorMessage(err, (err as any)?.status);
      setCadErrorMessage(userMsg);
      setGenerationError({
        error: userMsg,
        errorCategory: err.errorCategory || 'UNKNOWN_ERROR',
        technicalDetails: err.technicalDetails || err.message,
        statusCode: err.status,
        canSimplifyToParametric: err.canSimplifyToParametric,
        requirements: err.requirements,
      });
      if (err.diagnostics || err.raw?.diagnostics) {
        setGenerationDiagnostics(err.diagnostics || err.raw.diagnostics);
      }
      setIsGeneratingCad(false);
    }
  };

  const triggerConceptVariantStage = async (
    promptText: string,
    reqs: ExtractedRequirements,
    userOverrides: string[] = [],
    options?: any,
    priorAiRecords: AIRequestRecord[] = []
  ) => {
    const activeProjRefImages = (options?.targetProject || activeProject)?.referenceImages;
    const cacheKey = `${promptText.trim().toLowerCase()}:::${reqs.objectName || ''}:::${reqs.overallDimensions?.width || 0}x${reqs.overallDimensions?.depth || 0}x${reqs.overallDimensions?.height || 0}:::${reqs.wallThicknessMm || 0}`;

    const existingProject = options?.targetProject || activeProject;
    const cached = existingProject?.conceptCache?.[cacheKey];

    setPendingConceptPrompt(promptText);
    setPendingConceptReqs(reqs);
    setPendingConceptUserOverrides(userOverrides);
    setPendingConceptOptions(options);
    setPendingConceptAiRecords(priorAiRecords);
    setIsReviewingSpec(false);

    if (cached && Array.isArray(cached) && cached.length > 0) {
      setConceptVariants(cached);
      setIsSelectingConcept(true);
      setPipelineStage('choose_approach');
      setIsGeneratingCad(false);
      return;
    }

    // Fetch from /api/generate-concepts
    setPipelineStage('choose_approach');
    setIsGeneratingCad(true);
    try {
      const res = await requestConceptVariants({
        prompt: promptText,
        requirements: reqs,
        referenceImages: activeProjRefImages,
      });
      if (res.diagnostics?.requestRecords) {
        priorAiRecords.push(...res.diagnostics.requestRecords);
      }
      if (res.concepts && Array.isArray(res.concepts) && res.concepts.length > 0) {
        // Save in conceptCache
        if (existingProject && persistActiveProject) {
          const updatedCache = {
            ...(existingProject.conceptCache || {}),
            [cacheKey]: res.concepts,
          };
          const updatedProject = {
            ...existingProject,
            conceptCache: updatedCache,
          };
          await persistActiveProject(updatedProject);
        }
        setConceptVariants(res.concepts);
        setIsSelectingConcept(true);
        setIsGeneratingCad(false);
        return;
      }
    } catch (conceptErr) {
      console.warn('Concept variant generation failed or was skipped, proceeding to direct CAD synthesis:', conceptErr);
    }

    // Fall back silently to direct CAD generation
    setIsSelectingConcept(false);
    await executeCadGenerationPipeline(promptText, reqs, userOverrides, options, priorAiRecords);
  };

  const handleSelectConcept = async (concept: DesignConcept) => {
    const baseReqs = pendingConceptReqs || extractedRequirements;
    if (!baseReqs) return;

    const mergedReqs: ExtractedRequirements = {
      ...baseReqs,
      ...(concept.specPatch || {}),
      designPlan: {
        ...(baseReqs.designPlan || {}),
        ...(concept.specPatch?.designPlan || {}),
        keyFeatures: [
          ...(concept.keyFeatures || []),
          ...(concept.specPatch?.designPlan?.keyFeatures || []),
        ],
      },
      functionalRequirements: [
        ...(baseReqs.functionalRequirements || []),
        ...(concept.specPatch?.functionalRequirements || []),
      ],
    };

    const updatedOverrides = [
      ...pendingConceptUserOverrides,
      `SELECTED STRATEGY: ${concept.name}. ${concept.approach}`,
      ...concept.keyFeatures.map((f) => `Feature constraint: ${f}`),
    ];

    setIsSelectingConcept(false);
    setExtractedRequirements(mergedReqs);
    await executeCadGenerationPipeline(
      pendingConceptPrompt,
      mergedReqs,
      updatedOverrides,
      pendingConceptOptions,
      pendingConceptAiRecords
    );
  };

  const handleCustomApproach = async (customDirectives: string) => {
    const baseReqs = pendingConceptReqs || extractedRequirements;
    if (!baseReqs) return;

    const updatedOverrides = [
      ...pendingConceptUserOverrides,
      `AUTHORITATIVE USER STRATEGY DIRECTIVE: ${customDirectives}`,
    ];

    setIsSelectingConcept(false);
    await executeCadGenerationPipeline(
      pendingConceptPrompt,
      baseReqs,
      updatedOverrides,
      pendingConceptOptions,
      pendingConceptAiRecords
    );
  };

  const handleSkipConceptSelection = async () => {
    const baseReqs = pendingConceptReqs || extractedRequirements;
    if (!baseReqs) return;

    setIsSelectingConcept(false);
    await executeCadGenerationPipeline(
      pendingConceptPrompt,
      baseReqs,
      pendingConceptUserOverrides,
      pendingConceptOptions,
      pendingConceptAiRecords
    );
  };

  const handleConfirmSpecAndGenerate = async (
    updatedReqs: ExtractedRequirements,
    userOverrides: string[]
  ) => {
    const promptToUse = pendingSpecPrompt || lastPrompt;
    const optionsToUse = pendingSpecOptions;
    const shouldExplore = optionsToUse?.exploreApproaches ?? exploreApproaches;

    setForcedClarification(false);
    if (shouldExplore) {
      setIsReviewingSpec(false);
      await triggerConceptVariantStage(promptToUse, updatedReqs, userOverrides, optionsToUse);
    } else {
      setIsReviewingSpec(false);
      await executeCadGenerationPipeline(promptToUse, updatedReqs, userOverrides, optionsToUse);
    }
  };

  const handleRegenerateSpec = async (
    updatedPrompt: string,
    _updatedReqs: ExtractedRequirements,
    userOverrides: string[]
  ) => {
    setIsRegeneratingSpec(true);
    setPipelineStage('understanding_design');
    try {
      const activeProjRefImages = activeProject?.referenceImages;
      const extractionRes = await extractPromptRequirements(updatedPrompt, activeProjRefImages);
      const refreshedReqs = extractionRes.requirements;
      refreshedReqs.userOverrides = Array.from(new Set([...(refreshedReqs.userOverrides || []), ...userOverrides]));
      setExtractedRequirements(refreshedReqs);
      setLastPrompt(updatedPrompt);
      setPendingSpecPrompt(updatedPrompt);
      setPipelineStage('review_spec');
      setIsReviewingSpec(true);
    } catch (err: any) {
      console.error('Failed to regenerate spec:', err);
      setPipelineStage('error');
      const userMsg = mapApiErrorMessage(err, (err as any)?.status);
      setCadErrorMessage(userMsg);
    } finally {
      setIsRegeneratingSpec(false);
    }
  };

  // Conversational Multi-Turn Revision Workflow
  const handleConversationalRevision = async (instruction: string) => {
    if (!activeProject) return;

    if (viewingVersionId && viewingVersionId !== activeProject.currentVersionId) {
      alert('Cannot modify historical versions directly. Please return to head or restore this version first.');
      return;
    }

    await executeDirectRevision(instruction);
  };

  const handleFixMissingFeatures = async (missingFeatures: string[]) => {
    if (!activeProject || missingFeatures.length === 0) return;
    if (viewingVersionId && viewingVersionId !== activeProject.currentVersionId) {
      alert('Cannot modify historical versions directly. Please return to head or restore this version first.');
      return;
    }
    setIsFixingFeatures(true);
    try {
      await handleConversationalRevision(`Add the missing required features: ${missingFeatures.join(', ')}`);
    } finally {
      setIsFixingFeatures(false);
    }
  };

  // Execute Direct Revision
  const executeDirectRevision = async (instruction: string) => {
    if (!activeProject) return;

    setIsRevisingCad(true);
    setCadErrorMessage(null);
    setGenerationError(null);
    setPipelineStage('generating_cad');

    try {
      const outcome = await applyRevisionToProject({
        project: activeProject,
        instruction,
        currentCode: currentJscadCode,
        selectedFilamentDensity: model.selectedFilament.densityGcm3,
        selectedFeatureIds: selectedFeatureIds.length > 0 ? selectedFeatureIds : selectedFeatureId ? [selectedFeatureId] : undefined,
        onStatusUpdate: (text) => setGenerationStatusText(text),
      });

      // Update 3D Geometry and set active head identity
      if (activateVersionGeometry) {
        const geomRes = activateVersionGeometry(outcome.newVersion, { head: true });
        if (!geomRes.success) {
          setLastGenerationStatus('error');
        }
      }

      // Update Active Project state and persist to IndexedDB
      if (persistActiveProject) {
        await persistActiveProject(outcome.updatedProject);
      }
      if (setViewingVersionId) {
        setViewingVersionId(null);
      }
      setPipelineStage('completed');
    } catch (err: any) {
      console.error('Revision error:', err);
      setPipelineStage('error');
      setLastGenerationStatus('error');
      const userMsg = mapApiErrorMessage(err, (err as any)?.status);
      setCadErrorMessage(userMsg);
      setGenerationError({
        error: userMsg,
        errorCategory: err.errorCategory || 'UNKNOWN_ERROR',
        technicalDetails: err.technicalDetails || err.message,
        statusCode: err.status,
      });
    } finally {
      setIsRevisingCad(false);
      setGenerationStatusText('');
    }
  };

  const handleExplainSlicerSettings = async () => {
    setIsExplainingSlicer(true);
    try {
      const explanation = await requestSlicerExplanation({
        settings: slicerSettings,
        geometry: geometryStats,
        printer: model.selectedPrinter,
        filament: model.selectedFilament,
        mustHoldLiquid: model.mustHoldLiquid,
        printabilityReport,
      });
      setSlicerExplanation(explanation);
    } catch (err: any) {
      console.error('Explanation request error:', err);
      setSlicerExplanation(
        'Calculated based on volumetric flow ceilings, perimeter requirements, and cooling constraints.'
      );
    } finally {
      setIsExplainingSlicer(false);
    }
  };

  const handleRetryLastPrompt = useCallback((options?: {
    useTemplate?: boolean;
    simplifyToParametric?: boolean;
    mode?: GenerationMode;
    targetProject?: KatPrintProject;
    bypassSpecReview?: boolean;
    exploreApproaches?: boolean;
  }) => {
    if (lastPrompt) {
      return handleGenerateJscad(lastPrompt, options);
    }
  }, [lastPrompt, handleGenerateJscad]);

  const handleTargetedRepair = useCallback(async (customPrompt?: string) => {
    if (customPrompt) {
      return handleConversationalRevision(customPrompt);
    }
    if (lastPrompt) {
      return handleGenerateJscad(lastPrompt);
    }
  }, [handleConversationalRevision, handleGenerateJscad, lastPrompt]);

  // Clear previous job / reset workspace for fresh design
  const handleClearJob = async () => {
    setLastPrompt('');
    setCadErrorMessage(null);
    setGenerationError(null);
    setGenerationDiagnostics(null);
    setValidationReport(null);
    setExtractedRequirements(null);
    setDesignSpecification(null);
    setDesignChecklist([]);
    setFidelityReviewResult(null);
    setIsReviewingSpec(false);
    setIsSelectingConcept(false);
    setPendingSpecPrompt('');
    setPendingConceptPrompt('');
    setLastGenerationStatus('idle');
    if (setViewingVersionId) setViewingVersionId(null);

    if (handleCreateBlankProject) {
      await handleCreateBlankProject('New Model');
    }
  };

  return {
    // State fields
    isGeneratingCad,
    setIsGeneratingCad,
    isRevisingCad,
    setIsRevisingCad,
    isFixingFeatures,
    setIsFixingFeatures,
    pipelineStage,
    setPipelineStage,
    repairAttempt,
    setRepairAttempt,
    generationStatusText,
    setGenerationStatusText,
    cadErrorMessage,
    setCadErrorMessage,
    generationError,
    setGenerationError,
    generationDiagnostics,
    setGenerationDiagnostics,
    generationId,
    setGenerationId,
    currentGenerationId,
    setCurrentGenerationId,
    activeGeometryGenerationId,
    setActiveGeometryGenerationId,
    lastGenerationStatus,
    setLastGenerationStatus,
    cadSource,
    setCadSource,
    lastPrompt,
    setLastPrompt,
    extractedRequirements,
    setExtractedRequirements,
    validationReport,
    setValidationReport,
    currentJscadCode,
    setCurrentJscadCode,
    activeGeometry,
    setActiveGeometry,
    modelName,
    setModelName,

    // Spec Review State
    skipSpecReview,
    setSkipSpecReview,
    isReviewingSpec,
    setIsReviewingSpec,
    isRegeneratingSpec,
    setIsRegeneratingSpec,
    pendingSpecPrompt,
    setPendingSpecPrompt,
    pendingSpecOptions,
    setPendingSpecOptions,
    forcedClarification,
    setForcedClarification,
    handleToggleSkipSpecReview,

    // Concept Variant State
    exploreApproaches,
    setExploreApproaches,
    isSelectingConcept,
    setIsSelectingConcept,
    conceptVariants,
    setConceptVariants,
    pendingConceptPrompt,
    setPendingConceptPrompt,
    pendingConceptReqs,
    setPendingConceptReqs,
    pendingConceptUserOverrides,
    setPendingConceptUserOverrides,
    pendingConceptOptions,
    setPendingConceptOptions,
    pendingConceptAiRecords,
    setPendingConceptAiRecords,
    handleToggleExploreApproaches,

    // Precision Engine State
    designSpecification,
    setDesignSpecification,
    designChecklist,
    setDesignChecklist,
    fidelityReviewResult,
    setFidelityReviewResult,

    // Slicer & Printability
    slicerExplanation,
    setSlicerExplanation,
    isExplainingSlicer,
    setIsExplainingSlicer,
    printabilityReport,
    setPrintabilityReport,
    isAnalyzingPrintability,
    setIsAnalyzingPrintability,

    // Records
    generationRecords,
    setGenerationRecords,
    currentGenerationRecord,
    setCurrentGenerationRecord,
    selectedRecordForModal,
    setSelectedRecordForModal,
    recordSuccessfulGeneration,
    handleSavePrintResult,
    handleReopenRecord,
    handleLoadLibraryExample,
    handleLogResultForRecord,

    // Primary Handlers & Aliases (generate, revise, repair, retry, explain)
    generate: handleGenerateJscad,
    handleGenerateJscad,
    executeCadGenerationPipeline,
    revise: executeDirectRevision,
    executeDirectRevision,
    handleConversationalRevision,
    handleFixMissingFeatures,
    repair: handleTargetedRepair,
    handleTargetedRepair,
    retry: handleRetryLastPrompt,
    handleRetryLastPrompt,
    explain: handleExplainSlicerSettings,
    handleExplainSlicerSettings,

    // Concept & Spec Handlers
    triggerConceptVariantStage,
    handleSelectConcept,
    handleCustomApproach,
    handleSkipConceptSelection,
    handleConfirmSpecAndGenerate,
    handleRegenerateSpec,
    handleClearJob,
    activateVersionGeometry,
  };
}
