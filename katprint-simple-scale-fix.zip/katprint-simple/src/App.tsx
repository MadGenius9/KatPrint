import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import * as THREE from 'three';
import {
  Printer,
  Flame,
  Layers,
  FileCode,
  Download,
  Upload,
  Droplets,
  Activity,
  Sliders,
  Settings,
  HelpCircle,
  Maximize2,
  Box,
  Image as ImageIcon,
  Camera,
  Cpu,
  ShieldCheck,
  FolderKanban,
  History,
  MessageSquare,
  Package,
  HardDrive,
  FlaskConical,
  GitBranch,
  Edit2,
  Check,
  X,
  Plus,
  Boxes,
  LayoutGrid,
  Loader2,
  Wand2,
  Bookmark,
  Flower2,
  RotateCcw,
} from 'lucide-react';

import {
  GenerationRecord,
  PrintResult,
  CadExample,
} from './types';
import { PrintResultModal } from './components/PrintResultModal';
import { GenerationHistoryModal } from './components/GenerationHistoryModal';
import { ExampleLibraryModal } from './components/ExampleLibraryModal';

import {
  PrinterSpec,
  FilamentSpec,
  ModelGeometryStats,
  PrinterFitResult,
  SlicerSettings,
  CreationMode,
  GenerationPipelineStage,
  ExtractedRequirements,
  DesignConcept,
  DesignValidationReport,
  GenerationError,
  GenerationDiagnostics,
  DesignSpecification,
  DesignCheck,
  FidelityReviewResult,
  GenerationMode,
  AIRequestRecord,
  ExecutedModelPart,
  ProjectReferenceImage,
  PrintabilityReport,
  DesignIntentAudit,
  RequirementCoverageReport,
  SemanticFeaturePlan,
  ProjectDesignState,
  PrecisionReviewProblem,
  ReferenceImageObservation,
} from './types';

import {
  KatPrintProject,
  ModelVersion,
  DesignConversationMessage,
  DesignChangeSet,
} from './projects/projectTypes';
import { projectRepository } from './projects/projectRepository';
import {
  createDefaultProject,
  createBlankProject,
  inferProjectName,
  getNextVersionNumber,
  createVersionLabel,
  duplicateProjectGraph,
  buildModelVersion,
} from './projects/projectService';
import {
  updateProjectMemoryFromVersion,
  initializeProjectDesignState,
  mergeDesignStateWithSpecification,
  partitionCachedReferenceImages,
  mergeReferenceImageObservations,
  attachObservationsToReferenceImages,
} from './projects/projectMemory';
import { buildGenerationDiagnostics } from './projects/generationDiagnostics';
import {
  applyRevisionToProject,
  applyDirectParameterUpdateToProject,
  applyBoundParameterChangesToProject,
  restoreVersionAsNewHead,
  branchNewVersion,
  parseRevisionInstruction,
} from './projects/revisionEngine';
import { exportProjectPackage } from './projects/projectSerializer';
import { sanitizeStlFilename } from './versions/versionService';
import {
  SemanticFeatureModel,
  planSemanticFeatureModel,
  planSemanticFeatureModelFromPlan,
  evaluateSemanticPlanCoverage,
  verifySemanticFeatureModel,
  finalizeFeatureModelForCode,
  reconstructLegacyFeatureModel,
  toggleParameterLock,
  shouldGenerateMultipleSemanticPlans,
  ManipulatorType,
  SemanticRevisionOpType,
} from './features';

import { FILAMENTS } from './data/filaments';
import { FIT_COUPON_JSCAD } from './engine/fitCoupon';
import { saveStoredPrinterOverride } from './storage/printerStorage';
import { analyzeBufferGeometry, exportBinarySTL } from './engine/geometryUtils';
import { getPhysicalPieceCount, hasMultiplePhysicalPieces, validateExecutedModelParts, downloadExportSTL } from './engine/stlExporter';
import { computeSlicerSettings, computePrinterFit, exportGCodeFile } from './engine/slicerEngine';
import { useModelState, EMPTY_GEOMETRY_STATS } from './hooks/useModelState';
import { useGeneration } from './hooks/useGeneration';
import { useProjectState } from './hooks/useProjectState';
import { useModals } from './hooks/useModals';
import { runPrintabilityAnalysisAsync } from './engine/clientPrintability';
import { executeJscadCode, executeJscadModel, DEFAULT_PLANTER_JSCAD } from './engine/jscadRunner';
import { generateCadThumbnail } from './engine/designVerification/renderInspectionViews';

import { ChatPanel } from './components/chat/ChatPanel';
import { OneJobViewerPanel } from './components/viewer/OneJobViewerPanel';
import { extractPromptRequirements } from './services/geminiService';
import { ensureCriticalOpenQuestions } from './engine/clarificationGate';
import { CameraCaptureModal, CapturedPhotoData } from './components/camera/CameraCaptureModal';
import { CustomPrinterModal } from './components/CustomPrinterModal';

export default function App() {
  // Navigation: Workspace vs Project Library
  const [navView, setNavView] = useState<'workspace' | 'projects'>('workspace');
  const [mobileTab, setMobileTab] = useState<'create' | 'viewer' | 'assistant' | 'print' | 'projects'>('create');
  const [rightPanelTab, setRightPanelTab] = useState<'design' | 'print' | 'versions'>('design');
  const [designPanelMode, setDesignPanelMode] = useState<'assistant' | 'feature'>('assistant');
  const [isHeaderMenuOpen, setIsHeaderMenuOpen] = useState(false);

  // Mode Selection
  const [mode, setMode] = useState<CreationMode>('describe');

  // Model State (Parts, Scale, Printer, Filament, Watertight, Fit)
  const model = useModelState();

  // Projects State & Persistence Hook
  const project = useProjectState();

  // Modals
  const { activeModal, openModal, closeModal } = useModals();

  // Proposed Changes Modal
  const [proposedChangeSet, setProposedChangeSet] = useState<DesignChangeSet | null>(null);
  const [pendingRevisionInstruction, setPendingRevisionInstruction] = useState<string | null>(null);
  const [isCameraModalOpen, setIsCameraModalOpen] = useState(false);
  const [experienceMode, setExperienceMode] = useState<'quick' | 'advanced'>('quick');

  // Multi-Part Assembly State
  const [explodedOffset, setExplodedOffset] = useState<number>(0);
  const [partVisibility, setPartVisibility] = useState<Record<string, boolean>>({});
  const [selectedPartId, setSelectedPartId] = useState<string | null>(null);

  const [selectedRecordForModal, setSelectedRecordForModal] = useState<GenerationRecord | null>(null);
  const [hasExportedStl, setHasExportedStl] = useState(false);

  const [printerCardCollapsed, setPrinterCardCollapsed] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('kf.printerCardCollapsed');
      if (saved !== null) return JSON.parse(saved);
      return typeof window !== 'undefined' ? window.innerWidth < 1024 : false;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('kf.printerCardCollapsed', JSON.stringify(printerCardCollapsed));
    } catch {
      // ignore
    }
  }, [printerCardCollapsed]);

  const [highlightOverhangs, setHighlightOverhangs] = useState<boolean>(true);
  const handleToggleOverhangs = useCallback(() => setHighlightOverhangs((v) => !v), []);

  // STL Export Generation State
  const [stlExportProgress, setStlExportProgress] = useState<number | null>(null);

  // Semantic 3D Feature Selection
  const [selectedFeatureId, setSelectedFeatureId] = useState<string | null>(null);
  const [selectedFeatureIds, setSelectedFeatureIds] = useState<string[]>([]);
  const [debugShowPickProxies, setDebugShowPickProxies] = useState<boolean>(false);
  const [focusTarget, setFocusTarget] = useState<{ featureId: string; nonce: number } | null>(null);

  const handleSelectFeature = useCallback((featureId: string | null) => {
    setSelectedFeatureId(featureId);
    setSelectedFeatureIds(featureId ? [featureId] : []);
    if (featureId) {
      // Auto-open features tab to display parameters immediately upon 3D click
      setRightPanelTab('design');
      setDesignPanelMode('feature');
    }
  }, []);

  const handleMultiSelectFeatures = useCallback((featureIds: string[]) => {
    setSelectedFeatureIds(featureIds);
    setSelectedFeatureId(featureIds[featureIds.length - 1] || null);
    if (featureIds.length > 0) {
      setRightPanelTab('design');
      setDesignPanelMode('feature');
    }
  }, []);

  const handleFocusFeature = useCallback((featureId: string) => {
    setFocusTarget({ featureId, nonce: Date.now() });
  }, []);

  // Left panel scroll affordance fade state
  const leftPanelScrollRef = useRef<HTMLDivElement>(null);
  const [showLeftPanelScrollFade, setShowLeftPanelScrollFade] = useState<boolean>(false);

  const slicerSettingsRef = useRef<SlicerSettings>();

  // Generation Hook: encapsulates entire CAD generation, revision, review, repair, and logging pipeline
  const generation = useGeneration({
    model,
    activeProject: project.activeProject,
    referenceImages: project.referenceImages,
    currentActiveVersion: project.currentActiveVersion,
    viewingVersionId: project.viewingVersionId,
    selectedFeatureId,
    selectedFeatureIds,
    setMobileTab,
    setViewingVersionId: project.setViewingVersionId,
    setEditableTitle: project.setEditableTitle,
    setRightPanelTab,
    setHasExportedStl,
    recordNewVersion: project.recordNewVersion,
    persistActiveProject: project.persistActiveProject,
    getSlicerSettings: () => slicerSettingsRef.current,
    setProposedChangeSet,
    setPendingRevisionInstruction,
    handleCreateBlankProject: async (name) => {
      await project.handleCreateBlankProject(name);
    },
  });

  const {
    currentJscadCode,
    setCurrentJscadCode,
    activeGeometry,
    setActiveGeometry,
    modelName,
    setModelName,
    isGeneratingCad,
    setIsGeneratingCad,
    isRevisingCad,
    setIsRevisingCad,
    isFixingFeatures,
    setIsFixingFeatures,
    pipelineStage,
    setPipelineStage,
    repairAttempt,
    setRepairAttempt,
    generationStatusText,
    setGenerationStatusText,
    cadErrorMessage,
    setCadErrorMessage,
    generationError,
    setGenerationError,
    generationDiagnostics,
    setGenerationDiagnostics,
    generationId,
    setGenerationId,
    currentGenerationId,
    setCurrentGenerationId,
    activeGeometryGenerationId,
    setActiveGeometryGenerationId,
    lastGenerationStatus,
    setLastGenerationStatus,
    cadSource,
    setCadSource,
    lastPrompt,
    setLastPrompt,
    extractedRequirements,
    setExtractedRequirements,
    validationReport,
    setValidationReport,
    skipSpecReview,
    setSkipSpecReview,
    handleToggleSkipSpecReview,
    forcedClarification,
    isReviewingSpec,
    setIsReviewingSpec,
    isRegeneratingSpec,
    setIsRegeneratingSpec,
    pendingSpecPrompt,
    setPendingSpecPrompt,
    exploreApproaches,
    setExploreApproaches,
    handleToggleExploreApproaches,
    isSelectingConcept,
    setIsSelectingConcept,
    conceptVariants,
    setConceptVariants,
    pendingConceptReqs,
    pendingConceptPrompt,
    designSpecification,
    setDesignSpecification,
    designChecklist,
    setDesignChecklist,
    fidelityReviewResult,
    setFidelityReviewResult,
    slicerExplanation,
    setSlicerExplanation,
    isExplainingSlicer,
    setIsExplainingSlicer,
    printabilityReport,
    setPrintabilityReport,
    isAnalyzingPrintability,
    setIsAnalyzingPrintability,
    generationRecords,
    setGenerationRecords,
    currentGenerationRecord,
    setCurrentGenerationRecord,
    recordSuccessfulGeneration,
    handleSavePrintResult,
    handleReopenRecord,
    handleLoadLibraryExample,
    handleGenerateJscad,
    executeCadGenerationPipeline,
    executeDirectRevision,
    handleConversationalRevision,
    handleFixMissingFeatures,
    handleTargetedRepair,
    handleRetryLastPrompt,
    handleExplainSlicerSettings,
    triggerConceptVariantStage,
    handleSelectConcept,
    handleCustomApproach,
    handleSkipConceptSelection,
    handleConfirmSpecAndGenerate,
    handleRegenerateSpec,
    handleClearJob: genClearJob,
    activateVersionGeometry,
  } = generation;

  useEffect(() => {
    const el = leftPanelScrollRef.current;
    if (!el) return;

    let rafId: number | null = null;

    const checkScroll = () => {
      if (rafId !== null) return;
      rafId = requestAnimationFrame(() => {
        rafId = null;
        if (!el) return;
        const hasOverflow = el.scrollHeight > el.clientHeight + 4;
        const isAtBottom = el.scrollHeight - el.scrollTop - el.clientHeight <= 8;
        setShowLeftPanelScrollFade(hasOverflow && !isAtBottom);
      });
    };

    checkScroll();
    el.addEventListener('scroll', checkScroll, { passive: true });

    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => checkScroll());
      ro.observe(el);
    }

    return () => {
      if (rafId !== null) cancelAnimationFrame(rafId);
      el.removeEventListener('scroll', checkScroll);
      if (ro) ro.disconnect();
    };
  }, [navView, mode, isReviewingSpec, isSelectingConcept, printerCardCollapsed, currentJscadCode, project.activeProject]);

  // Centralized project activation & geometry validation
  const activateProject = useCallback(
    (proj: KatPrintProject) => {
      if (!proj) return;
      project.activateProject(proj);
      project.setEditableTitle(proj.name);
      setModelName(proj.name);
      project.setViewingVersionId(null);

      // Validate & restore hardware configuration
      if (proj.projectSettings) {
        const validPrinter = model.printers.some((p) => p.id === proj.projectSettings.printerId);
        const targetPrinterId = validPrinter ? proj.projectSettings.printerId : 'bambu-x1c';
        model.setSelectedPrinterId(targetPrinterId);

        const validFilament = FILAMENTS.some((f) => f.id === proj.projectSettings.filamentId);
        const targetFilamentId = validFilament ? proj.projectSettings.filamentId : 'pla';
        model.setSelectedFilamentId(targetFilamentId);

        if (typeof proj.projectSettings.scaleFactor === 'number') {
          model.setScaleFactor(proj.projectSettings.scaleFactor);
        }
        if (typeof proj.projectSettings.mustHoldLiquid === 'boolean') {
          model.setMustHoldLiquid(proj.projectSettings.mustHoldLiquid);
        }
      }

      const versions = proj.versions || [];
      const currentVer =
        versions.find((v) => v.id === proj.currentVersionId) || versions[versions.length - 1];
      if (currentVer) {
        activateVersionGeometry(currentVer, { head: true });
      }
    },
    [project, model, activateVersionGeometry, setModelName]
  );

  // Update active project's generation mode and persist
  const handleGenerationModeChange = async (newMode: GenerationMode) => {
    await project.handleGenerationModeChange(newMode);
  };

  // Sync 3D geometry when project or active version loads/changes
  const lastActivatedVersionKeyRef = useRef<string | null>(null);

  useEffect(() => {
    const ver = project.currentActiveVersion;
    if (!ver) return;
    const isHead = !project.viewingVersionId || project.viewingVersionId === project.activeProject?.currentVersionId;
    const key = `${ver.id}:${isHead}`;
    if (lastActivatedVersionKeyRef.current === key) {
      return;
    }
    lastActivatedVersionKeyRef.current = key;
    activateVersionGeometry(ver, { head: isHead });
  }, [project.currentActiveVersion?.id, project.viewingVersionId, activateVersionGeometry, project.activeProject?.currentVersionId]);

  const lastAppliedProjectSettingsRef = useRef<string | null>(null);

  useEffect(() => {
    if (project.activeProject) {
      const ps = project.activeProject.projectSettings;
      const settingsKey = `${project.activeProject.id}:${project.activeProject.name}:${ps?.printerId}:${ps?.filamentId}:${ps?.scaleFactor}:${ps?.mustHoldLiquid}`;
      if (lastAppliedProjectSettingsRef.current === settingsKey) {
        return;
      }
      lastAppliedProjectSettingsRef.current = settingsKey;

      setModelName((prev) => (prev !== project.activeProject!.name ? project.activeProject!.name : prev));
      if (ps) {
        if (ps.printerId && model.printers.some((p) => p.id === ps.printerId) && model.selectedPrinterId !== ps.printerId) {
          model.setSelectedPrinterId(ps.printerId);
        }
        if (ps.filamentId && model.selectedFilamentId !== ps.filamentId) {
          model.setSelectedFilamentId(ps.filamentId);
        }
        if (typeof ps.scaleFactor === 'number' && model.scaleFactor !== ps.scaleFactor) {
          model.setScaleFactor(ps.scaleFactor);
        }
        if (typeof ps.mustHoldLiquid === 'boolean' && model.mustHoldLiquid !== ps.mustHoldLiquid) {
          model.setMustHoldLiquid(ps.mustHoldLiquid);
        }
      }
    }
  }, [
    project.activeProject?.id,
    project.activeProject?.name,
    project.activeProject?.projectSettings?.printerId,
    project.activeProject?.projectSettings?.filamentId,
    project.activeProject?.projectSettings?.scaleFactor,
    project.activeProject?.projectSettings?.mustHoldLiquid,
  ]);

  // Reconcile 3D feature selection when active version or feature model changes
  useEffect(() => {
    const featModel = project.currentActiveVersion?.featureModel;
    if (!featModel || !Array.isArray(featModel.features)) {
      setSelectedFeatureId((prev) => (prev !== null ? null : prev));
      setSelectedFeatureIds((prev) => (prev.length > 0 ? [] : prev));
      return;
    }

    const validFeatureIds = new Set(featModel.features.map((f) => f.id));
    setSelectedFeatureIds((prev) => {
      const nextSelectedIds = prev.filter((id) => validFeatureIds.has(id));
      if (nextSelectedIds.length === prev.length && nextSelectedIds.every((id, i) => id === prev[i])) {
        return prev;
      }
      return nextSelectedIds;
    });

    setSelectedFeatureId((prev) => {
      const isPrimaryValid = prev ? validFeatureIds.has(prev) : false;
      if (isPrimaryValid) return prev;
      return null;
    });
  }, [project.currentActiveVersion?.id, project.currentActiveVersion?.featureModel]);

  // Volumetric & Overhang stats
  const geometryStats: ModelGeometryStats = useMemo(() => {
    if (!activeGeometry) {
      return EMPTY_GEOMETRY_STATS;
    }
    return analyzeBufferGeometry(activeGeometry, model.selectedFilament.densityGcm3);
  }, [activeGeometry, model.selectedFilament.densityGcm3]);

  // Live Printer Fit Check computed directly from geometryStats without useEffect synchronization cycles
  const printerFitResult: PrinterFitResult = useMemo(() => {
    return computePrinterFit(
      geometryStats,
      model.selectedPrinter,
      model.scaleFactor,
      model.currentParts
    );
  }, [geometryStats, model.selectedPrinter, model.scaleFactor, model.currentParts]);

  // Slicer Settings Engine
  const slicerSettings: SlicerSettings = useMemo(() => {
    return computeSlicerSettings(
      geometryStats,
      model.selectedPrinter,
      model.selectedFilament,
      model.scaleFactor,
      model.mustHoldLiquid,
      printabilityReport || undefined
    );
  }, [geometryStats, model.selectedPrinter, model.selectedFilament, model.scaleFactor, model.mustHoldLiquid, printabilityReport]);

  slicerSettingsRef.current = slicerSettings;

  // Centralized Export Validation Guard
  const exportValidation = useMemo(() => {
    if (!activeGeometry && (!model.currentParts || model.currentParts.length === 0)) {
      return { allowed: false, reason: 'No active 3D model geometry loaded.' };
    }
    if (isGeneratingCad || isRevisingCad) {
      return {
        allowed: false,
        reason: 'Generation in progress — export will be available once rendering completes.',
      };
    }
    const hasParts = model.currentParts && model.currentParts.length > 0;
    const triangles = geometryStats?.triangleCount || 0;
    if (!hasParts && triangles <= 0) {
      return { allowed: false, reason: 'Model has no mesh polygons/triangles.' };
    }
    if (hasMultiplePhysicalPieces(model.currentParts)) {
      const partValidation = validateExecutedModelParts(model.currentParts);
      if (!partValidation.valid && (!activeGeometry || (geometryStats?.triangleCount || 0) <= 0)) {
        const first = partValidation.invalidParts[0];
        return {
          allowed: false,
          reason: `STL export blocked: ${first?.partName || 'A part'} ${first?.reason || 'is invalid'}.`,
        };
      }
    }
    return { allowed: true, reason: '' };
  }, [activeGeometry, geometryStats, isGeneratingCad, isRevisingCad, model.currentParts]);

  const handleLogResultForRecord = useCallback(
    (record: GenerationRecord) => {
      setSelectedRecordForModal(record);
      openModal('printResult');
    },
    [openModal]
  );

  // Handle Natural Language Undo / Rollback
  const handleRollbackLastRevision = async () => {
    const restored = await project.handleRollbackLastRevision();
    if (restored) {
      activateVersionGeometry(restored, { head: true });
    }
  };

  // Handle Direct 3D Manipulation Commits (dragging gizmos, hole dragging, spacing adjustments)
  const handleManipulationCommit = async (params: {
    featureId: string;
    featureIds?: string[];
    manipulatorId: string;
    manipulatorType: ManipulatorType;
    parameterChanges: Array<{
      parameterId: string;
      newValue: number | string | boolean;
      oldValue?: number | string | boolean;
      unit?: string;
    }>;
    instructionSummary?: string;
  }) => {
    const outcome = await project.handleManipulationCommit({
      ...params,
      selectedFilamentDensity: model.selectedFilament.densityGcm3,
    });
    if (outcome?.newVersion) {
      const geomRes = activateVersionGeometry(outcome.newVersion, { head: true });
      if (!geomRes.success) {
        setLastGenerationStatus('error');
      }
    }
  };

  // Restore previous version (Non-destructive new head)
  const handleRestoreVersion = async (version: ModelVersion) => {
    const newHead = await project.handleRestoreVersion(version);
    if (newHead) {
      activateVersionGeometry(newHead, { head: true });
    }
  };

  // Branch new version from an existing version
  const handleBranchVersion = async (version: ModelVersion) => {
    const newBranch = await project.handleBranchVersion(version);
    if (newBranch) {
      activateVersionGeometry(newBranch, { head: true });
    }
  };

  // Return to Head version
  const handleReturnToHead = useCallback(() => {
    const head = project.handleReturnToHead();
    if (head) {
      activateVersionGeometry(head, { head: true });
    }
  }, [project, activateVersionGeometry]);

  // Inspect previous version in 3D viewer without changing head
  const handleSelectVersionForViewing = (version: ModelVersion) => {
    project.handleSelectVersionForViewing(version);
    activateVersionGeometry(version, { head: false });
  };

  // Version Comparison modal
  const handleCompareVersions = (versionA: ModelVersion, versionB: ModelVersion) => {
    project.handleCompareVersions(versionA, versionB);
    openModal('comparison');
  };

  // Rename a specific version's label
  const handleRenameVersionLabel = async (versionId: string, newLabel: string) => {
    await project.handleRenameVersionLabel(versionId, newLabel);
  };

  // Export STL for a specific version in timeline
  const handleExportVersionStl = (version: ModelVersion) => {
    project.handleExportVersionStl(version, model.scaleFactor);
  };

  // View diagnostics & fidelity details for a specific version
  const handleViewVersionDiagnostics = (version: ModelVersion) => {
    if (version.generationDiagnostics) {
      setGenerationDiagnostics(version.generationDiagnostics);
    }
    if (version.fidelityReview) {
      setFidelityReviewResult(version.fidelityReview);
    }
    if (version.designSpecification) {
      setDesignSpecification(version.designSpecification);
    }
    if (version.designChecklist) {
      setDesignChecklist(version.designChecklist);
    }
    handleSelectVersionForViewing(version);
    setRightPanelTab('print');
  };

  // Create brand new project from user prompt
  const handleCreateNewProject = async (prompt: string, customName?: string) => {
    const promptText = prompt.trim() || '100 mm × 60 mm × 25 mm electronics enclosure with 3 mm walls and removable top lid';
    const newProj = createDefaultProject(promptText);
    if (customName && customName.trim()) {
      newProj.name = customName.trim();
    }

    await projectRepository.saveProject(newProj);
    const all = await projectRepository.listProjects();
    project.setProjects(all);
    activateProject(newProj);
    setNavView('workspace');

    // Generate initial CAD for the new project passing targetProject directly to avoid race conditions
    handleGenerateJscad(promptText, {
      mode: newProj.projectSettings?.generationMode || 'precision',
      targetProject: newProj,
    });
  };

  // Clear previous job / reset workspace for fresh design
  const handleClearJob = async () => {
    setSelectedFeatureId(null);
    setSelectedFeatureIds([]);
    setProposedChangeSet(null);
    project.setViewingVersionId(null);
    await genClearJob();
  };

  // Create empty / blank project without initial AI generation
  const handleCreateBlankProject = async (customName?: string) => {
    const blank = await project.handleCreateBlankProject(customName);
    activateProject(blank);
    setNavView('workspace');
    setMobileTab('create');
  };

  // Select project from library
  const handleSelectProject = (proj: KatPrintProject) => {
    if (!proj) return;
    activateProject(proj);
    setNavView('workspace');
    setMobileTab('viewer');
  };

  // Update printer and persist to project settings
  const handlePrinterChange = async (printerId: string) => {
    model.setSelectedPrinterId(printerId);
    await project.handlePrinterChange(printerId);
  };

  // Update filament and persist to project settings
  const handleFilamentChange = async (filamentId: string) => {
    model.setSelectedFilamentId(filamentId);
    await project.handleFilamentChange(filamentId);
  };

  // Update scale factor and persist to project settings
  const handleScaleFactorChange = async (scale: number) => {
    model.setScaleFactor(scale);
    await project.handleScaleFactorChange(scale);
  };

  // Update watertight mode and persist to project settings
  const handleMustHoldLiquidChange = async (enabled: boolean) => {
    model.setMustHoldLiquid(enabled);
    await project.handleMustHoldLiquidChange(enabled);
  };

  // Delete project
  const handleDeleteProject = async (target: string | KatPrintProject) => {
    await project.handleDeleteProject(target);
  };

  // Duplicate project
  const handleDuplicateProject = async (proj: KatPrintProject) => {
    await project.handleDuplicateProject(proj);
  };

  // Project rename action
  const handleRenameProject = async (proj: KatPrintProject, newName: string) => {
    await project.handleRenameProject(proj, newName);
    setModelName(newName.trim() || proj.name);
  };

  // Favorite toggle
  const handleToggleFavorite = async (target: string | KatPrintProject) => {
    await project.handleToggleFavorite(target);
  };

  // Export project package archive
  const handleExportKatPrint = (proj?: KatPrintProject) => {
    project.handleExportKatPrint(proj);
  };

  // Import .katprint project package
  const handleImportKatPrint = async (fileContent: string) => {
    const imported = await project.handleImportKatPrint(fileContent);
    if (imported) {
      activateProject(imported);
      setNavView('workspace');
    }
  };

  // Save renamed title
  const handleSaveTitle = async () => {
    await project.handleSaveTitle();
    if (project.editableTitle.trim()) {
      setModelName(project.editableTitle.trim());
    }
  };

  const handleUpdateFeatureParameter = async (
    parameterId: string,
    newValue: number | string | boolean
  ) => {
    const newHead = await project.handleUpdateFeatureParameter(
      parameterId,
      newValue,
      model.selectedFilament.densityGcm3
    );
    if (newHead) {
      activateVersionGeometry(newHead, { head: true });
    }
  };

  // Reconstruct Feature Model for Legacy Versions
  const handleReconstructFeatureModel = async () => {
    await project.handleReconstructFeatureModel(currentJscadCode, geometryStats);
  };

  // Toggle Parameter Lock
  const handleToggleLockParameter = async (parameterId: string, currentLocked: boolean) => {
    await project.handleToggleLockParameter(parameterId, currentLocked);
  };

  // Code editor update
  const handleCodeUpdate = useCallback((newCode: string) => {
    const thisGenId = `gen_manual_${Date.now()}`;
    setCurrentGenerationId(thisGenId);
    setCurrentJscadCode(newCode);
    try {
      const executed = executeJscadModel(newCode);
      setActiveGeometry(executed.combinedGeometry);
      model.setCurrentParts(executed.parts || []);
      setActiveGeometryGenerationId(thisGenId);
      setLastGenerationStatus('success');
      setCadErrorMessage(null);
    } catch (err: any) {
      setLastGenerationStatus('error');
      setCadErrorMessage(err?.message || 'Syntax error in JSCAD script.');
    }
  }, []);

  // Update Reference Images for Active Project
  const handleUpdateReferenceImages = async (images: ProjectReferenceImage[]) => {
    await project.handleUpdateReferenceImages(images);
  };

  // Mode 2 & Mode 3 outputs
  const handleExternalGeometry = useCallback((geom: THREE.BufferGeometry) => {
    const thisGenId = `gen_ext_${Date.now()}`;
    setCurrentGenerationId(thisGenId);
    setActiveGeometry(geom);
    setActiveGeometryGenerationId(thisGenId);
    setLastGenerationStatus('success');
    setSlicerExplanation(null);
  }, []);

  // Reorient model to optimal orientation
  const handleApplySuggestedOrientation = useCallback(async (rotDeg: [number, number, number]) => {
    const instruction = `Reorient the 3D model geometry by rotating [${rotDeg[0]}°, ${rotDeg[1]}°, ${rotDeg[2]}°] around the origin and translating so its minimum Z rests flat on the Z=0 build plate.`;
    await handleConversationalRevision(instruction);
  }, [handleConversationalRevision]);

  // Custom Printer Update
  const handleSaveCustomPrinter = (updated: PrinterSpec) => {
    saveStoredPrinterOverride(updated.id, updated);
    model.setPrinters((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    model.setSelectedPrinterId(updated.id);
  };

  // Fit Test Coupon Loading & Clearance Persistence
  const handleLoadFitCoupon = useCallback(() => {
    const thisGenId = `gen_fit_coupon_${Date.now()}`;
    setCurrentGenerationId(thisGenId);
    setCurrentJscadCode(FIT_COUPON_JSCAD);
    try {
      const executed = executeJscadModel(FIT_COUPON_JSCAD);
      setActiveGeometry(executed.combinedGeometry);
      model.setCurrentParts(executed.parts || []);
      setActiveGeometryGenerationId(thisGenId);
      setModelName('Fit Test Coupon');
      project.setEditableTitle('Fit Test Coupon');
      setLastGenerationStatus('success');
      setCadErrorMessage(null);
    } catch (err: any) {
      console.error('Failed to execute fit coupon geometry:', err);
    }
  }, []);

  const handleSaveFitTestClearance = useCallback((printerId: string, clearanceMm: number, filamentId: string) => {
    const measuredAt = new Date().toISOString().slice(0, 10);
    const patch: Partial<PrinterSpec> = {
      measuredClearanceMm: clearanceMm,
      clearanceMeasuredAt: measuredAt,
      clearanceFilamentId: filamentId,
    };
    saveStoredPrinterOverride(printerId, patch);
    model.setPrinters((prev) => prev.map((p) => (p.id === printerId ? { ...p, ...patch } : p)));
  }, []);

  // One-job Chat & Clarification State
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const handleClearCapturedPhoto = useCallback(() => setCapturedPhoto(null), []);
  const [clarificationQuestionsToAsk, setClarificationQuestionsToAsk] = useState<Array<{
    id: string;
    question: string;
    category: 'size' | 'fit' | 'mount';
    suggestedOptions: string[];
  }> | null>(null);
  const [pendingPromptForClarification, setPendingPromptForClarification] = useState<string | null>(null);
  const [pendingReqsForClarification, setPendingReqsForClarification] = useState<ExtractedRequirements | null>(null);

  const handleChatSendMessage = async (
    promptText: string,
    photoDataUrl?: string,
    photoMode?: 'relief' | 'reference'
  ) => {
    const promptTrimmed = promptText.trim().toLowerCase();

    // Check if the message names a new object or includes mm sizes (treat as new generate)
    const newObjectRegex = /\b(tray|trays|stand|stands|bracket|brackets|box|boxes|enclosure|enclosures|holder|holders|organizer|organizers|hanger|hangers)\b/i;
    const namesNewObject = newObjectRegex.test(promptText);
    const includesMmSize = /\d+(\.\d+)?\s*mm\b/i.test(promptText);
    const isNewPart = namesNewObject || includesMmSize;

    // Tweak = starts like: make it, make the, add, remove, wider, taller, shorter, thicker, thinner, increase, decrease, change, move, fillet, round, undo
    const tweakStarters = [
      'make it',
      'make the',
      'add',
      'remove',
      'wider',
      'taller',
      'shorter',
      'thicker',
      'thinner',
      'increase',
      'decrease',
      'change',
      'move',
      'fillet',
      'round',
      'undo',
    ];
    const startsLikeTweak = tweakStarters.some((prefix) => {
      if (promptTrimmed === prefix) return true;
      if (prefix.includes(' ')) {
        return promptTrimmed.startsWith(prefix);
      }
      return (
        promptTrimmed.startsWith(prefix + ' ') ||
        promptTrimmed.startsWith(prefix + ',') ||
        promptTrimmed.startsWith(prefix + '.') ||
        promptTrimmed.startsWith(prefix + '-')
      );
    });

    const isTweak = startsLikeTweak && !isNewPart;

    // Only call handleConversationalRevision when ALL of these are true:
    // - activeGeometry exists
    // - activeProject.currentVersionId exists
    // - the message is a tweak, not a new part
    if (activeGeometry && project.activeProject?.currentVersionId && isTweak) {
      await handleConversationalRevision(promptText);
      return;
    }

    if (photoDataUrl && photoMode === 'reference') {
      const refImg: ProjectReferenceImage = {
        id: `photo_${Date.now()}`,
        dataUrl: photoDataUrl,
        fileName: 'reference_photo.jpg',
        mimeType: 'image/jpeg',
        role: 'front',
        createdAt: new Date().toISOString(),
      };
      if (project.activeProject) {
        handleUpdateReferenceImages([...(project.activeProject.referenceImages || []), refImg]);
      }
    }

    try {
      const res = await extractPromptRequirements(promptText, project.activeProject?.referenceImages);
      const reqs = ensureCriticalOpenQuestions(res.requirements);
      setExtractedRequirements(reqs);

      const dims = reqs.overallDimensions || {};
      const hasAnyDim =
        dims.width != null ||
        dims.depth != null ||
        dims.height != null ||
        dims.diameter != null ||
        dims.length != null;
      const promptLower = promptText.toLowerCase();

      const questions: Array<{
        id: string;
        question: string;
        category: 'size' | 'fit' | 'mount';
        suggestedOptions: string[];
      }> = [];

      // 1. Size check
      if (!hasAnyDim && !reqs.referenceObject) {
        questions.push({
          id: 'q_size',
          question: 'What overall dimensions (W × D × H in mm) do you need?',
          category: 'size',
          suggestedOptions: ['120 × 80 × 25 mm', '150 × 100 × 40 mm', '80 × 50 × 20 mm'],
        });
      }

      // 2. Fit check
      const fitKeywords = ['phone', 'cable', 'charger', 'pen', 'tool', 'battery', 'fit', 'snug', 'loose', 'insert', 'slot'];
      if (fitKeywords.some((k) => promptLower.includes(k)) || reqs.referenceObject) {
        questions.push({
          id: 'q_fit',
          question: 'What tolerance or fit do you prefer?',
          category: 'fit',
          suggestedOptions: ['Standard clearance (0.3mm)', 'Snug friction-fit (0.15mm)', 'Loose drop-in (0.6mm)'],
        });
      }

      // 3. Mount check
      const mountKeywords = ['bracket', 'mount', 'hanger', 'holder', 'stand', 'wall', 'desk'];
      if (mountKeywords.some((k) => promptLower.includes(k))) {
        questions.push({
          id: 'q_mount',
          question: 'How should this part be positioned or mounted?',
          category: 'mount',
          suggestedOptions: ['Freestanding on desk', 'M4 countersunk screw holes', 'Snap-fit / Adhesive'],
        });
      }

      const finalQuestions = questions.slice(0, 3);

      if (finalQuestions.length > 0) {
        setPendingPromptForClarification(promptText);
        setPendingReqsForClarification(reqs);
        setClarificationQuestionsToAsk(finalQuestions);
        return;
      }

      setPendingPromptForClarification(null);
      setPendingReqsForClarification(null);
      setClarificationQuestionsToAsk(null);

      await handleGenerateJscad(promptText, {
        bypassSpecReview: true,
        exploreApproaches: false,
        mode: 'precision',
      });
    } catch (err: any) {
      const realError = err instanceof Error ? err.message : String(err || 'Failed to extract requirements');
      setCadErrorMessage(realError);
    }
  };

  const handleChatAnswerClarification = async (answers: Record<string, string>, useDefaults: boolean) => {
    const basePrompt = pendingPromptForClarification || lastPrompt;
    let enrichedPrompt = basePrompt;

    if (!useDefaults && Object.keys(answers).length > 0) {
      const answersText = Object.values(answers).join(', ');
      enrichedPrompt = `${basePrompt}. Key parameters: ${answersText}`;
    }

    setPendingPromptForClarification(null);
    setPendingReqsForClarification(null);
    setClarificationQuestionsToAsk(null);

    await handleGenerateJscad(enrichedPrompt, {
      bypassSpecReview: true,
      exploreApproaches: false,
      mode: 'precision',
    });
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-kf-bg text-kf-text font-sans overflow-hidden">
      {/* 1. TOP HEADER / BRAND */}
      <header className="h-13 bg-kf-panel border-b border-kf-border px-4 flex items-center justify-between shrink-0 z-40 font-sans">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="flex items-center gap-2 shrink-0">
            <Flower2 className="w-5 h-5 text-kf-pink" />
            <span className="font-display font-bold text-sm tracking-[0.14em] uppercase text-kf-text">
              KatPrint
            </span>
          </div>
          <div className="h-4 w-px bg-kf-border hidden sm:block shrink-0" />
          <span className="text-xs font-mono text-kf-muted hidden sm:inline truncate max-w-[240px]">
            {modelName || 'Parametric 3D Part'}
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setIsCameraModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded border border-kf-border bg-kf-panel-2 hover:border-kf-pink/50 text-kf-text text-xs font-mono transition cursor-pointer"
            title="Capture reference photo with camera"
          >
            <Camera className="w-3.5 h-3.5 text-kf-pink" />
            <span className="hidden sm:inline">Camera</span>
          </button>
          <button
            type="button"
            onClick={() => {
              handleClearJob();
              setClarificationQuestionsToAsk(null);
              setPendingPromptForClarification(null);
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded border border-kf-border bg-kf-panel-2 hover:border-kf-pink/50 text-kf-muted hover:text-kf-pink text-xs font-mono transition cursor-pointer"
            title="Start a new 3D part"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>New Part</span>
          </button>
        </div>
      </header>

      {/* 2. MAIN ONE-JOB WORKSPACE: LEFT CHAT + RIGHT 3D VIEWER */}
      <main className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden relative">
        {/* Left: Chat Only */}
        <div
          className={`${
            mobileTab === 'create' || mobileTab === 'assistant' ? 'flex' : 'hidden'
          } lg:flex w-full lg:w-[440px] xl:w-[480px] shrink-0 border-r border-kf-border flex-col h-full bg-kf-panel z-10`}
        >
          <ChatPanel
            onSendMessage={handleChatSendMessage}
            onAnswerClarification={handleChatAnswerClarification}
            onResetChat={() => {
              handleClearJob();
              setClarificationQuestionsToAsk(null);
              setPendingPromptForClarification(null);
            }}
            isGeneratingCad={isGeneratingCad || isRevisingCad}
            pipelineStage={pipelineStage}
            generationStatusText={generationStatusText}
            cadErrorMessage={cadErrorMessage}
            activeGeometry={activeGeometry}
            geometryStats={geometryStats}
            modelName={modelName}
            extractedRequirements={extractedRequirements}
            onOpenCamera={() => setIsCameraModalOpen(true)}
            capturedPhoto={capturedPhoto}
            onClearCapturedPhoto={handleClearCapturedPhoto}
            onApplyGeometry={handleExternalGeometry}
            clarificationQuestionsToAsk={clarificationQuestionsToAsk}
          />
        </div>

        {/* Right: 3D Viewer + Printability + Download STL */}
        <div
          className={`${
            mobileTab === 'viewer' || mobileTab === 'print' ? 'flex' : 'hidden'
          } lg:flex flex-1 flex-col h-full relative min-h-0 bg-kf-bg`}
        >
          <OneJobViewerPanel
            activeGeometry={activeGeometry}
            geometryStats={geometryStats}
            currentParts={model.currentParts}
            modelName={modelName}
            selectedPrinter={model.selectedPrinter}
            printers={model.printers}
            onSelectPrinter={handlePrinterChange}
            printerFitResult={printerFitResult}
            scaleFactor={model.scaleFactor}
            highlightOverhangs={highlightOverhangs}
            onToggleOverhangs={handleToggleOverhangs}
            isGeneratingCad={isGeneratingCad || isRevisingCad}
            cadSource={cadSource}
            extractedRequirements={extractedRequirements}
            onScaleCommit={handleScaleFactorChange}
          />
        </div>
      </main>

      {/* 3. MOBILE BOTTOM NAVIGATION (CHAT / 3D VIEW) */}
      <nav
        id="mobile-bottom-navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 h-14 bg-kf-panel/95 backdrop-blur-md border-t border-kf-border z-40 flex items-center justify-around px-2 pb-safe select-none"
      >
        <button
          type="button"
          onClick={() => setMobileTab('create')}
          className={`flex items-center justify-center gap-2 flex-1 py-2 font-mono text-xs transition cursor-pointer ${
            mobileTab === 'create' || mobileTab === 'assistant'
              ? 'text-kf-pink font-bold border-t-2 border-kf-pink'
              : 'text-kf-muted hover:text-kf-text'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Design Chat</span>
        </button>

        <button
          type="button"
          onClick={() => setMobileTab('viewer')}
          className={`flex items-center justify-center gap-2 flex-1 py-2 font-mono text-xs transition cursor-pointer ${
            mobileTab === 'viewer' || mobileTab === 'print'
              ? 'text-kf-pink font-bold border-t-2 border-kf-pink'
              : 'text-kf-muted hover:text-kf-text'
          }`}
        >
          <Box className="w-4 h-4" />
          <span>3D View & STL</span>
        </button>
      </nav>

      {/* 4. CAMERA CAPTURE MODAL */}
      <CameraCaptureModal
        isOpen={isCameraModalOpen}
        onClose={() => setIsCameraModalOpen(false)}
        hasActiveProject={Boolean(project.activeProject)}
        onCaptureAndConvert={async (photo, conversionPrompt) => {
          setIsCameraModalOpen(false);
          const newRefImage: ProjectReferenceImage = {
            id: `ref_img_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
            fileName: photo.fileName,
            filename: photo.fileName,
            dataUrl: photo.dataUrl,
            thumbnailDataUrl: photo.dataUrl,
            mimeType: photo.mimeType as any,
            width: photo.width,
            height: photo.height,
            role: 'front',
            notes: 'Captured via Camera for 3D conversion',
            createdAt: new Date().toISOString(),
          };

          const currentRefs = project.activeProject?.referenceImages || [];
          const updatedRefs = [...currentRefs, newRefImage];

          let targetProj = project.activeProject;
          if (targetProj) {
            targetProj = {
              ...targetProj,
              referenceImages: updatedRefs,
              updatedAt: new Date().toISOString(),
            };
            await project.persistActiveProject(targetProj);
          }

          setNavView('workspace');
          setMobileTab('viewer');

          await handleGenerateJscad(conversionPrompt, {
            mode: project.activeProject?.projectSettings?.generationMode || 'precision',
            targetProject: targetProj || undefined,
          });
        }}
        onAddAsReferenceOnly={async (photo) => {
          const newRefImage: ProjectReferenceImage = {
            id: `ref_img_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
            fileName: photo.fileName,
            filename: photo.fileName,
            dataUrl: photo.dataUrl,
            thumbnailDataUrl: photo.dataUrl,
            mimeType: photo.mimeType as any,
            width: photo.width,
            height: photo.height,
            role: 'front',
            notes: 'Captured via Camera',
            createdAt: new Date().toISOString(),
          };
          if (project.handleUpdateReferenceImages) {
            project.handleUpdateReferenceImages([...(project.referenceImages || []), newRefImage]);
          } else if (project.activeProject) {
            const updated = {
              ...project.activeProject,
              referenceImages: [...(project.activeProject.referenceImages || []), newRefImage],
              updatedAt: new Date().toISOString(),
            };
            await project.persistActiveProject(updated);
          }
        }}
      />
    </div>
  );
}
