import React, { useState, useRef, useEffect, useCallback } from 'react';
import type * as THREE from 'three';
import {
  Send,
  Camera,
  Image as ImageIcon,
  Loader2,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Sparkles,
  RotateCcw,
  X,
  Layers,
  ArrowRight,
  Maximize2,
} from 'lucide-react';
import type {
  ExtractedRequirements,
  GenerationPipelineStage,
  PrinterSpec,
  ModelGeometryStats,
} from '../../types';
import { generateHeightmapGeometry } from '../../engine/heightmap';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: number;
  photoUrl?: string;
  photoMode?: 'relief' | 'reference';
  stage?: 'clarifying' | 'generating' | 'ready' | 'error';
  clarificationQuestions?: Array<{
    id: string;
    question: string;
    category: 'size' | 'fit' | 'mount';
    suggestedOptions: string[];
    selectedAnswer?: string;
  }>;
  dimensionsSummary?: string;
}

export interface ChatPanelProps {
  onSendMessage: (prompt: string, photoDataUrl?: string, photoMode?: 'relief' | 'reference') => Promise<void>;
  onAnswerClarification: (answers: Record<string, string>, useDefaults: boolean) => Promise<void>;
  onResetChat: () => void;
  isGeneratingCad: boolean;
  pipelineStage: GenerationPipelineStage;
  generationStatusText: string;
  cadErrorMessage: string | null;
  activeGeometry: THREE.BufferGeometry | null;
  geometryStats: ModelGeometryStats | null;
  modelName: string;
  extractedRequirements: ExtractedRequirements | null;
  onOpenCamera: () => void;
  capturedPhoto: string | null;
  onClearCapturedPhoto: () => void;
  onApplyGeometry: (geom: THREE.BufferGeometry) => void;
  clarificationQuestionsToAsk?: Array<{
    id: string;
    question: string;
    category: 'size' | 'fit' | 'mount';
    suggestedOptions: string[];
  }> | null;
}

const STARTER_PROMPTS = [
  {
    title: 'Desk Organizer Tray',
    prompt: 'Desk organizer tray with 3 compartments (140×90×25mm) with rounded inner corners',
  },
  {
    title: 'Phone Stand with Cable Slot',
    prompt: 'Desktop phone stand angled back with charging cable pass-through hole',
  },
  {
    title: 'Headphone Wall Bracket',
    prompt: 'Under-desk headphone hanger bracket with 2 M4 screw holes',
  },
  {
    title: 'Electronics Enclosure Box',
    prompt: 'Snap-fit electronics enclosure box (90×60×25mm) with 2.5mm wall thickness',
  },
];

export const ChatPanel: React.FC<ChatPanelProps> = ({
  onSendMessage,
  onAnswerClarification,
  onResetChat,
  isGeneratingCad,
  pipelineStage,
  generationStatusText,
  cadErrorMessage,
  activeGeometry,
  geometryStats,
  modelName,
  extractedRequirements,
  onOpenCamera,
  capturedPhoto,
  onClearCapturedPhoto,
  onApplyGeometry,
  clarificationQuestionsToAsk,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputPrompt, setInputPrompt] = useState('');
  const [attachedPhoto, setAttachedPhoto] = useState<string | null>(null);
  const [photoMode, setPhotoMode] = useState<'relief' | 'reference'>('reference');
  const [clarificationAnswers, setClarificationAnswers] = useState<Record<string, string>>({});
  
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isGeneratingCad, pipelineStage]);

  // Sync captured photo from camera modal
  useEffect(() => {
    if (capturedPhoto) {
      setAttachedPhoto(capturedPhoto);
      onClearCapturedPhoto();
    }
  }, [capturedPhoto, onClearCapturedPhoto]);

  const lastClarifyKeyRef = useRef<string | null>(null);

  // Sync clarification questions when requested
  useEffect(() => {
    if (clarificationQuestionsToAsk && clarificationQuestionsToAsk.length > 0) {
      const key = clarificationQuestionsToAsk.map((q) => q.id).join(':');
      if (lastClarifyKeyRef.current === key) return;
      lastClarifyKeyRef.current = key;

      const asstMsgId = `asst_clarify_${Date.now()}`;
      setClarificationAnswers({});
      setMessages((prev) => [
        ...prev,
        {
          id: asstMsgId,
          sender: 'assistant',
          text: 'Before generating, I have a few quick questions to make sure the model fits your exact needs:',
          timestamp: Date.now(),
          stage: 'clarifying',
          clarificationQuestions: clarificationQuestionsToAsk,
        },
      ]);
    } else {
      lastClarifyKeyRef.current = null;
    }
  }, [clarificationQuestionsToAsk]);

  // Auto-resize textarea
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputPrompt(e.target.value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 160)}px`;
    }
  };

  // Handle file attachment
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setAttachedPhoto(reader.result);
      }
    };
    reader.readAsDataURL(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Submit chat message
  const handleSend = async () => {
    const trimmed = inputPrompt.trim();
    if (!trimmed && !attachedPhoto) return;
    
    const userMsgId = `user_${Date.now()}`;
    const newMsg: ChatMessage = {
      id: userMsgId,
      sender: 'user',
      text: trimmed || (photoMode === 'relief' ? 'Generate 3D photo relief from image' : 'Generate 3D model from reference photo'),
      timestamp: Date.now(),
      photoUrl: attachedPhoto || undefined,
      photoMode,
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputPrompt('');
    const currentPhoto = attachedPhoto;
    const currentPhotoMode = photoMode;
    setAttachedPhoto(null);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    // If photo relief mode chosen, directly generate heightmap geometry in browser
    if (currentPhoto && currentPhotoMode === 'relief') {
      const assistantMsgId = `asst_${Date.now()}`;
      setMessages((prev) => [
        ...prev,
        {
          id: assistantMsgId,
          sender: 'assistant',
          text: 'Generating 3D relief mesh from photo heightmap...',
          timestamp: Date.now(),
          stage: 'generating',
        },
      ]);

      try {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = currentPhoto;
        await new Promise((res, rej) => {
          img.onload = () => res(true);
          img.onerror = rej;
        });

        const canvas = document.createElement('canvas');
        canvas.width = 128;
        canvas.height = 128;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, 128, 128);
          const geom = generateHeightmapGeometry(canvas, {
            widthMm: 100,
            lengthMm: 100,
            baseThicknessMm: 3,
            maxDepthMm: 10,
            resolution: 96,
            invert: false,
          });
          onApplyGeometry(geom);
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantMsgId
                ? {
                    ...m,
                    text: '3D relief plate generated! You can inspect the model in the 3D viewer on the right and click Download STL.',
                    stage: 'ready',
                    dimensionsSummary: '100 × 100 × 13 mm',
                  }
                : m
            )
          );
          return;
        }
      } catch (err: any) {
        console.error('Failed to generate relief mesh:', err);
      }
    }

    // Standard CAD generation workflow
    await onSendMessage(trimmed, currentPhoto || undefined, currentPhotoMode);
  };

  // Add Assistant Clarification Questions Message
  const promptForClarification = useCallback((questions: Array<{
    id: string;
    question: string;
    category: 'size' | 'fit' | 'mount';
    suggestedOptions: string[];
  }>) => {
    const asstMsgId = `asst_clarify_${Date.now()}`;
    setClarificationAnswers({});
    setMessages((prev) => [
      ...prev,
      {
        id: asstMsgId,
        sender: 'assistant',
        text: 'Before generating, I have a few quick questions to make sure the model fits your exact needs:',
        timestamp: Date.now(),
        stage: 'clarifying',
        clarificationQuestions: questions,
      },
    ]);
  }, []);

  // Answer a specific clarification question
  const selectClarificationOption = (qId: string, answer: string) => {
    setClarificationAnswers((prev) => ({ ...prev, [qId]: answer }));
  };

  // Submit clarification answers
  const handleConfirmClarifications = async (useDefaults: boolean = false) => {
    const summaryText = useDefaults
      ? 'Using recommended engineering defaults.'
      : Object.entries(clarificationAnswers)
          .map(([_, ans]) => ans)
          .join(', ');

    setMessages((prev) => [
      ...prev,
      {
        id: `user_ans_${Date.now()}`,
        sender: 'user',
        text: summaryText || 'Proceed with standard dimensions.',
        timestamp: Date.now(),
      },
      {
        id: `asst_gen_${Date.now()}`,
        sender: 'assistant',
        text: 'Generating parameterized 3D model...',
        timestamp: Date.now(),
        stage: 'generating',
      },
    ]);

    await onAnswerClarification(clarificationAnswers, useDefaults);
  };

  const lastAnnouncedGeomRef = useRef<THREE.BufferGeometry | null>(null);
  const lastAnnouncedErrorRef = useRef<string | null>(null);

  // When model generation succeeds
  useEffect(() => {
    if (activeGeometry && pipelineStage === 'ready') {
      if (lastAnnouncedGeomRef.current === activeGeometry) {
        return;
      }
      lastAnnouncedGeomRef.current = activeGeometry;

      const dims = geometryStats?.dimensions;
      const dimSummary = dims
        ? `${dims.x.toFixed(0)} × ${dims.y.toFixed(0)} × ${dims.z.toFixed(0)} mm`
        : undefined;

      setMessages((prev) => {
        const last = prev[prev.length - 1];
        if (last && last.sender === 'assistant' && last.stage === 'ready') {
          return prev; // already marked ready
        }
        return [
          ...prev,
          {
            id: `asst_ready_${Date.now()}`,
            sender: 'assistant',
            text: `Model generated: **${modelName || 'Custom 3D Part'}**! The 3D preview is active on the right. You can download the STL anytime, or tell me below if you would like any revisions (e.g. *"make it 10mm taller"*, *"add 2 screw holes"*).`,
            timestamp: Date.now(),
            stage: 'ready',
            dimensionsSummary: dimSummary,
          },
        ];
      });
    }
  }, [activeGeometry, pipelineStage, modelName]);

  // When error occurs
  useEffect(() => {
    if (pipelineStage === 'error' && cadErrorMessage) {
      if (lastAnnouncedErrorRef.current === cadErrorMessage) {
        return;
      }
      lastAnnouncedErrorRef.current = cadErrorMessage;

      setMessages((prev) => [
        ...prev,
        {
          id: `asst_err_${Date.now()}`,
          sender: 'assistant',
          text: `Generation note: ${cadErrorMessage}. You can try rephrasing with specific dimensions or starter shapes.`,
          timestamp: Date.now(),
          stage: 'error',
        },
      ]);
    }
  }, [pipelineStage, cadErrorMessage]);

  return (
    <div className="flex flex-col h-full bg-kf-panel select-none relative font-sans">
      {/* Chat Header */}
      <div className="h-12 border-b border-kf-border px-4 flex items-center justify-between shrink-0 bg-kf-panel/90 backdrop-blur-sm">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-2 h-2 rounded-full bg-kf-pink animate-pulse" />
          <span className="font-display font-bold text-xs tracking-wider uppercase text-kf-text">
            Design Chat
          </span>
          <span className="text-[10px] font-mono text-kf-muted bg-kf-panel-2 px-1.5 py-0.5 rounded border border-kf-border">
            Prompt → STL
          </span>
        </div>

        <button
          type="button"
          onClick={() => {
            setMessages([]);
            onResetChat();
          }}
          className="flex items-center gap-1 text-[11px] font-mono text-kf-muted hover:text-kf-pink transition cursor-pointer px-2 py-1 rounded hover:bg-kf-panel-2"
          title="Start fresh with a new 3D model prompt"
        >
          <RotateCcw className="w-3 h-3" />
          <span>New Part</span>
        </button>
      </div>

      {/* Chat Messages Feed */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-0">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col justify-center items-center text-center px-4 py-6 space-y-6">
            <div className="w-12 h-12 rounded-2xl bg-kf-pink/10 border border-kf-pink/30 flex items-center justify-center text-kf-pink shadow-lg shadow-kf-pink/5">
              <Sparkles className="w-6 h-6" />
            </div>

            <div className="space-y-1.5 max-w-sm">
              <h2 className="font-display font-bold text-base text-kf-text tracking-wide">
                What would you like to 3D print?
              </h2>
              <p className="text-xs text-kf-muted leading-relaxed">
                Describe any functional part, bracket, organizer tray, or stand. KatPrint generates printable, watertight STLs directly.
              </p>
            </div>

            <div className="w-full max-w-sm space-y-2 text-left">
              <span className="text-[10px] font-mono text-kf-muted uppercase tracking-wider block pl-1">
                Quick Starters:
              </span>
              <div className="grid grid-cols-1 gap-2">
                {STARTER_PROMPTS.map((starter, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setInputPrompt(starter.prompt);
                      if (textareaRef.current) textareaRef.current.focus();
                    }}
                    className="p-2.5 rounded-lg border border-kf-border bg-kf-panel-2/60 hover:border-kf-pink/50 hover:bg-kf-panel-2 text-left transition cursor-pointer group"
                  >
                    <div className="font-medium text-xs text-kf-text group-hover:text-kf-pink transition">
                      {starter.title}
                    </div>
                    <div className="text-[11px] text-kf-muted line-clamp-1 mt-0.5">
                      {starter.prompt}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[90%] rounded-xl px-3.5 py-2.5 text-xs leading-relaxed ${
                    isUser
                      ? 'bg-kf-pink text-[#0A0004] font-medium shadow-md'
                      : 'bg-kf-panel-2 border border-kf-border text-kf-text shadow-sm'
                  }`}
                >
                  {/* Attached photo preview */}
                  {msg.photoUrl && (
                    <div className="mb-2 rounded-lg overflow-hidden border border-black/20 max-w-[200px]">
                      <img
                        src={msg.photoUrl}
                        alt="Uploaded reference"
                        className="w-full h-auto object-cover max-h-40"
                      />
                    </div>
                  )}

                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  {/* Dimensions badge if available */}
                  {msg.dimensionsSummary && (
                    <div className="mt-2 pt-2 border-t border-kf-border/40 flex items-center gap-1.5 font-mono text-[10px] text-kf-muted">
                      <span className="text-kf-pink font-bold">Bounding Size:</span>
                      <span>{msg.dimensionsSummary}</span>
                    </div>
                  )}

                  {/* Clarification Questions Interface (At most 3 short questions) */}
                  {msg.clarificationQuestions && msg.clarificationQuestions.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-kf-border/60 space-y-3">
                      {msg.clarificationQuestions.map((q, qIdx) => {
                        const currentAns = clarificationAnswers[q.id];
                        return (
                          <div key={q.id} className="space-y-1.5 text-left">
                            <div className="font-semibold text-kf-text text-[11px] flex items-start gap-1.5">
                              <span className="text-kf-pink font-mono">{qIdx + 1}.</span>
                              <span>{q.question}</span>
                            </div>
                            <div className="flex flex-wrap gap-1.5 pl-3">
                              {q.suggestedOptions.map((opt) => {
                                const isSelected = currentAns === opt;
                                return (
                                  <button
                                    key={opt}
                                    type="button"
                                    onClick={() => selectClarificationOption(q.id, opt)}
                                    className={`px-2.5 py-1 rounded-full text-[10px] font-mono transition cursor-pointer border ${
                                      isSelected
                                        ? 'bg-kf-pink text-[#0A0004] border-kf-pink font-bold shadow-sm'
                                        : 'bg-kf-panel border-kf-border text-kf-muted hover:text-kf-text hover:border-kf-pink/50'
                                    }`}
                                  >
                                    {opt}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}

                      {/* Action buttons to proceed */}
                      <div className="pt-2 flex flex-col sm:flex-row gap-2">
                        <button
                          type="button"
                          onClick={() => handleConfirmClarifications(false)}
                          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 bg-kf-pink hover:bg-kf-pink-hi text-[#0A0004] font-bold text-xs rounded transition cursor-pointer shadow-sm"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Generate with Choices</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleConfirmClarifications(true)}
                          className="px-3 py-1.5 bg-kf-panel hover:bg-kf-panel-2 border border-kf-border text-kf-muted hover:text-kf-text text-[11px] rounded transition cursor-pointer text-center"
                        >
                          Use Standard Defaults
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                <span className="text-[9px] font-mono text-kf-muted/60 mt-1 px-1">
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            );
          })
        )}

        {/* Live Generation Progress Indicator */}
        {isGeneratingCad && (
          <div className="flex items-center gap-2.5 p-3 rounded-lg border border-kf-pink/30 bg-kf-pink/5 text-xs text-kf-text animate-pulse">
            <Loader2 className="w-4 h-4 text-kf-pink animate-spin shrink-0" />
            <div className="min-w-0 flex-1">
              <span className="font-semibold text-kf-pink font-mono block text-[11px] uppercase tracking-wide">
                Generating 3D Model
              </span>
              <span className="text-kf-muted text-[11px] truncate block">
                {generationStatusText || 'Compiling watertight CSG geometry...'}
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-3 border-t border-kf-border bg-kf-panel shrink-0 space-y-2">
        {/* Attached Photo Preview */}
        {attachedPhoto && (
          <div className="flex items-center justify-between p-2 rounded-lg bg-kf-panel-2 border border-kf-border">
            <div className="flex items-center gap-2 min-w-0">
              <img
                src={attachedPhoto}
                alt="Attached"
                className="w-10 h-10 object-cover rounded border border-kf-border"
              />
              <div className="min-w-0">
                <span className="text-xs font-medium text-kf-text block truncate">
                  Photo Attached
                </span>
                <div className="flex items-center gap-2 mt-0.5">
                  <button
                    type="button"
                    onClick={() => setPhotoMode('reference')}
                    className={`text-[10px] font-mono px-1.5 py-0.5 rounded transition ${
                      photoMode === 'reference'
                        ? 'bg-kf-pink text-[#0A0004] font-bold'
                        : 'text-kf-muted hover:text-kf-text'
                    }`}
                  >
                    CAD Reference
                  </button>
                  <button
                    type="button"
                    onClick={() => setPhotoMode('relief')}
                    className={`text-[10px] font-mono px-1.5 py-0.5 rounded transition ${
                      photoMode === 'relief'
                        ? 'bg-kf-pink text-[#0A0004] font-bold'
                        : 'text-kf-muted hover:text-kf-text'
                    }`}
                  >
                    Photo Relief Plate
                  </button>
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setAttachedPhoto(null)}
              className="text-kf-muted hover:text-kf-pink p-1 transition cursor-pointer"
              title="Remove photo"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Text Input Row */}
        <div className="flex items-end gap-2 bg-kf-panel-2 border border-kf-border rounded-xl p-1.5 focus-within:border-kf-pink transition">
          <textarea
            ref={textareaRef}
            rows={1}
            value={inputPrompt}
            onChange={handleInputChange}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={
              messages.length === 0
                ? 'Describe what you want to 3D print...'
                : 'Ask for changes (e.g. "make it 10mm taller", "add screw holes")...'
            }
            disabled={isGeneratingCad}
            className="flex-1 bg-transparent text-xs text-kf-text placeholder-kf-muted/60 p-1.5 resize-none focus:outline-none max-h-36 leading-relaxed"
          />

          {/* Photo & Camera Attachments */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isGeneratingCad}
            className="p-1.5 text-kf-muted hover:text-kf-pink transition cursor-pointer rounded hover:bg-kf-panel"
            title="Attach reference photo or sketch"
          >
            <ImageIcon className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onOpenCamera}
            disabled={isGeneratingCad}
            className="p-1.5 text-kf-muted hover:text-kf-pink transition cursor-pointer rounded hover:bg-kf-panel"
            title="Take photo with camera"
          >
            <Camera className="w-4 h-4" />
          </button>

          {/* Send Button */}
          <button
            type="button"
            onClick={handleSend}
            disabled={(!inputPrompt.trim() && !attachedPhoto) || isGeneratingCad}
            className="p-2 bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-40 text-[#0A0004] rounded-lg transition cursor-pointer font-bold shrink-0 shadow-sm"
            title="Send prompt"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
