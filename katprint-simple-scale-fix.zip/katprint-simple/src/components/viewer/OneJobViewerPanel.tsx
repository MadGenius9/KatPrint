import React, { Suspense, lazy, useState } from 'react';
import type * as THREE from 'three';
import {
  Download,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Maximize2,
  Box,
  ChevronDown,
  Printer,
  Sparkles,
} from 'lucide-react';
const Viewer3D = lazy(() => import('../Viewer3D').then((m) => ({ default: m.Viewer3D })));
import { downloadExportSTL } from '../../engine/stlExporter';
import type {
  PrinterSpec,
  PrinterFitResult,
  ModelGeometryStats,
  ExecutedModelPart,
  ExtractedRequirements,
} from '../../types';

export interface OneJobViewerPanelProps {
  activeGeometry: THREE.BufferGeometry | null;
  geometryStats: ModelGeometryStats | null;
  currentParts: ExecutedModelPart[];
  modelName: string;
  selectedPrinter: PrinterSpec;
  printers: PrinterSpec[];
  onSelectPrinter: (printerId: string) => void;
  printerFitResult: PrinterFitResult;
  scaleFactor: number;
  highlightOverhangs: boolean;
  onToggleOverhangs: () => void;
  isGeneratingCad: boolean;
  cadSource?: string | null;
  extractedRequirements: ExtractedRequirements | null;
  onScaleCommit?: (nextScaleFactor: number) => void;
}

export const OneJobViewerPanel: React.FC<OneJobViewerPanelProps> = ({
  activeGeometry,
  geometryStats,
  currentParts,
  modelName,
  selectedPrinter,
  printers,
  onSelectPrinter,
  printerFitResult,
  scaleFactor,
  highlightOverhangs,
  onToggleOverhangs,
  isGeneratingCad,
  cadSource,
  extractedRequirements,
  onScaleCommit,
}) => {
  const [stlExportProgress, setStlExportProgress] = useState<number | null>(null);
  const [isPrinterDropdownOpen, setIsPrinterDropdownOpen] = useState(false);

  const hasGeometry = Boolean(activeGeometry || (currentParts && currentParts.length > 0));
  const dims = geometryStats?.dimensions;
  const isFits = printerFitResult?.fits ?? true;

  const handleDownloadSTL = async () => {
    if (!hasGeometry || stlExportProgress !== null) return;
    const cleanName = (modelName || 'model')
      .replace(/^TEMPLATE-/i, '')
      .toLowerCase()
      .replace(/[^a-z0-9_]/g, '_')
      .slice(0, 32);
    const heightMm = ((dims?.z || 10) * scaleFactor).toFixed(0);
    const filename = `katprint_${cleanName}_${heightMm}mm_${selectedPrinter.id}`;

    setStlExportProgress(0);
    try {
      await downloadExportSTL(
        activeGeometry,
        currentParts,
        filename,
        scaleFactor,
        10,
        (percent) => setStlExportProgress(percent)
      );
    } catch (err) {
      console.error('Failed to download STL:', err);
    } finally {
      setTimeout(() => setStlExportProgress(null), 800);
    }
  };

  return (
    <div className="flex flex-col h-full w-full relative bg-kf-bg select-none font-sans">
      {/* Top Toolbar: Printability Bar & STL Download */}
      <div className="h-14 border-b border-kf-border px-3 sm:px-4 bg-kf-panel/90 backdrop-blur-md flex items-center justify-between gap-2 shrink-0 z-30">
        {/* Left: Bed-Fit Check & Dimensions */}
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          {/* Printer Selector Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsPrinterDropdownOpen((v) => !v)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-kf-border bg-kf-panel-2 hover:border-kf-pink/50 text-kf-text font-mono text-[11px] transition cursor-pointer"
              title="Select 3D Printer for build plate verification"
            >
              <Printer className="w-3.5 h-3.5 text-kf-pink shrink-0" />
              <span className="truncate max-w-[110px] sm:max-w-[160px] font-medium">
                {selectedPrinter.name}
              </span>
              <ChevronDown className="w-3 h-3 text-kf-muted" />
            </button>

            {isPrinterDropdownOpen && (
              <div className="absolute left-0 top-9 w-60 bg-kf-panel border border-kf-border rounded-lg shadow-2xl p-1 z-50 space-y-0.5">
                <span className="text-[10px] font-mono text-kf-muted uppercase tracking-wider px-2 py-1 block">
                  Verify Bed Dimensions:
                </span>
                {printers.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      onSelectPrinter(p.id);
                      setIsPrinterDropdownOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-left text-xs font-mono transition ${
                      p.id === selectedPrinter.id
                        ? 'bg-kf-pink text-[#0A0004] font-bold'
                        : 'text-kf-text hover:bg-kf-panel-2'
                    }`}
                  >
                    <span className="truncate">{p.name}</span>
                    <span className="text-[10px] opacity-70 shrink-0">
                      {p.buildVolume?.x ?? 220}×{p.buildVolume?.y ?? 220}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Bed Fit Badge */}
          {hasGeometry && (
            <div
              className={`hidden md:flex items-center gap-1.5 px-2 py-1 rounded text-[11px] font-mono border ${
                isFits
                  ? 'bg-kf-ok/10 border-kf-ok/40 text-kf-ok'
                  : 'bg-kf-warn/10 border-kf-warn/40 text-kf-warn'
              }`}
              title={
                isFits
                  ? `Fits ${selectedPrinter.name} build plate (${selectedPrinter.buildVolume?.x ?? 220}×${selectedPrinter.buildVolume?.y ?? 220}×${selectedPrinter.buildVolume?.z ?? 250}mm)`
                  : `Model exceeds ${selectedPrinter.name} build plate!`
              }
            >
              {isFits ? (
                <CheckCircle2 className="w-3.5 h-3.5" />
              ) : (
                <AlertTriangle className="w-3.5 h-3.5" />
              )}
              <span>{isFits ? 'Fits Build Plate' : 'Exceeds Bed'}</span>
            </div>
          )}

          {/* Bounding Size */}
          {hasGeometry && dims && (
            <div className="hidden lg:flex items-center gap-1 font-mono text-[11px] text-kf-muted">
              <span>{dims.x.toFixed(0)}×{dims.y.toFixed(0)}×{dims.z.toFixed(0)} mm</span>
            </div>
          )}
        </div>

        {/* Right: Printability Status & Primary STL Download Button */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Watertight / Manifold status */}
          {hasGeometry && (
            <div
              className="hidden sm:flex items-center gap-1 px-2 py-1 rounded border border-kf-border bg-kf-panel-2 text-[10px] font-mono text-kf-ok"
              title="Geometry is watertight & manifold for 3D slicing"
            >
              <CheckCircle2 className="w-3 h-3 text-kf-ok" />
              <span>Watertight</span>
            </div>
          )}

          {/* Overhang toggle */}
          {hasGeometry && (
            <button
              type="button"
              onClick={onToggleOverhangs}
              className={`hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded border text-[10px] font-mono transition cursor-pointer ${
                highlightOverhangs
                  ? 'bg-kf-warn/20 border-kf-warn text-kf-warn font-bold'
                  : 'border-kf-border bg-kf-panel-2 text-kf-muted hover:text-kf-text'
              }`}
              title="Highlight steep overhangs (>45°) in red"
            >
              <AlertTriangle className="w-3 h-3" />
              <span>Overhangs</span>
            </button>
          )}

          {/* Primary Download STL Button */}
          <button
            type="button"
            id="btn-download-stl"
            disabled={!hasGeometry || isGeneratingCad || stlExportProgress !== null}
            onClick={handleDownloadSTL}
            className="flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-lg bg-kf-pink hover:bg-kf-pink-hi disabled:opacity-40 text-[#0A0004] font-mono text-xs font-bold uppercase tracking-wider transition cursor-pointer shadow-md shadow-kf-pink/20 active:scale-95 shrink-0"
            title={hasGeometry ? 'Download printable binary STL' : 'Generate a model to download STL'}
          >
            {stlExportProgress !== null ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{stlExportProgress}%</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Download STL</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 3D WebGL Canvas Viewport */}
      <div className="flex-1 w-full h-full relative min-h-0">
        <Suspense
          fallback={
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-kf-bg text-kf-muted font-mono text-xs gap-2">
              <Loader2 className="w-6 h-6 animate-spin text-kf-pink" />
              <span>Initializing 3D viewer…</span>
            </div>
          }
        >
          <Viewer3D
            geometry={activeGeometry}
            printer={selectedPrinter}
            scaleFactor={scaleFactor}
            highlightOverhangs={highlightOverhangs}
            onToggleOverhangs={onToggleOverhangs}
            isGenerating={isGeneratingCad}
            referenceObject={extractedRequirements?.referenceObject}
            parts={currentParts}
            isMultiPart={currentParts && currentParts.length > 1}
            onScaleCommit={onScaleCommit}
          />
        </Suspense>

        {/* Empty State Overlay when no geometry has been created yet */}
        {!hasGeometry && !isGeneratingCad && (
          <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center text-center p-6 bg-kf-bg/40">
            <div className="w-16 h-16 rounded-3xl bg-kf-panel border border-kf-border flex items-center justify-center text-kf-muted/60 mb-3 shadow-inner">
              <Box className="w-8 h-8" />
            </div>
            <h3 className="font-display font-bold text-sm text-kf-text mb-1">
              3D Print Preview Area
            </h3>
            <p className="text-xs text-kf-muted max-w-xs leading-relaxed">
              Enter a prompt in the chat on the left to generate your printable model.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
