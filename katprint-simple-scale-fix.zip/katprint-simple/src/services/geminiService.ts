import {
  ModelGeometryStats,
  PrinterSpec,
  FilamentSpec,
  SlicerSettings,
  ExtractedRequirements,
  DesignConcept,
  DesignValidationReport,
  DesignSpecification,
  DesignCheck,
  FidelityReviewResult,
  GenerationMode,
  AIRequestRecord,
  ProjectReferenceImage,
  PrintabilityReport,
  ProjectDesignState,
  SemanticFeaturePlan,
  RequirementCoverageReport,
  DesignIntentAudit,
  RevisionIntent,
  ReferenceImageObservation,
  DesignIntentStateDelta,
} from '../types';
import {
  SemanticFeatureModel,
  SemanticRevisionOperation,
  FeatureBindingValidation,
} from '../features/featureTypes';
import {
  ProjectMemory,
  DesignChange,
} from '../projects/projectTypes';

export interface GenerateJscadResponse {
  code: string;
  source: 'ai' | 'template';
  generationId?: string;
  diagnostics?: any;
  requirements?: ExtractedRequirements;
  validationReport?: DesignValidationReport;
  explanation?: string;
}

export interface AiStageDiagnostics {
  modelUsed?: string;
  modelsUsed?: string[];
  aiCallsMade?: number;
  requestRecords?: AIRequestRecord[];
  durationMs?: number;
}

export interface ExtractRequirementsResponse {
  requirements: ExtractedRequirements;
  diagnostics?: AiStageDiagnostics;
}

export interface GenerateConceptsResponse {
  concepts: DesignConcept[];
  diagnostics?: AiStageDiagnostics;
}

export interface FidelityReviewResponse {
  review: FidelityReviewResult;
  diagnostics?: AiStageDiagnostics;
}

export function mapApiErrorMessage(err: any, status?: number): string {
  const str = String(err?.message || err || '');
  const s = status || (typeof err?.status === 'number' ? err.status : undefined) || (typeof err?.statusCode === 'number' ? err.statusCode : undefined);
  const cat = err?.errorCategory || '';

  // 1. Timeout errors handled FIRST (including 504 / DEADLINE_EXCEEDED)
  if (
    err?.isTimeout ||
    cat === 'REQUEST_TIMEOUT' ||
    cat === 'TIMEOUT_ERROR' ||
    s === 408 ||
    s === 504 ||
    str.includes('timed out') ||
    str.includes('timeout') ||
    str.includes('504') ||
    str.includes('DEADLINE_EXCEEDED') ||
    str.includes('Deadline expired') ||
    str.includes('AbortError')
  ) {
    return 'Generation took longer than 3 minutes across all models. Try again — if it keeps happening, split the part into simpler pieces.';
  }

  // 2. 429 / Rate Limit / Quota
  if (
    s === 429 ||
    cat === 'QUOTA_EXCEEDED' ||
    cat === 'RATE_LIMIT' ||
    str.includes('429') ||
    str.includes('RESOURCE_EXHAUSTED') ||
    str.includes('quota') ||
    str.includes('Quota exceeded') ||
    str.includes('rate limit')
  ) {
    return 'Rate limit reached. Please wait a moment before generating again, or switch to Template Mode.';
  }

  // 3. 503 / UNAVAILABLE / Overloaded
  if (
    s === 503 ||
    cat === 'SERVICE_UNAVAILABLE' ||
    cat === 'GEMINI_UNAVAILABLE' ||
    str.includes('503') ||
    str.includes('UNAVAILABLE') ||
    str.includes('high demand') ||
    str.includes('overloaded')
  ) {
    return 'Gemini AI is experiencing high demand. Please try again in a few moments, or switch to Template Mode.';
  }

  // 4. Authentication / Missing API Key
  if (
    cat === 'AUTH_ERROR' ||
    s === 401 ||
    s === 403 ||
    str.includes('GEMINI_API_KEY is not configured') ||
    str.includes('Invalid or missing Gemini API credential') ||
    str.includes('UNAUTHENTICATED')
  ) {
    return 'Gemini API key is not configured. Configure GEMINI_API_KEY or GOOGLE_API_KEY in Settings > Secrets to enable conversational AI generation, or continue using Template Mode & local JSCAD.';
  }

  // 5. Preserved high-level user-facing messages
  if (
    str.includes('Organic 3D Engine not configured') ||
    str.includes('Organic mesh generation provider not configured') ||
    str.includes('Hybrid organic/mechanical generation provider not configured') ||
    str.includes('Photo-to-Mesh provider not configured') ||
    str.includes('AI model generation is unavailable')
  ) {
    return str;
  }

  // 5. HTML / JSON parsing / unexpected token errors (e.g. if server returned 502/504 HTML)
  if (
    str.includes('Unexpected token') ||
    str.includes('is not valid JSON') ||
    str.includes('<!doctype') ||
    str.includes('SyntaxError')
  ) {
    if (s && s >= 500) {
      return 'AI generation service is temporarily busy. Please try again in a few moments.';
    }
    return 'The server took too long to respond. Please try again or switch to Template Mode.';
  }

  // 6. Network connection error
  if (
    err?.isNetwork ||
    str.includes('Failed to fetch') ||
    str.includes('NetworkError') ||
    str.includes('ECONNREFUSED') ||
    str.includes('network')
  ) {
    return 'Unable to reach the CAD server. Please check your connection and retry.';
  }

  // 7. 4xx / Request Rejected
  if (
    (s && s >= 400 && s < 500) ||
    str.includes('400') ||
    str.includes('422') ||
    str.includes('INVALID_ARGUMENT')
  ) {
    return str || 'Request could not be processed. Try rephrasing your description.';
  }

  return str || 'An unexpected error occurred. Please try again.';
}

export function createApiError(data: any, status: number): Error & Record<string, any> {
  const message = data?.error || `Server responded with status ${status}`;
  const err: any = new Error(message);
  err.status = status;
  err.statusCode = status;
  err.errorCategory = data?.errorCategory || 'UNKNOWN_ERROR';
  err.technicalDetails = data?.technicalDetails;
  err.diagnostics = data?.diagnostics;
  err.raw = data;
  if (data?.canSimplifyToParametric !== undefined) {
    err.canSimplifyToParametric = data.canSimplifyToParametric;
  }
  if (data?.requirements) {
    err.requirements = data.requirements;
  }
  return err;
}

export interface GenerationStatus {
  model: string;
  attempt: number;
  thinkingLevel: string;
  elapsedMs: number;
  phase: string;
  lastTimeoutModel?: string;
}

export function formatGenerationStatus(status: {
  model?: string;
  attempt?: number;
  thinkingLevel?: string;
  elapsedMs?: number;
  phase?: string;
  lastTimeoutModel?: string;
}): string {
  const elapsedSec = Math.max(1, Math.round((status.elapsedMs || 0) / 1000));
  const modelShort = (m: string) => m.replace('gemini-', '').replace('-flash', '');

  if (status.lastTimeoutModel || (status.phase === 'retrying' && status.attempt && status.attempt > 1)) {
    const fromModel = status.lastTimeoutModel ? modelShort(status.lastTimeoutModel) : '3.8';
    const toModel = status.model ? modelShort(status.model) : '3.7';
    return `${fromModel} timed out, retrying on ${toModel} — ${elapsedSec}s`;
  }

  const modelName = status.model || 'gemini-3.8-flash';
  const thinking = status.thinkingLevel ? `${status.thinkingLevel.toLowerCase()} thinking` : 'medium thinking';
  return `Designing with ${modelName} (${thinking}) — ${elapsedSec}s`;
}

export async function fetchGenerationStatus(requestId: string): Promise<GenerationStatus | null> {
  try {
    const res = await fetch(`/api/generation-status/${encodeURIComponent(requestId)}`);
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

async function fetchWithTimeout(
  url: string,
  options: RequestInit = {},
  timeoutMs?: number
): Promise<Response> {
  const defaultTimeout =
    url.startsWith('/api/generate-jscad') || url.startsWith('/api/revise-jscad')
      ? 210000
      : 95000;
  const effectiveTimeout = timeoutMs ?? defaultTimeout;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), effectiveTimeout);

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    return response;
  } catch (err: any) {
    if (err.name === 'AbortError') {
      const timeoutError: any = new Error(`Request to ${url} timed out after ${Math.round(effectiveTimeout / 1000)}s.`);
      timeoutError.isTimeout = true;
      timeoutError.isNetwork = false;
      timeoutError.errorCategory = 'REQUEST_TIMEOUT';
      throw timeoutError;
    }
    throw err;
  } finally {
    clearTimeout(timeoutId);
  }
}

export async function extractPromptRequirements(
  prompt: string,
  referenceImages: ProjectReferenceImage[] = []
): Promise<ExtractRequirementsResponse> {
  const res = await fetchWithTimeout('/api/extract-requirements', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt, referenceImages }),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    requirements: data.requirements,
    diagnostics: data.diagnostics,
  };
}

export interface GenerateJscadOptions {
  requirements?: ExtractedRequirements;
  useTemplate?: boolean;
  simplifyToParametric?: boolean;
  mode?: GenerationMode;
  featureModel?: SemanticFeatureModel;
  designSpecification?: DesignSpecification;
  designChecklist?: DesignCheck[];
  referenceImages?: ProjectReferenceImage[];
  userOverrides?: string[];
  requestId?: string;
  examples?: Array<{ id?: string; title: string; code: string; source?: string }>;
  onProgress?: (loadingText: string, status?: GenerationStatus) => void;
}

export async function requestJscadGeneration(
  prompt: string,
  options?: GenerateJscadOptions
): Promise<GenerateJscadResponse> {
  const requestId =
    options?.requestId ||
    `req_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

  let pollInterval: any = null;
  if (options?.onProgress) {
    const onProgress = options.onProgress;
    onProgress(`Designing with gemini-3.8-flash (medium thinking) — 1s`);

    pollInterval = setInterval(async () => {
      const status = await fetchGenerationStatus(requestId);
      if (status) {
        onProgress(formatGenerationStatus(status), status);
      }
    }, 2000);
  }

  let res: Response;
  try {
    res = await fetchWithTimeout('/api/generate-jscad', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt,
        requestId,
        requirements: options?.requirements,
        useTemplate: options?.useTemplate,
        simplifyToParametric: options?.simplifyToParametric,
        mode: options?.mode || 'precision',
        featureModel: options?.featureModel,
        designSpecification: options?.designSpecification,
        designChecklist: options?.designChecklist,
        referenceImages: options?.referenceImages,
        userOverrides: options?.userOverrides || options?.requirements?.userOverrides,
        examples: options?.examples,
      }),
    });
  } catch (netErr: any) {
    console.error('Fetch network error during CAD generation:', netErr);
    const err: any = new Error(netErr.message || "Couldn't reach the server. Check your connection.");
    err.isNetwork = true;
    err.errorCategory = netErr.errorCategory || 'NETWORK_ERROR';
    throw err;
  } finally {
    if (pollInterval) {
      clearInterval(pollInterval);
    }
  }

  const rawText = await res.text();
  let data: any = {};
  try {
    data = JSON.parse(rawText);
  } catch (parseErr) {
    console.error('Non-JSON response received from /api/generate-jscad:', res.status, rawText.slice(0, 100));
    const err: any = new Error(res.ok ? "Couldn't reach the server. Check your connection." : `Server returned ${res.status}`);
    err.status = res.status;
    err.errorCategory = 'NETWORK_ERROR';
    throw err;
  }

  if (!res.ok) {
    console.error('Raw API Error from /api/generate-jscad:', res.status, data);
    throw createApiError(data, res.status);
  }

  if (!data.code) {
    throw new Error('No JSCAD code returned from server');
  }

  return {
    code: data.code,
    source: data.source || 'ai',
    generationId: data.generationId,
    diagnostics: data.diagnostics,
    requirements: data.requirements,
    validationReport: data.validationReport,
  };
}

export async function requestFidelityReview(payload: {
  specification: DesignSpecification;
  code: string;
  geometryStats: any;
  deterministicChecks: DesignCheck[];
  views: {
    isometric?: string;
    front?: string;
    rear?: string;
    top?: string;
    left?: string;
    right?: string;
  };
  purpose?: 'visual_fidelity_review' | 'final_visual_review';
}): Promise<FidelityReviewResponse> {
  const res = await fetchWithTimeout('/api/review-fidelity', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  const review: FidelityReviewResult = data.review;
  return {
    review,
    diagnostics: data.diagnostics,
  };
}

export async function requestTargetedRepair(payload: {
  originalPrompt: string;
  currentCode: string;
  specification: DesignSpecification;
  reviewResult: FidelityReviewResult;
  deterministicChecks: DesignCheck[];
  geometryStats: any;
  featureModel?: SemanticFeatureModel;
  bindingValidation?: FeatureBindingValidation;
  lockedParameterIds?: string[];
  repairStrategy?: 'targeted' | 'simplify';
}): Promise<GenerateJscadResponse> {
  const res = await fetchWithTimeout('/api/targeted-repair', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    code: data.code,
    source: 'ai',
    generationId: data.generationId,
    diagnostics: data.diagnostics,
    requirements: data.requirements,
    validationReport: data.validationReport,
  };
}

export interface RevisionContextPayload {
  requestedChanges?: DesignChange[];
  preservedFeatures?: string[];
  designSpecification?: DesignSpecification | null;
  projectMemory?: ProjectMemory | Record<string, any>;
  recentConversation?: Array<{ role: string; content: string; timestamp?: string }>;
  featureModel?: SemanticFeatureModel;
  targetFeatureModel?: SemanticFeatureModel;
  semanticOperation?: SemanticRevisionOperation;
  bindingValidation?: FeatureBindingValidation;
  lockedParameterIds?: string[];
  selectedFeatureIds?: string[];
  selectedFeatureParameters?: string[];
}

export async function requestJscadRevision(payload: {
  originalPrompt: string;
  currentCode: string;
  revisionPrompt: string;
  userInstruction?: string;
  previousRequirements?: ExtractedRequirements;
  revisionContext?: RevisionContextPayload;
  referenceImages?: ProjectReferenceImage[];
  requestId?: string;
  onProgress?: (loadingText: string, status?: GenerationStatus) => void;
}): Promise<GenerateJscadResponse> {
  const requestId =
    payload.requestId ||
    `req_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

  let pollInterval: any = null;
  if (payload.onProgress) {
    const onProgress = payload.onProgress;
    onProgress(`Designing with gemini-3.8-flash (medium thinking) — 1s`);

    pollInterval = setInterval(async () => {
      const status = await fetchGenerationStatus(requestId);
      if (status) {
        onProgress(formatGenerationStatus(status), status);
      }
    }, 2000);
  }

  try {
    const res = await fetchWithTimeout('/api/revise-jscad', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...payload, requestId }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw createApiError(data, res.status);
    }

    return {
      code: data.code,
      source: data.source || 'ai',
      generationId: data.generationId,
      diagnostics: data.diagnostics,
      requirements: data.requirements,
      validationReport: data.validationReport,
    };
  } finally {
    if (pollInterval) {
      clearInterval(pollInterval);
    }
  }
}

export async function requestSlicerExplanation(payload: {
  settings: SlicerSettings;
  geometry: ModelGeometryStats;
  printer: PrinterSpec;
  filament: FilamentSpec;
  mustHoldLiquid: boolean;
  printabilityReport?: PrintabilityReport | null;
}): Promise<string> {
  let res: Response;
  try {
    res = await fetchWithTimeout('/api/explain-slicer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }, 95000);
  } catch (netErr: any) {
    console.error('Fetch network error during slicer explanation:', netErr);
    throw new Error("Couldn't reach the server. Check your connection.");
  }

  const rawText = await res.text();
  let data: any = {};
  try {
    data = JSON.parse(rawText);
  } catch (parseErr) {
    console.error('Non-JSON response received from /api/explain-slicer:', res.status, rawText.slice(0, 100));
    throw new Error(res.ok ? "Couldn't reach the server. Check your connection." : `Server responded with ${res.status}`);
  }

  if (!res.ok) {
    console.error('Raw API Error from /api/explain-slicer:', res.status, data);
    throw new Error(data.error || `Server responded with ${res.status}`);
  }

  return data.explanation;
}

export async function requestConceptVariants(payload: {
  prompt: string;
  requirements: ExtractedRequirements;
  referenceImages?: ProjectReferenceImage[];
}): Promise<GenerateConceptsResponse> {
  const res = await fetchWithTimeout('/api/generate-concepts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    concepts: data.concepts || [],
    diagnostics: data.diagnostics,
  };
}

export async function requestPlanSemanticFeatures(payload: {
  prompt: string;
  spec?: DesignSpecification;
  checklist?: DesignCheck[];
  referenceImages?: ProjectReferenceImage[];
  referenceImageObservations?: ReferenceImageObservation[];
  projectDesignState?: ProjectDesignState;
  projectMemory?: ProjectMemory;
  printer?: PrinterSpec | null;
  mode?: GenerationMode;
}): Promise<{
  plan: SemanticFeaturePlan;
  featureModel: SemanticFeatureModel;
  score: number;
  scoreBreakdown: Record<string, number | null>;
  usedFallback?: boolean;
  fallbackReason?: string;
  plansRequested?: 1 | 3;
  plansReceived?: number;
  initialPlansReceived?: number;
  retryPlansReceived?: number;
  validPlansEvaluated?: number;
  distinctPlansEvaluated?: number;
  degradedMultiPlan?: boolean;
  degradedReason?: string;
  plansEvaluated?: number;
  diagnostics?: AiStageDiagnostics;
}> {
  const res = await fetchWithTimeout('/api/plan-semantic-features', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    plan: data.plan,
    featureModel: data.featureModel,
    score: data.score,
    scoreBreakdown: data.scoreBreakdown || {},
    usedFallback: data.usedFallback,
    fallbackReason: data.fallbackReason,
    plansRequested: data.plansRequested,
    plansReceived: data.plansReceived,
    initialPlansReceived: data.initialPlansReceived,
    retryPlansReceived: data.retryPlansReceived,
    validPlansEvaluated: data.validPlansEvaluated,
    distinctPlansEvaluated: data.distinctPlansEvaluated,
    degradedMultiPlan: data.degradedMultiPlan,
    degradedReason: data.degradedReason,
    plansEvaluated: data.plansEvaluated,
    diagnostics: data.diagnostics,
  };
}

export async function requestInterpretRevision(payload: {
  instruction: string;
  currentCode: string;
  currentFeatureModel: SemanticFeatureModel;
  currentDesignState?: ProjectDesignState;
  recentConversation?: Array<{ role: string; content: string; timestamp?: string }>;
}): Promise<{
  revisionIntent: RevisionIntent;
  diagnostics?: AiStageDiagnostics;
}> {
  const res = await fetchWithTimeout('/api/interpret-revision', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    revisionIntent: data.revisionIntent,
    diagnostics: data.diagnostics,
  };
}

export async function requestRepairSemanticPlan(payload: {
  prompt: string;
  currentPlan: SemanticFeaturePlan;
  unresolvedCriticalRequirements: string[];
  spec?: DesignSpecification;
  projectDesignState?: ProjectDesignState;
  referenceImageObservations?: ReferenceImageObservation[];
  projectMemory?: ProjectMemory;
  printer?: PrinterSpec;
}): Promise<{
  repairedPlan: SemanticFeaturePlan;
  modificationsMade: string[];
  resolvedCriticalRequirements: string[];
  unresolvableCriticalRequirements: string[];
  clarificationNeeded?: string;
  diagnostics?: AiStageDiagnostics;
}> {
  const res = await fetchWithTimeout('/api/repair-semantic-plan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    repairedPlan: data.repairedPlan,
    modificationsMade: data.modificationsMade || [],
    resolvedCriticalRequirements: data.resolvedCriticalRequirements || [],
    unresolvableCriticalRequirements: data.unresolvableCriticalRequirements || [],
    clarificationNeeded: data.clarificationNeeded,
    diagnostics: data.diagnostics,
  };
}

export async function requestAuditDesignIntent(payload: {
  prompt: string;
  code: string;
  measurements: any;
  spec?: DesignSpecification;
  featureModel?: SemanticFeatureModel;
  designState?: ProjectDesignState;
  referenceImages?: ProjectReferenceImage[];
  semanticFeaturePlan?: SemanticFeaturePlan;
  referenceImageObservations?: ReferenceImageObservation[];
}): Promise<{
  audit: DesignIntentAudit;
  coverageReport: RequirementCoverageReport;
  diagnostics?: AiStageDiagnostics;
}> {
  const res = await fetchWithTimeout('/api/audit-design-intent', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    audit: data.audit,
    coverageReport: data.coverageReport,
    diagnostics: data.diagnostics,
  };
}

export async function requestAnalyzeReferenceImages(payload: {
  referenceImages: ProjectReferenceImage[];
  prompt?: string;
}): Promise<{
  observations: ReferenceImageObservation[];
  diagnostics?: AiStageDiagnostics;
}> {
  const res = await fetchWithTimeout('/api/analyze-reference-images', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    observations: data.observations || [],
    diagnostics: data.diagnostics,
  };
}

export async function requestUpdateDesignIntent(payload: {
  currentDesignState: ProjectDesignState;
  userMessage: string;
  currentFeatureModel?: SemanticFeatureModel;
  currentDesignSpecification?: DesignSpecification;
  selectedFeatureIds?: string[];
  recentConversation?: Array<{ role: string; content: string; timestamp?: string }>;
}): Promise<{
  delta: DesignIntentStateDelta;
  diagnostics?: AiStageDiagnostics;
}> {
  const res = await fetchWithTimeout('/api/update-design-intent', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }, 95000);

  const data = await res.json();
  if (!res.ok) {
    throw createApiError(data, res.status);
  }

  return {
    delta: data.delta,
    diagnostics: data.diagnostics,
  };
}

