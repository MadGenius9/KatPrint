import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import { Request, Response } from 'express';

// Lazy/Safe Gemini Client
export function getGeminiClient(): GoogleGenAI | null {
  const rawKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
  const key = rawKey?.trim();
  if (!key || key === '' || key === 'MY_GEMINI_API_KEY') {
    console.warn('GEMINI_API_KEY or GOOGLE_API_KEY is not configured or is placeholder.');
    return null;
  }
  return new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      timeout: 150000,
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// ---------------------------------------------------------------------------
// Unified Gemini Request Budget & Resilience
// ---------------------------------------------------------------------------
export const PRIMARY_MODEL = 'gemini-3.8-flash';
export const FALLBACK_MODELS = ['gemini-3.1-flash-lite'];
export const BACKOFF_DELAYS_MS = [1500, 3000, 6000];
export const MAX_ATTEMPTS_PER_MODEL = 2;

export interface AIRequestRecord {
  id?: string;
  purpose: string;
  model: string;
  attemptNumber?: number;
  durationMs: number;
  timestamp: number;
  status: 'success' | 'failure';
  statusCode?: number;
  errorCategory?: string;
}

export function getLastSuccessfulModel(records: AIRequestRecord[]): string | undefined {
  const successful = (records || []).filter((r) => r.status === 'success');
  return successful.length > 0 ? successful[successful.length - 1].model : undefined;
}

export function dropThinkingLevel(level: ThinkingLevel): ThinkingLevel {
  if (level === ThinkingLevel.HIGH) return ThinkingLevel.MEDIUM;
  if (level === ThinkingLevel.MEDIUM) return ThinkingLevel.LOW;
  return ThinkingLevel.LOW;
}

export interface GenerationStatusEntry {
  model: string;
  attempt: number;
  thinkingLevel: string;
  phase: string;
  startTime: number;
  updatedAt: number;
  lastTimeoutModel?: string;
}

export const generationStatusMap = new Map<string, GenerationStatusEntry>();

export function updateGenerationStatus(
  requestId: string | undefined,
  update: Partial<GenerationStatusEntry>
) {
  if (!requestId) return;
  const now = Date.now();
  const existing = generationStatusMap.get(requestId);
  const entry: GenerationStatusEntry = {
    model: update.model ?? existing?.model ?? PRIMARY_MODEL,
    attempt: update.attempt ?? existing?.attempt ?? 1,
    thinkingLevel: update.thinkingLevel ?? existing?.thinkingLevel ?? 'medium',
    phase: update.phase ?? existing?.phase ?? 'designing',
    startTime: update.startTime ?? existing?.startTime ?? now,
    updatedAt: now,
    lastTimeoutModel: update.lastTimeoutModel ?? existing?.lastTimeoutModel,
  };
  generationStatusMap.set(requestId, entry);
}

// Clean up entries older than 10 minutes (600,000 ms)
export function pruneGenerationStatusMap() {
  const now = Date.now();
  for (const [id, entry] of generationStatusMap.entries()) {
    if (now - entry.updatedAt > 10 * 60 * 1000) {
      generationStatusMap.delete(id);
    }
  }
}
setInterval(pruneGenerationStatusMap, 60 * 1000).unref();

export function handleGenerationStatus(req: Request, res: Response) {
  const { requestId } = req.params;
  const entry = generationStatusMap.get(requestId);
  if (!entry) {
    return res.status(404).json({ error: 'Status not found' });
  }
  const now = Date.now();
  const elapsedMs = now - entry.startTime;
  res.json({
    model: entry.model,
    attempt: entry.attempt,
    thinkingLevel: entry.thinkingLevel,
    elapsedMs,
    phase: entry.phase,
    lastTimeoutModel: entry.lastTimeoutModel,
  });
}

export interface GeminiCallParams {
  purpose:
    | 'design_reasoning'
    | 'design_brief'
    | 'design_spec'
    | 'spec_review'
    | 'cad_generation'
    | 'cad_execution_repair'
    | 'visual_fidelity_review'
    | 'precision_correction'
    | 'final_visual_review'
    | 'explain-slicer'
    | string;
  contents: any;
  config?: any;
  enableThinking?: boolean;
  timeoutMs?: number;
  requestId?: string;
}

export interface GeminiCallResult {
  text: string;
  model: string;
  durationMs: number;
  attempts: number;
  requestRecords: AIRequestRecord[];
}

export async function callGeminiWithResilience(
  ai: GoogleGenAI,
  params: GeminiCallParams
): Promise<GeminiCallResult> {
  const modelsToTry = [PRIMARY_MODEL, ...FALLBACK_MODELS];
  let lastError: any = null;
  const perAttemptTimeoutMs =
    params.timeoutMs ||
    (params.purpose === 'cad_generation' ||
    params.purpose === 'cad_revision' ||
    params.purpose === 'cad_execution_repair' ||
    params.purpose === 'precision_correction'
      ? 75000
      : 60000);
  const TOTAL_DEADLINE_MS = 180000;
  const MIN_REMAINING_TIME_MS = 15000;
  const overallStartTime = Date.now();
  const overallDeadline = overallStartTime + TOTAL_DEADLINE_MS;
  let totalAttempts = 0;
  const requestRecords: AIRequestRecord[] = [];
  let lastTimeoutModel: string | undefined = undefined;

  let currentThinkingLevel: ThinkingLevel | null = null;
  if (params.purpose === 'precision_correction') {
    currentThinkingLevel = ThinkingLevel.LOW;
  } else if (params.purpose === 'explain-slicer' || params.purpose === 'explain_slicer') {
    currentThinkingLevel = ThinkingLevel.LOW;
  } else if (params.purpose === 'cad_generation' || params.purpose === 'cad_execution_repair' || params.enableThinking) {
    currentThinkingLevel = ThinkingLevel.LOW;
  }

  for (let mIdx = 0; mIdx < modelsToTry.length; mIdx++) {
    const model = modelsToTry[mIdx];

    for (let attempt = 0; attempt < MAX_ATTEMPTS_PER_MODEL; attempt++) {
      const remainingTime = overallDeadline - Date.now();
      if (remainingTime < MIN_REMAINING_TIME_MS) {
        console.warn(`[gemini] Remaining time ${remainingTime}ms < ${MIN_REMAINING_TIME_MS}ms budget before attempt on ${model}. Stopping call.`);
        if (lastError) {
          throw lastError;
        }
        const deadlineErr: any = new Error(`AI generation total deadline budget (${TOTAL_DEADLINE_MS}ms) expired.`);
        deadlineErr.isTimeout = true;
        deadlineErr.statusCode = 504;
        deadlineErr.errorCategory = 'REQUEST_TIMEOUT';
        throw deadlineErr;
      }

      const attemptNumber = totalAttempts + 1;
      totalAttempts++;
      const attemptStartTime = Date.now();
      const attemptTimeoutMs = Math.min(perAttemptTimeoutMs, remainingTime);
      let timeoutId: NodeJS.Timeout | null = null;

      if (params.requestId) {
        updateGenerationStatus(params.requestId, {
          model,
          attempt: attempt + 1,
          thinkingLevel: (currentThinkingLevel || ThinkingLevel.MEDIUM).toLowerCase(),
          phase: lastTimeoutModel ? 'retrying' : (attempt > 0 ? 'retrying' : 'designing'),
          startTime: attemptStartTime,
          lastTimeoutModel,
        });
      }

      try {
        const configToUse = { ...(params.config || {}) };
        if (currentThinkingLevel) {
          configToUse.thinkingConfig = {
            thinkingLevel: currentThinkingLevel,
          };
        }

        const callPromise = ai.models.generateContent({
          model,
          contents: params.contents,
          config: configToUse,
        });

        const timeoutPromise = new Promise<never>((_, reject) => {
          timeoutId = setTimeout(() => {
            const tErr: any = new Error(`AI generation request timed out after ${attemptTimeoutMs}ms`);
            tErr.isTimeout = true;
            tErr.statusCode = 504;
            tErr.errorCategory = 'REQUEST_TIMEOUT';
            reject(tErr);
          }, attemptTimeoutMs);
        });

        const response = await Promise.race([callPromise, timeoutPromise]);

        if (!response || !response.text || !response.text.trim()) {
          const emptyErr: any = new Error(`Gemini model ${model} returned an empty response`);
          emptyErr.errorCategory = 'EMPTY_MODEL_RESPONSE';
          emptyErr.status = 200;
          throw emptyErr;
        }

        const attemptDuration = Date.now() - attemptStartTime;
        requestRecords.push({
          purpose: params.purpose,
          model,
          attemptNumber,
          durationMs: attemptDuration,
          timestamp: attemptStartTime,
          status: 'success',
        });

        return {
          text: response.text,
          model,
          durationMs: Date.now() - overallStartTime,
          attempts: totalAttempts,
          requestRecords,
        };
      } catch (err: any) {
        lastError = err;
        const attemptDuration = Date.now() - attemptStartTime;
        const msg = String(err?.message || err || '');

        let rawStatus: number | undefined = undefined;
        if (typeof err?.status === 'number') rawStatus = err.status;
        else if (typeof err?.statusCode === 'number') rawStatus = err.statusCode;
        else if (typeof err?.code === 'number') rawStatus = err.code;
        else if (typeof err?.error?.code === 'number') rawStatus = err.error.code;
        else if (typeof err?.response?.status === 'number') rawStatus = err.response.status;
        else if (err?.isTimeout) rawStatus = 504;

        const isQuotaExceeded =
          rawStatus === 429 ||
          msg.includes('429') ||
          msg.includes('RESOURCE_EXHAUSTED') ||
          msg.includes('quota') ||
          msg.includes('Quota exceeded') ||
          msg.includes('rate_limit') ||
          msg.includes('rate limit');

        const isAuth =
          rawStatus === 401 ||
          rawStatus === 403 ||
          msg.includes('401') ||
          msg.includes('403') ||
          msg.includes('UNAUTHENTICATED') ||
          msg.includes('PERMISSION_DENIED') ||
          msg.includes('API key not valid');

        const isTimeoutOrDeadline =
          err?.isTimeout ||
          err?.errorCategory === 'REQUEST_TIMEOUT' ||
          rawStatus === 408 ||
          rawStatus === 504 ||
          msg.includes('504') ||
          msg.includes('DEADLINE_EXCEEDED') ||
          msg.includes('Deadline expired') ||
          msg.includes('timed out') ||
          msg.includes('timeout') ||
          msg.includes('ETIMEDOUT') ||
          err?.error?.status === 'DEADLINE_EXCEEDED';

        const isUnavailable =
          rawStatus === 503 ||
          msg.includes('503') ||
          msg.includes('UNAVAILABLE') ||
          msg.includes('high demand') ||
          msg.includes('overloaded');

        const isNotFound =
          rawStatus === 404 ||
          msg.includes('404') ||
          msg.includes('NOT_FOUND') ||
          msg.includes('is not supported') ||
          msg.includes('no longer available');

        const isBadRequest =
          rawStatus === 400 ||
          msg.includes('400') ||
          msg.includes('INVALID_ARGUMENT') ||
          msg.includes('bad request');

        let errorCategory = err?.errorCategory || (err?.isTimeout ? 'REQUEST_TIMEOUT' : undefined);
        if (!errorCategory) {
          if (isQuotaExceeded) errorCategory = 'RATE_LIMIT';
          else if (isAuth) errorCategory = 'AUTH_ERROR';
          else if (isTimeoutOrDeadline) errorCategory = 'REQUEST_TIMEOUT';
          else if (isUnavailable) errorCategory = 'GEMINI_UNAVAILABLE';
          else if (isNotFound) errorCategory = 'MODEL_UNAVAILABLE';
          else if (isBadRequest) errorCategory = 'INVALID_REQUEST';
          else errorCategory = 'UNKNOWN_ERROR';
        }

        const effectiveStatusCode = rawStatus || (isTimeoutOrDeadline ? 504 : isQuotaExceeded ? 429 : isAuth ? 401 : isUnavailable ? 503 : isNotFound ? 404 : isBadRequest ? 400 : 500);

        requestRecords.push({
          purpose: params.purpose,
          model,
          attemptNumber,
          durationMs: attemptDuration,
          timestamp: attemptStartTime,
          status: 'failure',
          statusCode: effectiveStatusCode,
          errorCategory,
        });

        err.errorCategory = errorCategory;
        err.statusCode = effectiveStatusCode;
        err.requestRecords = requestRecords;
        err.modelsUsed = Array.from(new Set(requestRecords.map((r) => r.model)));
        err.totalModelCalls = totalAttempts;

        // 429 and 401/403 abort immediately with no retry and no fallback.
        if (isQuotaExceeded || isAuth) {
          throw err;
        }

        // 400 aborts.
        if (isBadRequest) {
          throw err;
        }

        // 404 moves to the next model immediately.
        if (isNotFound) {
          console.warn(`[gemini] ${model} returned 404, moving to next model...`);
          break;
        }

        // REQUEST_TIMEOUT / 504 / Deadline expired: NOT transient — a prompt that took 150s will take 150s again.
        // Do NOT retry the same model. Instead, move immediately to the next model in the chain AND drop one thinking level (MEDIUM -> LOW).
        if (isTimeoutOrDeadline) {
          lastTimeoutModel = model;
          if (mIdx + 1 < modelsToTry.length) {
            const nextModel = modelsToTry[mIdx + 1];
            const oldLevel = currentThinkingLevel || ThinkingLevel.MEDIUM;
            if (currentThinkingLevel) {
              currentThinkingLevel = dropThinkingLevel(currentThinkingLevel);
            }
            const newLevel = currentThinkingLevel || ThinkingLevel.LOW;
            console.log(`[gemini] ${model} timed out at ${oldLevel}, falling to ${nextModel} at ${newLevel}`);
            if (params.requestId) {
              updateGenerationStatus(params.requestId, {
                model: nextModel,
                attempt: 1,
                thinkingLevel: (currentThinkingLevel || ThinkingLevel.LOW).toLowerCase(),
                phase: 'retrying',
                startTime: Date.now(),
                lastTimeoutModel: model,
              });
            }
            break;
          } else {
            console.warn(`[gemini] ${model} timed out and no fallback models remain in chain.`);
            throw err;
          }
        }

        // 503 / UNAVAILABLE / EMPTY_MODEL_RESPONSE: transient. Keep the current same-model backoff retry.
        const isTransient = isUnavailable || errorCategory === 'EMPTY_MODEL_RESPONSE';
        if (isTransient) {
          if (attempt + 1 < MAX_ATTEMPTS_PER_MODEL) {
            const delayBase = BACKOFF_DELAYS_MS[attempt] ?? 2000;
            const waitMs = Math.round(delayBase + Math.random() * 500);
            const statusLabel = effectiveStatusCode || 503;
            console.log(`[gemini] ${model} attempt ${attempt + 2}/${MAX_ATTEMPTS_PER_MODEL} after ${statusLabel}, waiting ${waitMs}ms`);
            if (params.requestId) {
              updateGenerationStatus(params.requestId, {
                model,
                attempt: attempt + 2,
                thinkingLevel: (currentThinkingLevel || ThinkingLevel.MEDIUM).toLowerCase(),
                phase: 'retrying',
                startTime: Date.now(),
              });
            }
            await new Promise((res) => setTimeout(res, waitMs));
            continue;
          } else {
            console.warn(`[gemini] ${model} exhausted ${MAX_ATTEMPTS_PER_MODEL} attempts.`);
            break;
          }
        }

        // Any other non-transient error: move to next model if available, else throw
        if (mIdx + 1 < modelsToTry.length) {
          break;
        }
        throw err;
      } finally {
        if (timeoutId) {
          clearTimeout(timeoutId);
        }
      }
    }
  }

  if (lastError) {
    lastError.requestRecords = requestRecords;
    lastError.modelsUsed = Array.from(new Set(requestRecords.map((r) => r.model)));
    lastError.totalModelCalls = totalAttempts;
    throw lastError;
  }

  const genericErr: any = new Error('CAD generation request could not be completed.');
  genericErr.requestRecords = requestRecords;
  genericErr.modelsUsed = Array.from(new Set(requestRecords.map((r) => r.model)));
  genericErr.totalModelCalls = totalAttempts;
  throw genericErr;
}

export function sanitizeErrorDetails(raw: any): string {
  const str = typeof raw === 'string' ? raw : raw?.stack || raw?.message || JSON.stringify(raw) || '';
  return str
    .replace(/AIza[0-9A-Za-z-_]{35}/g, '[REDACTED_API_KEY]')
    .replace(/Bearer\s+[a-zA-Z0-9_\-\.]+/gi, 'Bearer [REDACTED_TOKEN]')
    .replace(/key=[a-zA-Z0-9_\-]+/gi, 'key=[REDACTED]');
}

export interface CleanedError {
  message: string;
  errorCategory: string;
  technicalDetails: string;
  statusCode: number;
}

export function cleanErrorMessage(err: any): CleanedError {
  const msg = String(err?.message || err || '');
  let rawStatus: number = 0;
  if (typeof err?.status === 'number') rawStatus = err.status;
  else if (typeof err?.statusCode === 'number') rawStatus = err.statusCode;
  else if (typeof err?.code === 'number') rawStatus = err.code;
  else if (typeof err?.error?.code === 'number') rawStatus = err.error.code;
  else if (typeof err?.response?.status === 'number') rawStatus = err.response.status;
  else if (err?.isTimeout) rawStatus = 504;

  const technicalDetails = sanitizeErrorDetails(err);

  // 401: Invalid or missing API key
  if (
    rawStatus === 401 ||
    msg.includes('401') ||
    msg.includes('UNAUTHENTICATED') ||
    msg.includes('API key not valid') ||
    msg.includes('invalid api_key') ||
    msg.includes('Invalid API key') ||
    msg.includes('GEMINI_API_KEY is not configured')
  ) {
    return {
      message: 'Invalid or missing Gemini API credential.',
      errorCategory: 'AUTH_ERROR',
      technicalDetails,
      statusCode: 401,
    };
  }

  // 403: Permission denied
  if (
    rawStatus === 403 ||
    msg.includes('403') ||
    msg.includes('PERMISSION_DENIED') ||
    msg.includes('permission')
  ) {
    return {
      message: 'Gemini API credential does not have permission to access this model or project.',
      errorCategory: 'PERMISSION_ERROR',
      technicalDetails,
      statusCode: 403,
    };
  }

  // 429: Rate limit / Quota
  if (
    rawStatus === 429 ||
    msg.includes('429') ||
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('quota') ||
    msg.includes('Quota exceeded') ||
    msg.includes('rate limit') ||
    msg.includes('rate_limit')
  ) {
    return {
      message: 'Gemini AI rate limit reached. Please wait a few seconds before generating again, or switch to Template Mode.',
      errorCategory: 'RATE_LIMIT',
      technicalDetails,
      statusCode: 429,
    };
  }

  // 404: Model unavailable
  if (
    rawStatus === 404 ||
    msg.includes('404') ||
    msg.includes('NOT_FOUND') ||
    msg.includes('is not supported') ||
    msg.includes('no longer available') ||
    msg.includes('model not found')
  ) {
    return {
      message: 'Requested Gemini model is unavailable.',
      errorCategory: 'MODEL_UNAVAILABLE',
      technicalDetails,
      statusCode: 404,
    };
  }

  // Timeout / 504 / DEADLINE_EXCEEDED
  if (
    rawStatus === 504 ||
    rawStatus === 408 ||
    err?.errorCategory === 'REQUEST_TIMEOUT' ||
    msg.includes('504') ||
    msg.includes('DEADLINE_EXCEEDED') ||
    msg.includes('Deadline expired') ||
    msg.includes('timeout') ||
    msg.includes('timed out') ||
    msg.includes('ETIMEDOUT') ||
    err?.error?.status === 'DEADLINE_EXCEEDED'
  ) {
    return {
      message: 'Generation took longer than 3 minutes across all models. Try again — if it keeps happening, split the part into simpler pieces.',
      errorCategory: 'REQUEST_TIMEOUT',
      technicalDetails,
      statusCode: 504,
    };
  }

  // 503 / Unavailable / Overloaded
  if (
    rawStatus === 503 ||
    msg.includes('503') ||
    msg.includes('UNAVAILABLE') ||
    msg.includes('high demand') ||
    msg.includes('overloaded') ||
    msg.includes('Service Unavailable')
  ) {
    return {
      message: 'Gemini AI is temporarily experiencing high traffic. Please retry in a few moments, or switch to Template Mode.',
      errorCategory: 'GEMINI_UNAVAILABLE',
      technicalDetails,
      statusCode: 503,
    };
  }

  // Security violations
  if (
    msg.includes('Security violation') ||
    msg.includes('security sandbox') ||
    msg.includes('forbidden') ||
    msg.includes('FORBIDDEN_SECURITY')
  ) {
    return {
      message: 'Generated code violated security sandbox constraints.',
      errorCategory: 'SECURITY_REJECTION',
      technicalDetails,
      statusCode: 422,
    };
  }

  // Organic unconfigured
  if (
    msg.includes('Organic mesh generation provider not configured') ||
    msg.includes('Organic 3D Engine not configured')
  ) {
    return {
      message: 'Organic 3D Engine not configured. The requested model requires a Text-to-3D neural mesh engine rather than the Parametric CAD engine.',
      errorCategory: 'ORGANIC_UNCONFIGURED',
      technicalDetails,
      statusCode: 422,
    };
  }

  // Hybrid unconfigured
  if (
    msg.includes('Hybrid organic/mechanical generation provider not configured')
  ) {
    return {
      message: 'Hybrid organic/mechanical generation provider not configured.',
      errorCategory: 'HYBRID_UNCONFIGURED',
      technicalDetails,
      statusCode: 422,
    };
  }

  // Empty or degenerate geometry
  if (
    msg.includes('empty or degenerate') ||
    msg.includes('zero valid polygons') ||
    msg.includes('empty or invalid geometry') ||
    msg.includes('INVALID_GEOMETRY')
  ) {
    return {
      message: 'Generated model produced empty or degenerate geometry.',
      errorCategory: 'INVALID_GEOMETRY',
      technicalDetails,
      statusCode: 422,
    };
  }

  // JSCAD execution / runtime errors
  if (
    msg.includes('JSCAD') ||
    msg.includes('execution error') ||
    msg.includes('could not generate valid executable CAD') ||
    msg.includes('ReferenceError') ||
    msg.includes('TypeError') ||
    msg.includes('SyntaxError') ||
    msg.includes('main() returned')
  ) {
    return {
      message: 'Generated JSCAD code could not be executed into valid geometry.',
      errorCategory: 'JSCAD_EXECUTION_ERROR',
      technicalDetails,
      statusCode: 422,
    };
  }

  // 400 / INVALID_ARGUMENT
  if (
    rawStatus === 400 ||
    msg.includes('400') ||
    msg.includes('INVALID_ARGUMENT') ||
    msg.includes('bad request')
  ) {
    return {
      message: 'Gemini rejected the request parameters.',
      errorCategory: 'INVALID_REQUEST',
      technicalDetails,
      statusCode: 400,
    };
  }

  return {
    message: err?.message || 'Failed to complete parametric CAD generation.',
    errorCategory: 'UNKNOWN_ERROR',
    technicalDetails,
    statusCode: 500,
  };
}

export function getErrorDiagnostics(err: any) {
  const records: AIRequestRecord[] = Array.isArray(err?.requestRecords)
    ? err.requestRecords
    : [];

  return {
    modelUsed: getLastSuccessfulModel(records),
    modelsUsed:
      err?.modelsUsed ?? Array.from(new Set(records.map((r: AIRequestRecord) => r.model))),
    requestRecords: records,
    aiCallsMade: err?.totalModelCalls ?? records.length,
  };
}
