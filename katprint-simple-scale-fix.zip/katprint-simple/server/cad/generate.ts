import type { Express } from "express";
import type { GoogleGenAI } from "@google/genai";
import type {
  ExtractedRequirements,
  ProjectReferenceImage,
  PrinterSpec,
  FilamentSpec,
  DesignSpecification,
  DesignCheck,
  GenerationMode,
} from "../../src/types";
import type {
  SemanticFeatureModel,
  FeatureParameter,
} from "../../src/features/featureTypes";
import type { RevisionContextPayload } from "../../src/services/geminiService";
import {
  getGeminiClient,
  callGeminiWithResilience,
  cleanErrorMessage,
  getErrorDiagnostics,
  getLastSuccessfulModel,
  updateGenerationStatus,
  PRIMARY_MODEL,
  AIRequestRecord,
  GeminiCallResult,
} from "../gemini/client";
import {
  extractAndValidateJscad,
  executeJscadServerSide,
  measureJscadSolids,
  validateCodeSecurity as validateCadCodeSecurity,
  GeometryMeasurements,
} from "./sandbox";
import {
  auditGeneratedGeometry,
  auditPromptPhysicalMeasurements,
  AuditFinding,
  GeometryAuditResult,
} from "./audit";
import { validateReservedBuilderUsage } from "../../src/features/featureGenerators";
import { synthesizeOfflineJscad } from "./template";
import { CAD_EXAMPLES } from "../../src/prompts/cadExamples";
import {
  formatMatingClearanceContext,
  getFeatureBuilderPromptDocs,
  appendReferenceImagesToContents,
  buildTextOnlyRequirements,
} from "./shared";
import { extractRequirements } from "../full/extractRequirements";

// ---------------------------------------------------------------------------
// Step 2 & 3: CAD Generation & Closed Verification Loop
// ---------------------------------------------------------------------------
export interface GenerateAndRepairJscadOptions {
  prompt: string;
  requirements: ExtractedRequirements | DesignSpecification | Record<string, unknown>;
  ai: GoogleGenAI;
  isRevision?: boolean;
  previousCode?: string;
  revisionContext?: RevisionContextPayload;
  mode?: GenerationMode | string;
  featureModel?: SemanticFeatureModel;
  designSpecification?: DesignSpecification;
  designChecklist?: DesignCheck[];
  referenceImages?: ProjectReferenceImage[];
  userOverrides?: string[];
  printer?: PrinterSpec | null;
  priorAudit?: GeometryAuditResult;
  priorFeatures?: string[];
  requestId?: string;
  examples?: Array<{ id?: string; title: string; code: string; source?: string }>;
}

export interface GenerateAndRepairJscadResult {
  code: string;
  measurements: GeometryMeasurements;
  repairAttempts: number;
  requestRecords: AIRequestRecord[];
  modelsUsed: string[];
  totalModelCalls: number;
  auditFindings: AuditFinding[];
  auditScore: number;
  auditCycles: number;
  auditDurationMs: number;
  auditPassed: boolean;
}

export async function generateAndRepairJscad(options: GenerateAndRepairJscadOptions): Promise<GenerateAndRepairJscadResult> {
  const {
    prompt,
    requirements,
    ai,
    isRevision = false,
    previousCode = '',
    revisionContext,
    mode,
    featureModel,
    designSpecification,
    designChecklist,
    referenceImages,
    userOverrides,
    printer,
    priorAudit,
    priorFeatures,
    requestId,
  } = options;

  let refImagesContext = '';
  if (referenceImages && Array.isArray(referenceImages) && referenceImages.length > 0) {
    refImagesContext = `\nPROJECT REFERENCE PHOTOS & USER SPECIFICATIONS:\n` +
      referenceImages.map((img: any, idx: number) => {
        const title = img.name || img.label || `Photo ${idx + 1}`;
        const notes = img.notes ? ` (Notes: ${img.notes})` : '';
        return `- Reference Image [${title}]${notes}`;
      }).join('\n') + '\n';
  }

  const semanticFeatures =
    featureModel?.features ||
    revisionContext?.targetFeatureModel?.features ||
    revisionContext?.featureModel?.features;
  const builderDocs = getFeatureBuilderPromptDocs(semanticFeatures);

  let examplesBlock = CAD_EXAMPLES;
  if (Array.isArray(options.examples) && options.examples.length > 0) {
    const validExamples: Array<{ id?: string; title: string; code: string; source?: string }> = [];
    for (const ex of options.examples) {
      if (!ex || typeof ex.code !== 'string' || !ex.title) continue;
      // 12 KB size cap
      if (Buffer.byteLength(ex.code, 'utf8') > 12 * 1024) continue;
      // Validate with validateCadCodeSecurity
      const sec = validateCadCodeSecurity(ex.code);
      if (!sec.isSafe) continue;
      validExamples.push(ex);
    }

    if (validExamples.length > 0) {
      const logEntries = validExamples.map((ex) => {
        const src = ex.source || 'seed';
        const name = ex.id
          ? ex.id.replace(/^seed_/, '')
          : ex.title.toLowerCase().replace(/[^a-z0-9\-]/g, '-').slice(0, 20);
        return `${name}(${src})`;
      });
      console.log(`[gen] examples: ${logEntries.join(', ')}`);

      examplesBlock = validExamples
        .map((ex, idx) => {
          const cleanCode = ex.code.replace(/^\/\/\s*EXAMPLE\s*\d+\s*[—\-–][^\n]*\n?/i, '').trim();
          return `// EXAMPLE ${idx + 1} — ${ex.title}\n${cleanCode}`;
        })
        .join('\n\n');
    } else {
      console.log('[gen] examples: fallback to CAD_EXAMPLES (no valid examples)');
    }
  }

  const systemInstruction = `You are an expert mechanical CAD engineer writing functional @jscad/modeling (v2) JavaScript for 3D printing.
Before writing code, state in a single comment line at the top which example most resembles this request and what differs.

VERIFIED REFERENCE EXAMPLES:
${examplesBlock}

CORE RULES:
1. CONSTANTS: Declare all dimensions as top-level numeric consts in mm (e.g. const width = 80.0;). Keep them literal numbers, not expressions.
2. KP_DERIVED: After consts, include a JSON block in a /* KP_DERIVED [ { "derived": "name", "expression": "...", "inputs": [...] } ] */ comment.
3. FEATURES: Encapsulate features in function kpFeature_<id>() returning geometry in WORLD coordinates at final position. Call in main().
4. MULTI-PART: For assemblies with multiple pieces, define kpPart_<id>(), getParts() returning [{ id, name, quantity, geometry }], and main() { return getParts().map(p => p.geometry); }.
5. PRINTABILITY: Single-piece parts must sit with flat base at Z=0. Wall thickness >= 2.0mm. Use subtract() for cavities and union() for additions.
6. FORMAT: Functional JSCAD V2 format only (translate, rotate, subtract, union, cuboid, cylinder). No imports/require/DOM access. Return executable JS.
7. PARAMETERIZED BUILDERS PREFERENCE: Prefer parameterized volumetric builders (tray, stand, bracket, box, holder, relief) instead of freeform JSCAD when possible. Define clean numeric constants for dimensions, wall thickness, clearances, and corner radii.
${builderDocs}`;

  const requestRecords: AIRequestRecord[] = [];
  const modelsUsedSet = new Set<string>();
  let totalModelCalls = 0;

  const attachTelemetryAndRethrow = (err: any) => {
    err.requestRecords = requestRecords;
    err.modelsUsed = Array.from(modelsUsedSet);
    err.totalModelCalls = totalModelCalls;
    throw err;
  };

  // ---------------------------------------------------------------------------
  // Stage 1: Primary CAD Generation
  // ---------------------------------------------------------------------------
  let stage1Prompt = '';
  if (isRevision && previousCode) {
    let contextDetails = '';
    if (revisionContext) {
      if (revisionContext.requestedChanges && Array.isArray(revisionContext.requestedChanges) && revisionContext.requestedChanges.length > 0) {
        contextDetails += `\nEXPLICIT CHANGES TO APPLY:\n${revisionContext.requestedChanges.map((c: any) => `- ${c.feature}: ${c.change}${c.toValue ? ` (Target: ${c.toValue})` : ''}`).join('\n')}\n`;
      }
      if (revisionContext.preservedFeatures && Array.isArray(revisionContext.preservedFeatures) && revisionContext.preservedFeatures.length > 0) {
        contextDetails += `\nPRESERVED UNTOUCHED FEATURES (DO NOT REMOVE OR BREAK):\n${revisionContext.preservedFeatures.map((f: string) => `- ${f}`).join('\n')}\n`;
      }
      if (revisionContext.projectMemory?.importantDecisions && Array.isArray(revisionContext.projectMemory.importantDecisions) && revisionContext.projectMemory.importantDecisions.length > 0) {
        contextDetails += `\nPROJECT MEMORY & DESIGN CONSTRAINTS:\n${revisionContext.projectMemory.importantDecisions.map((d: string) => `- ${d}`).join('\n')}\n`;
      }
      if (revisionContext.recentConversation && Array.isArray(revisionContext.recentConversation) && revisionContext.recentConversation.length > 0) {
        contextDetails += `\nRECENT CONVERSATION CONTEXT:\n${revisionContext.recentConversation.slice(-5).map((m: any) => `${m.role}: ${m.content}`).join('\n')}\n`;
      }

      // Current Semantic Feature Model
      if (revisionContext.featureModel) {
        contextDetails += `
CURRENT SEMANTIC FEATURE MODEL (PRE-REVISION):
${JSON.stringify(revisionContext.featureModel, null, 2)}
`;
      }

      // Target Semantic Feature Model
      const targetModel = revisionContext.targetFeatureModel || featureModel || revisionContext.featureModel;
      if (targetModel) {
        contextDetails += `
TARGET SEMANTIC FEATURE MODEL AFTER REQUESTED CHANGE (AUTHORITATIVE FOR NEW VERSION):
${JSON.stringify(targetModel, null, 2)}

THIS TARGET SEMANTIC FEATURE MODEL IS AUTHORITATIVE FOR THIS REVISION.
The generated revised CAD must implement this target model.
`;
      }

      // Semantic Revision Operation
      if (revisionContext.semanticOperation) {
        contextDetails += `
SEMANTIC REVISION OPERATION:
${JSON.stringify(revisionContext.semanticOperation, null, 2)}

Instruction: Only the features/parameters named by this operation should change unless a dependent derived constraint requires another update.
`;
      }

      // Current Semantic Binding Validation
      if (revisionContext.bindingValidation) {
        contextDetails += `
CURRENT SEMANTIC BINDING VALIDATION:
${JSON.stringify(revisionContext.bindingValidation, null, 2)}
`;
      }

      // Locked Semantic Parameters with IDs, constants, and values
      const modelParams: FeatureParameter[] = (targetModel || revisionContext.featureModel)?.parameters || [];
      const lockedIds = revisionContext.lockedParameterIds || modelParams.filter((p) => p.locked).map((p) => p.id);
      if (lockedIds.length > 0) {
        const lockedDetails = lockedIds.map((id) => {
          const p = modelParams.find((param) => param.id === id);
          return `- Parameter ID: ${id} | Semantic Name: ${p?.name || p?.semanticName || id} | Constant: const ${p?.jscadConstantName || p?.name || id} | Value: ${p?.value !== undefined ? p.value : 'N/A'} ${p?.unit || 'mm'}`;
        });
        contextDetails += `
LOCKED SEMANTIC PARAMETERS:
${lockedDetails.join('\n')}

Instruction: DO NOT CHANGE THESE VALUES unless the SemanticRevisionOperation explicitly represents an intentional lock override.
`;
      }

      // Code Binding ABI & Preservation
      if (revisionContext.featureModel?.codeBindings && Object.keys(revisionContext.featureModel.codeBindings).length > 0) {
        contextDetails += `
CODE BINDING ABI TO PRESERVE:
${JSON.stringify(revisionContext.featureModel.codeBindings, null, 2)}

Instruction: Do not rename bound constants. Do not rename preserved feature wrappers.
`;
      }
    }

    const matingClearanceLine = formatMatingClearanceContext(printer);
    stage1Prompt = `REVISION TASK:
Original Code:
\`\`\`js
${previousCode}
\`\`\`

User Revision Request: "${prompt}"
${matingClearanceLine}
${contextDetails}
Updated Technical Requirements:
${JSON.stringify(requirements, null, 2)}

INSTRUCTIONS:
1. MODIFY ONLY the features and parameters requested by the revision.
2. For every SemanticFeature preserved from the current model, reuse its existing code bindings (wrapper function name kpFeature_<featureId> and parameter constant names). Only added or modified features should receive new or updated bindings.
3. PRESERVE WORLD-SPACE WRAPPER ABI: Every kpFeature_<featureId>() must return geometry positioned in final model coordinates. DO NOT introduce outer transforms (translate, rotate, scale, center, align) around semantic wrappers in main().
4. DO NOT recreate or regenerate the whole model from scratch when the change can be expressed by modifying existing semantic parameters or features.
5. DO NOT violate projectMemory constraints or modify locked parameters.
6. Maintain top-level editable numeric constants.
7. If the existing CAD contains getParts() or kpPart_ wrappers, PRESERVE THE MULTI-PIECE ABI: keep unchanged part IDs, kpPart_<id>() names, quantities, getParts() metadata, and separate solids unless the user explicitly changes assembly structure. Never repair/revise by fusing printable pieces.
8. Return ONLY executable JavaScript.`;
  } else {
    let semanticContext = '';
    if (featureModel && Array.isArray(featureModel.features) && featureModel.features.length > 0) {
      semanticContext += `
AUTHORITATIVE SEMANTIC FEATURE MODEL:
${JSON.stringify(featureModel, null, 2)}

SEMANTIC IMPLEMENTATION RULES:
1. Implement every critical and important feature from the semantic model.
2. Preserve exact feature IDs: for each feature, create a dedicated wrapper function named \`kpFeature_<featureId>()\`.
3. WORLD-SPACE SELECTION ABI: Every \`kpFeature_<featureId>()\` must return its geometry already positioned in FINAL WORLD COORDINATES. Do NOT wrap \`kpFeature_*()\` calls in outer \`translate\`, \`rotate\`, \`scale\`, \`center\`, or \`align\` inside \`main()\`.
4. Preserve exact parameter constant names: declare top-level consts with the exact \`jscadConstantName\` (or parameter name) and required numeric values.
5. Preserve locked values: do not change or substitute locked parameters.
6. Use registered deterministic builders (such as createThroughHole, createCountersinkHole, createCounterboreHole, createElongatedSlot, createCableOpening, createMountingBoss, createPCBStandoff, createReinforcingRib, createCornerGusset, createLinearHolePattern, createCircularHolePattern, createDrainageSlotPattern).
7. Do not silently replace semantic dimensions or omit planned features.
`;
    }

    if (designSpecification) {
      semanticContext += `
FORMAL DESIGN SPECIFICATION:
${JSON.stringify(designSpecification, null, 2)}
`;
    }

    if (designChecklist && Array.isArray(designChecklist) && designChecklist.length > 0) {
      semanticContext += `
VERIFICATION CHECKLIST EXPECTATIONS:
${designChecklist.map((c: any) => `- [${c.severity || 'CRITICAL'}] ${c.title || c.requirement || 'Check'}: ${c.description || ''}`).join('\n')}
`;
    }

    const effectiveOverrides: string[] =
      userOverrides ||
      (requirements as any)?.userOverrides ||
      [];

    let overridesContext = '';
    if (Array.isArray(effectiveOverrides) && effectiveOverrides.length > 0) {
      overridesContext = `\nUSER-CONFIRMED PARAMETERS (AUTHORITATIVE — these override any inference and must appear as exact top-level constants):\n${effectiveOverrides.map((o: string) => `- ${o}`).join('\n')}\n`;
    }

    const matingClearanceLine = formatMatingClearanceContext(printer);
    stage1Prompt = `USER REQUEST: "${prompt}"
${refImagesContext}${overridesContext}
${matingClearanceLine}
EXTRACTED HARD SPECIFICATIONS:
${JSON.stringify(requirements, null, 2)}
${semanticContext}
Generate the complete, verified, executable @jscad/modeling script containing every single requested feature, top-level named consts, and dedicated kpFeature_<featureId>() wrapper functions.`;
  }

  let stage1Result: GeminiCallResult;
  try {
    const generationContents: any[] = [{ text: stage1Prompt }];
    appendReferenceImagesToContents(generationContents, referenceImages || []);
    stage1Result = await callGeminiWithResilience(ai, {
      purpose: 'cad_generation',
      contents: generationContents,
      config: {
        systemInstruction,
      },
      enableThinking: true,
      requestId,
    });
  } catch (apiErr: any) {
    if (apiErr?.requestRecords && Array.isArray(apiErr.requestRecords)) {
      apiErr.requestRecords.forEach((r: AIRequestRecord) => {
        modelsUsedSet.add(r.model);
        requestRecords.push(r);
      });
      totalModelCalls += (apiErr.totalModelCalls || apiErr.requestRecords.length);
    }
    attachTelemetryAndRethrow(apiErr);
  }

  totalModelCalls += stage1Result.attempts;
  stage1Result.requestRecords.forEach((r) => {
    modelsUsedSet.add(r.model);
    requestRecords.push(r);
  });

  const extractedCode1 = extractAndValidateJscad(stage1Result.text);
  let lastExecutionError = '';
  let failingCode = stage1Result.text;

  let currentCode: string | null = null;
  let currentExec: any = null;
  let currentMeasurements: GeometryMeasurements | null = null;
  let stage1ExecutionRepairs = 0;

  if (extractedCode1) {
    failingCode = extractedCode1;
    const reservedErr = validateReservedBuilderUsage(extractedCode1);
    if (reservedErr) {
      lastExecutionError = reservedErr.message;
    } else {
      const execResult1 = executeJscadServerSide(extractedCode1);
      if (execResult1.success && execResult1.measurements && execResult1.measurements.isNonEmpty) {
        currentCode = extractedCode1;
        currentExec = execResult1;
        currentMeasurements = execResult1.measurements;
      } else {
        lastExecutionError = execResult1.error || 'Execution returned empty or invalid geometry';
      }
    }
  } else {
    lastExecutionError = 'Generated code did not contain a valid main() function declaration';
  }

  // ---------------------------------------------------------------------------
  // Stage 2: Single CAD Execution Repair (ONLY if Stage 1 code failed execution)
  // ---------------------------------------------------------------------------
  if (!currentCode || !currentMeasurements) {
    console.warn(`[JSCAD Repair] Stage 1 execution failed (${lastExecutionError}). Launching cad_execution_repair pass...`);

    let executionRepairSemanticContext = '';

    if (isRevision && revisionContext) {
      if (revisionContext.featureModel) {
        executionRepairSemanticContext += `
CURRENT SEMANTIC FEATURE MODEL (PRE-REVISION):
${JSON.stringify(revisionContext.featureModel, null, 2)}
`;
      }
      const targetModel = revisionContext.targetFeatureModel || featureModel || revisionContext.featureModel;
      if (targetModel) {
        executionRepairSemanticContext += `
TARGET SEMANTIC FEATURE MODEL AFTER REQUESTED CHANGE (AUTHORITATIVE FOR NEW VERSION):
${JSON.stringify(targetModel, null, 2)}
`;
      }
      if (revisionContext.semanticOperation) {
        executionRepairSemanticContext += `
SEMANTIC REVISION OPERATION:
${JSON.stringify(revisionContext.semanticOperation, null, 2)}
`;
      }
      if (revisionContext.bindingValidation) {
        executionRepairSemanticContext += `
CURRENT SEMANTIC BINDING VALIDATION:
${JSON.stringify(revisionContext.bindingValidation, null, 2)}
`;
      }
      const modelParams: FeatureParameter[] = (targetModel || revisionContext.featureModel)?.parameters || [];
      const lockedIds = revisionContext.lockedParameterIds || modelParams.filter((p) => p.locked).map((p) => p.id);
      if (lockedIds.length > 0) {
        const lockedDetails = lockedIds.map((id) => {
          const p = modelParams.find((param) => param.id === id);
          return `- Parameter ID: ${id} | Semantic Name: ${p?.name || p?.semanticName || id} | Constant: const ${p?.jscadConstantName || p?.name || id} | Value: ${p?.value !== undefined ? p.value : 'N/A'} ${p?.unit || 'mm'}`;
        });
        executionRepairSemanticContext += `
LOCKED SEMANTIC PARAMETERS:
${lockedDetails.join('\n')}
`;
      }
      if (revisionContext.featureModel?.codeBindings && Object.keys(revisionContext.featureModel.codeBindings).length > 0) {
        executionRepairSemanticContext += `
CODE BINDING ABI TO PRESERVE:
${JSON.stringify(revisionContext.featureModel.codeBindings, null, 2)}
`;
      }
    } else if (featureModel) {
      executionRepairSemanticContext += `
AUTHORITATIVE SEMANTIC FEATURE MODEL:
${JSON.stringify(featureModel, null, 2)}
`;
      const modelParams: FeatureParameter[] = featureModel.parameters || [];
      const lockedParams = modelParams.filter((p) => p.locked);
      if (lockedParams.length > 0) {
        const lockedDetails = lockedParams.map((p) => `- Parameter ID: ${p.id} | Semantic Name: ${p.name || p.semanticName || p.id} | Constant: const ${p.jscadConstantName || p.name || p.id} | Value: ${p.value !== undefined ? p.value : 'N/A'} ${p.unit || 'mm'}`);
        executionRepairSemanticContext += `
LOCKED SEMANTIC PARAMETERS:
${lockedDetails.join('\n')}
`;
      }
    }

    const specToInclude = designSpecification || revisionContext?.designSpecification;
    if (specToInclude) {
      executionRepairSemanticContext += `
FORMAL DESIGN SPECIFICATION:
${JSON.stringify(specToInclude, null, 2)}
`;
    }

    if (designChecklist && Array.isArray(designChecklist) && designChecklist.length > 0) {
      executionRepairSemanticContext += `
CRITICAL DESIGN CHECKLIST EXPECTATIONS:
${designChecklist.map((c: any) => `- [${c.severity || c.importance || 'CRITICAL'}] ${c.title || c.requirement || c.id || 'Check'}: ${c.description || c.notes || ''}`).join('\n')}
`;
    }

    const stage2Prompt = `RUNTIME ERROR REPAIR: Auto-Repairing Geometry (Attempt 1/1):
The generated JSCAD code failed execution with the following error:
>>> ${lastExecutionError}

Original Prompt: "${prompt}"
Mandatory Technical Requirements:
${JSON.stringify(requirements, null, 2)}
${executionRepairSemanticContext}

Failing Code:
\`\`\`js
${failingCode}
\`\`\`

CAD EXECUTION & RUNTIME REPAIR RULES:
1. REPAIR ONLY THE EXECUTION FAILURE (syntax error, invalid CSG/boolean operation, bad transform input, invalid geometry construction, undefined local helper, empty geometry).
2. DO NOT REDESIGN OR SIMPLIFY THE OBJECT.
3. PRESERVE THE SEMANTIC ABI:
   - DO NOT rename top-level parameter constants (e.g. const <jscadConstantName> = <value>;).
   - DO NOT change exact parameter constant values unless the execution error is directly caused by an invalid numeric value AND the semantic model explicitly authorizes a different value.
   - DO NOT rename or delete kpFeature_<featureId>() wrapper functions.
   - DO NOT delete failing feature wrappers to "fix" an error — keep every feature wrapper connected to executable main() geometry.
   - DO NOT remove unrelated or preserved features.
   - PRESERVE registered deterministic builder calls (createThroughHole, createCountersinkHole, createCounterboreHole, createElongatedSlot, createCableOpening, createMountingBoss, createPCBStandoff, createReinforcingRib, createCornerGusset, createLinearHolePattern, createCircularHolePattern, createDrainageSlotPattern). Do NOT rewrite them with raw primitive geometry.
   - PRESERVE WORLD-SPACE WRAPPER ABI: Every feature wrapper kpFeature_<featureId>() must return world-positioned geometry. A repair may NOT fix code by moving spatial transforms outside kpFeature_<id>().
4. If this is a revision, ensure the code satisfies the TARGET SEMANTIC FEATURE MODEL (all added/modified features must remain present and functional).
5. DO NOT modify locked parameter values.
6. PRESERVE MULTI-PIECE ABI when the failing code or user request is multi-piece: keep kpPart_<id>() wrappers, getParts(), stable part IDs/names/quantities, and separate solids. Never fix execution by unioning independent printed pieces.
7. Return ONLY executable @jscad/modeling JavaScript preserving the original single-piece or multi-piece structure. Single-piece may use main() returning one solid; multi-piece must retain getParts() and main() returning getParts().map((part) => part.geometry).`;

    let stage2Result: GeminiCallResult;
    try {
      stage2Result = await callGeminiWithResilience(ai, {
        purpose: 'cad_execution_repair',
        contents: stage2Prompt,
        config: {
          systemInstruction,
        },
        enableThinking: true,
        requestId,
      });
    } catch (repairApiErr: any) {
      if (repairApiErr?.requestRecords && Array.isArray(repairApiErr.requestRecords)) {
        repairApiErr.requestRecords.forEach((r: AIRequestRecord) => {
          modelsUsedSet.add(r.model);
          requestRecords.push(r);
        });
        totalModelCalls += (repairApiErr.totalModelCalls || repairApiErr.requestRecords.length);
      }
      attachTelemetryAndRethrow(repairApiErr);
    }

    totalModelCalls += stage2Result.attempts;
    stage2Result.requestRecords.forEach((r) => {
      modelsUsedSet.add(r.model);
      requestRecords.push(r);
    });

    const extractedCode2 = extractAndValidateJscad(stage2Result.text);
    if (extractedCode2) {
      const reservedErr2 = validateReservedBuilderUsage(extractedCode2);
      if (reservedErr2) {
        lastExecutionError = reservedErr2.message;
      } else {
        const execResult2 = executeJscadServerSide(extractedCode2);
        if (execResult2.success && execResult2.measurements && execResult2.measurements.isNonEmpty) {
          currentCode = extractedCode2;
          currentExec = execResult2;
          currentMeasurements = execResult2.measurements;
          stage1ExecutionRepairs = 1;
        } else {
          lastExecutionError = execResult2.error || 'Execution returned empty or invalid geometry';
        }
      }
    } else {
      lastExecutionError = 'Repaired code did not contain a valid main() function declaration';
    }

    if (!currentCode || !currentMeasurements) {
      const execErr: any = new Error(`Generated JSCAD code could not be executed into valid geometry: ${lastExecutionError}`);
      execErr.errorCategory = 'JSCAD_EXECUTION_ERROR';
      attachTelemetryAndRethrow(execErr);
    }
  }

  // ---------------------------------------------------------------------------
  // Stage 3 & 4: Closed Verification Loop with Measured Feedback & Targeted Semantic Repair
  // ---------------------------------------------------------------------------
  const auditStartTime = Date.now();
  const effectiveFeatureModel = featureModel || revisionContext?.targetFeatureModel || revisionContext?.featureModel;

  let currentAudit = auditGeneratedGeometry(
    currentCode!,
    currentExec,
    requirements,
    effectiveFeatureModel,
    printer,
    {
      isRevision,
      priorAudit,
      priorFeatures,
    }
  );

  // Integrate physical prompt measurements feedback (dimensions, multi-part, hollowness, clearance)
  const measuredFlags = auditPromptPhysicalMeasurements(prompt, currentMeasurements!, currentExec, currentCode!, requirements);
  for (const mf of measuredFlags) {
    currentAudit.findings.push({
      id: `audit_measured_${mf.type}`,
      severity: 'blocking',
      category: mf.type === 'dimension' ? 'DIMENSIONAL_CONFORMANCE' : mf.type === 'part_count' ? 'PART_COUNT' : mf.type === 'clearance' ? 'REFERENCE_CLEARANCE' : 'PRINTABILITY',
      message: mf.message,
      expected: mf.expected,
      actual: mf.actual,
      suggestedFix: mf.type === 'dimension'
        ? 'Adjust top-level dimension constants to match prompt dimensions.'
        : mf.type === 'part_count'
        ? 'Implement multi-part ABI with kpPart_*() and getParts() returning array of parts.'
        : mf.type === 'clearance'
        ? `Update clearance constant to match printer calibration (${typeof (requirements as any)?.matingClearanceMm === 'number' ? (requirements as any).matingClearanceMm.toFixed(2) : '0.25'}mm).`
        : 'Subtract() inner cavity/reservoir so object is hollow with appropriate wall thickness.',
    });
  }

  const blockingFindings = currentAudit.findings.filter((f) => f.severity === 'blocking');
  if (blockingFindings.length === 0 && currentAudit.passed) {
    return {
      code: currentCode!,
      measurements: currentMeasurements!,
      repairAttempts: stage1ExecutionRepairs,
      requestRecords,
      modelsUsed: Array.from(modelsUsedSet),
      totalModelCalls,
      auditFindings: currentAudit.findings,
      auditScore: currentAudit.score,
      auditCycles: 0,
      auditDurationMs: Date.now() - auditStartTime,
      auditPassed: true,
    };
  }

  // Stage 4: Targeted Measured Semantic Repair (strictly 1 cycle when defects are raised)
  let auditCyclesCount = 0;
  const candidates: Array<{
    code: string;
    measurements: GeometryMeasurements;
    audit: GeometryAuditResult;
    score: number;
    blockingCount: number;
  }> = [
    {
      code: currentCode!,
      measurements: currentMeasurements!,
      audit: currentAudit,
      score: currentAudit.score,
      blockingCount: currentAudit.findings.filter((f) => f.severity === 'blocking').length,
    },
  ];

  for (let cycle = 1; cycle <= 1; cycle++) {
    auditCyclesCount = cycle;
    const blockingAndWarnings = currentAudit.findings.filter(
      (f) => f.severity === 'blocking' || f.severity === 'warning'
    );
    if (blockingAndWarnings.length === 0) {
      break;
    }

    // Budget guard: if we've already spent more than 45s or if the model already runs and has no blocking errors, do not risk a timeout
    const elapsedSoFar = Date.now() - auditStartTime;
    const hasOnlyWarnings = !blockingAndWarnings.some((f) => f.severity === 'blocking');
    if (elapsedSoFar > 45000 || hasOnlyWarnings) {
      console.log(`[JSCAD Semantic Audit] Skipping extra precision correction pass (elapsed: ${elapsedSoFar}ms, only warnings: ${hasOnlyWarnings}) to preserve fast turnaround.`);
      break;
    }

    console.warn(`[JSCAD Semantic Audit] Cycle ${cycle}/1: ${blockingAndWarnings.length} findings detected. Launching targeted precision correction...`);

    const defectReport = blockingAndWarnings
      .map((f, idx) => {
        return `${idx + 1}. [${f.severity.toUpperCase()}] ${f.category}: ${f.message}\n   - Expected: ${f.expected}\n   - Actual: ${f.actual}\n   - Suggested Fix: ${f.suggestedFix}`;
      })
      .join('\n\n');

    const repairSystemInstruction = `You are a precision mechanical CAD engineer performing a targeted ONE-PASS correction on @jscad/modeling (version 2.x) JavaScript code.

STRICT TARGETED REPAIR RULES:
1. FIX ONLY THE LISTED DEFECTS in the defect report.
2. PRESERVE EVERY OTHER CONSTANT, WRAPPER FUNCTION, AND FEATURE.
3. PRESERVE TOP-LEVEL EDITABLE NUMERIC CONSTANTS:
   - Keep all constants declared at the top of the file with numeric literal values (e.g. const width = 80.0;).
   - If a dimension defect requires changing a constant value, update that numeric constant directly.
4. PRESERVE WORLD-SPACE WRAPPER ABI:
   - Keep every kpFeature_<id>() wrapper returning geometry positioned in final coordinates.
   - Do NOT wrap kpFeature_*() calls in outer translates/rotates inside main().
5. PRESERVE MULTI-PIECE ARCHITECTURE:
   - If the design has separate printable parts, keep getParts() returning unique part objects. Never fuse separate printable pieces.
6. BASE PLANE AT Z=0:
   - Ensure the entire assembled solid sits at Z >= 0 with the bottom surface at minimum Z = 0.00.
7. Return ONLY executable @jscad/modeling JavaScript.`;

    const repairPrompt = `TARGETED CAD AUDIT CORRECTION (Cycle ${cycle}/1):
The current geometry executed successfully but failed the following deterministic engineering audit checks:

${defectReport}

CURRENT CODE:
\`\`\`js
${currentCode}
\`\`\`

USER REQUIREMENTS & SPECIFICATIONS:
${JSON.stringify(requirements, null, 2)}

Instructions:
Review the specific defect findings above. Fix ONLY the reported defects (adjust dimensions, position Z min at 0, ensure all kpFeature_* wrappers are declared and called, ensure top-level constants are present, verify getParts() or part fit).
Return ONLY the corrected, executable @jscad/modeling JavaScript code.`;

    let repairResult: GeminiCallResult;
    const remainingTimeForAudit = Math.max(35000, 100000 - elapsedSoFar);
    try {
      repairResult = await callGeminiWithResilience(ai, {
        purpose: 'precision_correction',
        contents: repairPrompt,
        config: {
          systemInstruction: repairSystemInstruction,
        },
        timeoutMs: remainingTimeForAudit,
        enableThinking: true,
        requestId,
      });
    } catch (err: any) {
      console.warn(`[JSCAD Semantic Audit] Cycle ${cycle} API call failed:`, err);
      break;
    }

    totalModelCalls += repairResult.attempts;
    repairResult.requestRecords.forEach((r) => {
      modelsUsedSet.add(r.model);
      requestRecords.push(r);
    });

    const repairedCode = extractAndValidateJscad(repairResult.text);
    if (repairedCode) {
      const reservedCheck = validateReservedBuilderUsage(repairedCode);
      if (!reservedCheck) {
        const repairedExec = executeJscadServerSide(repairedCode);
        if (repairedExec.success && repairedExec.measurements && repairedExec.measurements.isNonEmpty) {
          const repairedAudit = auditGeneratedGeometry(
            repairedCode,
            repairedExec,
            requirements,
            effectiveFeatureModel,
            printer,
            {
              isRevision,
              priorAudit,
              priorFeatures,
            }
          );

          const repairedMeasuredFlags = auditPromptPhysicalMeasurements(prompt, repairedExec.measurements, repairedExec, repairedCode, requirements);
          for (const mf of repairedMeasuredFlags) {
            repairedAudit.findings.push({
              id: `audit_repaired_measured_${mf.type}`,
              severity: 'blocking',
              category: mf.type === 'dimension' ? 'DIMENSIONAL_CONFORMANCE' : mf.type === 'part_count' ? 'PART_COUNT' : mf.type === 'clearance' ? 'REFERENCE_CLEARANCE' : 'PRINTABILITY',
              message: mf.message,
              expected: mf.expected,
              actual: mf.actual,
              suggestedFix: mf.type === 'dimension'
                ? 'Adjust top-level dimension constants to match prompt dimensions.'
                : mf.type === 'part_count'
                ? 'Implement multi-part ABI with kpPart_*() and getParts() returning array of parts.'
                : mf.type === 'clearance'
                ? `Update clearance constant to match printer calibration (${typeof (requirements as any)?.matingClearanceMm === 'number' ? (requirements as any).matingClearanceMm.toFixed(2) : '0.25'}mm).`
                : 'Subtract() inner cavity/reservoir so object is hollow with appropriate wall thickness.',
            });
          }

          const blockingCount = repairedAudit.findings.filter((f) => f.severity === 'blocking').length;
          candidates.push({
            code: repairedCode,
            measurements: repairedExec.measurements,
            audit: repairedAudit,
            score: repairedAudit.score,
            blockingCount,
          });

          if (repairedAudit.passed && blockingCount === 0) {
            currentCode = repairedCode;
            currentMeasurements = repairedExec.measurements;
            currentAudit = repairedAudit;
            break;
          } else {
            currentCode = repairedCode;
            currentExec = repairedExec;
            currentMeasurements = repairedExec.measurements;
            currentAudit = repairedAudit;
          }
        }
      }
    }
  }

  // Stage 5: Select the best candidate (highest score, lowest blocking count)
  candidates.sort((a, b) => {
    if (a.blockingCount !== b.blockingCount) return a.blockingCount - b.blockingCount;
    return b.score - a.score;
  });

  const best = candidates[0];
  return {
    code: best.code,
    measurements: best.measurements,
    repairAttempts: stage1ExecutionRepairs + auditCyclesCount,
    requestRecords,
    modelsUsed: Array.from(modelsUsedSet),
    totalModelCalls,
    auditFindings: best.audit.findings,
    auditScore: best.score,
    auditCycles: auditCyclesCount,
    auditDurationMs: Date.now() - auditStartTime,
    auditPassed: best.audit.passed,
  };
}



export function registerGenerate(app: Express) {
app.post('/api/generate-jscad', async (req, res) => {
  const {
    prompt,
    requestId,
    useTemplate,
    requirements,
    simplifyToParametric,
    mode,
    featureModel,
    designSpecification,
    designChecklist,
    referenceImages,
    userOverrides,
    printer,
    filament,
    examples,
  } = req.body;
  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({
      error: 'Prompt is required',
      errorCategory: 'INVALID_REQUEST',
      statusCode: 400,
    });
  }

  if (requestId) {
    updateGenerationStatus(requestId, {
      model: PRIMARY_MODEL,
      attempt: 1,
      thinkingLevel: 'medium',
      phase: 'designing',
      startTime: Date.now(),
    });
  }

  const startTime = Date.now();
  const generationId = `gen_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

  // Explicit template mode request
  if (useTemplate) {
    const code = synthesizeOfflineJscad(prompt);
    const execTest = executeJscadServerSide(code);
    return res.json({
      code,
      source: 'template',
      generationId,
      requirements: requirements || {
        objectName: 'Template Model',
        classification: 'parametric',
        units: 'mm',
        overallDimensions: { width: 100, depth: 60, height: 25 },
        features: ['Template preset model'],
        quantities: {},
        spatialArrangements: [],
        printConsiderations: ['Base flat at Z=0'],
        warnings: [],
      },
      diagnostics: {
        generationId,
        timestamp: Date.now(),
        modelUsed: 'template-library',
        modelsUsed: ['template-library'],
        aiCallsMade: 0,
        repairAttempts: 0,
        latencyMs: Date.now() - startTime,
        measuredDimensions: execTest.measurements?.dimensions,
        measuredVolumeMm3: execTest.measurements?.actualVolumeMm3 ?? execTest.measurements?.volumeMm3,
        polygonCount: execTest.measurements?.polygonCount,
        triangleCount: execTest.measurements?.triangleCount,
        vertexCount: execTest.measurements?.vertexCount,
        isManifold: execTest.measurements?.isManifold,
        nonManifoldEdgeCount: execTest.measurements?.nonManifoldEdgeCount,
      },
      validationReport: {
        items: [
          {
            id: 'template_notice',
            label: 'Template Mode (Explicit Selection)',
            status: 'warning',
            detail: 'Synthesized from standard mechanical template library',
            requirementText: prompt,
            verificationSource: 'user-assumption',
          },
        ],
        overallScore: null,
        passed: true,
        verdict: 'PARTIALLY_VERIFIED',
        summary: 'Template model loaded directly by user selection.',
        missingFeatures: [],
        warnings: ['This is a parametric template model.'],
      },
    });
  }

  // If AI is not configured, return clear AUTH_ERROR
  const ai = getGeminiClient();
  if (!ai) {
    return res.status(401).json({
      error: 'Invalid or missing Gemini API credential.',
      errorCategory: 'AUTH_ERROR',
      technicalDetails: 'GEMINI_API_KEY environment variable is not configured.',
      statusCode: 401,
      canSimplifyToParametric: false,
    });
  }

  try {
    // Stage 1: Extract Requirements if not provided
    const hasImages = Array.isArray(referenceImages) && referenceImages.length > 0;
    const intakeRan = !requirements && hasImages;
    let intakeRecords: AIRequestRecord[] = [];
    let intakeModels: string[] = [];
    let intakeCalls = 0;

    let reqs = requirements;
    if (!reqs) {
      if (hasImages) {
        const extracted = await extractRequirements(prompt, ai, referenceImages);
        reqs = extracted.requirements;
        intakeRecords = extracted.aiMetadata?.requestRecords || [];
        intakeModels = extracted.aiMetadata?.modelsUsed || [];
        intakeCalls = extracted.aiMetadata?.totalModelCalls || intakeRecords.length || 0;
      } else {
        reqs = buildTextOnlyRequirements(prompt, printer, filament);
      }
    }

    if (reqs && reqs.matingClearanceMm === undefined) {
      reqs.matingClearanceMm = typeof printer?.measuredClearanceMm === 'number' ? printer.measuredClearanceMm : 0.25;
    }

    // Route all requests to parametric CAD / relief builders without unconfigured provider errors
    if (reqs.isOrganicOnly || reqs.classification === 'organic' || reqs.classification === 'hybrid') {
      reqs.isOrganicOnly = false;
      reqs.classification = 'parametric';
    }

    // Stage 2: CAD Generation with Server Execution Self-Repair (Throws on failure)
    const genResult = await generateAndRepairJscad({
      prompt,
      requirements: reqs,
      ai,
      isRevision: false,
      mode,
      featureModel,
      designSpecification,
      designChecklist,
      referenceImages,
      userOverrides,
      printer,
      requestId,
      examples,
    });

    const mergedRequestRecords = [...intakeRecords, ...genResult.requestRecords];
    const mergedModelsUsed = Array.from(new Set([...intakeModels, ...genResult.modelsUsed]));
    const totalCalls = intakeCalls + genResult.totalModelCalls;

    console.log(`[gen] model calls: ${totalCalls} (intake: ${intakeRan ? 'ran' : 'skipped'})`);

    const latencyMs = Date.now() - startTime;
    const actualModelUsed = getLastSuccessfulModel(mergedRequestRecords);

    const validationItems = [
      {
        id: 'manifold_check',
        label: 'Closed Watertight Mesh',
        status: genResult.measurements?.isManifold ? ('verified' as const) : ('warning' as const),
        detail: genResult.measurements?.isManifold ? 'Manifold geometry' : 'Non-manifold edges detected',
        requirementText: 'Mesh must be closed',
        verificationSource: 'geometry' as const,
      },
      ...genResult.auditFindings.map((f) => ({
        id: f.id,
        label: f.category.replace(/_/g, ' '),
        status: f.severity === 'blocking' ? ('failed' as const) : f.severity === 'warning' ? ('warning' as const) : ('verified' as const),
        detail: f.message,
        requirementText: f.expected,
        verificationSource: 'geometry' as const,
      })),
    ];

    return res.json({
      code: genResult.code,
      source: 'ai',
      generationId,
      requirements: reqs,
      diagnostics: {
        generationId,
        timestamp: Date.now(),
        modelUsed: actualModelUsed,
        modelsUsed: mergedModelsUsed,
        requestRecords: mergedRequestRecords,
        aiCallsMade: totalCalls,
        repairAttempts: genResult.repairAttempts,
        latencyMs,
        measuredDimensions: genResult.measurements?.dimensions,
        measuredVolumeMm3: genResult.measurements?.actualVolumeMm3 ?? genResult.measurements?.volumeMm3,
        polygonCount: genResult.measurements?.polygonCount,
        triangleCount: genResult.measurements?.triangleCount,
        vertexCount: genResult.measurements?.vertexCount,
        isManifold: genResult.measurements?.isManifold,
        nonManifoldEdgeCount: genResult.measurements?.nonManifoldEdgeCount,
        auditScore: genResult.auditScore,
        auditFindings: genResult.auditFindings,
        auditCycles: genResult.auditCycles,
        auditDurationMs: genResult.auditDurationMs,
        auditPassed: genResult.auditPassed,
      },
      validationReport: {
        items: validationItems,
        overallScore: Math.round(genResult.auditScore * 100),
        passed: genResult.auditPassed,
        verdict: genResult.auditPassed ? 'VERIFIED' : genResult.auditScore >= 0.7 ? 'PARTIALLY_VERIFIED' : 'FAILED',
        summary: genResult.auditPassed
          ? 'CAD geometry compiled and passed all deterministic engineering audit checks.'
          : `CAD geometry compiled with ${genResult.auditFindings.length} audit observation(s).`,
        missingFeatures: genResult.auditFindings
          .filter((f) => f.category === 'FEATURE_PRESENCE')
          .map((f) => f.message),
        warnings: genResult.auditFindings.map((f) => f.message),
      },
    });

    if (requestId) {
      updateGenerationStatus(requestId, {
        phase: 'completed',
      });
    }
  } catch (err: any) {
    console.error('Error generating JSCAD code:', err);
    const cleaned = cleanErrorMessage(err);
    return res.status(cleaned.statusCode).json({
      error: cleaned.message,
      errorCategory: cleaned.errorCategory,
      technicalDetails: cleaned.technicalDetails,
      statusCode: cleaned.statusCode,
      diagnostics: getErrorDiagnostics(err),
      canSimplifyToParametric:
        cleaned.errorCategory === 'ORGANIC_UNCONFIGURED' ||
        cleaned.errorCategory === 'HYBRID_UNCONFIGURED',
    });
  }
});

}
