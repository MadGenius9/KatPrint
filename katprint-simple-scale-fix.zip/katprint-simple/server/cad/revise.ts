import type { Express } from "express";
import type { GoogleGenAI } from "@google/genai";
import type {
  ProjectReferenceImage,
  PrinterSpec,
  FilamentSpec,
  DesignSpecification,
  DesignCheck,
  RevisionIntent,
  SemanticFeaturePlan,
  ProjectDesignState,
} from "../../src/types";
import type {
  SemanticFeatureModel,
  FeatureParameter,
} from "../../src/features/featureTypes";
import type { RevisionContextPayload } from "../../src/services/geminiService";
import { RevisionIntentSchema } from "../../src/ai/schemas";
import {
  getGeminiClient,
  callGeminiWithResilience,
  cleanErrorMessage,
  getErrorDiagnostics,
  getLastSuccessfulModel,
  updateGenerationStatus,
  PRIMARY_MODEL,
  AIRequestRecord,
  GeminiCallResult,
} from "../gemini/client";
import {
  extractAndValidateJscad,
  executeJscadServerSide,
  measureJscadSolids,
  validateCodeSecurity as validateCadCodeSecurity,
  GeometryMeasurements,
} from "./sandbox";
import {
  auditGeneratedGeometry,
  AuditFinding,
  GeometryAuditResult,
} from "./audit";
import {
  validateReservedBuilderUsage,
  FEATURE_BUILDER_REGISTRY,
} from "../../src/features/featureGenerators";
import {
  formatMatingClearanceContext,
  getFeatureBuilderPromptDocs,
  appendReferenceImagesToContents,
} from "./shared";
import { generateAndRepairJscad } from "./generate";

export async function interpretRevisionIntentAI(
  ai: GoogleGenAI,
  options: {
    instruction: string;
    currentCode: string;
    currentFeatureModel: SemanticFeatureModel;
    currentDesignState?: ProjectDesignState;
    recentConversation?: any[];
  }
): Promise<{
  revisionIntent: RevisionIntent;
  targetFeatureModel?: SemanticFeatureModel;
  aiMetadata: {
    modelUsed: string;
    modelsUsed: string[];
    totalModelCalls: number;
    requestRecords: AIRequestRecord[];
    durationMs: number;
  };
}> {
  const { instruction, currentCode, currentFeatureModel, currentDesignState, recentConversation } = options;
  const startTime = Date.now();
  const requestRecords: AIRequestRecord[] = [];
  const modelsUsedSet = new Set<string>();

  const systemInstruction = `You are an expert Mechanical CAD Revision Interpreter.
Your job is to analyze the user's natural language modification request against an existing 3D model and its Semantic Feature Model.

Analyze precisely:
1. Intent Type: 'parameter_edit', 'feature_add', 'feature_remove', 'feature_move', 'feature_replace', 'style_change', 'structural_redesign', or 'part_structure_change'.
2. Which feature IDs are being targeted for change.
3. Which feature IDs and constraints must be strictly preserved.
4. Specific numeric dimension changes (from -> to).
5. Whether CAD regeneration/modification is required (true) or if it's purely conversational.
6. Confidence score (0.0 to 1.0):
   - >= 0.80: Clear, unambiguous revision instruction.
   - 0.55 - 0.79: Plausible but has assumptions or ambiguities that benefit from cross-checking.
   - < 0.55: Ambiguous, unclear, or conflicting instruction requiring user clarification.

Return JSON conforming to the RevisionIntent schema.`;

  const promptText = `USER REVISION INSTRUCTION: "${instruction}"

CURRENT SEMANTIC FEATURE MODEL:
${JSON.stringify(currentFeatureModel, null, 2)}

CURRENT DESIGN STATE CONSTRAINTS:
${JSON.stringify(currentDesignState || {}, null, 2)}

RECENT CONVERSATION:
${JSON.stringify((recentConversation || []).slice(-4), null, 2)}

Provide the structured RevisionIntent JSON.`;

  const result = await callGeminiWithResilience(ai, {
    purpose: 'revision_interpretation',
    contents: [{ text: promptText }],
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: RevisionIntentSchema,
    },
    enableThinking: true,
  });

  result.requestRecords.forEach((r) => {
    modelsUsedSet.add(r.model);
    requestRecords.push(r);
  });

  let revisionIntent: RevisionIntent;
  try {
    const text = result.text.trim().replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
    revisionIntent = JSON.parse(text);
  } catch (err) {
    revisionIntent = {
      intentType: 'parameter_edit',
      targetFeatureIds: [],
      requestedChanges: [{ feature: 'Model', change: instruction }],
      preserveFeatureIds: currentFeatureModel.features.map((f) => f.id),
      preserveConstraints: ['Minimum Wall Thickness'],
      requiresCadRegeneration: true,
      confidence: 0.8,
      interpretation: instruction,
    };
  }

  return {
    revisionIntent,
    aiMetadata: {
      modelUsed: result.model,
      modelsUsed: Array.from(modelsUsedSet),
      totalModelCalls: result.attempts,
      requestRecords,
      durationMs: Date.now() - startTime,
    },
  };
}



// ---------------------------------------------------------------------------
// Revision Requirements Updater (Preserves Previous Constraints)
// ---------------------------------------------------------------------------
async function updateRequirementsForRevision(
  originalPrompt: string,
  revisionPrompt: string,
  previousRequirements: any,
  ai: GoogleGenAI
): Promise<{
  requirements: any;
  requestRecords: AIRequestRecord[];
  modelsUsed: string[];
  totalModelCalls: number;
}> {
  const systemInstruction = `You are a precision CAD specification engineer managing parametric revisions.
TASK:
1. Update technical requirements based on the user's revision prompt: "${revisionPrompt}".
2. PRESERVE EVERY PREVIOUS REQUIREMENT (dimensions, holes, slots, features, hardware, referenceObject) that was NOT explicitly modified or removed by the user.
3. Modify only the properties affected by the revision.
4. Update "designDecisions" and "suggestedImprovements" to match the new state.

Output ONLY valid JSON matching the ExtractedRequirements schema.`;

  try {
    const geminiRes = await callGeminiWithResilience(ai, {
      purpose: 'design_reasoning',
      contents: `Original Base Prompt: "${originalPrompt}"
Previous Specifications:
${JSON.stringify(previousRequirements || {}, null, 2)}

User Revision Request: "${revisionPrompt}"

Update the technical requirements while preserving all untouched features and reference object constraints.`,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(geminiRes.text);
    if (!parsed.referenceObject && previousRequirements?.referenceObject) {
      parsed.referenceObject = previousRequirements.referenceObject;
    }
    return {
      requirements: parsed,
      requestRecords: geminiRes.requestRecords,
      modelsUsed: Array.from(new Set(geminiRes.requestRecords.map((r) => r.model))),
      totalModelCalls: geminiRes.attempts,
    };
  } catch (err: any) {
    console.warn('Revision requirements update fallback:', err);
    return {
      requirements: {
        ...(previousRequirements || {}),
        features: [
          ...(previousRequirements?.features || []),
          `Revision: ${revisionPrompt}`,
        ],
        explicitRequirements: [
          ...(previousRequirements?.explicitRequirements || []),
          revisionPrompt,
        ],
        designDecisions: [
          ...(previousRequirements?.designDecisions || []),
          `Applied revision: ${revisionPrompt}`,
        ],
      },
      requestRecords: err?.requestRecords || [],
      modelsUsed: err?.modelsUsed || [],
      totalModelCalls: err?.totalModelCalls || (err?.requestRecords?.length ?? 0),
    };
  }
}



export function registerRevise(app: Express) {
// -------------------------------------------------------------
app.post('/api/interpret-revision', async (req, res) => {
  const {
    instruction,
    currentCode,
    currentFeatureModel,
    currentDesignState,
    recentConversation = [],
  } = req.body;

  if (!instruction || typeof instruction !== 'string') {
    return res.status(400).json({
      error: 'Revision instruction is required',
      errorCategory: 'INVALID_REQUEST',
      statusCode: 400,
    });
  }

  const ai = getGeminiClient();
  if (!ai) {
    return res.status(401).json({
      error: 'Invalid or missing Gemini API credential.',
      errorCategory: 'AUTH_ERROR',
      technicalDetails: 'GEMINI_API_KEY environment variable is not set.',
      statusCode: 401,
    });
  }

  try {
    const result = await interpretRevisionIntentAI(ai, {
      instruction,
      currentCode: currentCode || '',
      currentFeatureModel: currentFeatureModel || { features: [], constraints: [] },
      currentDesignState,
      recentConversation,
    });

    return res.json({
      revisionIntent: result.revisionIntent,
      diagnostics: {
        modelUsed: result.aiMetadata.modelUsed,
        modelsUsed: result.aiMetadata.modelsUsed,
        aiCallsMade: result.aiMetadata.totalModelCalls,
        requestRecords: result.aiMetadata.requestRecords,
        durationMs: result.aiMetadata.durationMs,
      },
    });
  } catch (err: any) {
    console.error('Interpret revision error:', err);
    const cleaned = cleanErrorMessage(err);
    return res.status(cleaned.statusCode).json({
      error: cleaned.message,
      errorCategory: cleaned.errorCategory,
      technicalDetails: cleaned.technicalDetails,
      statusCode: cleaned.statusCode,
      diagnostics: getErrorDiagnostics(err),
    });
  }
});



// POST /api/revise-jscad
// -------------------------------------------------------------
app.post('/api/revise-jscad', async (req, res) => {
  const {
    originalPrompt,
    revisionHistory,
    currentCode,
    revisionPrompt,
    userInstruction,
    previousRequirements,
    revisionContext,
    mode,
    featureModel,
    designSpecification,
    designChecklist,
    referenceImages,
    printer,
    priorAudit,
    priorFeatures,
    requestId,
  } = req.body;

  if (requestId) {
    updateGenerationStatus(requestId, {
      model: PRIMARY_MODEL,
      attempt: 1,
      thinkingLevel: 'medium',
      phase: 'designing',
      startTime: Date.now(),
    });
  }

  const actualPrompt = revisionPrompt || userInstruction;
  if (!currentCode || !actualPrompt) {
    return res.status(400).json({
      error: 'currentCode and revisionPrompt/userInstruction are required',
      errorCategory: 'INVALID_REQUEST',
      statusCode: 400,
    });
  }

  const startTime = Date.now();
  const generationId = `gen_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

  const ai = getGeminiClient();
  if (!ai) {
    return res.status(401).json({
      error: 'Invalid or missing Gemini API credential.',
      errorCategory: 'AUTH_ERROR',
      technicalDetails: 'GEMINI_API_KEY environment variable is not configured.',
      statusCode: 401,
    });
  }

  try {
    let updatedReqs = revisionContext?.designSpecification || designSpecification;
    let updateReqsRecords: AIRequestRecord[] = [];
    let updateReqsModels: string[] = [];
    let updateReqsCalls = 0;

    // If no structured spec provided or confidence is low, fall back to AI requirement update
    if (!updatedReqs || !updatedReqs.primaryObject) {
      const updateRes = await updateRequirementsForRevision(
        originalPrompt || actualPrompt,
        actualPrompt,
        previousRequirements,
        ai
      );
      updatedReqs = updateRes.requirements;
      updateReqsRecords = updateRes.requestRecords;
      updateReqsModels = updateRes.modelsUsed;
      updateReqsCalls = updateRes.totalModelCalls;
    }

    if (updatedReqs && updatedReqs.matingClearanceMm === undefined) {
      updatedReqs.matingClearanceMm = typeof printer?.measuredClearanceMm === 'number' ? printer.measuredClearanceMm : 0.25;
    }

    const effectiveFeatureModel = revisionContext?.featureModel || featureModel;
    const effectiveSpec = revisionContext?.designSpecification || designSpecification || updatedReqs;

    const genResult = await generateAndRepairJscad({
      prompt: actualPrompt,
      requirements: updatedReqs,
      ai,
      isRevision: true,
      previousCode: currentCode,
      revisionContext,
      mode,
      featureModel: effectiveFeatureModel,
      designSpecification: effectiveSpec,
      designChecklist,
      referenceImages,
      printer,
      priorAudit,
      priorFeatures,
      requestId,
    });

    const mergedRequestRecords = [...updateReqsRecords, ...genResult.requestRecords];
    const mergedModelsUsed = Array.from(new Set([...updateReqsModels, ...genResult.modelsUsed]));
    const mergedTotalCalls = updateReqsCalls + genResult.totalModelCalls;

    const latencyMs = Date.now() - startTime;
    const actualModelUsed = getLastSuccessfulModel(mergedRequestRecords);

    const validationItems = [
      {
        id: 'manifold_check',
        label: 'Closed Watertight Mesh',
        status: genResult.measurements?.isManifold ? ('verified' as const) : ('warning' as const),
        detail: genResult.measurements?.isManifold ? 'Manifold geometry' : 'Non-manifold edges detected',
        requirementText: 'Mesh must be closed',
        verificationSource: 'geometry' as const,
      },
      ...genResult.auditFindings.map((f) => ({
        id: f.id,
        label: f.category.replace(/_/g, ' '),
        status: f.severity === 'blocking' ? ('failed' as const) : f.severity === 'warning' ? ('warning' as const) : ('verified' as const),
        detail: f.message,
        requirementText: f.expected,
        verificationSource: 'geometry' as const,
      })),
    ];

    return res.json({
      code: genResult.code,
      source: 'ai',
      generationId,
      requirements: updatedReqs,
      diagnostics: {
        generationId,
        timestamp: Date.now(),
        modelUsed: actualModelUsed,
        modelsUsed: mergedModelsUsed,
        requestRecords: mergedRequestRecords,
        aiCallsMade: mergedTotalCalls,
        repairAttempts: genResult.repairAttempts,
        latencyMs,
        measuredDimensions: genResult.measurements?.dimensions,
        measuredVolumeMm3: genResult.measurements?.actualVolumeMm3 ?? genResult.measurements?.volumeMm3,
        polygonCount: genResult.measurements?.polygonCount,
        triangleCount: genResult.measurements?.triangleCount,
        vertexCount: genResult.measurements?.vertexCount,
        isManifold: genResult.measurements?.isManifold,
        nonManifoldEdgeCount: genResult.measurements?.nonManifoldEdgeCount,
        auditScore: genResult.auditScore,
        auditFindings: genResult.auditFindings,
        auditCycles: genResult.auditCycles,
        auditDurationMs: genResult.auditDurationMs,
        auditPassed: genResult.auditPassed,
      },
      validationReport: {
        items: validationItems,
        overallScore: Math.round(genResult.auditScore * 100),
        passed: genResult.auditPassed,
        verdict: genResult.auditPassed ? 'VERIFIED' : genResult.auditScore >= 0.7 ? 'PARTIALLY_VERIFIED' : 'FAILED',
        summary: genResult.auditPassed
          ? 'Revised CAD geometry compiled and verified with zero audit defects.'
          : `Revised CAD geometry compiled with ${genResult.auditFindings.length} audit observation(s).`,
        missingFeatures: genResult.auditFindings
          .filter((f) => f.category === 'FEATURE_PRESENCE')
          .map((f) => f.message),
        warnings: genResult.auditFindings.map((f) => f.message),
      },
    });

    if (requestId) {
      updateGenerationStatus(requestId, {
        phase: 'completed',
      });
    }
  } catch (err: any) {
    console.error('Error revising JSCAD model:', err);
    const cleaned = cleanErrorMessage(err);
    return res.status(cleaned.statusCode).json({
      error: cleaned.message,
      errorCategory: cleaned.errorCategory,
      technicalDetails: cleaned.technicalDetails,
      statusCode: cleaned.statusCode,
      diagnostics: getErrorDiagnostics(err),
    });
  }
});



// -------------------------------------------------------------
// POST /api/targeted-repair (Targeted 1-Pass Precision Repair)
// -------------------------------------------------------------
app.post('/api/targeted-repair', async (req, res) => {
  const {
    originalPrompt,
    currentCode,
    specification,
    reviewResult,
    deterministicChecks,
    geometryStats,
    featureModel,
    bindingValidation,
    lockedParameterIds,
    repairStrategy = 'targeted',
  } = req.body;
  if (!currentCode) {
    return res.status(400).json({ error: 'currentCode is required for targeted repair' });
  }

  const startTime = Date.now();
  const generationId = `gen_repair_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

  const ai = getGeminiClient();
  if (!ai) {
    return res.status(401).json({
      error: 'Invalid or missing Gemini API credential.',
      errorCategory: 'AUTH_ERROR',
      statusCode: 401,
    });
  }

  try {
    const problemsList = [...(reviewResult?.problems || [])];

    // Include failed critical deterministic checks in problemsList
    if (deterministicChecks && Array.isArray(deterministicChecks)) {
      deterministicChecks.forEach((chk: any) => {
        if (chk.status === 'failed' || chk.status === 'FAIL' || chk.passed === false) {
          problemsList.push({
            severity: chk.importance || chk.severity || 'CRITICAL',
            requirement: `Deterministic Check: ${chk.description || chk.title || chk.requirement || chk.id}`,
            issue: chk.notes || chk.failureReason || `Deterministic check failed (Expected: ${chk.expected}, Actual: ${chk.actual ?? 'unmatched'})`,
            recommendedCorrection: chk.expected !== undefined ? `Adjust geometry so dimension/feature satisfies: ${chk.expected}` : 'Correct geometric dimensions and features to satisfy check',
          });
        }
      });
    }

    function formatParamLiteral(val: any): string {
      if (typeof val === 'string') return JSON.stringify(val);
      if (typeof val === 'boolean') return String(val);
      if (typeof val === 'number') return Number.isFinite(val) ? String(val) : '0';
      if (val === undefined || val === null) return '0';
      return JSON.stringify(val);
    }

    // Add binding validation issues with exact missing constant values and expected builders
    if (bindingValidation) {
      if (Array.isArray(bindingValidation.criticalUnboundParameters) && bindingValidation.criticalUnboundParameters.length > 0) {
        bindingValidation.criticalUnboundParameters.forEach((paramId: string) => {
          const paramObj = featureModel?.parameters?.find((p: any) => p.id === paramId);
          const feat = featureModel?.features?.find((f: any) => f.id === paramObj?.featureId);
          const requiredConstName = paramObj?.jscadConstantName || paramObj?.name || paramId;
          const requiredValue = paramObj?.value !== undefined ? paramObj.value : 0;
          const formattedVal = formatParamLiteral(requiredValue);
          const unit = paramObj?.unit || 'mm';
          const isLocked = paramObj?.locked ? 'YES' : 'NO';

          problemsList.push({
            severity: 'CRITICAL',
            requirement: `Parameter Binding: ${paramObj?.name || paramId}`,
            issue: `Missing required top-level numeric constant \`const ${requiredConstName} = ...;\` for Feature: ${feat?.id || paramObj?.featureId || 'unknown'}, Parameter: ${paramObj?.name || paramId} (ID: ${paramId}). Required value: ${requiredValue} ${unit}, Locked: ${isLocked}.`,
            recommendedCorrection: `Declare \`const ${requiredConstName} = ${formattedVal};\` at the top level and use it in ${feat ? `kpFeature_${feat.id.replace(/[^a-zA-Z0-9_]/g, '_')}()` : 'geometry calculations'}.`,
          });
        });
      }

      if (Array.isArray(bindingValidation.missingBuilderFeatures) && bindingValidation.missingBuilderFeatures.length > 0) {
        bindingValidation.missingBuilderFeatures.forEach((featId: string) => {
          const feat = featureModel?.features?.find((f: any) => f.id === featId);
          const wrapperName = `kpFeature_${featId.replace(/[^a-zA-Z0-9_]/g, '_')}`;
          const builderSpec = feat?.type ? FEATURE_BUILDER_REGISTRY[feat.type] : undefined;
          const builderDesc = builderSpec
            ? `Required deterministic builder: ${builderSpec.builderName}`
            : 'Required standard builder or CSG operation';

          problemsList.push({
            severity: feat?.criticality === 'critical' ? 'CRITICAL' : 'IMPORTANT',
            requirement: `Feature Binding: ${feat?.label || feat?.name || featId}`,
            issue: `Feature: ${featId}. Required wrapper: \`${wrapperName}()\`. ${builderDesc}.`,
            recommendedCorrection: `Implement and call \`${wrapperName}()\` using ${builderSpec ? `\`${builderSpec.builderName}\`` : 'deterministic builders'} and combine in main().`,
          });
        });
      }
    }

    const problemsFormatted = problemsList
      .map(
        (p: any, idx: number) =>
          `${idx + 1}. [${p.severity || 'CRITICAL'}] ${p.requirement}: ${p.issue}. Suggested fix: ${p.recommendedCorrection || 'Fix geometry'}`
      )
      .join('\n');

    let lockedContext = '';
    const modelParams: FeatureParameter[] = featureModel?.parameters || [];
    const lockedIds = lockedParameterIds || modelParams.filter((p) => p.locked).map((p) => p.id);
    if (Array.isArray(lockedIds) && lockedIds.length > 0) {
      const lockedDetails = lockedIds.map((id: string) => {
        const p = modelParams.find((param) => param.id === id);
        return `- Parameter ID: ${id} | Semantic Name: ${p?.name || p?.semanticName || id} | Constant: const ${p?.jscadConstantName || p?.name || id} | Value: ${p?.value !== undefined ? p.value : 'N/A'} ${p?.unit || 'mm'}`;
      });
      lockedContext = `\nLOCKED SEMANTIC PARAMETERS (DO NOT CHANGE VALUES OF THESE CONSTANTS):\n${lockedDetails.join('\n')}\n`;
    }

    const builderDocs = getFeatureBuilderPromptDocs(featureModel?.features);

    const simplifyMode = repairStrategy === 'simplify';
    const systemInstruction = `You are a precision mechanical CAD engineer performing a ${simplifyMode ? 'ROBUST SIMPLIFICATION / RECOVERY PASS' : 'targeted ONE-PASS correction'} on existing @jscad/modeling code.

STRICT CORRECTION RULES:
1. PRESERVE EVERYTHING THAT ALREADY PASSES.
2. DO NOT redesign the model from scratch or replace working geometry.
3. Fix ONLY the specific reported problems and feature bindings identified in the design audit.
4. Maintain top-level named constants.
5. Implement clean feature wrapper functions (kpFeature_<featureId>) for bound features adhering strictly to the World-Space Selection ABI (positioning and orientation must be inside the wrapper, NO outer transforms in main()).
6. Preserve existing:
   - feature IDs
   - kpFeature_<featureId>() names
   - jscadConstantName values
   - parameter values
   - locked parameters
   - relationships
   - builder assignments
   unless the reported defect explicitly requires a change.
7. DO NOT redefine or re-declare reserved standard builder functions (createThroughHole, createCountersinkHole, createElongatedSlot, etc.).
8. PRESERVE MULTI-PIECE ABI if current code/request contains multiple printable pieces: keep kpPart_<id>(), getParts(), stable part metadata/quantities, and separate solids; do not fuse parts.
9. Return ONLY executable @jscad/modeling JavaScript preserving the original single-piece or multi-piece structure. No markdown commentary.
${simplifyMode ? `10. RECOVERY MODE: prefer robust parametric primitives and shallow, deterministic CSG over fragile decorative detail.
11. Preserve every critical dimension, opening, mating surface, hole, slot, clearance, and locked parameter. Simplify only non-critical geometry.
12. Reduce boolean depth and transform nesting when possible. Avoid tiny slivers, coplanar cuts, zero-thickness walls, and near-tangent operations.
13. If a cosmetic feature is causing invalid geometry, replace it with a simpler printable approximation rather than deleting a functional requirement.` : ''}

${builderDocs}`;

    let semanticRepairContext = '';
    if (featureModel) {
      semanticRepairContext += `
AUTHORITATIVE SEMANTIC FEATURE MODEL:
${JSON.stringify(featureModel, null, 2)}
`;
    }
    if (bindingValidation) {
      semanticRepairContext += `
CURRENT SEMANTIC BINDING VALIDATION:
${JSON.stringify(bindingValidation, null, 2)}
`;
    }

    const contentPrompt = `ORIGINAL USER REQUEST: "${originalPrompt}"

STRUCTURED DESIGN SPECIFICATION:
${JSON.stringify(specification || {}, null, 2)}
${semanticRepairContext}
${lockedContext}
${simplifyMode ? 'RECOVERY GOAL: rebuild the failing regions with simpler, more robust parametric construction while preserving critical requirements.\nPROBLEMS TO FIX:' : 'PROBLEMS TO FIX IN THIS ONE TARGETED PASS:'}
${problemsFormatted || 'Refine geometry features, feature bindings, and clearances.'}

CURRENT WORKING JSCAD CODE:
\`\`\`js
${currentCode}
\`\`\`

Perform the targeted correction and return the complete, repaired JSCAD script.`;

    const geminiRes = await callGeminiWithResilience(ai, {
      purpose: 'precision_correction',
      contents: contentPrompt,
      config: {
        systemInstruction,
      },
      enableThinking: true,
    });

    const cleanCode = extractAndValidateJscad(geminiRes.text);
    if (!cleanCode) {
      throw new Error('Repaired code did not contain a valid main() function declaration');
    }

    const reservedErr = validateReservedBuilderUsage(cleanCode);
    if (reservedErr) {
      throw new Error(`Repaired code validation error: ${reservedErr.message}`);
    }

    const execTest = executeJscadServerSide(cleanCode);
    if (!execTest.success || !execTest.measurements || !execTest.measurements.isNonEmpty) {
      throw new Error(`Repaired geometry execution failed: ${execTest.error || 'degenerate geometry'}`);
    }

    const latencyMs = Date.now() - startTime;
    const actualModelUsed = getLastSuccessfulModel(geminiRes.requestRecords) || geminiRes.model;
    const modelsUsed = Array.from(new Set(geminiRes.requestRecords.map((r: any) => r.model)));

    return res.json({
      code: cleanCode,
      source: 'ai',
      generationId,
      diagnostics: {
        generationId,
        timestamp: Date.now(),
        modelUsed: actualModelUsed,
        modelsUsed,
        requestRecords: geminiRes.requestRecords,
        aiCallsMade: geminiRes.attempts,
        repairAttempts: 1,
        latencyMs,
        measuredDimensions: execTest.measurements?.dimensions,
        measuredVolumeMm3: execTest.measurements?.actualVolumeMm3 ?? execTest.measurements?.volumeMm3,
        polygonCount: execTest.measurements?.polygonCount,
        triangleCount: execTest.measurements?.triangleCount,
        vertexCount: execTest.measurements?.vertexCount,
        isManifold: execTest.measurements?.isManifold,
        nonManifoldEdgeCount: execTest.measurements?.nonManifoldEdgeCount,
      },
      validationReport: {
        items: [
          {
            id: 'targeted_repair_pass',
            label: 'Targeted Precision Repair',
            status: 'verified',
            detail: `Corrected ${problemsList.length} reported design issue(s)`,
            verificationSource: 'ai-review',
            isHardRequirement: true,
          },
        ],
        overallScore: null,
        passed: true,
        verdict: 'VERIFIED',
        summary: `Targeted precision repair successfully applied for ${problemsList.length} issue(s).`,
        missingFeatures: [],
        warnings: [],
      },
    });
  } catch (err: any) {
    console.error('Targeted repair error:', err);
    const cleaned = cleanErrorMessage(err);
    return res.status(cleaned.statusCode).json({
      error: cleaned.message,
      errorCategory: cleaned.errorCategory,
      technicalDetails: cleaned.technicalDetails,
      statusCode: cleaned.statusCode,
      diagnostics: getErrorDiagnostics(err),
    });
  }
});


}
