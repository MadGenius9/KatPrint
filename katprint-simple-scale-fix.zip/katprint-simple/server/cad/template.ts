// ---------------------------------------------------------------------------
// Offline / Explicit Template Generator (Only when explicitly invoked)
// ---------------------------------------------------------------------------

export function synthesizeOfflineJscad(prompt: string): string {
  const p = prompt.toLowerCase();
  const numbers = prompt.match(/\d+(\.\d+)?/g)?.map(Number) || [];
  const primaryDim = numbers[0] || 120;
  const secondaryDim = numbers[1] || 80;
  const tertiaryDim = numbers[2] || 35;

  if (p.includes('planter') || p.includes('pot') || p.includes('plant')) {
    return `// Parametric Planter & Reservoir (Template)
// Key dimensions in millimeters (live editable)
const totalHeight = ${primaryDim >= 20 ? primaryDim : 130}.0;
const outerDiameter = ${secondaryDim >= 20 ? secondaryDim : 110}.0;
const wallThickness = 3.2;
const reservoirHeight = ${tertiaryDim >= 10 ? tertiaryDim : 30}.0;
const innerPotDiameter = outerDiameter - 18.0;
const drainageHoleDiameter = 6.0;

function main() {
  const outerRadius = outerDiameter / 2;
  const innerRadius = outerRadius - wallThickness;
  const potInnerRadius = innerPotDiameter / 2;
  
  const outerPot = cylinder({ radius: outerRadius, height: totalHeight, segments: 48 });
  const outerHollow = cylinder({ radius: innerRadius, height: totalHeight, segments: 48 });
  const outerShell = subtract(outerPot, translate([0, 0, wallThickness * 2], outerHollow));

  const basketHeight = totalHeight - reservoirHeight;
  const innerBasket = cylinder({ radius: potInnerRadius, height: basketHeight, segments: 48 });
  const innerCavity = cylinder({ radius: potInnerRadius - wallThickness, height: basketHeight + 10, segments: 48 });
  const basketShell = subtract(innerBasket, translate([0, 0, wallThickness * 1.5], innerCavity));

  const drainage = cylinder({ radius: drainageHoleDiameter / 2, height: wallThickness * 4, segments: 16 });
  const basketWithHoles = subtract(basketShell, translate([0, 0, -2], drainage));

  const assembly = union(outerShell, translate([0, 0, reservoirHeight], basketWithHoles));
  return translate([0, 0, totalHeight / 2], assembly);
}`;
  }

  if (p.includes('tray') || p.includes('organizer') || p.includes('dish') || p.includes('compartment')) {
    return `// Parametric Desk Organizer Tray (Parameterized Builder)
// Key dimensions in millimeters (live editable)
const trayLength = ${primaryDim >= 30 ? primaryDim : 140}.0;
const trayWidth = ${secondaryDim >= 30 ? secondaryDim : 90}.0;
const trayHeight = ${tertiaryDim >= 10 ? tertiaryDim : 25}.0;
const wallThickness = 2.4;
const floorThickness = 2.4;
const cornerRadius = 3.0;
const dividerThickness = 2.0;

function main() {
  const outer = roundedCuboid({
    size: [trayLength, trayWidth, trayHeight],
    roundRadius: cornerRadius,
    segments: 24
  });

  const innerL = (trayLength - (wallThickness * 2) - dividerThickness) / 2;
  const innerW = trayWidth - (wallThickness * 2);
  const cavityH = trayHeight;

  const compartment1 = roundedCuboid({
    size: [innerL, innerW, cavityH],
    roundRadius: Math.max(1, cornerRadius - 1),
    segments: 16
  });

  const compartment2 = roundedCuboid({
    size: [innerL, innerW, cavityH],
    roundRadius: Math.max(1, cornerRadius - 1),
    segments: 16
  });

  const posX1 = -innerL / 2 - (dividerThickness / 2);
  const posX2 = innerL / 2 + (dividerThickness / 2);
  const posZ = floorThickness;

  const cavities = union(
    translate([posX1, 0, posZ], compartment1),
    translate([posX2, 0, posZ], compartment2)
  );

  const tray = subtract(outer, cavities);
  return translate([0, 0, trayHeight / 2], tray);
}`;
  }

  if (p.includes('stand') || p.includes('cradle') || p.includes('dock') || p.includes('rest')) {
    return `// Parametric Device Stand (Parameterized Builder)
// Key dimensions in millimeters (live editable)
const standWidth = ${primaryDim >= 30 ? primaryDim : 75}.0;
const standDepth = ${secondaryDim >= 30 ? secondaryDim : 85}.0;
const standHeight = ${tertiaryDim >= 30 ? tertiaryDim : 70}.0;
const slotWidth = 14.0;
const lipHeight = 16.0;
const wallThickness = 4.0;
const cablePassDiameter = 12.0;

function main() {
  const base = cuboid({ size: [standWidth, standDepth, wallThickness] });
  const backWall = cuboid({ size: [standWidth, wallThickness, standHeight] });
  const angledBack = rotateX(-Math.PI / 8, backWall);
  const frontLip = cuboid({ size: [standWidth, wallThickness, lipHeight] });

  const structure = union(
    translate([0, 0, wallThickness / 2], base),
    translate([0, -standDepth / 4, standHeight / 2], angledBack),
    translate([0, standDepth / 2 - wallThickness / 2, lipHeight / 2], frontLip)
  );

  const cableHole = cylinder({ radius: cablePassDiameter / 2, height: wallThickness * 4, segments: 24 });
  const cleanStand = subtract(structure, translate([0, 0, 0], cableHole));
  return translate([0, 0, 0], cleanStand);
}`;
  }

  if (p.includes('holder') || p.includes('cup') || p.includes('caddy') || p.includes('pen') || p.includes('pencil')) {
    return `// Parametric Cylindrical Holder (Parameterized Builder)
// Key dimensions in millimeters (live editable)
const outerDiameter = ${primaryDim >= 30 ? primaryDim : 75}.0;
const totalHeight = ${secondaryDim >= 30 ? secondaryDim : 95}.0;
const wallThickness = 3.0;
const baseThickness = 3.0;

function main() {
  const outerRadius = outerDiameter / 2;
  const innerRadius = outerRadius - wallThickness;
  const outerCyl = cylinder({ radius: outerRadius, height: totalHeight, segments: 48 });
  const innerCyl = cylinder({ radius: innerRadius, height: totalHeight + 2, segments: 48 });
  const hollow = subtract(outerCyl, translate([0, 0, baseThickness], innerCyl));
  return translate([0, 0, totalHeight / 2], hollow);
}`;
  }

  if (p.includes('relief') || p.includes('lithophane') || p.includes('plaque') || p.includes('plate')) {
    return `// Parametric Framed Relief Plate (Parameterized Builder)
// Key dimensions in millimeters (live editable)
const plateWidth = ${primaryDim >= 30 ? primaryDim : 100}.0;
const plateHeight = ${secondaryDim >= 30 ? secondaryDim : 100}.0;
const plateThickness = 3.5;
const frameBorder = 5.0;
const frameThickness = 5.0;

function main() {
  const basePlate = cuboid({ size: [plateWidth, plateHeight, plateThickness] });
  const frameOuter = cuboid({ size: [plateWidth, plateHeight, frameThickness] });
  const frameInner = cuboid({
    size: [plateWidth - (frameBorder * 2), plateHeight - (frameBorder * 2), frameThickness + 2]
  });
  const frame = subtract(frameOuter, frameInner);
  const assembly = union(basePlate, frame);
  return translate([0, 0, frameThickness / 2], assembly);
}`;
  }

  if (p.includes('bracket') || p.includes('mount') || p.includes('brace')) {
    return `// Parametric Reinforced Angle Bracket (Template)
// Key dimensions in millimeters (live editable)
const legLengthA = ${primaryDim >= 20 ? primaryDim : 60}.0;
const legLengthB = ${secondaryDim >= 20 ? secondaryDim : 60}.0;
const bracketWidth = ${tertiaryDim >= 10 ? tertiaryDim : 35}.0;
const plateThickness = 5.0;
const gussetThickness = 4.0;
const holeDiameter = 5.2;

function main() {
  const legA = cuboid({ size: [legLengthA, bracketWidth, plateThickness] });
  const legB = cuboid({ size: [plateThickness, bracketWidth, legLengthB] });
  const gussetSize = Math.min(legLengthA, legLengthB) - plateThickness - 5;
  const gusset = cuboid({ size: [gussetSize, gussetThickness, gussetSize] });

  const baseStructure = union(
    translate([legLengthA / 2, 0, plateThickness / 2], legA),
    translate([plateThickness / 2, 0, legLengthB / 2], legB),
    translate([gussetSize / 2 + plateThickness, 0, gussetSize / 2 + plateThickness], gusset)
  );

  const hole = cylinder({ radius: holeDiameter / 2, height: plateThickness * 3, segments: 24 });
  return subtract(
    baseStructure,
    translate([legLengthA * 0.7, 0, 0], hole),
    translate([0, 0, legLengthB * 0.7], rotateY(Math.PI / 2, hole))
  );
}`;
  }

  return `// Parametric Electronics Enclosure Box (Template)
// Key dimensions in millimeters (live editable)
const boxLength = ${primaryDim >= 20 ? primaryDim : 100}.0;
const boxWidth = ${secondaryDim >= 20 ? secondaryDim : 60}.0;
const boxHeight = ${tertiaryDim >= 10 ? tertiaryDim : 25}.0;
const wallThickness = 3.0;
const cornerRadius = 3.0;
const mountingHoleDiameter = 4.0;
const cornerInset = 8.0;

function main() {
  const outerBox = roundedCuboid({
    size: [boxLength, boxWidth, boxHeight],
    roundRadius: cornerRadius,
    segments: 24
  });

  const innerCavity = roundedCuboid({
    size: [boxLength - (wallThickness * 2), boxWidth - (wallThickness * 2), boxHeight + 5],
    roundRadius: Math.max(1, cornerRadius - 1),
    segments: 24
  });

  const hollow = subtract(outerBox, translate([0, 0, wallThickness], innerCavity));
  const hole = cylinder({ radius: mountingHoleDiameter / 2, height: wallThickness * 4, segments: 24 });

  const hX = (boxLength / 2) - cornerInset;
  const hY = (boxWidth / 2) - cornerInset;

  const withHoles = subtract(
    hollow,
    translate([hX, hY, 0], hole),
    translate([-hX, hY, 0], hole),
    translate([hX, -hY, 0], hole),
    translate([-hX, -hY, 0], hole)
  );

  return translate([0, 0, boxHeight / 2], withHoles);
}`;
}
