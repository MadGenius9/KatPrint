# Plate Packer Fixes — src/engine/printPlatePacker.ts

Four bugs fixed in `computePrintPlatePlan`:

1. **Z height was ignored.** `partFitsZ` was computed and never used, so a part
   taller than the printer's build volume was laid out as if it fit. Parts
   exceeding Z now route to a flagged Oversized plate.

2. **No rotation.** Every part was placed at rotationZ 0, so a 200x40mm bar
   that fits rotated on a 220mm bed was pushed to its own plate. The packer now
   tries both orientations and records the rotation in `rotationDeg`.

3. **Hardcoded flow ceiling.** Print time used `Math.min(18, ...)` regardless of
   printer. Now bounded by that printer's `maxVolumetricFlow` from printers.ts,
   and nozzle diameter is read from the spec instead of assumed 0.4.

4. **Spurious empty plates.** When the first item was oversized, an empty plate
   was pushed before the overflow plate, inflating `totalPlates` and total time.
   Oversized parts are now separated up front and empty plates are never emitted.

Also: `fitsAllOnOnePlate` now requires that the single plate actually fits,
and `instances` is populated alongside `items` for the PlateLayoutModal.

Verified with: 300mm-tall part, 3x 200x40mm bars, two-piece planter,
6-quantity small part, and a mixed oversized set. `tsc --noEmit` clean,
`npm run build` clean.
