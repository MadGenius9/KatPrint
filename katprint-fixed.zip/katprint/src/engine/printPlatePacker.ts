import { ExecutedModelPart, PrinterSpec, PrintPlatePlan, PrintPlate, PlacedPartInstance } from '../types';

export interface PackingOptions {
  partSpacingMm?: number;
  bedMarginMm?: number;
  layerHeightMm?: number;
  printSpeedMmS?: number;
  infillPercent?: number;
}

/**
 * Computes an optimal 2D guillotine/shelf nesting layout for multi-part 3D prints across one or more print beds
 */
export function computePrintPlatePlan(
  parts: ExecutedModelPart[],
  printer: PrinterSpec,
  options: PackingOptions = {}
): PrintPlatePlan {
  const partSpacing = options.partSpacingMm ?? 10;
  const bedMargin = options.bedMarginMm ?? 10;
  const layerHeight = options.layerHeightMm ?? 0.2;
  const printSpeed = options.printSpeedMmS ?? 60;
  const infillFactor = ((options.infillPercent ?? 20) / 100) * 0.4 + 0.6;

  const bedWidth = Math.max(50, printer.buildVolume.x - bedMargin * 2);
  const bedDepth = Math.max(50, printer.buildVolume.y - bedMargin * 2);
  const bedHeight = printer.buildVolume.z;

  // Print time is bounded by the PRINTER's real flow ceiling, not a hardcoded constant.
  const theoreticalFlow = printSpeed * printer.nozzleDiameter * layerHeight * 1.5;
  const volumetricFlowMm3s = Math.max(1, Math.min(printer.maxVolumetricFlow || 12, theoreticalFlow));

  interface Instance {
    instanceId: string; partId: string; partName: string;
    width: number; depth: number; height: number;
    volumeCm3: number; weightGrams: number; requiresSupports: boolean;
  }

  const instancesToPlace: Instance[] = [];
  parts.forEach((part) => {
    const qty = Math.max(1, part.quantity || 1);
    const dims = part.stats?.dimensions || { x: 20, y: 20, z: 20 };
    const w = Math.max(1, dims.x);
    const d = Math.max(1, dims.y);
    const h = Math.max(1, dims.z);
    const vol = part.stats?.volumeCm3 || (w * d * h) / 1000;
    const weight = part.stats?.estimatedWeightGrams || vol * 1.24;
    for (let q = 1; q <= qty; q++) {
      instancesToPlace.push({
        instanceId: `${part.id}_inst_${q}`,
        partId: part.id,
        partName: qty > 1 ? `${part.name} (#${q})` : part.name,
        width: w, depth: d, height: h,
        volumeCm3: vol, weightGrams: weight,
        requiresSupports: !!part.requiresSupports,
      });
    }
  });

  const plates: PrintPlate[] = [];
  let plateIndex = 0;

  const estimatePlateMinutes = (volCm3: number, itemCount: number) => {
    const seconds = ((volCm3 * 1000) / volumetricFlowMm3s) * infillFactor + itemCount * 90;
    return Math.max(12, Math.round(seconds / 60));
  };

  // A part is oversized if it is too tall, or its footprint does not fit in
  // EITHER orientation. Z height was previously computed and then ignored.
  const fitsFootprint = (i: Instance) =>
    (i.width <= bedWidth && i.depth <= bedDepth) ||
    (i.depth <= bedWidth && i.width <= bedDepth);

  const oversized = instancesToPlace.filter((i) => i.height > bedHeight || !fitsFootprint(i));
  const packable = instancesToPlace.filter((i) => i.height <= bedHeight && fitsFootprint(i));

  packable.sort((a, b) => Math.max(b.width, b.depth) - Math.max(a.width, a.depth));

  let unplaced = [...packable];

  while (unplaced.length > 0) {
    const items: PlacedPartInstance[] = [];
    const deferred: Instance[] = [];

    let cursorX = -bedWidth / 2;
    let rowBaseY = -bedDepth / 2;
    let rowMaxDepth = 0;
    let plateVol = 0;
    let plateWeight = 0;
    let areaOccupied = 0;

    for (const item of unplaced) {
      // Try both orientations; rotate 90 degrees when it makes the part fit.
      const orientations = [
        { w: item.width, d: item.depth, rot: 0 },
        { w: item.depth, d: item.width, rot: 90 },
      ];

      let placed = false;
      for (const o of orientations) {
        const fitsInRow =
          cursorX + o.w <= bedWidth / 2 &&
          rowBaseY + Math.max(rowMaxDepth, o.d) <= bedDepth / 2;
        const fitsNewRow =
          o.w <= bedWidth &&
          rowBaseY + rowMaxDepth + partSpacing + o.d <= bedDepth / 2;

        if (fitsInRow || fitsNewRow) {
          if (!fitsInRow) {
            rowBaseY += rowMaxDepth + partSpacing;
            cursorX = -bedWidth / 2;
            rowMaxDepth = 0;
          }
          items.push({
            instanceId: item.instanceId,
            partId: item.partId,
            partName: item.partName,
            position: { x: cursorX + o.w / 2, y: rowBaseY + o.d / 2, z: 0 },
            rotationZ: o.rot,
            rotationDeg: o.rot,
            dimensions: { x: o.w, y: o.d, z: item.height },
            plateIndex,
            requiresSupports: item.requiresSupports,
          });
          plateVol += item.volumeCm3;
          plateWeight += item.weightGrams;
          areaOccupied += (o.w + partSpacing) * (o.d + partSpacing);
          cursorX += o.w + partSpacing;
          rowMaxDepth = Math.max(rowMaxDepth, o.d);
          placed = true;
          break;
        }
      }
      if (!placed) deferred.push(item);
    }

    // Never emit an empty plate; every packable item fits somewhere by construction.
    if (items.length === 0) {
      deferred.forEach((i) => oversized.push(i));
      break;
    }

    plates.push({
      plateIndex,
      plateName: `Plate ${plateIndex + 1}`,
      items,
      instances: items,
      occupiedAreaPercent: Math.min(100, Math.round((areaOccupied / (bedWidth * bedDepth)) * 100)),
      totalVolumeCm3: plateVol,
      estimatedWeightGrams: plateWeight,
      estimatedPrintTimeMinutes: estimatePlateMinutes(plateVol, items.length),
      fitsOnBed: true,
    });

    unplaced = deferred;
    plateIndex++;
  }

  // Each oversized part gets its own clearly flagged plate.
  oversized.forEach((item) => {
    const reasons: string[] = [];
    if (item.height > bedHeight) reasons.push(`${item.height.toFixed(1)}mm tall > ${bedHeight}mm Z`);
    if (!fitsFootprint(item)) reasons.push(`${item.width.toFixed(0)}×${item.depth.toFixed(0)}mm footprint`);
    plates.push({
      plateIndex,
      plateName: `Plate ${plateIndex + 1} (Oversized)`,
      items: [{
        instanceId: item.instanceId,
        partId: item.partId,
        partName: `${item.partName} — exceeds bed (${reasons.join(', ')})`,
        position: { x: 0, y: 0, z: 0 },
        rotationZ: 0,
        rotationDeg: 0,
        dimensions: { x: item.width, y: item.depth, z: item.height },
        plateIndex,
        requiresSupports: item.requiresSupports,
      }],
      occupiedAreaPercent: 100,
      totalVolumeCm3: item.volumeCm3,
      estimatedWeightGrams: item.weightGrams,
      estimatedPrintTimeMinutes: estimatePlateMinutes(item.volumeCm3, 1),
      fitsOnBed: false,
    });
    plateIndex++;
  });

  const totalVol = plates.reduce((a, p) => a + p.totalVolumeCm3, 0);
  const totalWeight = plates.reduce((a, p) => a + p.estimatedWeightGrams, 0);
  const totalTime = plates.reduce((a, p) => a + p.estimatedPrintTimeMinutes, 0);

  return {
    plates,
    totalPlates: plates.length,
    fitsAllOnOnePlate: plates.length === 1 && plates[0].fitsOnBed,
    totalVolumeCm3: totalVol,
    totalEstimatedWeightGrams: totalWeight,
    totalEstimatedPrintTimeMinutes: totalTime,
    printerBedDimensions: { x: printer.buildVolume.x, y: printer.buildVolume.y, z: printer.buildVolume.z },
  };
}
